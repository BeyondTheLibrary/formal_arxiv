import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

open BigOperators

namespace Workspace.Definitions.Tower

/-- Bundled "tower of minimum fragments" configuration.

For an `ℋ ⊆ 2^X` and `s ≥ 1`, a `TowerData ℋ s` packages the data of
samples `W = (W₁,…,W_s)`, a tower of minimum fragments `T = (T₁,…,T_s)` for
some `H ∈ ℋ`, together with the auxiliary "container" sets `(Ĥ_i)_{<b̂_i}`
that arise from the chosen witness of `t`-feasibility of `Z_i := T_i ∪ W_i`.

This bundles the deep results of Section 3 of the paper:

- The existence of the procedure that produces `(Ĥ_i)_{<b̂_i}` from `Z`.
- Lemma 3.5 (`fragment_contain`): `T_i ⊆ (Ĥ_i)_{<b̂_i}`.
- Pairwise disjointness of the `(Ĥ_i)_{<b̂_i}` (immediate from the procedure).
- Disjointness of `T_i` from `W_i` (definitional in the construction).

By separating these properties out as fields, the encoding surjection itself
becomes a purely combinatorial consequence of the bundle. The construction
of a `TowerData` from a given `(W, H)` is the deep content (axiomatised by
`Workspace.Lemmas.ProbGoodEvent.prob_good_event` in the present formalisation).

**Source**: @../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf
         (@../../../arXiv-2412.03540v1.tex, Section 3, Definitions 3.1–3.4)
-/
structure TowerData {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ) where
  /-- The samples `W_1,…,W_s`. -/
  W : Fin s → Finset X
  /-- The tower of minimum fragments `T_1,…,T_s`. -/
  T : Fin s → Finset X
  /-- The set `H ∈ ℋ` for which `T = T(W, H)` is the minimum tower. -/
  H : Finset X
  /-- The "container" sets `(Ĥ_i)_{<b̂_i}` from the chosen witness for
      `Z_i = T_i ∪ W_i`. -/
  container : Fin s → Finset X
  /-- `H` belongs to the family `ℋ`. -/
  H_mem : H ∈ ℋ
  /-- Each `T_i` is contained in `H`. -/
  T_subset_H : ∀ i, T i ⊆ H
  /-- Each `T_i` is disjoint from the corresponding `W_i`. -/
  T_disj_W : ∀ i, Disjoint (T i) (W i)
  /-- Lemma 3.5: each `T_i` is contained in its container `(Ĥ_i)_{<b̂_i}`. -/
  T_subset_container : ∀ i, T i ⊆ container i
  /-- The containers `(Ĥ_i)_{<b̂_i}` are pairwise disjoint
      (immediate from the iterative procedure). -/
  container_pairwise_disjoint :
    ∀ i j : Fin s, i ≠ j → Disjoint (container i) (container j)

namespace TowerData

variable {X : Type} [Fintype X] [DecidableEq X]
variable {ℋ : Set (Finset X)} {s : ℕ}

/-- The encoding `Z_i = T_i ∪ W_i`. -/
def Z (td : TowerData ℋ s) (i : Fin s) : Finset X := td.T i ∪ td.W i

/-- The encoding `U = ⋃ T_i`. -/
def U (td : TowerData ℋ s) : Finset X :=
  (Finset.univ : Finset (Fin s)).biUnion td.T

/-- The total size of the tower, `∑ |T_i|`. -/
def totalSize (td : TowerData ℋ s) : ℕ := ∑ i, (td.T i).card

end TowerData

end Workspace.Definitions.Tower
