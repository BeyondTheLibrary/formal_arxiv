import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.CoverCollection
import Workspace.Types.IsPSmall

open BigOperators
open Classical

namespace Workspace.Definitions.TFeasibility

open Workspace.Definitions.CoverCollection

/-! # Fiber and canonical `Z`-container (paper §3.2 Def 3.3–3.4, §3.3 surjection)

This file packages, on the **genuine min-tower cover** (`Workspace.Encoding.*`),
the surjection fiber over a recovery base `Z` and the *single canonical
`Z`-container* `R̂(Z)` of paper §3.3 (the `(b̂, Ŵ, Ĥ)(Z)` "function of `Z` alone"
step, `@../arXiv-2412.03540v1.tex` l.421–422).

# The objects

* `Fiber ℋ s lambda_vec Z u` — the finite set of pairs `(W, U)` with
  `U ∈ coverCollection ℋ s lambda_vec W` (the genuine non-empty min-tower cover
  element), `chosenZ ℋ s lambda_vec W U = Z`, and `|U| = u`.

* `CanonicalZContainer ℋ s lambda_vec Z u` — a single disjoint container family
  `R : ℕ → Finset X` such that *every* fiber element `(W, U)` over `(Z, u)`
  satisfies `U ⊆ ⋃_{i<s} R i`, recovers `W` via `liftW W i = Z i ∖ (U ∩ R i)`
  for `i < s`, and `|⋃_{i<s} R i| ≤ 2u`. This is the §3.3 fiber-uniformity
  object; its existence (scoped to `¬IsPSmall ℋ p`) is the R2 axiom
  `Workspace.Axioms.FiberUniformity.canonical_Z_container_exists`.

Because `chosenZ`/`chosenContainer`/`chosenT` are `ℕ`-indexed (built from the
min tower via `liftW`), `Z`, `u` and `R` here are `ℕ`-indexed too, with `i < s`
guards on the per-index recovery clauses (matching `chosenContainer_T_spec`).

**Source**: `@../arXiv-2412.03540v1.tex`, Section 3.2, Definitions 3.3–3.4,
Section 3.3 surjection `eq:surj` and the `(b̂, Ŵ, Ĥ)(Z)` step (l.421–422).
-/

variable {X : Type} [Fintype X] [DecidableEq X]

/-- The fiber over `(Z, u)`: pairs `(W, U)` with `U ∈ coverCollection ℋ s lambda_vec W`,
`chosenZ ℋ s lambda_vec W U hU = Z`, and `|U| = u`. -/
noncomputable def Fiber
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : ℕ → Finset X) (u : ℕ) :
    Finset ((W : Fin s → Finset X) × { U // U ∈ coverCollection ℋ s lambda_vec W }) :=
  ((Finset.univ : Finset (Fin s → Finset X)).sigma
      (fun W => (coverCollection ℋ s lambda_vec W).attach)).filter
    (fun p => chosenZ ℋ s lambda_vec p.1 p.2.val p.2.property = Z ∧ p.2.val.card = u)

/-- **Canonical `Z`-container family** (paper §3.3, the `(b̂, Ŵ, Ĥ)(Z)` step).

A single disjoint family `R : ℕ → Finset X` (a function of `Z`, `u` alone, not of
the particular fiber element) inside whose `⋃_{i<s} R i` every fiber element's
`U` sits, with the recovery `liftW W i = Z i ∖ (U ∩ R i)` for `i < s`, and
`|⋃_{i<s} R i| ≤ 2u`. -/
structure CanonicalZContainer
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : ℕ → Finset X) (u : ℕ) where
  R : ℕ → Finset X
  R_pairwise_disjoint :
    ∀ i j : ℕ, i ≠ j → Disjoint (R i) (R j)
  fiber_subset :
    ∀ p ∈ Fiber ℋ s lambda_vec Z u,
      p.2.val ⊆ (Finset.range s).biUnion R
  fiber_W_recovery :
    ∀ p ∈ Fiber ℋ s lambda_vec Z u,
      ∀ i, i < s → Z i \ (p.2.val ∩ R i) = liftW s p.1 i
  R_card_le : ((Finset.range s).biUnion R).card ≤ 2 * u

end Workspace.Definitions.TFeasibility
