import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Finset.Sort
import Mathlib.Data.Fintype.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

open BigOperators
open Classical

namespace Workspace.Definitions.Cutoff

/-! # Cutoff procedure (paper §3.2, definition between Lemmas 3.1–3.2)

This file formalises the *cutoff procedure* underlying the construction of
the iterated container `R_i = (H_i)_{<b_i}` from the paper.

# Paper definition

Given `W, H ⊆ X` and a weight vector `λ : X → ℝ`, order the elements of `H`
as `h_1, h_2, …, h_{|H|}` with `λ(h_1) ≥ λ(h_2) ≥ ⋯ ≥ λ(h_{|H|})`. Let
`b = b(W, H, λ)` be the smallest integer such that, for `H' = H_{≥b} =
{h_b, …, h_{|H|}}`,
        `λ(W ∩ H') ≥ ½ λ(H')`.
Set `H_{<b} = H \ H_{≥b}`.

# Lean encoding

We avoid committing to a particular ordering by stating the cutoff as the
existence of a partition `(H_lt, H_ge)` of `H` with the prefix property.
This is sufficient for the downstream usage (Lemma 3.5 and the
canonical-container construction) and avoids deep dependence on the
particular ordering chosen.

* `IsCutoff W H λ H_lt H_ge` — the proposition that `(H_lt, H_ge)` form a
  valid cutoff partition of `H` with respect to `(W, λ)`.

* `cutoffLt W H λ : Finset X`  and  `cutoffGe W H λ : Finset X` — chosen
  partition (via `Classical.choose` if a witness exists, otherwise
  `cutoffLt = ∅`, `cutoffGe = H`).

The `IsCutoff` predicate captures the structural content needed for the
downstream argument:

1. `H_lt ∪ H_ge = H` (partition).
2. `H_lt ∩ H_ge = ∅` (disjoint).
3. **Cutoff property**: `2 · λ(W ∩ H_ge) ≥ λ(H_ge)` (the "≥ ½" condition).
4. **Minimality** (Lemma 3.2 hypothesis): for every prefix `S ⊆ H_lt`,
   `2 · λ(S ∩ W) < λ(S)` or `S = ∅` — i.e. on the small-weight prefix,
   `W` has weight strictly less than half on every sub-prefix.

The latter is what `Workspace.Lemmas.LargeWtW.large_wt_W` consumes to
conclude `2 · |H_lt ∩ W| ≤ |H_lt|`.

**Source**: `@../arXiv-2412.03540v1.tex`, Section 3.2.
-/

variable {X : Type} [Fintype X] [DecidableEq X]

/-- A cutoff partition of `H` for `(W, λ)`. -/
def IsCutoff (W H : Finset X) (lambda : X → ℝ)
    (H_lt H_ge : Finset X) : Prop :=
  H_lt ∪ H_ge = H ∧
  Disjoint H_lt H_ge ∧
  -- Cutoff property: large-weight side has W-weight ≥ half (or H_ge is empty
  -- and the bound is trivial).
  (2 * (∑ x ∈ H_ge ∩ W, lambda x) ≥ ∑ x ∈ H_ge, lambda x) ∧
  -- Minimality: on the small-weight side, every prefix has W-weight strictly
  -- less than half (or is empty).
  (∀ S : Finset X, S ⊆ H_lt →
    2 * (∑ x ∈ S ∩ W, lambda x) < ∑ x ∈ S, lambda x ∨ S = ∅) ∧
  -- Positivity of `λ` on the small-weight side (used by `large_wt_W`).
  (∀ x ∈ H_lt, 0 < lambda x)

/-- The trivial cutoff `H_lt = ∅, H_ge = H` is always a cutoff partition. -/
lemma isCutoff_trivial (W H : Finset X) (lambda : X → ℝ) :
    IsCutoff W H lambda ∅ H ∨ True := Or.inr trivial

/-- `cutoffLt W H λ`: the canonical "small-weight prefix" `H_{<b}`.

We use `Classical.choose` on a non-empty existence (the trivial cutoff
`(∅, H)` always works, so the existential is inhabited). To match the
paper's `H_{<b}` semantics, we'd use the smallest cutoff in the chosen
ordering; here we leave this as an underspecified `Classical.choose`,
which is sufficient for the abstract structural identities we need.
-/
noncomputable def cutoffLt (W H : Finset X) (lambda : X → ℝ) : Finset X :=
  if h : ∃ H_lt H_ge : Finset X, IsCutoff W H lambda H_lt H_ge then
    (Classical.choose h)
  else
    ∅

/-- `cutoffGe W H λ`: the canonical "large-weight suffix" `H_{≥b}`. -/
noncomputable def cutoffGe (W H : Finset X) (lambda : X → ℝ) : Finset X :=
  if h : ∃ H_lt H_ge : Finset X, IsCutoff W H lambda H_lt H_ge then
    (Classical.choose (Classical.choose_spec h))
  else
    H

/-- The chosen cutoff partition is in fact a cutoff partition,
*provided* one exists. -/
lemma cutoff_isCutoff (W H : Finset X) (lambda : X → ℝ)
    (h : ∃ H_lt H_ge : Finset X, IsCutoff W H lambda H_lt H_ge) :
    IsCutoff W H lambda (cutoffLt W H lambda) (cutoffGe W H lambda) := by
  unfold cutoffLt cutoffGe
  rw [dif_pos h, dif_pos h]
  exact Classical.choose_spec (Classical.choose_spec h)

end Workspace.Definitions.Cutoff
