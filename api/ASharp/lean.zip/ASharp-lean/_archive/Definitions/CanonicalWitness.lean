import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.Cutoff
import Workspace.Definitions.IterativeR
import Workspace.Definitions.TFeasibility

open BigOperators
open Classical

namespace Workspace.Definitions.CanonicalWitness

open Workspace.Definitions.Cutoff
open Workspace.Definitions.IterativeR
open Workspace.Definitions.TFeasibility

/-! # Canonical `t`-feasibility witness `(b̂, Ŵ, Ĥ)(Z)` (paper §3.2, .tex lines 422-423)

This file makes **explicit** the paper's *implicit definitional choice* of a
canonical witness of the `t`-feasibility of `Z`.

# Paper quote (`.tex` lines 422-423)

> "Given **Z** and **t**, we make an arbitrary choice of a witness
> `(b̂, Ŵ, Ĥ) = (b̂, Ŵ, Ĥ)(Z)` of the **t**-feasibility of **Z**.
> (Note that such a choice must exist for **Z** = **Z**(**W**, H).)
> We define Ĥ_i = R_i(Ŵ, Ĥ) for i ∈ [s] according to the procedure preceding
> Definition \ref{def:feas}."

# Lean encoding

We make this choice explicit via `Classical.choose` from the proposition
`TFeasible ℋ s lambda_vec Z t` (which is `Nonempty (TFeasibilityWitness ...)`).

When `Z` is *not* `t`-feasible, we provide a default witness using
`H = ∅` (which trivially lives in any `ℋ` only if `∅ ∈ ℋ` — otherwise
the default is junk; this is fine since the canonical witness is only
*used* when `Z` is `t`-feasible).

# References

* Paper `@../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf`
* TeX source `@../../../arXiv-2412.03540v1.tex`, Section 3.2,
  paragraph immediately after Definition 3.4 (lines 420-423).
-/

variable {X : Type} [Fintype X] [DecidableEq X]

/-- The canonical `t`-feasibility witness `(b̂, Ŵ, Ĥ)(Z, t)`.

When `TFeasible ℋ s lambda_vec Z t` holds, this extracts a canonical
`TFeasibilityWitness` via `Classical.choose`. This is the **explicit Lean
lift** of the paper's implicit definitional choice (paper §3.2, .tex lines
422-423).

Note: while the paper writes `(b̂, Ŵ, Ĥ)(Z)` (suggesting Z-only
dependence), the witness mathematically depends on `(Z, t)` — see the proof
of Lemma 3.5 (`fragment_contain`), which uses the witness's `t`-feasibility
property for the *specific* `t = (|T_i|)` of the minimum tower being
analysed. We expose `t` as an explicit parameter for clarity.
-/
noncomputable def canonicalWitness
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) :
    TFeasibilityWitness ℋ s lambda_vec Z t :=
  h.some

/-- The canonical witness's underlying `Ŵ` (paper notation), as a function
of `(Z, t)` and a `t`-feasibility hypothesis. -/
noncomputable def canonicalW_hat
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) :
    Fin s → Finset X :=
  (canonicalWitness ℋ s lambda_vec Z t h).W'

/-- The canonical witness's underlying `Ĥ` (paper notation), as a function
of `(Z, t)` and a `t`-feasibility hypothesis. -/
noncomputable def canonicalH_hat
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) :
    Finset X :=
  (canonicalWitness ℋ s lambda_vec Z t h).H

lemma canonicalH_hat_mem
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) :
    canonicalH_hat ℋ s lambda_vec Z t h ∈ ℋ :=
  (canonicalWitness ℋ s lambda_vec Z t h).H_mem

/-- **The canonical `R̂_i` family** (paper §3.2, .tex lines 422-423):

    Ĥ_i := R_i(Ŵ, Ĥ)  for i ∈ [s]

(Despite the paper using `Ĥ_i` for these, we use `canonicalR` to avoid
collision with the `Ĥ ∈ ℋ` symbol.) -/
noncomputable def canonicalR
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) (i : Fin s) :
    Finset X :=
  R_at (canonicalW_hat ℋ s lambda_vec Z t h)
       (canonicalH_hat ℋ s lambda_vec Z t h)
       (lambda_vec (canonicalH_hat ℋ s lambda_vec Z t h)
                   (canonicalH_hat_mem ℋ s lambda_vec Z t h))
       i

/-- **The canonical `Y(Z, t)`** (paper §3.3, eq. 3.6 ambient set):

    Y(Z, t) = ⋃_{i=1}^s R̂_i

This is the ambient set in the paper's surjection
`Ψ_u : {(Z, U) : U ⊆ Y(Z, t), |U| = u} → ...`. -/
noncomputable def canonicalY
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) :
    Finset X :=
  (Finset.univ : Finset (Fin s)).biUnion (canonicalR ℋ s lambda_vec Z t h)

/-! ## Structural properties of the canonical witness

The structural identities of the underlying `TFeasibilityWitness` carry
over to the canonical witness via `Classical.choose_spec`. -/

/-- The canonical `Ŵ_i ⊆ Z_i` (.tex line 396, Definition 3.3 condition). -/
lemma canonicalW_hat_subset
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) (i : Fin s) :
    canonicalW_hat ℋ s lambda_vec Z t h i ⊆ Z i :=
  (canonicalWitness ℋ s lambda_vec Z t h).W'_subset i

/-- The canonical `|Ŵ_i| = |Z_i| - t_i` (.tex line 396, Definition 3.3). -/
lemma canonicalW_hat_card
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) (i : Fin s) :
    (canonicalW_hat ℋ s lambda_vec Z t h i).card = (Z i).card - t i :=
  (canonicalWitness ℋ s lambda_vec Z t h).W'_card i

/-- The canonical `R̂_i ⊆ Z_i` (.tex line 396, Definition 3.3 containment). -/
lemma canonicalR_subset_Z
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) (i : Fin s) :
    canonicalR ℋ s lambda_vec Z t h i ⊆ Z i :=
  (canonicalWitness ℋ s lambda_vec Z t h).R_subset_Z i

end Workspace.Definitions.CanonicalWitness
