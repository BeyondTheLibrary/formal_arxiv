import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.Cutoff

open BigOperators
open Classical

namespace Workspace.Definitions.IterativeR

open Workspace.Definitions.Cutoff

/-! # Iterative procedure for `H_i`, `b_i`, `R_i`
(paper §3.2, paragraph between Lemma 3.2 and Definition 3.3)

Given `W = (W_1, …, W_s)` and `H ∈ ℋ`, the paper defines:
* `H_1 = H`,
* `b_i = b(W_i, H_i, λ_H)` (the cutoff of Definition 3.1 on the current set),
* `H_{i+1} = (H_i)_{≥ b_i} \ W_i`,
* `R_i(W, H) = (H_i)_{<b_i}`,
* `R(W, H) = ⋃_{i=1}^s R_i`.

We use the abstract `cutoffLt` / `cutoffGe` from `Cutoff.lean` to define the
iterative `H_at` and `R_at` over `Fin s`.

# Lean encoding

Since `Fin s` doesn't admit straightforward primitive recursion, we define
the iteration by recursion on `i.val : ℕ` and use `Fin.mk` to access fields.
-/

variable {X : Type} [Fintype X] [DecidableEq X]

/-- The iterative `H_i` from the paper's procedure. `H_at W H λ 0 = H`,
`H_at W H λ (i+1) = cutoffGe W_i (H_at i) λ \ W_i`. -/
noncomputable def H_at_nat (W : ℕ → Finset X) (H : Finset X) (lambda : X → ℝ) :
    ℕ → Finset X
  | 0 => H
  | i + 1 =>
    let H_i := H_at_nat W H lambda i
    cutoffGe (W i) H_i lambda \ W i

/-- The iterative `R_i = (H_i)_{<b_i}` from the paper's procedure. -/
noncomputable def R_at_nat (W : ℕ → Finset X) (H : Finset X) (lambda : X → ℝ)
    (i : ℕ) : Finset X :=
  cutoffLt (W i) (H_at_nat W H lambda i) lambda

/-- `Fin s` version of `H_at`: indexes by `Fin s` via `i.val`, treating any
`W : Fin s → Finset X` as a function on `ℕ` (zero outside `[0, s)`). -/
noncomputable def H_at {s : ℕ} (W : Fin s → Finset X) (H : Finset X)
    (lambda : X → ℝ) (i : ℕ) : Finset X :=
  H_at_nat (fun n => if h : n < s then W ⟨n, h⟩ else ∅) H lambda i

/-- `Fin s` version of `R_at`. -/
noncomputable def R_at {s : ℕ} (W : Fin s → Finset X) (H : Finset X)
    (lambda : X → ℝ) (i : Fin s) : Finset X :=
  R_at_nat (fun n => if h : n < s then W ⟨n, h⟩ else ∅) H lambda i.val

/-- `H_at` at index 0 is `H`. -/
lemma H_at_zero {s : ℕ} (W : Fin s → Finset X) (H : Finset X)
    (lambda : X → ℝ) :
    H_at W H lambda 0 = H := rfl

end Workspace.Definitions.IterativeR
