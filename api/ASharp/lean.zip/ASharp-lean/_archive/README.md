# `_archive/` — dead code removed from the build (2026-06-13)

These files were **not in the `Workspace.MainTheorem` import closure** — the live proof bypasses them
and routes the entire §3.2–3.3 content through the single axiom
`Workspace.Axioms.CanonicalRWitness.canonical_R_for_fiber`. They were moved here (out of the Lake-globbed
`Workspace/` tree) so they no longer compile or clutter the main folder, **but are preserved** because
some are genuine partial attempts that will be useful when we replace the axiom with a real
formalization of §3.2–3.3.

To restore a file for reuse: move it back under `lean_workspace/Workspace/...` (same relative subdir) and
re-add the relevant `import`. The single live edit that detached this whole set was removing
`import Workspace.Lemmas.Lemma_SurjectionExists` from `Workspace/Lemmas/Lemma_KeyLemma.lean`.

Build status at archival: `lake build` green; `main_theorem` axioms = {propext, Classical.choice,
Quot.sound, canonical_R_for_fiber}. No `sorry` anywhere. None of the archived files contained `sorry` or
`axiom` either (they compiled), but several are mathematically vacuous (see below).

## GENUINE / REUSABLE (faithful proofs of real sub-steps — reuse when killing the axiom)

- **`Lemmas/Lemma_RAtDisjoint.lean`** — `R_at_pairwise_disjoint`: pairwise disjointness of the iterative
  family `R_i = (H_i)_{<b_i}` from the cutoff partition + `H_at_nat` monotonicity. **Genuine, faithful**
  proof of the disjointness the paper uses (§3.2 procedure). Directly reusable. Also contains useful
  helper lemmas: `H_at_nat_succ_subset`, `H_at_nat_mono`, `cutoffLt_cutoffGe_disjoint`.
- **`Definitions/CanonicalWitness.lean`** — `canonicalWitness`/`canonicalW_hat`/`canonicalH_hat`/
  `canonicalR`/`canonicalY` + projection lemmas. Genuine plumbing that makes the paper's "arbitrary
  choice of witness `(b̂,Ŵ,Ĥ)(Z)`" (.tex 422) explicit via `Classical.choose`. Reusable scaffolding.
- **`Lemmas/Lemma_MinimumTowerExists.lean`** — MIXED. Contains genuine reusable helper lemmas about the
  cutoff/iterative procedure (`cutoffLt_subset`, `cutoffGe_subset`, `H_at_nat_subset`, `R_at_subset_H`,
  `towerSet`/`cardVec` lex-min machinery) — reusable. BUT its headline `minimum_tower_exists` is
  effectively discharged via the `trivialTower` (empty tower), so the existence claim itself is weak.
- **`Lemmas/Lemma_CanonicalRDisjoint.lean`** — `canonicalR_pairwise_disjoint`: disjointness of the
  canonical-witness family, built on `R_at_pairwise_disjoint`. Likely genuine/reusable.
- **`Lemmas/Lemma_MaxLeSum.lean`, `Lemmas/Lemma_SumPositiveCardOnly.lean`** — generic Finset/∑ helpers,
  possibly reusable as utilities.

## VACUOUS / UNFAITHFUL (do not match a paper claim — re-prove faithfully before reuse)

These state paper lemmas as "proven in Lean" but do not prove the paper's claim:

- **`Lemmas/Lemma_FragmentContain.lean`** — `fragment_contain` claims **Lemma 3.6** but takes the substantive
  content as hypotheses (`_h_min : ∀ S ⊆ T_i, S ⊆ container_i` literally *is* `T_i ⊆ container_i`;
  `_h_large_wt`, `_h_min_size` handed in) and only does trivial card arithmetic. VACUOUS. A faithful
  Lemma 3.6 must prove the inclusion by minimality and the size bound via Lemma 3.2.
- **`Lemmas/Lemma_LargeWtW.lean`** — `large_wt_W` claims **Lemma 3.2** but its hypothesis `h_cut` is
  quantified over **all** subsets (not just the λ-ordered prefixes `H_{[b',b)}`), which is stronger than
  the paper and forces `H_{<b} ∩ W = ∅`; it proves emptiness, not the `≤ ½` summation-by-parts bound.
  WRONG/VACUOUS. A faithful Lemma 3.2 needs the ordering of `H` by `λ` and summation by parts.
- **`Lemmas/Lemma_TowerExists.lean`** — `tower_exists` claims **Lemma 3.5** (minimum tower well-defined)
  but discharges it with the **trivial empty tower** (`T_i = ∅`, `container_i = ∅`). VACUOUS — because
  `Definitions/Tower.lean`'s `TowerData` structure is too weak (no minimality, no `2|T_i| ≥ |container_i|`
  size bound, no requirement that `container` is the cutoff family).
- **`Lemmas/Lemma_SurjectionExists.lean`** — `surjection_exists`, built on `tower_exists`; inherits the
  vacuity of the trivial tower.
- **`Lemmas/Lemma_Surjection.lean`** — `surjection_psi`: a *genuine* proof of the recovery identities
  (`U ∩ container_i = T_i`, `Z_i \ (U ∩ container_i) = W_i`) **given a `TowerData`**, but since `TowerData`
  is the too-weak structure above, it is not the real surjection `eq:surj` (which needs the cutoff
  containers + size bound). Reusable as the recovery-step skeleton once `TowerData` is strengthened.

## TRIVIAL / EMPTY (honest, low value)

- **`Lemmas/Lemma_CoverCostBound.lean`** — `cover_cost_bound`: original axiom had conclusion `True`; now a
  trivial theorem. Honest but content-free.
- **`Lemmas/Lemma_FiberTFeasible.lean`** — no declarations (superseded historical file).

## (was) STILL LIVE but FLAGGED — now archived in the second pass below

- **`Definitions/Tower.lean`** (`TowerData`) — the too-weak structure underpinning the vacuous surjection
  chain above. Now ARCHIVED (second cleanup pass, see below); its stale imports in `Lemma_KeyLemma` /
  `Lemma_LevelSetCount` were removed. Superseded by `Encoding/TowerFrag.lean` + `Encoding/MinTower.lean`.

See `../../proving_notes.md` for the full faithfulness audit and the plan to replace `canonical_R_for_fiber`.

## Second cleanup pass (2026-06-13) — loose §3 defs superseded by the genuine Encoding chain

Archived because the genuine `Workspace/Encoding/*` chain (Lemma 3.2, procedure, t-feasibility, tower, min
tower, Lemma 3.6, Lemma 3.8, container) now supersedes them, and they were unused/loose definitions:
- `Definitions/Cutoff.lean` — loose `IsCutoff` (too-strong minimality over all subsets), vacuous
  `isCutoff_trivial` (`_ ∨ True`), underspecified `Classical.choose` `cutoffLt`/`cutoffGe`. No live use.
  REPLACED by the genuine list-sorted cutoff in `Encoding/Lemma32_LargeWeight.lean` + `Encoding/Procedure.lean`.
- `Definitions/IterativeR.lean` — `H_at`/`R_at` over the loose cutoff. No live use. REPLACED by
  `Encoding/Procedure.lean` (`Hstep`/`Rstep`).
- `Definitions/Tower.lean` — the too-weak `TowerData` (postulated containment, dropped the size bound). No
  live term use. REPLACED by `Encoding/TowerFrag.lean` + `Encoding/MinTower.lean`.

Also removed (not archived, were dead defs inside a still-live file): `Definitions/TFeasibility.TFeasible` and
`TFeasibility.TFeasibilityWitness` (used the loose `R_at`; only comment-referenced). The live
`TFeasibility.lean` now keeps ONLY `Fiber` + `CanonicalZContainer` (consumed by `Lemma_FiberInjection`).
Build stays green; `main_theorem` axiom set unchanged.
