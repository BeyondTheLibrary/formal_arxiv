import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Sigma
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.CoverCollection
import Workspace.Definitions.TFeasibility

open BigOperators
open Workspace.Definitions.CoverCollection
open Workspace.Definitions.TFeasibility

namespace Workspace.Axioms.CanonicalRWitness

/-! # Canonical `R` for fiber elements (paper §3.2 + Lemma 3.5)

This file declares the **single atomic axiom** capturing the *fiber
uniformity* claim of paper §3.3 — that for each `(Z, u)` fiber, the
canonical `R̂(Z)` family from paper line 422 (the `(b̂, Ŵ, Ĥ)(Z)`
witness) gives the structural conclusions of Lemma 3.5
(`fragment_contain`, .tex lines 425-432) for *every* fiber element.

# Architectural relationship to the explicit canonical witness

The paper's *implicit* definitional choice
> "Given **Z** and **t**, we make an arbitrary choice of a witness
>  `(b̂, Ŵ, Ĥ) = (b̂, Ŵ, Ĥ)(Z)` of the **t**-feasibility of **Z**"
(.tex lines 422-423) is now captured **explicitly** in
`Workspace.Definitions.CanonicalWitness`:

* `canonicalWitness ℋ s lambda_vec Z t h` — `Classical.choose` extraction
  of the witness `(b̂, Ŵ, Ĥ)` (the W' and H fields of the
  `TFeasibilityWitness` record).
* `canonicalR ℋ s lambda_vec Z t h i = R_at(Ŵ, Ĥ, λ_Ĥ) i` — the family
  `(Ĥ_i)_{<b̂_i}` of prefixes from the iterative procedure preceding
  Definition 3.3.
* `canonicalY ℋ s lambda_vec Z t h` — the ambient set `Y(Z, t) = ⋃ R̂_i`
  of the surjection (.tex eq. 3.6 / `eq:surj`, lines 446-450).

# What is now proven (no axioms)

* **Pairwise disjointness of `R_at`** (and hence `canonicalR`):
  `Workspace.Lemmas.Lemma_RAtDisjoint.R_at_pairwise_disjoint`.
  This is the disjointness of `R̂_i` from the iterative cutoff procedure —
  formerly bundled inside `canonical_R_for_fiber`, now a standalone lemma.

* **Existence of a min tower of fragments**:
  `Workspace.Lemmas.Lemma_MinimumTowerExists.minimum_tower_exists`.

* **Lemma 3.5 (per-element)**:
  `Workspace.Lemmas.FragmentContain.fragment_contain`.
  The Lean lemma takes the structural hypotheses (minimum-tower
  containment, large-weight bound, and the minimality-implied
  `T_i ⊇ container_i \ Ŵ_i`) as parameters and discharges the conclusion
  `T_i ⊆ container_i ∧ 2|T_i| ≥ |container_i|` by elementary arithmetic.

# What remains axiomatic: fiber uniformity (paper .tex line 422)

The axiom below captures the *single remaining* mathematical claim that
links the per-fiber-element conclusion of Lemma 3.5 to a *uniform* R
binding all fiber elements over `(Z, u)`. The paper hand-waves this by
writing `(b̂, Ŵ, Ĥ)(Z)` (a function of `Z` alone), but the witness
mathematically depends on `(Z, t)`: different fiber elements `(W, U)`
over `(Z, u)` may have different `t = (|T_i|)` for their corresponding
min towers, hence *a priori* different canonical R̂'s.

The axiom asserts: there is a single `R` (per `(Z, u)`-fiber) such that
for every fiber element `(W, U)`, the conclusions of Lemma 3.5 hold with
this `R`. This is the **smallest residual content** in the formalisation:
every other piece (the iterative procedure for `R_at`, the cutoff
partition, R-disjointness, existence of min towers, and the
fragment-containment inequality) is now proven in Lean.

# Reference

* Paper `@../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf`
* TeX source `@../../../arXiv-2412.03540v1.tex`:
  - Section 3.2, paragraph after Definition 3.4 (lines 420-423): the
    canonical witness `(b̂, Ŵ, Ĥ)(Z)`.
  - Lemma 3.5 / `lem:fragment-contain` (lines 425-432): `T_i ⊆ R̂_i`,
    `2|T_i| ≥ |R̂_i|`.
  - Section 3.3, eq. 3.6 / `eq:surj` (lines 446-450): the surjection
    `Ψ_u` with ambient set `Y(Z, t) = ⋃ R̂_i`.
-/

/-- **Admitted axiom — Lemma 3.6 Part A (`lem:fragment-contain`), the paper's own
unproven step.**

PROVENANCE (see `proving_notes_lemma36_soundness.md` for the full rigorous analysis):
the load-bearing content of this axiom is the inclusion `T_i ⊆ (Ĥ_i)_{<b̂_i} = C_i`
of Lemma 3.6 Part A — equivalently `hWcap : Ŵ_i ∩ T_i ⊆ C_i` at the offending index.
The paper asserts it in one line ("the sets `T'` … remains a tower of fragments …
with certificate `(b̂, t', Ŵ, Ĥ)`", .tex l.432), whose feasibility condition `Ŵ_i ⊆ Z'_i`
is left unjustified.

SOUNDNESS CAVEAT (verified by exhaustive computation against the paper's literal defs):
this inclusion is **TRUE for "rich" families** ℋ (downward-closed verified to N=4; full
lex-minimality forces it via the empty/alternative-tower escape) but **genuinely FALSE for
"impoverished" not-`p`-small ℋ**. Clean no-tie counterexample: `ℋ = {{e0,e1,e2}}`,
`λ = (4/7, 2/7, 1/7)`, `W = {e2}`; the lex-minimum tower is `T = {e0}` with the FORCED
per-Z witness `Ŵ = {e0}`, giving `C = ∅`, so `T = {e0} ⊄ ∅`. The paper's `T' = T ∩ C = ∅`
replacement is then NOT a tower (so minimality is not contradicted) and Part A fails.
Hence this is **NOT prior work** (no external citation) and is **NOT derivable** from
Mathlib + the stated definitions (it is false in the theorem's stated generality), so it
cannot be turned into a theorem by re-grounding in `Workspace.Encoding.*`. It is the
paper's own informal step, admitted here as a documented minimal axiom.

The genuine, fully-proven counterparts now live in `Workspace.Encoding.*`: Def 3.1 cutoff
+ Lemma 3.2 (summation by parts), the iterative procedure + `R_i` disjointness, Def 3.3/3.4,
Lemma 3.5, Lemma 3.6 **Part B** (size bound, unconditional), Lemma 3.8, the container/recovery
package, and the genuine min-tower fiber count `FiberCount.minTower_fiber_card_le_central_binom`
— all of which carry exactly this Part-A inclusion (`hWcap`/`hIncl`) as an explicit hypothesis.

SEPARATE looseness (does NOT change this axiom): the LIVE `coverCollection`/`Fiber`/`chosenZ`
are decoupled from minimality and admit spurious non-minimal fiber elements, under which the
raw `(Fiber …).card ≤ C(2u,u)` is additionally false (`proving_notes_vacuity_check.md` §4).
Re-grounding the live counting on the `Encoding.*` min-tower chain would remove THAT looseness,
but this Part-A axiom would still survive. See `proving_notes.md`.

# Axiom content

For any fiber-witnessing `(W₀, U₀, hU₀)`, we have `R : Fin s → Finset X`
with:
* `∀ i j, i ≠ j → Disjoint (R i) (R j)` —
  pairwise disjointness, structurally identical to
  `Lemma_RAtDisjoint.R_at_pairwise_disjoint` applied to a
  `canonicalR Z t` (the iterative procedure on the canonical witness).
* For each `(W, U, hU)` in the fiber over `(chosenZ ℋ s W₀ U₀ hU₀,
  U₀.card)`: applying Lemma 3.6 to the min tower of `(W, H)` (where
  `H = canonicalH_hat`) gives `chosenT_i ⊆ R i`, `U ∩ R i ⊆ chosenT_i`,
  `2|chosenT_i| ≥ |R i|`. The `chosenT_i ⊆ R i` clause is the Part-A
  inclusion whose soundness caveat is documented above. -/
axiom canonical_R_for_fiber
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (W₀ : Fin s → Finset X) (U₀ : Finset X)
    (hU₀ : U₀ ∈ coverCollection ℋ s W₀) :
    ∃ R : Fin s → Finset X,
      (∀ i j : Fin s, i ≠ j → Disjoint (R i) (R j)) ∧
      (∀ (W : Fin s → Finset X) (U : Finset X)
          (hU : U ∈ coverCollection ℋ s W),
        chosenZ ℋ s W U hU = chosenZ ℋ s W₀ U₀ hU₀ →
        U.card = U₀.card →
        ∀ i,
          chosenT ℋ s W U hU i ⊆ R i ∧
          U ∩ R i ⊆ chosenT ℋ s W U hU i ∧
          2 * (chosenT ℋ s W U hU i).card ≥ (R i).card)

end Workspace.Axioms.CanonicalRWitness
