import Workspace.Definitions.TFeasibility
import Workspace.Types.IsPSmall

namespace Workspace.Axioms.FiberUniformity

open Workspace.Definitions.CoverCollection
open Workspace.Definitions.TFeasibility
open Workspace.Types.IsPSmall

/-! # R2 — Fiber-uniformity: the single canonical `Z`-container (paper §3.3).

**Source**: `@../arXiv-2412.03540v1.tex`, Section 3.3, the surjection-count of
`lem:key`, eq. `eq:surj` (l.446–450), and the `(b̂, Ŵ, Ĥ)(Z)` "arbitrary choice
of a witness, a function of `Z` alone" step (l.421–422).

This is the SECOND of the two genuinely-informal residuals the paper hand-waves
(the first being Lemma 3.6 Part A, admitted as
`Workspace.Axioms.Lemma36PartA.minTower_part_A_inclusion`). Together they replace
the FALSE monolithic axiom `canonical_R_for_fiber`.

## What it asserts

For each recovery base `Z : ℕ → Finset X` and level `u`, there exists a SINGLE
canonical disjoint container family `R̂(Z) : ℕ → Finset X` such that EVERY genuine
min-tower fiber element `(W, U)` over `(Z, u)` (i.e. every
`p ∈ Fiber ℋ s lambda_vec Z u`) has

* `U ⊆ ⋃_{i<s} R̂ i`,
* `liftW W i = Z i ∖ (U ∩ R̂ i)` for `i < s`  (the surjection recovery `eq:surj`),
* `|⋃_{i<s} R̂ i| ≤ 2u`.

This is exactly `Nonempty (CanonicalZContainer ℋ s lambda_vec Z u)`.

## Why a single shared container is needed, and why it does not follow from R1

`lem:key` groups the surjection's codomain by `(Z, u)` and bounds each fiber by
`C(2u, u) = #{ U' ⊆ Y(Z) : |U'| = u }` using `∑_Z B(Z) = 1`. This requires ONE
ground set `Y(Z) = ⋃ R̂(Z)_i` shared by all fiber elements over `(Z, u)`. The
genuine min-tower containers (`Workspace.Encoding.ContainerFromMinTower`) are
*per element* (per `(W, H, Ŵ, Ĥ)`): different fiber elements over the same `Z`
carry different `t`-profiles `t = (|T_i|)` (only `∑ t_i = u` is fixed), and a
`t`-specific witness's container need not transfer. So R2 does NOT follow from
R1 (Part A) — it is a genuinely distinct fact.

## SOUNDNESS (verified, in-regime)

`#Fib(Z, u) ≤ C(2u, u)` — equivalently the single-shared-container R2 — is TRUE
for not-`p`-small ℋ at `p ≤ 1/16`, and FALSE only for `p`-small ℋ (which the
selector theorem `sharp_selector_theorem` excludes via its `¬ IsPSmall ℋ p`
hypothesis). Verified by exhaustive computation against the paper's literal defs
(`proving_notes_fiberuniformity_verify.md`):

* In-regime witness `singletons-9` (`ℋ = {{0},…,{8}}`, `c_int@1/16 = 9/16`,
  genuinely not-`(1/16)`-small): 0 counterexamples.
* The smallest `p` at which any R2-violating family becomes not-`p`-small is
  `33/128 ≈ 0.258`, a factor `> 4` above the selector regime `p ≤ 1/16`.
* Out-of-regime counterexample (`p`-small): `ℋ = {{0,1,2}}`, `s = 2`,
  `Z = ((0,1),(2,))`, `u = 1` gives `#Fib = 3 > C(2,1) = 2`; this ℋ has
  `c_int@1/16 = 1/4096`, solidly `p`-small.

The structural reason: an R2 failure needs small cutoff containers, i.e. an
*impoverished* (cheap-to-cover) ℋ — exactly the regime where a cheap integral
cover exists, i.e. `p`-small. "R2 fails" and "not-`p`-small" are structurally
opposed, and at `p ≤ 1/16` the opposition is total.

Hence R2 is admitted as a MINIMAL `¬ IsPSmall ℋ p`-scoped axiom. It is the
paper's own informal `(b̂, Ŵ, Ĥ)(Z)` step (NOT prior work), and the regime
reduction is paper-absent. The caller (`Lemma_KeyLemma.key_lemma_bound`) supplies
`¬ IsPSmall ℋ p` from its own hypotheses, so no statement is weakened. -/
axiom canonical_Z_container_exists
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (p : ℝ) (h_not_small : ¬ IsPSmall ℋ p)
    (Z : ℕ → Finset X) (u : ℕ) :
    Nonempty (CanonicalZContainer ℋ s lambda_vec Z u)

end Workspace.Axioms.FiberUniformity
