import Workspace.Encoding.ContainerFromMinTower
import Workspace.Types.IsPSmall

namespace Workspace.Axioms.Lemma36PartA

open Workspace.Encoding.Procedure
open Workspace.Encoding.MinTower
open Workspace.Types.IsPSmall

/-- Lemma 3.6 Part A (`lem:fragment-contain` inclusion), the paper's single
genuinely-informal step. TRUE for ¬IsPSmall ℋ p (verified exhaustively; FALSE for
p-small ℋ, which the selector theorem excludes). The W-disjointness companion is
NOT needed — it is now provable from `IsTowerOfFragments`'s disjointness conjunct
(`minTower_isTower`). Admitted minimally, replacing the false monolithic
`canonical_R_for_fiber`. See proving_notes_lemma36_soundness.md. -/
axiom minTower_part_A_inclusion
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ) (W : ℕ → Finset X)
    (H : Finset X) (hH : H ∈ ℋ)
    (p : ℝ) (h_not_small : ¬ IsPSmall ℋ p)
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hZsub : ∀ i, i < s → Wh i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)
    (hZcard : ∀ i, i < s → (Wh i).card
        = (minTower ℋ s lambda_vec W H hH i ∪ W i).card
            - (minTower ℋ s lambda_vec W H hH i).card)
    (hRsub : ∀ i, i < s → Workspace.Encoding.Procedure.Rstep Wh Hh (lambda_vec Hh hHh) i
        ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i) :
    ∀ i, i < s → minTower ℋ s lambda_vec W H hH i
        ⊆ Workspace.Encoding.Procedure.Rstep Wh Hh (lambda_vec Hh hHh) i

end Workspace.Axioms.Lemma36PartA
