import Workspace.Encoding.ContainerFromMinTower
import Workspace.Lemmas.Lemma_LevelSetCount

open BigOperators
open Classical

namespace Workspace.Encoding.FiberCount

/-! # Section 3.3 — the genuine min-tower fiber-count bound `C(2u,u)`.

**Source**: `@../arXiv-2412.03540v1.tex`, Section 3.3, proof of Lemma `lem:key`
(the surjection `eq:surj` and the displayed counting chain).

The paper bounds, for a fixed `Z` and `u`, the inner sum

  `Σ_{U ⊆ Y(Z), |U|=u} 1  =  #{ U ⊆ Y(Z) : |U| = u }  ≤  C(|Y(Z)|, u)  ≤  C(2u, u)`,

where `Y(Z) := ⋃_{i<s} (Ĥ(Z)_i)_{<b̂(Z)_i}` is the **single** `Z`-canonical
ground set (a function of `Z` alone), `|Y(Z)| ≤ 2u` by Lemma 3.6, and each fiber
element `(W, U)` injects into `{ U ⊆ Y(Z) : |U| = u }` via `(W,U) ↦ U` because
`W` is recovered from `(Z, U)` by `W_i = Z_i ∖ (U ∩ R_i)` (`eq:surj`).

This file delivers the **genuine** version of the (FALSE) live `fiber_count_bound`,
now grounded in the **minimum** tower: the spurious non-minimal fiber elements
that break the live statement (see `proving_notes_vacuity_check.md`) are absent,
because the ground set `Y(Z)` here is the canonical container family
`R i := Rstep Ŵ Ĥ λ_Ĥ i` built from the genuine `t`-feasibility witness of the
minimum tower (`ContainerFromMinTower`), whose `⋃` has card `≤ 2u`
(`bUnion_R_card_le`) and against which the fiber injects via the genuine recovery
(`recovery`).

Two theorems:

1. `fiber_card_le_central_binom` — the abstract counting core. Given any disjoint
   container family `R`, any base family `Z`, and a `Finset` `Fib` of `(W, U)`
   data each of whose `U` is a `u`-subset of `⋃_{i<s} R i` and whose `W` is the
   recovered family `fun i => Z i ∖ (U ∩ R i)`, together with `|⋃R| ≤ 2u`,
   conclude `Fib.card ≤ C(2u, u)`. The injection `(W,U) ↦ U` into
   `{ U' ⊆ ⋃R : |U'| = u }` is genuine (recovery makes `U` determine `W`), and
   that level set has card `≤ C(2u,u)` by `levelSetCount_le_central_binom_of_card_le`.

2. `minTower_fiber_card_le_central_binom` — the same bound instantiated at the
   min-tower container `R i = Rstep Ŵ Ĥ λ_Ĥ i`, `Z i = T i ∪ W i`, carrying the
   *exact same* residual hypotheses (`hIncl` = Lemma 3.6 Part A inclusion, the
   `t`-feasibility witness data, `hpos`) that `ContainerFromMinTower` takes — and
   nothing more. The `≤ 2u` ground-set bound and the recovery are both *proved*
   here from those inputs (`bUnion_R_card_le`), so this is the faithful, genuine
   replacement for the live `fiber_count_bound`.

No `sorry`, no `admit`, no new `axiom`. The residual `hWcap`/`hIncl` is an
explicit **hypothesis** of theorem 2, not an axiom; theorem 1 is unconditional. -/

variable {X : Type} [Fintype X] [DecidableEq X]

open Workspace.Encoding.Procedure
open Workspace.Encoding.TowerFrag
open Workspace.Encoding.MinTower
open Workspace.Encoding.FragmentContain
open Workspace.Encoding.ContainerFromMinTower
open Workspace.Lemmas.LevelSetCount

/-! ## 1. The abstract counting core.

A *fiber element* is a pair `(W, U) : (ℕ → Finset X) × Finset X`. Fix the base
family `Z : ℕ → Finset X`, the container family `R : ℕ → Finset X`, the index
bound `s`, and the level `u`. The ground set is `Y := ⋃_{i<s} R i`. -/

/-- **The genuine fiber-count bound (abstract core).**

Let `Fib : Finset ((ℕ → Finset X) × Finset X)` be a finite set of fiber elements
such that every `(W, U) ∈ Fib` satisfies

* `U ⊆ ⋃_{i<s} R i`         (the `U` lives in the single ground set `Y(Z)`),
* `|U| = u`                  (it is a `u`-subset), and
* `W = fun i => Z i ∖ (U ∩ R i)`   (the genuine recovery `W_i = Z_i ∖ (U ∩ R_i)`).

If moreover `|⋃_{i<s} R i| ≤ 2u`, then `|Fib| ≤ C(2u, u)`.

The proof injects `Fib` into the level set `{ U' ⊆ ⋃R : |U'| = u }` via
`(W,U) ↦ U`. Injectivity is genuine: if two fiber elements share the same `U`,
the recovery clause forces their `W` to coincide, so the pairs are equal. The
level set has cardinality `levelSetCount (⋃R) u ≤ C(2u,u)` by
`levelSetCount_le_central_binom_of_card_le` using `|⋃R| ≤ 2u`. -/
theorem fiber_card_le_central_binom
    (s u : ℕ) (Z R : ℕ → Finset X)
    (Fib : Finset ((ℕ → Finset X) × Finset X))
    (hUsub : ∀ p ∈ Fib, p.2 ⊆ (Finset.range s).biUnion R)
    (hUcard : ∀ p ∈ Fib, p.2.card = u)
    (hrec : ∀ p ∈ Fib, p.1 = fun i => Z i \ (p.2 ∩ R i))
    (hRcard : ((Finset.range s).biUnion R).card ≤ 2 * u) :
    Fib.card ≤ Nat.choose (2 * u) u := by
  -- The target level set `{ U' ⊆ ⋃R : |U'| = u }`.
  set Y : Finset X := (Finset.range s).biUnion R with hY
  set L : Finset (Finset X) := Y.powerset.filter (fun U => U.card = u) with hL
  -- Inject `Fib` into `L` via `(W, U) ↦ U`.
  have hcard : Fib.card ≤ L.card := by
    apply Finset.card_le_card_of_injOn (fun p => p.2)
    · -- MapsTo: each `p.2 ∈ L`.
      intro p hp
      rw [hL, Finset.mem_coe, Finset.mem_filter, Finset.mem_powerset]
      exact ⟨hUsub p hp, hUcard p hp⟩
    · -- InjOn: equal `U` ⟹ equal pair, via the recovery clause.
      intro p hp q hq hpq
      simp only [Finset.mem_coe] at hp hq
      -- `p.2 = q.2` (the projected equality).
      have hU : p.2 = q.2 := hpq
      -- Recover both `W` components from the shared `U`.
      have hWp : p.1 = fun i => Z i \ (p.2 ∩ R i) := hrec p hp
      have hWq : q.1 = fun i => Z i \ (q.2 ∩ R i) := hrec q hq
      have hW : p.1 = q.1 := by rw [hWp, hWq, hU]
      -- Equal both components ⟹ equal pairs.
      exact Prod.ext hW hU
  -- `L.card = levelSetCount Y u ≤ C(2u,u)`.
  have hLlevel : L.card = levelSetCount Y u := by
    rw [hL]; rfl
  have hbound : levelSetCount Y u ≤ Nat.choose (2 * u) u :=
    levelSetCount_le_central_binom_of_card_le Y u (by rw [hY]; exact hRcard)
  calc Fib.card ≤ L.card := hcard
    _ = levelSetCount Y u := hLlevel
    _ ≤ Nat.choose (2 * u) u := hbound

/-! ## 2. The bound instantiated at the minimum-tower container.

We instantiate the abstract core at the genuine §3.3 objects:

* `R i := Rstep Ŵ Ĥ λ_Ĥ i`   — the canonical `Z`-container family `Y(Z)_i`,
* `Z i := T i ∪ W i`          — where `T = minTower …`,

carrying the *exact same* residual hypotheses as `ContainerFromMinTower`
(the `t`-feasibility witness data of `Z`, the Lemma 3.6 Part A inclusion
`hIncl : T i ⊆ R i`, and the faithful positivity `hpos`). The `≤ 2u` ground-set
bound is then `bUnion_R_card_le` and the recovery is `recovery`, so the fiber
genuinely injects into `{ U ⊆ Y(Z) : |U| = u }`. -/

/-- **The genuine min-tower fiber-count bound.**

Fix the minimum tower `T = minTower ℋ s λ W H hH` and a `t`-feasibility witness
`(Ŵ, Ĥ)` of `Z i = T i ∪ W i`, with container family `R i = Rstep Ŵ Ĥ λ_Ĥ i`.
The level is the genuine total tower size `u := |⋃_{i<s} T i| = ∑ t_i` (the
paper's `u = ∑ t_i`). Let `Fib` be a finite set of fiber elements `(W', U)` with

* `U ⊆ ⋃_{i<s} R i`,
* `|U| = u` (= `|⋃_{i<s} T i|`), and
* `W' = fun i => (T i ∪ W i) ∖ (U ∩ R i)`   (the genuine recovery `W'_i = Z_i ∖ (U ∩ R_i)`).

Then `|Fib| ≤ C(2u, u)`.

The `≤ 2u` ground-set size `|⋃R| ≤ 2 |⋃T| = 2u` is exactly `bUnion_R_card_le`
(genuine, from the witness + `hpos`); it feeds the abstract core
`fiber_card_le_central_binom`. This is the faithful replacement for the live
`fiber_count_bound`: the count is the number of `u`-subsets of the single
`Z`-canonical ground set `Y(Z) = ⋃_i (Ĥ_i)_{<b̂_i}`, exactly the paper's
`C(2u,u)`. -/
theorem minTower_fiber_card_le_central_binom
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ) (W : ℕ → Finset X)
    (H : Finset X) (hH : H ∈ ℋ)
    (hpos : ∀ (H' : Finset X) (hH' : H' ∈ ℋ) x, x ∈ H' → 0 < lambda_vec H' hH' x)
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hZsub : ∀ i, i < s → Wh i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)
    (hZcard : ∀ i, i < s → (Wh i).card
        = (minTower ℋ s lambda_vec W H hH i ∪ W i).card
            - (minTower ℋ s lambda_vec W H hH i).card)
    (hRsub : ∀ i, i < s → Rstep Wh Hh (lambda_vec Hh hHh) i
        ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)
    (hIncl : ∀ i, i < s → minTower ℋ s lambda_vec W H hH i
        ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i)
    (Fib : Finset ((ℕ → Finset X) × Finset X))
    (hUsub : ∀ p ∈ Fib,
        p.2 ⊆ (Finset.range s).biUnion (Rstep Wh Hh (lambda_vec Hh hHh)))
    (hUcard : ∀ p ∈ Fib,
        p.2.card = ((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card)
    (hrec : ∀ p ∈ Fib, p.1 =
        fun i => (minTower ℋ s lambda_vec W H hH i ∪ W i)
            \ (p.2 ∩ Rstep Wh Hh (lambda_vec Hh hHh) i)) :
    Fib.card
      ≤ Nat.choose (2 * ((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card)
          (((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card) := by
  -- The level `u := |⋃_{i<s} T i| = ∑ t_i` is the genuine total tower size
  -- (the paper's `u = ∑ t_i`). The genuine ground-set bound `|⋃R| ≤ 2u` is then
  -- exactly `bUnion_R_card_le` (from the witness + `hpos`), with no side
  -- conditions: `|⋃R| ≤ 2 |⋃T| = 2u`.
  set u : ℕ := ((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card with hu
  have hRcard : ((Finset.range s).biUnion (Rstep Wh Hh (lambda_vec Hh hHh))).card
      ≤ 2 * u :=
    bUnion_R_card_le ℋ s lambda_vec W H hH hpos Wh Hh hHh
      hZsub hZcard hRsub hIncl
  -- Apply the abstract core with `Z i := T i ∪ W i`, `R i := Rstep …`.
  exact fiber_card_le_central_binom s u
    (fun i => minTower ℋ s lambda_vec W H hH i ∪ W i)
    (Rstep Wh Hh (lambda_vec Hh hHh))
    Fib hUsub hUcard hrec hRcard

end Workspace.Encoding.FiberCount
