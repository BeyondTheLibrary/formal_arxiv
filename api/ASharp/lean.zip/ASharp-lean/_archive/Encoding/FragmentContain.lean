import Workspace.Encoding.MinTower

open BigOperators
open Classical

namespace Workspace.Encoding.FragmentContain

/-! # Section 3.2 — Lemma 3.6 (`lem:fragment-contain`): the key property of
towers of minimum fragments.

**Source**: `@../arXiv-2412.03540v1.tex`, Section 3.2, Lemma
`lem:fragment-contain` (paper lines ~420–432).

Let `T := minTower ℋ s λ W H hH` be the minimum tower of fragments of `(W,H)`.
Unfolding `IsTowerOfFragments`/`TFeasible` (via `minTower_isTower`) gives a
witness family `Ŵ : ℕ → Finset X` and a hypothesis `Ĥ ∈ ℋ` such that, for all
`i < s`,

* `Ŵ i ⊆ Z i`,
* `(Ŵ i).card = (Z i).card − (T i).card`, and
* `Rstep Ŵ Ĥ λ i ⊆ Z i`,

where `Z i := T i ∪ W i`. The paper's `(Ĥ_i)_{<b̂_i} = R_i(Ŵ,Ĥ)` is
`container i := Rstep Ŵ Ĥ λ i`. Lemma 3.6 states, for each `i < s`:

  (A) `T i ⊆ container i`, and
  (B) `2 · |T i| ≥ |container i|`.

This file builds on `Workspace.Encoding.MinTower`, `TowerFrag`, and `Procedure`.
-/

variable {X : Type} [Fintype X] [DecidableEq X]

open Workspace.Encoding.Procedure
open Workspace.Encoding.TowerFrag
open Workspace.Encoding.MinTower

/-! ## Part B — the size bound, given the inclusion `T i ⊆ container i`.

This is a pure cardinality computation from the `TFeasible` witness for the
minimum tower together with Lemma 3.2 (`large_wt_Rset`). It is stated as a
standalone fact about an arbitrary witness `(Ŵ, Ĥ)` of the `t`-feasibility of
`Z i = T i ∪ W i`, so it is reusable both for the minimum tower and in the Part A
contradiction argument. -/

/-- **Part B (size bound), witness-level.**

If, at index `i`, the witness `(Ŵ, Ĥ)` certifies the `t`-feasibility of
`Z i = T i ∪ W i` (i.e. `Ŵ i ⊆ Z i`, `|Ŵ i| = |Z i| − |T i|`, and
`container i := Rstep Ŵ Ĥ λ i ⊆ Z i`), then `2·|T i| ≥ |container i|`.

This is the paper's inequality `|T_i| ≥ |C_i ∖ Ŵ_i| ≥ ½|C_i|`: the first step
`|C_i ∖ Ŵ_i| ≤ |T_i|` follows from `C_i ⊆ Z_i` and `|Z_i ∖ Ŵ_i| = |T_i|` (the
`t`-feasibility cardinality), the second from Lemma 3.2 applied to `C_i`. The
inclusion `T i ⊆ container i` (Part A) is not required for the size bound.

`hpos` is the (faithful, minimal) positivity of `λ` on `Hstep Ŵ Ĥ λ i`, needed
to invoke Lemma 3.2. -/
theorem size_bound_of_witness
    (lambda : X → ℝ) (T W Wh : ℕ → Finset X) (Hh : Finset X) (i : ℕ)
    (hpos : ∀ x ∈ Hstep Wh Hh lambda i, 0 < lambda x)
    (hWsub : Wh i ⊆ T i ∪ W i)
    (hWcard : (Wh i).card = (T i ∪ W i).card - (T i).card)
    (hRsub : Rstep Wh Hh lambda i ⊆ T i ∪ W i) :
    (Rstep Wh Hh lambda i).card ≤ 2 * (T i).card := by
  set C : Finset X := Rstep Wh Hh lambda i with hC
  set Z : Finset X := T i ∪ W i with hZ
  -- `|Z \ Ŵ i| = |Z| − |Ŵ i| = |T i|`.
  have hWZle : (Wh i).card ≤ Z.card := Finset.card_le_card hWsub
  have hTle : (T i).card ≤ Z.card := by
    apply Finset.card_le_card
    rw [hZ]; exact Finset.subset_union_left
  -- `Z ∩ Ŵ i = Ŵ i` since `Ŵ i ⊆ Z`.
  have hZinter : Z ∩ Wh i = Wh i := Finset.inter_eq_right.mpr hWsub
  have hsplitZ : (Z ∩ Wh i).card + (Z \ Wh i).card = Z.card :=
    Finset.card_inter_add_card_sdiff Z (Wh i)
  have hdiffZ : (Z \ Wh i).card = (T i).card := by
    rw [hZinter] at hsplitZ
    omega
  -- `C \ Ŵ i ⊆ Z \ Ŵ i`, so `|C \ Ŵ i| ≤ |T i|`.
  have hCdiff_sub : C \ Wh i ⊆ Z \ Wh i :=
    Finset.sdiff_subset_sdiff hRsub (Finset.Subset.refl _)
  have hCdiff_le : (C \ Wh i).card ≤ (T i).card := by
    rw [← hdiffZ]; exact Finset.card_le_card hCdiff_sub
  -- `|C ∩ Ŵ i| + |C \ Ŵ i| = |C|`.
  have hsplit : (C ∩ Wh i).card + (C \ Wh i).card = C.card :=
    Finset.card_inter_add_card_sdiff C (Wh i)
  -- Lemma 3.2: `2·|C ∩ Ŵ i| ≤ |C|`.
  have hlemma32 : 2 * ((C ∩ Wh i).card) ≤ C.card := by
    rw [hC]
    unfold Rstep
    exact large_wt_Rset (Wh i) (Hstep Wh Hh lambda i) lambda hpos
  -- Combine: `|C| = |C \ Ŵ i| + |C ∩ Ŵ i| ≤ |T i| + |C|/2 ⟹ |C| ≤ 2|T i|`.
  omega

/-! ## `Hstep` of a witness sits inside the witness hypothesis `Ĥ`.

The positivity hypothesis of Lemma 3.2 is `0 < λ` on `Hstep Ŵ Ĥ λ i`. Since
`Hstep Ŵ Ĥ λ i ⊆ Ĥ` and the witness `Ĥ ∈ ℋ`, it suffices to assume `λ > 0` on
every member of `ℋ` (faithful: `λ_H` is a probability weight positive on its
support, and the cutoff machinery is run with that `λ`). -/

lemma Hstep_subset_base (Wh : ℕ → Finset X) (Hh : Finset X) (lambda : X → ℝ)
    (i : ℕ) : Hstep Wh Hh lambda i ⊆ Hh := by
  have := Hstep_antitone Wh Hh lambda (Nat.zero_le i)
  simpa using this

/-! ## Part B at the level of the minimum tower.

We state Lemma 3.6(B) for the minimum tower against an **arbitrary** witness
`(Ŵ, Ĥ)` of the `t`-feasibility of `Z = Z(W,H)` (the paper's "arbitrary choice
of a witness"). This is the universal/most-faithful form: the size bound holds
for every certificate. -/

/-- **Lemma 3.6, Part B (size bound) for the minimum tower.**

Let `T = minTower …`. For every witness `(Ŵ, Ĥ)` of the `t`-feasibility of
`Z i = T i ∪ W i`, the container `container i = Rstep Ŵ Ĥ λ i` satisfies
`|container i| ≤ 2·|T i|` for all `i < s`. (No reliance on Part A.) -/
theorem fragment_contain_B
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ) (W : ℕ → Finset X)
    (H : Finset X) (hH : H ∈ ℋ)
    (hlampos : ∀ (H' : Finset X) (hH' : H' ∈ ℋ) x, x ∈ H' → 0 < lambda_vec H' hH' x)
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hwit : (∀ i, i < s →
        Wh i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i ∧
          (Wh i).card =
            (minTower ℋ s lambda_vec W H hH i ∪ W i).card -
              (minTower ℋ s lambda_vec W H hH i).card) ∧
      (∀ i, i < s →
        Rstep Wh Hh (lambda_vec Hh hHh) i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)) :
    ∀ i, i < s →
      (Rstep Wh Hh (lambda_vec Hh hHh) i).card
        ≤ 2 * (minTower ℋ s lambda_vec W H hH i).card := by
  intro i hi
  obtain ⟨hsub, hR⟩ := hwit
  obtain ⟨hWsub, hWcard⟩ := hsub i hi
  -- positivity on `Hstep Ŵ Ĥ λ_Ĥ i` via `Ĥ ∈ ℋ`.
  have hpos : ∀ x ∈ Hstep Wh Hh (lambda_vec Hh hHh) i, 0 < lambda_vec Hh hHh x := by
    intro x hx
    exact hlampos Hh hHh x (Hstep_subset_base Wh Hh (lambda_vec Hh hHh) i hx)
  exact size_bound_of_witness (lambda_vec Hh hHh) (minTower ℋ s lambda_vec W H hH)
    W Wh Hh i hpos hWsub hWcard (hR i hi)

/-! ## Part A — the inclusion `T i ⊆ container i`, via lex-minimality.

The argument: if `T i ⊄ container i` for some `i < s`, replace `T i` by
`T' i := T i ∩ container i` (strictly smaller, still `⊆ H`), keeping `T' j = T j`
elsewhere. Using the **same** witness `(Ŵ, Ĥ)`, `T'` is again a tower of
fragments of `(W,H)`, and its size vector is lexicographically strictly smaller
(it agrees with `T` below `i` and is strictly smaller at `i`). This contradicts
`minTower_lex_le`.

For the **same** witness to certify the replacement at index `i`, the
`TFeasible` conditions at `i` must hold for `Z' i = (T i ∩ container i) ∪ W i`:

* (c) `container i ⊆ Z' i` — holds unconditionally (proved as `hc` below);
* (a) `Ŵ i ⊆ Z' i` — needs `Ŵ i ∩ T i ⊆ container i`;
* (b) `|Ŵ i| = |Z' i| − |T' i|` — needs `(T i \ container i) ∩ W i = ∅`.

Conditions (a) and (b) are exactly the two structural facts that the same-witness
replacement requires; they are NOT derivable from the bare `TFeasible` data (see
the report). We therefore state Part A conditionally on these two facts, named
`hWcap` and `hWdisj`, applied at the offending index. -/

/-- **Lemma 3.6, Part A (inclusion) for the minimum tower — conditional form.**

Let `T = minTower …` and `(Ŵ, Ĥ)` be a witness of the `t`-feasibility of
`Z i = T i ∪ W i`, with `container i = Rstep Ŵ Ĥ λ i`. Assume the one
same-witness replacement fact holds at every index:

* `hWcap : ∀ i < s, Ŵ i ∩ T i ⊆ container i` (closes condition (a)).

Condition (b) `(T i \ container i) ∩ W i = ∅` now follows from the new
disjointness conjunct of `IsTowerOfFragments` (since `minTower_isTower` gives
`Disjoint (T i) (W i)`, which implies `(T i \ C i) ∩ W i = ∅`).

Then `T i ⊆ container i` for all `i < s`. -/
theorem fragment_contain_A
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ) (W : ℕ → Finset X)
    (H : Finset X) (hH : H ∈ ℋ)
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hsub : ∀ i, i < s →
        Wh i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i ∧
          (Wh i).card =
            (minTower ℋ s lambda_vec W H hH i ∪ W i).card -
              (minTower ℋ s lambda_vec W H hH i).card)
    (hR : ∀ i, i < s →
        Rstep Wh Hh (lambda_vec Hh hHh) i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)
    (hWcap : ∀ i, i < s →
        Wh i ∩ minTower ℋ s lambda_vec W H hH i ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i) :
    ∀ i, i < s →
      minTower ℋ s lambda_vec W H hH i ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i := by
  -- Derive `hWdisj` from the disjointness conjunct of `minTower_isTower`.
  have hWdisj : ∀ j, j < s →
      (minTower ℋ s lambda_vec W H hH j \ Rstep Wh Hh (lambda_vec Hh hHh) j) ∩ W j = ∅ := by
    intro j hj
    have hdisj_TW : Disjoint (minTower ℋ s lambda_vec W H hH j) (W j) :=
      (minTower_isTower ℋ s lambda_vec W H hH).2.2 j hj
    -- `(T j \ C j) ⊆ T j`, and `Disjoint (T j) (W j)` gives `Disjoint (T j \ C j) (W j)`.
    have hdisj_sub : Disjoint (minTower ℋ s lambda_vec W H hH j \ Rstep Wh Hh (lambda_vec Hh hHh) j) (W j) :=
      Finset.disjoint_of_subset_left Finset.sdiff_subset hdisj_TW
    exact Finset.disjoint_iff_inter_eq_empty.mp hdisj_sub
  intro i hi
  set T : ℕ → Finset X := minTower ℋ s lambda_vec W H hH with hT
  set C : ℕ → Finset X := fun j => Rstep Wh Hh (lambda_vec Hh hHh) j with hCdef
  by_contra hbad
  -- The replacement tower `T' j = if j = i then T j ∩ C j else T j`.
  set T' : ℕ → Finset X := fun j => if j = i then T j ∩ C j else T j with hT'
  -- `T' j = T j` for `j ≠ i`.
  have hT'_ne : ∀ j, j ≠ i → T' j = T j := by
    intro j hj; simp [hT', hj]
  -- `T' i = T i ∩ C i`.
  have hT'_eq : T' i = T i ∩ C i := by simp [hT']
  -- Strictness: there is an element of `T i` outside `C i`.
  have hstrict : (T' i).card < (T i).card := by
    rw [hT'_eq]
    -- `T i ∩ C i ⊆ T i` and the inclusion is strict (some `x ∈ T i`, `x ∉ C i`).
    have hsubset : T i ∩ C i ⊆ T i := Finset.inter_subset_left
    have hne : T i ∩ C i ≠ T i := by
      intro heq
      apply hbad
      -- `T i = T i ∩ C i ⊆ C i`.
      rw [hCdef] at *
      have : T i ⊆ C i := by rw [← heq]; exact Finset.inter_subset_right
      simpa [hCdef] using this
    exact Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨hsubset, hne⟩)
  -- `T'` is a tower of fragments of `(W,H)`.
  have htower : IsTowerOfFragments ℋ s lambda_vec W H T' := by
    refine ⟨?_, ?_, ?_⟩
    · -- TFeasible(Z', t') with the SAME witness (Ŵ, Ĥ).
      refine ⟨Wh, Hh, hHh, ?_, ?_⟩
      · -- (a) + (b) at every index `j < s`.
        intro j hj
        simp only []
        by_cases hji : j = i
        · subst hji
          rw [hT'_eq]
          obtain ⟨hWsub, hWcard⟩ := hsub j hj
          constructor
          · -- (a) `Ŵ j ⊆ (T j ∩ C j) ∪ W j`.
            intro x hx
            have hxZ : x ∈ T j ∪ W j := hWsub hx
            rw [Finset.mem_union] at hxZ ⊢
            rcases hxZ with hxT | hxW
            · -- `x ∈ T j` and `x ∈ Ŵ j` ⟹ `x ∈ Ŵ j ∩ T j ⊆ C j`, so `x ∈ T j ∩ C j`.
              left
              have hxC : x ∈ C j :=
                hWcap j hj (Finset.mem_inter.mpr ⟨hx, hxT⟩)
              exact Finset.mem_inter.mpr ⟨hxT, hxC⟩
            · right; exact hxW
          · -- (b) `|Ŵ j| = |(T j ∩ C j) ∪ W j| − |T j ∩ C j|`.
            -- LHS via original: |Ŵ j| = |T j ∪ W j| − |T j| = |W j \ T j|.
            -- RHS = |W j \ (T j ∩ C j)|; equal by `hWdisj`.
            rw [hWcard]
            -- reduce both sides to set-difference cardinalities.
            have hL : (T j ∪ W j).card - (T j).card = (W j \ T j).card := by
              have h1 : (W j \ T j).card + (T j).card = (W j ∪ T j).card :=
                Finset.card_sdiff_add_card (W j) (T j)
              rw [Finset.union_comm (T j) (W j)]
              omega
            have hRcard : ((T j ∩ C j) ∪ W j).card - (T j ∩ C j).card
                = (W j \ (T j ∩ C j)).card := by
              have h1 : (W j \ (T j ∩ C j)).card + (T j ∩ C j).card
                  = (W j ∪ (T j ∩ C j)).card :=
                Finset.card_sdiff_add_card (W j) (T j ∩ C j)
              rw [Finset.union_comm (T j ∩ C j) (W j)]
              omega
            rw [hL, hRcard]
            -- `W j \ T j = W j \ (T j ∩ C j)` because `(T j \ C j) ∩ W j = ∅`.
            congr 1
            apply Finset.Subset.antisymm
            · exact Finset.sdiff_subset_sdiff (Finset.Subset.refl _)
                Finset.inter_subset_left
            · -- `W j \ (T j ∩ C j) ⊆ W j \ T j`.
              intro x hx
              rw [Finset.mem_sdiff] at hx ⊢
              obtain ⟨hxW, hxnTC⟩ := hx
              refine ⟨hxW, ?_⟩
              intro hxT
              -- `x ∈ W j`, `x ∈ T j`, `x ∉ T j ∩ C j` ⟹ `x ∉ C j` ⟹ `x ∈ (T j \ C j) ∩ W j = ∅`.
              apply hxnTC
              rw [Finset.mem_inter]
              refine ⟨hxT, ?_⟩
              by_contra hxnC
              have : x ∈ (T j \ C j) ∩ W j := by
                rw [Finset.mem_inter, Finset.mem_sdiff]
                exact ⟨⟨hxT, hxnC⟩, hxW⟩
              rw [hWdisj j hj] at this
              exact (Finset.notMem_empty x) this
        · -- `j ≠ i`: `T' j = T j`, conditions are the original ones.
          rw [hT'_ne j hji]
          exact hsub j hj
      · -- (c) `C j ⊆ Z' j` for all `j < s`.
        intro j hj
        simp only []
        by_cases hji : j = i
        · subst hji
          rw [hT'_eq]
          -- `C j ⊆ (T j ∩ C j) ∪ W j`: `x ∈ C j ⊆ Z j = T j ∪ W j`.
          intro x hx
          have hxZ : x ∈ T j ∪ W j := hR j hj hx
          rw [Finset.mem_union] at hxZ ⊢
          rcases hxZ with hxT | hxW
          · left; exact Finset.mem_inter.mpr ⟨hxT, hx⟩
          · right; exact hxW
        · rw [hT'_ne j hji]; exact hR j hj
    · -- Containment `∀ j < s, T' j ⊆ H`.
      intro j hj
      have hTH : T j ⊆ H := by
        have := (minTower_isTower ℋ s lambda_vec W H hH).2.1 j hj
        simpa [hT] using this
      by_cases hji : j = i
      · subst hji; rw [hT'_eq]; exact (Finset.inter_subset_left).trans hTH
      · rw [hT'_ne j hji]; exact hTH
    · -- Disjointness `∀ j < s, Disjoint (T' j) (W j)`.
      intro j hj
      have hdisj_TW : Disjoint (T j) (W j) :=
        (minTower_isTower ℋ s lambda_vec W H hH).2.2 j hj
      by_cases hji : j = i
      · subst hji; rw [hT'_eq]
        -- `T' i = T i ∩ C i ⊆ T i`, and `Disjoint (T i) (W i)` gives disjointness.
        exact Finset.disjoint_of_subset_left Finset.inter_subset_left hdisj_TW
      · rw [hT'_ne j hji]; exact hdisj_TW
  -- Lex-minimality of `T` contradicts `T'` being a strictly-smaller tower.
  have hle := minTower_lex_le ℋ s lambda_vec W H hH T' htower
  -- `hle : toLex (fun k => |T k|) ≤ toLex (fun k => |T' k|)` (note minTower = T).
  -- Build the strict `<` in the other direction.
  have hlt : (toLex (fun k : Fin s => (T' k.val).card) : Lex (Fin s → ℕ))
      < toLex (fun k : Fin s => (T k.val).card) := by
    refine ⟨⟨i, hi⟩, ?_, ?_⟩
    · -- agreement for `k < i`: `T' k = T k` since `k.val ≠ i`.
      intro k hk
      have hkval : k.val < i := hk
      have hkne : k.val ≠ i := Nat.ne_of_lt hkval
      show (T' k.val).card = (T k.val).card
      rw [hT'_ne k.val hkne]
    · -- strict decrease at `i`.
      show (T' i).card < (T i).card
      exact hstrict
  -- `minTower … k.val = T k.val`.
  have hmin_eq : (fun k : Fin s => (minTower ℋ s lambda_vec W H hH k.val).card)
      = (fun k : Fin s => (T k.val).card) := by rw [hT]
  rw [hmin_eq] at hle
  exact absurd hle (not_le.mpr hlt)

end Workspace.Encoding.FragmentContain
