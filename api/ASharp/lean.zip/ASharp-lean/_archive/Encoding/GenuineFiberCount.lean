import Workspace.Encoding.FiberCount
import Workspace.Axioms.Lemma36PartA

open BigOperators
open Classical

namespace Workspace.Encoding.GenuineFiberCount

/-! # Section 3.3 — the genuine fiber-count bound `C(2u,u)`, with Lemma 3.6 Part A
discharged by the minimal `¬IsPSmall` axiom.

**Source**: `@../arXiv-2412.03540v1.tex`, Section 3.3, Lemma `lem:key`.

This file is the faithful, sound replacement for the (FALSE) monolithic axiom
`canonical_R_for_fiber`. It exposes exactly the same conclusion as
`Workspace.Encoding.FiberCount.minTower_fiber_card_le_central_binom`, but with the
informal inclusion hypothesis `hIncl` (Lemma 3.6 Part A) REPLACED by the theorem's
actual hypothesis `¬ IsPSmall ℋ p`. The `hIncl` is then supplied by the single
minimal axiom `Workspace.Axioms.Lemma36PartA.minTower_part_A_inclusion`, which is
TRUE precisely under `¬IsPSmall ℋ p` (verified exhaustively; FALSE for p-small ℋ).

No `sorry`, no `admit`. The only new axiom in the dependency closure is
`minTower_part_A_inclusion`. -/

variable {X : Type} [Fintype X] [DecidableEq X]

open Workspace.Encoding.Procedure
open Workspace.Encoding.MinTower
open Workspace.Encoding.ContainerFromMinTower
open Workspace.Encoding.FiberCount
open Workspace.Types.IsPSmall
open Workspace.Axioms.Lemma36PartA

/-- **The genuine min-tower fiber-count bound, with Lemma 3.6 Part A discharged.**

Identical in conclusion and all data hypotheses to
`minTower_fiber_card_le_central_binom`, except the informal inclusion hypothesis
`hIncl : T i ⊆ R i` is removed and replaced by `(p : ℝ) (h_not_small : ¬ IsPSmall ℋ p)`.
The inclusion is recovered from the minimal axiom `minTower_part_A_inclusion`
(TRUE under `¬IsPSmall ℋ p`), and the bound then follows from
`minTower_fiber_card_le_central_binom`. -/
theorem genuine_fiber_count_bound
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ) (W : ℕ → Finset X)
    (H : Finset X) (hH : H ∈ ℋ)
    (hpos : ∀ (H' : Finset X) (hH' : H' ∈ ℋ) x, x ∈ H' → 0 < lambda_vec H' hH' x)
    (p : ℝ) (h_not_small : ¬ IsPSmall ℋ p)
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hZsub : ∀ i, i < s → Wh i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)
    (hZcard : ∀ i, i < s → (Wh i).card
        = (minTower ℋ s lambda_vec W H hH i ∪ W i).card
            - (minTower ℋ s lambda_vec W H hH i).card)
    (hRsub : ∀ i, i < s → Rstep Wh Hh (lambda_vec Hh hHh) i
        ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)
    (Fib : Finset ((ℕ → Finset X) × Finset X))
    (hUsub : ∀ p ∈ Fib,
        p.2 ⊆ (Finset.range s).biUnion (Rstep Wh Hh (lambda_vec Hh hHh)))
    (hUcard : ∀ p ∈ Fib,
        p.2.card = ((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card)
    (hrec : ∀ p ∈ Fib, p.1 =
        fun i => (minTower ℋ s lambda_vec W H hH i ∪ W i)
            \ (p.2 ∩ Rstep Wh Hh (lambda_vec Hh hHh) i)) :
    Fib.card
      ≤ Nat.choose (2 * ((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card)
          (((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card) := by
  -- Discharge the Lemma 3.6 Part A inclusion `hIncl` from the minimal `¬IsPSmall` axiom.
  have hIncl : ∀ i, i < s → minTower ℋ s lambda_vec W H hH i
      ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i :=
    minTower_part_A_inclusion ℋ s lambda_vec W H hH p h_not_small
      Wh Hh hHh hZsub hZcard hRsub
  -- Feed it into the genuine counting core.
  exact minTower_fiber_card_le_central_binom ℋ s lambda_vec W H hH hpos
    Wh Hh hHh hZsub hZcard hRsub hIncl Fib hUsub hUcard hrec

end Workspace.Encoding.GenuineFiberCount
