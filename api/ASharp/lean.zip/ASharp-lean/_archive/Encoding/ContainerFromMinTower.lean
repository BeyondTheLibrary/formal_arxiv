import Workspace.Encoding.FragmentContain

open BigOperators
open Classical

namespace Workspace.Encoding.ContainerFromMinTower

/-! # Section 3.3 — the container / recovery package built on the minimum tower.

**Source**: `@../arXiv-2412.03540v1.tex`, Section 3.3 (the surjection step:
the canonical `Z`-container family and the recovery `T_i = U ∩ R_i`,
`W_i = Z_i ∖ (U ∩ R_i)`).

This file isolates the **only** hand-waved residual facts of §3.3 — the
Lemma 3.6 inclusion `T i ⊆ R i` (Part A) and the `W`-disjointness of the
minimum tower `Disjoint (T i) (W i)` — and shows that, *given exactly those two
facts as explicit hypotheses* (plus the genuine `t`-feasibility witness data of
`Z := T ∪ W` and the faithful positivity of `λ`), the entire container/recovery
structure of §3.3 is GENUINELY provable. Nothing else is admitted: no `sorry`,
no `axiom`, no `admit`, no vacuous lemma.

The five theorems below mirror the live `CanonicalZContainer` fields
(`R_pairwise_disjoint`, `fiber_subset`, `fiber_W_recovery`, `R_card_le`) together
with the surjection recovery identities `T_i = U ∩ R_i`, `W_i = Z_i ∖ (U ∩ R_i)`:

1. `container_disjoint`  — the `R i` are pairwise disjoint.
2. `U_subset_bUnion_R`   — `U ⊆ ⋃_{i<s} R i`.
3. `inter_U_R_eq_T`      — `U ∩ R i = T i` (the recovery of the tower fragment).
4. `recovery`            — `(T i ∪ W i) ∖ (U ∩ R i) = W i` (recovery of `W`).
5. `bUnion_R_card_le`    — `|⋃_{i<s} R i| ≤ 2 · |U|`.

## The admitted inputs (residual + faithful witness/positivity)

* `hIncl : ∀ i < s, T i ⊆ R i`              — Lemma 3.6 inclusion / Part A (residual).
* `hWdisj : ∀ i < s, Disjoint (T i) (W i)`  — `W`-disjointness of the min tower (residual).
* the `t`-feasibility witness `(Ŵ, Ĥ, hĤ, hZsub, hZcard, hRsub)` of `Z = T ∪ W` (faithful).
* `hpos : ∀ H' hH' x, x ∈ H' → 0 < λ_{H'} x`  — faithful positivity of `λ` (Lemma 3.2).

These are exactly the paper's hand-waved facts; everything else here is proved.
-/

variable {X : Type} [Fintype X] [DecidableEq X]

open Workspace.Encoding.Procedure
open Workspace.Encoding.TowerFrag
open Workspace.Encoding.MinTower
open Workspace.Encoding.FragmentContain

/-! ## Fixed data of §3.3.

We fix the hypothesis family `ℋ`, sample bound `s`, weight family `lambda_vec`,
the sample tuple `W`, and the chosen hypothesis `H ∈ ℋ`. The minimum tower and
its biUnion `U` are then defined, together with the `t`-feasibility witness
`(Ŵ, Ĥ)` of `Z = T ∪ W`. The container family is `R i := Rstep Ŵ Ĥ λ_Ĥ i`. -/

variable (ℋ : Set (Finset X)) (s : ℕ)
  (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ) (W : ℕ → Finset X)
  (H : Finset X) (hH : H ∈ ℋ)

/-- The minimum tower `T i := minTower ℋ s λ W H hH i`. -/
local notation3 "T" => minTower ℋ s lambda_vec W H hH

/-! ### 1. Container disjointness.

`R i = Rstep Ŵ Ĥ λ_Ĥ i`, and the cutoff prefixes of any single run of the
procedure are pairwise disjoint — this is `Rstep_pairwise_disjoint`, proven in
`Procedure.lean` with no residual hypotheses. -/

/-- **Container disjointness** (mirrors `CanonicalZContainer.R_pairwise_disjoint`).
The `R i` are pairwise disjoint, directly from `Rstep_pairwise_disjoint`. -/
theorem container_disjoint
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ) :
    ∀ i j, i ≠ j →
      Disjoint (Rstep Wh Hh (lambda_vec Hh hHh) i)
        (Rstep Wh Hh (lambda_vec Hh hHh) j) :=
  Rstep_pairwise_disjoint Wh Hh (lambda_vec Hh hHh)

/-! ### 2–5. The remaining package, given the residual hypotheses.

We bundle the §3.3 hypotheses so each theorem reads cleanly:

* witness data of `Z = T ∪ W`: `hZsub`, `hZcard`, `hRsub` (faithful);
* residual `hIncl : ∀ i < s, T i ⊆ R i` (Lemma 3.6 / Part A);
* residual `hWdisj : ∀ i < s, Disjoint (T i) (W i)`;
* faithful positivity `hpos`.

`U := (Finset.range s).biUnion T`. -/

/-- **`U ⊆ ⋃_{i<s} R i`** (mirrors `CanonicalZContainer.fiber_subset`).

Every element of `U = ⋃_{i<s} T i` lies in some `T i` with `i < s`, hence in
`R i` by the residual inclusion `hIncl`, hence in `⋃_{i<s} R i`. -/
theorem U_subset_bUnion_R
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hIncl : ∀ i, i < s → minTower ℋ s lambda_vec W H hH i
        ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i) :
    (Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)
      ⊆ (Finset.range s).biUnion (Rstep Wh Hh (lambda_vec Hh hHh)) := by
  intro x hx
  rw [Finset.mem_biUnion] at hx ⊢
  obtain ⟨i, hi, hxi⟩ := hx
  exact ⟨i, hi, hIncl i (Finset.mem_range.mp hi) hxi⟩

/-- **Recovery of the tower fragment: `U ∩ R i = T i`** (the surjection identity
`T_i = U ∩ R_i`).

`⊇`: `T i ⊆ U` (it is one of the biUnion pieces) and `T i ⊆ R i` (residual
`hIncl`). `⊆`: an element of `U ∩ R i` lies in some `T j` (`j < s`); if `j ≠ i`
then `T j ⊆ R j` and `R j`/`R i` are disjoint (container disjointness), so the
element cannot also be in `R i`; hence `j = i` and the element is in `T i`. -/
theorem inter_U_R_eq_T
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hIncl : ∀ i, i < s → minTower ℋ s lambda_vec W H hH i
        ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i) :
    ∀ i, i < s →
      (Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)
          ∩ Rstep Wh Hh (lambda_vec Hh hHh) i
        = minTower ℋ s lambda_vec W H hH i := by
  intro i hi
  apply Finset.Subset.antisymm
  · -- `U ∩ R i ⊆ T i`.
    intro x hx
    rw [Finset.mem_inter] at hx
    obtain ⟨hxU, hxRi⟩ := hx
    rw [Finset.mem_biUnion] at hxU
    obtain ⟨j, hj, hxTj⟩ := hxU
    have hjlt : j < s := Finset.mem_range.mp hj
    by_cases hji : j = i
    · subst hji; exact hxTj
    · -- `x ∈ T j ⊆ R j`, and `R j` disjoint from `R i` (j ≠ i): contradiction.
      exfalso
      have hxRj : x ∈ Rstep Wh Hh (lambda_vec Hh hHh) j := hIncl j hjlt hxTj
      have hdisj := container_disjoint ℋ lambda_vec Wh Hh hHh j i hji
      exact (Finset.disjoint_left.mp hdisj) hxRj hxRi
  · -- `T i ⊆ U ∩ R i`.
    intro x hx
    rw [Finset.mem_inter]
    refine ⟨?_, hIncl i hi hx⟩
    rw [Finset.mem_biUnion]
    exact ⟨i, Finset.mem_range.mpr hi, hx⟩

/-- **Recovery of `W`: `(T i ∪ W i) ∖ (U ∩ R i) = W i`** (mirrors
`CanonicalZContainer.fiber_W_recovery`, with `Z_i = T i ∪ W i`).

Rewrite `U ∩ R i = T i` (item 3), then `(T i ∪ W i) ∖ T i = W i` by
`Finset.union_sdiff_cancel_left` using the residual `Disjoint (T i) (W i)`. -/
theorem recovery
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hIncl : ∀ i, i < s → minTower ℋ s lambda_vec W H hH i
        ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i)
    (hWdisj : ∀ i, i < s → Disjoint (minTower ℋ s lambda_vec W H hH i) (W i)) :
    ∀ i, i < s →
      (minTower ℋ s lambda_vec W H hH i ∪ W i)
          \ ((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)
              ∩ Rstep Wh Hh (lambda_vec Hh hHh) i)
        = W i := by
  intro i hi
  rw [inter_U_R_eq_T ℋ s lambda_vec W H hH Wh Hh hHh hIncl i hi]
  exact Finset.union_sdiff_cancel_left (hWdisj i hi)

/-! ### 5. The biUnion size bound.

`|⋃_{i<s} R i| = ∑_{i<s} |R i|` (container disjointness)
            `≤ ∑_{i<s} 2·|T i|`  (`fragment_contain_B`: needs witness + `hpos`)
            `= 2 · ∑_{i<s} |T i|`
            `= 2 · |U|`           (`U.card = ∑_{i<s}|T i|`, the `T i` being
                                    pairwise disjoint inside the disjoint `R i`). -/

/-- The `T i` (`i < s`) are pairwise disjoint: for `i ≠ j` they sit inside the
disjoint containers `R i`, `R j` (residual `hIncl` + container disjointness). -/
theorem T_pairwise_disjoint
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hIncl : ∀ i, i < s → minTower ℋ s lambda_vec W H hH i
        ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i) :
    (↑(Finset.range s) : Set ℕ).PairwiseDisjoint
      (minTower ℋ s lambda_vec W H hH) := by
  intro i hi j hj hij
  have hilt : i < s := Finset.mem_range.mp hi
  have hjlt : j < s := Finset.mem_range.mp hj
  exact Finset.disjoint_of_subset_left (hIncl i hilt)
    (Finset.disjoint_of_subset_right (hIncl j hjlt)
      (container_disjoint ℋ lambda_vec Wh Hh hHh i j hij))

/-- **The container biUnion is at most twice `|U|`** (mirrors
`CanonicalZContainer.R_card_le`).

`|⋃ R i| = ∑ |R i| ≤ ∑ 2|T i| = 2 ∑ |T i| = 2 |⋃ T i| = 2 |U|`. The per-index
bound `|R i| ≤ 2|T i|` is `fragment_contain_B` (the genuine size bound from the
witness + `hpos`); the disjointness of both biUnions turns them into sums. -/
theorem bUnion_R_card_le
    (hpos : ∀ (H' : Finset X) (hH' : H' ∈ ℋ) x, x ∈ H' → 0 < lambda_vec H' hH' x)
    (Wh : ℕ → Finset X) (Hh : Finset X) (hHh : Hh ∈ ℋ)
    (hZsub : ∀ i, i < s → Wh i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)
    (hZcard : ∀ i, i < s → (Wh i).card
        = (minTower ℋ s lambda_vec W H hH i ∪ W i).card
            - (minTower ℋ s lambda_vec W H hH i).card)
    (hRsub : ∀ i, i < s → Rstep Wh Hh (lambda_vec Hh hHh) i
        ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i)
    (hIncl : ∀ i, i < s → minTower ℋ s lambda_vec W H hH i
        ⊆ Rstep Wh Hh (lambda_vec Hh hHh) i) :
    ((Finset.range s).biUnion (Rstep Wh Hh (lambda_vec Hh hHh))).card
      ≤ 2 * ((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card := by
  -- Per-index size bound `|R i| ≤ 2 |T i|` from `fragment_contain_B`.
  have hwit : (∀ i, i < s →
        Wh i ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i ∧
          (Wh i).card =
            (minTower ℋ s lambda_vec W H hH i ∪ W i).card -
              (minTower ℋ s lambda_vec W H hH i).card) ∧
      (∀ i, i < s →
        Rstep Wh Hh (lambda_vec Hh hHh) i
          ⊆ minTower ℋ s lambda_vec W H hH i ∪ W i) :=
    ⟨fun i hi => ⟨hZsub i hi, hZcard i hi⟩, hRsub⟩
  have hbound := fragment_contain_B ℋ s lambda_vec W H hH hpos Wh Hh hHh hwit
  -- Container biUnion card = ∑ |R i| (containers disjoint).
  have hRpd : (↑(Finset.range s) : Set ℕ).PairwiseDisjoint
      (Rstep Wh Hh (lambda_vec Hh hHh)) := by
    intro i _ j _ hij
    exact container_disjoint ℋ lambda_vec Wh Hh hHh i j hij
  have hRcard : ((Finset.range s).biUnion (Rstep Wh Hh (lambda_vec Hh hHh))).card
      = ∑ i ∈ Finset.range s, (Rstep Wh Hh (lambda_vec Hh hHh) i).card :=
    Finset.card_biUnion hRpd
  -- Tower biUnion card = ∑ |T i| (towers disjoint, item `T_pairwise_disjoint`).
  have hTpd := T_pairwise_disjoint ℋ s lambda_vec W H hH Wh Hh hHh hIncl
  have hUcard : ((Finset.range s).biUnion (minTower ℋ s lambda_vec W H hH)).card
      = ∑ i ∈ Finset.range s, (minTower ℋ s lambda_vec W H hH i).card :=
    Finset.card_biUnion hTpd
  rw [hRcard, hUcard, Finset.mul_sum]
  -- ∑ |R i| ≤ ∑ 2|T i|.
  apply Finset.sum_le_sum
  intro i hi
  exact hbound i (Finset.mem_range.mp hi)

end Workspace.Encoding.ContainerFromMinTower
