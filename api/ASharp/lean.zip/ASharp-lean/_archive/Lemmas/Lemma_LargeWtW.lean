import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Tactic.Linarith

open BigOperators

namespace Workspace.Lemmas.LargeWtW

/-- **Lemma 3.2** (`lem:large-wt-W`).

For the cutoff `b = b(W, H, λ)` of Definition 3.1, the part of `H` strictly
above the cutoff (the "high-weight" part `H_{<b}`) intersects `W` in at most
half its size:
`|H_{<b} ∩ W| ≤ |H_{<b}| / 2`.

**Proof sketch (paper)**: by summation by parts using the ordering of `H` by
`λ`-values and the definition of the cutoff.

This lemma is one of the building blocks of Lemma 3.5 (`fragment_contain`),
which is in turn used in the encoding surjection.

We state the bound here in the abstract form `2 * |H_lt_b ∩ W| ≤ |H_lt_b|`,
working over `Finset X` so we do not have to commit to a particular Lean
encoding of the cutoff `b` and the prefix `H_<b`.

**Source**: @../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf
         (@../../../arXiv-2412.03540v1.tex, Section 3, Lemma 3.2 / `lem:large-wt-W`)
-/
theorem large_wt_W
    {X : Type} [Fintype X] [DecidableEq X]
    (W : Finset X) (H_lt_b : Finset X)
    (lambda : X → ℝ)
    (h_pos : ∀ x ∈ H_lt_b, 0 < lambda x)
    -- The cutoff property: for every prefix `H_{[b',b)} ⊆ H_lt_b`, the weight
    -- on `W` is less than half the total weight.
    (h_cut : ∀ S : Finset X, S ⊆ H_lt_b →
      2 * (∑ x ∈ S ∩ W, lambda x) < ∑ x ∈ S, lambda x ∨ S = ∅) :
    2 * (H_lt_b ∩ W).card ≤ H_lt_b.card := by
  -- Show H_lt_b ∩ W is empty
  have h_empty : H_lt_b ∩ W = ∅ := by
    rw [Finset.eq_empty_iff_forall_notMem]
    intro x hx
    rw [Finset.mem_inter] at hx
    obtain ⟨hxH, hxW⟩ := hx
    have hx_subset : ({x} : Finset X) ⊆ H_lt_b := Finset.singleton_subset_iff.mpr hxH
    have hx_pos : 0 < lambda x := h_pos x hxH
    have h_inter : ({x} : Finset X) ∩ W = {x} := by
      ext y
      simp only [Finset.mem_inter, Finset.mem_singleton]
      refine ⟨fun h => h.1, fun hy => ⟨hy, ?_⟩⟩
      rw [hy]; exact hxW
    rcases h_cut {x} hx_subset with hineq | hempty
    · rw [h_inter, Finset.sum_singleton] at hineq
      linarith
    · simp at hempty
  rw [h_empty]
  simp

end Workspace.Lemmas.LargeWtW
