import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.CoverCollection
import Workspace.Definitions.TFeasibility
import Workspace.Definitions.Cutoff
import Workspace.Definitions.IterativeR

open BigOperators
open Classical

namespace Workspace.Lemmas.FiberTFeasible

open Workspace.Definitions.CoverCollection
open Workspace.Definitions.TFeasibility
open Workspace.Definitions.Cutoff
open Workspace.Definitions.IterativeR

/-! # `t`-feasibility for fiber elements (paper §3.2, Definition 3.3)

# Status: superseded

Previously this file contained:

* the axiom `fiber_R_subset_chosenZ` (per fiber element, the existence of
  `H ∈ ℋ` with `R_at W H λ_H i ⊆ chosenZ i`), and
* the derived theorem `chosenZ_tFeasible`.

Both have been **superseded** by the single atomic axiom
`Workspace.Axioms.CanonicalRWitness.canonical_R_for_fiber`, which directly
produces a canonical container family `R` per fiber element together with
the structural conclusions of Lemma 3.5. The `chosenZ_tFeasible` route
through `t`-feasibility is no longer needed: the consumer
`Workspace.Lemmas.MinimumTower.minimum_tower_canonical_R` now uses
`canonical_R_for_fiber` directly, bypassing `t`-feasibility entirely.

This file is kept (without axioms or unproven theorems) for historical
context and to record the old API. It currently exports nothing
meaningful.

# Reference

* Paper `@../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf`
* TeX source `@../../../arXiv-2412.03540v1.tex`, Section 3.2,
  Definitions 3.3–3.4 and Lemma 3.5 / `lem:fragment-contain`.
-/

end Workspace.Lemmas.FiberTFeasible
