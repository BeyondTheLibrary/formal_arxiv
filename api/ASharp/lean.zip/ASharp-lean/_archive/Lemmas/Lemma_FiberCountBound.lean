import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Sigma
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.CoverCollection
import Workspace.Definitions.TFeasibility
import Workspace.Lemmas.Lemma_FiberInjection
import Workspace.Lemmas.Lemma_LevelSetCount

open BigOperators
open Classical
open Workspace.Definitions.CoverCollection
open Workspace.Definitions.TFeasibility
open Workspace.Lemmas.FiberInjection

namespace Workspace.Lemmas.FiberCountBound

/-! # Fiber count bound (paper §3.3, central combinatorial claim).

**Source**: `@../arXiv-2412.03540v1.tex`, Section 3.3, eq. `eq:surj`.

For each fixed `Z : ℕ → Finset X` and `u : ℕ`, the number of genuine min-tower
cover pairs `(W, U)` with `U ∈ coverCollection ℋ s lambda_vec W`,
`chosenZ ℋ s lambda_vec W U = Z`, `|U| = u`, is at most `C(2u, u)`.

This is now SOUND: the cover is grounded in the genuine minimum tower
(`Workspace.Encoding.*`), so the spurious non-minimal fiber elements that made
the earlier loose statement false (see `proving_notes.md`, vacuity check) are
absent. The bound is proven from:

* `Workspace.Lemmas.FiberInjection.fiber_inj_to_levelSet` — the surjection
  inversion into the `u`-subsets of a single ground set `Y(Z)` of size `≤ 2u`,
  existence of which (`canonical_Z_container`) is the R2 fiber-uniformity axiom
  `Workspace.Axioms.FiberUniformity.canonical_Z_container_exists`, scoped to
  `¬ IsPSmall ℋ p` (TRUE in-regime; see that file).
* `Workspace.Lemmas.LevelSetCount.levelSetCount_le_central_binom_of_card_le` —
  the count of `u`-subsets of a `≤ 2u`-set is `≤ C(2u, u)` (fully proven).

The `(p, h_not_small)` hypotheses are supplied by the caller
(`Lemma_KeyLemma.key_lemma_bound`, which carries `¬ IsPSmall ℋ p`). -/
theorem fiber_count_bound
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (p : ℝ) (h_not_small : ¬ Workspace.Types.IsPSmall.IsPSmall ℋ p)
    (Z : ℕ → Finset X) (u : ℕ) :
    (((Finset.univ : Finset (Fin s → Finset X)).sigma
        (fun W => (coverCollection ℋ s lambda_vec W).attach)).filter
        (fun p =>
          chosenZ ℋ s lambda_vec p.1 p.2.val p.2.property = Z ∧ p.2.val.card = u)).card
      ≤ Nat.choose (2 * u) u := by
  show (FiberInjection.Fiber ℋ s lambda_vec Z u).card ≤ Nat.choose (2 * u) u
  obtain ⟨Y, φ, hY_card, h_image, h_inj⟩ :=
    fiber_inj_to_levelSet ℋ s lambda_vec p h_not_small Z u
  have h_card_eq : (FiberInjection.Fiber ℋ s lambda_vec Z u).card
      = ((FiberInjection.Fiber ℋ s lambda_vec Z u).image φ).card := by
    symm
    exact Finset.card_image_of_injOn h_inj
  rw [h_card_eq]
  have h_subset :
      (FiberInjection.Fiber ℋ s lambda_vec Z u).image φ ⊆ Y.powerset.filter (fun U => U.card = u) := by
    intro U hU
    rw [Finset.mem_image] at hU
    obtain ⟨p, hp_mem, hp_eq⟩ := hU
    rw [Finset.mem_filter, Finset.mem_powerset]
    obtain ⟨h_sub, h_card⟩ := h_image p hp_mem
    exact ⟨hp_eq ▸ h_sub, hp_eq ▸ h_card⟩
  refine le_trans (Finset.card_le_card h_subset) ?_
  rw [← Finset.powersetCard_eq_filter, Finset.card_powersetCard]
  exact Nat.choose_le_choose u hY_card

end Workspace.Lemmas.FiberCountBound
