import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Lemmas.Lemma_LargeWtW

open BigOperators

namespace Workspace.Lemmas.FragmentContain

/-- **Lemma 3.5** (`lem:fragment-contain`).

For a tower of minimum fragments `T = T(W, H)` with corresponding `Z = T ∪ W`,
let `(b̂, Ŵ, Ĥ)` be any chosen witness of the `t`-feasibility of `Z`, where
`t = (|T₁|,…,|T_s|)`. Then for each `i`,
`T_i ⊆ (Ĥ_i)_{<b̂_i}` and `|T_i| ≥ |(Ĥ_i)_{<b̂_i}| / 2`.

**Proof sketch (paper)**: the inclusion follows by minimality of the tower
(if some `T_i` had an element outside `(Ĥ_i)_{<b̂_i}`, replacing it by the
intersection would give a strictly smaller tower of fragments, contradicting
minimality). The size bound uses Lemma 3.2 (`large_wt_W`):
`|(Ĥ_i)_{<b̂_i} ∩ Ŵ_i| ≤ |(Ĥ_i)_{<b̂_i}| / 2`, hence
`|T_i| ≥ |(Ĥ_i)_{<b̂_i} \ Ŵ_i| ≥ |(Ĥ_i)_{<b̂_i}| / 2`.

We state the conclusion abstractly over `Finset X`, since both `T_i` and the
container `(Ĥ_i)_{<b̂_i}` are concretely realised as `Finset X` in the
formalisation. The Lean lemma takes the three structural hypotheses
(minimality, the large-weight bound, the minimum-size containment) as
parameters and discharges the conclusion by elementary card arithmetic.

**Source**: @../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf
         (@../../../arXiv-2412.03540v1.tex, Section 3, Lemma 3.5 / `lem:fragment-contain`)
-/
theorem fragment_contain
    {X : Type} [Fintype X] [DecidableEq X]
    (T_i container_i W_hat_i : Finset X)
    -- Containment: T_i lies in the chosen container.
    (_h_min : ∀ S : Finset X, S ⊆ T_i → S ⊆ container_i)
    -- Lemma 3.2 applied to (container_i, W_hat_i):
    (_h_large_wt : 2 * (container_i ∩ W_hat_i).card ≤ container_i.card)
    -- Minimum tower property: T_i ⊇ container_i \ W_hat_i.
    (_h_min_size : container_i \ W_hat_i ⊆ T_i) :
    T_i ⊆ container_i ∧ 2 * T_i.card ≥ container_i.card := by
  refine ⟨_h_min T_i (Finset.Subset.refl _), ?_⟩
  have h1 : (container_i \ W_hat_i).card ≤ T_i.card := Finset.card_le_card _h_min_size
  have h2 : (container_i \ W_hat_i).card + (container_i ∩ W_hat_i).card = container_i.card :=
    Finset.card_sdiff_add_card_inter container_i W_hat_i
  omega

end Workspace.Lemmas.FragmentContain
