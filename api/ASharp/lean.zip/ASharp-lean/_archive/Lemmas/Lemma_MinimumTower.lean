import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Sigma
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.CoverCollection
import Workspace.Definitions.TFeasibility
import Workspace.Axioms.CanonicalRWitness

open BigOperators
open Workspace.Definitions.CoverCollection
open Workspace.Definitions.TFeasibility
open Workspace.Axioms.CanonicalRWitness

namespace Workspace.Lemmas.MinimumTower

/-- **Canonical R witness data** for `(Z, u)`. -/
structure CanonicalRWitness {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (Z : Fin s → Finset X) (u : ℕ) where
  R : Fin s → Finset X
  R_pairwise_disjoint : ∀ i j : Fin s, i ≠ j → Disjoint (R i) (R j)
  T_subset_R :
    ∀ (W : Fin s → Finset X) (U : Finset X)
      (hU : U ∈ coverCollection ℋ s W),
    chosenZ ℋ s W U hU = Z → U.card = u →
    ∀ i, U ∩ chosenContainer ℋ s W U hU i ⊆ R i
  R_inter_U_eq_T :
    ∀ (W : Fin s → Finset X) (U : Finset X)
      (hU : U ∈ coverCollection ℋ s W),
    chosenZ ℋ s W U hU = Z → U.card = u →
    ∀ i, U ∩ R i ⊆ U ∩ chosenContainer ℋ s W U hU i
  R_card_le_two_T :
    ∀ (W : Fin s → Finset X) (U : Finset X)
      (hU : U ∈ coverCollection ℋ s W),
    chosenZ ℋ s W U hU = Z → U.card = u →
    ∀ i, 2 * (U ∩ chosenContainer ℋ s W U hU i).card ≥ (R i).card

theorem minimum_tower_canonical_R
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (Z : Fin s → Finset X) (u : ℕ) :
    Nonempty (CanonicalRWitness ℋ s Z u) := by
  by_cases h_empty :
    (((Finset.univ : Finset (Fin s → Finset X)).sigma
        (fun W => (coverCollection ℋ s W).attach)).filter
        (fun p => chosenZ ℋ s p.1 p.2.val p.2.property = Z ∧
                  p.2.val.card = u)) = ∅
  · refine ⟨{
      R := fun _ => (∅ : Finset X)
      R_pairwise_disjoint := fun _ _ _ => Finset.disjoint_empty_left _
      T_subset_R := ?_
      R_inter_U_eq_T := ?_
      R_card_le_two_T := ?_
    }⟩
    all_goals (
      intro W U hU hZ hcard i
      exfalso
      have hp_mem :
          (⟨W, ⟨U, hU⟩⟩ :
            (W : Fin s → Finset X) × { U // U ∈ coverCollection ℋ s W }) ∈
            ((Finset.univ : Finset (Fin s → Finset X)).sigma
              (fun W => (coverCollection ℋ s W).attach)).filter
              (fun p => chosenZ ℋ s p.1 p.2.val p.2.property = Z ∧
                        p.2.val.card = u) := by
        refine Finset.mem_filter.mpr ⟨?_, hZ, hcard⟩
        exact Finset.mem_sigma.mpr ⟨Finset.mem_univ _, Finset.mem_attach _ _⟩
      rw [h_empty] at hp_mem
      exact Finset.notMem_empty _ hp_mem)
  · have h_nonempty :
        (((Finset.univ : Finset (Fin s → Finset X)).sigma
            (fun W => (coverCollection ℋ s W).attach)).filter
            (fun p => chosenZ ℋ s p.1 p.2.val p.2.property = Z ∧
                      p.2.val.card = u)).Nonempty :=
      Finset.nonempty_iff_ne_empty.mpr h_empty
    obtain ⟨p₀, hp₀⟩ := h_nonempty
    have hp₀_data := (Finset.mem_filter.mp hp₀).2
    have hp₀_Z : chosenZ ℋ s p₀.1 p₀.2.val p₀.2.property = Z := hp₀_data.1
    have hp₀_card : p₀.2.val.card = u := hp₀_data.2
    obtain ⟨R, h_disjoint, h_universal⟩ :=
      canonical_R_for_fiber ℋ s p₀.1 p₀.2.val p₀.2.property
    refine ⟨{
      R := R
      R_pairwise_disjoint := h_disjoint
      T_subset_R := ?_
      R_inter_U_eq_T := ?_
      R_card_le_two_T := ?_
    }⟩
    · intro W U hU hZ hcard i
      have hZ' : chosenZ ℋ s W U hU = chosenZ ℋ s p₀.1 p₀.2.val p₀.2.property := by
        rw [hZ, ← hp₀_Z]
      have hcard' : U.card = p₀.2.val.card := by rw [hcard, ← hp₀_card]
      have h_spec := chosenContainer_T_spec hU
      simp only at h_spec
      obtain ⟨_, _, h_inter_eq, _, _, _⟩ := h_spec
      have h_T_eq : U ∩ chosenContainer ℋ s W U hU i = chosenT ℋ s W U hU i :=
        h_inter_eq i
      rw [h_T_eq]
      exact (h_universal W U hU hZ' hcard' i).1
    · intro W U hU hZ hcard i
      have hZ' : chosenZ ℋ s W U hU = chosenZ ℋ s p₀.1 p₀.2.val p₀.2.property := by
        rw [hZ, ← hp₀_Z]
      have hcard' : U.card = p₀.2.val.card := by rw [hcard, ← hp₀_card]
      have h_spec := chosenContainer_T_spec hU
      simp only at h_spec
      obtain ⟨_, _, h_inter_eq, _, _, _⟩ := h_spec
      have h_T_eq : U ∩ chosenContainer ℋ s W U hU i = chosenT ℋ s W U hU i :=
        h_inter_eq i
      rw [h_T_eq]
      exact (h_universal W U hU hZ' hcard' i).2.1
    · intro W U hU hZ hcard i
      have hZ' : chosenZ ℋ s W U hU = chosenZ ℋ s p₀.1 p₀.2.val p₀.2.property := by
        rw [hZ, ← hp₀_Z]
      have hcard' : U.card = p₀.2.val.card := by rw [hcard, ← hp₀_card]
      have h_spec := chosenContainer_T_spec hU
      simp only at h_spec
      obtain ⟨_, _, h_inter_eq, _, _, _⟩ := h_spec
      have h_T_eq : U ∩ chosenContainer ℋ s W U hU i = chosenT ℋ s W U hU i :=
        h_inter_eq i
      rw [h_T_eq]
      exact (h_universal W U hU hZ' hcard' i).2.2

end Workspace.Lemmas.MinimumTower
