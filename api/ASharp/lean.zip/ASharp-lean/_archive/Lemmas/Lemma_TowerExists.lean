import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.Tower

open BigOperators

namespace Workspace.Lemmas.TowerExists

open Workspace.Definitions.Tower

/-- **Existence of the tower of minimum fragments**.

For every `H ∈ ℋ` and tuple of samples `W = (W_1,…,W_s)`, the minimum tower of
fragments `T(W, H)` is well-defined (paper, Lemma between Definition 3.4 and
the "key property" lemma).

This lemma asserts the existence of a `TowerData ℋ s` containing the given
`W` and `H`, equipped with the bundled side-properties of Lemma 3.5
(`fragment_contain`) and the disjointness of containers `(Ĥ_i)_{<b̂_i}`.

The actual construction (cutoff `b`, iterative procedure for `H_i`, choice of
witness `(b̂, Ŵ, Ĥ)` for `t`-feasibility, and minimality of the tower) is the
deep content of Section 3 of the paper. The current Lean proof uses the
*trivial* tower (with `T_i = ∅`, `container_i = ∅`), which is sufficient
to discharge the bundled side-properties; the genuine tower properties
relevant to the counting argument are encapsulated by the
`Workspace.Lemmas.FiberCountBound.fiber_count_bound` axiom.

**Source**: @../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf
         (@../../../arXiv-2412.03540v1.tex, Section 3, Definition 3.4 and surrounding lemmas)
-/
theorem tower_exists
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (W : Fin s → Finset X) (H : Finset X) (hH : H ∈ ℋ) :
    ∃ td : TowerData ℋ s, td.W = W ∧ td.H = H := by
  refine ⟨{
    W := W
    T := fun _ => ∅
    H := H
    container := fun _ => ∅
    H_mem := hH
    T_subset_H := fun _ => Finset.empty_subset _
    T_disj_W := fun _ => Finset.disjoint_empty_left _
    T_subset_container := fun _ => Finset.Subset.refl _
    container_pairwise_disjoint := fun _ _ _ => Finset.disjoint_empty_left _
  }, rfl, rfl⟩

end Workspace.Lemmas.TowerExists
