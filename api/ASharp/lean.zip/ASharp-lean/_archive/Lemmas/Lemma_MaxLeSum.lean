import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Real.Basic
import Workspace.Types.FractionalCover
import Workspace.Lemmas.Lemma_SumOverSubsetLe

open BigOperators

namespace Workspace.Lemmas.MaxLeSum

open Workspace.Types.FractionalCover

/-- Helper lemma: if the max over H is at least v, then the sum over all W' is at least v.

**Source**: @../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf
         (@../../../arXiv-2412.03540v1.tex, Section 4, Proof of Theorem 1.2)
-/
lemma max_le_sum {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (cov : FractionalCover X ℋ)
    (W : Finset X) (v : ℝ)
    (h : ∃ (H : Finset X) (_hH : H ∈ ℋ), v ≤ ∑ W' ∈ (H ∩ W).powerset, cov.w W') :
    v ≤ ∑ W' ∈ W.powerset, cov.w W' := by
  obtain ⟨H, hH, h_sum⟩ := h
  calc v ≤ ∑ W' ∈ (H ∩ W).powerset, cov.w W' := h_sum
       _ ≤ ∑ W' ∈ W.powerset, cov.w W' := Workspace.Lemmas.SumOverSubsetLe.sum_over_subset_le ℋ cov W H hH

end Workspace.Lemmas.MaxLeSum
