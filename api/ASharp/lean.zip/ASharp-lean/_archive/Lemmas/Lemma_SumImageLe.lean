import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic.Linarith

open BigOperators

namespace Workspace.Lemmas.SumImageLe

/-- **Sum-over-image bound**: For `f : α → β`, sum on the source equals
sum on the image, weighted by preimage cardinality. -/
lemma sum_eq_sum_image_card_smul
    {α β : Type*} [DecidableEq β]
    (s : Finset α) (f : α → β) (g : β → ℝ) :
    ∑ x ∈ s, g (f x) = ∑ y ∈ s.image f, ((s.filter (fun x => f x = y)).card : ℝ) * g y := by
  -- Group `s` by the value of `f` over its image, using `sum_fiberwise_of_maps_to`.
  have h_maps_to : ∀ x ∈ s, f x ∈ s.image f := fun x hx => Finset.mem_image_of_mem f hx
  -- First, rewrite the LHS as a fiberwise sum over `s.image f`.
  have h_fiber :
      ∑ y ∈ s.image f, ∑ x ∈ s.filter (fun x => f x = y), g (f x) = ∑ x ∈ s, g (f x) :=
    Finset.sum_fiberwise_of_maps_to h_maps_to (fun x => g (f x))
  -- On each fiber, `f x = y`, so `g (f x) = g y`.
  have h_inner :
      ∀ y ∈ s.image f,
        ∑ x ∈ s.filter (fun x => f x = y), g (f x)
          = ((s.filter (fun x => f x = y)).card : ℝ) * g y := by
    intro y _
    have h_eq : ∀ x ∈ s.filter (fun x => f x = y), g (f x) = g y := by
      intro x hx
      have : f x = y := (Finset.mem_filter.mp hx).2
      rw [this]
    rw [Finset.sum_congr rfl h_eq, Finset.sum_const, nsmul_eq_mul]
  -- Combine: rewrite the inner sums and rearrange.
  calc ∑ x ∈ s, g (f x)
      = ∑ y ∈ s.image f, ∑ x ∈ s.filter (fun x => f x = y), g (f x) := h_fiber.symm
    _ = ∑ y ∈ s.image f, ((s.filter (fun x => f x = y)).card : ℝ) * g y :=
        Finset.sum_congr rfl h_inner

/-- **Sum-over-image bound (the simple version)**: when `g ≥ 0` and each preimage
has cardinality ≤ K, the source sum is bounded by K times the image sum. -/
lemma sum_le_card_smul_sum_image
    {α β : Type*} [DecidableEq β]
    (s : Finset α) (f : α → β) (g : β → ℝ)
    (K : ℕ) (h_card : ∀ y ∈ s.image f, (s.filter (fun x => f x = y)).card ≤ K)
    (hg : ∀ y ∈ s.image f, 0 ≤ g y) :
    ∑ x ∈ s, g (f x) ≤ (K : ℝ) * ∑ y ∈ s.image f, g y := by
  -- Step 1: rewrite the LHS using `sum_eq_sum_image_card_smul`.
  rw [sum_eq_sum_image_card_smul s f g]
  -- Step 2: factor `K` through the RHS sum.
  rw [Finset.mul_sum]
  -- Step 3: bound termwise.
  apply Finset.sum_le_sum
  intro y hy
  have h1 : ((s.filter (fun x => f x = y)).card : ℝ) ≤ (K : ℝ) := by
    exact_mod_cast h_card y hy
  have h2 : 0 ≤ g y := hg y hy
  exact mul_le_mul_of_nonneg_right h1 h2

/-- **Disjoint cover sum bound**: if a Finset `s` decomposes via `f` over an image
set with bounded preimages, the sum is bounded. -/
lemma sum_le_via_image
    {α β : Type*} [DecidableEq β]
    (s : Finset α) (f : α → β) (h : α → ℝ) (g : β → ℝ)
    (hf_h_le : ∀ x ∈ s, h x ≤ g (f x))
    (hg_nn : ∀ y ∈ s.image f, 0 ≤ g y) :
    ∑ x ∈ s, h x ≤ ∑ x ∈ s, g (f x) := by
  apply Finset.sum_le_sum hf_h_le

end Workspace.Lemmas.SumImageLe
