import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Tactic.Linarith

open BigOperators
open Classical

namespace Workspace.Lemmas.LevelSetCount

/-- Count of subsets `U` of a given Finset `Y` with `|U| = u`.

This is the `levelSetCount`: the number of `u`-element subsets of `Y`.
In §3.3 of the paper, `Y` plays the role of `⋃ container_i`, and the
bound `|Y| ≤ 2u` derived from `fragment_contain` (Lemma 3.5) yields the
central-binomial bound `≤ C(2u, u)`. -/
noncomputable def levelSetCount {X : Type} [Fintype X] [DecidableEq X]
    (Y : Finset X) (u : ℕ) : ℕ :=
  (Y.powerset.filter (fun U => U.card = u)).card

/-- Standard count: `#{U ⊆ Y : |U| = u} = C(|Y|, u)`.

This is the **Formula for the Number of Combinations**, expressed via the
filter-on-powerset formulation used in `levelSetCount`. The proof rewrites
the filter as `Finset.powersetCard` and applies `Finset.card_powersetCard`. -/
lemma levelSetCount_eq {X : Type} [Fintype X] [DecidableEq X]
    (Y : Finset X) (u : ℕ) :
    levelSetCount Y u = Nat.choose Y.card u := by
  unfold levelSetCount
  rw [← Finset.powersetCard_eq_filter]
  exact Finset.card_powersetCard u Y

/-- Bound: `#{U ⊆ Y : |U| = u} ≤ C(2u, u)` whenever `|Y| ≤ 2u`.

In the paper, this is applied with `Y = ⋃ container_i`, where `|Y| ≤ 2u`
follows from `fragment_contain` (Lemma 3.5): each `|T_i| ≥ |container_i|/2`
and `∑ |T_i| = u`, while the `container_i` are pairwise disjoint, hence
`|⋃ container_i| = ∑ |container_i| ≤ 2 ∑ |T_i| = 2u`. -/
lemma levelSetCount_le_central_binom_of_card_le
    {X : Type} [Fintype X] [DecidableEq X]
    (Y : Finset X) (u : ℕ) (h_card : Y.card ≤ 2 * u) :
    levelSetCount Y u ≤ Nat.choose (2 * u) u := by
  rw [levelSetCount_eq]
  exact Nat.choose_le_choose u h_card

end Workspace.Lemmas.LevelSetCount
