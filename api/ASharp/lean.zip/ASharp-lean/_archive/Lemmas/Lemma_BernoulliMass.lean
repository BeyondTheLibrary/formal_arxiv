import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Workspace.Lemmas.Lemma_JointProbBasics

open BigOperators

namespace Workspace.Lemmas.BernoulliMass

/-- **Bernoulli normalisation over `(Fin s → Finset X)`**:
the joint Bernoulli mass sums to 1. -/
theorem bernoulli_mass_eq_one
    {X : Type} [Fintype X] [DecidableEq X]
    (q : ℝ) (s : ℕ) (hq_nn : 0 ≤ q) (hq_le : q ≤ 1) :
    ∑ Z : Fin s → Finset X,
      ∏ i : Fin s, q ^ (Z i).card * (1 - q) ^ (Fintype.card X - (Z i).card) = 1 := by
  have h := Workspace.Lemmas.JointProbBasics.prob_xp_joint_norm
              (X := X) q s hq_nn hq_le
  unfold Workspace.Definitions.ProbDistributions.ProbXpJoint at h
  simp only [one_mul] at h
  exact h

end Workspace.Lemmas.BernoulliMass
