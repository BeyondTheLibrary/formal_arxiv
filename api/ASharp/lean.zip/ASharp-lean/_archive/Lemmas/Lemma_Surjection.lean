import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.Tower
import Workspace.Lemmas.Lemma_FragmentContain
import Workspace.Lemmas.Lemma_TowerExists

open BigOperators

namespace Workspace.Lemmas.Surjection

open Workspace.Definitions.Tower

/-- **Theorem (Encoding surjection, eq. 3.6 in the paper).**

For each integer `u ≥ 0`, the map
  `Ψ_u : (Z, U) ↦ (W, T)` with `T_i = U ∩ container_i` and `W_i = Z_i \ T_i`
is a surjection from
  `{(Z, U) : U ⊆ ⋃_i container_i, |U| = u}`
onto
  `{(W, T) : T = T(W, H) for some H ∈ ℋ, ∑ |T_i| = u}`.

We state surjectivity as: for every `TowerData ℋ s` (which packages a
`(W, T, H)` realising a tower of minimum fragments together with its
container sets), there exists a preimage `(Z, U)` mapping to `(W, T)` under
`Ψ_u`. The proof is purely combinatorial given the bundled properties of
`TowerData`:

1. `Z_i := T_i ∪ W_i`, `U := ⋃_i T_i`.
2. `U ⊆ ⋃_i container_i`  (since each `T_i ⊆ container_i`).
3. `|U| = ∑_i |T_i|` (since `T_i` are pairwise disjoint, inherited from
   the pairwise disjoint containers).
4. `U ∩ container_i = T_i` (cross terms vanish by container disjointness;
   the `i`-th term equals `T_i` by `T_i ⊆ container_i`).
5. `Z_i \ (U ∩ container_i) = W_i` (using step 4 and `T_i` disjoint from `W_i`).

**Source**: @../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf
         (@../../../arXiv-2412.03540v1.tex, Section 3, eq. 3.6 / `eq:surj`)
-/
theorem surjection_psi
    {X : Type} [Fintype X] [DecidableEq X]
    {ℋ : Set (Finset X)} {s : ℕ}
    (td : TowerData ℋ s) :
    ∃ (Z : Fin s → Finset X) (U : Finset X),
      -- (1) The pair `(Z, U)` lies in the domain of `Ψ_u`:
      U ⊆ (Finset.univ : Finset (Fin s)).biUnion td.container ∧
      -- (2) Its size matches the total tower size:
      U.card = ∑ i, (td.T i).card ∧
      -- (3) `Ψ_u(Z, U)` recovers `T`:
      (∀ i, U ∩ td.container i = td.T i) ∧
      -- (4) `Ψ_u(Z, U)` recovers `W`:
      (∀ i, Z i \ (U ∩ td.container i) = td.W i) ∧
      -- (5) `Z_i = T_i ∪ W_i` (book-keeping):
      (∀ i, Z i = td.T i ∪ td.W i) := by
  refine ⟨td.Z, td.U, ?_, ?_, ?_, ?_, ?_⟩
  · -- (1) U ⊆ ⋃ container i
    intro x hx
    simp only [TowerData.U, Finset.mem_biUnion, Finset.mem_univ, true_and] at hx
    obtain ⟨i, hxi⟩ := hx
    exact Finset.mem_biUnion.mpr ⟨i, Finset.mem_univ _, td.T_subset_container i hxi⟩
  · -- (2) |U| = ∑ |T_i|. Use that the T_i are pairwise disjoint
    -- (inherited from container_pairwise_disjoint).
    have hT_disj : ((Finset.univ : Finset (Fin s)) : Set (Fin s)).PairwiseDisjoint td.T := by
      intro i _ j _ hij
      exact (td.container_pairwise_disjoint i j hij).mono
        (td.T_subset_container i) (td.T_subset_container j)
    simp only [TowerData.U]
    rw [Finset.card_biUnion hT_disj]
  · -- (3) U ∩ container_i = T_i
    intro i
    ext x
    simp only [Finset.mem_inter, TowerData.U, Finset.mem_biUnion,
      Finset.mem_univ, true_and]
    constructor
    · rintro ⟨⟨j, hxj⟩, hxc⟩
      -- x ∈ T_j and x ∈ container_i. If j ≠ i, container disjointness gives contradiction.
      by_cases hji : j = i
      · exact hji ▸ hxj
      · exfalso
        have hxcj : x ∈ td.container j := td.T_subset_container j hxj
        exact (td.container_pairwise_disjoint j i hji).forall_ne_finset hxcj hxc rfl
    · intro hxi
      exact ⟨⟨i, hxi⟩, td.T_subset_container i hxi⟩
  · -- (4) Z_i \ (U ∩ container_i) = W_i, given (3) and T_i disjoint from W_i.
    intro i
    -- First simplify U ∩ container_i = T_i using the same argument as (3)
    have h_inter : td.U ∩ td.container i = td.T i := by
      ext x
      simp only [Finset.mem_inter, TowerData.U, Finset.mem_biUnion,
        Finset.mem_univ, true_and]
      constructor
      · rintro ⟨⟨j, hxj⟩, hxc⟩
        by_cases hji : j = i
        · exact hji ▸ hxj
        · exfalso
          have hxcj : x ∈ td.container j := td.T_subset_container j hxj
          exact (td.container_pairwise_disjoint j i hji).forall_ne_finset hxcj hxc rfl
      · intro hxi
        exact ⟨⟨i, hxi⟩, td.T_subset_container i hxi⟩
    rw [h_inter]
    -- Now show Z_i \ T_i = W_i, given Z_i = T_i ∪ W_i and T_i ∩ W_i = ∅.
    show (td.T i ∪ td.W i) \ td.T i = td.W i
    rw [Finset.union_sdiff_left]
    exact Finset.sdiff_eq_self_of_disjoint (td.T_disj_W i).symm
  · -- (5) Z_i = T_i ∪ W_i (definitional)
    intro i; rfl

end Workspace.Lemmas.Surjection
