import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.Cutoff
import Workspace.Definitions.IterativeR
import Workspace.Lemmas.Lemma_MinimumTowerExists

open BigOperators
open Classical

namespace Workspace.Lemmas.RAtDisjoint

open Workspace.Definitions.Cutoff
open Workspace.Definitions.IterativeR
open Workspace.Lemmas.MinimumTowerExists

/-! # Pairwise disjointness of the iterative `R_at` family

The iterative procedure preceding paper Definition 3.3 produces, for each
`i`, the prefix `R_i = (H_i)_{<b_i}`. The key observation is:

* `H_{i+1} ⊆ (H_i)_{≥b_i} \ W_i ⊆ (H_i)_{≥b_i}` (definition of `H_at_nat`).
* For `j > i`, `R_j ⊆ H_j ⊆ ⋯ ⊆ H_{i+1} ⊆ (H_i)_{≥b_i}`.
* `R_i = (H_i)_{<b_i}` is disjoint from `(H_i)_{≥b_i}` (cutoff partition).
* Hence `R_i` and `R_j` are disjoint.

This file proves `R_at_pairwise_disjoint`, eliminating one of the
ingredients previously bundled in the `minimum_tower_canonical_R` axiom.
-/

variable {X : Type} [Fintype X] [DecidableEq X]

/-- Monotonicity of `H_at_nat`: `H_at_nat W H λ (i+1) ⊆ cutoffGe (W i) (H_at_nat W H λ i) λ`. -/
lemma H_at_nat_succ_subset_cutoffGe
    (W : ℕ → Finset X) (H : Finset X) (lambda : X → ℝ) (i : ℕ) :
    H_at_nat W H lambda (i + 1) ⊆ cutoffGe (W i) (H_at_nat W H lambda i) lambda := by
  show cutoffGe (W i) (H_at_nat W H lambda i) lambda \ W i ⊆
        cutoffGe (W i) (H_at_nat W H lambda i) lambda
  exact Finset.sdiff_subset

/-- Monotonicity of `H_at_nat` over single steps:
`H_at_nat W H λ (i+1) ⊆ H_at_nat W H λ i`. -/
lemma H_at_nat_succ_subset
    (W : ℕ → Finset X) (H : Finset X) (lambda : X → ℝ) (i : ℕ) :
    H_at_nat W H lambda (i + 1) ⊆ H_at_nat W H lambda i := by
  apply (H_at_nat_succ_subset_cutoffGe W H lambda i).trans
  exact cutoffGe_subset _ _ _

/-- Monotonicity of `H_at_nat` (transitive): for `i ≤ j`,
`H_at_nat W H λ j ⊆ H_at_nat W H λ i`. -/
lemma H_at_nat_mono
    (W : ℕ → Finset X) (H : Finset X) (lambda : X → ℝ)
    {i j : ℕ} (hij : i ≤ j) :
    H_at_nat W H lambda j ⊆ H_at_nat W H lambda i := by
  induction j with
  | zero =>
      have : i = 0 := Nat.le_zero.mp hij
      subst this
      exact Finset.Subset.refl _
  | succ j ih =>
      rcases Nat.lt_or_ge i (j + 1) with hlt | hge
      · -- i ≤ j
        have hij' : i ≤ j := Nat.lt_succ_iff.mp hlt
        exact (H_at_nat_succ_subset W H lambda j).trans (ih hij')
      · -- i = j + 1
        have heq : i = j + 1 := le_antisymm hij hge
        subst heq
        exact Finset.Subset.refl _

/-- For `i < j`, `H_at_nat W H λ j ⊆ cutoffGe (W i) (H_at_nat W H λ i) λ`. -/
lemma H_at_nat_lt_subset_cutoffGe
    (W : ℕ → Finset X) (H : Finset X) (lambda : X → ℝ)
    {i j : ℕ} (hij : i < j) :
    H_at_nat W H lambda j ⊆ cutoffGe (W i) (H_at_nat W H lambda i) lambda := by
  -- `j ≥ i + 1`, so `H_at_nat j ⊆ H_at_nat (i+1) ⊆ cutoffGe (W i) (H_at_nat i) λ`.
  have h1 : H_at_nat W H lambda j ⊆ H_at_nat W H lambda (i + 1) :=
    H_at_nat_mono W H lambda (Nat.succ_le_of_lt hij)
  exact h1.trans (H_at_nat_succ_subset_cutoffGe W H lambda i)

/-- Key disjointness step: for any `W' H λ`, the chosen `cutoffLt` and
`cutoffGe` are disjoint Finsets. -/
lemma cutoffLt_cutoffGe_disjoint (W H : Finset X) (lambda : X → ℝ) :
    Disjoint (cutoffLt W H lambda) (cutoffGe W H lambda) := by
  unfold cutoffLt cutoffGe
  by_cases h : ∃ H_lt H_ge : Finset X, IsCutoff W H lambda H_lt H_ge
  · rw [dif_pos h, dif_pos h]
    have hcut : IsCutoff W H lambda (Classical.choose h)
        (Classical.choose (Classical.choose_spec h)) :=
      Classical.choose_spec (Classical.choose_spec h)
    -- IsCutoff has Disjoint H_lt H_ge as second component.
    exact hcut.2.1
  · rw [dif_neg h, dif_neg h]
    exact Finset.disjoint_empty_left _

/-- **Pairwise disjointness of the iterative `R_at` family** (paper §3.2,
implicit observation in the iterative procedure preceding Definition 3.3).

For any `W : Fin s → Finset X`, `H : Finset X`, weight `λ`, and `i ≠ j`,
the iterative `R_at i` and `R_at j` are disjoint. -/
theorem R_at_pairwise_disjoint
    {s : ℕ} (W : Fin s → Finset X) (H : Finset X) (lambda : X → ℝ)
    (i j : Fin s) (hij : i ≠ j) :
    Disjoint (R_at W H lambda i) (R_at W H lambda j) := by
  -- WLOG `i.val < j.val`; the symmetric case follows by `Disjoint.symm`.
  rcases lt_or_gt_of_ne (Fin.val_ne_of_ne hij) with hlt | hgt
  · -- Case: i.val < j.val
    -- R_at i = cutoffLt (W i) (H_at_nat i) λ
    -- R_at j = cutoffLt (W j) (H_at_nat j) λ ⊆ H_at_nat j ⊆ cutoffGe (W i) (H_at_nat i) λ
    -- Then disjointness of cutoffLt and cutoffGe at step i gives the claim.
    let W' : ℕ → Finset X :=
      fun n => if h : n < s then W ⟨n, h⟩ else ∅
    -- R_at i = R_at_nat W' H λ i.val
    have hRi : R_at W H lambda i = R_at_nat W' H lambda i.val := rfl
    have hRj : R_at W H lambda j = R_at_nat W' H lambda j.val := rfl
    rw [hRi, hRj]
    -- R_at_nat i = cutoffLt (W' i) (H_at_nat W' H λ i) λ
    unfold R_at_nat
    -- R_at_nat j ⊆ H_at_nat j ⊆ cutoffGe (W' i) (H_at_nat i) λ
    have hsub : cutoffLt (W' j.val) (H_at_nat W' H lambda j.val) lambda ⊆
        cutoffGe (W' i.val) (H_at_nat W' H lambda i.val) lambda := by
      apply (cutoffLt_subset _ _ _).trans
      exact H_at_nat_lt_subset_cutoffGe W' H lambda hlt
    exact (cutoffLt_cutoffGe_disjoint (W' i.val)
            (H_at_nat W' H lambda i.val) lambda).mono_right hsub
  · -- Case: j.val < i.val: symmetric.
    have hsymm : Disjoint (R_at W H lambda j) (R_at W H lambda i) := by
      let W' : ℕ → Finset X :=
        fun n => if h : n < s then W ⟨n, h⟩ else ∅
      have hRi : R_at W H lambda i = R_at_nat W' H lambda i.val := rfl
      have hRj : R_at W H lambda j = R_at_nat W' H lambda j.val := rfl
      rw [hRi, hRj]
      unfold R_at_nat
      have hsub : cutoffLt (W' i.val) (H_at_nat W' H lambda i.val) lambda ⊆
          cutoffGe (W' j.val) (H_at_nat W' H lambda j.val) lambda := by
        apply (cutoffLt_subset _ _ _).trans
        exact H_at_nat_lt_subset_cutoffGe W' H lambda hgt
      exact (cutoffLt_cutoffGe_disjoint (W' j.val)
              (H_at_nat W' H lambda j.val) lambda).mono_right hsub
    exact hsymm.symm

end Workspace.Lemmas.RAtDisjoint
