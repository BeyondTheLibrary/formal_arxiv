import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Workspace.Lemmas.Lemma_Surjection
import Workspace.Lemmas.Lemma_TowerExists

namespace Workspace.Lemmas.SurjectionExists

/-- The encoding surjection from `(Z, U)` pairs to `(W, T)` pairs.

This is derived from `Workspace.Lemmas.Surjection.surjection_psi` applied to
a `TowerData` configuration produced by `tower_exists`.

For each `H ∈ ℋ` and tuple `W = (W_1, …, W_s)`, there exist `Z` and `U`
such that the encoding map `Ψ_u : (Z, U) ↦ (W', T')`
defined by `T'_i = U ∩ container_i` and `W'_i = Z_i ∖ T'_i` recovers
`(W, T)` for the minimum tower of fragments `T = T(W, H)`.

**Source**: @../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf
         (@../../../arXiv-2412.03540v1.tex, Section 3, eq. 3.6 / `eq:surj`)
-/
lemma surjection_exists
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (W : Fin s → Finset X) (H : Finset X) (hH : H ∈ ℋ) :
    ∃ (Z : Fin s → Finset X) (U : Finset X)
      (container : Fin s → Finset X) (T : Fin s → Finset X),
      U ⊆ (Finset.univ : Finset (Fin s)).biUnion container ∧
      U.card = ∑ i, (T i).card ∧
      (∀ i, U ∩ container i = T i) ∧
      (∀ i, Z i \ (U ∩ container i) = W i) ∧
      (∀ i, Z i = T i ∪ W i) ∧
      (∀ i, T i ⊆ H) := by
  obtain ⟨td, hW, hH'⟩ :=
    Workspace.Lemmas.TowerExists.tower_exists ℋ s W H hH
  obtain ⟨Z, U, h1, h2, h3, h4, h5⟩ :=
    Workspace.Lemmas.Surjection.surjection_psi td
  subst hW
  subst hH'
  exact ⟨Z, U, td.container, td.T, h1, h2, h3, h4, h5, td.T_subset_H⟩

end Workspace.Lemmas.SurjectionExists
