import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Sigma
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.CoverCollection
import Workspace.Definitions.TFeasibility
import Workspace.Axioms.FiberUniformity

open BigOperators
open Classical
open Workspace.Definitions.CoverCollection
open Workspace.Definitions.TFeasibility

namespace Workspace.Lemmas.FiberInjection

/-- `Fiber` re-exported under this namespace (genuine min-tower cover fiber). -/
noncomputable def Fiber {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : ℕ → Finset X) (u : ℕ) :
    Finset ((W : Fin s → Finset X) × { U // U ∈ coverCollection ℋ s lambda_vec W }) :=
  Workspace.Definitions.TFeasibility.Fiber ℋ s lambda_vec Z u

/-- **Existence of the canonical `Z`-container** (paper §3.3 fiber-uniformity).

Scoped to `¬ IsPSmall ℋ p`: supplied by the R2 axiom
`Workspace.Axioms.FiberUniformity.canonical_Z_container_exists`. -/
theorem canonical_Z_container
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (p : ℝ) (h_not_small : ¬ Workspace.Types.IsPSmall.IsPSmall ℋ p)
    (Z : ℕ → Finset X) (u : ℕ) :
    Nonempty (Workspace.Definitions.TFeasibility.CanonicalZContainer ℋ s lambda_vec Z u) :=
  Workspace.Axioms.FiberUniformity.canonical_Z_container_exists ℋ s lambda_vec p h_not_small Z u

/-- **Surjection inversion**: the fiber injects into the `u`-subsets of a single
ground set `Y(Z)` of size `≤ 2u` (paper §3.3, `eq:surj`). -/
theorem fiber_inj_to_levelSet
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (p : ℝ) (h_not_small : ¬ Workspace.Types.IsPSmall.IsPSmall ℋ p)
    (Z : ℕ → Finset X) (u : ℕ) :
    ∃ (Y : Finset X) (φ : (W : Fin s → Finset X) ×
                            { U // U ∈ coverCollection ℋ s lambda_vec W } → Finset X),
      Y.card ≤ 2 * u ∧
      (∀ p ∈ Fiber ℋ s lambda_vec Z u, φ p ⊆ Y ∧ (φ p).card = u) ∧
      Set.InjOn φ (Fiber ℋ s lambda_vec Z u : Set _) := by
  obtain ⟨c⟩ := canonical_Z_container ℋ s lambda_vec p h_not_small Z u
  refine ⟨(Finset.range s).biUnion c.R, fun p => p.2.val,
          c.R_card_le, ?_, ?_⟩
  · intro p hp
    refine ⟨c.fiber_subset p hp, ?_⟩
    have hp' :
        p ∈ ((Finset.univ : Finset (Fin s → Finset X)).sigma
              (fun W => (coverCollection ℋ s lambda_vec W).attach)).filter
            (fun p => chosenZ ℋ s lambda_vec p.1 p.2.val p.2.property = Z ∧
                      p.2.val.card = u) := hp
    exact (Finset.mem_filter.mp hp').2.2
  · intro p hp q hq h_eq
    have hU : p.2.val = q.2.val := h_eq
    have hW : p.1 = q.1 := by
      funext i
      by_cases hi : (i : ℕ) < s
      · -- recover via fiber_W_recovery at index i.val
        have hp_rec : Z (i : ℕ) \ (p.2.val ∩ c.R (i : ℕ)) = liftW s p.1 (i : ℕ) :=
          c.fiber_W_recovery p hp (i : ℕ) hi
        have hq_rec : Z (i : ℕ) \ (q.2.val ∩ c.R (i : ℕ)) = liftW s q.1 (i : ℕ) :=
          c.fiber_W_recovery q hq (i : ℕ) hi
        have hpl : liftW s p.1 (i : ℕ) = p.1 i := liftW_apply_lt s p.1 hi
        have hql : liftW s q.1 (i : ℕ) = q.1 i := liftW_apply_lt s q.1 hi
        rw [← hpl, ← hp_rec, ← hql, ← hq_rec, hU]
      · -- i : Fin s so i.val < s always; this branch is vacuous
        exact absurd i.isLt hi
    rcases p with ⟨pW, pU⟩
    rcases q with ⟨qW, qU⟩
    simp only at hU hW ⊢
    subst hW
    rcases pU with ⟨pUv, pUh⟩
    rcases qU with ⟨qUv, qUh⟩
    simp only [Sigma.mk.injEq, heq_eq_eq, true_and, Subtype.mk.injEq] at *
    exact hU

end Workspace.Lemmas.FiberInjection
