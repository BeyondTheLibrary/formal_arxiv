import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Sigma
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Workspace.Definitions.CoverCollection
import Workspace.Definitions.TFeasibility
import Workspace.Definitions.Cutoff
import Workspace.Definitions.IterativeR
import Workspace.Definitions.CanonicalWitness
import Workspace.Lemmas.Lemma_RAtDisjoint

open BigOperators
open Workspace.Definitions.CoverCollection
open Workspace.Definitions.TFeasibility
open Workspace.Definitions.Cutoff
open Workspace.Definitions.IterativeR
open Workspace.Definitions.CanonicalWitness
open Workspace.Lemmas.RAtDisjoint

namespace Workspace.Lemmas.CanonicalRDisjoint

/-- **Pairwise disjointness of the canonical R̂ family** (provable, no axiom).

The canonical `R̂_i = R_at(Ŵ, Ĥ, λ_Ĥ) i` family — defined on top of the
`canonicalWitness` (paper .tex line 422) — inherits the pairwise
disjointness of `R_at` from `Workspace.Lemmas.Lemma_RAtDisjoint`.

This lemma is the *proven* part of what was previously bundled inside
`canonical_R_for_fiber`'s disjointness claim. The remaining axiomatic
content is purely the *fiber-uniformity* claim: the *same* `R̂` works for
every fiber element. -/
theorem canonicalR_pairwise_disjoint
    {X : Type} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (Z : Fin s → Finset X) (t : Fin s → ℕ)
    (h : TFeasible ℋ s lambda_vec Z t) (i j : Fin s) (hij : i ≠ j) :
    Disjoint (canonicalR ℋ s lambda_vec Z t h i)
             (canonicalR ℋ s lambda_vec Z t h j) :=
  R_at_pairwise_disjoint
    (canonicalW_hat ℋ s lambda_vec Z t h)
    (canonicalH_hat ℋ s lambda_vec Z t h)
    (lambda_vec (canonicalH_hat ℋ s lambda_vec Z t h)
                (canonicalH_hat_mem ℋ s lambda_vec Z t h))
    i j hij

end Workspace.Lemmas.CanonicalRDisjoint
