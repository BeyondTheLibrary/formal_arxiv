import Mathlib.Data.Finset.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Powerset
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Real.Basic
import Workspace.Types.FractionalCover

open BigOperators

namespace Workspace.Lemmas.SumPositiveCardOnly

open Workspace.Types.FractionalCover

/-- If w(∅) = 0 and w(W) ≥ 0, then ∑_W w(W) a^|W| is a sum over non-empty sets only.

**Proof**: The only Finset with `card = 0` is `∅`, and `cov.w ∅ = 0`
(by `FractionalCover.w_empty`). So the contribution from `W = ∅` is
`0 * a^0 = 0`, and including or excluding it leaves the sum unchanged.

**Source**: @../A_sharp_version_of_Talagrands_selector_process_conjecture_and_an_application_to_rounding_fractional_covers.pdf
         (@../../../arXiv-2412.03540v1.tex, Section 4, Proof of Theorem 1.2)
-/
theorem sum_positive_card_only {X : Type} [Fintype X] [DecidableEq X]
    (cov : FractionalCover X (∅ : Set (Finset X))) (a : ℝ) :
    (∑ W : Finset X, cov.w W * a ^ W.card) = (∑ W : Finset X, if W.card > 0 then cov.w W * a ^ W.card else 0) := by
  apply Finset.sum_congr rfl
  intro W _hW
  by_cases h : W.card > 0
  · rw [if_pos h]
  · rw [if_neg h]
    have h0 : W.card = 0 := by omega
    have hW_empty : W = ∅ := Finset.card_eq_zero.mp h0
    rw [hW_empty, cov.w_empty, zero_mul]

end Workspace.Lemmas.SumPositiveCardOnly
