import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Data.Finset.Max
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Powerset
import Mathlib.Data.Finset.Sigma
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Order.PiLex
import Mathlib.Data.DFinsupp.WellFounded
import Workspace.Definitions.Cutoff
import Workspace.Definitions.IterativeR
import Workspace.Definitions.TFeasibility

open BigOperators
open Classical

namespace Workspace.Lemmas.MinimumTowerExists

open Workspace.Definitions.Cutoff
open Workspace.Definitions.IterativeR
open Workspace.Definitions.TFeasibility

/-! # Existence of a minimum tower of fragments
(paper §3.2, Lemma between Definition 3.4 and Lemma 3.5)

For every `H ∈ ℋ` and tuple `W = (W_1, …, W_s)`, there exists a *minimum*
tower of fragments of `(W, H)`: a tuple `T = (T_1, …, T_s)` of subsets of
`H` with `Z := T ∪ W` being `t`-feasible (`t_i = |T_i|`), minimal in the
lexicographic order on `(|T_1|, …, |T_s|)`.

The proof has two parts:

* **Existence of *some* tower of fragments** — paper observes that
  `T_i := R_at W H λ_H i \ W_i` is always a tower of fragments, with
  witness `W' := W` for the `t`-feasibility of `Z = T ∪ W` (note that
  `Z_i = (R_at i \ W_i) ∪ W_i ⊇ R_at i`, so the `R_at`-containment
  condition holds).

* **Lex-minimization** — over the finite set of all tuples in
  `(Fin s → Finset X)`, the predicate "is a tower of fragments" cuts out
  a non-empty Finset (Step 1). Apply `Finset.exists_min_image` against
  the linear order `Lex (Fin s → ℕ)` (given by the well-founded lex
  order on `Fin s` indexing into `ℕ`).

**Source**: @../arXiv-2412.03540v1.tex, Section 3.2, Definition 3.4 and
the Lemma immediately preceding `lem:fragment-contain`.
-/

variable {X : Type} [Fintype X] [DecidableEq X]

/-- **Tower of fragments** predicate (paper Definition 3.4).

`T : Fin s → Finset X` is a tower of fragments of `(W, H)` (with weights
provided by `lambda_vec`) if:

* `T_i ⊆ H` for all `i` (so `⋃ T_i ⊆ H`);
* `T_i` is disjoint from `W_i` for all `i` (the paper's tower has
  `T_i ⊆ H \ W_i` implicit via `T_i ⊆ R_i(W,H) \ W_i` in the canonical
  candidate; we record disjointness explicitly so the size identity
  `|Z_i| = |T_i| + |W_i|` holds);
* `Z := T ∪ W` is `t`-feasible (with `t_i = |T_i|`).
-/
def IsTowerOfFragments
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (W : Fin s → Finset X) (H : Finset X) (_hH : H ∈ ℋ)
    (T : Fin s → Finset X) : Prop :=
  (∀ i, T i ⊆ H) ∧
  (∀ i, Disjoint (T i) (W i)) ∧
  TFeasible ℋ s lambda_vec (fun i => T i ∪ W i) (fun i => (T i).card)

/-! ## Helper: the "trivial" tower `T_i = R_at W H λ_H i \ W_i`. -/

/-- The trivial tower candidate `T_i = R_at(W,H) i \ W_i`. -/
noncomputable def trivialTower {s : ℕ}
    (W : Fin s → Finset X) (H : Finset X) (lambda : X → ℝ) :
    Fin s → Finset X :=
  fun i => R_at W H lambda i \ W i

/-! ### Subset bookkeeping for the iterative procedure. -/

/-- For any `W, H, λ`, the chosen `cutoffLt` lies inside `H`. -/
lemma cutoffLt_subset (W H : Finset X) (lambda : X → ℝ) :
    cutoffLt W H lambda ⊆ H := by
  unfold cutoffLt
  by_cases h : ∃ H_lt H_ge : Finset X, IsCutoff W H lambda H_lt H_ge
  · rw [dif_pos h]
    have hcut : IsCutoff W H lambda (Classical.choose h)
        (Classical.choose (Classical.choose_spec h)) :=
      Classical.choose_spec (Classical.choose_spec h)
    -- IsCutoff ... = (H_lt ∪ H_ge = H) ∧ ...
    have hunion : Classical.choose h ∪
        Classical.choose (Classical.choose_spec h) = H := hcut.1
    intro x hx
    have : x ∈ Classical.choose h ∪
        Classical.choose (Classical.choose_spec h) :=
      Finset.mem_union_left _ hx
    rw [hunion] at this
    exact this
  · rw [dif_neg h]
    exact Finset.empty_subset _

/-- For any `W, H, λ`, the chosen `cutoffGe` lies inside `H`. -/
lemma cutoffGe_subset (W H : Finset X) (lambda : X → ℝ) :
    cutoffGe W H lambda ⊆ H := by
  unfold cutoffGe
  by_cases h : ∃ H_lt H_ge : Finset X, IsCutoff W H lambda H_lt H_ge
  · rw [dif_pos h]
    have hcut : IsCutoff W H lambda (Classical.choose h)
        (Classical.choose (Classical.choose_spec h)) :=
      Classical.choose_spec (Classical.choose_spec h)
    have hunion : Classical.choose h ∪
        Classical.choose (Classical.choose_spec h) = H := hcut.1
    intro x hx
    have : x ∈ Classical.choose h ∪
        Classical.choose (Classical.choose_spec h) :=
      Finset.mem_union_right _ hx
    rw [hunion] at this
    exact this
  · rw [dif_neg h]

/-- The iterative `H_at_nat W H λ i` is a subset of `H` for every `i`. -/
lemma H_at_nat_subset (W : ℕ → Finset X) (H : Finset X) (lambda : X → ℝ) :
    ∀ i, H_at_nat W H lambda i ⊆ H
  | 0 => by
      unfold H_at_nat
      exact Finset.Subset.refl _
  | i + 1 => by
      unfold H_at_nat
      -- H_at_nat (i+1) = cutoffGe W_i (H_at_nat i) λ \ W_i ⊆ cutoffGe W_i (H_at_nat i) λ
      have hsub_diff :
          cutoffGe (W i) (H_at_nat W H lambda i) lambda \ W i ⊆
          cutoffGe (W i) (H_at_nat W H lambda i) lambda :=
        Finset.sdiff_subset
      have hsub_cutoff :
          cutoffGe (W i) (H_at_nat W H lambda i) lambda ⊆
          H_at_nat W H lambda i :=
        cutoffGe_subset _ _ _
      have hih : H_at_nat W H lambda i ⊆ H := H_at_nat_subset W H lambda i
      exact hsub_diff.trans (hsub_cutoff.trans hih)

/-- The iterative `R_at_nat W H λ i` is a subset of `H_at_nat W H λ i`. -/
lemma R_at_nat_subset_H_at_nat
    (W : ℕ → Finset X) (H : Finset X) (lambda : X → ℝ) (i : ℕ) :
    R_at_nat W H lambda i ⊆ H_at_nat W H lambda i := by
  unfold R_at_nat
  exact cutoffLt_subset _ _ _

/-- `R_at W H λ i ⊆ H` for all `i`. -/
lemma R_at_subset_H {s : ℕ}
    (W : Fin s → Finset X) (H : Finset X) (lambda : X → ℝ) (i : Fin s) :
    R_at W H lambda i ⊆ H := by
  unfold R_at
  exact (R_at_nat_subset_H_at_nat _ _ _ _).trans
    (H_at_nat_subset _ _ _ _)

/-! ## Step 1: the trivial tower is a tower of fragments. -/

/-- The trivial tower `T_i = R_at(W,H) i \ W_i` is a tower of fragments. -/
lemma trivialTower_isTower
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (W : Fin s → Finset X) (H : Finset X) (hH : H ∈ ℋ) :
    IsTowerOfFragments ℋ s lambda_vec W H hH
      (trivialTower W H (lambda_vec H hH)) := by
  refine ⟨?_, ?_, ?_⟩
  · -- T_i ⊆ H
    intro i
    have h1 : trivialTower W H (lambda_vec H hH) i ⊆ R_at W H (lambda_vec H hH) i :=
      Finset.sdiff_subset
    exact h1.trans (R_at_subset_H _ _ _ _)
  · -- Disjoint (T i) (W i)
    intro i
    -- T i = R_at i \ W i; (R_at i \ W i) ∩ W i = ∅
    unfold trivialTower
    exact Finset.sdiff_disjoint
  · -- t-feasibility witness: take W' := W, H' := H.
    refine ⟨{
      W' := W
      H := H
      H_mem := hH
      W'_subset := ?_
      W'_card := ?_
      R_subset_Z := ?_
    }⟩
    · intro i
      -- W i ⊆ T i ∪ W i = (R_at i \ W i) ∪ W i
      intro x hx
      exact Finset.mem_union_right _ hx
    · intro i
      -- |W i| = |T i ∪ W i| - |T i|
      -- T i = R_at i \ W i, disjoint from W i; so |T i ∪ W i| = |T i| + |W i|.
      have hdisj : Disjoint (trivialTower W H (lambda_vec H hH) i) (W i) := by
        unfold trivialTower
        exact Finset.sdiff_disjoint
      have hcard :
          (trivialTower W H (lambda_vec H hH) i ∪ W i).card =
            (trivialTower W H (lambda_vec H hH) i).card + (W i).card :=
        Finset.card_union_of_disjoint hdisj
      omega
    · intro i
      -- R_at W H λ_H i ⊆ Z_i = T_i ∪ W_i = (R_at i \ W i) ∪ W_i
      -- Indeed, R_at i ⊆ (R_at i \ W i) ∪ W_i.
      intro x hx
      by_cases hxW : x ∈ W i
      · exact Finset.mem_union_right _ hxW
      · have : x ∈ R_at W H (lambda_vec H hH) i \ W i :=
          Finset.mem_sdiff.mpr ⟨hx, hxW⟩
        exact Finset.mem_union_left _ this

/-! ## Step 2: lex-minimization. -/

/-- The Finset of *all* candidate tuples `T : Fin s → Finset X`. Since
`X` is a `Fintype`, this is `Finset.univ` of a finite type. -/
noncomputable def allTuples (s : ℕ) : Finset (Fin s → Finset X) :=
  (Finset.univ : Finset (Fin s → Finset X))

/-- The Finset of towers of fragments. -/
noncomputable def towerSet
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (W : Fin s → Finset X) (H : Finset X) (hH : H ∈ ℋ) :
    Finset (Fin s → Finset X) :=
  (allTuples s).filter (fun T => IsTowerOfFragments ℋ s lambda_vec W H hH T)

/-- The trivial tower belongs to `towerSet`. -/
lemma trivialTower_mem_towerSet
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (W : Fin s → Finset X) (H : Finset X) (hH : H ∈ ℋ) :
    trivialTower W H (lambda_vec H hH) ∈
      towerSet ℋ s lambda_vec W H hH := by
  unfold towerSet allTuples
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
  exact trivialTower_isTower ℋ s lambda_vec W H hH

/-- The Finset of towers is non-empty. -/
lemma towerSet_nonempty
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (W : Fin s → Finset X) (H : Finset X) (hH : H ∈ ℋ) :
    (towerSet ℋ s lambda_vec W H hH).Nonempty :=
  ⟨trivialTower W H (lambda_vec H hH),
   trivialTower_mem_towerSet ℋ s lambda_vec W H hH⟩

/-- The card-vector of a tuple, viewed as `Lex (Fin s → ℕ)` (so we can
linearly order it lexicographically). -/
noncomputable def cardVec {s : ℕ} (T : Fin s → Finset X) : Lex (Fin s → ℕ) :=
  toLex (fun i => (T i).card)

/-- **Existence of a minimum tower of fragments** (paper §3.2, Lemma
between Definition 3.4 and Lemma 3.5).

For every `H ∈ ℋ` and `W : Fin s → Finset X`, there exists a tower of
fragments `T` of `(W, H)` whose card-vector `(|T_1|, …, |T_s|)` is
minimal in the lexicographic order on `Fin s → ℕ` among all towers of
fragments of `(W, H)`.

The proof:

* Step 1: by `trivialTower_isTower`, `T_i := R_at(W,H) i \ W_i` is a
  tower of fragments, so the Finset of all towers is non-empty.

* Step 2: apply `Finset.exists_min_image` to that Finset with
  `f := cardVec` and the (noncomputable) linear order `Lex.linearOrder`
  on `Lex (Fin s → ℕ)` (which is itself well-founded, since it is the
  lex order on a finite product of a well-founded order on `ℕ`).

This eliminates the need for an axiom asserting the existence of a
minimum tower — the only remaining ingredient (delegated to other
lemmas / axioms) is *Lemma 3.5* applied to the minimum tower, which is
the actual content of `fragment_contain`.
-/
theorem minimum_tower_exists
    (ℋ : Set (Finset X)) (s : ℕ)
    (lambda_vec : (H : Finset X) → H ∈ ℋ → X → ℝ)
    (W : Fin s → Finset X) (H : Finset X) (hH : H ∈ ℋ) :
    ∃ T : Fin s → Finset X,
      IsTowerOfFragments ℋ s lambda_vec W H hH T ∧
      ∀ T' : Fin s → Finset X,
        IsTowerOfFragments ℋ s lambda_vec W H hH T' →
        cardVec (X := X) T ≤ cardVec (X := X) T' := by
  -- Apply `Finset.exists_min_image` to the (non-empty) tower Finset.
  obtain ⟨T, hT_mem, hT_min⟩ :=
    Finset.exists_min_image
      (towerSet ℋ s lambda_vec W H hH)
      (fun T => cardVec (X := X) T)
      (towerSet_nonempty ℋ s lambda_vec W H hH)
  -- Unpack membership.
  have hT_isTower : IsTowerOfFragments ℋ s lambda_vec W H hH T := by
    have := (Finset.mem_filter.mp hT_mem).2
    exact this
  refine ⟨T, hT_isTower, ?_⟩
  intro T' hT'
  -- T' belongs to towerSet because it satisfies the predicate.
  have hT'_mem : T' ∈ towerSet ℋ s lambda_vec W H hH := by
    unfold towerSet allTuples
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hT'⟩
  exact hT_min T' hT'_mem

end Workspace.Lemmas.MinimumTowerExists
