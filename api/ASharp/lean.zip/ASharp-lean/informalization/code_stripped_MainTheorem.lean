-- Pulls in the entire Mathlib library; gives access to `Finset`, `Real.log`,
-- `Fintype`, big operators (`∑`), powerset, etc.
import Mathlib

-- Brings names from the `Finset` namespace into scope, so we can write
-- `powerset`, `card`, etc. without the `Finset.` prefix.
open Finset

/- ============================================================
   FRACTIONAL COVER
   A fractional cover of a family ℋ ⊆ 2^X is a weight function
   w : 2^X → [0,1] such that for every H ∈ ℋ the weights of the
   subsets of H sum to at least 1.
   ============================================================ -/
namespace Workspace.Types.FractionalCover

-- `X` is the (finite, with decidable equality) ground set.
-- `ℋ : Set (Finset X)` is the family of subsets of `X` we want to cover.
-- A `FractionalCover X ℋ` bundles the weight function with its three axioms.
structure FractionalCover (X : Type*) [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) where

  -- The weight function w : 2^X → ℝ. (Subsets of `X` are `Finset X` here.)
  w        : Finset X → ℝ

  -- Non-negativity: every weight is ≥ 0.
  nonneg   : ∀ W : Finset X, 0 ≤ w W

  -- Upper bound: every weight is ≤ 1, so w lands in [0,1].
  le_one   : ∀ W : Finset X, w W ≤ 1

  -- Cover condition: for every H in the family ℋ, the total weight
  -- placed on the subsets of H is at least 1.
  -- `H.powerset` is the finset of all subsets of `H`, so the sum
  -- `∑ W ∈ H.powerset, w W` equals ∑_{W ⊆ H} w(W).
  is_cover : ∀ H ∈ ℋ, (1 : ℝ) ≤ ∑ W ∈ H.powerset, w W

end Workspace.Types.FractionalCover

/- ============================================================
   INTEGRAL COVER
   An integral cover of ℋ is a {0,1}-valued function g : 2^X → {0,1}
   such that every H ∈ ℋ contains some W ⊆ H with g(W) = 1.
   (Equivalently, ∑_{W ⊆ H} g(W) ≥ 1, since g is {0,1}-valued.)
   ============================================================ -/
namespace Workspace.Types.IntegralCover

-- Same setting: finite ground set `X` and family `ℋ ⊆ 2^X`.
structure IntegralCover (X : Type*) [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) where

  -- The {0,1}-valued indicator function on subsets of `X`.
  -- We use `Bool` (true / false) as the {0,1} carrier.
  g        : Finset X → Bool

  -- Cover condition (existence form): for every H ∈ ℋ there exists
  -- some subset W ⊆ H that g picks (g W = true).
  -- Because `g` is {0,1}-valued, this is equivalent to ∑_{W ⊆ H} g(W) ≥ 1.
  is_cover : ∀ H ∈ ℋ, ∃ W : Finset X, W ⊆ H ∧ g W = true

end Workspace.Types.IntegralCover

/- ============================================================
   p-SMALLNESS
   ℋ is p-small if it has an integral cover g whose weighted
   "size" ∑_{W ∈ 2^X} g(W) · p^|W| is at most 1/2.
   ============================================================ -/
namespace Workspace.Types.IsPSmall

-- Brings `IntegralCover` into scope unqualified.
open Workspace.Types.IntegralCover

-- `IsPSmall ℋ p` is a Prop: it asserts that the family ℋ admits an
-- integral cover g such that the weighted sum
--    ∑_{W ∈ 2^X} g(W) · p^|W|     ≤   1/2.
def IsPSmall {X : Type*} [Fintype X] [DecidableEq X]
    (ℋ : Set (Finset X)) (p : ℝ) : Prop :=
  -- "There exists an integral cover g of ℋ ..."
  ∃ g : IntegralCover X ℋ,
    -- "... such that the LP-objective sum is at most 1/2."
    -- The factor `(if g.g W then 1 else 0)` converts the Bool
    -- indicator g.g into a real number 0/1.
    -- `W.card` is |W|; `p ^ W.card` is p^|W|.
    -- The sum ranges over **all** W : Finset X (the full power set 2^X),
    -- matching the LP-objective definition of c_int(ℋ; p).
    (∑ W : Finset X, (if g.g W then (1:ℝ) else 0) * p ^ W.card) ≤ 1/2

end Workspace.Types.IsPSmall

/- ============================================================
   MAIN THEOREM (Theorem 1.1, arXiv:2412.03540)
   A fractional cover w with weighted-mass ≤ 1/2 at probability p,
   supported on sets of size ≤ t, can be "rounded" to an integral
   cover with weighted-mass ≤ 1/2 at probability q = c·p / log t,
   for some absolute constant c > 0.
   ============================================================ -/
namespace Workspace.MainTheorem

-- Bring the three building blocks into unqualified scope.
open Workspace.Types.FractionalCover
open Workspace.Types.IntegralCover
open Workspace.Types.IsPSmall

-- The main theorem statement. Body is `sorry` (no proof here).
theorem main_theorem :
    -- "There exists an absolute constant c > 0 ..."
    -- (`c` does not depend on X, ℋ, t, or p — it is bound outside the ∀.)
    ∃ c : ℝ, 0 < c ∧
      -- "... such that for every finite set X (with decidable equality),
      -- every integer t, every real p, every family ℋ ⊆ 2^X,
      -- and every fractional cover `cov` of ℋ ..."
      ∀ {X : Type} [Fintype X] [DecidableEq X]
        (t : ℕ) (p : ℝ) (ℋ : Set (Finset X))
        (cov : FractionalCover X ℋ),
        -- Hypothesis: t ≥ 2 (ensures log t > 0, so the bound q = c·p/log t
        -- is well-defined and positive).
        2 ≤ t →
        -- Hypothesis: 0 < p ≤ 1 (p is a probability in (0,1]).
        0 < p → p ≤ 1 →
        -- Hypothesis: w is supported on sets of size at most t,
        -- i.e. w(W) = 0 whenever |W| > t.
        (∀ W : Finset X, t < W.card → cov.w W = 0) →
        -- Hypothesis: the fractional cover has weighted-mass ≤ 1/2 at
        -- probability p:    ∑_{W ∈ 2^X} w(W) · p^|W|  ≤  1/2.
        (∑ W : Finset X, cov.w W * p ^ W.card) ≤ (1 : ℝ) / 2 →
        -- Conclusion: ℋ is q-small with q = c · p / log t.
        -- `Real.log t` is the natural logarithm of t (as a real number).
        IsPSmall ℋ (c * p / Real.log t) := by
  -- The proof is omitted — the statement is what is being formalized.
  sorry

end Workspace.MainTheorem
