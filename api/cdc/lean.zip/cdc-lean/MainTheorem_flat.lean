import Mathlib

/-!
# The group `Γ = 𝔽₂³` and its dual `Γ*`

The group `Γ` of the paper: the `3`-dimensional vector space over the two-element field
`𝔽₂ = ZMod 2`, written additively, with `8` elements and characteristic two. `Γ*` is its dual
space of `𝔽₂`-linear maps `Γ → 𝔽₂`. Both are `abbrev`s over standard Mathlib objects
(`Γ := Fin 3 → ZMod 2`, `Γ* := Module.Dual (ZMod 2) Γ`), so Mathlib's linear-algebra API
applies directly; the basic numerical facts are recorded as lemmas.
-/

namespace Workspace.Types.Gamma

/-- The two-element field `𝔽₂`, realised as `ZMod 2`. -/
abbrev F2 : Type := ZMod 2

/-- The group `Γ = 𝔽₂³` of the paper: the `3`-dimensional vector space over the
two-element field, written additively.  It is a reducible abbreviation for
`Fin 3 → ZMod 2`, so all of Mathlib's linear-algebra API applies to it. -/
abbrev Gamma : Type := Fin 3 → F2

/-- The dual space `Γ*` of `Γ`: the `𝔽₂`-vector space of `𝔽₂`-linear maps
`Γ → 𝔽₂`. -/
abbrev GammaDual : Type := Module.Dual F2 Gamma

/-- `Γ*` is a finite type: a linear map is determined by its underlying
function, and there are only finitely many functions `Γ → 𝔽₂`. -/
instance : Finite GammaDual :=
  Finite.of_injective (fun f : GammaDual => (f : Gamma → F2)) DFunLike.coe_injective

namespace Gamma

/-- `Γ` has exactly `8` elements. -/
theorem card_eq : Fintype.card Gamma = 8 := by
  simp [Gamma, F2]

/-- `Γ` has characteristic two: every element is its own additive inverse. -/
theorem add_self (a : Gamma) : a + a = 0 := by
  funext i
  exact CharTwo.add_self_eq_zero (a i)

/-- `Γ` is `3`-dimensional over `𝔽₂`. -/
theorem finrank_eq : Module.finrank F2 Gamma = 3 := by
  simp [Gamma, F2]

/-- The dual `Γ*` is `3`-dimensional over `𝔽₂`. -/
theorem finrank_dual_eq : Module.finrank F2 GammaDual = 3 := by
  rw [Subspace.dual_finrank_eq, finrank_eq]

/-- `Γ*` has exactly `8` elements. -/
theorem card_dual_eq : Nat.card GammaDual = 8 := by
  have : Fintype GammaDual := Fintype.ofFinite _
  rw [Nat.card_eq_fintype_card, Module.card_eq_pow_finrank (K := F2), finrank_dual_eq]
  simp

end Gamma

end Workspace.Types.Gamma

/-!
# Basic vertex-degree invariants of a multigraph

Elementary degree theory for Mathlib's multigraph type `Graph α β` (parallel edges and
loops allowed). The **degree** of a vertex `v` counts edge-ends at `v`: a non-loop edge
incident to `v` contributes one end, a loop at `v` contributes two. On top of `degree`
we define the predicates `IsLoopless`, `IsCubic` (3-regular) and `IsTwoRegular`.
-/

open Set

open scoped Graph

namespace Graph

variable {α β : Type*} {G : Graph α β} {e : β} {u v : α}

/-! ## Degree -/

/-- The **degree** of a vertex `v` of a multigraph `G`: the number of edge-ends at `v`.
A non-loop edge incident to `v` contributes one end; a loop at `v` contributes two. -/
noncomputable def degree (G : Graph α β) (v : α) : ℕ :=
  (G.incidenceSet v).ncard + (G.loopSet v).ncard

lemma degree_def (G : Graph α β) (v : α) :
    G.degree v = (G.incidenceSet v).ncard + (G.loopSet v).ncard := rfl

/-- The set of non-loop edges at `v`: the edges contributing exactly one end at `v`. -/
def nonloopSet (G : Graph α β) (v : α) : Set β := {e | G.IsNonloopAt e v}

@[simp]
lemma mem_nonloopSet : e ∈ G.nonloopSet v ↔ G.IsNonloopAt e v := Iff.rfl

lemma nonloopSet_subset_incidenceSet (G : Graph α β) (v : α) :
    G.nonloopSet v ⊆ G.incidenceSet v := fun _ he ↦ he.inc

/-- The edges incident to `v` split into the non-loops at `v` and the loops at `v`. -/
lemma nonloopSet_union_loopSet (G : Graph α β) (v : α) :
    G.nonloopSet v ∪ G.loopSet v = G.incidenceSet v := by
  ext e
  simp only [Set.mem_union, Graph.mem_nonloopSet, Graph.mem_loopSet, Graph.mem_incidenceSet]
  exact ⟨fun h ↦ h.elim Graph.IsNonloopAt.inc Graph.IsLoopAt.inc,
    fun h ↦ h.isLoopAt_or_isNonloopAt.symm⟩

lemma disjoint_nonloopSet_loopSet (G : Graph α β) (v : α) :
    Disjoint (G.nonloopSet v) (G.loopSet v) := by
  rw [Set.disjoint_left]
  exact fun e he he' ↦ he.not_isLoopAt v he'

/-- Each loop at `v` counts twice in the degree; each non-loop edge incident to `v` counts once. -/
lemma degree_eq_ncard_nonloopSet_add_two_mul_ncard_loopSet
    (hfin : (G.incidenceSet v).Finite) :
    G.degree v = (G.nonloopSet v).ncard + 2 * (G.loopSet v).ncard := by
  have hn : (G.nonloopSet v).Finite := hfin.subset (G.nonloopSet_subset_incidenceSet v)
  have hl : (G.loopSet v).Finite := hfin.subset (G.loopSet_subset_incidenceSet v)
  have hsplit : (G.incidenceSet v).ncard = (G.nonloopSet v).ncard + (G.loopSet v).ncard := by
    rw [← G.nonloopSet_union_loopSet v, Set.ncard_union_eq (G.disjoint_nonloopSet_loopSet v) hn hl]
  rw [Graph.degree_def, hsplit]
  omega

/-- A vertex outside the graph has no incident edges. -/
lemma incidenceSet_eq_empty_of_notMem (hv : v ∉ V(G)) : G.incidenceSet v = ∅ := by
  ext e
  simp only [Graph.mem_incidenceSet, Set.mem_empty_iff_false, iff_false]
  exact fun h ↦ hv h.vertex_mem

lemma loopSet_eq_empty_of_notMem (hv : v ∉ V(G)) : G.loopSet v = ∅ :=
  Set.subset_empty_iff.1 <|
    (G.loopSet_subset_incidenceSet v).trans (Graph.incidenceSet_eq_empty_of_notMem hv).subset

lemma degree_eq_zero_of_notMem (hv : v ∉ V(G)) : G.degree v = 0 := by
  simp [Graph.degree_def, Graph.incidenceSet_eq_empty_of_notMem hv,
    Graph.loopSet_eq_empty_of_notMem hv]

/-! ## Looplessness -/

/-- A multigraph is **loopless** if it has no loop at all. -/
def IsLoopless (G : Graph α β) : Prop := ∀ e x, ¬ G.IsLoopAt e x

lemma IsLoopless.loopSet_eq_empty (h : G.IsLoopless) (v : α) : G.loopSet v = ∅ := by
  ext e
  simpa using h e v

/-- In a loopless graph the degree of `v` is the number of edges incident to `v`. -/
lemma IsLoopless.degree_eq_ncard_incidenceSet (h : G.IsLoopless) (v : α) :
    G.degree v = (G.incidenceSet v).ncard := by
  simp [Graph.degree_def, h.loopSet_eq_empty v]

lemma IsLoopless.isNonloopAt_of_inc (h : G.IsLoopless) (hi : G.Inc e v) :
    G.IsNonloopAt e v :=
  hi.isLoopAt_or_isNonloopAt.resolve_left (h e v)

lemma isLoopless_iff_forall_isLink_ne :
    G.IsLoopless ↔ ∀ e x y, G.IsLink e x y → x ≠ y := by
  constructor
  · intro h e x y hl hxy
    subst hxy
    exact h e x hl
  · intro h e x hl
    exact h e x x hl rfl

/-! ## Regularity predicates -/

/-- A multigraph is **cubic** (3-regular) if every one of its vertices has degree `3`. -/
def IsCubic (G : Graph α β) : Prop := ∀ v ∈ V(G), G.degree v = 3

/-- A multigraph is **two-regular** if every one of its vertices has degree `2`.
With the loops-count-twice convention, a single loop and a pair of parallel edges are
both two-regular. -/
def IsTwoRegular (G : Graph α β) : Prop := ∀ v ∈ V(G), G.degree v = 2

lemma IsCubic.degree_eq (h : G.IsCubic) (hv : v ∈ V(G)) : G.degree v = 3 := h v hv

lemma IsTwoRegular.degree_eq (h : G.IsTwoRegular) (hv : v ∈ V(G)) :
    G.degree v = 2 := h v hv

/-! ## Basic examples -/

@[simp]
lemma incidenceSet_banana_left (u v : α) (F : Set β) :
    (Graph.banana u v F).incidenceSet u = F := by
  ext e; simp

@[simp]
lemma incidenceSet_banana_right (u v : α) (F : Set β) :
    (Graph.banana u v F).incidenceSet v = F := by
  ext e; simp

lemma loopSet_banana_left_of_ne (h : u ≠ v) (F : Set β) :
    (Graph.banana u v F).loopSet u = ∅ := by
  ext e; simp [h]

/-- In a `banana` on two distinct vertices, each endpoint has degree equal to the number
of edges. In particular two parallel edges give both endpoints degree `2`. -/
lemma degree_banana_left_of_ne (h : u ≠ v) (F : Set β) :
    (Graph.banana u v F).degree u = F.ncard := by
  simp [Graph.degree_def, Graph.loopSet_banana_left_of_ne h]

/-- The single vertex of a `bouquet` has degree twice the number of loops. In particular a
single loop gives degree `2`. -/
lemma degree_bouquet (v : α) (F : Set β) :
    (Graph.bouquet v F).degree v = 2 * F.ncard := by
  have hl : (Graph.bouquet v F).loopSet v = F := by ext e; simp
  rw [Graph.degree_def, hl, Graph.incidenceSet_banana_left, two_mul]

end Graph

/-!
# Connectivity for multigraphs

Reachability and connectedness for Mathlib's multigraph type `Graph α β` (parallel edges
and loops allowed).

* `Graph.Reachable G x y` — `x` and `y` are joined by a walk in `G`, i.e. the
  reflexive-transitive closure of the adjacency relation `Graph.Adj`.
* `Graph.Connected G` — `G` has at least one vertex, and any two of its vertices are
  reachable from each other.
-/

open Set

open scoped Graph

namespace Graph

variable {α β : Type*} {G H : Graph α β} {x y z : α}

/-- `G.Reachable x y` means that `x` and `y` are joined by a walk in the multigraph `G`;
equivalently, the reflexive-transitive closure of `G.Adj`. Note that `G.Reachable x x`
holds for every `x : α`, even for `x ∉ V(G)`. -/
def Reachable (G : Graph α β) (x y : α) : Prop :=
  Relation.ReflTransGen G.Adj x y

/-- `G.Connected` means the multigraph `G` has at least one vertex and every two of its
vertices are reachable from each other. The nonemptiness requirement rules out the empty
graph. -/
def Connected (G : Graph α β) : Prop :=
  V(G).Nonempty ∧ ∀ x ∈ V(G), ∀ y ∈ V(G), G.Reachable x y

/-! ### Basic API for `Graph.Reachable` -/

theorem reachable_def : G.Reachable x y ↔ Relation.ReflTransGen G.Adj x y := Iff.rfl

/-- Reachability is reflexive. -/
@[refl]
protected theorem Reachable.refl (G : Graph α β) (x : α) : G.Reachable x x :=
  Relation.ReflTransGen.refl

protected theorem Reachable.rfl : G.Reachable x x :=
  Relation.ReflTransGen.refl

/-- Adjacent vertices are reachable from one another. -/
theorem Adj.reachable (h : G.Adj x y) : G.Reachable x y :=
  Relation.ReflTransGen.single h

/-- If `e` is an edge of `G` with ends `x` and `y`, then `x` and `y` are reachable. -/
theorem IsLink.reachable {e : β} (h : G.IsLink e x y) : G.Reachable x y :=
  (Graph.Adj.reachable ⟨e, h⟩)

/-- Reachability is symmetric. -/
@[symm]
protected theorem Reachable.symm (h : G.Reachable x y) : G.Reachable y x :=
  Relation.ReflTransGen.symmetric (fun _ _ hxy => hxy.symm) h

theorem reachable_comm : G.Reachable x y ↔ G.Reachable y x :=
  ⟨Graph.Reachable.symm, Graph.Reachable.symm⟩

/-- Reachability is transitive. -/
@[trans]
protected theorem Reachable.trans (hxy : G.Reachable x y) (hyz : G.Reachable y z) :
    G.Reachable x z :=
  Relation.ReflTransGen.trans hxy hyz

/-- Prepend an adjacency to a walk. -/
theorem Reachable.head (hxy : G.Adj x y) (hyz : G.Reachable y z) : G.Reachable x z :=
  Relation.ReflTransGen.head hxy hyz

/-- Append an adjacency to a walk. -/
theorem Reachable.tail (hxy : G.Reachable x y) (hyz : G.Adj y z) : G.Reachable x z :=
  Relation.ReflTransGen.tail hxy hyz

/-- Reachability is monotone in the graph: a walk in a subgraph is a walk in the
ambient graph. -/
protected theorem Reachable.mono (hHG : H ≤ G) (h : H.Reachable x y) :
    G.Reachable x y :=
  Relation.ReflTransGen.mono (fun _ _ hxy => hxy.mono hHG) h

/-- Reachability is an equivalence relation on the ambient vertex type `α`. -/
theorem reachable_equivalence (G : Graph α β) : Equivalence G.Reachable :=
  ⟨fun x => Graph.Reachable.refl G x, Graph.Reachable.symm, Graph.Reachable.trans⟩

/-- A vertex reachable from `x` by a *nontrivial* walk certifies that `x ∈ V(G)`. -/
theorem Reachable.left_mem_of_ne (h : G.Reachable x y) (hne : x ≠ y) : x ∈ V(G) := by
  obtain (rfl | ⟨c, hac, -⟩) := h.cases_head
  · exact absurd rfl hne
  · exact hac.left_mem

theorem Reachable.right_mem_of_ne (h : G.Reachable x y) (hne : x ≠ y) : y ∈ V(G) :=
  h.symm.left_mem_of_ne hne.symm

/-! ### Basic API for `Graph.Connected` -/

theorem connected_def :
    G.Connected ↔ V(G).Nonempty ∧ ∀ x ∈ V(G), ∀ y ∈ V(G), G.Reachable x y := Iff.rfl

/-- A connected graph has a vertex. -/
theorem Connected.nonempty (h : G.Connected) : V(G).Nonempty := h.1

/-- Any two vertices of a connected graph are reachable from each other. -/
theorem Connected.reachable (h : G.Connected) (hx : x ∈ V(G)) (hy : y ∈ V(G)) :
    G.Reachable x y :=
  h.2 x hx y hy

/-- To prove a graph connected it suffices to exhibit a vertex of `G` from which every
vertex of `G` is reachable. -/
theorem connected_of_forall_reachable (hx : x ∈ V(G))
    (h : ∀ y ∈ V(G), G.Reachable x y) : G.Connected :=
  ⟨⟨x, hx⟩, fun _ ha _ hb => (h _ ha).symm.trans (h _ hb)⟩

end Graph

/-!
# Bridges of a multigraph

An edge `e` of a multigraph `G : Graph α β` is a **bridge** (a cut edge) when deleting it —
keeping all vertices — disconnects its two ends. `G` is **bridgeless** when none of its
edges is a bridge.

* `Graph.IsBridge G e` — `∃ x y, G.IsLink e x y ∧ ¬ (G.deleteEdges {e}).Reachable x y`.
* `Graph.Bridgeless G` — `∀ e ∈ E(G), ¬ G.IsBridge e`.
-/

open Set

open scoped Graph

namespace Graph

variable {α β : Type*} {G H : Graph α β} {e f : β} {x y : α}

/-- `G.IsBridge e` means that `e` is an edge of `G` whose ends lie in different components
of `G - e`, the multigraph obtained by deleting `e` and keeping every vertex. -/
def IsBridge (G : Graph α β) (e : β) : Prop :=
  ∃ x y, G.IsLink e x y ∧ ¬ (G.deleteEdges {e}).Reachable x y

/-- `G.Bridgeless` means that no edge of `G` is a bridge. -/
def Bridgeless (G : Graph α β) : Prop :=
  ∀ e ∈ E(G), ¬ G.IsBridge e

/-! ### Basic API -/

theorem isBridge_def :
    G.IsBridge e ↔ ∃ x y, G.IsLink e x y ∧ ¬ (G.deleteEdges {e}).Reachable x y := Iff.rfl

theorem bridgeless_def : G.Bridgeless ↔ ∀ e ∈ E(G), ¬ G.IsBridge e := Iff.rfl

/-- A bridge is an edge. -/
theorem IsBridge.edge_mem (h : G.IsBridge e) : e ∈ E(G) := by
  obtain ⟨x, y, hxy, -⟩ := h
  exact hxy.edge_mem

/-- The ends of a bridge are separated in `G - e`, for either ordering of the ends. -/
theorem IsBridge.not_reachable (h : G.IsBridge e) (hxy : G.IsLink e x y) :
    ¬ (G.deleteEdges {e}).Reachable x y := by
  obtain ⟨a, b, hab, hr⟩ := h
  obtain ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ := hab.eq_and_eq_or_eq_and_eq hxy
  · exact hr
  · exact fun hc => hr hc.symm

/-- The existential and universal formulations of `IsBridge` agree. -/
theorem isBridge_iff_forall :
    G.IsBridge e ↔ e ∈ E(G) ∧ ∀ x y, G.IsLink e x y → ¬ (G.deleteEdges {e}).Reachable x y := by
  refine ⟨fun h => ⟨h.edge_mem, fun _ _ hxy => h.not_reachable hxy⟩, fun ⟨he, h⟩ => ?_⟩
  obtain ⟨x, y, hxy⟩ := Graph.exists_isLink_of_mem_edgeSet he
  exact ⟨x, y, hxy, h x y hxy⟩

/-- The ends of a bridge are distinct; equivalently, a bridge is not a loop. -/
theorem IsBridge.ne_of_isLink (h : G.IsBridge e) (hxy : G.IsLink e x y) : x ≠ y := by
  rintro rfl
  exact h.not_reachable hxy Graph.Reachable.rfl

/-- A loop is never a bridge: deleting it leaves its (unique) end reachable from itself. -/
theorem IsLoopAt.not_isBridge (h : G.IsLoopAt e x) : ¬ G.IsBridge e :=
  fun hb => hb.ne_of_isLink h rfl

/-- A bridge is a nonloop edge at each of its ends. -/
theorem IsBridge.isNonloopAt (h : G.IsBridge e) (hxy : G.IsLink e x y) :
    G.IsNonloopAt e x :=
  ⟨y, (h.ne_of_isLink hxy).symm, hxy⟩

/-- To show a graph bridgeless it suffices to reconnect the ends of every edge after
deleting it. -/
theorem bridgeless_of_forall_reachable
    (h : ∀ e ∈ E(G), ∀ x y, G.IsLink e x y → (G.deleteEdges {e}).Reachable x y) :
    G.Bridgeless :=
  fun e he hb => (hb.not_reachable (Graph.exists_isLink_of_mem_edgeSet he).choose_spec.choose_spec)
    (h e he _ _ (Graph.exists_isLink_of_mem_edgeSet he).choose_spec.choose_spec)

/-- A bridgeless graph has no bridges at all. -/
theorem Bridgeless.not_isBridge (h : G.Bridgeless) (e : β) : ¬ G.IsBridge e :=
  fun hb => h e hb.edge_mem hb

/-! ### Sanity checks -/

/-- A loop is never a bridge. -/
example (v : α) (e : β) : ¬ (Graph.bouquet v ({e} : Set β)).IsBridge e := by
  refine Graph.IsLoopAt.not_isBridge (x := v) ?_
  simp [Graph.bouquet]

/-- Neither of two parallel edges is a bridge: deleting one leaves the other joining the
same pair of vertices. -/
example (u v : α) (e₁ e₂ : β) (_huv : u ≠ v) (he : e₁ ≠ e₂) :
    ¬ (Graph.banana u v ({e₁, e₂} : Set β)).IsBridge e₁ := by
  set G : Graph α β := Graph.banana u v ({e₁, e₂} : Set β) with hG
  intro hb
  have h₂ : (G.deleteEdges {e₁}).IsLink e₂ u v := by
    simp [hG, Graph.deleteEdges_isLink, Ne.symm he]
  exact hb.not_reachable (x := u) (y := v) (by simp [hG]) h₂.reachable

/-- A lone cut edge is a bridge. -/
example (u v : α) (e : β) (huv : u ≠ v) : (Graph.banana u v ({e} : Set β)).IsBridge e := by
  set G : Graph α β := Graph.banana u v ({e} : Set β) with hG
  refine ⟨u, v, by simp [hG], fun hr => huv ?_⟩
  have hadj : ∀ b, ¬ (G.deleteEdges ({e} : Set β)).Adj u b := by
    rintro b ⟨f, hf⟩
    rw [Graph.deleteEdges_isLink, hG] at hf
    simp at hf
    exact hf.2 hf.1.1
  rw [Graph.reachable_def, Relation.reflTransGen_iff_eq hadj] at hr
  exact hr.symm

end Graph

/-!
# Cycles of a multigraph

A **cycle** of a multigraph `G : Graph α β` is a subgraph `C ≤ G` that is connected and in
which every vertex has degree exactly `2` (computed inside `C`, with the multigraph
convention that a loop contributes two edge-ends). Because Mathlib's `Graph α β` uses the
embedded-set design, a subgraph is again a `Graph α β`, so a cycle is a graph, not a walk.

With this convention a single loop is a cycle and a pair of parallel edges is a cycle, while
a single non-loop edge and an isolated vertex are not; the empty graph is excluded via the
`V(C).Nonempty` conjunct hidden in `Graph.Connected`.

* `Graph.IsCycle G C` — `C ≤ G ∧ C.Connected ∧ C.IsTwoRegular`.
-/

open Set

open scoped Graph

variable {α β : Type*} {G H C : Graph α β} {e e₁ e₂ : β} {u v : α}

namespace Graph

/-! ## The definition -/

/-- `G.IsCycle C` means the multigraph `C` is a **cycle of `G`**: a subgraph of `G` that is
connected and every one of whose vertices has degree exactly `2` in `C`. Consequently a
single loop is a cycle, and so is a pair of parallel edges. -/
def IsCycle (G C : Graph α β) : Prop :=
  C ≤ G ∧ C.Connected ∧ C.IsTwoRegular

/-- The definition of `Graph.IsCycle`, with `Graph.IsTwoRegular` spelled out. -/
theorem isCycle_def :
    G.IsCycle C ↔ C ≤ G ∧ C.Connected ∧ ∀ v ∈ V(C), C.degree v = 2 := Iff.rfl

theorem IsCycle.mk (hle : C ≤ G) (hconn : C.Connected)
    (hdeg : ∀ v ∈ V(C), C.degree v = 2) : G.IsCycle C := ⟨hle, hconn, hdeg⟩

/-! ## Basic API -/

/-- A cycle of `G` is a subgraph of `G`. -/
theorem IsCycle.le (h : G.IsCycle C) : C ≤ G := h.1

/-- A cycle is connected. -/
theorem IsCycle.connected (h : G.IsCycle C) : C.Connected := h.2.1

/-- A cycle is two-regular. -/
theorem IsCycle.isTwoRegular (h : G.IsCycle C) : C.IsTwoRegular := h.2.2

/-- Every vertex of a cycle has degree `2` in the cycle. -/
theorem IsCycle.degree_eq (h : G.IsCycle C) (hv : v ∈ V(C)) : C.degree v = 2 :=
  h.2.2 v hv

/-- A cycle has at least one vertex; in particular the empty graph is never a cycle. -/
theorem IsCycle.vertexSet_nonempty (h : G.IsCycle C) : V(C).Nonempty :=
  h.connected.nonempty

/-- A cycle has at least one edge. -/
theorem IsCycle.edgeSet_nonempty (h : G.IsCycle C) : E(C).Nonempty := by
  obtain ⟨v, hv⟩ := h.vertexSet_nonempty
  have hdeg : C.degree v = 2 := h.degree_eq hv
  have hne : (C.incidenceSet v).Nonempty := by
    rw [Set.nonempty_iff_ne_empty]
    intro hempty
    have hloop : C.loopSet v = ∅ :=
      Set.subset_empty_iff.1 <| (C.loopSet_subset_incidenceSet v).trans hempty.subset
    rw [Graph.degree_def, hempty, hloop] at hdeg
    simp at hdeg
  obtain ⟨e, he⟩ := hne
  exact ⟨e, ((C.mem_incidenceSet v e).1 he).edge_mem⟩

/-- Being a cycle is monotone in the ambient graph. -/
theorem IsCycle.mono (h : G.IsCycle C) (hGH : G ≤ H) : H.IsCycle C :=
  ⟨h.le.trans hGH, h.connected, h.isTwoRegular⟩

/-- A cycle of `G` is a cycle of itself. -/
theorem IsCycle.self (h : G.IsCycle C) : C.IsCycle C :=
  ⟨le_rfl, h.connected, h.isTwoRegular⟩

/-- Anything that is a cycle of itself and a subgraph of `G` is a cycle of `G`. -/
theorem IsCycle.of_self (h : C.IsCycle C) (hle : C ≤ G) : G.IsCycle C :=
  ⟨hle, h.connected, h.isTwoRegular⟩

end Graph

namespace Workspace.Types.Cycle

/-! ## Sanity checks against the intended conventions -/

/-- **A single loop is a cycle.** -/
theorem isCycle_bouquet_singleton (v : α) (e : β) :
    (Graph.bouquet v {e}).IsCycle (Graph.bouquet v ({e} : Set β)) := by
  refine ⟨le_rfl, ?_, ?_⟩
  · exact Graph.connected_of_forall_reachable (x := v) (by simp) <| by
      intro y hy
      simp only [Graph.vertexSet_bouquet, Set.mem_singleton_iff] at hy
      subst hy
      exact Graph.Reachable.rfl
  · intro x hx
    simp only [Graph.vertexSet_bouquet, Set.mem_singleton_iff] at hx
    subst hx
    rw [Graph.degree_bouquet, Set.ncard_singleton]

end Workspace.Types.Cycle

/-!
# Cycle double covers

The paper's central object: a **cycle double cover** of a graph is a multiset of cycles in
which every edge occurs exactly twice.

* `Multiset.edgeMultiplicity D e` — the number of members of `D`, counted with multiplicity,
  whose edge set contains `e`.
* `Graph.IsCycleDoubleCover G D` — every member of `D` is a cycle of `G`, and every edge of
  `G` has multiplicity exactly `2` in `D`.
* `Graph.HasCycleDoubleCover G` — `∃ D, G.IsCycleDoubleCover D`; the conclusion of the main
  theorem.

A `Multiset` (not a `Set`) is essential: the same cycle may legitimately be used twice.
-/

open Set

open scoped Graph

variable {α β : Type*} {G C : Graph α β} {D : Multiset (Graph α β)} {e : β} {u v : α}

namespace Multiset

/-! ## Counting the members of a multiset of graphs that use a given edge -/

open scoped Classical in
/-- `D.edgeMultiplicity e` is the number of graphs in the multiset `D`, counted with
multiplicity, whose edge set contains `e`. -/
noncomputable def edgeMultiplicity (D : Multiset (Graph α β)) (e : β) : ℕ :=
  D.countP (fun C ↦ e ∈ E(C))

open scoped Classical in
theorem edgeMultiplicity_def (D : Multiset (Graph α β)) (e : β) :
    D.edgeMultiplicity e = D.countP (fun C ↦ e ∈ E(C)) := by
  rw [Multiset.edgeMultiplicity]

@[simp]
theorem edgeMultiplicity_zero (e : β) :
    (0 : Multiset (Graph α β)).edgeMultiplicity e = 0 := by
  classical
  rw [Multiset.edgeMultiplicity_def, Multiset.countP_zero]

/-- Consing on a graph that uses `e` increases the multiplicity of `e` by one. -/
theorem edgeMultiplicity_cons_of_mem (D : Multiset (Graph α β))
    (h : e ∈ E(C)) : (C ::ₘ D).edgeMultiplicity e = D.edgeMultiplicity e + 1 := by
  classical
  rw [Multiset.edgeMultiplicity_def, Multiset.edgeMultiplicity_def,
    Multiset.countP_cons_of_pos (p := fun C ↦ e ∈ E(C)) D h]

/-- Consing on a graph that does not use `e` leaves the multiplicity of `e` unchanged. -/
theorem edgeMultiplicity_cons_of_notMem (D : Multiset (Graph α β))
    (h : e ∉ E(C)) : (C ::ₘ D).edgeMultiplicity e = D.edgeMultiplicity e := by
  classical
  rw [Multiset.edgeMultiplicity_def, Multiset.edgeMultiplicity_def,
    Multiset.countP_cons_of_neg (p := fun C ↦ e ∈ E(C)) D h]

/-- An edge has positive multiplicity exactly when some member of the multiset uses it. -/
theorem edgeMultiplicity_pos_iff :
    0 < D.edgeMultiplicity e ↔ ∃ C ∈ D, e ∈ E(C) := by
  classical
  rw [Multiset.edgeMultiplicity_def]
  exact Multiset.countP_pos

/-- An edge has multiplicity zero exactly when no member of the multiset uses it. -/
theorem edgeMultiplicity_eq_zero_iff :
    D.edgeMultiplicity e = 0 ↔ ∀ C ∈ D, e ∉ E(C) := by
  classical
  rw [Multiset.edgeMultiplicity_def]
  exact Multiset.countP_eq_zero

end Multiset

namespace Graph

/-! ## The definition -/

/-- `G.IsCycleDoubleCover D` means the multiset of graphs `D` is a **cycle double cover** of
`G`: every member of `D` is a cycle of `G`, and every edge of `G` occurs in exactly two
members of `D`, counted with multiplicity. -/
def IsCycleDoubleCover (G : Graph α β) (D : Multiset (Graph α β)) : Prop :=
  (∀ C ∈ D, G.IsCycle C) ∧ ∀ e ∈ E(G), D.edgeMultiplicity e = 2

theorem isCycleDoubleCover_def :
    G.IsCycleDoubleCover D ↔
      (∀ C ∈ D, G.IsCycle C) ∧ ∀ e ∈ E(G), D.edgeMultiplicity e = 2 := Iff.rfl

theorem IsCycleDoubleCover.mk (hcyc : ∀ C ∈ D, G.IsCycle C)
    (hcount : ∀ e ∈ E(G), D.edgeMultiplicity e = 2) : G.IsCycleDoubleCover D := ⟨hcyc, hcount⟩

/-- `G` **has a cycle double cover** if some multiset of graphs is a cycle double cover of
`G`. This is the conclusion of the cycle double cover theorem. -/
def HasCycleDoubleCover (G : Graph α β) : Prop :=
  ∃ D : Multiset (Graph α β), G.IsCycleDoubleCover D

theorem IsCycleDoubleCover.hasCycleDoubleCover (h : G.IsCycleDoubleCover D) :
    G.HasCycleDoubleCover := ⟨D, h⟩

theorem hasCycleDoubleCover_def :
    G.HasCycleDoubleCover ↔ ∃ D : Multiset (Graph α β), G.IsCycleDoubleCover D := Iff.rfl

/-! ## Basic API -/

/-- Every member of a cycle double cover of `G` is a cycle of `G`. -/
theorem IsCycleDoubleCover.isCycle_of_mem (h : G.IsCycleDoubleCover D)
    (hC : C ∈ D) : G.IsCycle C := h.1 C hC

/-- Every edge of `G` occurs exactly twice in a cycle double cover of `G`. -/
theorem IsCycleDoubleCover.edgeMultiplicity_eq (h : G.IsCycleDoubleCover D)
    (he : e ∈ E(G)) : D.edgeMultiplicity e = 2 := h.2 e he

/-- Every member of a cycle double cover of `G` is a subgraph of `G`. -/
theorem IsCycleDoubleCover.le_of_mem (h : G.IsCycleDoubleCover D) (hC : C ∈ D) :
    C ≤ G := (h.isCycle_of_mem hC).le

/-- No member of a cycle double cover of `G` uses an edge outside `E(G)`. -/
theorem IsCycleDoubleCover.edgeSet_subset_of_mem (h : G.IsCycleDoubleCover D)
    (hC : C ∈ D) : E(C) ⊆ E(G) :=
  Graph.IsSubgraph.edgeSet_mono (h.le_of_mem hC)

/-- Every edge of `G` is used by at least one member of a cycle double cover. -/
theorem IsCycleDoubleCover.exists_mem_of_mem_edgeSet (h : G.IsCycleDoubleCover D)
    (he : e ∈ E(G)) : ∃ C ∈ D, e ∈ E(C) := by
  refine Multiset.edgeMultiplicity_pos_iff.1 ?_
  rw [h.edgeMultiplicity_eq he]
  norm_num

/-- Every edge of `G` lies on a cycle of `G`, if `G` has a cycle double cover. -/
theorem IsCycleDoubleCover.exists_isCycle_mem_edgeSet (h : G.IsCycleDoubleCover D)
    (he : e ∈ E(G)) : ∃ C, G.IsCycle C ∧ e ∈ E(C) := by
  obtain ⟨C, hCD, heC⟩ := h.exists_mem_of_mem_edgeSet he
  exact ⟨C, h.isCycle_of_mem hCD, heC⟩

/-- **The obstruction lemma.** If some edge of `G` lies on no cycle of `G`, then `G` has no
cycle double cover. This is what rules out bridges. -/
theorem not_hasCycleDoubleCover_of_forall_isCycle_notMem (he : e ∈ E(G))
    (h : ∀ C, G.IsCycle C → e ∉ E(C)) : ¬ G.HasCycleDoubleCover := by
  rintro ⟨D, hD⟩
  obtain ⟨C, hC, heC⟩ := hD.exists_isCycle_mem_edgeSet he
  exact h C hC heC

/-- The empty multiset is a cycle double cover of `G` exactly when `G` has no edges. -/
theorem isCycleDoubleCover_zero_iff :
    G.IsCycleDoubleCover 0 ↔ E(G) = ∅ := by
  constructor
  · intro h
    refine Set.eq_empty_iff_forall_notMem.2 fun e he ↦ ?_
    have := h.edgeMultiplicity_eq he
    rw [Multiset.edgeMultiplicity_zero] at this
    exact absurd this (by norm_num)
  · intro h
    refine ⟨fun C hC ↦ absurd hC (Multiset.notMem_zero C), fun e he ↦ ?_⟩
    rw [h] at he
    exact absurd he (Set.notMem_empty e)

end Graph

namespace Workspace.Types.CycleDoubleCover

/-! ## Sanity checks against the intended meaning -/

/-- **A cycle is doubly covered by itself taken twice.** If `G` is a cycle of itself, then
`{G, G}` — containing `G` with multiplicity `2` — is a cycle double cover of `G`. This is
exactly the statement that fails if one uses a `Set` of cycles instead of a multiset. -/
theorem isCycleDoubleCover_pair_self (h : G.IsCycle G) :
    G.IsCycleDoubleCover {G, G} := by
  have hpair : ({G, G} : Multiset (Graph α β)) = G ::ₘ G ::ₘ 0 := rfl
  refine ⟨fun C hC ↦ ?_, fun e he ↦ ?_⟩
  · rw [hpair] at hC
    simp only [Multiset.mem_cons, Multiset.notMem_zero, or_false] at hC
    obtain rfl | rfl := hC <;> exact h
  · rw [hpair, Multiset.edgeMultiplicity_cons_of_mem _ he,
      Multiset.edgeMultiplicity_cons_of_mem _ he, Multiset.edgeMultiplicity_zero]

/-- **No cycle of a single non-loop edge contains that edge**: its ends would have degree
`1`, not `2`. -/
theorem notMem_edgeSet_of_isCycle_banana_singleton (huv : u ≠ v) (e : β) (C : Graph α β)
    (hC : (Graph.banana u v ({e} : Set β)).IsCycle C) : e ∉ E(C) := by
  have key : ∀ (x y : α), x ≠ y → ∀ C : Graph α β, (Graph.banana x y ({e} : Set β)).IsCycle C →
      x ∉ V(C) := by
    intro x y hxy C hC hxC
    have hinc : C.incidenceSet x ⊆ ({e} : Set β) := by
      intro f hf
      have hb : (Graph.banana x y ({e} : Set β)).Inc f x :=
        Graph.Inc.mono hC.le ((C.mem_incidenceSet x f).1 hf)
      rw [Graph.banana_inc] at hb
      exact hb.1
    have hloop : C.loopSet x = ∅ := by
      refine Set.eq_empty_iff_forall_notMem.2 fun f hf ↦ ?_
      have hb : (Graph.banana x y ({e} : Set β)).IsLoopAt f x :=
        Graph.IsLoopAt.mono hC.le ((C.mem_loopSet x f).1 hf)
      rw [Graph.banana_isLoopAt] at hb
      exact hxy hb.2.2
    have hcard : (C.incidenceSet x).ncard ≤ 1 := by
      simpa using Set.ncard_le_ncard hinc (Set.finite_singleton e)
    have hdeg : C.degree x = 2 := hC.degree_eq hxC
    rw [Graph.degree_def, hloop, Set.ncard_empty] at hdeg
    omega
  intro heC
  obtain ⟨x, y, hxy⟩ := Graph.exists_isLink_of_mem_edgeSet heC
  have hb : (Graph.banana u v ({e} : Set β)).IsLink e x y := Graph.IsLink.mono hC.le hxy
  rw [Graph.banana_isLink] at hb
  obtain ⟨-, ⟨hx, -⟩ | ⟨hx, -⟩⟩ := hb
  · exact key u v huv C hC (hx ▸ hxy.left_mem)
  · exact key v u huv.symm C (by rwa [Graph.banana_comm]) (hx ▸ hxy.left_mem)

/-- **A single non-loop edge — i.e. a bridge — has no cycle double cover.** -/
theorem not_hasCycleDoubleCover_banana_singleton (huv : u ≠ v) (e : β) :
    ¬ (Graph.banana u v ({e} : Set β)).HasCycleDoubleCover :=
  Graph.not_hasCycleDoubleCover_of_forall_isCycle_notMem (e := e) (by simp)
    (notMem_edgeSet_of_isCycle_banana_singleton huv e)

end Workspace.Types.CycleDoubleCover

/-!
# Orientations of a multigraph

An *orientation* of a multigraph `G : Graph α β` chooses, for each edge `e`, which of its two
ends is the **tail** and which is the **head**. `Orientation G` bundles total functions
`tail head : β → α` with the single axiom `G.IsLink e (tail e) (head e)` for every `e ∈ E(G)`,
so `tail e`, `head e` are the two ends of `e` in some order (equal on a loop). Values on
non-edges are junk and must never be observed. Every multigraph over a nonempty vertex type
admits an orientation (`Orientation.ofGraph`; the hypothesis is necessary, see `nonempty_iff`).
-/

open Graph
open scoped Graph

namespace Workspace.Types.Orientation

variable {α β : Type*} {G H : Graph α β} {e : β} {x y : α}

/-- An **orientation** of the multigraph `G`: each edge `e` of `G` is assigned a `tail` and a
`head`, which are required to be the two ends of `e`. The values of `tail`/`head` outside of
`E(G)` are arbitrary junk and carry no meaning. -/
@[ext]
structure Orientation (G : Graph α β) where
  /-- The vertex an edge is directed *out of*. Meaningful only on `E(G)`. -/
  tail : β → α
  /-- The vertex an edge is directed *into*. Meaningful only on `E(G)`. -/
  head : β → α
  /-- For every edge of `G`, its tail and head are its two ends. -/
  isLink_tail_head : ∀ ⦃e⦄, e ∈ E(G) → G.IsLink e (tail e) (head e)

namespace Orientation

variable (O : Orientation G)

/-! ### Basic incidence facts -/

/-- The tail of an edge is an end of that edge. -/
lemma isLink_head_tail (he : e ∈ E(G)) : G.IsLink e (O.head e) (O.tail e) :=
  (O.isLink_tail_head he).symm

/-- The tail of an edge of `G` is incident to it. -/
lemma inc_tail (he : e ∈ E(G)) : G.Inc e (O.tail e) :=
  (O.isLink_tail_head he).inc_left

/-- The head of an edge of `G` is incident to it. -/
lemma inc_head (he : e ∈ E(G)) : G.Inc e (O.head e) :=
  (O.isLink_tail_head he).inc_right

/-- The tail of an edge of `G` is a vertex of `G`. -/
lemma tail_mem (he : e ∈ E(G)) : O.tail e ∈ V(G) :=
  (O.isLink_tail_head he).left_mem

/-- The head of an edge of `G` is a vertex of `G`. -/
lemma head_mem (he : e ∈ E(G)) : O.head e ∈ V(G) :=
  (O.isLink_tail_head he).right_mem

/-- The ends of an edge, as seen by an orientation, are the ends of that edge in some order. -/
lemma eq_and_eq_or_eq_and_eq (h : G.IsLink e x y) :
    (O.tail e = x ∧ O.head e = y) ∨ (O.tail e = y ∧ O.head e = x) :=
  (O.isLink_tail_head h.edge_mem).eq_and_eq_or_eq_and_eq h

/-- An orientation recovers the link relation: for an edge of `G`, the ends of `e` are exactly
`tail e` and `head e`, up to swapping. -/
lemma isLink_iff (he : e ∈ E(G)) :
    G.IsLink e x y ↔ (O.tail e = x ∧ O.head e = y) ∨ (O.tail e = y ∧ O.head e = x) :=
  (O.isLink_tail_head he).isLink_iff

/-- A vertex is incident to an edge of `G` exactly when it is its tail or its head. -/
lemma inc_iff (he : e ∈ E(G)) : G.Inc e x ↔ x = O.tail e ∨ x = O.head e :=
  ⟨fun h ↦ h.eq_or_eq_of_isLink (O.isLink_tail_head he), by
    rintro (rfl | rfl)
    · exact O.inc_tail he
    · exact O.inc_head he⟩

/-! ### Loops -/

/-- On a loop, the tail is the loop's vertex. -/
lemma tail_eq_of_isLoopAt (h : G.IsLoopAt e x) : O.tail e = x :=
  (h.eq_of_inc (O.inc_tail h.edge_mem)).symm

/-- On a loop, the head is the loop's vertex. -/
lemma head_eq_of_isLoopAt (h : G.IsLoopAt e x) : O.head e = x :=
  (h.eq_of_inc (O.inc_head h.edge_mem)).symm

/-- On a loop, tail and head coincide (with the loop's vertex). -/
lemma tail_eq_head_of_isLoopAt (h : G.IsLoopAt e x) : O.tail e = O.head e := by
  rw [O.tail_eq_of_isLoopAt h, O.head_eq_of_isLoopAt h]

/-- An edge of `G` is a loop exactly when its tail and head agree. -/
lemma isLoopAt_tail_iff_tail_eq_head (he : e ∈ E(G)) :
    G.IsLoopAt e (O.tail e) ↔ O.tail e = O.head e := by
  refine ⟨fun h ↦ O.tail_eq_head_of_isLoopAt h, fun h ↦ ?_⟩
  have := O.isLink_tail_head he
  rwa [← h] at this

/-! ### Reversal -/

/-- Reversing an orientation: swap tails and heads. -/
@[simps]
def reverse (O : Orientation G) : Orientation G where
  tail := O.head
  head := O.tail
  isLink_tail_head _ he := (O.isLink_tail_head he).symm

@[simp]
lemma reverse_reverse (O : Orientation G) : O.reverse.reverse = O := rfl

lemma reverse_injective : Function.Injective (reverse (G := G)) :=
  Function.LeftInverse.injective reverse_reverse

/-! ### Restriction to a subgraph -/

/-- An orientation of `G` restricts to an orientation of any subgraph `H ≤ G`: since `H` and `G`
agree on the ends of every edge of `H`, the same `tail`/`head` functions work. -/
@[simps]
def restrict (O : Orientation G) (hHG : H ≤ G) : Orientation H where
  tail := O.tail
  head := O.head
  isLink_tail_head _ he := (hHG.isLink_iff he).2 (O.isLink_tail_head (hHG.edgeSet_mono he))

/-! ### Existence -/

open Classical in
/-- Every multigraph over a nonempty vertex type has an orientation: pick, for each edge, some
pair of ends via choice (and an arbitrary junk value on non-edges). -/
noncomputable def ofGraph [Nonempty α] (G : Graph α β) : Orientation G where
  tail e := if he : e ∈ E(G) then (G.exists_isLink_of_mem_edgeSet he).choose
            else Classical.arbitrary α
  head e := if he : e ∈ E(G) then (G.exists_isLink_of_mem_edgeSet he).choose_spec.choose
            else Classical.arbitrary α
  isLink_tail_head e he := by
    simp only [dif_pos he]
    exact (G.exists_isLink_of_mem_edgeSet he).choose_spec.choose_spec

/-- **Existence of orientations**: every multigraph with a nonempty vertex type can be oriented. -/
theorem exists_orientation [Nonempty α] (G : Graph α β) : Nonempty (Orientation G) :=
  ⟨ofGraph G⟩

instance [Nonempty α] : Nonempty (Orientation G) := exists_orientation G

/-- If `G` has at least one edge, it has an orientation (its vertex type is then automatically
nonempty). -/
theorem nonempty_of_edgeSet_nonempty (h : E(G).Nonempty) : Nonempty (Orientation G) := by
  obtain ⟨e, he⟩ := h
  obtain ⟨x, y, hxy⟩ := G.exists_isLink_of_mem_edgeSet he
  have : Nonempty α := ⟨x⟩
  exact exists_orientation G

/-- A graph admits an orientation iff there is somewhere for `tail`/`head` to send edges: either
the edge type is empty (so the junk data is vacuous) or the vertex type is nonempty. This makes
precise that the `Nonempty α` hypothesis in `exists_orientation` is honest and unavoidable. -/
theorem nonempty_iff : Nonempty (Orientation G) ↔ (IsEmpty β ∨ Nonempty α) := by
  constructor
  · rintro ⟨O⟩
    rcases isEmpty_or_nonempty β with hβ | ⟨⟨e⟩⟩
    · exact Or.inl hβ
    · exact Or.inr ⟨O.tail e⟩
  · rintro (hβ | hα)
    · exact ⟨⟨fun e ↦ (hβ.false e).elim, fun e ↦ (hβ.false e).elim,
        fun e _ ↦ (hβ.false e).elim⟩⟩
    · exact exists_orientation G

end Orientation

end Workspace.Types.Orientation

/-!
# Flows on an oriented multigraph

Fix an orientation `O : Orientation G` of a multigraph `G : Graph α β`. If `A` is an abelian
group, an **`A`-flow** is a map `f : E(G) → A` such that at every vertex the sum of `f` over the
edges directed *out* of that vertex equals the sum over the edges directed *in*. It is
**nowhere-zero** if `f e ≠ 0` for every edge `e`. For an integer `k ≥ 2`, an **integer
`k`-flow** is an integer-valued flow `φ` with `0 < |φ e| < k` on every edge.

The conservation sums are `finsum`s over `E(G)`; on a finite edge set (the paper's setting,
supplied downstream via `E(G).Finite`) they agree with ordinary finite sums, see
`Graph.isFlow_iff_finset_sum`. A loop at `v` lies in both the out- and in-edge sets, so it
contributes to both sides.
-/

open Workspace.Types.Orientation
open scoped Graph

namespace Graph

variable {α β : Type*} {A : Type*} [AddCommGroup A] {G : Graph α β} {O : Orientation G}
  {f g : β → A} {v : α} {e : β} {φ : β → ℤ} {k : ℤ}

/-! ### Out- and in-edges at a vertex -/

/-- The edges of `G` directed **out of** `v` by `O`, i.e. the edges whose tail is `v`.
A loop at `v` belongs to this set. -/
def outEdgeSet (G : Graph α β) (O : Orientation G) (v : α) : Set β :=
  {e ∈ E(G) | O.tail e = v}

/-- The edges of `G` directed **in to** `v` by `O`, i.e. the edges whose head is `v`.
A loop at `v` belongs to this set. -/
def inEdgeSet (G : Graph α β) (O : Orientation G) (v : α) : Set β :=
  {e ∈ E(G) | O.head e = v}

@[simp]
lemma mem_outEdgeSet : e ∈ G.outEdgeSet O v ↔ e ∈ E(G) ∧ O.tail e = v := Iff.rfl

@[simp]
lemma mem_inEdgeSet : e ∈ G.inEdgeSet O v ↔ e ∈ E(G) ∧ O.head e = v := Iff.rfl

lemma outEdgeSet_subset_edgeSet : G.outEdgeSet O v ⊆ E(G) := fun _ he ↦ he.1

lemma inEdgeSet_subset_edgeSet : G.inEdgeSet O v ⊆ E(G) := fun _ he ↦ he.1

/-- Reversing the orientation swaps out-edges and in-edges. -/
@[simp]
lemma outEdgeSet_reverse : G.outEdgeSet O.reverse v = G.inEdgeSet O v := rfl

/-- Reversing the orientation swaps in-edges and out-edges. -/
@[simp]
lemma inEdgeSet_reverse : G.inEdgeSet O.reverse v = G.outEdgeSet O v := rfl

/-- A loop at `v` is directed out of `v`. -/
lemma IsLoopAt.mem_outEdgeSet (h : G.IsLoopAt e v) (O : Orientation G) :
    e ∈ G.outEdgeSet O v :=
  ⟨h.edge_mem, O.tail_eq_of_isLoopAt h⟩

/-- A loop at `v` is directed in to `v`. -/
lemma IsLoopAt.mem_inEdgeSet (h : G.IsLoopAt e v) (O : Orientation G) :
    e ∈ G.inEdgeSet O v :=
  ⟨h.edge_mem, O.head_eq_of_isLoopAt h⟩

/-! ### The out- and in-sums of a map at a vertex -/

/-- The sum of `f` over the edges of `G` directed out of `v`. -/
noncomputable def outSum (G : Graph α β) (O : Orientation G) (f : β → A) (v : α) : A :=
  ∑ᶠ e ∈ G.outEdgeSet O v, f e

/-- The sum of `f` over the edges of `G` directed in to `v`. -/
noncomputable def inSum (G : Graph α β) (O : Orientation G) (f : β → A) (v : α) : A :=
  ∑ᶠ e ∈ G.inEdgeSet O v, f e

@[simp]
lemma outSum_reverse : G.outSum O.reverse f v = G.inSum O f v := rfl

@[simp]
lemma inSum_reverse : G.inSum O.reverse f v = G.outSum O f v := rfl

/-! ### Flows -/

/-- `G.IsFlow O f` says that `f`, read through the orientation `O`, is a **flow**: at every
vertex, the sum of `f` over the out-edges equals the sum over the in-edges. Here `A` is an
arbitrary abelian group, so this is the paper's notion of an `A`-flow. -/
def IsFlow (G : Graph α β) (O : Orientation G) (f : β → A) : Prop :=
  ∀ v ∈ V(G), G.outSum O f v = G.inSum O f v

/-- `G.IsNowhereZero f` says that `f` takes no zero value on an edge of `G`. A *nowhere-zero
`A`-flow* is a map satisfying both this and `Graph.IsFlow`. -/
def IsNowhereZero (G : Graph α β) (f : β → A) : Prop :=
  ∀ e ∈ E(G), f e ≠ 0

/-- `G.IsIntegerKFlow O φ k` says that the integer-valued map `φ` is an **integer `k`-flow**:
a flow satisfying `0 < |φ e| < k` on every edge. The side condition `k ≥ 2` is stated by the
caller, not folded in here. -/
def IsIntegerKFlow (G : Graph α β) (O : Orientation G) (φ : β → ℤ) (k : ℤ) : Prop :=
  G.IsFlow O φ ∧ ∀ e ∈ E(G), 0 < |φ e| ∧ |φ e| < k

/-! ### Basic lemmas -/

/-- The zero map is a flow. -/
theorem isFlow_zero (G : Graph α β) (O : Orientation G) :
    G.IsFlow O (0 : β → A) := by
  intro v _
  simp [Graph.outSum, Graph.inSum]

/-- A map is a flow for `O` iff it is a flow for the reversed orientation. -/
theorem isFlow_reverse_iff : G.IsFlow O.reverse f ↔ G.IsFlow O f := by
  simp only [Graph.IsFlow, Graph.outSum_reverse, Graph.inSum_reverse]
  exact ⟨fun h v hv ↦ (h v hv).symm, fun h v hv ↦ (h v hv).symm⟩

alias ⟨IsFlow.of_reverse, IsFlow.reverse⟩ := Graph.isFlow_reverse_iff

/-- The negation of a flow is a flow (on a graph with finitely many edges). -/
theorem IsFlow.neg (hE : E(G).Finite) (hf : G.IsFlow O f) : G.IsFlow O (-f) := by
  intro v hv
  have hout : (G.outEdgeSet O v).Finite := hE.subset Graph.outEdgeSet_subset_edgeSet
  have hin : (G.inEdgeSet O v).Finite := hE.subset Graph.inEdgeSet_subset_edgeSet
  simp only [Graph.outSum, Graph.inSum, Pi.neg_apply, finsum_mem_neg_distrib _ hout,
    finsum_mem_neg_distrib _ hin]
  exact congrArg Neg.neg (hf v hv)

/-- The sum of two flows is a flow (on a graph with finitely many edges). -/
theorem IsFlow.add (hE : E(G).Finite) (hf : G.IsFlow O f) (hg : G.IsFlow O g) :
    G.IsFlow O (f + g) := by
  intro v hv
  have hout : (G.outEdgeSet O v).Finite := hE.subset Graph.outEdgeSet_subset_edgeSet
  have hin : (G.inEdgeSet O v).Finite := hE.subset Graph.inEdgeSet_subset_edgeSet
  simp only [Graph.outSum, Graph.inSum, Pi.add_apply, finsum_mem_add_distrib hout,
    finsum_mem_add_distrib hin]
  exact congrArg₂ (· + ·) (hf v hv) (hg v hv)

/-- An integer `k`-flow is in particular a flow. -/
theorem IsIntegerKFlow.isFlow (h : G.IsIntegerKFlow O φ k) : G.IsFlow O φ := h.1

/-- An integer `k`-flow is nowhere-zero. -/
theorem IsIntegerKFlow.isNowhereZero (h : G.IsIntegerKFlow O φ k) :
    G.IsNowhereZero φ := fun e he ↦ abs_pos.mp (h.2 e he).1

/-- The values of an integer `k`-flow on edges are bounded: `|φ e| < k`. -/
theorem IsIntegerKFlow.abs_lt (h : G.IsIntegerKFlow O φ k) (he : e ∈ E(G)) :
    |φ e| < k := (h.2 e he).2

/-- An integer `k`-flow for the reversed orientation is the same thing as one for `O`. -/
theorem isIntegerKFlow_reverse_iff :
    G.IsIntegerKFlow O.reverse φ k ↔ G.IsIntegerKFlow O φ k := by
  simp [Graph.IsIntegerKFlow, Graph.isFlow_reverse_iff]

/-! ### Finite reformulation

On a graph with finitely many edges the `finsum`s are ordinary `Finset.sum`s. -/

lemma outSum_eq_finset_sum (hE : E(G).Finite) (O : Orientation G) (f : β → A)
    (v : α) : G.outSum O f v = ∑ e ∈ (hE.subset (Graph.outEdgeSet_subset_edgeSet
      (O := O) (v := v))).toFinset, f e := by
  rw [Graph.outSum, ← finsum_mem_coe_finset]
  exact finsum_mem_congr (by simp) fun _ _ ↦ rfl

lemma inSum_eq_finset_sum (hE : E(G).Finite) (O : Orientation G) (f : β → A)
    (v : α) : G.inSum O f v = ∑ e ∈ (hE.subset (Graph.inEdgeSet_subset_edgeSet
      (O := O) (v := v))).toFinset, f e := by
  rw [Graph.inSum, ← finsum_mem_coe_finset]
  exact finsum_mem_congr (by simp) fun _ _ ↦ rfl

/-- Conservation as an identity of ordinary finite sums over the edge set, when `E(G)` is finite. -/
theorem isFlow_iff_finset_sum [DecidableEq α] (hE : E(G).Finite) :
    G.IsFlow O f ↔ ∀ v ∈ V(G),
      ∑ e ∈ hE.toFinset with O.tail e = v, f e = ∑ e ∈ hE.toFinset with O.head e = v, f e := by
  have key : ∀ (t : β → α) (v : α),
      (∑ᶠ e ∈ {e ∈ E(G) | t e = v}, f e) = ∑ e ∈ hE.toFinset with t e = v, f e := by
    intro t v
    rw [← finsum_mem_coe_finset]
    refine finsum_mem_congr ?_ fun _ _ ↦ rfl
    ext e
    simp [Set.mem_setOf_eq, and_comm]
  simp only [Graph.IsFlow, Graph.outSum, Graph.inSum, Graph.outEdgeSet, Graph.inEdgeSet,
    key O.tail, key O.head]

end Graph

/-!
# Proper 3-edge-colourings of a multigraph

A **proper 3-edge-colouring** of a multigraph `G : Graph α β` is a map `c : β → Fin 3` such
that any two *distinct* edges meeting at a common vertex get distinct colours:

  `G.IsProper3EdgeColouring c ↔ ∀ v ∈ V(G), Set.InjOn c (G.incidenceSet v)`.

On a loopless cubic graph this is equivalent to "the three edges at each vertex receive all
three colours" (`Graph.IsProper3EdgeColouring.image_incidenceSet_eq_univ`). Cubicness,
looplessness and surjectivity are hypotheses of the statements that use this predicate, not
part of the predicate itself.
-/

open Set

open scoped Graph

namespace Graph

variable {α β : Type*} {G H : Graph α β} {c : β → Fin 3} {e e₁ e₂ : β} {u v : α}

/-! ## The definition -/

/-- A map `c : β → Fin 3` is a **proper 3-edge-colouring** of `G` if, at every vertex, any
two distinct edges incident to that vertex receive distinct colours. -/
def IsProper3EdgeColouring (G : Graph α β) (c : β → Fin 3) : Prop :=
  ∀ v ∈ V(G), ∀ e₁, G.Inc e₁ v → ∀ e₂, G.Inc e₂ v → e₁ ≠ e₂ → c e₁ ≠ c e₂

/-! ## Basic reformulations -/

/-- The defining property in applied form: two distinct edges meeting at a vertex have
different colours. -/
lemma IsProper3EdgeColouring.ne_of_inc (h : G.IsProper3EdgeColouring c)
    (hv : v ∈ V(G)) (h₁ : G.Inc e₁ v) (h₂ : G.Inc e₂ v) (hne : e₁ ≠ e₂) : c e₁ ≠ c e₂ :=
  h v hv e₁ h₁ e₂ h₂ hne

/-- A proper 3-edge-colouring is **injective on the edges incident to any vertex**. -/
lemma IsProper3EdgeColouring.injOn (h : G.IsProper3EdgeColouring c) (hv : v ∈ V(G)) :
    Set.InjOn c (G.incidenceSet v) := by
  intro e₁ h₁ e₂ h₂ hcol
  by_contra hne
  exact h v hv e₁ ((G.mem_incidenceSet v e₁).1 h₁) e₂ ((G.mem_incidenceSet v e₂).1 h₂) hne hcol

/-- Being a proper 3-edge-colouring is exactly injectivity on every incidence set. -/
lemma isProper3EdgeColouring_iff_injOn :
    G.IsProper3EdgeColouring c ↔ ∀ v ∈ V(G), Set.InjOn c (G.incidenceSet v) :=
  ⟨fun h _v hv ↦ h.injOn hv,
    fun h v hv e₁ h₁ e₂ h₂ hne hcol ↦
      hne (h v hv ((G.mem_incidenceSet v e₁).2 h₁) ((G.mem_incidenceSet v e₂).2 h₂) hcol)⟩

/-! ## Behaviour under passing to a subgraph -/

/-- Properness is inherited by subgraphs. -/
lemma IsProper3EdgeColouring.mono (h : G.IsProper3EdgeColouring c) (hHG : H ≤ G) :
    H.IsProper3EdgeColouring c :=
  fun v hv e₁ h₁ e₂ h₂ hne ↦
    h v (Graph.IsSubgraph.vertexSet_mono hHG hv) e₁ (h₁.mono hHG) e₂ (h₂.mono hHG) hne

/-! ## The loopless cubic case

On a loopless cubic graph the injectivity formulation is equivalent to "all three colours
appear at each vertex". -/

/-- At a degree-`3` vertex of a loopless graph, a proper 3-edge-colouring hits **every**
colour. -/
lemma IsProper3EdgeColouring.image_incidenceSet_eq_univ
    (h : G.IsProper3EdgeColouring c) (hloop : G.IsLoopless) (hv : v ∈ V(G))
    (hdeg : G.degree v = 3) : c '' G.incidenceSet v = (Set.univ : Set (Fin 3)) := by
  have hcard : (G.incidenceSet v).ncard = 3 := by
    rw [← hloop.degree_eq_ncard_incidenceSet v, hdeg]
  have himg : (c '' G.incidenceSet v).ncard = 3 := by
    rw [(h.injOn hv).ncard_image, hcard]
  have hle : (Set.univ : Set (Fin 3)).ncard ≤ (c '' G.incidenceSet v).ncard := by
    rw [himg, Set.ncard_univ]
    simp
  exact Set.eq_of_subset_of_ncard_le (Set.subset_univ _) hle (Set.finite_univ)

/-- At a degree-`3` vertex of a loopless graph, each of the three colours is realised by an
edge at `v`. -/
lemma IsProper3EdgeColouring.exists_inc_colour
    (h : G.IsProper3EdgeColouring c) (hloop : G.IsLoopless) (hv : v ∈ V(G))
    (hdeg : G.degree v = 3) (i : Fin 3) : ∃ e, G.Inc e v ∧ c e = i := by
  have := h.image_incidenceSet_eq_univ hloop hv hdeg
  have hi : i ∈ c '' G.incidenceSet v := by rw [this]; trivial
  obtain ⟨e, he, hce⟩ := hi
  exact ⟨e, (G.mem_incidenceSet v e).1 he, hce⟩

end Graph

/-!
# Local orderings of the incident edges of a multigraph

Formalises the paper's "at each vertex `v`, locally order the incident edges as `a`, `b`, `c`".
The ordering is *data*: `LocalOrdering G` carries a function `edge : α → Fin 3 → β` with axioms
saying that, at every `v ∈ V(G)`, the list `edge v 0, edge v 1, edge v 2` enumerates the edges
incident to `v` without repetition (`inc_edge`, `injective`, `exists_index`); equivalently
(`range_edge`) `edge v` maps `Fin 3` bijectively onto `G.incidenceSet v`.

Values at `v ∉ V(G)` are junk and must never be observed. Looplessness/cubicness are not baked
in but are hypotheses of the existence theorem `exists_localOrdering`, whose `[Nonempty β]` only
supplies that junk value and is automatic once `G` has a vertex.
-/

open Set

open scoped Graph

namespace Workspace.Types.LocalOrdering

open Workspace.Types.LocalOrdering

variable {α β : Type*} {G : Graph α β} {e : β} {u v : α} {i j : Fin 3}

/-- A **local ordering** of a multigraph `G`: at each vertex `v` of `G` it names the three
incident edges `edge v 0`, `edge v 1`, `edge v 2` (the paper's `a`, `b`, `c`).

The axioms say precisely that, for `v ∈ V(G)`, the map `edge v : Fin 3 → β` enumerates
`G.incidenceSet v` without repetition. For `v ∉ V(G)` the value of `edge v` is unconstrained
junk and carries no meaning. -/
structure LocalOrdering (G : Graph α β) where
  /-- `edge v i` is the `i`-th of the three edges at `v`. -/
  edge : α → Fin 3 → β
  /-- Every listed edge is incident to `v`. -/
  inc_edge : ∀ v ∈ V(G), ∀ i, G.Inc (edge v i) v
  /-- The listed edges are pairwise distinct: no edge at `v` is listed twice. -/
  injective : ∀ v ∈ V(G), Function.Injective (edge v)
  /-- Every edge incident to `v` is listed. -/
  exists_index : ∀ v ∈ V(G), ∀ e, G.Inc e v → ∃ i, edge v i = e

namespace LocalOrdering

variable (o : LocalOrdering G)

/-! ## Basic lemmas -/

/-- Each of the three edges listed at a vertex `v` of `G` is incident to `v`. -/
lemma inc (hv : v ∈ V(G)) (i : Fin 3) : G.Inc (o.edge v i) v := o.inc_edge v hv i

/-- Each of the three edges listed at a vertex `v` of `G` lies in `G.incidenceSet v`. -/
lemma edge_mem_incidenceSet (hv : v ∈ V(G)) (i : Fin 3) : o.edge v i ∈ G.incidenceSet v :=
  o.inc hv i

/-- Each of the three edges listed at a vertex `v` of `G` is an edge of `G`. -/
lemma edge_mem_edgeSet (hv : v ∈ V(G)) (i : Fin 3) : o.edge v i ∈ E(G) := (o.inc hv i).edge_mem

/-- The three edges listed at a vertex `v` of `G` are pairwise distinct. -/
lemma edge_ne_edge (hv : v ∈ V(G)) (hij : i ≠ j) : o.edge v i ≠ o.edge v j :=
  fun h ↦ hij (o.injective v hv h)

/-- At a vertex `v` of `G`, the local ordering enumerates exactly the edges incident to `v`. -/
lemma range_edge (hv : v ∈ V(G)) : Set.range (o.edge v) = G.incidenceSet v := by
  ext e
  refine ⟨?_, fun he ↦ ?_⟩
  · rintro ⟨i, rfl⟩
    exact o.edge_mem_incidenceSet hv i
  · obtain ⟨i, hi⟩ := o.exists_index v hv e he
    exact ⟨i, hi⟩

/-- An edge `e` is incident to `v ∈ V(G)` if and only if it is one of the three listed edges. -/
lemma inc_iff_exists_index (hv : v ∈ V(G)) : G.Inc e v ↔ ∃ i, o.edge v i = e :=
  ⟨o.exists_index v hv e, by rintro ⟨i, rfl⟩; exact o.inc hv i⟩

end LocalOrdering

/-! ## Existence

Every loopless cubic multigraph (over a nonempty edge type) admits a local ordering. -/

/-- A cubic graph with at least one vertex has at least one edge; in particular its edge type
is nonempty. This makes the `[Nonempty β]` hypothesis of `exists_localOrdering` harmless. -/
lemma nonempty_edgeType_of_isCubic (hcubic : G.IsCubic) (hv : v ∈ V(G)) : Nonempty β := by
  by_contra h
  rw [not_nonempty_iff] at h
  have : G.degree v = 0 := by
    have h1 : G.incidenceSet v = ∅ := Set.eq_empty_of_isEmpty _
    have h2 : G.loopSet v = ∅ := Set.eq_empty_of_isEmpty _
    simp [Graph.degree_def, h1, h2]
  rw [hcubic v hv] at this
  exact absurd this (by norm_num)

/-- In a loopless cubic multigraph, every vertex is incident to exactly three edges. -/
lemma ncard_incidenceSet_eq_three (hloopless : G.IsLoopless) (hcubic : G.IsCubic)
    (hv : v ∈ V(G)) : (G.incidenceSet v).ncard = 3 := by
  rw [← hloopless.degree_eq_ncard_incidenceSet v]
  exact hcubic v hv

/-- **Existence of local orderings.** Every loopless cubic multigraph admits a local ordering
of the edges at each of its vertices. The `[Nonempty β]` hypothesis only supplies the
never-observed junk value of `edge v` at vertices `v ∉ V(G)`. -/
theorem exists_localOrdering [Nonempty β] (hloopless : G.IsLoopless) (hcubic : G.IsCubic) :
    Nonempty (LocalOrdering G) := by
  classical
  -- Choose, for each vertex `v`, an enumeration of the edges at `v` (junk off `V(G)`).
  have key : ∀ v : α, ∃ f : Fin 3 → β, v ∈ V(G) →
      (∀ i, G.Inc (f i) v) ∧ Function.Injective f ∧ ∀ e, G.Inc e v → ∃ i, f i = e := by
    intro v
    by_cases hv : v ∈ V(G)
    · obtain ⟨a, b, c, hab, hac, hbc, hset⟩ :=
        Set.ncard_eq_three.1 (ncard_incidenceSet_eq_three hloopless hcubic hv)
      have hmem : ∀ x ∈ ({a, b, c} : Set β), G.Inc x v := by
        intro x hx
        rw [← hset] at hx
        exact hx
      refine ⟨![a, b, c], fun _ ↦ ⟨?_, ?_, ?_⟩⟩
      · intro i
        fin_cases i
        · exact hmem a (by simp)
        · exact hmem b (by simp)
        · exact hmem c (by simp)
      · intro i j hij
        fin_cases i <;> fin_cases j <;> simp_all
      · intro e he
        have : e ∈ ({a, b, c} : Set β) := by rw [← hset]; exact he
        rcases this with rfl | rfl | rfl
        · exact ⟨0, by simp⟩
        · exact ⟨1, by simp⟩
        · exact ⟨2, by simp⟩
    · exact ⟨fun _ ↦ Classical.arbitrary β, fun h ↦ absurd h hv⟩
  choose f hf using key
  exact ⟨{ edge := f
           inc_edge := fun v hv i ↦ (hf v hv).1 i
           injective := fun v hv ↦ (hf v hv).2.1
           exists_index := fun v hv e he ↦ (hf v hv).2.2 e he }⟩

end Workspace.Types.LocalOrdering

/-!
# The local shift `g` and its edge-difference `d`

Formalises the paper's shift construction (2): at each vertex `v` with locally ordered incident
edges `a, b, c` and `x = f(a)`, set `g_{v,a} = 0`, `g_{v,b} = x`, `g_{v,c} = 0`, and for `e = uv`
put `d_e = g_{u,e} + g_{v,e}`. Thus `g` is supported on the *second* listed edge, where its value
is the flow on the *first* (`g_edge_one`: `S.g v (ord.edge v 1) = S.flow (ord.edge v 0)`).

`LocalShift G` bundles the input data `flow : β → Γ` and `ord : LocalOrdering G`; `g` and `d`
are then `def`s, so the structure carries no axioms. `d` is defined as a `finsum` over the set
of ends `∑ᶠ w ∈ {w | G.Inc e w}, S.g w e`, symmetric by construction and equal to `g_{u,e} + g_{v,e}`
for a non-loop edge (`d_eq_add`). Values of `g` off the second listed edge, and at `v ∉ V(G)`,
are zero/junk and are only ever observed through the incident-edge sum (8) and through `d`.
-/

open Set Function
open scoped Graph
open Workspace.Types.Gamma
open Workspace.Types.LocalOrdering

namespace Workspace.Types.LocalShift

open Workspace.Types.LocalShift

variable {α β : Type*} {G : Graph α β} {e : β} {u v w : α}

/-- The input data of the paper's shift construction on a multigraph `G`: a `Γ`-valued map
`flow` on the edges (the paper's `f`; in the applications it is a nowhere-zero `Γ`-flow, but
that is a hypothesis of the lemmas, not part of this data) together with a local ordering
`ord` of the edges at each vertex (the paper's `a, b, c`).

The shift `g` and its edge-difference `d` are *definitions* on this data — see
`LocalShift.g` and `LocalShift.d` — so the structure carries no axioms. -/
@[ext]
structure LocalShift (G : Graph α β) where
  /-- The `Γ`-valued map on edges — the paper's `f`. -/
  flow : β → Gamma
  /-- The local ordering of the edges at each vertex — the paper's `a, b, c` at each `v`. -/
  ord : LocalOrdering G

namespace LocalShift

variable (S : LocalShift G)

/-! ## The shift `g` -/

open Classical in
/-- The paper's shift `g_{v,e}` of equation (2): supported on the second listed edge
`b = ord.edge v 1`, where its value is `flow (ord.edge v 0)`, and zero on every other edge. -/
noncomputable def g (S : LocalShift G) (v : α) (e : β) : Gamma :=
  if e = S.ord.edge v 1 then S.flow (S.ord.edge v 0) else 0

/-- The shift vanishes off the second listed edge at `v`. -/
@[simp]
lemma g_of_ne (h : e ≠ S.ord.edge v 1) : S.g v e = 0 := by
  simp [g, h]

/-- `g_{v,b} = x`: the shift on the **second** listed edge `b = ord.edge v 1` is the flow value
`x = flow a` on the **first** listed edge `a = ord.edge v 0`.  This is the substance of
equation (2). -/
@[simp]
lemma g_edge_one (v : α) : S.g v (S.ord.edge v 1) = S.flow (S.ord.edge v 0) := by
  simp [g]

/-- `g_{v,a} = 0`: the shift on the first listed edge vanishes. -/
@[simp]
lemma g_edge_zero (hv : v ∈ V(G)) : S.g v (S.ord.edge v 0) = 0 :=
  S.g_of_ne (S.ord.edge_ne_edge hv (by decide))

/-- `g_{v,c} = 0`: the shift on the third listed edge vanishes. -/
@[simp]
lemma g_edge_two (hv : v ∈ V(G)) : S.g v (S.ord.edge v 2) = 0 :=
  S.g_of_ne (S.ord.edge_ne_edge hv (by decide))

/-- `g v` is nonzero only on the second listed edge at `v`. -/
lemma eq_edge_one_of_g_ne_zero (h : S.g v e ≠ 0) : e = S.ord.edge v 1 := by
  by_contra hne
  exact h (S.g_of_ne hne)

/-- The support of `g v` is contained in the singleton `{ord.edge v 1}`. -/
lemma support_g_subset : Function.support (S.g v) ⊆ {S.ord.edge v 1} :=
  fun _ he ↦ S.eq_edge_one_of_g_ne_zero he

/-! ## Equation (8): the local sum of the shift

At a vertex `v` of `G` the three incident edges are `a, b, c` and they contribute
`0 + x + 0 = x` to the sum of `g_{v,·}`.  Note that no looplessness or cubicness hypothesis is
needed: the axioms of `LocalOrdering` already say that `a, b, c` enumerate `G.incidenceSet v`
without repetition, for every `v ∈ V(G)`. -/

/-- The edges incident to `v ∈ V(G)` are exactly the three listed edges `a, b, c`. -/
lemma incidenceSet_eq_triple (hv : v ∈ V(G)) :
    G.incidenceSet v = {S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} := by
  rw [← S.ord.range_edge hv]
  ext x
  simp only [Set.mem_range, Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · rintro ⟨i, rfl⟩
    fin_cases i <;> simp
  · rintro (rfl | rfl | rfl)
    exacts [⟨0, rfl⟩, ⟨1, rfl⟩, ⟨2, rfl⟩]

/-- **Equation (8).** The sum of the shift over the edges incident to a vertex `v` of `G` is
`x = flow (ord.edge v 0)`, since the three incident edges `a, b, c` contribute `0 + x + 0`. -/
theorem finsum_g_incidenceSet (hv : v ∈ V(G)) :
    (∑ᶠ e ∈ G.incidenceSet v, S.g v e) = S.flow (S.ord.edge v 0) := by
  classical
  have h01 : S.ord.edge v 0 ≠ S.ord.edge v 1 := S.ord.edge_ne_edge hv (by decide)
  have h02 : S.ord.edge v 0 ≠ S.ord.edge v 2 := S.ord.edge_ne_edge hv (by decide)
  have h12 : S.ord.edge v 1 ≠ S.ord.edge v 2 := S.ord.edge_ne_edge hv (by decide)
  have hcoe : ({S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} : Set β)
      = (↑({S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} : Finset β) : Set β) := by
    simp
  rw [S.incidenceSet_eq_triple hv, hcoe, finsum_mem_coe_finset]
  rw [Finset.sum_insert (by simp [h01, h02]), Finset.sum_insert (by simp [h12]),
    Finset.sum_singleton]
  simp [S.g_edge_zero hv, S.g_edge_one v, S.g_edge_two hv]

/-! ## The edge-difference `d` -/

/-- The paper's `d_e = g_{u,e} + g_{v,e}` for an edge `e` with ends `u, v`.

To keep the definition manifestly symmetric in the two ends — the paper's formula does not
depend on which end is called `u` — we sum `g_{·,e}` over the *set of ends* of `e`.  For a
non-loop edge with ends `u ≠ v` this is exactly `g_{u,e} + g_{v,e}`; see `d_eq_add`. -/
noncomputable def d (S : LocalShift G) (e : β) : Gamma :=
  ∑ᶠ w ∈ {w | G.Inc e w}, S.g w e

lemma d_def (e : β) : S.d e = ∑ᶠ w ∈ {w | G.Inc e w}, S.g w e := rfl

/-- The set of ends of a non-loop edge `e` with ends `u ≠ v` is the pair `{u, v}`. -/
lemma setOf_inc_eq_pair (h : G.IsLink e u v) : {w | G.Inc e w} = ({u, v} : Set α) := by
  ext x
  simp only [Set.mem_setOf_eq, Set.mem_insert_iff, Set.mem_singleton_iff]
  refine ⟨(Graph.isLink_iff_inc.1 h).2.2 x, ?_⟩
  rintro (rfl | rfl)
  exacts [h.inc_left, h.inc_right]

/-- **The paper's formula for `d`.** For an edge `e` whose ends `u, v` are distinct (i.e. `e` is
not a loop — automatic in a loopless graph), `d_e = g_{u,e} + g_{v,e}`. -/
theorem d_eq_add (h : G.IsLink e u v) (hne : u ≠ v) : S.d e = S.g u e + S.g v e := by
  rw [d_def, setOf_inc_eq_pair h, finsum_mem_pair hne]

/-- An edge that is not the second listed edge at either of its (distinct) ends has `d_e = 0`. -/
lemma d_eq_zero_of_ne (h : G.IsLink e u v) (hne : u ≠ v) (hu : e ≠ S.ord.edge u 1)
    (hv : e ≠ S.ord.edge v 1) : S.d e = 0 := by
  rw [S.d_eq_add h hne, S.g_of_ne hu, S.g_of_ne hv, add_zero]

end LocalShift

end Workspace.Types.LocalShift

/-!
# Two-element assignments (the paper's relaxed 3-edge-colouring)

The hypothesis of Lemma 2.1 of *"A Proof of the Cycle Double Cover Conjecture"*: an
assignment `P : β → Set Gamma` of a two-element palette to every edge such that, for every
vertex `v` and colour `s`, the number of edges incident to `v` whose palette contains `s`
is `0` or `2`. Looplessness and cubicness are separate hypotheses of Lemma 2.1 and are not
part of this predicate. Cardinalities use `Set.encard` (`ℕ∞`-valued), so `∈ {0, 2}` says
exactly "zero or two" with no finiteness side-condition.
-/

open Set

open scoped Graph

open Workspace.Types.Gamma

namespace Graph

variable {α β : Type*} {G : Graph α β} {P Q : β → Set Gamma} {e f : β} {v : α} {s : Gamma}

/-! ## The edges at a vertex carrying a given colour -/

/-- The set of edges **incident to `v`** whose palette contains the colour `s`; the paper's
`{e ∋ v : s ∈ P_e}`. This is a set of edges, not of edge-ends. -/
def paletteIncidenceSet (G : Graph α β) (P : β → Set Gamma) (v : α) (s : Gamma) :
    Set β :=
  {e ∈ G.incidenceSet v | s ∈ P e}

@[simp]
lemma mem_paletteIncidenceSet (G : Graph α β) (P : β → Set Gamma) (v : α) (s : Gamma)
    (e : β) : e ∈ G.paletteIncidenceSet P v s ↔ G.Inc e v ∧ s ∈ P e := Iff.rfl

lemma paletteIncidenceSet_subset_incidenceSet (G : Graph α β) (P : β → Set Gamma)
    (v : α) (s : Gamma) : G.paletteIncidenceSet P v s ⊆ G.incidenceSet v :=
  fun _ he ↦ he.1

lemma paletteIncidenceSet_subset_edgeSet (G : Graph α β) (P : β → Set Gamma)
    (v : α) (s : Gamma) : G.paletteIncidenceSet P v s ⊆ E(G) :=
  (G.paletteIncidenceSet_subset_incidenceSet P v s).trans (G.incidenceSet_subset_edgeSet v)

/-! ## The predicate -/

/-- **The paper's relaxed 3-edge-colouring** (hypothesis of Lemma 2.1): an assignment `P`
such that every edge of `G` receives a two-element palette, and at every vertex every colour
is carried by exactly `0` or exactly `2` incident edges. Looplessness and cubicness of `G`
are not part of this predicate. -/
structure IsTwoElementAssignment (G : Graph α β) (P : β → Set Gamma) : Prop where
  /-- Every edge of `G` is assigned a two-element subset of `Γ`. -/
  encard_palette : ∀ e ∈ E(G), (P e).encard = 2
  /-- At every vertex, every colour is carried by exactly `0` or exactly `2` incident edges. -/
  encard_paletteIncidenceSet :
    ∀ v ∈ V(G), ∀ s : Gamma, (G.paletteIncidenceSet P v s).encard ∈ ({0, 2} : Set ℕ∞)

/-- The incidence-count condition, spelled out as a disjunction. -/
lemma IsTwoElementAssignment.encard_eq_zero_or_eq_two
    (h : G.IsTwoElementAssignment P) (hv : v ∈ V(G)) (s : Gamma) :
    (G.paletteIncidenceSet P v s).encard = 0 ∨ (G.paletteIncidenceSet P v s).encard = 2 := by
  simpa using h.encard_paletteIncidenceSet v hv s

/-- **The two colours of an edge are distinct**: the palette of an edge is an unordered pair
of different elements of `Γ`. -/
lemma IsTwoElementAssignment.exists_pair_palette
    (h : G.IsTwoElementAssignment P) (he : e ∈ E(G)) :
    ∃ a b : Gamma, a ≠ b ∧ P e = {a, b} :=
  Set.encard_eq_two.1 (h.encard_palette e he)

/-- The palette of an edge of `G` contains two distinct colours. -/
lemma IsTwoElementAssignment.nontrivial_palette
    (h : G.IsTwoElementAssignment P) (he : e ∈ E(G)) : (P e).Nontrivial := by
  obtain ⟨a, b, hab, hP⟩ := h.exists_pair_palette he
  exact hP ▸ Set.nontrivial_pair hab

/-- **A colour seen at a vertex is seen exactly twice there.** -/
lemma IsTwoElementAssignment.encard_eq_two_of_mem
    (h : G.IsTwoElementAssignment P) (hv : v ∈ V(G)) (he : G.Inc e v)
    (hs : s ∈ P e) : (G.paletteIncidenceSet P v s).encard = 2 := by
  refine (h.encard_eq_zero_or_eq_two hv s).resolve_left fun h0 ↦ ?_
  rw [Set.encard_eq_zero] at h0
  exact absurd (h0 ▸ (⟨he, hs⟩ : e ∈ G.paletteIncidenceSet P v s)) (Set.notMem_empty e)

/-- **A colour occurring at a vertex occurs on a second edge there**: colours come in pairs
at each vertex. -/
lemma IsTwoElementAssignment.exists_ne_inc_mem_palette
    (h : G.IsTwoElementAssignment P) (hv : v ∈ V(G)) (he : G.Inc e v)
    (hs : s ∈ P e) : ∃ f, f ≠ e ∧ G.Inc f v ∧ s ∈ P f := by
  obtain ⟨a, b, hab, hset⟩ := Set.encard_eq_two.1 (h.encard_eq_two_of_mem hv he hs)
  have ha : a ∈ G.paletteIncidenceSet P v s := by rw [hset]; exact Or.inl rfl
  have hb : b ∈ G.paletteIncidenceSet P v s := by rw [hset]; exact Or.inr rfl
  have hmem : e ∈ ({a, b} : Set β) := hset ▸ (⟨he, hs⟩ : e ∈ G.paletteIncidenceSet P v s)
  rcases hmem with rfl | rfl
  · exact ⟨b, Ne.symm hab, hb.1, hb.2⟩
  · exact ⟨a, hab, ha.1, ha.2⟩

/-- The incidence-count condition restated with `Set.ncard`. -/
lemma IsTwoElementAssignment.ncard_mem
    (h : G.IsTwoElementAssignment P) (hv : v ∈ V(G)) (s : Gamma) :
    (G.paletteIncidenceSet P v s).ncard ∈ ({0, 2} : Set ℕ) := by
  rcases h.encard_eq_zero_or_eq_two hv s with hc | hc <;> rw [Set.ncard_def, hc] <;> simp

/-! ## Junk-independence

The predicate only inspects `P` on `E(G)`, so two assignments agreeing on `E(G)` are
interchangeable. -/

lemma paletteIncidenceSet_congr (G : Graph α β) (v : α) (s : Gamma)
    (hPQ : ∀ e ∈ E(G), P e = Q e) :
    G.paletteIncidenceSet P v s = G.paletteIncidenceSet Q v s := by
  ext e
  simp only [Graph.mem_paletteIncidenceSet, and_congr_right_iff]
  exact fun he ↦ by rw [hPQ e (he.edge_mem)]

lemma isTwoElementAssignment_congr (G : Graph α β) (hPQ : ∀ e ∈ E(G), P e = Q e) :
    G.IsTwoElementAssignment P ↔ G.IsTwoElementAssignment Q := by
  have key : ∀ (R S : β → Set Gamma), (∀ e ∈ E(G), R e = S e) →
      G.IsTwoElementAssignment R → G.IsTwoElementAssignment S := by
    refine fun R S hRS h ↦ ⟨fun e he ↦ ?_, fun v hv s ↦ ?_⟩
    · rw [← hRS e he]; exact h.encard_palette e he
    · rw [← Graph.paletteIncidenceSet_congr G v s hRS]
      exact h.encard_paletteIncidenceSet v hv s
  exact ⟨key P Q hPQ, key Q P fun e he ↦ (hPQ e he).symm⟩

end Graph

/-!
# The linear system `L` of Lemma 2.2

Formalises the linear-algebraic core of Lemma 2.2:

> `L : Γ^{V(G)} ⊕ 𝔽₂^{E(G)} ⟶ Γ^{E(G)}`,  `L(t, ε)_e = t_u + t_v + ε_e f(e)`  (`e = uv`),

so that the system (4), `t_u + t_v + ε_e f(e) = d_e`, is solvable exactly when `d` belongs to
`im L`. `SystemL G` bundles the two `Γ`-valued edge functions `flow` (the paper's `f`) and `rhs`
(the paper's `d`); the structure carries no axioms, and `L`, `HasSolution` and the bridge
between them are definitions and lemmas.

Design points, each justified by a lemma below:
* The codomain is `↥E(G) → Γ` (the paper's `Γ^{E(G)}`), not `β → Γ`, so `d ∈ im L` imposes no
  spurious condition on non-edges.
* The domain uses total functions `(α → Γ) × (β → 𝔽₂)`; only their restrictions to `V(G)`/`E(G)`
  affect `L` (`L_congr`), so the range is unchanged.
* `t_u + t_v` is the symmetric ends sum `∑ᶠ w ∈ {w | G.Inc e w}, t w`, equal to `t u + t v` for
  distinct ends (`L_apply_of_isLink`); the ends set is always finite (`setOf_inc_finite`), so no
  finiteness hypothesis on `G` is needed.
-/

open Set Function
open scoped Graph
open Workspace.Types.Gamma
open Workspace.Types.LocalShift

namespace Workspace.Types.SystemL

open Workspace.Types.SystemL

variable {α β : Type*} {G : Graph α β} {e : β} {u v : α}

/-! ## The set of ends of an edge is finite -/

/-- The set of ends of an edge is always finite: it is empty when `e ∉ E(G)`, and is the
(at most two element) pair of ends of `e` otherwise.  This is what makes the ends sum
`∑ᶠ w ∈ {w | G.Inc e w}, t w` additive and `𝔽₂`-homogeneous in `t` with **no** finiteness
hypothesis on `G`. -/
lemma setOf_inc_finite (G : Graph α β) (e : β) : {w | G.Inc e w}.Finite := by
  by_cases he : e ∈ E(G)
  · obtain ⟨x, y, h⟩ := Graph.exists_isLink_of_mem_edgeSet he
    rw [LocalShift.setOf_inc_eq_pair h]
    exact (Set.finite_singleton y).insert x
  · have hemp : {w | G.Inc e w} = (∅ : Set α) := by
      ext w
      simp only [Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false]
      exact fun hw => he hw.edge_mem
    rw [hemp]
    exact Set.finite_empty

/-! ## The data of the system -/

/-- The data of the paper's linear system (4) on a multigraph `G`: the edge function `f`
(`flow`) appearing in the term `ε_e f(e)`, and the right-hand side `d` (`rhs`).

No axioms: the map `L`, the solvability predicate `HasSolution` and the bridge between them
are definitions and lemmas on this data.  In particular `flow` is *not* required to be a flow
and `rhs` is *not* required to arise from a local shift — those are hypotheses of the lemmas
that use the system, not part of what it means to write the system down. -/
@[ext]
structure SystemL (G : Graph α β) where
  /-- The paper's `f`: the `Γ`-valued edge function in the term `ε_e f(e)`. -/
  flow : β → Gamma
  /-- The paper's `d`: the right-hand side of the system (4). -/
  rhs : β → Gamma

namespace SystemL

variable (Sys : SystemL G)

/-! ## The map `L` -/

/-- **The paper's map `L : Γ^{V(G)} ⊕ 𝔽₂^{E(G)} ⟶ Γ^{E(G)}`**, `L(t, ε)_e = t_u + t_v + ε_e f(e)`
(`e = uv`), as a bundled `𝔽₂`-linear map. The codomain is indexed by `↥E(G)`, the ends sum is
symmetric, and additivity/homogeneity hold unconditionally since the ends set is finite. -/
noncomputable def L : ((α → Gamma) × (β → F2)) →ₗ[F2] (↥E(G) → Gamma) where
  toFun p := fun e : ↥E(G) =>
    (∑ᶠ w ∈ {w | G.Inc (e : β) w}, p.1 w) + p.2 (e : β) • Sys.flow (e : β)
  map_add' p q := by
    funext e
    simp only [Prod.fst_add, Prod.snd_add, Pi.add_apply]
    rw [finsum_mem_add_distrib (setOf_inc_finite G (e : β)), add_smul]
    abel
  map_smul' c p := by
    funext e
    simp only [Prod.smul_fst, Prod.smul_snd, Pi.smul_apply, RingHom.id_apply, smul_add,
      smul_eq_mul]
    rw [← smul_finsum_mem (setOf_inc_finite G (e : β)), mul_smul]

/-- The defining formula for `L`: `L(t, ε)_e = (∑ over the ends w of e, t w) + ε_e • f(e)`. -/
@[simp]
lemma L_apply (p : (α → Gamma) × (β → F2)) (e : ↥E(G)) :
    Sys.L p e = (∑ᶠ w ∈ {w | G.Inc (e : β) w}, p.1 w) + p.2 (e : β) • Sys.flow (e : β) :=
  rfl

/-- **`L` in the paper's notation.** For an edge `e` with distinct ends `u ≠ v` (automatic when
`G` is loopless), `L(t, ε)_e = t_u + t_v + ε_e f(e)`. -/
lemma L_apply_of_isLink (p : (α → Gamma) × (β → F2)) (e : ↥E(G))
    (h : G.IsLink (e : β) u v) (hne : u ≠ v) :
    Sys.L p e = p.1 u + p.1 v + p.2 (e : β) • Sys.flow (e : β) := by
  rw [L_apply, LocalShift.setOf_inc_eq_pair h, finsum_mem_pair hne]

/-- **Justification for using total functions on the domain.** The value of `L` depends only on
the restriction of `t` to `V(G)` and of `ε` to `E(G)`; hence taking the domain to be
`(α → Γ) × (β → 𝔽₂)` rather than `(↥V(G) → Γ) × (↥E(G) → 𝔽₂)` does not change the range of
`L`, and so does not change the meaning of `rhs ∈ range L`. -/
lemma L_congr (p q : (α → Gamma) × (β → F2)) (ht : ∀ v ∈ V(G), p.1 v = q.1 v)
    (hε : ∀ e ∈ E(G), p.2 e = q.2 e) : Sys.L p = Sys.L q := by
  funext e
  rw [L_apply, L_apply, hε (e : β) e.2]
  congr 1
  exact finsum_mem_congr rfl fun w hw => ht w (Graph.Inc.vertex_mem hw)

/-! ## Solvability of the system (4) -/

/-- **The system (4).** `HasSolution` says that there are `t : V(G) → Γ` and `ε : E(G) → 𝔽₂`
(given here as total functions, cf. `L_congr`) with

  `t_u + t_v + ε_e f(e) = d_e`   for every **edge** `e = uv` of `G`.

Note the quantifier is over `e ∈ E(G)` only — no condition is imposed at `e ∉ E(G)`.  This is
the statement of the paper's Lemma 2.2. -/
def HasSolution : Prop :=
  ∃ t : α → Gamma, ∃ ε : β → F2,
    ∀ e ∈ E(G), (∑ᶠ w ∈ {w | G.Inc e w}, t w) + ε e • Sys.flow e = Sys.rhs e

lemma hasSolution_def :
    Sys.HasSolution ↔ ∃ t : α → Gamma, ∃ ε : β → F2,
      ∀ e ∈ E(G), (∑ᶠ w ∈ {w | G.Inc e w}, t w) + ε e • Sys.flow e = Sys.rhs e :=
  Iff.rfl

/-- The right-hand side `d` of the system, viewed as an element of the codomain `Γ^{E(G)}`
of `L`. -/
def rhsOn : ↥E(G) → Gamma := Set.restrict E(G) Sys.rhs

@[simp]
lemma rhsOn_apply (e : ↥E(G)) : Sys.rhsOn e = Sys.rhs (e : β) := rfl

/-- **The bridging lemma.** "(4) asks whether `d = (d_e)_e` belongs to `im L`": the system (4)
is solvable exactly when the restriction of `d` to `E(G)` lies in the range of `L`. -/
theorem hasSolution_iff_mem_range :
    Sys.HasSolution ↔ Sys.rhsOn ∈ LinearMap.range Sys.L := by
  constructor
  · rintro ⟨t, ε, h⟩
    refine ⟨(t, ε), ?_⟩
    funext e
    exact h (e : β) e.2
  · rintro ⟨⟨t, ε⟩, h⟩
    exact ⟨t, ε, fun e he => congrFun h ⟨e, he⟩⟩

/-- The paper's phrasing, with `im L` written as a `Submodule`. -/
theorem hasSolution_iff_mem_range_map :
    Sys.HasSolution ↔ Sys.rhsOn ∈ Set.range (Sys.L : ((α → Gamma) × (β → F2)) → (↥E(G) → Gamma)) :=
  Sys.hasSolution_iff_mem_range

/-! ## The system arising from a local shift

In the paper the system (4) is set up with `f` a nowhere-zero `Γ`-flow and `d` the
edge-difference `d_e = g_{u,e} + g_{v,e}` of the local shift built from `f` and a local
ordering.  This is the corresponding `SystemL`. -/

/-- The system (4) attached to a local shift `S`: take `f = S.flow` and `d = S.d`. -/
noncomputable def ofLocalShift (S : LocalShift G) : SystemL G where
  flow := S.flow
  rhs := S.d

@[simp]
lemma ofLocalShift_flow (S : LocalShift G) : (ofLocalShift S).flow = S.flow := rfl

@[simp]
lemma ofLocalShift_rhs (S : LocalShift G) : (ofLocalShift S).rhs = S.d := rfl

end SystemL

end Workspace.Types.SystemL

/-!
# Tutte's group-flow theorem — foundational infrastructure

Graph/flow infrastructure for the group-flow theorem:

* **Flow count** `flowCount G O Γ : ℕ` — the number of nowhere-zero `Γ`-flows of `G`
  w.r.t. `O`, counted as *normalized* flows (nowhere-zero on `E(G)`, vanishing off it, so
  each observable flow has one representative), together with finiteness (`flowSet_finite`).
  This is the `n(G, Γ)` of the paper.

* **Edge deletion** `G − e := G.deleteEdges {e}` (a thin wrapper on Mathlib's
  `Graph.deleteEdges`), with its basic API.

* **Edge contraction** `contract G e x y` — `Graph α β` has no contraction operation, so it is
  defined from scratch via the vertex-merge map `y ↦ x` (keeping the vertex type `α`, so the
  whole flow API applies unchanged), with the flow correspondence driving the
  deletion–contraction recurrence (Lemma I.1.1).

* **Orientation reversal at one edge** and the **reverse-and-negate bijection** (Lemma B0):
  flipping one edge and negating its flow value is an involutive bijection on nowhere-zero
  flows, so flow existence and the flow count are orientation-independent.
-/

open Graph Workspace.Types.Orientation
open scoped Graph

namespace Workspace.PriorWorkProofs.Tutte

variable {α β : Type*} {G : Graph α β} {O : Orientation G}

/-! ## The flow count `n(G, Γ)` -/

/-- The set of **normalized** nowhere-zero `Γ`-flows of `G` w.r.t. `O`: flows that are
nowhere-zero on `E(G)` *and* vanish off `E(G)`. The off-edge normalization pins the
unobservable junk values of a total map `β → Γ`, making the count finite and giving one
canonical representative per observable flow. -/
def flowSet (G : Graph α β) (O : Orientation G) (Γ : Type*) [AddCommGroup Γ] : Set (β → Γ) :=
  {f | G.IsFlow O f ∧ G.IsNowhereZero f ∧ ∀ e ∉ E(G), f e = 0}

/-- The **flow count** `n(G, Γ)`: the number of nowhere-zero `Γ`-flows of `G` w.r.t. `O`
(counted as normalized flows). -/
noncomputable def flowCount (G : Graph α β) (O : Orientation G) (Γ : Type*) [AddCommGroup Γ] : ℕ :=
  Nat.card ↥(flowSet G O Γ)

/-- **Finiteness of the flow set** (foundational). If `G` has finitely many edges and `Γ`
is finite, the set of normalized nowhere-zero `Γ`-flows is finite. Proof: restriction to
`E(G)` injects `flowSet` into the finite type `↥E(G) → Γ`, because two normalized flows
that agree on `E(G)` agree everywhere (both vanish off `E(G)`). -/
theorem flowSet_finite {Γ : Type*} [AddCommGroup Γ] [Finite Γ] (hE : E(G).Finite) :
    (flowSet G O Γ).Finite := by
  haveI : Finite ↥E(G) := hE.to_subtype
  rw [← Set.finite_coe_iff]
  refine Finite.of_injective
    (fun F : ↥(flowSet G O Γ) => (fun e : ↥E(G) => (F : β → Γ) e.1)) ?_
  rintro ⟨f, hf⟩ ⟨g, hg⟩ h
  apply Subtype.ext
  funext e
  by_cases he : e ∈ E(G)
  · exact congrFun h ⟨e, he⟩
  · exact (hf.2.2 e he).trans (hg.2.2 e he).symm

instance flowSet_finite_inst {Γ : Type*} [AddCommGroup Γ] [Finite Γ] [hE : Fact E(G).Finite] :
    Finite ↥(flowSet G O Γ) :=
  Set.finite_coe_iff.mpr (flowSet_finite hE.out)

/-- **Lemma I.2 (empty base case).** If `G` has no edges then the flow count is `1`: the
only normalized flow is the zero map (which is vacuously a nowhere-zero flow). -/
theorem flowCount_empty {Γ : Type*} [AddCommGroup Γ] (hE : E(G) = ∅) :
    flowCount G O Γ = 1 := by
  have hset : flowSet G O Γ = {(0 : β → Γ)} := by
    ext f
    simp only [flowSet, Set.mem_setOf_eq, Set.mem_singleton_iff]
    constructor
    · rintro ⟨_, _, h3⟩
      funext e
      exact h3 e (by rw [hE]; exact Set.notMem_empty e)
    · rintro rfl
      refine ⟨G.isFlow_zero O, ?_, fun _ _ => rfl⟩
      intro e he
      rw [hE] at he
      exact absurd he (Set.notMem_empty e)
  unfold flowCount
  rw [hset]
  simp

/-! ## Edge deletion `G − e`

Mathlib provides `Graph.deleteEdges G F`. We specialize it to a single edge and record the
basic API used by the deletion–contraction recurrence. -/

/-- `deleteEdge G e = G − e`: delete the single edge `e` from `G`. -/
abbrev deleteEdge (G : Graph α β) (e : β) : Graph α β := G.deleteEdges {e}

@[simp] lemma deleteEdge_le (e : β) : deleteEdge G e ≤ G := Graph.deleteEdges_le

/-- The vertex set is unchanged by edge deletion. -/
@[simp] lemma vertexSet_deleteEdge (e : β) : V(deleteEdge G e) = V(G) := by
  simp [deleteEdge]

/-- The edge set of `G − e` is `E(G) \ {e}`. -/
@[simp] lemma edgeSet_deleteEdge (e : β) : E(deleteEdge G e) = E(G) \ {e} := by
  simp [deleteEdge]

/-- Incidence of an edge `e' ≠ e` is unchanged by deleting `e`. -/
lemma deleteEdge_isLink_of_ne {e e' : β} {x y : α} (hne : e' ≠ e) :
    (deleteEdge G e).IsLink e' x y ↔ G.IsLink e' x y := by
  simp [deleteEdge, hne]

/-- An orientation of `G` restricts to an orientation of `G − e`. -/
def deleteEdgeOrientation (O : Orientation G) (e : β) : Orientation (deleteEdge G e) :=
  O.restrict Graph.deleteEdges_le

/-! ## Edge contraction `G / e`

Mathlib's `Graph α β` has **no** edge-contraction operation. We define contraction of a
non-loop edge `e = xy` by *merging* `y` into `x` via the vertex map `m : α → α`,
`m z = if z = x' then y' else z`… concretely we merge `y` into `x` (map `y ↦ x`, identity
elsewhere) and drop the edge `e`. Keeping the vertex type `α` means every downstream notion
(orientations, flows, the flow count) applies to `contract G e x y` with no re-derivation. -/

section Contract
variable [DecidableEq α]

/-- The vertex-merge map underlying contraction: send `y` to `x`, fix everything else. -/
def mergeMap (x y : α) : α → α := fun z => if z = y then x else z

@[simp] lemma mergeMap_self (x y : α) : mergeMap x y y = x := by simp [mergeMap]

lemma mergeMap_of_ne (x : α) {y z : α} (h : z ≠ y) : mergeMap x y z = z := by
  simp [mergeMap, h]

/-- **Edge contraction** `G / e`, contracting the (non-loop) edge `e` with ends `x, y` by
identifying `y` with `x`. Every edge other than `e` is kept, with its ends pushed through the
merge map `mergeMap x y`; parallel copies of `e` become loops, as contraction requires. -/
@[simps isLink]
def contract (G : Graph α β) (e : β) (x y : α) : Graph α β where
  vertexSet := (mergeMap x y) '' V(G)
  IsLink e' a b :=
    e' ≠ e ∧ ∃ a' b', G.IsLink e' a' b' ∧ mergeMap x y a' = a ∧ mergeMap x y b' = b
  isLink_symm := by
    rintro e' _ a b ⟨hne, a', b', hL, ha, hb⟩
    exact ⟨hne, b', a', hL.symm, hb, ha⟩
  eq_or_eq_of_isLink_of_isLink := by
    rintro e' a b v w ⟨_, a', b', hL, ha, hb⟩ ⟨_, v', w', hL', hv, hw⟩
    rcases hL.left_eq_or_eq hL' with h | h
    · left; rw [← ha, ← hv, h]
    · right; rw [← ha, ← hw, h]
  left_mem_of_isLink := by
    rintro e' a b ⟨_, a', b', hL, ha, _⟩
    exact ⟨a', hL.left_mem, ha⟩

@[simp] lemma vertexSet_contract (e : β) (x y : α) :
    V(contract G e x y) = (mergeMap x y) '' V(G) := rfl

/-- The edge set of `G / e` is `E(G) \ {e}`. -/
@[simp] lemma edgeSet_contract (e : β) (x y : α) :
    E(contract G e x y) = E(G) \ {e} := by
  ext e'
  rw [Graph.edgeSet_eq_setOf_exists_isLink]
  simp only [Set.mem_setOf_eq, contract_isLink, Set.mem_diff, Set.mem_singleton_iff]
  constructor
  · rintro ⟨a, b, hne, a', b', hL, -, -⟩
    exact ⟨hL.edge_mem, hne⟩
  · rintro ⟨he'G, hne⟩
    obtain ⟨a', b', hL⟩ := G.exists_isLink_of_mem_edgeSet he'G
    exact ⟨_, _, hne, a', b', hL, rfl, rfl⟩

/-- The orientation `O` of `G` induces an orientation of `G / e` by pushing tails and heads
through the merge map. -/
def contractOrientation (O : Orientation G) (e : β) (x y : α) :
    Orientation (contract G e x y) where
  tail e' := mergeMap x y (O.tail e')
  head e' := mergeMap x y (O.head e')
  isLink_tail_head e' he' := by
    rw [edgeSet_contract] at he'
    obtain ⟨he'G, hne⟩ := he'
    exact ⟨by simpa using hne, O.tail e', O.head e', O.isLink_tail_head he'G, rfl, rfl⟩

/-! ### Deletion–contraction: supporting development

The lemmas below build the deletion–contraction recurrence `contract_flow_correspondence`.
They require decidable equality on the edge type `β` (for `Function.update` and `Finset`
operations); the final theorem does not, obtaining an instance via `Classical`. -/

section ContractFlowAux
variable [DecidableEq β]

/-- The intermediate set `S`: maps satisfying Kirchhoff everywhere, nowhere-zero on `E(G) \ {e}`,
value at `e` free, normalized to vanish off `E(G)`. -/
def SSet (G : Graph α β) (O : Orientation G) (e : β) (Γ : Type*) [AddCommGroup Γ] :
    Set (β → Γ) :=
  {f | G.IsFlow O f ∧ (∀ e' ∈ E(G), e' ≠ e → f e' ≠ 0) ∧ (∀ e' ∉ E(G), f e' = 0)}

/-- `S` is finite: restriction to `E(G)` injects it into the finite type `↥E(G) → Γ`. -/
theorem SSet_finite {Γ : Type*} [AddCommGroup Γ] [Finite Γ] (hE : E(G).Finite) (e : β) :
    (SSet G O e Γ).Finite := by
  haveI : Finite ↥E(G) := hE.to_subtype
  rw [← Set.finite_coe_iff]
  refine Finite.of_injective
    (fun F : ↥(SSet G O e Γ) => (fun ee : ↥E(G) => (F : β → Γ) ee.1)) ?_
  rintro ⟨f, hf⟩ ⟨g, hg⟩ h
  apply Subtype.ext
  funext ee
  by_cases he : ee ∈ E(G)
  · exact congrFun h ⟨ee, he⟩
  · exact (hf.2.2 ee he).trans (hg.2.2 ee he).symm

/-- **P2.** The elements of `S` with `f e ≠ 0` are exactly the nowhere-zero flows of `G`. -/
theorem SSet_ne_eq_flowSet {Γ : Type*} [AddCommGroup Γ] (e : β) (heG : e ∈ E(G)) :
    {f ∈ SSet G O e Γ | f e ≠ 0} = flowSet G O Γ := by
  ext f
  simp only [SSet, flowSet, Set.mem_setOf_eq, Set.mem_sep_iff]
  constructor
  · rintro ⟨⟨hflow, hnz, hoff⟩, hfe⟩
    refine ⟨hflow, ?_, hoff⟩
    intro e' he'
    by_cases h : e' = e
    · rw [h]; exact hfe
    · exact hnz e' he' h
  · rintro ⟨hflow, hnz, hoff⟩
    exact ⟨⟨hflow, fun e' he' _ => hnz e' he', hoff⟩, hnz e heG⟩

lemma deleteEdgeOrientation_tail (e : β) : (deleteEdgeOrientation O e).tail = O.tail := rfl
lemma deleteEdgeOrientation_head (e : β) : (deleteEdgeOrientation O e).head = O.head := rfl

/-- If `f` vanishes at `e`, being a flow on `G` is the same as being a flow on `G - e`. -/
theorem isFlow_deleteEdge_of_zero {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β)
    {f : β → Γ} (hfe : f e = 0) :
    G.IsFlow O f ↔ (deleteEdge G e).IsFlow (deleteEdgeOrientation O e) f := by
  have hE' : E(deleteEdge G e).Finite := by rw [edgeSet_deleteEdge]; exact hE.diff
  have hsub : hE'.toFinset ⊆ hE.toFinset := by
    intro a ha
    rw [Set.Finite.mem_toFinset] at ha ⊢
    rw [edgeSet_deleteEdge] at ha
    exact ha.1
  have key : ∀ (t : β → α) (v : α),
      (∑ a ∈ hE'.toFinset with t a = v, f a) = ∑ a ∈ hE.toFinset with t a = v, f a := by
    intro t v
    apply Finset.sum_subset (Finset.filter_subset_filter _ hsub)
    intro a ha hna
    simp only [Finset.mem_filter] at ha
    have hnotmem : a ∉ hE'.toFinset := fun hmem => hna (Finset.mem_filter.mpr ⟨hmem, ha.2⟩)
    rw [Set.Finite.mem_toFinset, edgeSet_deleteEdge] at hnotmem
    rw [Set.Finite.mem_toFinset] at ha
    have hae : a = e := by
      by_contra hne
      exact hnotmem ⟨ha.1, by simp [hne]⟩
    rw [hae]; exact hfe
  rw [Graph.isFlow_iff_finset_sum hE, Graph.isFlow_iff_finset_sum hE',
    deleteEdgeOrientation_tail, deleteEdgeOrientation_head, vertexSet_deleteEdge]
  refine forall_congr' fun v => imp_congr_right fun _ => ?_
  rw [key O.tail v, key O.head v]

/-- **P3.** The elements of `S` with `f e = 0` are exactly the nowhere-zero flows of `G - e`. -/
theorem SSet_eq_eq_flowSet_deleteEdge {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β) :
    {f ∈ SSet G O e Γ | f e = 0}
      = flowSet (deleteEdge G e) (deleteEdgeOrientation O e) Γ := by
  ext f
  simp only [SSet, flowSet, Graph.IsNowhereZero, Set.mem_setOf_eq, Set.mem_sep_iff,
    edgeSet_deleteEdge, Set.mem_diff, Set.mem_singleton_iff]
  constructor
  · rintro ⟨⟨hflow, hnz, hoff⟩, hfe⟩
    refine ⟨(isFlow_deleteEdge_of_zero hE e hfe).mp hflow, ?_, ?_⟩
    · intro e' he'
      exact hnz e' he'.1 he'.2
    · intro e' he'
      by_cases hmem : e' ∈ E(G)
      · have : e' = e := by tauto
        rw [this]; exact hfe
      · exact hoff e' hmem
  · rintro ⟨hflow, hnz, hoff⟩
    have hfe : f e = 0 := hoff e (by simp)
    refine ⟨⟨(isFlow_deleteEdge_of_zero hE e hfe).mpr hflow, ?_, ?_⟩, hfe⟩
    · intro e' he'G he'ne
      exact hnz e' ⟨he'G, he'ne⟩
    · intro e' he'
      exact hoff e' (by tauto)

/-- **P4.** Partition of the finite set `S` by the predicate `f e = 0`. -/
theorem SSet_card_split {Γ : Type*} [AddCommGroup Γ] [Finite Γ] (hE : E(G).Finite) (e : β) :
    Nat.card ↥(SSet G O e Γ)
      = Nat.card ↥{f ∈ SSet G O e Γ | f e ≠ 0} + Nat.card ↥{f ∈ SSet G O e Γ | f e = 0} := by
  have hfin := SSet_finite (O := O) hE e (Γ := Γ)
  have hunion : SSet G O e Γ
      = {f ∈ SSet G O e Γ | f e ≠ 0} ∪ {f ∈ SSet G O e Γ | f e = 0} := by
    ext f; simp only [Set.mem_union, Set.mem_sep_iff]; tauto
  have hdisj : Disjoint {f ∈ SSet G O e Γ | f e ≠ 0} {f ∈ SSet G O e Γ | f e = 0} := by
    rw [Set.disjoint_left]; rintro f ⟨_, h1⟩ ⟨_, h2⟩; exact h1 h2
  rw [Nat.card_coe_set_eq, Nat.card_coe_set_eq, Nat.card_coe_set_eq]
  conv_lhs => rw [hunion]
  rw [Set.ncard_union_eq hdisj (hfin.subset (Set.sep_subset _ _))
    (hfin.subset (Set.sep_subset _ _))]

/-- Fact (i): the vertex set of `G / e` is `V(G) \ {y}`. -/
lemma vertexSet_contract_eq {x y : α} (hxV : x ∈ V(G)) (hne : x ≠ y) (e : β) :
    V(contract G e x y) = V(G) \ {y} := by
  rw [vertexSet_contract]
  ext w
  simp only [Set.mem_image, Set.mem_diff, Set.mem_singleton_iff]
  constructor
  · rintro ⟨v, hv, rfl⟩
    by_cases h : v = y
    · subst h; rw [mergeMap_self]; exact ⟨hxV, hne⟩
    · rw [mergeMap_of_ne _ h]; exact ⟨hv, h⟩
  · rintro ⟨hw, hwy⟩
    exact ⟨w, hw, mergeMap_of_ne _ hwy⟩

/-- The `toFinset` of `E(G) \ {e}` is the erasure of `e` from `hE.toFinset`. -/
lemma toFinset_diff_singleton (e : β) (hE : E(G).Finite) (hE'' : (E(G) \ {e}).Finite) :
    hE''.toFinset = hE.toFinset.erase e := by
  ext a
  simp only [Set.Finite.mem_toFinset, Set.mem_diff, Set.mem_singleton_iff, Finset.mem_erase]
  tauto

/-- Filtered sums of a map vanishing at `e` are unchanged by erasing `e` from the index set. -/
lemma sum_filter_erase_of_zero {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β)
    {h : β → Γ} (he0 : h e = 0) (p : β → Prop) [DecidablePred p] :
    (∑ a ∈ hE.toFinset.erase e with p a, h a) = ∑ a ∈ hE.toFinset with p a, h a := by
  apply Finset.sum_subset (Finset.filter_subset_filter _ (Finset.erase_subset _ _))
  intro a ha hna
  simp only [Finset.mem_filter, Finset.mem_erase] at ha hna
  have : a = e := by tauto
  rw [this]; exact he0

/-- `mergeMap x y u = x` iff `u ∈ {x, y}`. -/
lemma mergeMap_eq_left_iff {x y u : α} (hne : x ≠ y) :
    mergeMap x y u = x ↔ u = x ∨ u = y := by
  unfold mergeMap; split_ifs with h
  · subst h; simp
  · simp [h]

/-- For `w ∉ {x, y}`, `mergeMap x y u = w` iff `u = w`. -/
lemma mergeMap_eq_of_ne {x y w u : α} (hwx : w ≠ x) (hwy : w ≠ y) :
    mergeMap x y u = w ↔ u = w := by
  unfold mergeMap; split_ifs with h
  · subst h
    constructor
    · intro h2; exact (hwx h2.symm).elim
    · intro h2; exact (hwy h2.symm).elim
  · exact Iff.rfl

/-- The reconstruction value `r` forcing Kirchhoff at `x` for the extended map. -/
noncomputable def rval {Γ : Type*} [AddCommGroup Γ] (O : Orientation G) (hE : E(G).Finite)
    (e : β) (x : α) (g : β → Γ) : Γ :=
  if O.tail e = x
  then (∑ e' ∈ hE.toFinset with O.head e' = x, g e') - (∑ e' ∈ hE.toFinset with O.tail e' = x, g e')
  else (∑ e' ∈ hE.toFinset with O.tail e' = x, g e') - (∑ e' ∈ hE.toFinset with O.head e' = x, g e')

lemma contractOrientation_tail (e : β) (x y : α) (e' : β) :
    (contractOrientation O e x y).tail e' = mergeMap x y (O.tail e') := rfl

lemma contractOrientation_head (e : β) (x y : α) (e' : β) :
    (contractOrientation O e x y).head e' = mergeMap x y (O.head e') := rfl

/-- Bridge: a filtered sum of `Function.update g e r` equals the `g`-sum plus `r` at `e`. -/
lemma sum_filter_update_eq {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β)
    (heG : e ∈ E(G)) {g : β → Γ} (hge : g e = 0) (r : Γ) (q : β → Prop) [DecidablePred q] :
    (∑ e' ∈ hE.toFinset with q e', (Function.update g e r) e')
      = (∑ e' ∈ hE.toFinset with q e', g e') + (if q e then r else 0) := by
  have step : ∀ e' ∈ hE.toFinset.filter q,
      Function.update g e r e' = g e' + (if e' = e then r else 0) := by
    intro e' _
    by_cases h : e' = e
    · subst h; rw [Function.update_self, hge]; simp
    · rw [Function.update_of_ne h]; simp [h]
  rw [Finset.sum_congr rfl step, Finset.sum_add_distrib]
  congr 1
  rw [Finset.sum_ite_eq' (hE.toFinset.filter q) e (fun _ => r)]
  simp only [Finset.mem_filter, Set.Finite.mem_toFinset, heG, true_and]

/-- Bridge: a filtered sum of `Function.update f e 0` equals the `f`-sum minus `f e` at `e`. -/
lemma sum_filter_update_zero_eq {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β)
    (heG : e ∈ E(G)) (f : β → Γ) (q : β → Prop) [DecidablePred q] :
    (∑ e' ∈ hE.toFinset with q e', (Function.update f e 0) e')
      = (∑ e' ∈ hE.toFinset with q e', f e') - (if q e then f e else 0) := by
  have step : ∀ e' ∈ hE.toFinset.filter q,
      Function.update f e 0 e' = f e' + (if e' = e then - f e else 0) := by
    intro e' _
    by_cases h : e' = e
    · subst h; rw [Function.update_self]; simp
    · rw [Function.update_of_ne h]; simp [h]
  rw [Finset.sum_congr rfl step, Finset.sum_add_distrib,
    Finset.sum_ite_eq' (hE.toFinset.filter q) e (fun _ => - f e)]
  simp only [Finset.mem_filter, Set.Finite.mem_toFinset, heG, true_and]
  by_cases hq : q e <;> simp [hq, sub_eq_add_neg]

/-- Split a `mergeMap`-filtered sum at the merge target `x` into the `x`- and `y`-parts. -/
lemma sum_filter_mergeMap_left {Γ : Type*} [AddCommGroup Γ] (s : Finset β) (t : β → α)
    {x y : α} (hne : x ≠ y) (g : β → Γ) :
    (∑ e' ∈ s with mergeMap x y (t e') = x, g e')
      = (∑ e' ∈ s with t e' = x, g e') + (∑ e' ∈ s with t e' = y, g e') := by
  have hdisj : Disjoint (s.filter (fun e' => t e' = x)) (s.filter (fun e' => t e' = y)) := by
    rw [Finset.disjoint_left]
    intro a ha hb
    simp only [Finset.mem_filter] at ha hb
    exact hne (ha.2.symm.trans hb.2)
  have hfilter : s.filter (fun e' => mergeMap x y (t e') = x)
      = s.filter (fun e' => t e' = x) ∪ s.filter (fun e' => t e' = y) := by
    rw [← Finset.filter_or]
    apply Finset.filter_congr
    intro e' _
    exact mergeMap_eq_left_iff hne
  rw [hfilter, Finset.sum_union hdisj]

/-- For `w ∉ {x, y}`, the `mergeMap`-filtered sum is the plain filtered sum. -/
lemma sum_filter_mergeMap_other {Γ : Type*} [AddCommGroup Γ] (s : Finset β) (t : β → α)
    {x y w : α} (hwx : w ≠ x) (hwy : w ≠ y) (g : β → Γ) :
    (∑ e' ∈ s with mergeMap x y (t e') = w, g e') = ∑ e' ∈ s with t e' = w, g e' := by
  apply Finset.sum_congr _ (fun _ _ => rfl)
  apply Finset.filter_congr
  intro e' _
  exact mergeMap_eq_of_ne hwx hwy

/-- The contract edge finset is the erasure of `e`. -/
lemma toFinset_edgeSet_contract (e : β) (x y : α) (hE : E(G).Finite)
    (hE'' : E(contract G e x y).Finite) : hE''.toFinset = hE.toFinset.erase e := by
  ext a
  simp only [Set.Finite.mem_toFinset, edgeSet_contract, Set.mem_diff, Set.mem_singleton_iff,
    Finset.mem_erase]
  tauto

/-- Reduction of the contraction flow condition to `mergeMap`-filtered sums over `hE.toFinset`. -/
lemma contract_flow_iff_sums {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β) (x y : α)
    {g : β → Γ} (hge : g e = 0) :
    (contract G e x y).IsFlow (contractOrientation O e x y) g
      ↔ ∀ w ∈ V(contract G e x y),
          (∑ e' ∈ hE.toFinset with mergeMap x y (O.tail e') = w, g e')
            = ∑ e' ∈ hE.toFinset with mergeMap x y (O.head e') = w, g e' := by
  have hE'' : E(contract G e x y).Finite := by rw [edgeSet_contract]; exact hE.diff
  rw [Graph.isFlow_iff_finset_sum hE'']
  simp only [contractOrientation_tail, contractOrientation_head]
  rw [toFinset_edgeSet_contract e x y hE hE'']
  apply forall_congr'; intro w
  simp only [sum_filter_erase_of_zero hE e hge]
  exact Iff.rfl

/-- **Core flow equivalence.** For `g` vanishing at `e`, `g` is a flow of `G / e` iff the
extension `update g e r` (with `r = rval`) is a flow of `G`. -/
lemma flow_update_iff {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β) (x y : α)
    (hxy : G.IsLink e x y) (hne : x ≠ y) {g : β → Γ} (hge : g e = 0) :
    (contract G e x y).IsFlow (contractOrientation O e x y) g
      ↔ G.IsFlow O (Function.update g e (rval O hE e x g)) := by
  classical
  have heG : e ∈ E(G) := hxy.edge_mem
  have hxV : x ∈ V(G) := hxy.left_mem
  rw [contract_flow_iff_sums hE e x y hge, Graph.isFlow_iff_finset_sum hE,
      vertexSet_contract_eq hxV hne]
  set R := rval O hE e x g with hR
  have hxy' := O.eq_and_eq_or_eq_and_eq hxy
  have htail_mem : O.tail e = x ∨ O.tail e = y := by
    rcases hxy' with ⟨a, _⟩ | ⟨a, _⟩
    · exact Or.inl a
    · exact Or.inr a
  have hhead_mem : O.head e = x ∨ O.head e = y := by
    rcases hxy' with ⟨_, b⟩ | ⟨_, b⟩
    · exact Or.inr b
    · exact Or.inl b
  have hIT : (if O.tail e = x then R else 0) + (if O.tail e = y then R else 0) = R := by
    rcases htail_mem with h | h <;> rw [h] <;> simp [hne, Ne.symm hne]
  have hIH : (if O.head e = x then R else 0) + (if O.head e = y then R else 0) = R := by
    rcases hhead_mem with h | h <;> rw [h] <;> simp [hne, Ne.symm hne]
  have hTvanish : ∀ v, v ≠ x → v ≠ y → (if O.tail e = v then R else 0) = 0 := by
    intro v hvx hvy
    rcases htail_mem with h | h <;> rw [h] <;> [exact if_neg (fun hc => hvx hc.symm);
      exact if_neg (fun hc => hvy hc.symm)]
  have hHvanish : ∀ v, v ≠ x → v ≠ y → (if O.head e = v then R else 0) = 0 := by
    intro v hvx hvy
    rcases hhead_mem with h | h <;> rw [h] <;> [exact if_neg (fun hc => hvx hc.symm);
      exact if_neg (fun hc => hvy hc.symm)]
  have kx : (∑ e' ∈ hE.toFinset with O.tail e' = x, g e')
              + (if O.tail e = x then R else 0)
            = (∑ e' ∈ hE.toFinset with O.head e' = x, g e')
              + (if O.head e = x then R else 0) := by
    rcases hxy' with ⟨ht, hh⟩ | ⟨ht, hh⟩
    · rw [ht, hh, if_pos rfl, if_neg (Ne.symm hne), hR]
      simp only [rval]
      rw [if_pos ht]; abel
    · rw [ht, hh, if_neg (Ne.symm hne), if_pos rfl, hR]
      simp only [rval]
      rw [if_neg (by rw [ht]; exact Ne.symm hne)]; abel
  constructor
  · intro hL v hv
    rw [sum_filter_update_eq hE e heG hge R (fun e' => O.tail e' = v),
        sum_filter_update_eq hE e heG hge R (fun e' => O.head e' = v)]
    by_cases hvx : v = x
    · rw [hvx]; exact kx
    by_cases hvy : v = y
    · rw [hvy]
      have hmx := hL x (Set.mem_diff_singleton.mpr ⟨hxV, hne⟩)
      rw [sum_filter_mergeMap_left _ _ hne, sum_filter_mergeMap_left _ _ hne] at hmx
      have goalsub :
          ((∑ e' ∈ hE.toFinset with O.tail e' = y, g e') + (if O.tail e = y then R else 0))
            - ((∑ e' ∈ hE.toFinset with O.head e' = y, g e') + (if O.head e = y then R else 0))
          = (((∑ e' ∈ hE.toFinset with O.tail e' = x, g e')
                + (∑ e' ∈ hE.toFinset with O.tail e' = y, g e'))
              - ((∑ e' ∈ hE.toFinset with O.head e' = x, g e')
                + (∑ e' ∈ hE.toFinset with O.head e' = y, g e')))
            - (((∑ e' ∈ hE.toFinset with O.tail e' = x, g e') + (if O.tail e = x then R else 0))
                - ((∑ e' ∈ hE.toFinset with O.head e' = x, g e')
                  + (if O.head e = x then R else 0)))
            + ((if O.tail e = x then R else 0) + (if O.tail e = y then R else 0) - R)
            - ((if O.head e = x then R else 0) + (if O.head e = y then R else 0) - R) := by
        abel
      rw [← sub_eq_zero, goalsub, sub_eq_zero.mpr hmx, sub_eq_zero.mpr kx,
        sub_eq_zero.mpr hIT, sub_eq_zero.mpr hIH]
      abel
    · have hmv := hL v (Set.mem_diff_singleton.mpr ⟨hv, hvy⟩)
      rw [sum_filter_mergeMap_other _ _ hvx hvy, sum_filter_mergeMap_other _ _ hvx hvy] at hmv
      rw [hTvanish v hvx hvy, hHvanish v hvx hvy, add_zero, add_zero]
      exact hmv
  · intro hR2 w hw
    rw [Set.mem_diff_singleton] at hw
    obtain ⟨hwG, hwy⟩ := hw
    by_cases hwx : w = x
    · rw [hwx]
      rw [sum_filter_mergeMap_left _ _ hne, sum_filter_mergeMap_left _ _ hne]
      have hx := hR2 x hxV
      rw [sum_filter_update_eq hE e heG hge R (fun e' => O.tail e' = x),
          sum_filter_update_eq hE e heG hge R (fun e' => O.head e' = x)] at hx
      have hy := hR2 y (by
        rcases hxy' with ⟨_, hh⟩ | ⟨ht, _⟩
        · exact hh ▸ O.head_mem heG
        · exact ht ▸ O.tail_mem heG)
      rw [sum_filter_update_eq hE e heG hge R (fun e' => O.tail e' = y),
          sum_filter_update_eq hE e heG hge R (fun e' => O.head e' = y)] at hy
      have goalsub :
          ((∑ e' ∈ hE.toFinset with O.tail e' = x, g e')
              + (∑ e' ∈ hE.toFinset with O.tail e' = y, g e'))
            - ((∑ e' ∈ hE.toFinset with O.head e' = x, g e')
              + (∑ e' ∈ hE.toFinset with O.head e' = y, g e'))
          = (((∑ e' ∈ hE.toFinset with O.tail e' = x, g e') + (if O.tail e = x then R else 0))
                - ((∑ e' ∈ hE.toFinset with O.head e' = x, g e')
                  + (if O.head e = x then R else 0)))
            + (((∑ e' ∈ hE.toFinset with O.tail e' = y, g e') + (if O.tail e = y then R else 0))
                - ((∑ e' ∈ hE.toFinset with O.head e' = y, g e')
                  + (if O.head e = y then R else 0)))
            - ((if O.tail e = x then R else 0) + (if O.tail e = y then R else 0) - R)
            + ((if O.head e = x then R else 0) + (if O.head e = y then R else 0) - R) := by
        abel
      rw [← sub_eq_zero, goalsub, sub_eq_zero.mpr hx, sub_eq_zero.mpr hy,
        sub_eq_zero.mpr hIT, sub_eq_zero.mpr hIH]
      abel
    · rw [sum_filter_mergeMap_other _ _ hwx hwy, sum_filter_mergeMap_other _ _ hwx hwy]
      have hw2 := hR2 w hwG
      rw [sum_filter_update_eq hE e heG hge R (fun e' => O.tail e' = w),
          sum_filter_update_eq hE e heG hge R (fun e' => O.head e' = w),
          hTvanish w hwx hwy, hHvanish w hwx hwy, add_zero, add_zero] at hw2
      exact hw2

/-- For a flow `f`, the reconstruction value of `update f e 0` recovers `f e`. -/
lemma rval_update_zero_eq {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β) (x y : α)
    (hxy : G.IsLink e x y) (hne : x ≠ y) {f : β → Γ} (hf : G.IsFlow O f) :
    rval O hE e x (Function.update f e 0) = f e := by
  classical
  have heG : e ∈ E(G) := hxy.edge_mem
  have hxV : x ∈ V(G) := hxy.left_mem
  have hflowx := (Graph.isFlow_iff_finset_sum hE).mp hf x hxV
  unfold rval
  rw [sum_filter_update_zero_eq hE e heG f (fun e' => O.head e' = x),
      sum_filter_update_zero_eq hE e heG f (fun e' => O.tail e' = x)]
  rcases O.eq_and_eq_or_eq_and_eq hxy with ⟨ht, hh⟩ | ⟨ht, hh⟩
  · rw [if_pos ht, ht, hh, if_pos rfl, if_neg (Ne.symm hne), ← hflowx]; abel
  · rw [if_neg (by rw [ht]; exact Ne.symm hne), ht, hh, if_neg (Ne.symm hne), if_pos rfl,
      ← hflowx]; abel

/-- If `g` vanishes at `e`, updating it to `0` at `e` is the identity. -/
lemma update_zero_eq_self {Γ : Type*} [Zero Γ] {g : β → Γ} {e : β} (h : g e = 0) :
    Function.update g e 0 = g := by
  funext a; by_cases ha : a = e
  · subst ha; rw [Function.update_self]; exact h.symm
  · rw [Function.update_of_ne ha]

/-- The forward map lands in `S`. -/
lemma toS_mem {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β) (x y : α)
    (hxy : G.IsLink e x y) (hne : x ≠ y)
    {g : β → Γ} (hg : g ∈ flowSet (contract G e x y) (contractOrientation O e x y) Γ) :
    Function.update g e (rval O hE e x g) ∈ SSet G O e Γ := by
  obtain ⟨hflow, hnz, hoff⟩ := hg
  have heG : e ∈ E(G) := hxy.edge_mem
  have hge : g e = 0 := hoff e (by rw [edgeSet_contract, Set.mem_diff, Set.mem_singleton_iff]; simp)
  refine ⟨(flow_update_iff hE e x y hxy hne hge).mp hflow, ?_, ?_⟩
  · intro e' he'G he'ne
    rw [Function.update_of_ne he'ne]
    exact hnz e' (by rw [edgeSet_contract, Set.mem_diff, Set.mem_singleton_iff]; exact ⟨he'G, he'ne⟩)
  · intro e' he'
    have hne' : e' ≠ e := fun h => he' (h ▸ heG)
    rw [Function.update_of_ne hne']
    exact hoff e' (by rw [edgeSet_contract, Set.mem_diff, Set.mem_singleton_iff]; tauto)

/-- The inverse map lands in the flows of `G / e`. -/
lemma fromS_mem {Γ : Type*} [AddCommGroup Γ] (hE : E(G).Finite) (e : β) (x y : α)
    (hxy : G.IsLink e x y) (hne : x ≠ y) {f : β → Γ} (hf : f ∈ SSet G O e Γ) :
    Function.update f e 0 ∈ flowSet (contract G e x y) (contractOrientation O e x y) Γ := by
  obtain ⟨hflow, hnz, hoff⟩ := hf
  have heG : e ∈ E(G) := hxy.edge_mem
  have hge : (Function.update f e 0) e = 0 := by rw [Function.update_self]
  refine ⟨?_, ?_, ?_⟩
  · rw [flow_update_iff hE e x y hxy hne hge, rval_update_zero_eq hE e x y hxy hne hflow,
      Function.update_idem, Function.update_eq_self]
    exact hflow
  · intro e' he'
    rw [edgeSet_contract, Set.mem_diff, Set.mem_singleton_iff] at he'
    rw [Function.update_of_ne he'.2]
    exact hnz e' he'.1 he'.2
  · intro e' he'
    rw [edgeSet_contract, Set.mem_diff, Set.mem_singleton_iff] at he'
    by_cases h : e' = e
    · rw [h, Function.update_self]
    · rw [Function.update_of_ne h]
      exact hoff e' (fun hc => he' ⟨hc, h⟩)

/-- **P1 (the hard bijection).** The flow count of `G / e` equals `Nat.card S`. -/
theorem flowCount_contract_eq_card_SSet {Γ : Type*} [AddCommGroup Γ] [Finite Γ]
    (hE : E(G).Finite) (e : β) (x y : α) (hxy : G.IsLink e x y) (hne : x ≠ y) :
    flowCount (contract G e x y) (contractOrientation O e x y) Γ = Nat.card ↥(SSet G O e Γ) := by
  unfold flowCount
  apply Nat.card_congr
  refine {
    toFun := fun F => ⟨Function.update (F : β → Γ) e (rval O hE e x (F : β → Γ)),
      toS_mem hE e x y hxy hne F.2⟩
    invFun := fun F => ⟨Function.update (F : β → Γ) e 0, fromS_mem hE e x y hxy hne F.2⟩
    left_inv := ?_
    right_inv := ?_ }
  · rintro ⟨g, hg⟩
    apply Subtype.ext
    have hge : g e = 0 :=
      hg.2.2 e (by rw [edgeSet_contract, Set.mem_diff, Set.mem_singleton_iff]; simp)
    simp only [Function.update_idem]
    exact update_zero_eq_self hge
  · rintro ⟨f, hf⟩
    apply Subtype.ext
    simp only
    rw [rval_update_zero_eq hE e x y hxy hne hf.1, Function.update_idem, Function.update_eq_self]

end ContractFlowAux

/-- **Lemma I.1.1 (deletion–contraction).** For a non-loop edge `e = xy`, the nowhere-zero
`Γ`-flows of `G / e` are in bijection with the maps on `G` that satisfy Kirchhoff everywhere and
are nowhere-zero off `e` (the set `S = SSet` of the paper). Splitting `S` by whether `f e = 0`
yields the deletion–contraction recurrence
`flowCount (G/e) = flowCount G + flowCount (G − e)`. -/
theorem contract_flow_correspondence {Γ : Type*} [AddCommGroup Γ] [Finite Γ]
    (hE : E(G).Finite) (e : β) (x y : α) (hxy : G.IsLink e x y) (hne : x ≠ y) :
    flowCount (contract G e x y) (contractOrientation O e x y) Γ
      = flowCount G O Γ + flowCount (deleteEdge G e) (deleteEdgeOrientation O e) Γ := by
  classical
  have heG : e ∈ E(G) := hxy.edge_mem
  rw [flowCount_contract_eq_card_SSet hE e x y hxy hne, SSet_card_split hE e]
  unfold flowCount
  rw [← SSet_ne_eq_flowSet e heG, ← SSet_eq_eq_flowSet_deleteEdge hE e]

end Contract

/-! ## Orientation reversal at one edge (Lemma B0)

Reversing a single edge `e₀` and negating the flow value there is an involutive bijection
between nowhere-zero `Γ`-flows for the two orientations. Hence flow existence and the flow
count are orientation-independent. -/

section Reversal
variable [DecidableEq β]

/-- Reverse the orientation of the single edge `e₀`, leaving every other edge alone. -/
def reverseEdge (O : Orientation G) (e₀ : β) : Orientation G where
  tail e := if e = e₀ then O.head e₀ else O.tail e
  head e := if e = e₀ then O.tail e₀ else O.head e
  isLink_tail_head e he := by
    by_cases h : e = e₀
    · subst h; simpa using (O.isLink_tail_head he).symm
    · simpa [h] using O.isLink_tail_head he

@[simp] lemma reverseEdge_tail (e₀ e : β) :
    (reverseEdge O e₀).tail e = if e = e₀ then O.head e₀ else O.tail e := rfl

@[simp] lemma reverseEdge_head (e₀ e : β) :
    (reverseEdge O e₀).head e = if e = e₀ then O.tail e₀ else O.head e := rfl

@[simp] lemma reverseEdge_tail_self (e₀ : β) : (reverseEdge O e₀).tail e₀ = O.head e₀ := by
  simp [reverseEdge_tail]

@[simp] lemma reverseEdge_head_self (e₀ : β) : (reverseEdge O e₀).head e₀ = O.tail e₀ := by
  simp [reverseEdge_head]

/-- Reversing the same edge twice returns the original orientation. -/
@[simp] lemma reverseEdge_reverseEdge (O : Orientation G) (e₀ : β) :
    reverseEdge (reverseEdge O e₀) e₀ = O := by
  apply Orientation.ext <;> funext e <;> by_cases h : e = e₀ <;> simp [reverseEdge, h]

variable {Γ : Type*} [AddCommGroup Γ]

/-- **Reverse-and-negate** on flow values: negate the value at `e₀`, keep all others. -/
def twist (e₀ : β) (f : β → Γ) : β → Γ := fun e => if e = e₀ then -f e else f e

@[simp] lemma twist_self (e₀ : β) (f : β → Γ) : twist e₀ f e₀ = -f e₀ := by simp [twist]

lemma twist_of_ne {e₀ e : β} (f : β → Γ) (h : e ≠ e₀) : twist e₀ f e = f e := by
  simp [twist, h]

/-- `twist` is an involution. -/
@[simp] lemma twist_twist (e₀ : β) (f : β → Γ) : twist e₀ (twist e₀ f) = f := by
  funext e
  by_cases h : e = e₀ <;> simp [twist, h]

lemma twist_eq_zero_iff {e₀ e : β} (f : β → Γ) : twist e₀ f e = 0 ↔ f e = 0 := by
  by_cases h : e = e₀ <;> simp [twist, h]

/-- Reversing edge `e₀` and negating its value preserves the flow (conservation) property:
the loss of `f e₀` from one side of Kirchhoff's law at an endpoint of `e₀` is exactly matched
by the gain of `-f e₀` on the other side. This is the core of Lemma B0. -/
theorem isFlow_reverseEdge_twist_iff (hE : E(G).Finite) (e₀ : β) (f : β → Γ) :
    G.IsFlow (reverseEdge O e₀) (twist e₀ f) ↔ G.IsFlow O f := by
  classical
  rw [Graph.isFlow_iff_finset_sum hE, Graph.isFlow_iff_finset_sum hE]
  refine forall_congr' fun v => imp_congr_right fun _ => ?_
  have hnet :
      (∑ e ∈ hE.toFinset with (reverseEdge O e₀).tail e = v, twist e₀ f e)
        - (∑ e ∈ hE.toFinset with (reverseEdge O e₀).head e = v, twist e₀ f e)
      = (∑ e ∈ hE.toFinset with O.tail e = v, f e)
        - (∑ e ∈ hE.toFinset with O.head e = v, f e) := by
    simp only [Finset.sum_filter]
    rw [← sub_eq_zero]
    simp only [← Finset.sum_sub_distrib]
    apply Finset.sum_eq_zero
    intro e _
    by_cases h : e = e₀
    · subst h
      simp only [reverseEdge_tail_self, reverseEdge_head_self, twist_self]
      split_ifs <;> abel
    · simp only [reverseEdge_tail, reverseEdge_head, if_neg h, twist_of_ne f h]
      abel
  rw [← sub_eq_zero, hnet, sub_eq_zero]

/-- The `twist` of a normalized flow for `O` is a normalized flow for `reverseEdge O e₀`. -/
theorem twist_mem_flowSet (hE : E(G).Finite) (e₀ : β) {f : β → Γ}
    (hf : f ∈ flowSet G O Γ) : twist e₀ f ∈ flowSet G (reverseEdge O e₀) Γ := by
  obtain ⟨hflow, hnz, hoff⟩ := hf
  refine ⟨(isFlow_reverseEdge_twist_iff hE e₀ f).mpr hflow, ?_, ?_⟩
  · intro e he
    rw [Ne, twist_eq_zero_iff]
    exact hnz e he
  · intro e he
    rw [twist_eq_zero_iff]
    exact hoff e he

/-- **Lemma B0, count form.** The flow count is unchanged by reversing a single edge. -/
theorem flowCount_reverseEdge [Finite Γ] (hE : E(G).Finite) (e₀ : β) :
    flowCount G (reverseEdge O e₀) Γ = flowCount G O Γ := by
  apply Nat.card_congr
  exact
  { toFun := fun F => ⟨twist e₀ (F : β → Γ), by
      have := twist_mem_flowSet hE e₀ (O := reverseEdge O e₀) F.2
      rwa [reverseEdge_reverseEdge] at this⟩
    invFun := fun F => ⟨twist e₀ (F : β → Γ), twist_mem_flowSet hE e₀ F.2⟩
    left_inv := fun F => by apply Subtype.ext; simp
    right_inv := fun F => by apply Subtype.ext; simp }

/-!
# Tutte's group-flow theorem — Part I (deletion–contraction and group independence)

This file builds on `Workspace.PriorWorkProofs.Tutte.Basic` to prove:

* **Loop recurrence** (`flowCount_loop`): for a loop `e` at `x`,
  `flowCount G O Γ = (Nat.card Γ − 1) · flowCount (G−e) … Γ`.
* **Group independence, folded route** (`flowCount_eq_of_card_eq`): by strong induction on
  `E(G).ncard`, `Nat.card Γ = Nat.card Γ′ ⇒ flowCount G O Γ = flowCount G O′ Γ′`.
* **Corollary I.4** (`exists_flow_iff_of_card_eq`, `exists_flow_iff_zmod`): existence of a
  nowhere-zero `Γ`-flow depends only on `|Γ|`; in particular a nowhere-zero `A`-flow exists iff
  a nowhere-zero `(ZMod k)`-flow exists when `Nat.card A = k`.

The non-loop deletion–contraction recurrence is `contract_flow_correspondence` from `Basic`.
-/

open Graph Workspace.Types.Orientation
open scoped Graph

namespace Workspace.PriorWorkProofs.Tutte

variable {α β : Type*} {G : Graph α β} {O : Orientation G}

/-! ## Loop recurrence (Lemma I.1.2) -/

section Loop

variable {Γ : Type*} [AddCommGroup Γ]

/-- Updating a map at the deleted edge `e` does not affect being a flow of `G − e`, since the
edge `e` is not in `E(G − e)` and so never appears in any conservation sum. -/
theorem isFlow_deleteEdge_update_iff [DecidableEq β] (e : β) (g : β → Γ) (c : Γ) :
    (deleteEdge G e).IsFlow (deleteEdgeOrientation O e) (Function.update g e c) ↔
      (deleteEdge G e).IsFlow (deleteEdgeOrientation O e) g := by
  have hupd : ∀ (t : β → α) (v : α),
      (∑ᶠ e' ∈ {e' ∈ E(deleteEdge G e) | t e' = v}, Function.update g e c e')
        = ∑ᶠ e' ∈ {e' ∈ E(deleteEdge G e) | t e' = v}, g e' := by
    intro t v
    apply finsum_mem_congr rfl
    intro e' he'
    have : e' ∈ E(deleteEdge G e) := he'.1
    rw [edgeSet_deleteEdge] at this
    exact Function.update_of_ne this.2 _ _
  unfold Graph.IsFlow Graph.outSum Graph.inSum Graph.outEdgeSet Graph.inEdgeSet
  constructor <;> intro h v hv <;>
    · have := h v hv
      simpa only [hupd] using this

/-- **Loop flow-equivalence.** If `e` is a loop at `x`, then a map `f` is a flow of `G` iff it is
a flow of `G − e`: the loop contributes `f e` to both the out- and in-sums at `x`, cancelling. -/
theorem isFlow_deleteEdge_loop_iff [DecidableEq α] (hE : E(G).Finite) {e : β} {x : α}
    (hloop : G.IsLoopAt e x) (f : β → Γ) :
    (deleteEdge G e).IsFlow (deleteEdgeOrientation O e) f ↔ G.IsFlow O f := by
  classical
  have hE' : E(deleteEdge G e).Finite := by rw [edgeSet_deleteEdge]; exact hE.diff
  have hsub : E(deleteEdge G e) ⊆ E(G) := by rw [edgeSet_deleteEdge]; exact Set.diff_subset
  have htail : O.tail e = x := O.tail_eq_of_isLoopAt hloop
  have hhead : O.head e = x := O.head_eq_of_isLoopAt hloop
  have heG : e ∈ E(G) := hloop.edge_mem
  have hsetdiff : hE'.toFinset = hE.toFinset \ {e} := by
    ext a
    simp only [Set.Finite.mem_toFinset, edgeSet_deleteEdge, Set.mem_diff, Set.mem_singleton_iff,
      Finset.mem_sdiff, Finset.mem_singleton]
  rw [Graph.isFlow_iff_finset_sum hE', Graph.isFlow_iff_finset_sum hE]
  have hVeq : V(deleteEdge G e) = V(G) := vertexSet_deleteEdge e
  rw [hVeq]
  refine forall_congr' fun v => imp_congr_right fun _ => ?_
  -- Tail/head functions agree with `O`.
  have htaileq : ∀ e', (deleteEdgeOrientation O e).tail e' = O.tail e' := fun _ => rfl
  have hheadeq : ∀ e', (deleteEdgeOrientation O e).head e' = O.head e' := fun _ => rfl
  simp only [htaileq, hheadeq, hsetdiff]
  -- Split each `G`-sum: `∑ over (s), if p then f = (if p e then f e else 0) + ∑ over (s\{e})`.
  have key : ∀ (t : β → α),
      (∑ e' ∈ hE.toFinset with t e' = v, f e')
        = (if t e = v then f e else 0) + ∑ e' ∈ hE.toFinset \ {e} with t e' = v, f e' := by
    intro t
    rw [Finset.sum_filter, Finset.sum_filter]
    have he_mem : e ∈ hE.toFinset := by rw [Set.Finite.mem_toFinset]; exact heG
    rw [← Finset.sum_erase_add _ _ he_mem, Finset.erase_eq, add_comm]
  rw [key O.tail, key O.head, htail, hhead]
  constructor
  · intro h; rw [h]
  · intro h; exact add_left_cancel h

/-- The number of nonzero elements of a finite additive group is `Nat.card Γ − 1`. -/
theorem card_ne_zero (Γ : Type*) [AddGroup Γ] [Finite Γ] :
    Nat.card {γ : Γ // γ ≠ (0 : Γ)} = Nat.card Γ - 1 := by
  classical
  have : Fintype Γ := Fintype.ofFinite Γ
  rw [Nat.card_eq_fintype_card, Nat.card_eq_fintype_card, Fintype.card_subtype_compl]
  simp

/-- **Loop recurrence (Lemma I.1.2).** For a loop `e` at `x`,
`flowCount G O Γ = (Nat.card Γ − 1) · flowCount (G − e) … Γ`.

The flows of `G` are in bijection with pairs `(g, γ)` where `g` is a flow of `G − e` and
`γ ≠ 0` is the free value on the loop. -/
theorem flowCount_loop [DecidableEq α] [DecidableEq β] [Finite Γ]
    (hE : E(G).Finite) {e : β} {x : α} (hloop : G.IsLoopAt e x) :
    flowCount G O Γ
      = (Nat.card Γ - 1) * flowCount (deleteEdge G e) (deleteEdgeOrientation O e) Γ := by
  classical
  have heG : e ∈ E(G) := hloop.edge_mem
  set Gd := deleteEdge G e
  set Od := deleteEdgeOrientation O e
  have hEdmem : ∀ e', e' ∈ E(Gd) ↔ e' ∈ E(G) ∧ e' ≠ e := by
    intro e'; simp [Gd]
  -- membership: forward first component
  have hfwd1 : ∀ F : ↥(flowSet G O Γ), Function.update (F : β → Γ) e 0 ∈ flowSet Gd Od Γ := by
    rintro ⟨f, hflow, hnz, hoff⟩
    refine ⟨?_, ?_, ?_⟩
    · rw [isFlow_deleteEdge_update_iff]
      exact ((isFlow_deleteEdge_loop_iff hE hloop f).mpr hflow)
    · intro e' he'
      rw [hEdmem] at he'
      rw [Function.update_of_ne he'.2]
      exact hnz e' he'.1
    · intro e' he'
      rw [hEdmem, not_and_or, not_not] at he'
      by_cases hee : e' = e
      · rw [hee, Function.update_self]
      · rw [Function.update_of_ne hee]
        exact hoff e' (by tauto)
  -- membership: inverse
  have hinv : ∀ (P : ↥(flowSet Gd Od Γ) × {γ : Γ // γ ≠ (0:Γ)}),
      Function.update (P.1 : β → Γ) e (P.2 : Γ) ∈ flowSet G O Γ := by
    rintro ⟨⟨g, hgflow, hgnz, hgoff⟩, ⟨γ, hγ⟩⟩
    have hge : g e = 0 := hgoff e (by rw [hEdmem]; tauto)
    refine ⟨?_, ?_, ?_⟩
    · rw [← isFlow_deleteEdge_loop_iff hE hloop, isFlow_deleteEdge_update_iff]
      exact hgflow
    · intro e' he'
      by_cases hee : e' = e
      · rw [hee, Function.update_self]; exact hγ
      · rw [Function.update_of_ne hee]
        exact hgnz e' (by rw [hEdmem]; exact ⟨he', hee⟩)
    · intro e' he'
      have hee : e' ≠ e := by rintro rfl; exact he' heG
      rw [Function.update_of_ne hee]
      exact hgoff e' (by rw [hEdmem]; tauto)
  have hbij : Nat.card ↥(flowSet G O Γ)
      = Nat.card ↥(flowSet Gd Od Γ) * Nat.card {γ : Γ // γ ≠ (0:Γ)} := by
    rw [← Nat.card_prod]
    apply Nat.card_congr
    exact {
      toFun := fun F => (⟨Function.update (F : β → Γ) e 0, hfwd1 F⟩, ⟨(F : β → Γ) e,
        (F.2.2.1 e heG)⟩)
      invFun := fun P => ⟨Function.update (P.1 : β → Γ) e (P.2 : Γ), hinv P⟩
      left_inv := by
        rintro ⟨f, hf⟩
        apply Subtype.ext
        simp [Function.update_idem]
      right_inv := by
        rintro ⟨⟨g, hgflow, hgnz, hgoff⟩, ⟨γ, hγ⟩⟩
        have hge : g e = 0 := hgoff e (by rw [hEdmem]; tauto)
        apply Prod.ext
        · apply Subtype.ext
          simp [Function.update_idem, hge]
        · apply Subtype.ext
          simp }
  rw [flowCount, flowCount, hbij, card_ne_zero, mul_comm]

end Loop

/-! ## Group independence, folded route (Theorem I.3 / Corollary I.4) -/

section Independence

/-- Being a flow depends only on the values of the map on `E(G)`. -/
theorem isFlow_congr_on_edgeSet {Γ : Type*} [AddCommGroup Γ] {f g : β → Γ}
    (h : ∀ e ∈ E(G), f e = g e) : G.IsFlow O f ↔ G.IsFlow O g := by
  have hsum : ∀ (t : β → α) (v : α),
      (∑ᶠ e ∈ {e ∈ E(G) | t e = v}, f e) = ∑ᶠ e ∈ {e ∈ E(G) | t e = v}, g e := by
    intro t v
    exact finsum_mem_congr rfl fun e he => h e he.1
  unfold Graph.IsFlow Graph.outSum Graph.inSum Graph.outEdgeSet Graph.inEdgeSet
  constructor <;> intro hh v hv <;> · have := hh v hv; simpa only [hsum] using this

/-- Existence of a nowhere-zero `Γ`-flow is equivalent to the (normalized) flow set being
nonempty: any flow can be normalized to vanish off `E(G)` without changing its behaviour. -/
theorem flowSet_nonempty_iff {Γ : Type*} [AddCommGroup Γ] :
    (flowSet G O Γ).Nonempty ↔ ∃ f : β → Γ, G.IsFlow O f ∧ G.IsNowhereZero f := by
  classical
  constructor
  · rintro ⟨f, hflow, hnz, -⟩
    exact ⟨f, hflow, hnz⟩
  · rintro ⟨f, hflow, hnz⟩
    refine ⟨E(G).indicator f, ?_, ?_, ?_⟩
    · rw [isFlow_congr_on_edgeSet (f := E(G).indicator f) (g := f)]
      · exact hflow
      · intro e he; exact Set.indicator_of_mem he f
    · intro e he
      rw [Set.indicator_of_mem he f]; exact hnz e he
    · intro e he; exact Set.indicator_of_notMem he f

/-- Positivity of the flow count is equivalent to the existence of a nowhere-zero flow. -/
theorem flowCount_pos_iff {Γ : Type*} [AddCommGroup Γ] [Finite Γ] (hE : E(G).Finite) :
    0 < flowCount G O Γ ↔ ∃ f : β → Γ, G.IsFlow O f ∧ G.IsNowhereZero f := by
  rw [← flowSet_nonempty_iff]
  have hfin : (flowSet G O Γ).Finite := flowSet_finite hE
  rw [flowCount]
  constructor
  · intro h
    have : Nonempty ↥(flowSet G O Γ) := (Nat.card_pos_iff.mp h).1
    exact Set.nonempty_coe_sort.mp this
  · intro h
    haveI : Finite ↥(flowSet G O Γ) := hfin.to_subtype
    haveI : Nonempty ↥(flowSet G O Γ) := Set.nonempty_coe_sort.mpr h
    exact Nat.card_pos

/-- **Group independence, auxiliary form.** Strong induction on the number of edges: if
`Nat.card Γ = Nat.card Γ′` then the flow counts agree, for any orientations. -/
private theorem flowCount_eq_aux [DecidableEq α] :
    ∀ (n : ℕ) {G : Graph α β} (_hE : E(G).Finite) (_hn : E(G).ncard = n)
      (O O' : Orientation G) {Γ Γ' : Type*} [AddCommGroup Γ] [Finite Γ]
      [AddCommGroup Γ'] [Finite Γ'] (_hc : Nat.card Γ = Nat.card Γ'),
      flowCount G O Γ = flowCount G O' Γ' := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n IH =>
    intro G hE hn O O' Γ Γ' _ _ _ _ hc
    classical
    rcases Set.eq_empty_or_nonempty E(G) with hEmpty | ⟨e, heG⟩
    · rw [flowCount_empty hEmpty, flowCount_empty hEmpty]
    · obtain ⟨x, y, hxy⟩ := G.exists_isLink_of_mem_edgeSet heG
      by_cases hloop : x = y
      · subst hloop
        have hloopAt : G.IsLoopAt e x := hxy
        have hlt : E(deleteEdge G e).ncard < n := by
          rw [edgeSet_deleteEdge, ← hn]
          exact Set.ncard_diff_singleton_lt_of_mem heG hE
        have hEd : E(deleteEdge G e).Finite := by rw [edgeSet_deleteEdge]; exact hE.diff
        rw [flowCount_loop hE hloopAt, flowCount_loop hE hloopAt, hc]
        congr 1
        exact IH (E(deleteEdge G e).ncard) hlt hEd rfl
          (deleteEdgeOrientation O e) (deleteEdgeOrientation O' e) hc
      · have hlt1 : E(contract G e x y).ncard < n := by
          rw [edgeSet_contract, ← hn]
          exact Set.ncard_diff_singleton_lt_of_mem heG hE
        have hlt2 : E(deleteEdge G e).ncard < n := by
          rw [edgeSet_deleteEdge, ← hn]
          exact Set.ncard_diff_singleton_lt_of_mem heG hE
        have hEc : E(contract G e x y).Finite := by rw [edgeSet_contract]; exact hE.diff
        have hEd : E(deleteEdge G e).Finite := by rw [edgeSet_deleteEdge]; exact hE.diff
        have hrecΓ := contract_flow_correspondence (O := O) (Γ := Γ) hE e x y hxy hloop
        have hrecΓ' := contract_flow_correspondence (O := O') (Γ := Γ') hE e x y hxy hloop
        have ih_c : flowCount (contract G e x y) (contractOrientation O e x y) Γ
                  = flowCount (contract G e x y) (contractOrientation O' e x y) Γ' :=
          IH (E(contract G e x y).ncard) hlt1 hEc rfl
            (contractOrientation O e x y) (contractOrientation O' e x y) hc
        have ih_d : flowCount (deleteEdge G e) (deleteEdgeOrientation O e) Γ
                  = flowCount (deleteEdge G e) (deleteEdgeOrientation O' e) Γ' :=
          IH (E(deleteEdge G e).ncard) hlt2 hEd rfl
            (deleteEdgeOrientation O e) (deleteEdgeOrientation O' e) hc
        have key : flowCount G O Γ + flowCount (deleteEdge G e) (deleteEdgeOrientation O e) Γ
                 = flowCount G O' Γ' + flowCount (deleteEdge G e) (deleteEdgeOrientation O e) Γ := by
          rw [← hrecΓ, ih_c, hrecΓ', ih_d]
        exact Nat.add_right_cancel key

/-- **Group independence (folded route).** If `Nat.card Γ = Nat.card Γ′`, then the flow counts
of `G` agree, for any orientations `O, O′`. Proved by strong induction on `E(G).ncard`. -/
theorem flowCount_eq_of_card_eq [DecidableEq α] (hE : E(G).Finite) (O O' : Orientation G)
    {Γ Γ' : Type*} [AddCommGroup Γ] [Finite Γ] [AddCommGroup Γ'] [Finite Γ']
    (hc : Nat.card Γ = Nat.card Γ') : flowCount G O Γ = flowCount G O' Γ' :=
  flowCount_eq_aux E(G).ncard hE rfl O O' hc

/-- **Corollary I.4.** Existence of a nowhere-zero `Γ`-flow depends only on `|Γ|`. -/
theorem exists_flow_iff_of_card_eq [DecidableEq α] (hE : E(G).Finite) (O O' : Orientation G)
    {Γ Γ' : Type*} [AddCommGroup Γ] [Finite Γ] [AddCommGroup Γ'] [Finite Γ']
    (hc : Nat.card Γ = Nat.card Γ') :
    (∃ f : β → Γ, G.IsFlow O f ∧ G.IsNowhereZero f)
      ↔ (∃ f : β → Γ', G.IsFlow O' f ∧ G.IsNowhereZero f) := by
  rw [← flowCount_pos_iff hE, ← flowCount_pos_iff hE, flowCount_eq_of_card_eq hE O O' hc]

/-- **Corollary I.4, `ZMod k` bridge.** With `Nat.card A = k`, a nowhere-zero `A`-flow exists iff
a nowhere-zero `(ZMod k)`-flow exists (w.r.t. the same orientation `O`). This is the exact bridge
the final assembly consumes. -/
theorem exists_flow_iff_zmod [DecidableEq α] {A : Type*} [AddCommGroup A] [Finite A] {k : ℕ}
    [NeZero k] (hE : E(G).Finite) (O : Orientation G) (hA : Nat.card A = k) :
    (∃ f : β → A, G.IsFlow O f ∧ G.IsNowhereZero f)
      ↔ (∃ f : β → ZMod k, G.IsFlow O f ∧ G.IsNowhereZero f) := by
  have hcard : Nat.card A = Nat.card (ZMod k) := by rw [hA, Nat.card_zmod]
  exact exists_flow_iff_of_card_eq hE O O hcard

end Independence

end Workspace.PriorWorkProofs.Tutte

/-!
# Tutte's group-flow theorem, Part II — the ℤ/k ⇔ integer k-flow equivalence

This file proves **Theorem II.1** of the group-flow theorem: for `k ≥ 1` and a finite
multigraph `G` with a fixed orientation `O`,

  `G` has a nowhere-zero `(ℤ/k)`-flow  ⟺  `G` has a nowhere-zero integer `k`-flow.

It is independent of Part I (the deletion–contraction / group-independence half).

## Structure

* `IntFlowReducesToZk` (Lemma 8, the easy `⇐`): reducing an integer `k`-flow mod `k`
  gives a nowhere-zero `(ℤ/k)`-flow.
* `ZkFlowLiftsToIntFlow` (Lemmas 9–11, the hard `⇒`): the finite-descent construction of
  an integer `k`-flow from a `(ℤ/k)`-flow.
* `zk_iff_int_k_flow` (Lemma 12): the equivalence, assembled from the two directions.
-/

open Graph Workspace.Types.Orientation
open scoped Graph

namespace Workspace.PriorWorkProofs.Tutte

variable {α β : Type*} {G : Graph α β} {O : Orientation G}

/-! ## Lemma 8 (`IntFlowReducesToZk`): mod-`k` reduction of an integer `k`-flow

`Int.cast : ℤ → ZMod k` is an additive homomorphism, so it pushes through the Kirchhoff
out/in sums; and `0 < |φ e| < k` forces `(φ e : ZMod k) ≠ 0`. -/

/-- **Lemma 8 (⇐ direction).** If `φ` is an integer `k`-flow of `G` w.r.t. `O`, then its
mod-`k` reduction `e ↦ (φ e : ZMod k)` is a nowhere-zero `(ℤ/k)`-flow of `G` w.r.t. `O`. -/
theorem IntFlowReducesToZk {k : ℕ} (hE : E(G).Finite) (O : Orientation G)
    (φ : β → ℤ) (hφ : G.IsIntegerKFlow O φ (k : ℤ)) :
    G.IsFlow O (fun e => ((φ e : ZMod k))) ∧ G.IsNowhereZero (fun e => ((φ e : ZMod k))) := by
  classical
  obtain ⟨hflow, hbound⟩ := hφ
  refine ⟨?_, ?_⟩
  · rw [Graph.isFlow_iff_finset_sum hE]
    rw [Graph.isFlow_iff_finset_sum hE] at hflow
    intro v hv
    have hv' := hflow v hv
    calc (∑ e ∈ hE.toFinset with O.tail e = v, ((φ e : ZMod k)))
        = (((∑ e ∈ hE.toFinset with O.tail e = v, φ e : ℤ)) : ZMod k) := by
            rw [Int.cast_sum]
      _ = (((∑ e ∈ hE.toFinset with O.head e = v, φ e : ℤ)) : ZMod k) := by rw [hv']
      _ = (∑ e ∈ hE.toFinset with O.head e = v, ((φ e : ZMod k))) := by rw [Int.cast_sum]
  · intro e he
    simp only
    rw [Ne, ZMod.intCast_zmod_eq_zero_iff_dvd]
    intro hdvd
    have h1 : 0 < |φ e| := (hbound e he).1
    have h2 : |φ e| < (k : ℤ) := (hbound e he).2
    have hk : (k : ℤ) ∣ |φ e| := (dvd_abs _ _).mpr hdvd
    have := Int.le_of_dvd h1 hk
    omega

/-! ## Lemma B0′ (`IntFlowOrientationReversal`): single-edge reversal invariance

Reversing one edge `e₀` and negating its value (`twist`) sends an integer `k`-flow to an
integer `k`-flow for the reversed orientation: conservation is preserved by
`isFlow_reverseEdge_twist_iff`, and `|−x| = |x|` keeps the bound `0 < |·| < k`. -/

/-- **Lemma B0′ (single-edge form).** `twist e₀ φ` is an integer `k`-flow for `reverseEdge O e₀`
whenever `φ` is one for `O`. -/
theorem IntFlowReverseEdgeInvariance [DecidableEq β] {k : ℤ} (hE : E(G).Finite) (e₀ : β)
    (φ : β → ℤ) (hφ : G.IsIntegerKFlow O φ k) :
    G.IsIntegerKFlow (reverseEdge O e₀) (twist e₀ φ) k := by
  obtain ⟨hflow, hb⟩ := hφ
  refine ⟨(isFlow_reverseEdge_twist_iff hE e₀ φ).mpr hflow, ?_⟩
  intro e he
  have habs : |twist e₀ φ e| = |φ e| := by
    by_cases h : e = e₀ <;> simp [twist, h, abs_neg]
  rw [habs]
  exact hb e he

/-! ## Lemma 9 (`ZkFlowRepresentativeClaim`): positive integer representatives

Take `g e := (f e).val : ℤ`, the canonical representative in `[0, k-1]`. Since `f` is
nowhere-zero, `(f e).val ≠ 0`, so `g e ∈ [1, k-1]`, and `g e ≡ f e (mod k)` by construction. -/

/-- The canonical positive integer representative of a `(ZMod k)`-valued map: `e ↦ (f e).val`. -/
def zkRep {k : ℕ} (f : β → ZMod k) : β → ℤ := fun e => ((f e).val : ℤ)

/-- **Lemma 9.** For a nowhere-zero `(ℤ/k)`-flow `f` (`k ≥ 1`), the representative `zkRep f`
takes values in `[1, k-1]` on every edge and reduces mod `k` back to `f`. -/
theorem ZkFlowRepresentativeClaim {k : ℕ} (hk : 1 ≤ k) (f : β → ZMod k)
    (hnz : G.IsNowhereZero f) (e : β) (he : e ∈ E(G)) :
    1 ≤ zkRep f e ∧ zkRep f e ≤ (k : ℤ) - 1 ∧ ((zkRep f e : ℤ) : ZMod k) = f e := by
  haveI : NeZero k := ⟨by omega⟩
  have hval_lt : (f e).val < k := ZMod.val_lt (f e)
  have hne : f e ≠ 0 := hnz e he
  have hval_ne : (f e).val ≠ 0 := fun h => hne ((ZMod.val_eq_zero (f e)).mp h)
  refine ⟨?_, ?_, ?_⟩
  · simp only [zkRep]; omega
  · simp only [zkRep]; omega
  · simp only [zkRep]
    push_cast
    exact ZMod.natCast_zmod_val (f e)

/-! ## Integer imbalance and its mod-`k` vanishing (Lemma 9, second half)

The integer imbalance `b(v) := (out-sum of g at v) − (in-sum of g at v)`. For `g = zkRep f`
with `f` a `(ℤ/k)`-flow, every `b(v)` is a multiple of `k`, because `g` reduces to `f` mod `k`
on `E(G)` and `f` conserves at every vertex. -/

/-- The integer imbalance of `g` at `v`: net out-flow `out-sum − in-sum`. -/
noncomputable def imbalance (O : Orientation G) (g : β → ℤ) (v : α) : ℤ :=
  G.outSum O g v - G.inSum O g v

/-- **Lemma 9 (imbalance ≡ 0 (mod k)).** For a nowhere-zero `(ℤ/k)`-flow `f`, the integer
imbalance of `zkRep f` at any vertex is divisible by `k`. -/
theorem imbalance_dvd {k : ℕ} (hk : 1 ≤ k) (hE : E(G).Finite) (O : Orientation G)
    (f : β → ZMod k) (hflow : G.IsFlow O f) (hnz : G.IsNowhereZero f) (v : α) (hv : v ∈ V(G)) :
    (k : ℤ) ∣ imbalance O (zkRep f) v := by
  rw [← ZMod.intCast_zmod_eq_zero_iff_dvd]
  have hout : ((G.outSum O (zkRep f) v : ℤ) : ZMod k) = G.outSum O f v := by
    rw [Graph.outSum_eq_finset_sum hE, Graph.outSum_eq_finset_sum hE, Int.cast_sum]
    refine Finset.sum_congr rfl fun e he => ?_
    rw [Set.Finite.mem_toFinset] at he
    exact (ZkFlowRepresentativeClaim hk f hnz e (Graph.outEdgeSet_subset_edgeSet he)).2.2
  have hin : ((G.inSum O (zkRep f) v : ℤ) : ZMod k) = G.inSum O f v := by
    rw [Graph.inSum_eq_finset_sum hE, Graph.inSum_eq_finset_sum hE, Int.cast_sum]
    refine Finset.sum_congr rfl fun e he => ?_
    rw [Set.Finite.mem_toFinset] at he
    exact (ZkFlowRepresentativeClaim hk f hnz e (Graph.inEdgeSet_subset_edgeSet he)).2.2
  simp only [imbalance, Int.cast_sub, hout, hin]
  rw [sub_eq_zero]
  exact hflow v hv

/-! ## Rerouting infrastructure for the finite-descent construction (Lemmas 9–11)

The following private development proves `ZkFlowLiftsToIntFlow` by the fixed-orientation
`g ↦ g − k` reroute: positive/negative integer representatives with `|g e| ∈ [1,k-1]`, a
sign-oriented reachability, a telescoping reroute that strictly decreases `Φ := ∑_v |b(v)|`,
and a finite descent to `Φ = 0`. -/

section Bal
variable [DecidableEq α]

/-- Integer imbalance in finite-sum form. -/
private noncomputable def bal (O : Orientation G) (hE : E(G).Finite) (g : β → ℤ) (v : α) : ℤ :=
  (∑ e ∈ hE.toFinset with O.tail e = v, g e) - (∑ e ∈ hE.toFinset with O.head e = v, g e)

/-- Single-edge update change to `bal`. -/
private lemma bal_update [DecidableEq β] (hE : E(G).Finite) (g : β → ℤ) (e₀ : β) (he₀ : e₀ ∈ E(G))
    (c : ℤ) (p : α) :
    bal O hE (Function.update g e₀ c) p
      = bal O hE g p
        + (if O.tail e₀ = p then c - g e₀ else 0)
        - (if O.head e₀ = p then c - g e₀ else 0) := by
  have hmem : e₀ ∈ hE.toFinset := (Set.Finite.mem_toFinset hE).mpr he₀
  have key : ∀ (t : β → α),
      (∑ e ∈ hE.toFinset with t e = p, Function.update g e₀ c e)
        = (∑ e ∈ hE.toFinset with t e = p, g e) + (if t e₀ = p then c - g e₀ else 0) := by
    intro t
    have step : ∀ e ∈ hE.toFinset.filter (fun e => t e = p),
        Function.update g e₀ c e = g e + (if e = e₀ then c - g e₀ else 0) := by
      intro e _
      by_cases h : e = e₀
      · subst h; rw [Function.update_self, if_pos rfl]; ring
      · rw [Function.update_of_ne h, if_neg h, add_zero]
    rw [Finset.sum_congr rfl step, Finset.sum_add_distrib,
      Finset.sum_ite_eq' (hE.toFinset.filter (fun e => t e = p)) e₀ (fun _ => c - g e₀)]
    congr 1
    by_cases ht : t e₀ = p
    · rw [if_pos (by simp [Finset.mem_filter, hmem, ht]), if_pos ht]
    · rw [if_neg (by simp [Finset.mem_filter, ht]), if_neg ht]
  rw [bal, bal, key O.tail, key O.head]
  abel

end Bal

/-! ## Sign-oriented reroute -/

/-- Flip a nonzero integer across the modulus `k`: positive values drop by `k`,
negative values rise by `k`. Preserves `|·| ∈ [1,k-1]` and the class mod `k`. -/
private def rrVal (k : ℤ) (x : ℤ) : ℤ := if 0 < x then x - k else x + k

/-- Reroute the edges in `es` (each once) by `rrVal`. -/
private def reroute [DecidableEq β] (k : ℤ) (es : List β) (g : β → ℤ) : β → ℤ :=
  fun e => if e ∈ es then rrVal k (g e) else g e

/-- One sign-oriented step along edge `e` from `p` to `q`: either `e` is a positive edge
traversed tail→head, or a negative edge traversed head→tail. -/
private def SStepE (O : Orientation G) (g : β → ℤ) (e : β) (p q : α) : Prop :=
  e ∈ E(G) ∧ ((0 < g e ∧ O.tail e = p ∧ O.head e = q) ∨ (g e < 0 ∧ O.head e = p ∧ O.tail e = q))

/-- A sign-oriented walk: a chain of `SStepE` steps from `u` to `w` recording its edges. -/
private inductive SWalk (O : Orientation G) (g : β → ℤ) : α → List β → α → Prop
  | nil (u : α) : SWalk O g u [] u
  | cons {u v w : α} {e : β} {es : List β} :
      SStepE O g e u v → SWalk O g v es w → SWalk O g u (e :: es) w

/-- **Telescoping.** Rerouting an edge-distinct sign-oriented walk from `u` to `w` shifts
imbalance by `-k` at `u` and `+k` at `w`, leaving every other vertex unchanged. -/
private lemma walk_bal [DecidableEq α] (hE : E(G).Finite) [DecidableEq β] (k : ℤ) (g : β → ℤ)
    {u : α} {es : List β} {w : α} (hw : SWalk O g u es w) :
    ∀ p, es.Nodup → bal O hE (reroute k es g) p
      = bal O hE g p + k * ((if w = p then (1:ℤ) else 0) - (if u = p then 1 else 0)) := by
  induction hw with
  | nil u =>
    intro p _
    have : reroute k ([] : List β) g = g := by
      funext e; simp [reroute]
    rw [this]; ring
  | @cons u v w e es' hstep hrest ih =>
    intro p hnd
    rw [List.nodup_cons] at hnd
    obtain ⟨hnotin, hndes'⟩ := hnd
    have hdecomp : reroute k (e :: es') g
        = Function.update (reroute k es' g) e (rrVal k (g e)) := by
      funext e'
      by_cases h : e' = e
      · subst h; simp [reroute, Function.update_self]
      · simp only [reroute, Function.update_of_ne h, List.mem_cons, h, false_or]
    have he : e ∈ E(G) := hstep.1
    have hge : (reroute k es' g) e = g e := by simp [reroute, hnotin]
    rw [hdecomp, bal_update hE (reroute k es' g) e he (rrVal k (g e)) p, hge, ih p hndes']
    rcases hstep.2 with ⟨hpos, htail, hhead⟩ | ⟨hneg, hhead, htail⟩
    · rw [htail, hhead]
      simp only [rrVal, if_pos hpos]
      split_ifs <;> ring
    · rw [htail, hhead]
      simp only [rrVal, if_neg (not_lt.mpr hneg.le)]
      split_ifs <;> ring

/-! ## The potential Φ -/

/-- The total imbalance potential `Φ(g) = ∑_v |b(v)|`. -/
private noncomputable def Phi [DecidableEq α] (O : Orientation G) (hV : V(G).Finite) (hE : E(G).Finite)
    (g : β → ℤ) : ℕ :=
  ∑ v ∈ hV.toFinset, (bal O hE g v).natAbs

/-- If `Φ(g) = 0` then `g` is a flow. -/
private lemma flow_of_phi_zero [DecidableEq α] (hV : V(G).Finite) (hE : E(G).Finite) (g : β → ℤ)
    (h : Phi O hV hE g = 0) : G.IsFlow O g := by
  have hz : ∀ v ∈ hV.toFinset, (bal O hE g v).natAbs = 0 :=
    Finset.sum_eq_zero_iff.mp h
  rw [Graph.isFlow_iff_finset_sum hE]
  intro v hv
  have hvf : v ∈ hV.toFinset := (Set.Finite.mem_toFinset hV).mpr hv
  have : bal O hE g v = 0 := Int.natAbs_eq_zero.mp (hz v hvf)
  rw [bal, sub_eq_zero] at this
  exact this

/-- **Φ strictly decreases** on rerouting an edge-distinct walk from a positive-imbalance
vertex `u` to a negative-imbalance vertex `w` (both imbalances multiples of `k`). -/
private lemma reroute_decreases_phi [DecidableEq α] [DecidableEq β] (hV : V(G).Finite) (hE : E(G).Finite)
    (k : ℤ) (g : β → ℤ) {u : α} {es : List β} {w : α} (hw : SWalk O g u es w) (hnd : es.Nodup)
    (huV : u ∈ V(G)) (hwV : w ∈ V(G)) (hne : u ≠ w) (hk : 1 ≤ k)
    (hbu : 0 < bal O hE g u) (hbw : bal O hE g w < 0)
    (hdu : k ∣ bal O hE g u) (hdw : k ∣ bal O hE g w) :
    Phi O hV hE (reroute k es g) < Phi O hV hE g := by
  set s := hV.toFinset with hs
  have huf : u ∈ s := (Set.Finite.mem_toFinset hV).mpr huV
  have hwf : w ∈ s := (Set.Finite.mem_toFinset hV).mpr hwV
  have hwf' : w ∈ s.erase u := Finset.mem_erase.mpr ⟨hne.symm, hwf⟩
  -- values at u and w after rerouting
  have hbu' : bal O hE (reroute k es g) u = bal O hE g u - k := by
    rw [walk_bal hE k g hw u hnd]; rw [if_neg hne.symm, if_pos rfl]; ring
  have hbw' : bal O hE (reroute k es g) w = bal O hE g w + k := by
    rw [walk_bal hE k g hw w hnd]; rw [if_pos rfl, if_neg hne]; ring
  -- tail (off {u,w}) unchanged
  have htail : ∀ v ∈ (s.erase u).erase w,
      (bal O hE (reroute k es g) v).natAbs = (bal O hE g v).natAbs := by
    intro v hv
    rw [Finset.mem_erase, Finset.mem_erase] at hv
    obtain ⟨hvw, hvu, _⟩ := hv
    rw [walk_bal hE k g hw v hnd, if_neg (fun h => hvw h.symm), if_neg (fun h => hvu h.symm)]
    ring_nf
  -- expand Φ at u then w
  have expand : ∀ (f : α → ℕ),
      ∑ v ∈ s, f v = f u + (f w + ∑ v ∈ (s.erase u).erase w, f v) := by
    intro f
    rw [← Finset.add_sum_erase s f huf, ← Finset.add_sum_erase (s.erase u) f hwf']
  rw [Phi, Phi, expand (fun v => (bal O hE (reroute k es g) v).natAbs),
    expand (fun v => (bal O hE g v).natAbs)]
  rw [Finset.sum_congr rfl htail]
  -- reduce to the two endpoints
  have hkle_u : k ≤ bal O hE g u := Int.le_of_dvd hbu hdu
  have hkle_w : k ≤ -bal O hE g w := Int.le_of_dvd (by omega) ((dvd_neg).mpr hdw)
  simp only [hbu', hbw']
  omega

/-! ## The invariant INV -/

/-- The rerouting invariant: `g` reduces to `f` mod `k` on edges, has `|g e| ∈ [1,k-1]` there,
and vanishes off `E(G)`. -/
private def INV (O : Orientation G) (k : ℕ) (f : β → ZMod k) (g : β → ℤ) : Prop :=
  (∀ e ∈ E(G), 1 ≤ |g e| ∧ |g e| ≤ (k:ℤ) - 1 ∧ ((g e : ℤ) : ZMod k) = f e) ∧ (∀ e ∉ E(G), g e = 0)

/-- Every edge of a sign-oriented walk is an edge of `G`. -/
private lemma SWalk_edges_mem (g : β → ℤ) {u : α} {es : List β} {w : α} (hw : SWalk O g u es w) :
    ∀ e ∈ es, e ∈ E(G) := by
  induction hw with
  | nil u => intro e he; simp at he
  | @cons u v w e es' hstep hrest ih =>
    intro e' he'
    rw [List.mem_cons] at he'
    rcases he' with rfl | he'
    · exact hstep.1
    · exact ih e' he'

/-- Rerouting preserves INV (each rerouted edge's value flips across the modulus). -/
private lemma reroute_INV [DecidableEq β] (k : ℕ) (hk : 1 ≤ k) (f : β → ZMod k) (g : β → ℤ)
    (hinv : INV O k f g) (es : List β) (hes : ∀ e ∈ es, e ∈ E(G)) :
    INV O k f (reroute (k:ℤ) es g) := by
  have hk' : (1:ℤ) ≤ (k:ℤ) := by exact_mod_cast hk
  obtain ⟨hon, hoff⟩ := hinv
  constructor
  · intro e he
    by_cases hmem : e ∈ es
    · simp only [reroute, if_pos hmem]
      obtain ⟨h1, h2, h3⟩ := hon e he
      have hne : g e ≠ 0 := by rintro h; rw [h] at h1; norm_num at h1
      have hb1 : -((k:ℤ) - 1) ≤ g e := (abs_le.mp h2).1
      have hb2 : g e ≤ (k:ℤ) - 1 := (abs_le.mp h2).2
      have hbound : 1 ≤ |rrVal (k:ℤ) (g e)| ∧ |rrVal (k:ℤ) (g e)| ≤ (k:ℤ) - 1 := by
        rw [rrVal]
        split_ifs with hp
        · rw [abs_of_nonpos (by omega)]; omega
        · rw [abs_of_nonneg (by omega)]; omega
      refine ⟨hbound.1, hbound.2, ?_⟩
      have hcl : ((rrVal (k:ℤ) (g e) : ℤ) : ZMod k) = ((g e : ℤ) : ZMod k) := by
        rw [rrVal]; split_ifs <;> push_cast <;> simp [ZMod.natCast_self]
      rw [hcl]; exact h3
    · simp only [reroute, if_neg hmem]; exact hon e he
  · intro e he
    simp only [reroute, if_neg (fun hmem => he (hes e hmem))]
    exact hoff e he

/-! ## Divisibility and vanishing of the total imbalance -/

/-- Every vertex imbalance of an INV-map is a multiple of `k`. -/
private lemma bal_dvd [DecidableEq α] (hE : E(G).Finite) (k : ℕ) (f : β → ZMod k)
    (hflow : G.IsFlow O f) (g : β → ℤ) (hclass : ∀ e ∈ E(G), ((g e : ℤ) : ZMod k) = f e)
    (v : α) (hv : v ∈ V(G)) : (k:ℤ) ∣ bal O hE g v := by
  rw [← ZMod.intCast_zmod_eq_zero_iff_dvd]
  rw [bal]
  have htail : ((∑ e ∈ hE.toFinset with O.tail e = v, g e : ℤ) : ZMod k)
      = ∑ e ∈ hE.toFinset with O.tail e = v, f e := by
    rw [Int.cast_sum]
    refine Finset.sum_congr rfl fun e he => ?_
    rw [Finset.mem_filter, Set.Finite.mem_toFinset] at he
    exact hclass e he.1
  have hhead : ((∑ e ∈ hE.toFinset with O.head e = v, g e : ℤ) : ZMod k)
      = ∑ e ∈ hE.toFinset with O.head e = v, f e := by
    rw [Int.cast_sum]
    refine Finset.sum_congr rfl fun e he => ?_
    rw [Finset.mem_filter, Set.Finite.mem_toFinset] at he
    exact hclass e he.1
  rw [Int.cast_sub, htail, hhead, sub_eq_zero]
  exact (Graph.isFlow_iff_finset_sum hE).mp hflow v hv

/-- The total imbalance over all vertices vanishes. -/
private lemma sum_bal_zero [DecidableEq α] (hV : V(G).Finite) (hE : E(G).Finite) (g : β → ℤ) :
    ∑ v ∈ hV.toFinset, bal O hE g v = 0 := by
  simp only [bal, Finset.sum_sub_distrib]
  have htail : ∑ v ∈ hV.toFinset, ∑ e ∈ hE.toFinset with O.tail e = v, g e
      = ∑ e ∈ hE.toFinset, g e := by
    apply Finset.sum_fiberwise_of_maps_to
    intro e he
    rw [Set.Finite.mem_toFinset] at he ⊢
    exact O.tail_mem he
  have hhead : ∑ v ∈ hV.toFinset, ∑ e ∈ hE.toFinset with O.head e = v, g e
      = ∑ e ∈ hE.toFinset, g e := by
    apply Finset.sum_fiberwise_of_maps_to
    intro e he
    rw [Set.Finite.mem_toFinset] at he ⊢
    exact O.head_mem he
  rw [htail, hhead, sub_self]

/-! ## Sign-oriented reachability -/

/-- Two sign-oriented walks concatenate. -/
private lemma SWalk.append (g : β → ℤ) {u v w : α} {es₁ es₂ : List β}
    (h1 : SWalk O g u es₁ v) (h2 : SWalk O g v es₂ w) :
    SWalk O g u (es₁ ++ es₂) w := by
  induction h1 with
  | nil u => simpa using h2
  | cons hstep hrest ih => exact SWalk.cons hstep (ih h2)

/-- Sign-oriented reachability: existence of some walk. -/
private def SReach (O : Orientation G) (g : β → ℤ) (u w : α) : Prop := ∃ es, SWalk O g u es w

private lemma SReach.refl (O : Orientation G) (g : β → ℤ) (u : α) : SReach O g u u := ⟨[], SWalk.nil u⟩

private lemma SReach.step {g : β → ℤ} {e : β} {u v : α} (h : SStepE O g e u v) : SReach O g u v :=
  ⟨[e], SWalk.cons h (SWalk.nil v)⟩

private lemma SReach.trans {g : β → ℤ} {u v w : α} (h1 : SReach O g u v) (h2 : SReach O g v w) :
    SReach O g u w := by
  obtain ⟨es₁, hw₁⟩ := h1
  obtain ⟨es₂, hw₂⟩ := h2
  exact ⟨_, hw₁.append g hw₂⟩

/-- **Min-cut / augmenting reachability.** From a vertex `u` with positive imbalance there is a
sign-oriented path to some vertex `w` with negative imbalance. -/
private lemma exists_neg_reachable [DecidableEq α] (hV : V(G).Finite) (hE : E(G).Finite) (g : β → ℤ)
    (u : α) (huV : u ∈ V(G)) (hbu : 0 < bal O hE g u) :
    ∃ w, w ∈ V(G) ∧ SReach O g u w ∧ bal O hE g w < 0 := by
  classical
  by_contra hcon
  push_neg at hcon
  set X := hV.toFinset.filter (fun w => SReach O g u w) with hX
  have hnonneg : ∀ v ∈ X, 0 ≤ bal O hE g v := by
    intro v hv
    rw [hX, Finset.mem_filter, Set.Finite.mem_toFinset] at hv
    exact hcon v hv.1 hv.2
  have huX : u ∈ X := by
    rw [hX, Finset.mem_filter, Set.Finite.mem_toFinset]
    exact ⟨huV, SReach.refl O g u⟩
  have hpos : 0 < ∑ v ∈ X, bal O hE g v :=
    lt_of_lt_of_le hbu (Finset.single_le_sum hnonneg huX)
  have hsum_le : ∑ v ∈ X, bal O hE g v ≤ 0 := by
    have e1 : ∑ v ∈ X, bal O hE g v
        = (∑ e ∈ hE.toFinset with O.tail e ∈ X, g e)
          - ∑ e ∈ hE.toFinset with O.head e ∈ X, g e := by
      simp only [bal, Finset.sum_sub_distrib]
      rw [Finset.sum_fiberwise_eq_sum_filter hE.toFinset X O.tail g,
          Finset.sum_fiberwise_eq_sum_filter hE.toFinset X O.head g]
    rw [e1, Finset.sum_filter, Finset.sum_filter, ← Finset.sum_sub_distrib]
    apply Finset.sum_nonpos
    intro e he
    rw [Set.Finite.mem_toFinset] at he
    by_cases htX : O.tail e ∈ X <;> by_cases hhX : O.head e ∈ X
    · simp [htX, hhX]
    · rw [if_pos htX, if_neg hhX, sub_zero]
      by_contra hgpos
      push_neg at hgpos
      apply hhX
      have hru : SReach O g u (O.tail e) := (Finset.mem_filter.mp htX).2
      have hstep : SStepE O g e (O.tail e) (O.head e) := ⟨he, Or.inl ⟨hgpos, rfl, rfl⟩⟩
      rw [hX, Finset.mem_filter, Set.Finite.mem_toFinset]
      exact ⟨O.head_mem he, hru.trans (SReach.step hstep)⟩
    · rw [if_neg htX, if_pos hhX, zero_sub, neg_nonpos]
      by_contra hgneg
      push_neg at hgneg
      apply htX
      have hru : SReach O g u (O.head e) := (Finset.mem_filter.mp hhX).2
      have hstep : SStepE O g e (O.head e) (O.tail e) := ⟨he, Or.inr ⟨hgneg, rfl, rfl⟩⟩
      rw [hX, Finset.mem_filter, Set.Finite.mem_toFinset]
      exact ⟨O.tail_mem he, hru.trans (SReach.step hstep)⟩
    · simp [htX, hhX]
  exact absurd hpos (not_lt.mpr hsum_le)

/-! ## Extracting an edge-distinct walk -/

/-- A sign-oriented step's endpoints are determined by the edge (the sign fixes the direction). -/
private lemma SStepE_det {g : β → ℤ} {e : β} {a b a' b' : α}
    (h1 : SStepE O g e a b) (h2 : SStepE O g e a' b') : a = a' ∧ b = b' := by
  rcases h1.2 with ⟨hp, ht, hh⟩ | ⟨hn, hh, ht⟩ <;>
    rcases h2.2 with ⟨hp', ht', hh'⟩ | ⟨hn', hh', ht'⟩
  · exact ⟨ht.symm.trans ht', hh.symm.trans hh'⟩
  · exact absurd hp (by omega)
  · exact absurd hp' (by omega)
  · exact ⟨hh.symm.trans hh', ht.symm.trans ht'⟩

/-- A walk containing edge `e` splits around `e`. -/
private lemma SWalk_split {g : β → ℤ} {v w : α} {es : List β} (hw : SWalk O g v es w) {e : β}
    (he : e ∈ es) :
    ∃ (es₁ es₂ : List β) (a b : α), es = es₁ ++ e :: es₂ ∧ SWalk O g v es₁ a ∧
      SStepE O g e a b ∧ SWalk O g b es₂ w := by
  revert he
  induction hw with
  | nil u => intro he; simp at he
  | @cons u v' w e0 es0 hstep hrest ih =>
    intro he
    rw [List.mem_cons] at he
    rcases he with rfl | he
    · exact ⟨[], es0, u, v', by simp, SWalk.nil u, hstep, hrest⟩
    · obtain ⟨es₁, es₂, a, b, hsplit, hw₁, hstep', hw₂⟩ := ih he
      exact ⟨e0 :: es₁, es₂, a, b, by rw [hsplit, List.cons_append], SWalk.cons hstep hw₁,
        hstep', hw₂⟩

/-- A walk with a repeated edge can be strictly shortened. -/
private lemma SWalk_shorten {g : β → ℤ} {u w : α} {es : List β} (hw : SWalk O g u es w)
    (hnd : ¬ es.Nodup) :
    ∃ es', SWalk O g u es' w ∧ es'.length < es.length := by
  induction hw with
  | nil u => simp at hnd
  | @cons u v w e es0 hstep hrest ih =>
    by_cases he : e ∈ es0
    · obtain ⟨es₁, es₂, a, b, hsplit, hw₁, hstep', hw₂⟩ := SWalk_split hrest he
      obtain ⟨rfl, rfl⟩ := SStepE_det hstep' hstep
      refine ⟨e :: es₂, SWalk.cons hstep hw₂, ?_⟩
      rw [hsplit]
      simp only [List.length_cons, List.length_append]
      omega
    · have hnd0 : ¬ es0.Nodup := fun h => hnd (List.nodup_cons.mpr ⟨he, h⟩)
      obtain ⟨es', hw', hlt⟩ := ih hnd0
      exact ⟨e :: es', SWalk.cons hstep hw', by simp only [List.length_cons]; omega⟩

/-- Reachability yields an edge-distinct walk (minimal length). -/
private lemma exists_nodup_walk {g : β → ℤ} {u w : α} (h : SReach O g u w) :
    ∃ es, SWalk O g u es w ∧ es.Nodup := by
  classical
  obtain ⟨es0, hw0⟩ := h
  have hP : ∃ n, ∃ es, SWalk O g u es w ∧ es.length = n := ⟨es0.length, es0, hw0, rfl⟩
  obtain ⟨es, hw, hlen⟩ := Nat.find_spec hP
  refine ⟨es, hw, ?_⟩
  by_contra hnd
  obtain ⟨es', hw', hlt⟩ := SWalk_shorten hw hnd
  exact Nat.find_min hP (hlen ▸ hlt) ⟨es', hw', rfl⟩

/-! ## The augmenting step and finite descent -/

/-- **Augment.** If `Φ(g) > 0` there is an INV-map with strictly smaller potential. -/
private lemma augment [DecidableEq α] [DecidableEq β] (hV : V(G).Finite) (hE : E(G).Finite)
    (k : ℕ) (hk : 1 ≤ k) (f : β → ZMod k) (hflow : G.IsFlow O f) (g : β → ℤ)
    (hinv : INV O k f g) (hpos : 0 < Phi O hV hE g) :
    ∃ g', INV O k f g' ∧ Phi O hV hE g' < Phi O hV hE g := by
  have hclass : ∀ e ∈ E(G), ((g e : ℤ) : ZMod k) = f e := fun e he => (hinv.1 e he).2.2
  have hdvd : ∀ v ∈ V(G), (k:ℤ) ∣ bal O hE g v := fun v hv => bal_dvd hE k f hflow g hclass v hv
  have hex_pos : ∃ u ∈ V(G), 0 < bal O hE g u := by
    obtain ⟨v, hvf, hvne⟩ : ∃ v ∈ hV.toFinset, bal O hE g v ≠ 0 := by
      by_contra h
      push_neg at h
      have : Phi O hV hE g = 0 := by
        rw [Phi]; apply Finset.sum_eq_zero; intro v hv; rw [h v hv]; rfl
      omega
    by_contra hcon
    push_neg at hcon
    have hall_le : ∀ x ∈ hV.toFinset, bal O hE g x ≤ 0 :=
      fun x hx => hcon x ((Set.Finite.mem_toFinset hV).mp hx)
    have hvneg : bal O hE g v < 0 := lt_of_le_of_ne (hall_le v hvf) hvne
    have hsum0 : ∑ x ∈ hV.toFinset, bal O hE g x = 0 := sum_bal_zero hV hE g
    have hlt : ∑ x ∈ hV.toFinset, bal O hE g x < ∑ _x ∈ hV.toFinset, (0:ℤ) :=
      Finset.sum_lt_sum hall_le ⟨v, hvf, hvneg⟩
    rw [Finset.sum_const_zero] at hlt
    omega
  obtain ⟨u, huV, hbu⟩ := hex_pos
  obtain ⟨w, hwV, hreach, hbw⟩ := exists_neg_reachable hV hE g u huV hbu
  obtain ⟨es, hwalk, hnd⟩ := exists_nodup_walk hreach
  have hne : u ≠ w := by intro h; rw [h] at hbu; omega
  have hk' : (1:ℤ) ≤ (k:ℤ) := by exact_mod_cast hk
  refine ⟨reroute (k:ℤ) es g, reroute_INV k hk f g hinv es (SWalk_edges_mem g hwalk), ?_⟩
  exact reroute_decreases_phi hV hE (k:ℤ) g hwalk hnd huV hwV hne hk' hbu hbw
    (hdvd u huV) (hdvd w hwV)

/-- **Finite descent.** From any INV-map one reaches an INV-map of potential `0`. -/
private lemma descent [DecidableEq α] [DecidableEq β] (hV : V(G).Finite) (hE : E(G).Finite)
    (k : ℕ) (hk : 1 ≤ k) (f : β → ZMod k) (hflow : G.IsFlow O f) :
    ∀ n g, INV O k f g → Phi O hV hE g = n → ∃ g', INV O k f g' ∧ Phi O hV hE g' = 0 := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
    intro g hinv hphi
    rcases Nat.eq_zero_or_pos n with hn | hn
    · exact ⟨g, hinv, by rw [hphi, hn]⟩
    · have hpos : 0 < Phi O hV hE g := by rw [hphi]; exact hn
      obtain ⟨g', hinv', hlt⟩ := augment hV hE k hk f hflow g hinv hpos
      exact ih (Phi O hV hE g') (hphi ▸ hlt) g' hinv' rfl

/-! ## Lemmas 9–11 (`ZkFlowLiftsToIntFlow`): the hard `⇒` direction

From a nowhere-zero `(ℤ/k)`-flow, build an integer `k`-flow by the finite-descent argument:
choose positive representatives `g ∈ [1, k-1]` with all vertex imbalances `≡ 0 (mod k)`, then
repeatedly reroute along a directed `P⁺ → P⁻` path to strictly decrease `Φ := ∑_v |b(v)|`
until `Φ = 0`, at which point `g` is an honest integer `k`-flow. -/

/-- **Lemmas 9–11 (⇒ direction).** From a nowhere-zero `(ℤ/k)`-flow of `G` w.r.t. `O`, there is
an integer `k`-flow of `G` w.r.t. `O`, built by the finite-descent construction above
(positive representatives → sign-oriented reroute strictly decreasing `Φ` → `Φ = 0`). -/
theorem ZkFlowLiftsToIntFlow {k : ℕ} (hk : 1 ≤ k) (hV : V(G).Finite) (hE : E(G).Finite)
    (O : Orientation G) (f : β → ZMod k) (hflow : G.IsFlow O f) (hnz : G.IsNowhereZero f) :
    ∃ φ : β → ℤ, G.IsIntegerKFlow O φ (k : ℤ) := by
  classical
  set g₀ : β → ℤ := fun e => if e ∈ E(G) then zkRep f e else 0 with hg₀
  have hinv₀ : INV O k f g₀ := by
    constructor
    · intro e he
      simp only [hg₀, if_pos he]
      obtain ⟨h1, h2, h3⟩ := ZkFlowRepresentativeClaim hk f hnz e he
      rw [abs_of_pos (by omega : (0:ℤ) < zkRep f e)]
      exact ⟨h1, h2, h3⟩
    · intro e he; simp only [hg₀, if_neg he]
  obtain ⟨g', hinv', hphi0⟩ :=
    descent hV hE k hk f hflow (Phi O hV hE g₀) g₀ hinv₀ rfl
  refine ⟨g', flow_of_phi_zero hV hE g' hphi0, fun e he => ?_⟩
  obtain ⟨h1, h2, _⟩ := hinv'.1 e he
  exact ⟨by omega, by omega⟩

/-! ## Lemma 12 (`ZkIffIntKFlow`): the equivalence -/

/-- **Theorem II.1 / Lemma 12.** For `k ≥ 1` and a finite multigraph `G` with orientation `O`,
`G` has a nowhere-zero `(ℤ/k)`-flow iff it has a nowhere-zero integer `k`-flow. -/
theorem zk_iff_int_k_flow {k : ℕ} (hk : 1 ≤ k) (hV : V(G).Finite) (hE : E(G).Finite)
    (O : Orientation G) :
    (∃ f : β → ZMod k, G.IsFlow O f ∧ G.IsNowhereZero f) ↔
      (∃ φ : β → ℤ, G.IsIntegerKFlow O φ (k : ℤ)) := by
  constructor
  · rintro ⟨f, hflow, hnz⟩
    exact ZkFlowLiftsToIntFlow hk hV hE O f hflow hnz
  · rintro ⟨φ, hφ⟩
    exact ⟨fun e => ((φ e : ZMod k)), IntFlowReducesToZk hE O φ hφ⟩

end Workspace.PriorWorkProofs.Tutte

/-!
# Assembly of Tutte's group-flow theorem

This file assembles the two proved halves — `exists_flow_iff_zmod` (Part I) and
`zk_iff_int_k_flow` (Rerouting) — into Tutte's group-flow theorem and its `Γ`/`8`
corollary, matching byte-for-byte the signatures of the `axiom`s
`tutte_group_flow` and `tutte_gamma_flow_iff_integer_eight_flow` in
`Workspace/PriorWork.lean`.
-/

open Graph
open scoped Graph
open Workspace.Types.Gamma Workspace.Types.Orientation

namespace Workspace.PriorWorkProofs.Tutte

/-- **Tutte's group-flow theorem** (assembled). For a finite abelian group `A` of
order `k`, a graph has a nowhere-zero `A`-flow iff it has a nowhere-zero integer
`k`-flow. -/
theorem tutte_group_flow_proved {α β : Type*} {A : Type*} [AddCommGroup A] [Finite A] {k : ℕ}
    (hA : Nat.card A = k) (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (O : Orientation G) :
    (∃ f : β → A, G.IsFlow O f ∧ G.IsNowhereZero f) ↔
      (∃ φ : β → ℤ, G.IsIntegerKFlow O φ (k : ℤ)) := by
  haveI := Classical.decEq α
  haveI : Nonempty A := ⟨0⟩
  have hk : 1 ≤ k := by
    have : 0 < Nat.card A := Nat.card_pos
    omega
  haveI : NeZero k := ⟨by omega⟩
  exact (exists_flow_iff_zmod hE O hA).trans (zk_iff_int_k_flow hk hV hE O)

/-- **Tutte's group-flow theorem, the `Γ = 𝔽₂³` / `8`-flow corollary** (assembled).
A graph has a nowhere-zero `Γ`-flow iff it has a nowhere-zero integer `8`-flow. -/
theorem tutte_gamma_flow_iff_integer_eight_flow_proved {α β : Type*} (G : Graph α β)
    (hV : V(G).Finite) (hE : E(G).Finite) (O : Orientation G) :
    (∃ f : β → Gamma, G.IsFlow O f ∧ G.IsNowhereZero f) ↔
      (∃ φ : β → ℤ, G.IsIntegerKFlow O φ 8) := by
  have hcard : Nat.card Gamma = 8 := by
    rw [Nat.card_eq_fintype_card, Gamma.card_eq]
  have h := tutte_group_flow_proved hcard G hV hE O
  simpa using h

end Workspace.PriorWorkProofs.Tutte

/-!
# Even subgraphs and the assembly of a nowhere-zero `Γ`-flow (§3.1, §3.6 step 4-5, §3.8)

The `𝔽₂`-indicator of an edge set `H` is a `ZMod 2`-flow of `G` iff `H` is an even subgraph
(`indicator_isFlow_iff`), via the characteristic-two flow criterion `charTwo_flow_iff_endSum_zero`.
Assembled with `three_even_subgraphs_cover_gamma_flow`: three even subgraphs covering `E(G)` yield
a nowhere-zero `Γ`-flow (`Γ = 𝔽₂³`).
-/

open Set
open scoped Graph
open Workspace.Types.Gamma
open Workspace.Types.Orientation

namespace Workspace.PriorWorkProofs.EightFlow

open scoped Classical

variable {α β : Type*} {G : Graph α β} {u v : α} {e : β} {H : Set β}

/-! ## The characteristic-two flow criterion -/

/-- **Characteristic-two flow criterion.** For a group `A` in which every element is its own
negative (`a + a = 0`), a map `f : β → A` is an `A`-flow with respect to an orientation `O` iff
for every vertex `v` the sum of `f` over the edge-ends at `v` — a loop counted **twice** —
vanishes. This is the group-general version of
`Workspace.Facts.Construction.gamma_flow_iff_endSum_zero`; the orientation drops out because in
characteristic two `x = y ↔ x + y = 0`. -/
theorem charTwo_flow_iff_endSum_zero {A : Type*} [AddCommGroup A] (hchar : ∀ a : A, a + a = 0)
    (hE : E(G).Finite) (O : Orientation G) (f : β → A) :
    G.IsFlow O f ↔
      ∀ v ∈ V(G),
        (∑ᶠ e ∈ G.incidenceSet v, (if G.IsLoopAt e v then (2 : ℕ) else 1) • f e) = 0 := by
  classical
  have eq_iff : ∀ a b : A, (a = b) ↔ (a + b = 0) := by
    intro a b
    constructor
    · rintro rfl; exact hchar _
    · intro h
      have hh : a + b + b = b := by rw [h, zero_add]
      rwa [add_assoc, hchar, add_zero] at hh
  rw [Graph.isFlow_iff_finset_sum hE]
  refine forall_congr' (fun v => ?_)
  refine imp_congr_right (fun hv => ?_)
  set s := hE.toFinset with hs
  have hset : G.incidenceSet v = (↑(s.filter (fun e => G.Inc e v)) : Set β) := by
    ext e
    simp only [Graph.mem_incidenceSet, Finset.coe_filter, Set.mem_setOf_eq,
      Set.Finite.mem_toFinset, hs]
    exact ⟨fun h => ⟨h.edge_mem, h⟩, fun h => h.2⟩
  rw [hset, finsum_mem_coe_finset]
  have key : (∑ e ∈ s.filter (fun e => G.Inc e v),
        (if G.IsLoopAt e v then (2 : ℕ) else 1) • f e)
      = (∑ e ∈ s.filter (fun e => O.tail e = v), f e)
        + (∑ e ∈ s.filter (fun e => O.head e = v), f e) := by
    rw [Finset.sum_filter, Finset.sum_filter, Finset.sum_filter, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun e he => ?_)
    have heE : e ∈ E(G) := by rw [hs, Set.Finite.mem_toFinset] at he; exact he
    have hinc : G.Inc e v ↔ O.tail e = v ∨ O.head e = v := by
      rw [O.inc_iff heE]; exact or_congr eq_comm eq_comm
    have hloop : G.IsLoopAt e v ↔ O.tail e = v ∧ O.head e = v := by
      constructor
      · intro h; exact ⟨O.tail_eq_of_isLoopAt h, O.head_eq_of_isLoopAt h⟩
      · rintro ⟨h1, h2⟩
        have hlink := O.isLink_tail_head heE
        rw [h1, h2] at hlink
        exact hlink
    by_cases h1 : O.tail e = v <;> by_cases h2 : O.head e = v <;>
      simp [hinc, hloop, h1, h2, two_nsmul, one_nsmul, two_mul]
  rw [key, eq_iff]

/-- The `ℤ₂` specialisation of `charTwo_flow_iff_endSum_zero`. -/
theorem zmod2_flow_iff_endSum_zero (hE : E(G).Finite) (O : Orientation G) (f : β → ZMod 2) :
    G.IsFlow O f ↔
      ∀ v ∈ V(G),
        (∑ᶠ e ∈ G.incidenceSet v, (if G.IsLoopAt e v then (2 : ℕ) else 1) • f e) = 0 := by
  classical
  exact charTwo_flow_iff_endSum_zero (fun a => CharTwo.add_self_eq_zero a) hE O f

/-! ## Even subgraphs -/

/-- The **degree of `v` inside the edge set `H`**: the number of edge-ends at `v` that belong to
`H`, a loop counted **twice**. This mirrors `Graph.degree` restricted to `H`. -/
noncomputable def degreeWithin (G : Graph α β) (H : Set β) (v : α) : ℕ :=
  (G.incidenceSet v ∩ H).ncard + (G.loopSet v ∩ H).ncard

/-- `H` is an **even subgraph** of `G` if every vertex of `G` has even degree inside `H`
(loops counted twice). Equivalently (over `ℤ₂`) `H` is a cycle in the algebraic sense: an
element of the cycle space over `GF(2)`. -/
def IsEvenSubgraph (G : Graph α β) (H : Set β) : Prop :=
  ∀ v ∈ V(G), Even (degreeWithin G H v)

/-- The `𝔽₂`-**indicator** of an edge set `H`: the map sending edges of `H` to `1 : ZMod 2` and
everything else to `0`. -/
noncomputable def indicator (H : Set β) : β → ZMod 2 := H.indicator (fun _ => 1)

@[simp] lemma indicator_apply (H : Set β) (e : β) :
    indicator H e = if e ∈ H then 1 else 0 := by
  rw [indicator, Set.indicator_apply]

/-! ### The `endSum` of an indicator equals the within-degree -/

/-- At each vertex `v` the characteristic-two edge-end sum of the indicator of `H` equals the
`ℤ₂`-reduction of `degreeWithin G H v`: loops (which count twice) contribute `2 • 1 = 0`, so only
the parity of the number of `H`-edges at `v` survives. -/
theorem indicator_endSum_eq (hE : E(G).Finite) (H : Set β) (v : α) :
    (∑ᶠ e ∈ G.incidenceSet v, (if G.IsLoopAt e v then (2 : ℕ) else 1) • indicator H e)
      = ((degreeWithin G H v : ℕ) : ZMod 2) := by
  classical
  have hIsub : G.incidenceSet v ⊆ E(G) := by
    intro e he; rw [Graph.mem_incidenceSet] at he; exact he.edge_mem
  have hI : (G.incidenceSet v).Finite := hE.subset hIsub
  -- turn the finsum into a finset sum
  rw [show G.incidenceSet v = (↑hI.toFinset : Set β) from hI.coe_toFinset.symm,
    finsum_mem_coe_finset]
  -- each term is the ℤ₂-cast of a natural-number multiplicity
  have hterm : ∀ e ∈ hI.toFinset,
      (if G.IsLoopAt e v then (2 : ℕ) else 1) • indicator H e
        = (((if e ∈ H then (if G.IsLoopAt e v then (2 : ℕ) else 1) else 0) : ℕ) : ZMod 2) := by
    intro e _
    by_cases hH : e ∈ H
    · simp only [indicator_apply, hH, if_true]
      by_cases hl : G.IsLoopAt e v <;> simp [hl, nsmul_eq_mul]
    · simp [indicator_apply, hH]
  rw [Finset.sum_congr rfl hterm, ← Nat.cast_sum]
  congr 1
  -- the natural-number sum equals the within-degree
  unfold degreeWithin
  -- split the multiplicity  (2 if loop else 1)  as  1 + (1 if loop)
  have hsplit : ∀ e ∈ hI.toFinset,
      (if e ∈ H then (if G.IsLoopAt e v then (2 : ℕ) else 1) else 0)
        = (if e ∈ H then 1 else 0) + (if (e ∈ H ∧ G.IsLoopAt e v) then 1 else 0) := by
    intro e _
    by_cases hH : e ∈ H <;> by_cases hl : G.IsLoopAt e v <;> simp [hH, hl]
  rw [Finset.sum_congr rfl hsplit, Finset.sum_add_distrib, Finset.sum_boole, Finset.sum_boole]
  -- identify the two Finset.filter cards with the two ncards
  have hInc : (↑(hI.toFinset.filter (fun e => e ∈ H)) : Set β) = G.incidenceSet v ∩ H := by
    ext e
    simp only [Finset.mem_coe, Finset.mem_filter, Set.Finite.mem_toFinset, Set.mem_inter_iff]
  have hLoop : (↑(hI.toFinset.filter (fun e => e ∈ H ∧ G.IsLoopAt e v)) : Set β)
      = G.loopSet v ∩ H := by
    ext e
    simp only [Finset.mem_coe, Finset.mem_filter, Set.Finite.mem_toFinset, Set.mem_inter_iff,
      Graph.mem_loopSet]
    constructor
    · rintro ⟨hinc, hH, hl⟩; exact ⟨hl, hH⟩
    · rintro ⟨hl, hH⟩
      exact ⟨by rw [Graph.mem_incidenceSet]; exact hl.inc, hH, hl⟩
  simp only [Nat.cast_id]
  rw [← ncard_coe_finset, ← ncard_coe_finset, hInc, hLoop]

/-- **`ℤ₂`-flow ⇔ even subgraph.** The indicator of `H` is a `ZMod 2`-flow of `G` iff `H` is an
even subgraph. -/
theorem indicator_isFlow_iff (hE : E(G).Finite) (O : Orientation G) :
    G.IsFlow O (indicator H) ↔ IsEvenSubgraph G H := by
  rw [zmod2_flow_iff_endSum_zero hE]
  unfold IsEvenSubgraph
  refine forall_congr' fun v => imp_congr_right fun _ => ?_
  rw [indicator_endSum_eq hE, ZMod.natCast_eq_zero_iff, ← even_iff_two_dvd]

/-- Even ⟹ flow: the indicator of an even subgraph is a `ℤ₂`-flow. -/
theorem IsEvenSubgraph.indicator_isFlow (hE : E(G).Finite) (O : Orientation G)
    (h : IsEvenSubgraph G H) : G.IsFlow O (indicator H) :=
  (indicator_isFlow_iff hE O).mpr h

/-- Flow ⟹ even: the support (over `E(G)`) of a `ℤ₂`-flow is an even subgraph. Here the flow `f`
equals the indicator of its support, so the biconditional applies. -/
theorem IsFlow.support_isEvenSubgraph (hE : E(G).Finite) (O : Orientation G) {f : β → ZMod 2}
    (hf : G.IsFlow O f) : IsEvenSubgraph G {e | f e = 1} := by
  have hfeq : f = indicator {e | f e = 1} := by
    funext e
    simp only [indicator_apply, Set.mem_setOf_eq]
    by_cases h : f e = 1
    · simp [h]
    · simp only [h, if_false]
      exact (by decide : ∀ x : ZMod 2, x ≠ 1 → x = 0) (f e) h
  rw [hfeq] at hf
  exact (indicator_isFlow_iff hE O).mp hf

/-! ## The assembly: three even covers give a nowhere-zero `Γ`-flow -/

/-- **A `Π`-valued map is a flow iff every coordinate is.** Being a flow is a coordinatewise
condition: `f : β → (ι → A)` is a flow iff each `fun e => f e i` is. This is what lets a
`Γ = 𝔽₂³`-flow be read as a triple of `ℤ₂`-flows. -/
theorem isFlow_pi_iff {ι : Type*} {A : Type*} [AddCommGroup A]
    (hE : E(G).Finite) (O : Orientation G) (f : β → (ι → A)) :
    G.IsFlow O f ↔ ∀ i, G.IsFlow O (fun e => f e i) := by
  classical
  simp only [Graph.isFlow_iff_finset_sum hE]
  constructor
  · intro h i v hv
    have h1 := congrFun (h v hv) i
    simpa only [Finset.sum_apply] using h1
  · intro h v hv
    funext i
    have h1 := h i v hv
    simpa only [Finset.sum_apply] using h1

/-- **The payoff (Prop. 5 steps 4–5, Cor. 8).** If three even subgraphs `H₁, H₂, H₃` cover the
edge set of `G`, then `f := fun e => ![𝟙_{H₁} e, 𝟙_{H₂} e, 𝟙_{H₃} e] : β → Γ` is a
**nowhere-zero `Γ`-flow**: it is a flow because each coordinate is the indicator of an even
subgraph (a `ℤ₂`-flow), and it is nowhere-zero because every edge lies in some `Hᵢ`, making the
corresponding coordinate `1 ≠ 0`.

This is the elementary "cover by three even subgraphs ⟹ nowhere-zero `ℤ₂³`-flow" implication;
producing the three even subgraphs for a bridgeless `G` is the job of `ThreeEvenCover.lean`. -/
theorem three_even_subgraphs_cover_gamma_flow (hE : E(G).Finite) (O : Orientation G)
    {H₁ H₂ H₃ : Set β} (h₁ : IsEvenSubgraph G H₁) (h₂ : IsEvenSubgraph G H₂)
    (h₃ : IsEvenSubgraph G H₃) (hcov : E(G) ⊆ H₁ ∪ H₂ ∪ H₃) :
    ∃ f : β → Gamma, G.IsFlow O f ∧ G.IsNowhereZero f := by
  classical
  refine ⟨fun e => ![indicator H₁ e, indicator H₂ e, indicator H₃ e], ?_, ?_⟩
  · -- flow: coordinatewise, each is the indicator of an even subgraph
    rw [isFlow_pi_iff hE]
    intro i
    fin_cases i
    · simpa using h₁.indicator_isFlow hE O
    · simpa using h₂.indicator_isFlow hE O
    · simpa using h₃.indicator_isFlow hE O
  · -- nowhere-zero: every edge is covered, so some coordinate is `1`
    intro e he
    rcases hcov he with (h | h) | h
    · intro hcon
      have := congrFun hcon 0
      simp only [Matrix.cons_val_zero, indicator_apply, h, if_true] at this
      exact one_ne_zero this
    · intro hcon
      have := congrFun hcon 1
      simp only [Matrix.cons_val_one, Matrix.head_cons, indicator_apply, h, if_true] at this
      exact one_ne_zero this
    · intro hcon
      have := congrFun hcon 2
      simp only [Matrix.cons_val, indicator_apply, h, if_true] at this
      exact one_ne_zero this

end Workspace.PriorWorkProofs.EightFlow

/-!
# Fundamental cycles and the spanning-tree even cover (Dvořák Lemma 12)

The classical fundamental-cycle argument, carried out over `𝔽₂ = ZMod 2` through the boundary
`(degreeWithin G S v : ZMod 2)`: for a connected spanning edge set `T` of a finite multigraph `G`,
`spanning_tree_even_cover_core` produces an even subgraph `H` containing every non-tree edge
`E(G) \ T`. It inducts on the non-tree edges, each contributing its fundamental cycle `P ∆ {e}`.
-/

open Set
open scoped Graph symmDiff
open Workspace.Types.Orientation

namespace Workspace.PriorWorkProofs.EightFlow

open scoped Classical

variable {α β : Type*} {G : Graph α β} {x y v : α} {e : β}

/-! ## `𝔽₂` `ite` identities -/

private lemma zmod2_ite_or_and {P Q : Prop} [Decidable P] [Decidable Q] :
    (if P ∨ Q then (1 : ZMod 2) else 0) + (if P ∧ Q then 1 else 0)
      = (if P then 1 else 0) + (if Q then 1 else 0) := by
  by_cases hP : P <;> by_cases hQ : Q <;> simp [hP, hQ]

private lemma zmod2_ite_symmDiff {P Q : Prop} [Decidable P] [Decidable Q] :
    (if (P ∧ ¬ Q) ∨ (Q ∧ ¬ P) then (1 : ZMod 2) else 0)
      = (if P then 1 else 0) + (if Q then 1 else 0) := by
  by_cases hP : P <;> by_cases hQ : Q <;> simp [hP, hQ] <;> decide

/-! ## A tiny cardinality helper -/

lemma ncard_inter_singleton (A : Set β) (e : β) :
    (A ∩ {e}).ncard = if e ∈ A then 1 else 0 := by
  by_cases h : e ∈ A
  · rw [if_pos h, Set.inter_eq_right.mpr (by simpa using h), Set.ncard_singleton]
  · rw [if_neg h, Set.inter_singleton_eq_empty.mpr h, Set.ncard_empty]

/-! ## The `ZMod 2` boundary and its `𝔽₂`-linearity -/

/-- Boundary of a single edge, as a natural number: `[Inc e v] + [IsLoopAt e v]`. -/
lemma degreeWithin_singleton (v : α) (e : β) :
    degreeWithin G {e} v
      = (if G.Inc e v then 1 else 0) + (if G.IsLoopAt e v then 1 else 0) := by
  unfold degreeWithin
  rw [ncard_inter_singleton, ncard_inter_singleton]
  simp only [Graph.mem_incidenceSet, Graph.mem_loopSet]

/-- The `𝔽₂`-boundary of a single edge `e` with ends `x, y` is `χ_x + χ_y`. -/
lemma bdry_singleton (he : G.IsLink e x y) (v : α) :
    (↑(degreeWithin G {e} v) : ZMod 2)
      = (if v = x then (1 : ZMod 2) else 0) + (if v = y then 1 else 0) := by
  have hInc : G.Inc e v ↔ (v = x ∨ v = y) :=
    ⟨fun h => h.eq_or_eq_of_isLink he,
      fun h => h.elim (fun hh => hh ▸ he.inc_left) (fun hh => hh ▸ he.inc_right)⟩
  have hLoop : G.IsLoopAt e v ↔ (v = x ∧ v = y) := by
    refine ⟨fun h => ?_, fun ⟨hx, hy⟩ => ?_⟩
    · rcases he.eq_and_eq_or_eq_and_eq (show G.IsLink e v v from h) with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;>
        exact ⟨h1.symm, h2.symm⟩
    · subst hx; subst hy; exact he
  rw [degreeWithin_singleton, Nat.cast_add]
  simp only [hInc, hLoop, apply_ite (Nat.cast : ℕ → ZMod 2), Nat.cast_one, Nat.cast_zero]
  exact zmod2_ite_or_and

/-- `𝔽₂`-linearity of the boundary over symmetric difference. -/
lemma bdry_symmDiff (hE : E(G).Finite) (A B : Set β) (v : α) :
    (↑(degreeWithin G (A ∆ B) v) : ZMod 2)
      = ↑(degreeWithin G A v) + ↑(degreeWithin G B v) := by
  have hI : (G.incidenceSet v).Finite := hE.subset (G.incidenceSet_subset_edgeSet v)
  have hind : ∀ e : β, indicator (A ∆ B) e = indicator A e + indicator B e := by
    intro e
    simp only [indicator_apply, Set.mem_symmDiff]
    exact zmod2_ite_symmDiff
  rw [← indicator_endSum_eq hE, ← indicator_endSum_eq hE, ← indicator_endSum_eq hE,
    ← finsum_mem_add_distrib hI]
  refine finsum_mem_congr rfl (fun e _ => ?_)
  rw [hind e, smul_add]

/-- `H` is an even subgraph iff its `𝔽₂`-boundary vanishes on every vertex of `G`. -/
lemma isEvenSubgraph_iff_bdry (H : Set β) :
    IsEvenSubgraph G H ↔ ∀ v ∈ V(G), (↑(degreeWithin G H v) : ZMod 2) = 0 := by
  unfold IsEvenSubgraph
  refine forall_congr' fun v => imp_congr_right fun _ => ?_
  rw [ZMod.natCast_eq_zero_iff, ← even_iff_two_dvd]

/-- Symmetric difference of two even subgraphs is even. -/
lemma IsEvenSubgraph.symmDiff (hE : E(G).Finite) {A B : Set β}
    (hA : IsEvenSubgraph G A) (hB : IsEvenSubgraph G B) :
    IsEvenSubgraph G (A ∆ B) := by
  rw [isEvenSubgraph_iff_bdry] at hA hB ⊢
  intro v hv
  rw [bdry_symmDiff hE, hA v hv, hB v hv, add_zero]

/-! ## The `T`-path between reachable vertices (fundamental path) -/

/-- **The `T`-path.** If `x` reaches `y` inside `G.restrict T`, there is an edge set `P ⊆ T`
whose `𝔽₂`-boundary is `χ_x + χ_y`. Built by induction on the walk: each step across a tree
edge `f` (ends `b, c`) toggles `P` by `{f}`, and `bdry` telescopes over `𝔽₂`. -/
lemma exists_path_of_reachable (hE : E(G).Finite) {T : Set β} {x y : α}
    (hR : (G.restrict T).Reachable x y) :
    ∃ P : Set β, P ⊆ T ∧ ∀ v : α,
      (↑(degreeWithin G P v) : ZMod 2)
        = (if v = x then (1 : ZMod 2) else 0) + (if v = y then 1 else 0) := by
  rw [Graph.reachable_def] at hR
  induction hR with
  | refl =>
    refine ⟨∅, Set.empty_subset _, fun v => ?_⟩
    have h0 : degreeWithin G (∅ : Set β) v = 0 := by simp [degreeWithin]
    rw [h0, Nat.cast_zero]
    generalize (if v = x then (1 : ZMod 2) else 0) = t
    revert t; decide
  | @tail b c hab hbc ih =>
    obtain ⟨P, hPT, hPb⟩ := ih
    obtain ⟨f, hf⟩ := hbc
    rw [Graph.restrict_isLink] at hf
    obtain ⟨hfT, hflink⟩ := hf
    refine ⟨P ∆ {f}, ?_, fun v => ?_⟩
    · have h : P ∆ {f} ⊆ P ∪ {f} := symmDiff_le_sup
      exact h.trans (Set.union_subset hPT (Set.singleton_subset_iff.mpr hfT))
    · rw [bdry_symmDiff hE, hPb v, bdry_singleton hflink v]
      generalize (if v = x then (1 : ZMod 2) else 0) = a
      generalize (if v = b then (1 : ZMod 2) else 0) = bb
      generalize (if v = c then (1 : ZMod 2) else 0) = cc
      revert a bb cc; decide

/-! ## The spanning-tree even cover -/

/-- **Spanning-tree even cover (core).** If `T ⊆ E(G)` is spanning-connected (`G.restrict T`
connected), then `G` has an even subgraph `H ⊇ E(G) \ T`. No acyclicity is required. -/
theorem spanning_tree_even_cover_core (hE : E(G).Finite) {T : Set β}
    (hTsub : T ⊆ E(G)) (hconn : (G.restrict T).Connected) :
    ∃ H : Set β, IsEvenSubgraph G H ∧ (E(G) \ T) ⊆ H := by
  suffices h : ∀ D : Set β, D.Finite → D ⊆ E(G) \ T →
      ∃ H : Set β, IsEvenSubgraph G H ∧ D ⊆ H ∧ H ⊆ T ∪ D by
    obtain ⟨H, hev, hsub, -⟩ := h (E(G) \ T) (hE.diff) subset_rfl
    exact ⟨H, hev, hsub⟩
  intro D hDfin
  induction D, hDfin using Set.Finite.induction_on with
  | empty =>
    intro _
    refine ⟨∅, ?_, Set.empty_subset _, by simp⟩
    rw [isEvenSubgraph_iff_bdry]; intro v _; simp [degreeWithin]
  | @insert a s ha hs ih =>
    intro hDsub
    have hsD : s ⊆ E(G) \ T := (Set.subset_insert a s).trans hDsub
    have haD : a ∈ E(G) \ T := hDsub (Set.mem_insert a s)
    obtain ⟨Hs, hHsEven, hsHs, hHsT⟩ := ih hsD
    obtain ⟨x, y, hlink⟩ := (G.edge_mem_iff_exists_isLink a).mp haD.1
    obtain ⟨P, hPT, hPbdry⟩ := exists_path_of_reachable hE
      (hconn.reachable (by simpa using hlink.left_mem) (by simpa using hlink.right_mem))
    have haP : a ∉ P := fun h => haD.2 (hPT h)
    have hKeven : IsEvenSubgraph G (P ∆ {a}) := by
      rw [isEvenSubgraph_iff_bdry]; intro v _
      rw [bdry_symmDiff hE, hPbdry v, bdry_singleton hlink v]
      generalize (if v = x then (1 : ZMod 2) else 0) = p
      generalize (if v = y then (1 : ZMod 2) else 0) = q
      revert p q; decide
    refine ⟨Hs ∆ (P ∆ {a}), hHsEven.symmDiff hE hKeven, ?_, ?_⟩
    · intro g hg
      rcases Set.mem_insert_iff.mp hg with rfl | hgs
      · have haK : g ∈ P ∆ {g} :=
          Set.mem_symmDiff.mpr (Or.inr ⟨Set.mem_singleton g, haP⟩)
        have haHs : g ∉ Hs := fun h =>
          (hHsT h).elim (fun hT => haD.2 hT) (fun hs' => ha hs')
        exact Set.mem_symmDiff.mpr (Or.inr ⟨haK, haHs⟩)
      · have hgHs : g ∈ Hs := hsHs hgs
        have hgnT : g ∉ T := (hsD hgs).2
        have hgK : g ∉ P ∆ {a} := by
          rw [Set.mem_symmDiff]
          rintro (⟨hgP, _⟩ | ⟨hgf, _⟩)
          · exact hgnT (hPT hgP)
          · exact ha (by rwa [Set.mem_singleton_iff.mp hgf] at hgs)
        exact Set.mem_symmDiff.mpr (Or.inl ⟨hgHs, hgK⟩)
    · intro g hg
      have hgU : g ∈ Hs ∪ (P ∆ {a}) := (symmDiff_le_sup (a := Hs) (b := (P ∆ {a}))) hg
      rcases hgU with hgHs | hgK
      · rcases hHsT hgHs with hT | hgs
        · exact Set.mem_union_left _ hT
        · exact Set.mem_union_right _ (Set.mem_insert_of_mem a hgs)
      · have hgU2 : g ∈ P ∪ {a} := (symmDiff_le_sup (a := P) (b := ({a} : Set β))) hgK
        rcases hgU2 with hgP | hgf
        · exact Set.mem_union_left _ (hPT hgP)
        · rw [Set.mem_singleton_iff.mp hgf]; exact Set.mem_union_right _ (Set.mem_insert a s)

end Workspace.PriorWorkProofs.EightFlow

/-!
# Nash–Williams–Tutte and the spanning-tree even cover (§3.2, §3.3)

This file supplies the graph-connectivity notions the 8-flow proof needs on the multigraph type
`Graph α β` (`cutEdges`, `IsEdgeConnected`, `IsSpanningTree`; Mathlib has these only for
`SimpleGraph`), and packages the spanning-tree flow (Dvořák Lemma 12) in even-subgraph form as
`spanning_tree_even_cover`. The `k = 3` Nash–Williams–Tutte theorem is admitted as prior work in
`Workspace.PriorWork.NashWilliamsTutte`.
-/

open Set
open scoped Graph
open Workspace.Types.Gamma
open Workspace.Types.Orientation
open Workspace.PriorWorkProofs.EightFlow

namespace Workspace.PriorWorkProofs.EightFlow

variable {α β : Type*} {G : Graph α β}

/-! ## Edge cuts and edge-connectivity -/

/-- The **edge cut** of a vertex set `S`: the edges of `G` with exactly one end in `S`. A loop
never lies in a cut; each parallel edge is counted separately. -/
def cutEdges (G : Graph α β) (S : Set α) : Set β :=
  {e ∈ E(G) | ∃ x y, G.IsLink e x y ∧ x ∈ S ∧ y ∉ S}

/-- `G` is **`k`-edge-connected**: it has at least two vertices and every nontrivial vertex
bipartition `(S, V ∖ S)` is crossed by at least `k` edges. -/
def IsEdgeConnected (G : Graph α β) (k : ℕ) : Prop :=
  2 ≤ V(G).ncard ∧
    ∀ S : Set α, S.Nonempty → S ⊆ V(G) → (V(G) \ S).Nonempty → k ≤ (cutEdges G S).ncard

/-! ## Spanning trees -/

/-- `T ⊆ E(G)` is a **spanning tree** of `G`: the spanning subgraph `G.restrict T` is connected
and has exactly `|V(G)| - 1` edges. On a finite graph this is precisely the tree condition,
without a separate acyclicity clause. -/
def IsSpanningTree (G : Graph α β) (T : Set β) : Prop :=
  T ⊆ E(G) ∧ (G.restrict T).Connected ∧ T.ncard + 1 = V(G).ncard

/-! ## Nash–Williams–Tutte (admitted prior work in `Workspace.PriorWork.NashWilliamsTutte`) -/

/-! ## The spanning-tree flow, as an even cover of the non-tree edges -/

/-- **Dvořák, *Nowhere-zero flows*, Lemma 12 (the spanning-tree flow), in even-subgraph form.**
For a connected `G` with spanning tree `T`, there is an even subgraph `H` containing every
non-tree edge `E(G) \ T`. Proved via the fundamental-cycle argument of
`spanning_tree_even_cover_core`. -/
theorem spanning_tree_even_cover {α β : Type*} (G : Graph α β)
    (hV : V(G).Finite) (hE : E(G).Finite) (hG : G.Connected) (T : Set β)
    (hT : IsSpanningTree G T) :
    ∃ H : Set β, IsEvenSubgraph G H ∧ (E(G) \ T) ⊆ H :=
  spanning_tree_even_cover_core hE hT.1 hT.2.1

end Workspace.PriorWorkProofs.EightFlow

/-!
# Prior-work black box: Nash–Williams–Tutte (edge-disjoint spanning trees)

The admitted prior-work `axiom` for the Nash–Williams–Tutte theorem. The connectivity notions
it references (`IsEdgeConnected`, `IsSpanningTree`) are defined in
`Workspace.PriorWorkProofs.EightFlow.NashWilliams`.
-/

open scoped Graph
open Workspace.PriorWorkProofs.EightFlow

namespace Workspace.PriorWork

/-- **Nash–Williams (1961); Tutte (1961); Dvořák, *Nowhere-zero flows*, Theorem 13, case `k = 3`.**

> Every `6`-edge-connected finite multigraph has three pairwise edge-disjoint spanning trees.

The single non-elementary ingredient of the 8-flow theorem, admitted here as prior work. -/
axiom nash_williams_three_edge_disjoint_spanning_trees {α β : Type*} (G : Graph α β)
    (hV : V(G).Finite) (hE : E(G).Finite) (hconn : IsEdgeConnected G 6) :
    ∃ T₁ T₂ T₃ : Set β,
      IsSpanningTree G T₁ ∧ IsSpanningTree G T₂ ∧ IsSpanningTree G T₃ ∧
        Disjoint T₁ T₂ ∧ Disjoint T₁ T₃ ∧ Disjoint T₂ T₃

end Workspace.PriorWork

/-!
# Multigraph doubling and the doubling + projection step (Lemmas 3–4)

The graph-surgery infrastructure behind `three_spanning_trees_cover`: the edge-doubled multigraph
`double G : Graph α (β × Bool)` with its cut-size doubling and `6`-edge-connectivity, the
projection `π = Prod.fst` of a spanning tree of `2G` back to `G`, and the pigeonhole that every
edge lies outside some tree. Assembled into `doubling_covering`.
-/

open Set
open scoped Graph

namespace Workspace.PriorWorkProofs.EightFlow

variable {α β : Type*}

/-! ## A connected finite multigraph has at least `|V| - 1` edges -/

/-- The simple graph on the vertex subtype `↥V(H)` underlying a multigraph `H`: two distinct
vertices are adjacent iff they are joined by some edge of `H`. Parallel edges and loops are
collapsed, so its edge count is a *lower bound* proxy for `|E(H)|`. -/
def toSimpleGraph (H : Graph α β) : SimpleGraph ↥V(H) :=
  SimpleGraph.fromRel (fun a b => H.Adj a.1 b.1)

/-- Reachability in `H` lifts to reachability in `toSimpleGraph H`. -/
theorem toSimpleGraph_reachable (H : Graph α β) {x y : α} (hx : x ∈ V(H))
    (h : H.Reachable x y) : ∀ (hy : y ∈ V(H)),
      (toSimpleGraph H).Reachable ⟨x, hx⟩ ⟨y, hy⟩ := by
  induction h with
  | refl => intro hy; exact SimpleGraph.Reachable.refl _
  | @tail b c hxb hbc ih =>
      intro hc
      have hb : b ∈ V(H) := hbc.left_mem
      refine (ih hb).trans ?_
      by_cases hbc' : b = c
      · subst hbc'; exact SimpleGraph.Reachable.refl _
      · refine (show (toSimpleGraph H).Adj ⟨b, hb⟩ ⟨c, hc⟩ from ?_).reachable
        rw [toSimpleGraph, SimpleGraph.fromRel_adj]
        exact ⟨fun h => hbc' (Subtype.ext_iff.mp h), Or.inl hbc⟩

/-- `toSimpleGraph H` is connected whenever `H` is. -/
theorem toSimpleGraph_connected (H : Graph α β) (hconn : H.Connected) :
    (toSimpleGraph H).Connected := by
  obtain ⟨v₀, hv₀⟩ := hconn.nonempty
  rw [SimpleGraph.connected_iff]
  refine ⟨?_, ⟨⟨v₀, hv₀⟩⟩⟩
  rintro ⟨a, ha⟩ ⟨b, hb⟩
  exact toSimpleGraph_reachable H ha (hconn.reachable ha hb) hb

open Classical in
/-- A choice of `Sym2`-edge of `toSimpleGraph H` for each `β`-edge: the endpoints of `e`,
lifted to the vertex subtype (junk `s(v₀, v₀)` off `E(H)`). -/
noncomputable def emap (H : Graph α β) (v₀ : ↥V(H)) (e : β) : Sym2 ↥V(H) :=
  if h : ∃ x y, H.IsLink e x y then
    s(⟨h.choose, h.choose_spec.choose_spec.left_mem⟩,
      ⟨h.choose_spec.choose, h.choose_spec.choose_spec.right_mem⟩)
  else s(v₀, v₀)

/-- **Connected ⟹ `|V| ≤ |E| + 1`.** A connected multigraph with finitely many vertices and
edges has at least `|V(H)| - 1` edges. Proved by transporting to `toSimpleGraph H` and applying
`SimpleGraph.Connected.card_vert_le_card_edgeSet_add_one`; the simple graph's edges inject (via
`emap`) into `E(H)`, so its edge count bounds `|E(H)|`. -/
theorem connected_ncard_le (H : Graph α β) (hV : V(H).Finite) (hE : E(H).Finite)
    (hconn : H.Connected) : V(H).ncard ≤ E(H).ncard + 1 := by
  classical
  haveI : Finite ↥V(H) := hV.to_subtype
  obtain ⟨v₀, hv₀⟩ := hconn.nonempty
  have hSc := (toSimpleGraph_connected H hconn).card_vert_le_card_edgeSet_add_one
  have hcard_v : Nat.card ↥V(H) = V(H).ncard := Nat.card_coe_set_eq _
  -- the simple-graph edge set embeds into the image of `E(H)` under `emap`
  have hsub : (toSimpleGraph H).edgeSet ⊆ (emap H ⟨v₀, hv₀⟩) '' E(H) := by
    intro s hs
    induction s using Sym2.ind with
    | _ a b =>
      rw [SimpleGraph.mem_edgeSet, toSimpleGraph, SimpleGraph.fromRel_adj] at hs
      obtain ⟨hne, hor⟩ := hs
      -- pick an edge joining a.1 and b.1 (either orientation)
      obtain ⟨e, hlink⟩ : ∃ e, H.IsLink e a.1 b.1 := by
        rcases hor with h | h
        · exact h
        · obtain ⟨e, he⟩ := h; exact ⟨e, he.symm⟩
      refine ⟨e, hlink.edge_mem, ?_⟩
      have hex : ∃ x y, H.IsLink e x y := ⟨a.1, b.1, hlink⟩
      have hspec := hex.choose_spec.choose_spec
      rw [emap, dif_pos hex]
      -- endpoints of `e` are `{a.1, b.1}` up to swap
      rcases hspec.eq_and_eq_or_eq_and_eq hlink with ⟨h1, h2⟩ | ⟨h1, h2⟩
      · apply Sym2.eq_iff.mpr; left
        exact ⟨Subtype.ext h1, Subtype.ext h2⟩
      · apply Sym2.eq_iff.mpr; right
        exact ⟨Subtype.ext h1, Subtype.ext h2⟩
  have hfin_img : ((emap H ⟨v₀, hv₀⟩) '' E(H)).Finite := hE.image _
  have hbound : Nat.card ↥(toSimpleGraph H).edgeSet ≤ E(H).ncard := by
    rw [Nat.card_coe_set_eq]
    calc (toSimpleGraph H).edgeSet.ncard
        ≤ ((emap H ⟨v₀, hv₀⟩) '' E(H)).ncard := Set.ncard_le_ncard hsub hfin_img
      _ ≤ E(H).ncard := Set.ncard_image_le hE
  omega

/-! ## The edge-doubled multigraph `2G` -/

/-- The **edge-doubled** multigraph `2G := double G : Graph α (β × Bool)`: the vertex set is that
of `G`, and each edge is replaced by two parallel copies `(e, false)`, `(e, true)` with the same
incidence as `e`. The projection back to `G` is `Prod.fst`. -/
def double (G : Graph α β) : Graph α (β × Bool) where
  vertexSet := V(G)
  IsLink p x y := G.IsLink p.1 x y
  isLink_symm := by rintro p hp x y h; exact h.symm
  eq_or_eq_of_isLink_of_isLink := by rintro p x y v w h1 h2; exact h1.left_eq_or_eq h2
  left_mem_of_isLink := by rintro p x y h; exact h.left_mem

@[simp] lemma double_isLink (G : Graph α β) (p : β × Bool) (x y : α) :
    (double G).IsLink p x y ↔ G.IsLink p.1 x y := Iff.rfl

@[simp] lemma vertexSet_double (G : Graph α β) : V(double G) = V(G) := rfl

lemma vertexSet_double_finite (G : Graph α β) (hV : V(G).Finite) : V(double G).Finite := hV

/-- The edge set of `2G` is the preimage of `E(G)` under the projection: every copy of an edge of
`G`. -/
lemma edgeSet_double (G : Graph α β) : E(double G) = Prod.fst ⁻¹' E(G) := by
  ext p
  rw [Set.mem_preimage]
  constructor
  · intro hp
    obtain ⟨x, y, hxy⟩ := Graph.exists_isLink_of_mem_edgeSet hp
    exact (show G.IsLink p.1 x y from hxy).edge_mem
  · intro hp
    obtain ⟨x, y, hxy⟩ := Graph.exists_isLink_of_mem_edgeSet hp
    exact (show (double G).IsLink p x y from hxy).edge_mem

lemma edgeSet_double_finite (G : Graph α β) (hE : E(G).Finite) : E(double G).Finite := by
  rw [edgeSet_double]
  have hpre : Prod.fst ⁻¹' E(G) = E(G) ×ˢ (Set.univ : Set Bool) := by
    ext p; simp
  rw [hpre]
  exact hE.prod Set.finite_univ

/-- Each cut of `2G` is the preimage of the corresponding cut of `G`. -/
lemma cutEdges_double (G : Graph α β) (S : Set α) :
    cutEdges (double G) S = Prod.fst ⁻¹' (cutEdges G S) := by
  ext p
  simp only [cutEdges, Set.mem_preimage, Set.mem_sep_iff]
  constructor
  · rintro ⟨_, x, y, hxy, hxS, hyS⟩
    exact ⟨(show G.IsLink p.1 x y from hxy).edge_mem, x, y, hxy, hxS, hyS⟩
  · rintro ⟨_, x, y, hxy, hxS, hyS⟩
    exact ⟨(show (double G).IsLink p x y from hxy).edge_mem, x, y, hxy, hxS, hyS⟩

/-- **Lemma 3 (cut doubling).** Every cut of `2G` has exactly twice as many edges as the
corresponding cut of `G`. -/
lemma ncard_cutEdges_double (G : Graph α β) (S : Set α) :
    (cutEdges (double G) S).ncard = 2 * (cutEdges G S).ncard := by
  rw [cutEdges_double]
  have hpre : Prod.fst ⁻¹' (cutEdges G S) = (cutEdges G S) ×ˢ (Set.univ : Set Bool) := by
    ext p; simp
  rw [hpre, Set.ncard_prod, Set.ncard_univ, Nat.card_eq_fintype_card, Fintype.card_bool, mul_comm]

/-- **Lemma 3 (edge-connectivity doubling).** If `G` is `3`-edge-connected then `2G` is
`6`-edge-connected: each cut doubles. -/
lemma isEdgeConnected_double (G : Graph α β) (hconn : IsEdgeConnected G 3) :
    IsEdgeConnected (double G) 6 := by
  obtain ⟨hV2, hcut⟩ := hconn
  refine ⟨hV2, ?_⟩
  intro S hSne hSsub hScompl
  rw [ncard_cutEdges_double]
  have h3 := hcut S hSne hSsub hScompl
  omega

/-! ## Projecting a spanning tree of `2G` back to `G` -/

/-- The projection `π '' T` of an edge set of `2G` down to `G`. -/
def proj (T : Set (β × Bool)) : Set β := Prod.fst '' T

lemma mem_proj {T : Set (β × Bool)} {e : β} : e ∈ proj T ↔ ∃ b, (e, b) ∈ T := by
  simp only [proj, Set.mem_image]
  constructor
  · rintro ⟨p, hp, rfl⟩; exact ⟨p.2, by rw [Prod.mk.eta]; exact hp⟩
  · rintro ⟨b, hb⟩; exact ⟨(e, b), hb, rfl⟩

lemma proj_subset (G : Graph α β) {T : Set (β × Bool)} (hT : T ⊆ E(double G)) :
    proj T ⊆ E(G) := by
  intro e he
  rw [mem_proj] at he
  obtain ⟨b, hb⟩ := he
  have hmem : (e, b) ∈ E(double G) := hT hb
  rwa [edgeSet_double, Set.mem_preimage] at hmem

/-- A walk in `(2G).restrict T` projects to a walk in `G.restrict (π T)`. -/
lemma restrict_double_reachable (G : Graph α β) (T : Set (β × Bool)) {x y : α}
    (h : ((double G).restrict T).Reachable x y) :
    (G.restrict (proj T)).Reachable x y := by
  induction h with
  | refl => exact Graph.Reachable.rfl
  | @tail b c _ hbc ih =>
      refine ih.tail ?_
      obtain ⟨p, hp⟩ := hbc
      rw [Graph.restrict_isLink] at hp
      obtain ⟨hpT, hlink⟩ := hp
      refine ⟨p.1, ?_⟩
      rw [Graph.restrict_isLink]
      exact ⟨mem_proj.mpr ⟨p.2, by rw [Prod.mk.eta]; exact hpT⟩, hlink⟩

/-- The projection of a connected spanning subgraph of `2G` is a connected spanning subgraph of
`G`. -/
lemma restrict_double_connected (G : Graph α β) {T : Set (β × Bool)}
    (h : ((double G).restrict T).Connected) : (G.restrict (proj T)).Connected := by
  have hV1 : V((double G).restrict T) = V(G) := by
    rw [Graph.vertexSet_restrict, vertexSet_double]
  have hV2 : V(G.restrict (proj T)) = V(G) := Graph.vertexSet_restrict _ _
  obtain ⟨v₀, hv₀⟩ := h.nonempty
  rw [hV1] at hv₀
  refine Graph.connected_of_forall_reachable (x := v₀) (by rw [hV2]; exact hv₀) ?_
  intro y hy
  rw [hV2] at hy
  exact restrict_double_reachable G T (h.reachable (by rw [hV1]; exact hv₀) (by rw [hV1]; exact hy))

/-- **Lemma 4 (projection is a spanning tree).** The projection of a spanning tree of `2G` is a
spanning tree of `G`. The edge-count equality uses `connected_ncard_le` for the lower bound and
`Set.ncard_image_le` for the upper bound. -/
lemma isSpanningTree_proj (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    {T : Set (β × Bool)} (hT : IsSpanningTree (double G) T) : IsSpanningTree G (proj T) := by
  obtain ⟨hTsub, hTconn, hTcard⟩ := hT
  refine ⟨proj_subset G hTsub, restrict_double_connected G hTconn, ?_⟩
  have hTfin : T.Finite := (edgeSet_double_finite G hE).subset hTsub
  have hup : (proj T).ncard ≤ T.ncard := Set.ncard_image_le hTfin
  have hTcard' : T.ncard + 1 = V(G).ncard := by rwa [vertexSet_double] at hTcard
  have hpsub : proj T ⊆ E(G) := proj_subset G hTsub
  have hErestr : E(G.restrict (proj T)) = proj T := by
    rw [Graph.edgeSet_restrict, Set.inter_eq_right.mpr hpsub]
  have hVrestr : V(G.restrict (proj T)) = V(G) := Graph.vertexSet_restrict _ _
  have hlow : V(G).ncard ≤ (proj T).ncard + 1 := by
    have hc := connected_ncard_le (G.restrict (proj T)) (by rw [hVrestr]; exact hV)
      (by rw [hErestr]; exact hE.subset hpsub) (restrict_double_connected G hTconn)
    rwa [hVrestr, hErestr] at hc
  omega

/-- **The "≤ 2 of 3" pigeonhole.** Three pairwise edge-disjoint edge sets of `2G` project so that
every edge of `G` lies outside at least one projection: each edge has only two copies, and each
copy lies in at most one of the three disjoint sets. -/
lemma proj_cover (G : Graph α β) {T₁ T₂ T₃ : Set (β × Bool)}
    (h12 : Disjoint T₁ T₂) (h13 : Disjoint T₁ T₃) (h23 : Disjoint T₂ T₃) :
    ∀ e ∈ E(G), e ∉ proj T₁ ∨ e ∉ proj T₂ ∨ e ∉ proj T₃ := by
  intro e _
  by_contra hcon
  push_neg at hcon
  obtain ⟨h1, h2, h3⟩ := hcon
  rw [mem_proj] at h1 h2 h3
  obtain ⟨b1, hb1⟩ := h1
  obtain ⟨b2, hb2⟩ := h2
  obtain ⟨b3, hb3⟩ := h3
  have hpigeon : b1 = b2 ∨ b1 = b3 ∨ b2 = b3 := by
    rcases b1 <;> rcases b2 <;> rcases b3 <;> tauto
  rcases hpigeon with h | h | h
  · exact (Set.disjoint_left.mp h12 hb1) (by rw [h]; exact hb2)
  · exact (Set.disjoint_left.mp h13 hb1) (by rw [h]; exact hb3)
  · exact (Set.disjoint_left.mp h23 hb2) (by rw [h]; exact hb3)

/-! ## The doubling + projection step (`three_spanning_trees_cover`) -/

/-- **Lemmas 3–4 assembled.** A `3`-edge-connected finite multigraph has three spanning trees
such that every edge lies outside at least one of them. Route: double to `2G` (`6`-edge-connected
by `isEdgeConnected_double`), apply the Nash–Williams axiom to get three edge-disjoint spanning
trees of `2G`, project them back to `G` (`isSpanningTree_proj`), and use the pigeonhole
`proj_cover`. This is exactly the statement of `three_spanning_trees_cover`. -/
theorem doubling_covering (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (hconn : IsEdgeConnected G 3) :
    ∃ T₁ T₂ T₃ : Set β,
      IsSpanningTree G T₁ ∧ IsSpanningTree G T₂ ∧ IsSpanningTree G T₃ ∧
        ∀ e ∈ E(G), e ∉ T₁ ∨ e ∉ T₂ ∨ e ∉ T₃ := by
  have hconn6 : IsEdgeConnected (double G) 6 := isEdgeConnected_double G hconn
  obtain ⟨T₁, T₂, T₃, hT₁, hT₂, hT₃, h12, h13, h23⟩ :=
    Workspace.PriorWork.nash_williams_three_edge_disjoint_spanning_trees (double G)
      (vertexSet_double_finite G hV) (edgeSet_double_finite G hE) hconn6
  exact ⟨proj T₁, proj T₂, proj T₃,
    isSpanningTree_proj G hV hE hT₁, isSpanningTree_proj G hV hE hT₂,
    isSpanningTree_proj G hV hE hT₃, proj_cover G h12 h13 h23⟩

end Workspace.PriorWorkProofs.EightFlow

/-!
# The cut sum of a flow (handshake / double-counting)

For any characteristic-two `A`-flow `f` of a finite multigraph `G` and any `S ⊆ V(G)`, the sum of
`f` over the edge cut of `S` is zero (`flow_cutSum_zero`), by the classical double-counting
argument. The corollary `flow_two_cut` specialises to a two-edge cut `{e₁, e₂}`: `f e₁ + f e₂ = 0`.
-/

open Set
open scoped Graph
open scoped Classical
open Workspace.Types.Gamma
open Workspace.Types.Orientation

namespace Workspace.PriorWorkProofs.EightFlow

variable {α β : Type*} {G : Graph α β}

/-- Membership in the edge cut, unfolded. -/
private lemma mem_cutEdges_iff {S : Set α} {e : β} :
    e ∈ cutEdges G S ↔ e ∈ E(G) ∧ ∃ x y, G.IsLink e x y ∧ x ∈ S ∧ y ∉ S :=
  Iff.rfl

/-- The per-edge contribution to the double count. For an edge `e ∈ E(G)`, the number of its ends
lying in `S` (each end counted, `f e` per end) equals `f e` iff `e` is a cut edge, and cancels
(`2 • f e = 0` in characteristic two) or vanishes otherwise. -/
private lemma cut_edge_end_sum {A : Type*} [AddCommGroup A] (hchar : ∀ a : A, a + a = 0)
    (O : Orientation G) (f : β → A) (S : Set α) {e : β} (he : e ∈ E(G)) :
    ((if O.tail e ∈ S then f e else 0) + (if O.head e ∈ S then f e else 0))
      = if e ∈ cutEdges G S then f e else 0 := by
  classical
  have hmem : e ∈ cutEdges G S ↔
      (O.tail e ∈ S ∧ O.head e ∉ S) ∨ (O.head e ∈ S ∧ O.tail e ∉ S) := by
    rw [mem_cutEdges_iff]
    constructor
    · rintro ⟨-, x, y, hlink, hx, hy⟩
      rcases (O.isLink_iff he).1 hlink with ⟨ht, hh⟩ | ⟨ht, hh⟩
      · exact Or.inl ⟨by rw [ht]; exact hx, by rw [hh]; exact hy⟩
      · exact Or.inr ⟨by rw [hh]; exact hx, by rw [ht]; exact hy⟩
    · rintro (⟨ht, hh⟩ | ⟨hh, ht⟩)
      · exact ⟨he, O.tail e, O.head e, O.isLink_tail_head he, ht, hh⟩
      · exact ⟨he, O.head e, O.tail e, O.isLink_head_tail he, hh, ht⟩
  by_cases ht : O.tail e ∈ S
  · by_cases hh : O.head e ∈ S
    · have hcut : e ∉ cutEdges G S := by rw [hmem]; tauto
      rw [if_pos ht, if_pos hh, if_neg hcut]; exact hchar _
    · have hcut : e ∈ cutEdges G S := by rw [hmem]; tauto
      rw [if_pos ht, if_neg hh, if_pos hcut, add_zero]
  · by_cases hh : O.head e ∈ S
    · have hcut : e ∈ cutEdges G S := by rw [hmem]; tauto
      rw [if_neg ht, if_pos hh, if_pos hcut, zero_add]
    · have hcut : e ∉ cutEdges G S := by rw [hmem]; tauto
      rw [if_neg ht, if_neg hh, if_neg hcut, add_zero]

/-- **The cut sum of a flow vanishes** (handshake / double counting). For a flow `f` valued in a
characteristic-two group and any `S ⊆ V(G)`, the sum of `f` over the edges of the cut `∂S` is
zero. -/
theorem flow_cutSum_zero {A : Type*} [AddCommGroup A] (hchar : ∀ a : A, a + a = 0)
    (hV : V(G).Finite) (hE : E(G).Finite) (O : Orientation G) {f : β → A}
    (hf : G.IsFlow O f) {S : Set α} (hS : S ⊆ V(G)) :
    (∑ᶠ e ∈ cutEdges G S, f e) = 0 := by
  classical
  haveI hdec : DecidableEq α := Classical.decEq α
  have hSfin : S.Finite := hV.subset hS
  have hcut_sub : cutEdges G S ⊆ E(G) := fun e he => (mem_cutEdges_iff.1 he).1
  have hcutfin : (cutEdges G S).Finite := hE.subset hcut_sub
  have hflow := (Graph.isFlow_iff_finset_sum hE).1 hf
  -- Sum of tails over S, reorganised by edge.
  have hTS : (∑ v ∈ hSfin.toFinset, ∑ e ∈ hE.toFinset with O.tail e = v, f e)
      = ∑ e ∈ hE.toFinset, if O.tail e ∈ S then f e else 0 := by
    calc (∑ v ∈ hSfin.toFinset, ∑ e ∈ hE.toFinset with O.tail e = v, f e)
        = ∑ v ∈ hSfin.toFinset, ∑ e ∈ hE.toFinset, (if O.tail e = v then f e else 0) := by
          refine Finset.sum_congr rfl (fun v _ => ?_)
          rw [Finset.sum_filter]
      _ = ∑ e ∈ hE.toFinset, ∑ v ∈ hSfin.toFinset, (if O.tail e = v then f e else 0) :=
          Finset.sum_comm
      _ = ∑ e ∈ hE.toFinset, if O.tail e ∈ S then f e else 0 := by
          refine Finset.sum_congr rfl (fun e _ => ?_)
          simp only [Finset.sum_ite_eq, Set.Finite.mem_toFinset]
  -- Sum of heads over S, reorganised by edge.
  have hHS : (∑ v ∈ hSfin.toFinset, ∑ e ∈ hE.toFinset with O.head e = v, f e)
      = ∑ e ∈ hE.toFinset, if O.head e ∈ S then f e else 0 := by
    calc (∑ v ∈ hSfin.toFinset, ∑ e ∈ hE.toFinset with O.head e = v, f e)
        = ∑ v ∈ hSfin.toFinset, ∑ e ∈ hE.toFinset, (if O.head e = v then f e else 0) := by
          refine Finset.sum_congr rfl (fun v _ => ?_)
          rw [Finset.sum_filter]
      _ = ∑ e ∈ hE.toFinset, ∑ v ∈ hSfin.toFinset, (if O.head e = v then f e else 0) :=
          Finset.sum_comm
      _ = ∑ e ∈ hE.toFinset, if O.head e ∈ S then f e else 0 := by
          refine Finset.sum_congr rfl (fun e _ => ?_)
          simp only [Finset.sum_ite_eq, Set.Finite.mem_toFinset]
  -- The aggregated cut sum equals the double sum over vertices of S.
  have agg : (∑ e ∈ hE.toFinset, if e ∈ cutEdges G S then f e else 0)
      = ∑ v ∈ hSfin.toFinset,
          ((∑ e ∈ hE.toFinset with O.tail e = v, f e)
            + (∑ e ∈ hE.toFinset with O.head e = v, f e)) := by
    calc (∑ e ∈ hE.toFinset, if e ∈ cutEdges G S then f e else 0)
        = ∑ e ∈ hE.toFinset,
            ((if O.tail e ∈ S then f e else 0) + (if O.head e ∈ S then f e else 0)) := by
          refine Finset.sum_congr rfl (fun e he => ?_)
          rw [cut_edge_end_sum hchar O f S (hE.mem_toFinset.1 he)]
      _ = (∑ e ∈ hE.toFinset, if O.tail e ∈ S then f e else 0)
            + (∑ e ∈ hE.toFinset, if O.head e ∈ S then f e else 0) := by
          rw [Finset.sum_add_distrib]
      _ = (∑ v ∈ hSfin.toFinset, ∑ e ∈ hE.toFinset with O.tail e = v, f e)
            + (∑ v ∈ hSfin.toFinset, ∑ e ∈ hE.toFinset with O.head e = v, f e) := by
          rw [← hTS, ← hHS]
      _ = ∑ v ∈ hSfin.toFinset,
            ((∑ e ∈ hE.toFinset with O.tail e = v, f e)
              + (∑ e ∈ hE.toFinset with O.head e = v, f e)) := by
          rw [← Finset.sum_add_distrib]
  -- The double sum over vertices of S is zero: each vertex contributes tail = head, so 2•=0.
  have zero : (∑ v ∈ hSfin.toFinset,
      ((∑ e ∈ hE.toFinset with O.tail e = v, f e)
        + (∑ e ∈ hE.toFinset with O.head e = v, f e))) = 0 := by
    refine Finset.sum_eq_zero (fun v hv => ?_)
    have hvV : v ∈ V(G) := hS (hSfin.mem_toFinset.1 hv)
    rw [← hflow v hvV]
    exact hchar _
  have hzero : (∑ e ∈ hE.toFinset, if e ∈ cutEdges G S then f e else 0) = 0 := agg.trans zero
  -- Convert the target finsum into the finset sum we just showed is zero.
  have hfilter : hcutfin.toFinset = hE.toFinset.filter (· ∈ cutEdges G S) := by
    ext e
    simp only [Set.Finite.mem_toFinset, Finset.mem_filter]
    exact ⟨fun h => ⟨hcut_sub h, h⟩, fun h => h.2⟩
  rw [← hcutfin.coe_toFinset, finsum_mem_coe_finset, hfilter, Finset.sum_filter]
  exact hzero

/-- **Two-edge cut corollary.** If the cut of `S` is exactly the two-element set `{e₁, e₂}`, then
`f e₁ + f e₂ = 0`. -/
theorem flow_two_cut {A : Type*} [AddCommGroup A] (hchar : ∀ a : A, a + a = 0)
    (hV : V(G).Finite) (hE : E(G).Finite) (O : Orientation G) {f : β → A}
    (hf : G.IsFlow O f) {S : Set α} (hS : S ⊆ V(G)) {e₁ e₂ : β} (hne : e₁ ≠ e₂)
    (hcut : cutEdges G S = {e₁, e₂}) :
    f e₁ + f e₂ = 0 := by
  have h := flow_cutSum_zero hchar hV hE O hf hS
  rw [hcut] at h
  rwa [finsum_mem_pair hne] at h

end Workspace.PriorWorkProofs.EightFlow

open Set
open scoped Graph

namespace Workspace.PriorWorkProofs.EightFlow

variable {α β : Type*} {G : Graph α β}

/-- Membership in `cutEdges` unfolds to the defining conjunction. -/
theorem mem_cutEdges {G : Graph α β} {S : Set α} {e : β} :
    e ∈ cutEdges G S ↔ e ∈ E(G) ∧ ∃ x y, G.IsLink e x y ∧ x ∈ S ∧ y ∉ S := Iff.rfl

/-! ### G1 — a walk crossing a cut uses a crossing edge -/

theorem exists_cross_of_reachable {H : Graph α β} {x y : α} (S : Set α)
    (hx : x ∈ S) (hy : y ∉ S) (h : H.Reachable x y) :
    ∃ e a b, H.IsLink e a b ∧ a ∈ S ∧ b ∉ S := by
  rw [Graph.reachable_def] at h
  revert hy
  induction h with
  | refl => intro hy; exact absurd hx hy
  | @tail b c hab hbc ih =>
      intro hc
      by_cases hb : b ∈ S
      · obtain ⟨e, he⟩ := hbc
        exact ⟨e, b, c, he, hb, hc⟩
      · exact ih hb

/-! ### G2 — connected ⇔ every nontrivial cut is nonempty -/

theorem exists_cross_of_connected (hconn : G.Connected) {S : Set α}
    (hSne : S.Nonempty) (hScompl : (V(G) \ S).Nonempty) (hS : S ⊆ V(G)) :
    ∃ e a b, G.IsLink e a b ∧ a ∈ S ∧ b ∉ S := by
  obtain ⟨a, ha⟩ := hSne
  obtain ⟨b, hbV, hbnS⟩ := hScompl
  have haV : a ∈ V(G) := hS ha
  have hr : G.Reachable a b := hconn.reachable haV hbV
  exact exists_cross_of_reachable S ha hbnS hr

theorem cutEdges_nonempty_of_connected (hconn : G.Connected) {S : Set α}
    (hSne : S.Nonempty) (hScompl : (V(G) \ S).Nonempty) (hS : S ⊆ V(G)) :
    (cutEdges G S).Nonempty := by
  obtain ⟨e, a, b, hab, haS, hbnS⟩ := exists_cross_of_connected hconn hSne hScompl hS
  exact ⟨e, by rw [mem_cutEdges]; exact ⟨hab.edge_mem, a, b, hab, haS, hbnS⟩⟩

theorem connected_of_cutEdges_pos (hne : V(G).Nonempty)
    (h : ∀ S : Set α, S.Nonempty → S ⊆ V(G) → (V(G) \ S).Nonempty → (cutEdges G S).Nonempty) :
    G.Connected := by
  obtain ⟨v₀, hv₀⟩ := hne
  by_cases hEq : ∀ y ∈ V(G), G.Reachable v₀ y
  · exact Graph.connected_of_forall_reachable hv₀ hEq
  · push_neg at hEq
    obtain ⟨w, hwV, hwnr⟩ := hEq
    set S₀ : Set α := {z ∈ V(G) | G.Reachable v₀ z} with hS₀
    have hv₀S : v₀ ∈ S₀ := by rw [hS₀]; exact ⟨hv₀, Graph.Reachable.rfl⟩
    have hS₀sub : S₀ ⊆ V(G) := by rw [hS₀]; intro z hz; exact hz.1
    have hwnS : w ∉ S₀ := by rw [hS₀]; intro hz; exact hwnr hz.2
    obtain ⟨e, he⟩ := h S₀ ⟨v₀, hv₀S⟩ hS₀sub ⟨w, hwV, hwnS⟩
    rw [mem_cutEdges] at he
    obtain ⟨_, a, b, hab, haS, hbnS⟩ := he
    rw [hS₀] at haS
    exfalso
    apply hbnS
    rw [hS₀]
    exact ⟨hab.right_mem, haS.2.tail ⟨e, hab⟩⟩

/-! ### G3 — bridgeless ⇔ no nontrivial 1-edge cut -/

theorem cutEdges_ne_one_of_bridgeless (hbr : G.Bridgeless) {S : Set α}
    (hSne : S.Nonempty) (hS : S ⊆ V(G)) (hScompl : (V(G) \ S).Nonempty) :
    (cutEdges G S).ncard ≠ 1 := by
  intro hone
  rw [Set.ncard_eq_one] at hone
  obtain ⟨e, heq⟩ := hone
  have hemem : e ∈ cutEdges G S := by rw [heq]; exact Set.mem_singleton e
  rw [mem_cutEdges] at hemem
  obtain ⟨heE, x, y, hxy, hxS, hynS⟩ := hemem
  have hbridge : G.IsBridge e := by
    refine ⟨x, y, hxy, ?_⟩
    intro hr
    obtain ⟨e', a, b, hab, haS, hbnS⟩ := exists_cross_of_reachable S hxS hynS hr
    rw [Graph.deleteEdges_isLink] at hab
    obtain ⟨hab', hne⟩ := hab
    have hmem' : e' ∈ cutEdges G S := by
      rw [mem_cutEdges]; exact ⟨hab'.edge_mem, a, b, hab', haS, hbnS⟩
    rw [heq] at hmem'
    exact hne hmem'
  exact hbr.not_isBridge e hbridge

/-! ### G4 — connected from 3-edge-connected -/

theorem connected_of_isEdgeConnected3 (h : IsEdgeConnected G 3) : G.Connected := by
  obtain ⟨h2V, hcut⟩ := h
  have hVne : V(G).Nonempty := Set.nonempty_of_ncard_ne_zero (by omega)
  refine connected_of_cutEdges_pos hVne ?_
  intro S hSne hSsub hScompl
  have h3 := hcut S hSne hSsub hScompl
  exact Set.nonempty_of_ncard_ne_zero (by omega)

/-! ### G5 — extraction of a two-edge cut -/

theorem exists_two_edge_cut (hE : E(G).Finite) (hbr : G.Bridgeless)
    (hconn : G.Connected) (hn3 : ¬ IsEdgeConnected G 3) (h2V : 2 ≤ V(G).ncard) :
    ∃ (S : Set α) (e₁ e₂ : β) (x y : α),
      S.Nonempty ∧ S ⊆ V(G) ∧ (V(G) \ S).Nonempty ∧
      e₁ ≠ e₂ ∧ cutEdges G S = {e₁, e₂} ∧
      G.IsLink e₁ x y ∧ x ∈ S ∧ y ∉ S ∧ x ≠ y ∧ e₂ ∈ E(G) := by
  have hn3' : ∃ S : Set α, S.Nonempty ∧ S ⊆ V(G) ∧ (V(G) \ S).Nonempty ∧
      (cutEdges G S).ncard < 3 := by
    by_contra hcon
    push_neg at hcon
    exact hn3 ⟨h2V, fun S hs hsub hcompl => hcon S hs hsub hcompl⟩
  obtain ⟨S, hSne, hSsub, hScompl, hlt⟩ := hn3'
  have hfin : (cutEdges G S).Finite := hE.subset (fun e he => (mem_cutEdges.mp he).1)
  have hpos : (cutEdges G S).Nonempty := cutEdges_nonempty_of_connected hconn hSne hScompl hSsub
  have hne1 : (cutEdges G S).ncard ≠ 1 := cutEdges_ne_one_of_bridgeless hbr hSne hSsub hScompl
  have h1 : 1 ≤ (cutEdges G S).ncard := (Set.ncard_pos hfin).mpr hpos
  have h2 : (cutEdges G S).ncard = 2 := by omega
  rw [Set.ncard_eq_two] at h2
  obtain ⟨e₁, e₂, hne12, heq⟩ := h2
  have he1mem : e₁ ∈ cutEdges G S := by rw [heq]; exact Set.mem_insert e₁ _
  rw [mem_cutEdges] at he1mem
  obtain ⟨he1E, x, y, hxy, hxS, hynS⟩ := he1mem
  have hxy_ne : x ≠ y := fun hxeqy => hynS (hxeqy ▸ hxS)
  have he2mem : e₂ ∈ cutEdges G S := by rw [heq]; exact Set.mem_insert_of_mem _ rfl
  have he2E : e₂ ∈ E(G) := (mem_cutEdges.mp he2mem).1
  exact ⟨S, e₁, e₂, x, y, hSne, hSsub, hScompl, hne12, heq, hxy, hxS, hynS, hxy_ne, he2E⟩

end Workspace.PriorWorkProofs.EightFlow

open Set
open scoped Graph
open Workspace.PriorWorkProofs.Tutte

namespace Workspace.PriorWorkProofs.EightFlow

variable {α β : Type*} [DecidableEq α] {G : Graph α β}

/-- **GOAL 1.** Reachability pushes forward through contraction: a walk in `G − e'` maps to a
walk in `(G / e₁) − e'` under the merge map. The contracted edge `e₁` collapses its two ends to
a single vertex, so any step of the original walk that used `e₁` becomes a no-op. -/
theorem reachable_deleteEdges_contract {e₁ e' : β} {x y : α} (hxy : G.IsLink e₁ x y) {u v : α}
    (h : (G.deleteEdges {e'}).Reachable u v) :
    ((contract G e₁ x y).deleteEdges {e'}).Reachable (mergeMap x y u) (mergeMap x y v) := by
  -- `mergeMap x y` sends both ends of `e₁` to `x`.
  have hmerge : ∀ z : α, z = x ∨ z = y → mergeMap x y z = x := by
    rintro z (hz | hz)
    · rw [hz]; unfold mergeMap; split_ifs <;> rfl
    · rw [hz]; exact mergeMap_self x y
  induction h with
  | refl => exact Graph.Reachable.rfl
  | @tail p q hup hpq ih =>
    obtain ⟨e'', hf⟩ := hpq
    rw [Graph.deleteEdges_isLink] at hf
    obtain ⟨hLpq, hne'⟩ := hf
    by_cases hee : e'' = e₁
    · -- The step uses the contracted edge, so its two images coincide: no progress.
      subst hee
      have hpq_eq : mergeMap x y p = mergeMap x y q := by
        rcases hLpq.eq_and_eq_or_eq_and_eq hxy with ⟨hp, hq⟩ | ⟨hp, hq⟩
        · rw [hmerge p (Or.inl hp), hmerge q (Or.inr hq)]
        · rw [hmerge p (Or.inr hp), hmerge q (Or.inl hq)]
      rw [← hpq_eq]; exact ih
    · -- The step survives contraction as a genuine edge of `(G / e₁) − e'`.
      have hcontract : (contract G e₁ x y).IsLink e'' (mergeMap x y p) (mergeMap x y q) := by
        rw [contract_isLink]
        exact ⟨hee, p, q, hLpq, rfl, rfl⟩
      have hdel : ((contract G e₁ x y).deleteEdges {e'}).IsLink e''
          (mergeMap x y p) (mergeMap x y q) := by
        rw [Graph.deleteEdges_isLink]
        exact ⟨hcontract, hne'⟩
      exact ih.tail ⟨e'', hdel⟩

/-- **GOAL 2.** Contracting a (non-loop) edge preserves bridgelessness. -/
theorem contract_bridgeless {e₁ : β} {x y : α} (hbr : G.Bridgeless) (hxy : G.IsLink e₁ x y) :
    (contract G e₁ x y).Bridgeless := by
  apply Graph.bridgeless_of_forall_reachable
  intro e' _he' a b hab
  rw [contract_isLink] at hab
  obtain ⟨_hne, a', b', hLab, ha, hb⟩ := hab
  -- `e'` is a genuine edge of `G`, and `G` is bridgeless, so its ends stay connected in `G − e'`.
  have hnb : ¬ G.IsBridge e' := hbr.not_isBridge e'
  rw [Graph.isBridge_def] at hnb
  push_neg at hnb
  have hreach : (G.deleteEdges {e'}).Reachable a' b' := hnb a' b' hLab
  -- Push that walk through the contraction.
  have key := reachable_deleteEdges_contract hxy hreach
  rw [ha, hb] at key
  exact key

/-- **GOAL 3.** Contracting an existing edge strictly drops the edge count. -/
theorem edgeSet_contract_ncard_lt {e₁ : β} {x y : α} (hE : E(G).Finite) (he₁ : e₁ ∈ E(G)) :
    (E(contract G e₁ x y)).ncard < E(G).ncard := by
  rw [edgeSet_contract]
  exact Set.ncard_diff_singleton_lt_of_mem he₁ hE

end Workspace.PriorWorkProofs.EightFlow

/-!
# Splitting a graph at a 0-edge-cut (a "closed" vertex set)

We split a graph `G` at a set `X` of vertices across which **no** edge crosses: every edge
of `G` has both ends inside `X` or both ends outside `X`
(`hclosed : ∀ e a b, G.IsLink e a b → (a ∈ X ↔ b ∈ X)`).  This is the 0-edge-cut condition.
We work with Mathlib's induced subgraph `Graph.induce X`.

* `induce_bridgeless` — the induced subgraph on a closed vertex set of a bridgeless graph is
  again bridgeless.
* `gamma_flow_of_closed_split` — if both sides of a 0-edge-cut carry a nowhere-zero `Γ`-flow
  (for every orientation), then so does `G`.  The glued map is the indicator-style piecewise
  `f e := if e ∈ E(G.induce S) then fA e else fB e`.
-/

open Set
open scoped Graph
open Workspace.Types.Gamma
open Workspace.Types.Orientation

namespace Workspace.PriorWorkProofs.EightFlow

open scoped Classical

variable {α β : Type*} {G : Graph α β}

/-! ## Elementary facts about a closed vertex set -/

/-- If an edge of `G` is an edge of the induced subgraph `G.induce X` and `p` is one of its ends
in `G`, then `p ∈ X`.  (The ends of an induced edge lie in `X`.) -/
theorem end_mem_of_edge_induce {X : Set α} {e : β} {p q : α}
    (he : e ∈ E(G.induce X)) (hpq : G.IsLink e p q) : p ∈ X := by
  rw [Graph.edgeSet_induce, Set.mem_setOf_eq] at he
  obtain ⟨x, y, hxy, hxX, hyX⟩ := he
  rcases hpq.eq_and_eq_or_eq_and_eq hxy with ⟨rfl, _⟩ | ⟨rfl, _⟩
  · exact hxX
  · exact hyX

/-! ## GOAL 1 — induced subgraph on a closed vertex set stays bridgeless -/

/-- A walk in `G - e'` between two vertices of a closed set `X` lifts to a walk in
`(G.induce X) - e'`: since no edge crosses `X`, every vertex the walk visits stays in `X`, and
every edge it uses has both ends in `X`, hence survives in the induced subgraph. -/
theorem reachable_induce_of_reachable_deleteEdges {X : Set α} {e' : β}
    (hclosed : ∀ e a b, G.IsLink e a b → (a ∈ X ↔ b ∈ X)) {u v : α} (hu : u ∈ X)
    (h : (G.deleteEdges {e'}).Reachable u v) :
    ((G.induce X).deleteEdges {e'}).Reachable u v := by
  suffices hsuf : ((G.induce X).deleteEdges {e'}).Reachable u v ∧ v ∈ X from hsuf.1
  induction h with
  | refl => exact ⟨Graph.Reachable.refl _ _, hu⟩
  | @tail b c hab hbc ih =>
      obtain ⟨hru, hbX⟩ := ih
      obtain ⟨f, hf⟩ := hbc
      rw [Graph.deleteEdges_isLink] at hf
      obtain ⟨hflink, hfne⟩ := hf
      have hcX : c ∈ X := (hclosed f b c hflink).mp hbX
      refine ⟨hru.tail ⟨f, ?_⟩, hcX⟩
      rw [Graph.deleteEdges_isLink]
      refine ⟨?_, hfne⟩
      rw [Graph.induce_isLink]
      exact ⟨hflink, hbX, hcX⟩

/-- **GOAL 1.** The induced subgraph on a closed vertex set of a bridgeless graph is bridgeless. -/
theorem induce_bridgeless {X : Set α} (hbr : G.Bridgeless)
    (hclosed : ∀ e a b, G.IsLink e a b → (a ∈ X ↔ b ∈ X)) :
    (G.induce X).Bridgeless := by
  apply Graph.bridgeless_of_forall_reachable
  intro e' _ a b hlink
  rw [Graph.induce_isLink] at hlink
  obtain ⟨hlinkG, haX, _hbX⟩ := hlink
  have he'G : e' ∈ E(G) := hlinkG.edge_mem
  have hnb : ¬ G.IsBridge e' := hbr.not_isBridge e'
  have hreach : (G.deleteEdges {e'}).Reachable a b := by
    by_contra hcon
    exact hnb ⟨a, b, hlinkG, hcon⟩
  exact reachable_induce_of_reachable_deleteEdges hclosed haX hreach

/-! ## GOAL 2 — flow gluing across a 0-edge-cut -/

/-- The characteristic-two edge-end sum at a vertex `v ∈ X` is unchanged when passing from `G` to
the induced subgraph `G.induce X`, provided the two maps agree on the edges incident to `v` in the
induced subgraph.  The index set `G.incidenceSet v` equals `(G.induce X).incidenceSet v` (no edge
crosses `X`), and the loop indicator agrees. -/
theorem endSum_restrict {A : Type*} [AddCommGroup A] {X : Set α} {v : α}
    (hclosed : ∀ e a b, G.IsLink e a b → (a ∈ X ↔ b ∈ X))
    (hv : v ∈ X) (g g' : β → A)
    (hagree : ∀ e ∈ (G.induce X).incidenceSet v, g e = g' e) :
    (∑ᶠ e ∈ G.incidenceSet v, (if G.IsLoopAt e v then (2 : ℕ) else 1) • g e)
      = (∑ᶠ e ∈ (G.induce X).incidenceSet v,
          (if (G.induce X).IsLoopAt e v then (2 : ℕ) else 1) • g' e) := by
  refine finsum_mem_congr ?_ ?_
  · -- the two incidence sets coincide
    ext e
    rw [Graph.mem_incidenceSet, Graph.mem_incidenceSet]
    constructor
    · intro he
      obtain ⟨w, hlink⟩ := he
      have hwX : w ∈ X := (hclosed e v w hlink).mp hv
      exact ⟨w, by rw [Graph.induce_isLink]; exact ⟨hlink, hv, hwX⟩⟩
    · intro he
      obtain ⟨w, hlink⟩ := he
      rw [Graph.induce_isLink] at hlink
      exact ⟨w, hlink.1⟩
  · -- the summands agree pointwise on the induced incidence set
    intro e he
    have hg : g e = g' e := hagree e he
    have hiff : G.IsLoopAt e v ↔ (G.induce X).IsLoopAt e v := by
      show G.IsLink e v v ↔ (G.induce X).IsLink e v v
      rw [Graph.induce_isLink]
      exact ⟨fun h => ⟨h, hv, hv⟩, fun h => h.1⟩
    have hloop : (if G.IsLoopAt e v then (2 : ℕ) else 1)
        = (if (G.induce X).IsLoopAt e v then (2 : ℕ) else 1) := by
      by_cases hl : G.IsLoopAt e v
      · rw [if_pos hl, if_pos (hiff.mp hl)]
      · rw [if_neg hl, if_neg (fun h => hl (hiff.mpr h))]
    rw [hloop, hg]

/-- **GOAL 2.** Flow gluing across a 0-edge-cut.  If the two induced subgraphs on `S` and its
complement `V(G) \ S` (across which no edge crosses) each carry a nowhere-zero `Γ`-flow for every
orientation, then `G` carries a nowhere-zero `Γ`-flow. -/
theorem gamma_flow_of_closed_split (hV : V(G).Finite) (hE : E(G).Finite) {S : Set α}
    (hS : S ⊆ V(G)) (hclosed : ∀ e a b, G.IsLink e a b → (a ∈ S ↔ b ∈ S))
    (hA : ∀ O' : Orientation (G.induce S), ∃ f : β → Gamma,
            (G.induce S).IsFlow O' f ∧ (G.induce S).IsNowhereZero f)
    (hB : ∀ O' : Orientation (G.induce (V(G) \ S)), ∃ f : β → Gamma,
            (G.induce (V(G) \ S)).IsFlow O' f ∧ (G.induce (V(G) \ S)).IsNowhereZero f)
    (O : Orientation G) :
    ∃ f : β → Gamma, G.IsFlow O f ∧ G.IsNowhereZero f := by
  classical
  have hTsub : (V(G) \ S) ⊆ V(G) := Set.diff_subset
  have hleS : G.induce S ≤ G := Graph.induce_le hS
  have hleT : G.induce (V(G) \ S) ≤ G := Graph.induce_le hTsub
  have hEGS : E(G.induce S).Finite := hE.subset (Graph.IsSubgraph.edgeSet_mono hleS)
  have hEGT : E(G.induce (V(G) \ S)).Finite := hE.subset (Graph.IsSubgraph.edgeSet_mono hleT)
  obtain ⟨fA, hfA_flow, hfA_nz⟩ := hA (O.restrict hleS)
  obtain ⟨fB, hfB_flow, hfB_nz⟩ := hB (O.restrict hleT)
  -- the closedness of the complement `V(G) \ S`
  have hclosedT : ∀ e a b, G.IsLink e a b → (a ∈ V(G) \ S ↔ b ∈ V(G) \ S) := by
    intro e a b hlink
    have ha : a ∈ V(G) := hlink.left_mem
    have hb : b ∈ V(G) := hlink.right_mem
    have hiff := hclosed e a b hlink
    simp only [Set.mem_diff]
    constructor
    · rintro ⟨_, haS⟩; exact ⟨hb, fun hbS => haS (hiff.mpr hbS)⟩
    · rintro ⟨_, hbS⟩; exact ⟨ha, fun haS => hbS (hiff.mp haS)⟩
  refine ⟨fun e => if e ∈ E(G.induce S) then fA e else fB e, ?_, ?_⟩
  · -- FLOW
    rw [charTwo_flow_iff_endSum_zero Gamma.add_self hE O]
    intro v hvV
    by_cases hvS : v ∈ S
    · -- v ∈ S: the endSum reduces to the endSum of `fA` on `G.induce S`, which is 0
      have hvGS : v ∈ V(G.induce S) := by rw [Graph.vertexSet_induce]; exact hvS
      have hagreeS : ∀ e ∈ (G.induce S).incidenceSet v,
          (fun e => if e ∈ E(G.induce S) then fA e else fB e) e = fA e := by
        intro e he
        have heE : e ∈ E(G.induce S) := ((Graph.mem_incidenceSet v e).mp he).edge_mem
        exact if_pos heE
      rw [endSum_restrict hclosed hvS
            (fun e => if e ∈ E(G.induce S) then fA e else fB e) fA hagreeS]
      exact (charTwo_flow_iff_endSum_zero Gamma.add_self hEGS (O.restrict hleS) fA).mp
              hfA_flow v hvGS
    · -- v ∉ S: v ∈ V(G) \ S; the endSum reduces to the endSum of `fB`
      have hvT : v ∈ V(G) \ S := ⟨hvV, hvS⟩
      have hvGT : v ∈ V(G.induce (V(G) \ S)) := by rw [Graph.vertexSet_induce]; exact hvT
      have hagreeT : ∀ e ∈ (G.induce (V(G) \ S)).incidenceSet v,
          (fun e => if e ∈ E(G.induce S) then fA e else fB e) e = fB e := by
        intro e he
        obtain ⟨w, hlinkT⟩ := (Graph.mem_incidenceSet v e).mp he
        rw [Graph.induce_isLink] at hlinkT
        have hlinkG : G.IsLink e v w := hlinkT.1
        have heNGS : e ∉ E(G.induce S) := by
          intro hcon
          exact hvS (end_mem_of_edge_induce hcon hlinkG)
        exact if_neg heNGS
      rw [endSum_restrict hclosedT hvT
            (fun e => if e ∈ E(G.induce S) then fA e else fB e) fB hagreeT]
      exact (charTwo_flow_iff_endSum_zero Gamma.add_self hEGT (O.restrict hleT) fB).mp
              hfB_flow v hvGT
  · -- NOWHERE-ZERO
    intro e he hcontra
    obtain ⟨a, b, hlink⟩ := Graph.exists_isLink_of_mem_edgeSet he
    have ha : a ∈ V(G) := hlink.left_mem
    have hb : b ∈ V(G) := hlink.right_mem
    have hiff := hclosed e a b hlink
    by_cases haS : a ∈ S
    · have hbS : b ∈ S := hiff.mp haS
      have heGS : e ∈ E(G.induce S) := by
        rw [Graph.edgeSet_induce, Set.mem_setOf_eq]; exact ⟨a, b, hlink, haS, hbS⟩
      have hcontra' : (if e ∈ E(G.induce S) then fA e else fB e) = 0 := hcontra
      rw [if_pos heGS] at hcontra'
      exact hfA_nz e heGS hcontra'
    · have hbS : b ∉ S := fun h => haS (hiff.mpr h)
      have heGT : e ∈ E(G.induce (V(G) \ S)) := by
        rw [Graph.edgeSet_induce, Set.mem_setOf_eq]
        exact ⟨a, b, hlink, ⟨ha, haS⟩, ⟨hb, hbS⟩⟩
      have heNGS : e ∉ E(G.induce S) := fun hcon => haS (end_mem_of_edge_induce hcon hlink)
      have hcontra' : (if e ∈ E(G.induce S) then fA e else fB e) = 0 := hcontra
      rw [if_neg heNGS] at hcontra'
      exact hfB_nz e heGT hcontra'

end Workspace.PriorWorkProofs.EightFlow

/-!
# The reduction bridgeless ⟶ 3-edge-connected, and the 8-flow theorem (§3.7)

Proves `bridgeless_gamma_flow`: every finite bridgeless multigraph `G` has a nowhere-zero `Γ`-flow
(`Γ = 𝔽₂³`), by well-founded strong induction on `2 · |E(G)| + |V(G)|`. The cases are: `|V| ≤ 1`
(constant nonzero map, `gamma_flow_of_vertex_le_one`); disconnected (split at a `0`-edge-cut,
`gamma_flow_of_closed_split`); `3`-edge-connected (`gamma_flow_of_isEdgeConnected3`); and connected
but not `3`-edge-connected (contract an edge of a `2`-edge-cut and lift the recursive flow via
`flow_update_iff` and `flow_two_cut`).
-/

open Set
open scoped Graph
open Workspace.Types.Gamma
open Workspace.Types.Orientation
open Workspace.PriorWorkProofs.Tutte

namespace Workspace.PriorWorkProofs.EightFlow

variable {α β : Type*}

/-! ## A fixed nonzero element of `Γ = 𝔽₂³` -/

/-- A concrete nonzero element of `Γ = Fin 3 → F2`. -/
noncomputable def gammaOne : Gamma := fun i => if i = 0 then (1 : F2) else 0

lemma gammaOne_ne_zero : gammaOne ≠ 0 := by
  intro h
  have h0 := congrFun h 0
  simp [gammaOne] at h0

/-! ## The 3-edge-connected case (assembled from the Nash–Williams route) -/

/-- **Proposition 5, flow form.** Every `3`-edge-connected finite multigraph has a nowhere-zero
`Γ`-flow. Assembled from `doubling_covering` (three spanning trees covering `E` outside), the
spanning-tree even cover `spanning_tree_even_cover`, and the payoff
`three_even_subgraphs_cover_gamma_flow`. -/
theorem gamma_flow_of_isEdgeConnected3 (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (hconn : IsEdgeConnected G 3) (O : Orientation G) :
    ∃ f : β → Gamma, G.IsFlow O f ∧ G.IsNowhereZero f := by
  have hGc : G.Connected := connected_of_isEdgeConnected3 hconn
  obtain ⟨T₁, T₂, T₃, hT₁, hT₂, hT₃, hcov⟩ := doubling_covering G hV hE hconn
  obtain ⟨H₁, hH₁, hsub₁⟩ := spanning_tree_even_cover G hV hE hGc T₁ hT₁
  obtain ⟨H₂, hH₂, hsub₂⟩ := spanning_tree_even_cover G hV hE hGc T₂ hT₂
  obtain ⟨H₃, hH₃, hsub₃⟩ := spanning_tree_even_cover G hV hE hGc T₃ hT₃
  refine three_even_subgraphs_cover_gamma_flow hE O hH₁ hH₂ hH₃ ?_
  intro e he
  simp only [Set.mem_union]
  rcases hcov e he with h | h | h
  · exact Or.inl (Or.inl (hsub₁ ⟨he, h⟩))
  · exact Or.inl (Or.inr (hsub₂ ⟨he, h⟩))
  · exact Or.inr (hsub₃ ⟨he, h⟩)

/-! ## The degenerate case `|V(G)| ≤ 1` -/

/-- **Base case.** A finite bridgeless multigraph with at most one vertex has a nowhere-zero
`Γ`-flow: every edge is a loop (both ends are the unique vertex), so the constant map `γ₀ ≠ 0`
satisfies the characteristic-two flow criterion (a loop contributes `2 • γ₀ = 0`). -/
theorem gamma_flow_of_vertex_le_one (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (hcard : V(G).ncard ≤ 1) (O : Orientation G) :
    ∃ f : β → Gamma, G.IsFlow O f ∧ G.IsNowhereZero f := by
  classical
  have hsub : V(G).Subsingleton := by
    rw [Set.ncard_le_one_iff_eq hV] at hcard
    rcases hcard with h | ⟨a, h⟩
    · rw [h]; exact Set.subsingleton_empty
    · rw [h]; exact Set.subsingleton_singleton
  refine ⟨fun _ => gammaOne, ?_, ?_⟩
  · rw [charTwo_flow_iff_endSum_zero Gamma.add_self hE O]
    intro v hv
    have hzero : ∀ e ∈ G.incidenceSet v, (if G.IsLoopAt e v then (2 : ℕ) else 1) • gammaOne = 0 := by
      intro e he
      rw [Graph.mem_incidenceSet] at he
      obtain ⟨w, hw⟩ := he
      have hvw : v = w := hsub hv hw.right_mem
      have hloop : G.IsLoopAt e v := by rw [Graph.IsLoopAt]; rw [hvw] at hw ⊢; exact hw
      rw [if_pos hloop, two_nsmul, Gamma.add_self]
    calc (∑ᶠ e ∈ G.incidenceSet v, (if G.IsLoopAt e v then (2 : ℕ) else 1) • gammaOne)
        = ∑ᶠ e ∈ G.incidenceSet v, (0 : Gamma) := finsum_mem_congr rfl hzero
      _ = 0 := by simp
  · intro e _
    exact gammaOne_ne_zero

/-! ## The main reduction -/

/-- **The 8-flow theorem (Route B).** Every finite bridgeless multigraph has a nowhere-zero
`Γ`-flow, `Γ = 𝔽₂³`. Proved by strong induction on `2 · |E(G)| + |V(G)|`; the only admission on
the whole path is the Nash–Williams–Tutte axiom. This is exactly the shape of
`Workspace.PriorWork.kilpatrick_jaeger_nowhere_zero_gamma_flow`. -/
theorem bridgeless_gamma_flow (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (hG : G.Bridgeless) (O : Orientation G) :
    ∃ f : β → Gamma, G.IsFlow O f ∧ G.IsNowhereZero f := by
  classical
  rcases Nat.lt_or_ge (V(G).ncard) 2 with hlt2 | hge2
  · -- |V(G)| ≤ 1
    exact gamma_flow_of_vertex_le_one G hV hE (by omega) O
  · -- |V(G)| ≥ 2
    by_cases hconn : G.Connected
    · by_cases h3 : IsEdgeConnected G 3
      · exact gamma_flow_of_isEdgeConnected3 G hV hE h3 O
      · -- 2-edge-cut: contract e₁, recurse, lift
        obtain ⟨S, e₁, e₂, x, y, hSne, hSsub, hScompl, hne12, hcut, hxy, hxS, hyS, hxney, he₂⟩ :=
          exists_two_edge_cut hE hG hconn h3 hge2
        have he₁G : e₁ ∈ E(G) := hxy.edge_mem
        -- contract facts
        have hbrc : (contract G e₁ x y).Bridgeless := contract_bridgeless hG hxy
        have hVc : V(contract G e₁ x y).Finite := by
          rw [vertexSet_contract]; exact hV.image _
        have hEc : E(contract G e₁ x y).Finite := by
          rw [edgeSet_contract]; exact hE.diff
        -- measure facts for termination
        have hEclt : (E(G) \ {e₁}).ncard < E(G).ncard := by
          have h := edgeSet_contract_ncard_lt (G := G) (e₁ := e₁) (x := x) (y := y) hE he₁G
          rwa [edgeSet_contract] at h
        have hVcle : (mergeMap x y '' V(G)).ncard ≤ V(G).ncard := Set.ncard_image_le hV
        -- recurse on the contraction
        obtain ⟨g, hg_flow, hg_nz⟩ :=
          bridgeless_gamma_flow (contract G e₁ x y) hVc hEc hbrc (contractOrientation O e₁ x y)
        -- normalize g to vanish at e₁ (which is outside E(contract))
        have he₁notin : e₁ ∉ E(contract G e₁ x y) := by
          rw [edgeSet_contract]; simp
        set gc := Function.update g e₁ (0 : Gamma) with hgc
        have hgce : gc e₁ = 0 := by rw [hgc, Function.update_self]
        have hgc_flow : (contract G e₁ x y).IsFlow (contractOrientation O e₁ x y) gc := by
          rw [Graph.isFlow_iff_finset_sum hEc] at hg_flow ⊢
          intro v hv
          have hmem : e₁ ∉ hEc.toFinset := by rw [Set.Finite.mem_toFinset]; exact he₁notin
          have hagree : ∀ e ∈ hEc.toFinset, gc e = g e := by
            intro e he
            rw [hgc, Function.update_of_ne]
            rintro rfl; exact hmem he
          have hL : (∑ e ∈ hEc.toFinset with (contractOrientation O e₁ x y).tail e = v, gc e)
              = ∑ e ∈ hEc.toFinset with (contractOrientation O e₁ x y).tail e = v, g e :=
            Finset.sum_congr rfl (fun e he => hagree e (Finset.mem_of_mem_filter e he))
          have hR : (∑ e ∈ hEc.toFinset with (contractOrientation O e₁ x y).head e = v, gc e)
              = ∑ e ∈ hEc.toFinset with (contractOrientation O e₁ x y).head e = v, g e :=
            Finset.sum_congr rfl (fun e he => hagree e (Finset.mem_of_mem_filter e he))
          rw [hL, hR]; exact hg_flow v hv
        have hgc_nz : ∀ e ∈ E(contract G e₁ x y), gc e ≠ 0 := by
          intro e he
          have hne : e ≠ e₁ := by rintro rfl; exact he₁notin he
          rw [hgc, Function.update_of_ne hne]; exact hg_nz e he
        -- the lift: f is a flow on G
        set f := Function.update gc e₁ (rval O hE e₁ x gc) with hf
        have hf_flow : G.IsFlow O f :=
          (flow_update_iff hE e₁ x y hxy hxney hgce).mp hgc_flow
        -- nowhere-zero
        refine ⟨f, hf_flow, ?_⟩
        intro e he
        by_cases hee : e = e₁
        · rw [hee]
          -- f e₁ = f e₂ via the char-2 cut identity, and f e₂ = gc e₂ = g e₂ ≠ 0
          have h2 : f e₁ + f e₂ = 0 :=
            flow_two_cut Gamma.add_self hV hE O hf_flow hSsub hne12 hcut
          have he₂c : e₂ ∈ E(contract G e₁ x y) := by
            rw [edgeSet_contract, Set.mem_diff, Set.mem_singleton_iff]; exact ⟨he₂, hne12.symm⟩
          have hfe2 : f e₂ = gc e₂ := by
            rw [hf, Function.update_of_ne (Ne.symm hne12)]
          have hge2 : gc e₂ ≠ 0 := hgc_nz e₂ he₂c
          have heq : f e₁ = f e₂ := by
            rw [← add_zero (f e₁), ← Gamma.add_self (f e₂), ← add_assoc, h2, zero_add]
          rw [heq, hfe2]; exact hge2
        · -- e ≠ e₁, e ∈ E(G): f e = gc e = g e ≠ 0
          have hfe : f e = gc e := by rw [hf, Function.update_of_ne hee]
          have hec : e ∈ E(contract G e₁ x y) := by
            rw [edgeSet_contract]; exact ⟨he, hee⟩
          rw [hfe]; exact hgc_nz e hec
    · -- disconnected: 0-edge-cut split
      have hVne : V(G).Nonempty := by
        rw [← Set.ncard_pos hV]; omega
      have hnot : ¬ ∀ (T : Set α), T.Nonempty → T ⊆ V(G) → (V(G) \ T).Nonempty →
          (cutEdges G T).Nonempty := by
        intro hall; exact hconn (connected_of_cutEdges_pos hVne hall)
      push_neg at hnot
      obtain ⟨S, hSne, hSsub, hScompl, hcutne⟩ := hnot
      -- closedness of S under adjacency
      have hclosed : ∀ e a b, G.IsLink e a b → (a ∈ S ↔ b ∈ S) := by
        intro e a b hlink
        constructor
        · intro ha; by_contra hb
          have : e ∈ cutEdges G S := ⟨hlink.edge_mem, a, b, hlink, ha, hb⟩
          rw [hcutne] at this; exact this
        · intro hb; by_contra ha
          have : e ∈ cutEdges G S := ⟨hlink.edge_mem, b, a, hlink.symm, hb, ha⟩
          rw [hcutne] at this; exact this
      have hclosed' : ∀ e a b, G.IsLink e a b → (a ∈ V(G) \ S ↔ b ∈ V(G) \ S) := by
        intro e a b hlink
        have ha : a ∈ V(G) := hlink.left_mem
        have hb : b ∈ V(G) := hlink.right_mem
        have := hclosed e a b hlink
        simp only [Set.mem_diff, ha, hb, true_and]
        tauto
      -- V-decrease facts (both sides strictly fewer vertices, |E| non-increasing)
      have hVS : V(G.induce S) = S := rfl
      have hVSc : V(G.induce (V(G) \ S)) = V(G) \ S := rfl
      have hSlt : S.ncard < V(G).ncard := by
        apply Set.ncard_lt_ncard _ hV
        obtain ⟨z, hz⟩ := hScompl
        exact ⟨hSsub, fun h => hz.2 (h hz.1)⟩
      have hSclt : (V(G) \ S).ncard < V(G).ncard := by
        apply Set.ncard_lt_ncard _ hV
        obtain ⟨w, hw⟩ := hSne
        refine ⟨Set.diff_subset, fun h => ?_⟩
        exact (h (hSsub hw)).2 hw
      have hES : (E(G.induce S)).ncard ≤ E(G).ncard :=
        Set.ncard_le_ncard ((Graph.induce_le hSsub).edgeSet_mono) hE
      have hESc : (E(G.induce (V(G) \ S))).ncard ≤ E(G).ncard :=
        Set.ncard_le_ncard ((Graph.induce_le Set.diff_subset).edgeSet_mono) hE
      have hVSn : (V(G.induce S)).ncard < V(G).ncard := by rw [hVS]; exact hSlt
      have hVScn : (V(G.induce (V(G) \ S))).ncard < V(G).ncard := by rw [hVSc]; exact hSclt
      -- solve each induced subgraph by the IH
      refine gamma_flow_of_closed_split hV hE hSsub hclosed ?hA ?hB O
      · intro O'
        exact bridgeless_gamma_flow (G.induce S)
          (by rw [hVS]; exact hV.subset hSsub)
          (hE.subset ((Graph.induce_le hSsub).edgeSet_mono))
          (induce_bridgeless hG hclosed) O'
      · intro O'
        exact bridgeless_gamma_flow (G.induce (V(G) \ S))
          (by rw [hVSc]; exact hV.diff)
          (hE.subset ((Graph.induce_le Set.diff_subset).edgeSet_mono))
          (induce_bridgeless hG hclosed') O'
termination_by 2 * E(G).ncard + V(G).ncard
decreasing_by
  all_goals simp_wf
  all_goals omega

end Workspace.PriorWorkProofs.EightFlow

/-!
# Jaeger's reduction — the elementary graph moves and their CDC-lifts

The elementary (Fleischner-free) moves of Jaeger's reduction of the Cycle Double Cover
conjecture to the loopless cubic bridgeless case, with the lemmas that lift a cycle double
cover (CDC) back along each move. Every move is edge-reduced: it reuses existing edge labels
and keeps every vertex, so it stays on the same vertex/edge types `α`, `β`.
-/

open Set
open scoped Graph
open scoped Classical

namespace Graph

variable {α β : Type*} {G : Graph α β} {v : α} {ℓ : β}

/-- The single-loop graph `bouquet v {ℓ}` is a subgraph of any graph in which `ℓ` is a
loop at `v`. -/
theorem IsLoopAt.bouquet_le (h : G.IsLoopAt ℓ v) :
    Graph.bouquet v ({ℓ} : Set β) ≤ G := by
  refine ⟨?_, ?_⟩
  · rw [Graph.vertexSet_bouquet]
    intro x hx
    simp only [Set.mem_singleton_iff] at hx
    subst hx
    exact h.left_mem
  · intro f x y hf
    rw [Graph.bouquet_isLink] at hf
    obtain ⟨hfe, rfl, rfl⟩ := hf
    simp only [Set.mem_singleton_iff] at hfe
    subst hfe
    exact h

end Graph

namespace Workspace.PriorWorkProofs.Jaeger

open Workspace.Types.Cycle Workspace.Types.CycleDoubleCover

variable {α β : Type*} {G : Graph α β} {u v w : α} {e ℓ : β}

/-! ## Move L — loop removal -/

/-- The **loop-cycle** at `v`: the cycle consisting of the single loop `ℓ`. -/
def loopCycle (v : α) (ℓ : β) : Graph α β := Graph.bouquet v ({ℓ} : Set β)

@[simp] theorem edgeSet_loopCycle (v : α) (ℓ : β) : E(loopCycle v ℓ) = {ℓ} := by
  ext e
  rw [Graph.edge_mem_iff_exists_isLink]
  simp only [loopCycle, Graph.bouquet_isLink, Set.mem_singleton_iff]
  constructor
  · rintro ⟨x, y, he, -, -⟩; exact he
  · rintro rfl; exact ⟨v, v, rfl, rfl, rfl⟩

theorem mem_edgeSet_loopCycle (v : α) (ℓ : β) : ℓ ∈ E(loopCycle v ℓ) := by
  rw [edgeSet_loopCycle]; exact Set.mem_singleton ℓ

/-- The loop-cycle is a cycle of `G` when `ℓ` really is a loop at `v` in `G`. -/
theorem isCycle_loopCycle (h : G.IsLoopAt ℓ v) : G.IsCycle (loopCycle v ℓ) :=
  (Workspace.Types.Cycle.isCycle_bouquet_singleton v ℓ).of_self h.bouquet_le

/-- **Move L, the CDC lift.** If `ℓ` is a loop of `G` at `v` and `D` is a cycle double cover
of `G − ℓ`, then adjoining the loop-cycle **twice** to `D` yields a cycle double cover of `G`.
Every edge `≠ ℓ` keeps multiplicity `2`; `ℓ`, absent from `G − ℓ`, is covered exactly twice by
the two adjoined copies. -/
theorem cdc_lift_loop (h : G.IsLoopAt ℓ v) {D : Multiset (Graph α β)}
    (hD : (G.deleteEdges {ℓ}).IsCycleDoubleCover D) :
    G.IsCycleDoubleCover (loopCycle v ℓ ::ₘ loopCycle v ℓ ::ₘ D) := by
  have hℓE : ℓ ∈ E(loopCycle v ℓ) := mem_edgeSet_loopCycle v ℓ
  refine ⟨?_, ?_⟩
  · -- every member is a cycle of `G`
    intro C hC
    rw [Multiset.mem_cons, Multiset.mem_cons] at hC
    rcases hC with rfl | rfl | hC
    · exact isCycle_loopCycle h
    · exact isCycle_loopCycle h
    · exact (hD.isCycle_of_mem hC).mono Graph.deleteEdges_le
  · -- every edge of `G` has multiplicity 2
    intro e he
    by_cases he0 : e = ℓ
    · subst e
      -- ℓ is covered exactly by the two adjoined loop-cycles
      have hDℓ : D.edgeMultiplicity ℓ = 0 := by
        rw [Multiset.edgeMultiplicity_eq_zero_iff]
        intro C hCD hℓC
        -- members of D are subgraphs of `G − ℓ`, whose edge set excludes ℓ
        have hsub : E(C) ⊆ E(G.deleteEdges {ℓ}) :=
          Graph.IsSubgraph.edgeSet_mono (hD.le_of_mem hCD)
        have : ℓ ∈ E(G.deleteEdges {ℓ}) := hsub hℓC
        rw [Graph.edgeSet_deleteEdges] at this
        exact this.2 (Set.mem_singleton ℓ)
      rw [Multiset.edgeMultiplicity_cons_of_mem _ hℓE,
        Multiset.edgeMultiplicity_cons_of_mem _ hℓE, hDℓ]
    · -- e ≠ ℓ : the two loop-cycles miss it; it is covered twice inside `G − ℓ`
      have heNotLoop : e ∉ E(loopCycle v ℓ) := by
        rw [edgeSet_loopCycle]; simpa using he0
      have heG' : e ∈ E(G.deleteEdges {ℓ}) := by
        rw [Graph.edgeSet_deleteEdges]
        exact ⟨he, by simpa using he0⟩
      rw [Multiset.edgeMultiplicity_cons_of_notMem _ heNotLoop,
        Multiset.edgeMultiplicity_cons_of_notMem _ heNotLoop, hD.edgeMultiplicity_eq heG']

/-! ### Move L — bridgelessness is preserved

Deleting a loop cannot change reachability (a loop is an adjacency `v`–`v`, useless for
connecting distinct vertices), hence cannot create a bridge. -/

/-- Deleting a loop `ℓ` from `G` does not change reachability. -/
theorem reachable_deleteEdge_loop (h : G.IsLoopAt ℓ v) {x y : α} :
    (G.deleteEdges {ℓ}).Reachable x y ↔ G.Reachable x y := by
  constructor
  · exact fun hr => hr.mono Graph.deleteEdges_le
  · intro hr
    -- walk in G; every adjacency uses some edge; if that edge is ℓ the step is v–v, i.e.
    -- endpoints equal, so it can be dropped.
    induction hr with
    | refl => exact Graph.Reachable.refl _ _
    | @tail b c hab hbc ih =>
      obtain ⟨f, hf⟩ := hbc
      by_cases hfℓ : f = ℓ
      · -- the step b–c uses the loop ℓ; then b = c, so no progress is made
        have hf' : G.IsLink ℓ b c := hfℓ ▸ hf
        have hbc' : b = c := by
          rcases hf'.eq_and_eq_or_eq_and_eq h with ⟨hb, hc⟩ | ⟨hb, hc⟩ <;> rw [hb, hc]
        exact hbc' ▸ ih
      · exact ih.tail ⟨f, by rw [Graph.deleteEdges_isLink]; exact ⟨hf, by simpa using hfℓ⟩⟩

/-- **Move L preserves bridgelessness.** Deleting a loop from a bridgeless graph yields a
bridgeless graph. -/
theorem bridgeless_deleteEdge_loop (hbr : G.Bridgeless) (h : G.IsLoopAt ℓ v) :
    (G.deleteEdges {ℓ}).Bridgeless := by
  intro e he hb
  -- `e ≠ ℓ` since ℓ was deleted
  rw [Graph.edgeSet_deleteEdges] at he
  have heℓ : e ≠ ℓ := by simpa using he.2
  obtain ⟨x, y, hxy, hnr⟩ := hb
  -- e is an edge of G with the same ends
  have hxyG : G.IsLink e x y := Graph.deleteEdges_le.isLink_mono hxy
  refine hbr e he.1 ⟨x, y, hxyG, fun hrG => hnr ?_⟩
  -- reconnect x,y in (G-ℓ)-e using: reachability in G-e equals reachability in (G-e)-ℓ,
  -- because ℓ is still a loop in G-e (e ≠ ℓ).
  have hℓ' : (G.deleteEdges {e}).IsLoopAt ℓ v := by
    rw [Graph.deleteEdges_isLoopAt]
    exact ⟨h, by simpa using heℓ.symm⟩
  -- delete both edges; the two single-deletions commute up to the loop-reachability lemma
  have hcomm : (G.deleteEdges {ℓ}).deleteEdges {e} = (G.deleteEdges {e}).deleteEdges {ℓ} := by
    rw [Graph.deleteEdges_deleteEdges, Graph.deleteEdges_deleteEdges, Set.union_comm]
  rw [hcomm, reachable_deleteEdge_loop hℓ']
  exact hrG

/-! ## Moves D2 and SP — the edge-reduced reroute operation

The degree-2 suppression and the degree-≥4 Fleischner split share one edge-reduced graph
operation on the same types: pick two distinct edges `e₁ = v v₁`, `e₂ = v v₂` at the working
vertex `v`, **delete `e₂` and relabel `e₁` so that it now joins `v₁`–`v₂`** (a loop at `v₁`
when `v₁ = v₂`). Every vertex is kept and exactly one edge is removed. -/

/-- The edge-reduced **reroute** of `G` at `v₁, v₂` along `e₁, e₂`: delete `e₂` and make `e₁`
join `v₁`–`v₂`; all other edges and all vertices are unchanged. `IsLink` is given directly (no
`DecidableEq β` needed): `e₁` now links `{v₁, v₂}` when both lie in `V(G)`, `e₂` is gone, and
every other edge keeps its `G`-incidences. -/
def reroute (G : Graph α β) (v1 v2 : α) (e1 e2 : β) : Graph α β where
  vertexSet := V(G)
  IsLink f x y :=
    (f = e1 ∧ (v1 ∈ V(G) ∧ v2 ∈ V(G)) ∧ ((x = v1 ∧ y = v2) ∨ (x = v2 ∧ y = v1))) ∨
      (f ≠ e1 ∧ f ≠ e2 ∧ G.IsLink f x y)
  isLink_symm := by
    rintro f hf x y (⟨rfl, hm, hd⟩ | ⟨h1, h2, hxy⟩)
    · exact Or.inl ⟨rfl, hm, by tauto⟩
    · exact Or.inr ⟨h1, h2, hxy.symm⟩
  eq_or_eq_of_isLink_of_isLink := by
    rintro f x y a b (⟨hf1, hm, hd⟩ | ⟨h1, h2, hxy⟩) (⟨hf1', hm', hd'⟩ | ⟨h1', h2', hab⟩)
    · rcases hd with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ <;> rcases hd' with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ <;> tauto
    · exact absurd hf1 h1'
    · exact absurd hf1' h1
    · exact G.eq_or_eq_of_isLink_of_isLink hxy hab
  left_mem_of_isLink := by
    rintro f x y (⟨rfl, hm, hd⟩ | ⟨-, -, hxy⟩)
    · rcases hd with ⟨rfl, -⟩ | ⟨rfl, -⟩
      · exact hm.1
      · exact hm.2
    · exact hxy.left_mem

@[simp] theorem vertexSet_reroute (G : Graph α β) (v1 v2 : α) (e1 e2 : β) :
    V(reroute G v1 v2 e1 e2) = V(G) := rfl

theorem reroute_isLink (G : Graph α β) (v1 v2 : α) (e1 e2 : β) (f : β) (x y : α) :
    (reroute G v1 v2 e1 e2).IsLink f x y ↔
      (f = e1 ∧ (v1 ∈ V(G) ∧ v2 ∈ V(G)) ∧ ((x = v1 ∧ y = v2) ∨ (x = v2 ∧ y = v1))) ∨
        (f ≠ e1 ∧ f ≠ e2 ∧ G.IsLink f x y) := Iff.rfl

/-- The reroute removes exactly the edge `e₂`; every other edge of `G` survives (with `e₁`
possibly relabelled). Hence the edge count drops by one. -/
theorem edgeSet_reroute {v1 v2 : α} {e1 e2 : β} (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2)
    (hne : e1 ≠ e2) :
    E(reroute G v1 v2 e1 e2) = E(G) \ {e2} := by
  have hv1 : v1 ∈ V(G) := he1.right_mem
  have hv2 : v2 ∈ V(G) := he2.right_mem
  ext f
  rw [Graph.edge_mem_iff_exists_isLink]
  simp only [Set.mem_diff, Set.mem_singleton_iff]
  constructor
  · rintro ⟨x, y, hxy⟩
    rw [reroute_isLink] at hxy
    rcases hxy with ⟨rfl, -, -⟩ | ⟨-, h2, hg⟩
    · exact ⟨he1.edge_mem, hne⟩
    · exact ⟨hg.edge_mem, h2⟩
  · rintro ⟨hfG, hfe2⟩
    by_cases hfe1 : f = e1
    · subst hfe1
      exact ⟨v1, v2, by rw [reroute_isLink]; exact Or.inl ⟨rfl, ⟨hv1, hv2⟩, Or.inl ⟨rfl, rfl⟩⟩⟩
    · obtain ⟨x, y, hxy⟩ := Graph.exists_isLink_of_mem_edgeSet hfG
      exact ⟨x, y, by rw [reroute_isLink]; exact Or.inr ⟨hfe1, hfe2, hxy⟩⟩

/-! ### Reachability transfer for the reroute

`reroute_reachable_map` transports a walk of `K` into `reroute K` by sending the suppressed
vertex `v` to `v1`; `deleteEdges_reachable_pendant` is the analogue for deleting a pendant edge
`e2` at a vertex whose only incident edge is `e2`. -/

/-- Transport a walk of `K` into `reroute K v1 v2 e1 e2`, mapping the suppressed vertex `v`
(whose only incident edges are `e1 = v v1` and `e2 = v v2`) to `v1`. -/
private theorem reroute_reachable_map {α β : Type*} {K : Graph α β} {p v1 v2 : α} {e1 e2 : β}
    (hv1 : p ≠ v1) (hv2 : p ≠ v2) (he1 : K.IsLink e1 p v1) (he2 : K.IsLink e2 p v2)
    (hvonly : ∀ f x, K.IsLink f p x → f = e1 ∨ f = e2)
    {a b : α} (h : K.Reachable a b) :
    (reroute K v1 v2 e1 e2).Reachable (if a = p then v1 else a) (if b = p then v1 else b) := by
  induction h with
  | refl => exact Graph.Reachable.refl _ _
  | @tail c d hac hcd ih =>
    refine ih.trans ?_
    obtain ⟨f, hf⟩ := hcd
    have hv1V : v1 ∈ V(K) := he1.right_mem
    have hv2V : v2 ∈ V(K) := he2.right_mem
    by_cases hfe1 : f = e1
    · subst hfe1
      rcases hf.eq_and_eq_or_eq_and_eq he1 with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
      · rw [if_pos rfl, if_neg (Ne.symm hv1)]
      · rw [if_neg (Ne.symm hv1), if_pos rfl]
    · by_cases hfe2 : f = e2
      · subst hfe2
        rcases hf.eq_and_eq_or_eq_and_eq he2 with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
        · rw [if_pos rfl, if_neg (Ne.symm hv2)]
          exact Graph.IsLink.reachable (e := e1)
            (by rw [reroute_isLink]; exact Or.inl ⟨rfl, ⟨hv1V, hv2V⟩, Or.inl ⟨rfl, rfl⟩⟩)
        · rw [if_neg (Ne.symm hv2), if_pos rfl]
          exact Graph.IsLink.reachable (e := e1)
            (by rw [reroute_isLink]; exact Or.inl ⟨rfl, ⟨hv1V, hv2V⟩, Or.inr ⟨rfl, rfl⟩⟩)
      · have hcp : c ≠ p := fun h => (hvonly f d (h ▸ hf)).elim hfe1 hfe2
        have hdp : d ≠ p := fun h => (hvonly f c (h ▸ hf.symm)).elim hfe1 hfe2
        rw [if_neg hcp, if_neg hdp]
        exact Graph.IsLink.reachable (e := f)
          (by rw [reroute_isLink]; exact Or.inr ⟨hfe1, hfe2, hf⟩)

/-- Transport a walk of `K` into `K - e2`, where `v` is a vertex whose only incident edge is the
pendant `e2 = v v2`; the suppressed vertex `v` is sent to `v2`. -/
private theorem deleteEdges_reachable_pendant {α β : Type*} {K : Graph α β} {p v2 : α} {e2 : β}
    (hv2 : p ≠ v2) (he2 : K.IsLink e2 p v2)
    (hvonly : ∀ f x, K.IsLink f p x → f = e2)
    {a b : α} (h : K.Reachable a b) :
    (K.deleteEdges {e2}).Reachable (if a = p then v2 else a) (if b = p then v2 else b) := by
  induction h with
  | refl => exact Graph.Reachable.refl _ _
  | @tail c d hac hcd ih =>
    refine ih.trans ?_
    obtain ⟨f, hf⟩ := hcd
    by_cases hfe2 : f = e2
    · subst hfe2
      rcases hf.eq_and_eq_or_eq_and_eq he2 with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
      · rw [if_pos rfl, if_neg (Ne.symm hv2)]
      · rw [if_neg (Ne.symm hv2), if_pos rfl]
    · have hcp : c ≠ p := fun h => hfe2 (hvonly f d (h ▸ hf))
      have hdp : d ≠ p := fun h => hfe2 (hvonly f c (h ▸ hf.symm))
      rw [if_neg hcp, if_neg hdp]
      exact Graph.IsLink.reachable (e := f)
        (by rw [Graph.deleteEdges_isLink]; exact ⟨hf, by simpa using hfe2⟩)

/-- **Move D2 / SP preserve bridgelessness (degree-2 form).** Suppressing a degree-2 vertex
by rerouting preserves bridgelessness. -/
theorem bridgeless_reroute_of_degree_two {v1 v2 : α} {e1 e2 : β}
    (hbr : G.Bridgeless) (hll : G.IsLoopless) (hdeg : G.degree v = 2)
    (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2) (hne : e1 ≠ e2) :
    (reroute G v1 v2 e1 e2).Bridgeless := by
  have hv1 : v ≠ v1 := fun h => hll e1 v (h ▸ he1)
  have hv2 : v ≠ v2 := fun h => hll e2 v (h ▸ he2)
  -- `v`'s only incident edges are `e1` and `e2`
  have hvonly : ∀ f x, G.IsLink f v x → f = e1 ∨ f = e2 := by
    intro f x hf
    have hcard2 : (G.incidenceSet v).ncard = 2 := by
      rw [← hll.degree_eq_ncard_incidenceSet]; exact hdeg
    have hfin : (G.incidenceSet v).Finite := Set.finite_of_ncard_ne_zero (by rw [hcard2]; norm_num)
    have hsub : ({e1, e2} : Set β) ⊆ G.incidenceSet v := by
      rw [Set.insert_subset_iff, Set.singleton_subset_iff]
      exact ⟨(G.mem_incidenceSet v e1).2 he1.inc_left, (G.mem_incidenceSet v e2).2 he2.inc_left⟩
    have heq : G.incidenceSet v = ({e1, e2} : Set β) :=
      (Set.eq_of_subset_of_ncard_le hsub (by rw [hcard2, Set.ncard_pair hne]) hfin).symm
    have hfinc : f ∈ G.incidenceSet v := (G.mem_incidenceSet v f).2 hf.inc_left
    rw [heq] at hfinc
    simpa using hfinc
  -- for the reroute, deleting an edge `≠ e1, e2` commutes with the reroute up to `≤`
  have hle_gen : ∀ f, f ≠ e1 → f ≠ e2 →
      reroute (G.deleteEdges {f}) v1 v2 e1 e2 ≤ (reroute G v1 v2 e1 e2).deleteEdges {f} := by
    intro f hfe1 hfe2
    refine ⟨fun x hx => hx, ?_⟩
    intro g x y hg
    rw [reroute_isLink] at hg
    rw [Graph.deleteEdges_isLink, reroute_isLink]
    rcases hg with ⟨rfl, hmem, hxy⟩ | ⟨hge1, hge2, hglink⟩
    · rw [Graph.vertexSet_deleteEdges] at hmem
      exact ⟨Or.inl ⟨rfl, hmem, hxy⟩, by simpa using hfe1.symm⟩
    · rw [Graph.deleteEdges_isLink] at hglink
      exact ⟨Or.inr ⟨hge1, hge2, hglink.1⟩, by simpa using hglink.2⟩
  -- deleting `e1` from the reroute agrees with deleting `{e1, e2}` from `G` up to `≤`
  have hle_e1 : G.deleteEdges ({e1} ∪ {e2}) ≤ (reroute G v1 v2 e1 e2).deleteEdges {e1} := by
    refine ⟨fun x hx => hx, ?_⟩
    intro g x y hg
    rw [Graph.deleteEdges_isLink] at hg
    obtain ⟨hglink, hgmem⟩ := hg
    simp only [Set.mem_union, Set.mem_singleton_iff, not_or] at hgmem
    rw [Graph.deleteEdges_isLink, reroute_isLink]
    exact ⟨Or.inr ⟨hgmem.1, hgmem.2, hglink⟩, by simpa using hgmem.1⟩
  apply Graph.bridgeless_of_forall_reachable
  intro f hf x y hlink
  rw [reroute_isLink] at hlink
  rcases hlink with ⟨hfeq, hmem, hxy⟩ | ⟨hfe1, hfe2, hglink⟩
  · -- `f = e1`, relabelled to join `v1`–`v2`
    rw [hfeq]
    have hnb : ¬ G.IsBridge e1 := hbr.not_isBridge e1
    have hr : (G.deleteEdges {e1}).Reachable v v1 := by
      by_contra hc; exact hnb ⟨v, v1, he1, hc⟩
    -- in `G - e1`, `v`'s only edge is the pendant `e2`
    have he2' : (G.deleteEdges {e1}).IsLink e2 v v2 := by
      rw [Graph.deleteEdges_isLink]; exact ⟨he2, by simpa using hne.symm⟩
    have hvonly' : ∀ g x, (G.deleteEdges {e1}).IsLink g v x → g = e2 := by
      intro g x hg
      rw [Graph.deleteEdges_isLink] at hg
      exact (hvonly g x hg.1).resolve_left (by simpa using hg.2)
    have hpend := deleteEdges_reachable_pendant hv2 he2' hvonly' hr.symm
    rw [if_neg hv1.symm, if_pos rfl] at hpend
    -- `(G - e1) - e2 = G.deleteEdges ({e1} ∪ {e2})`
    rw [Graph.deleteEdges_deleteEdges] at hpend
    have hbase : ((reroute G v1 v2 e1 e2).deleteEdges {e1}).Reachable v1 v2 := hpend.mono hle_e1
    rcases hxy with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
    · exact hbase
    · exact hbase.symm
  · -- `f ≠ e1, e2`: `f` keeps its `G`-incidences
    have hfG : f ∈ E(G) := hglink.edge_mem
    have hnb : ¬ G.IsBridge f := hbr.not_isBridge f
    have hr : (G.deleteEdges {f}).Reachable x y := by
      by_contra hc; exact hnb ⟨x, y, hglink, hc⟩
    -- `x, y ≠ v` since `f` is not incident to `v`
    have hxv : x ≠ v := fun h => (hvonly f y (h ▸ hglink)).elim hfe1 hfe2
    have hyv : y ≠ v := fun h => (hvonly f x (h ▸ hglink.symm)).elim hfe1 hfe2
    have he1' : (G.deleteEdges {f}).IsLink e1 v v1 := by
      rw [Graph.deleteEdges_isLink]; exact ⟨he1, by simpa using hfe1.symm⟩
    have he2' : (G.deleteEdges {f}).IsLink e2 v v2 := by
      rw [Graph.deleteEdges_isLink]; exact ⟨he2, by simpa using hfe2.symm⟩
    have hvonly' : ∀ g x, (G.deleteEdges {f}).IsLink g v x → g = e1 ∨ g = e2 := by
      intro g x hg
      rw [Graph.deleteEdges_isLink] at hg
      exact hvonly g x hg.1
    have hmap := reroute_reachable_map hv1 hv2 he1' he2' hvonly' hr
    rw [if_neg hxv, if_neg hyv] at hmap
    exact hmap.mono (hle_gen f hfe1 hfe2)

/-! The CDC-lift lemmas for the reroute (`cdc_lift_reroute_degree_two`, `cdc_lift_reroute_split`)
require Veblen's cycle decomposition, so they are proved in `EvenLift.lean`. -/

end Workspace.PriorWorkProofs.Jaeger

/-!
# Prior-work black box: Fleischner's Splitting Lemma (degree ≥ 4)

The admitted prior-work `axiom` for Fleischner's Splitting Lemma, in the edge-reduced form the
Jaeger reduction consumes. The `reroute` move it references is defined in
`Workspace.PriorWorkProofs.Jaeger.Moves`.

> **Lemma 1 (Fleischner).** Let `v` be a vertex of degree at least `4` in a bridgeless graph
> `G`. There exist two edges `e₁, e₂` incident with `v` such that the split `G(v, e₁, e₂)`
> — detach `e₁, e₂` from `v` onto a fresh degree-2 vertex `v*` — is again bridgeless.

H. Fleischner, *Spanning Eulerian subgraphs, the Splitting Lemma, and Petersen's theorem*,
Discrete Math. **101** (1992) 33–37; restated (degree-≥4, unconditional) by Kaiser, Kužel, Li,
Wang, *A note on k-walks in bridgeless graphs*.
-/

open scoped Graph
open Workspace.PriorWorkProofs.Jaeger

namespace Workspace.PriorWork

/-- **E1 — Fleischner's Splitting Lemma (degree ≥ 4), edge-reduced form.**

For a finite bridgeless loopless graph `G` and a vertex `v` of degree at least `4`, there
exist two distinct edges `e₁ = v v₁`, `e₂ = v v₂` incident with `v` such that the
edge-reduced split `reroute G v₁ v₂ e₁ e₂` (delete `e₂`, relabel `e₁` to join `v₁`–`v₂`) is
bridgeless. Its edge count is one less than that of `G` (`edgeSet_reroute`).

Admitted from Fleischner (Discrete Math. 101, 1992); see the module docstring. -/
axiom fleischner_splitting_lemma {α β : Type*} (G : Graph α β) (v : α)
    (hV : V(G).Finite) (hE : E(G).Finite) (hll : G.IsLoopless) (hbr : G.Bridgeless)
    (hdeg : 4 ≤ G.degree v) :
    ∃ (v1 v2 : α) (e1 e2 : β), e1 ≠ e2 ∧ G.IsLink e1 v v1 ∧ G.IsLink e2 v v2 ∧
      (reroute G v1 v2 e1 e2).Bridgeless

end Workspace.PriorWork

/-!
# Prior-work black box: Veblen's cycle decomposition (general even case)

The admitted prior-work `axiom` for Veblen's cycle decomposition, referencing only the
accepted `Types`.

> **(Veblen 1912, folklore).** Every finite graph in which every vertex has even degree is
> an edge-disjoint union of cycles.

The `{0,2}`-degree special case is proved as
`Workspace.Facts.Lemma21.fact_2_1b_decomposition`; the general even case is strictly stronger
and is admitted here.
-/

open scoped Graph

namespace Workspace.PriorWork

/-- **E2 — Veblen's cycle decomposition (general even case).**

A finite graph `K` in which every vertex has even degree decomposes into an edge-disjoint
family of cycles: there is a multiset `D` of cycles of `K` in which every edge of `K` occurs
exactly once. (The `{0,2}`-degree special case is proved as
`Workspace.Facts.Lemma21.fact_2_1b_decomposition`; this is the strictly stronger statement
allowing higher even degrees.)

Admitted from Veblen (1912) / folklore; see the module docstring. -/
axiom veblen_even_decomposition {α β : Type*} (K : Graph α β)
    (hV : V(K).Finite) (hE : E(K).Finite) (hloop : K.IsLoopless)
    (hdeg : ∀ x ∈ V(K), Even (K.degree x)) :
    ∃ D : Multiset (Graph α β), (∀ C ∈ D, K.IsCycle C) ∧
      ∀ e ∈ E(K), D.edgeMultiplicity e = 1

end Workspace.PriorWork

/-!
# Jaeger's reduction — the CDC lift across the reroute

Lifts a cycle double cover of `reroute G v₁ v₂ e₁ e₂` back to `G`, serving both degree-2
suppression and the degree-≥4 Fleischner split with a single lemma `cdc_lift_reroute`.

For a CDC `D` of `G' = reroute G v₁ v₂ e₁ e₂` and each cycle `C ∈ D`, set

  `F C := E(C) ∪ (if e₁ ∈ E(C) then {e₂} else ∅)`,   `L C := G.restrict (F C)`.

The key degree identity

  `(L C).degree x = C.degree x + (if e₁ ∈ E(C) ∧ x = v then 2 else 0)`

makes every `L C` even, so Veblen's decomposition (`veblen_even_decomposition`) breaks it into
cycles of `G`; binding these over `D` gives a CDC of `G`.
-/

open Set
open scoped Graph
open scoped Classical

namespace Workspace.PriorWorkProofs.Jaeger

open Workspace.Types.Cycle Workspace.Types.CycleDoubleCover

variable {α β : Type*} {G : Graph α β} {v : α}

/-! ## Structural facts about a cycle of the reroute -/

/-- For an edge `f ≠ e₁` of a cycle `C` of the reroute, `G` and `C` see the same incidences
(the reroute only changes `e₁` and deletes `e₂`, and `e₂ ∉ E(C)`). -/
private theorem reroute_cycle_inc_iff {v1 v2 : α} {e1 e2 : β}
    (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2) (hne : e1 ≠ e2)
    {C : Graph α β} (hC : (reroute G v1 v2 e1 e2).IsCycle C)
    {f : β} (hfC : f ∈ E(C)) (hfe1 : f ≠ e1) (x : α) :
    (G.Inc f x ↔ C.Inc f x) := by
  have hCle : C ≤ reroute G v1 v2 e1 e2 := hC.le
  have hfe2 : f ≠ e2 := by
    intro h
    have hmem : f ∈ E(reroute G v1 v2 e1 e2) := Graph.IsSubgraph.edgeSet_mono hCle hfC
    rw [edgeSet_reroute he1 he2 hne] at hmem
    exact hmem.2 (by simpa using h)
  constructor
  · rintro ⟨y, hxy⟩
    obtain ⟨a, b, hab⟩ := Graph.exists_isLink_of_mem_edgeSet hfC
    have hGab : G.IsLink f a b := by
      have hr := hCle.isLink_mono hab
      rw [reroute_isLink] at hr
      rcases hr with ⟨rfl, -, -⟩ | ⟨-, -, hg⟩
      · exact absurd rfl hfe1
      · exact hg
    rcases hxy.eq_and_eq_or_eq_and_eq hGab with ⟨rfl, -⟩ | ⟨rfl, -⟩
    · exact ⟨b, hab⟩
    · exact ⟨a, hab.symm⟩
  · rintro ⟨y, hxy⟩
    have hr := hCle.isLink_mono hxy
    rw [reroute_isLink] at hr
    rcases hr with ⟨rfl, -, -⟩ | ⟨-, -, hg⟩
    · exact absurd rfl hfe1
    · exact ⟨y, hg⟩

/-- In a cycle `C` of the reroute that uses `e₁`, the edge `e₁` joins `v₁`–`v₂` (as relabelled). -/
private theorem reroute_cycle_e1_link {v1 v2 : α} {e1 e2 : β}
    {C : Graph α β} (hC : (reroute G v1 v2 e1 e2).IsCycle C) (hfC : e1 ∈ E(C)) :
    C.IsLink e1 v1 v2 := by
  have hCle : C ≤ reroute G v1 v2 e1 e2 := hC.le
  obtain ⟨a, b, hab⟩ := Graph.exists_isLink_of_mem_edgeSet hfC
  have hr := hCle.isLink_mono hab
  rw [reroute_isLink] at hr
  rcases hr with ⟨-, -, hd⟩ | ⟨hfe1, -, -⟩
  · rcases hd with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
    · exact hab
    · exact hab.symm
  · exact absurd rfl hfe1

/-- Only `e₁` can be a loop of a cycle `C` of the reroute (`G` is loopless, and every edge other
than `e₁` keeps its `G`-incidences), and `e₁` is a loop of `C` iff `v₁ = v₂` (at the vertex `v₁`). -/
private theorem reroute_cycle_isLoopAt_iff {v1 v2 : α} {e1 e2 : β}
    (hll : G.IsLoopless) (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2) (hne : e1 ≠ e2)
    {C : Graph α β} (hC : (reroute G v1 v2 e1 e2).IsCycle C)
    {f : β} {x : α} (hloop : C.IsLoopAt f x) : f = e1 ∧ v1 = v2 ∧ x = v1 := by
  have hCle : C ≤ reroute G v1 v2 e1 e2 := hC.le
  have hfC : f ∈ E(C) := hloop.inc.edge_mem
  have hlink : C.IsLink f x x := hloop
  by_cases hfe1 : f = e1
  · have hce1 : C.IsLink e1 v1 v2 := reroute_cycle_e1_link hC (hfe1 ▸ hfC)
    have hlink' : C.IsLink e1 x x := hfe1 ▸ hlink
    -- both `C.IsLink e1 x x` and `C.IsLink e1 v1 v2`, so `{x} = {v1, v2}`
    rcases hlink'.eq_and_eq_or_eq_and_eq hce1 with ⟨rfl, hb⟩ | ⟨rfl, hb⟩
    · exact ⟨hfe1, hb, rfl⟩
    · exact ⟨hfe1, hb.symm, hb⟩
  · exfalso
    have hr := hCle.isLink_mono hlink
    rw [reroute_isLink] at hr
    rcases hr with ⟨heq, -, -⟩ | ⟨-, -, hg⟩
    · exact hfe1 heq
    · exact hll f x hg
/-- Peeling one element `e` from a finite set: its cardinality is that of `S \ {e}` plus the
`0/1` indicator of `e ∈ S`. -/
private lemma ncard_peel (S : Set β) (hS : S.Finite) (e : β) :
    S.ncard = (S \ {e}).ncard + (if e ∈ S then 1 else 0) := by
  by_cases h : e ∈ S
  · rw [if_pos h]
    have hins : insert e (S \ {e}) = S := by
      rw [Set.insert_diff_singleton, Set.insert_eq_of_mem h]
    have hnotin : e ∉ S \ {e} := by simp
    conv_lhs => rw [← hins]
    rw [Set.ncard_insert_of_notMem hnotin hS.diff]
  · rw [if_neg h, add_zero, Set.diff_singleton_eq_self h]

/-- `G.Inc e x` for a non-loop edge `e = a b` holds exactly at its two ends. -/
private lemma inc_iff_ends {a b x : α} {e : β} (he : G.IsLink e a b) :
    G.Inc e x ↔ (x = a ∨ x = b) := by
  constructor
  · rintro ⟨y, hy⟩
    rcases hy.eq_and_eq_or_eq_and_eq he with ⟨rfl, -⟩ | ⟨rfl, -⟩
    · exact Or.inl rfl
    · exact Or.inr rfl
  · rintro (rfl | rfl)
    · exact ⟨b, he⟩
    · exact ⟨a, he.symm⟩

/-- **The key degree identity.** The lifted subgraph `L C = G.restrict (F C)` has degree at `x`
equal to `C`'s degree, except `+2` at the suppressed vertex `v` when `C` uses `e₁`. Hence every
degree of `L C` is even (a cycle is `2`-regular). -/
private theorem lift_degree_eq {v1 v2 : α} {e1 e2 : β}
    (hll : G.IsLoopless) (hEfin : E(G).Finite)
    (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2) (hne : e1 ≠ e2)
    {C : Graph α β} (hC : (reroute G v1 v2 e1 e2).IsCycle C) (x : α) :
    (G.restrict (E(C) ∪ (if e1 ∈ E(C) then {e2} else ∅))).degree x
      = C.degree x + (if e1 ∈ E(C) ∧ x = v then 2 else 0) := by
  classical
  have hv1 : v ≠ v1 := fun h => hll e1 v (h ▸ he1)
  have hv2 : v ≠ v2 := fun h => hll e2 v (h ▸ he2)
  have hCle : C ≤ reroute G v1 v2 e1 e2 := hC.le
  have hEC : E(C) ⊆ E(G) := by
    refine (Graph.IsSubgraph.edgeSet_mono hCle).trans ?_
    rw [edgeSet_reroute he1 he2 hne]; exact Set.diff_subset
  have he2nC : e2 ∉ E(C) := by
    intro h
    have hm := Graph.IsSubgraph.edgeSet_mono hCle h
    rw [edgeSet_reroute he1 he2 hne] at hm; exact hm.2 rfl
  have hGe1 : G.Inc e1 x ↔ (x = v ∨ x = v1) := inc_iff_ends he1
  have hGe2 : G.Inc e2 x ↔ (x = v ∨ x = v2) := inc_iff_ends he2
  set F : Set β := E(C) ∪ (if e1 ∈ E(C) then {e2} else ∅) with hFdef
  set L : Graph α β := G.restrict F with hLdef
  have hLloop : L.IsLoopless := fun e y hl => hll e y (hl.mono Graph.restrict_le)
  have hLincSubG : L.incidenceSet x ⊆ E(G) :=
    (L.incidenceSet_subset_edgeSet x).trans (Graph.IsSubgraph.edgeSet_mono Graph.restrict_le)
  have hLincFin : (L.incidenceSet x).Finite := hEfin.subset hLincSubG
  have hCincFin : (C.incidenceSet x).Finite :=
    hEfin.subset ((C.incidenceSet_subset_edgeSet x).trans hEC)
  have hCloopFin : (C.loopSet x).Finite :=
    hEfin.subset ((C.loopSet_subset_incidenceSet x).trans
      ((C.incidenceSet_subset_edgeSet x).trans hEC))
  have hmemL : ∀ f, f ∈ L.incidenceSet x ↔ (G.Inc f x ∧ f ∈ F) := by
    intro f; rw [Graph.mem_incidenceSet, hLdef, Graph.restrict_inc]
  -- membership facts as `↔` for rewriting the indicators
  have he1inL : (e1 ∈ L.incidenceSet x) ↔ (e1 ∈ F ∧ G.Inc e1 x) := (hmemL e1).trans And.comm
  have he2inL : (e2 ∈ L.incidenceSet x \ {e1}) ↔ (e2 ∈ F ∧ G.Inc e2 x) := by
    rw [Set.mem_diff, Set.mem_singleton_iff, hmemL]
    constructor
    · rintro ⟨⟨h1, h2⟩, -⟩; exact ⟨h2, h1⟩
    · rintro ⟨h1, h2⟩; exact ⟨⟨h2, h1⟩, hne.symm⟩
  have he1F : e1 ∈ F ↔ e1 ∈ E(C) := by
    rw [hFdef]; constructor
    · rintro (h | h)
      · exact h
      · split_ifs at h with hc
        · rw [Set.mem_singleton_iff] at h; exact absurd h hne
        · exact absurd h (Set.notMem_empty e1)
    · intro h; exact Or.inl h
  have he2F : e2 ∈ F ↔ e1 ∈ E(C) := by
    rw [hFdef]; constructor
    · rintro (h | h)
      · exact absurd h he2nC
      · split_ifs at h with hc
        · exact hc
        · exact absurd h (Set.notMem_empty e2)
    · intro h; exact Or.inr (by rw [if_pos h]; exact rfl)
  have hCe1inc : C.Inc e1 x ↔ (e1 ∈ E(C) ∧ (x = v1 ∨ x = v2)) := by
    constructor
    · intro h
      exact ⟨h.edge_mem, (inc_iff_ends (reroute_cycle_e1_link hC h.edge_mem)).mp h⟩
    · rintro ⟨hmem, hx⟩
      exact (inc_iff_ends (reroute_cycle_e1_link hC hmem)).mpr hx
  have hCe1loop : C.IsLoopAt e1 x ↔ (e1 ∈ E(C) ∧ v1 = v2 ∧ x = v1) := by
    constructor
    · intro h
      obtain ⟨-, hvv, hxv1⟩ := reroute_cycle_isLoopAt_iff hll he1 he2 hne hC h
      exact ⟨h.inc.edge_mem, hvv, hxv1⟩
    · rintro ⟨hmem, hvv, hxv1⟩
      have hlink := reroute_cycle_e1_link hC hmem
      rw [hxv1]; exact hvv.symm ▸ hlink
  -- the common `A = C.incidenceSet x \ {e1}` and the two peelings of `L`
  have hAeq : (L.incidenceSet x \ {e1}) \ {e2} = C.incidenceSet x \ {e1} := by
    ext f
    simp only [Set.mem_diff, Set.mem_singleton_iff, hmemL, Graph.mem_incidenceSet]
    constructor
    · rintro ⟨⟨⟨hInc, hfF⟩, hfe1⟩, hfe2⟩
      have hfC : f ∈ E(C) := by
        rw [hFdef] at hfF
        rcases hfF with h | h
        · exact h
        · split_ifs at h with hc
          · rw [Set.mem_singleton_iff] at h; exact absurd h hfe2
          · exact absurd h (Set.notMem_empty f)
      exact ⟨(reroute_cycle_inc_iff he1 he2 hne hC hfC hfe1 x).mp hInc, hfe1⟩
    · rintro ⟨hCInc, hfe1⟩
      have hfC : f ∈ E(C) := hCInc.edge_mem
      have hfe2 : f ≠ e2 := fun h => he2nC (h ▸ hfC)
      refine ⟨⟨⟨(reroute_cycle_inc_iff he1 he2 hne hC hfC hfe1 x).mpr hCInc, ?_⟩, hfe1⟩, hfe2⟩
      rw [hFdef]; exact Or.inl hfC
  have hCloopA : C.loopSet x \ {e1} = ∅ := by
    rw [Set.eq_empty_iff_forall_notMem]
    intro f hf
    rw [Set.mem_diff, Graph.mem_loopSet, Set.mem_singleton_iff] at hf
    obtain ⟨hfe1, -, -⟩ := reroute_cycle_isLoopAt_iff hll he1 he2 hne hC hf.1
    exact hf.2 hfe1
  have hL1 := ncard_peel (L.incidenceSet x) hLincFin e1
  have hL2 := ncard_peel (L.incidenceSet x \ {e1}) hLincFin.diff e2
  rw [hAeq] at hL2
  have hCdeg : C.degree x = (C.incidenceSet x \ {e1}).ncard
      + (if e1 ∈ C.incidenceSet x then 1 else 0) + (if e1 ∈ C.loopSet x then 1 else 0) := by
    rw [Graph.degree_def, ncard_peel (C.incidenceSet x) hCincFin e1,
        ncard_peel (C.loopSet x) hCloopFin e1, hCloopA, Set.ncard_empty]
    ring
  -- assemble and reduce to an arithmetic identity in the indicators
  rw [hLloop.degree_eq_ncard_incidenceSet, hL1, hL2, hCdeg, he1inL, he2inL, he1F, he2F,
    Graph.mem_incidenceSet, Graph.mem_loopSet, hCe1inc, hCe1loop]
  simp only [hGe1, hGe2]
  clear hmemL he1inL he2inL he1F he2F hCe1inc hCe1loop hL1 hL2 hCdeg hGe1 hGe2 hAeq hCloopA
    hLloop hLincFin hLincSubG hCincFin hCloopFin hEC he2nC hCle hFdef hLdef
  by_cases he1C : e1 ∈ E(C) <;> by_cases hxv : x = v <;> by_cases hxv1 : x = v1 <;>
    by_cases hxv2 : x = v2 <;> by_cases hvv : v1 = v2 <;> simp_all <;> omega

/-- Veblen-decompose the lift `L C` of a cycle `C` of the reroute: a multiset of cycles of `G`
covering each edge of `F C` exactly once (and no other edge). -/
private theorem exists_decomp {v1 v2 : α} {e1 e2 : β}
    (hll : G.IsLoopless) (hVfin : V(G).Finite) (hEfin : E(G).Finite)
    (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2) (hne : e1 ≠ e2)
    {C : Graph α β} (hC : (reroute G v1 v2 e1 e2).IsCycle C) :
    ∃ DC : Multiset (Graph α β), (∀ Ci ∈ DC, G.IsCycle Ci) ∧
      ∀ f, DC.edgeMultiplicity f
        = if f ∈ (E(C) ∪ (if e1 ∈ E(C) then {e2} else ∅)) then 1 else 0 := by
  classical
  have hEC : E(C) ⊆ E(G) :=
    (Graph.IsSubgraph.edgeSet_mono hC.le).trans
      (by rw [edgeSet_reroute he1 he2 hne]; exact Set.diff_subset)
  set F : Set β := E(C) ∪ (if e1 ∈ E(C) then {e2} else ∅) with hFdef
  have hFsubG : F ⊆ E(G) := by
    intro f hf
    rw [hFdef, Set.mem_union] at hf
    rcases hf with h | h
    · exact hEC h
    · split_ifs at h with hc
      · rw [Set.mem_singleton_iff] at h; exact h ▸ he2.edge_mem
      · exact absurd h (Set.notMem_empty f)
  have hLle : G.restrict F ≤ G := Graph.restrict_le
  have hLloop : (G.restrict F).IsLoopless := fun e y hl => hll e y (hl.mono hLle)
  have hVL : V(G.restrict F).Finite := by rw [Graph.vertexSet_restrict]; exact hVfin
  have hEL : E(G.restrict F).Finite := hEfin.subset (Graph.IsSubgraph.edgeSet_mono hLle)
  have hELeq : E(G.restrict F) = F := by
    rw [Graph.edgeSet_restrict, Set.inter_eq_right.mpr hFsubG]
  have hEven : ∀ x ∈ V(G.restrict F), Even ((G.restrict F).degree x) := by
    intro x _
    have hkey := lift_degree_eq hll hEfin he1 he2 hne hC x
    rw [← hFdef] at hkey
    rw [hkey]
    have hCe : Even (C.degree x) := by
      by_cases hx : x ∈ V(C)
      · rw [hC.degree_eq hx]; exact even_two
      · rw [Graph.degree_eq_zero_of_notMem hx]; exact ⟨0, rfl⟩
    by_cases hcond : e1 ∈ E(C) ∧ x = v
    · rw [if_pos hcond]; obtain ⟨k, hk⟩ := hCe; exact ⟨k + 1, by omega⟩
    · rw [if_neg hcond, add_zero]; exact hCe
  obtain ⟨DC, hcyc, hcover⟩ := Workspace.PriorWork.veblen_even_decomposition (G.restrict F) hVL hEL hLloop hEven
  refine ⟨DC, fun Ci hCi => (hcyc Ci hCi).mono hLle, fun f => ?_⟩
  by_cases hf : f ∈ F
  · rw [if_pos hf]; exact hcover f (by rw [hELeq]; exact hf)
  · rw [if_neg hf, Multiset.edgeMultiplicity_eq_zero_iff]
    intro Ci hCi hfCi
    have hmem : f ∈ E(G.restrict F) := Graph.IsSubgraph.edgeSet_mono (hcyc Ci hCi).le hfCi
    rw [hELeq] at hmem; exact hf hmem

/-- Multiplicity in a bind is the sum of the members' multiplicities. -/
private lemma edgeMultiplicity_bind (D : Multiset (Graph α β))
    (g : Graph α β → Multiset (Graph α β)) (f : β) :
    (D.bind g).edgeMultiplicity f = (D.map (fun C => (g C).edgeMultiplicity f)).sum := by
  classical
  induction D using Multiset.induction with
  | empty => simp [Multiset.edgeMultiplicity_def]
  | cons C D ih =>
    rw [Multiset.cons_bind, Multiset.map_cons, Multiset.sum_cons, ← ih,
      Multiset.edgeMultiplicity_def, Multiset.edgeMultiplicity_def, Multiset.edgeMultiplicity_def,
      Multiset.countP_add]

/-- Sum of `0/1` indicators over a multiset equals `countP`. -/
private lemma sum_map_indicator (D : Multiset (Graph α β)) (p : Graph α β → Prop)
    [DecidablePred p] : (D.map (fun C => if p C then (1 : ℕ) else 0)).sum = D.countP p := by
  induction D using Multiset.induction with
  | empty => simp
  | cons C D ih =>
    rw [Multiset.map_cons, Multiset.sum_cons, ih, Multiset.countP_cons, add_comm]

/-- **The unified reroute CDC lift.** -/
theorem cdc_lift_reroute {v1 v2 : α} {e1 e2 : β}
    (hll : G.IsLoopless) (hVfin : V(G).Finite) (hEfin : E(G).Finite)
    (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2) (hne : e1 ≠ e2)
    {D : Multiset (Graph α β)} (hD : (reroute G v1 v2 e1 e2).IsCycleDoubleCover D) :
    G.HasCycleDoubleCover := by
  classical
  -- for each cycle `C` of the reroute, its Veblen-decomposed lift
  let gg : Graph α β → Multiset (Graph α β) := fun C =>
    if hCc : (reroute G v1 v2 e1 e2).IsCycle C
    then (exists_decomp hll hVfin hEfin he1 he2 hne hCc).choose else 0
  have hggspec : ∀ C, (reroute G v1 v2 e1 e2).IsCycle C →
      (∀ Ci ∈ gg C, G.IsCycle Ci) ∧
        ∀ f, (gg C).edgeMultiplicity f
          = if f ∈ (E(C) ∪ (if e1 ∈ E(C) then {e2} else ∅)) then 1 else 0 := by
    intro C hCc
    have hgg : gg C = (exists_decomp hll hVfin hEfin he1 he2 hne hCc).choose := dif_pos hCc
    rw [hgg]; exact (exists_decomp hll hVfin hEfin he1 he2 hne hCc).choose_spec
  refine ⟨D.bind gg, ?_, ?_⟩
  · -- every member is a cycle of `G`
    intro Ci hCi
    rw [Multiset.mem_bind] at hCi
    obtain ⟨C, hCD, hCigg⟩ := hCi
    exact (hggspec C (hD.isCycle_of_mem hCD)).1 Ci hCigg
  · -- every edge of `G` has multiplicity `2`
    intro f hf
    rw [edgeMultiplicity_bind]
    have hmapeq : D.map (fun C => (gg C).edgeMultiplicity f)
        = D.map (fun C => if f ∈ (E(C) ∪ (if e1 ∈ E(C) then {e2} else ∅)) then 1 else 0) := by
      apply Multiset.map_congr rfl
      intro C hCD
      exact (hggspec C (hD.isCycle_of_mem hCD)).2 f
    rw [hmapeq, sum_map_indicator]
    by_cases hfe2 : f = e2
    · have hpred : ∀ C ∈ D, (f ∈ (E(C) ∪ (if e1 ∈ E(C) then {e2} else ∅))) ↔ (e1 ∈ E(C)) := by
        intro C hCD
        have hCc := hD.isCycle_of_mem hCD
        have he2nC : e2 ∉ E(C) := by
          intro h
          have hm := Graph.IsSubgraph.edgeSet_mono hCc.le h
          rw [edgeSet_reroute he1 he2 hne] at hm; exact hm.2 rfl
        rw [hfe2, Set.mem_union]
        constructor
        · rintro (h | h)
          · exact absurd h he2nC
          · split_ifs at h with hc
            · exact hc
            · exact absurd h (Set.notMem_empty e2)
        · intro h; exact Or.inr (by rw [if_pos h]; exact rfl)
      rw [Multiset.countP_congr rfl (by intro C hCD; exact propext (hpred C hCD)),
        ← Multiset.edgeMultiplicity_def]
      have he1G' : e1 ∈ E(reroute G v1 v2 e1 e2) := by
        rw [edgeSet_reroute he1 he2 hne]; exact ⟨he1.edge_mem, by simpa using hne⟩
      exact hD.edgeMultiplicity_eq he1G'
    · have hpred : ∀ C ∈ D, (f ∈ (E(C) ∪ (if e1 ∈ E(C) then {e2} else ∅))) ↔ (f ∈ E(C)) := by
        intro C hCD
        rw [Set.mem_union]
        constructor
        · rintro (h | h)
          · exact h
          · split_ifs at h with hc
            · rw [Set.mem_singleton_iff] at h; exact absurd h hfe2
            · exact absurd h (Set.notMem_empty f)
        · intro h; exact Or.inl h
      rw [Multiset.countP_congr rfl (by intro C hCD; exact propext (hpred C hCD)),
        ← Multiset.edgeMultiplicity_def]
      have hfG' : f ∈ E(reroute G v1 v2 e1 e2) := by
        rw [edgeSet_reroute he1 he2 hne]; exact ⟨hf, by simpa using hfe2⟩
      exact hD.edgeMultiplicity_eq hfG'

/-- **Move D2 — the CDC lift (degree-2 suppression).** -/
theorem cdc_lift_reroute_degree_two {v1 v2 : α} {e1 e2 : β}
    (hll : G.IsLoopless) (hVfin : V(G).Finite) (hEfin : E(G).Finite) (hdeg : G.degree v = 2)
    (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2) (hne : e1 ≠ e2)
    {D : Multiset (Graph α β)} (hD : (reroute G v1 v2 e1 e2).IsCycleDoubleCover D) :
    G.HasCycleDoubleCover :=
  cdc_lift_reroute hll hVfin hEfin he1 he2 hne hD

/-- **Move SP — the CDC lift (degree-≥4 split, uses Veblen).** -/
theorem cdc_lift_reroute_split {v1 v2 : α} {e1 e2 : β}
    (hll : G.IsLoopless) (hVfin : V(G).Finite) (hEfin : E(G).Finite)
    (he1 : G.IsLink e1 v v1) (he2 : G.IsLink e2 v v2) (hne : e1 ≠ e2)
    {D : Multiset (Graph α β)} (hD : (reroute G v1 v2 e1 e2).IsCycleDoubleCover D) :
    G.HasCycleDoubleCover :=
  cdc_lift_reroute hll hVfin hEfin he1 he2 hne hD

end Workspace.PriorWorkProofs.Jaeger

/-!
# Jaeger's reduction — the induction skeleton

Assembles the moves of `Moves.lean` and `EvenLift.lean` with the admitted classical inputs of
`Fleischner.lean`/`Veblen.lean` into a proof of **Jaeger's reduction** in the exact form of the
`Workspace.PriorWork.jaeger_cubic_reduction` axiom:

> if every finite bridgeless loopless cubic multigraph has a cycle double cover, then every
> finite bridgeless multigraph has a cycle double cover.

The proof is by strong induction on `E(G).ncard`, phrased polymorphically over all `α β` so the
induction hypothesis is available at every vertex/edge type. Each step applies one move:

* **Base** (`E(G) = ∅`): the empty CDC.
* **Move L** (a loop `ℓ`): delete `ℓ`, recurse, lift with `cdc_lift_loop`.
* **Move D2** (a degree-2 vertex): `reroute`, recurse, lift with `cdc_lift_reroute_degree_two`.
* **Move SP** (a degree-≥4 vertex): `fleischner_splitting_lemma` gives a bridgeless `reroute`;
  recurse; lift with `cdc_lift_reroute_split`.
* **Terminal** (loopless, every degree `0` or `3`): delete isolated vertices to get a cubic
  graph and apply `H`.
-/

open Set
open scoped Graph

namespace Workspace.PriorWorkProofs.Jaeger

open Workspace.Types.CycleDoubleCover Workspace.Types.Cycle

/-- In a loopless graph, an edge incident to `v` forces `v` to have positive degree. -/
private theorem degree_pos_of_mem_incidenceSet {α β : Type*} {G : Graph α β} {v : α} {e : β}
    (hll : G.IsLoopless) (hfin : (G.incidenceSet v).Finite) (he : e ∈ G.incidenceSet v) :
    0 < G.degree v := by
  rw [hll.degree_eq_ncard_incidenceSet]
  exact (Set.ncard_pos hfin).mpr ⟨e, he⟩

/-- **Terminal case of Jaeger's reduction.** A finite bridgeless loopless graph in which every
vertex has degree `0` or `3` has a cycle double cover: delete the isolated (degree-`0`) vertices
to obtain a cubic graph (with the same edge set), which is still finite, loopless and bridgeless,
and apply the loopless-cubic hypothesis `H`. Since no edge is lost, a CDC of the cubic graph is a
CDC of `G`. -/
private theorem terminal_hasCDC.{u, w}
    {α : Type u} {β : Type w} {G : Graph α β}
    (H : ∀ (α : Type u) (β : Type w) (G : Graph α β),
      V(G).Finite → E(G).Finite → G.IsLoopless → G.IsCubic → G.Bridgeless →
        G.HasCycleDoubleCover)
    (hV : V(G).Finite) (hE : E(G).Finite) (hbr : G.Bridgeless) (hll : G.IsLoopless)
    (hdeg : ∀ v ∈ V(G), G.degree v = 0 ∨ G.degree v = 3) :
    G.HasCycleDoubleCover := by
  classical
  set X : Set α := {v | G.degree v = 3} with hXdef
  have hmemX : ∀ a : α, a ∈ X ↔ G.degree a = 3 := fun a => Iff.rfl
  -- an edge end has degree `3`, hence lies in `X`
  have hendX : ∀ e a b, G.IsLink e a b → a ∈ X := by
    intro e a b hab
    have haV : a ∈ V(G) := hab.left_mem
    have hfin : (G.incidenceSet a).Finite := hE.subset (G.incidenceSet_subset_edgeSet a)
    have hpos : 0 < G.degree a :=
      degree_pos_of_mem_incidenceSet hll hfin ((G.mem_incidenceSet a e).2 hab.inc_left)
    rw [hmemX]
    rcases hdeg a haV with h0 | h3
    · omega
    · exact h3
  have hclosed : ∀ e a b, G.IsLink e a b → (a ∈ X ↔ b ∈ X) := fun e a b hab =>
    ⟨fun _ => hendX e b a hab.symm, fun _ => hendX e a b hab⟩
  have hXsub : X ⊆ V(G) := by
    intro v hv
    by_contra hvV
    rw [hmemX] at hv
    rw [Graph.degree_eq_zero_of_notMem hvV] at hv
    omega
  set G' : Graph α β := G.induce X with hG'def
  have hG'le : G' ≤ G := Graph.induce_le hXsub
  have hV' : V(G').Finite := by rw [hG'def, Graph.vertexSet_induce]; exact hV.subset hXsub
  have hE' : E(G').Finite := hE.subset (Graph.IsSubgraph.edgeSet_mono hG'le)
  have hll' : G'.IsLoopless := fun e x hl => hll e x (hl.mono hG'le)
  -- incidence sets agree for `X`-vertices, so `G'` is cubic
  have hinc_eq : ∀ v ∈ X, G'.incidenceSet v = G.incidenceSet v := by
    intro v hv
    ext e
    rw [Graph.mem_incidenceSet, Graph.mem_incidenceSet]
    constructor
    · intro h; exact h.mono hG'le
    · rintro ⟨w, hlink⟩
      have hwX : w ∈ X := hendX e w v hlink.symm
      exact ⟨w, by rw [hG'def, Graph.induce_isLink]; exact ⟨hlink, hv, hwX⟩⟩
  have hcubic : G'.IsCubic := by
    intro v hv
    rw [hG'def, Graph.vertexSet_induce] at hv
    rw [hll'.degree_eq_ncard_incidenceSet, hinc_eq v hv, ← hll.degree_eq_ncard_incidenceSet]
    exact (hmemX v).1 hv
  have hbr' : G'.Bridgeless :=
    Workspace.PriorWorkProofs.EightFlow.induce_bridgeless hbr hclosed
  obtain ⟨D, hD⟩ := H α β G' hV' hE' hll' hcubic hbr'
  -- `E(G') = E(G)`: both ends of every edge are in `X`
  have hEeq : E(G') = E(G) := by
    refine Set.eq_of_subset_of_subset (Graph.IsSubgraph.edgeSet_mono hG'le) ?_
    intro e he
    obtain ⟨a, b, hab⟩ := Graph.exists_isLink_of_mem_edgeSet he
    rw [Graph.edge_mem_iff_exists_isLink]
    exact ⟨a, b, by
      rw [hG'def, Graph.induce_isLink]
      exact ⟨hab, hendX e a b hab, hendX e b a hab.symm⟩⟩
  refine ⟨D, ?_, ?_⟩
  · intro C hC; exact (hD.isCycle_of_mem hC).mono hG'le
  · intro e he
    rw [← hEeq] at he
    exact hD.edgeMultiplicity_eq he

/-- **Jaeger's reduction to the loopless cubic case** — same statement as the
`Workspace.PriorWork.jaeger_cubic_reduction` axiom. Proved from the elementary moves
(`Moves.lean`, `EvenLift.lean`) and the admitted Fleischner/Veblen inputs. -/
theorem jaeger_cubic_reduction_proof.{u, w}
    (H : ∀ (α : Type u) (β : Type w) (G : Graph α β),
      V(G).Finite → E(G).Finite → G.IsLoopless → G.IsCubic → G.Bridgeless →
        G.HasCycleDoubleCover) :
    ∀ (α : Type u) (β : Type w) (G : Graph α β),
      V(G).Finite → E(G).Finite → G.Bridgeless → G.HasCycleDoubleCover := by
  -- Strong induction on the edge count, uniform over all `α β`.
  suffices key : ∀ n : ℕ, ∀ (α : Type u) (β : Type w) (G : Graph α β),
      V(G).Finite → E(G).Finite → E(G).ncard ≤ n → G.Bridgeless → G.HasCycleDoubleCover by
    intro α β G hV hE hbr
    exact key (E(G).ncard) α β G hV hE le_rfl hbr
  intro n
  induction n with
  | zero =>
    intro α β G _ hE hcard hbr
    have hEmpty : E(G) = ∅ := by
      rw [← Set.ncard_eq_zero hE]; omega
    exact ⟨0, (Graph.isCycleDoubleCover_zero_iff).2 hEmpty⟩
  | succ n ih =>
    intro α β G hV hE hcard hbr
    by_cases hEmpty : E(G) = ∅
    · exact ⟨0, (Graph.isCycleDoubleCover_zero_iff).2 hEmpty⟩
    -- `E(G)` is nonempty from here on.
    by_cases hLoop : ∃ ℓ x, G.IsLoopAt ℓ x
    · -- Move L — loop removal.
      obtain ⟨ℓ, x, hℓ⟩ := hLoop
      have hℓE : ℓ ∈ E(G) := hℓ.edge_mem
      have hpos : 0 < E(G).ncard := Set.ncard_pos hE |>.mpr ⟨ℓ, hℓE⟩
      have hbr' : (G.deleteEdges {ℓ}).Bridgeless := bridgeless_deleteEdge_loop hbr hℓ
      have hV' : V(G.deleteEdges {ℓ}).Finite := by
        rw [Graph.vertexSet_deleteEdges]; exact hV
      have hE' : E(G.deleteEdges {ℓ}).Finite := by
        rw [Graph.edgeSet_deleteEdges]; exact hE.diff
      have hcard' : E(G.deleteEdges {ℓ}).ncard ≤ n := by
        rw [Graph.edgeSet_deleteEdges, Set.ncard_diff_singleton_of_mem hℓE]; omega
      obtain ⟨D, hD⟩ := ih α β (G.deleteEdges {ℓ}) hV' hE' hcard' hbr'
      exact ⟨_, cdc_lift_loop hℓ hD⟩
    · -- `G` is loopless.
      have hll : G.IsLoopless := fun ℓ x h => hLoop ⟨ℓ, x, h⟩
      by_cases hD2 : ∃ (v v1 v2 : α) (e1 e2 : β),
          e1 ≠ e2 ∧ G.degree v = 2 ∧ G.IsLink e1 v v1 ∧ G.IsLink e2 v v2
      · -- Move D2 — degree-2 suppression.
        obtain ⟨v, v1, v2, e1, e2, hne, hdeg, he1, he2⟩ := hD2
        have he2E : e2 ∈ E(G) := he2.edge_mem
        have hpos : 0 < E(G).ncard := Set.ncard_pos hE |>.mpr ⟨e2, he2E⟩
        have hbr' : (reroute G v1 v2 e1 e2).Bridgeless :=
          bridgeless_reroute_of_degree_two hbr hll hdeg he1 he2 hne
        have hV' : V(reroute G v1 v2 e1 e2).Finite := by rw [vertexSet_reroute]; exact hV
        have hE' : E(reroute G v1 v2 e1 e2).Finite := by
          rw [edgeSet_reroute he1 he2 hne]; exact hE.diff
        have hcard' : E(reroute G v1 v2 e1 e2).ncard ≤ n := by
          rw [edgeSet_reroute he1 he2 hne, Set.ncard_diff_singleton_of_mem he2E]; omega
        obtain ⟨D, hD⟩ := ih α β (reroute G v1 v2 e1 e2) hV' hE' hcard' hbr'
        exact cdc_lift_reroute_degree_two hll hV hE hdeg he1 he2 hne hD
      · by_cases hD4 : ∃ v, 4 ≤ G.degree v
        · -- Move SP — degree-≥4 Fleischner split.
          obtain ⟨v, hdeg⟩ := hD4
          obtain ⟨v1, v2, e1, e2, hne, he1, he2, hbr'⟩ :=
            Workspace.PriorWork.fleischner_splitting_lemma G v hV hE hll hbr hdeg
          have he2E : e2 ∈ E(G) := he2.edge_mem
          have hpos : 0 < E(G).ncard := Set.ncard_pos hE |>.mpr ⟨e2, he2E⟩
          have hV' : V(reroute G v1 v2 e1 e2).Finite := by rw [vertexSet_reroute]; exact hV
          have hE' : E(reroute G v1 v2 e1 e2).Finite := by
            rw [edgeSet_reroute he1 he2 hne]; exact hE.diff
          have hcard' : E(reroute G v1 v2 e1 e2).ncard ≤ n := by
            rw [edgeSet_reroute he1 he2 hne, Set.ncard_diff_singleton_of_mem he2E]; omega
          obtain ⟨D, hD⟩ := ih α β (reroute G v1 v2 e1 e2) hV' hE' hcard' hbr'
          exact cdc_lift_reroute_split hll hV hE he1 he2 hne hD
        · -- Terminal — loopless, every vertex degree `0` or `3`: delete isolated vertices to
          -- obtain a finite bridgeless loopless CUBIC graph and apply `H`.
          -- Every vertex has degree `0` or `3`: `¬hD4` bounds degrees by `3`; `¬hD2` and
          -- looplessness rule out degree `2`; bridgelessness rules out degree `1`.
          have hdeg : ∀ v ∈ V(G), G.degree v = 0 ∨ G.degree v = 3 := by
            intro v hv
            have hfin : (G.incidenceSet v).Finite := hE.subset (G.incidenceSet_subset_edgeSet v)
            have hle3 : G.degree v ≤ 3 := by
              by_contra h; push_neg at h; exact hD4 ⟨v, h⟩
            have hne2 : G.degree v ≠ 2 := by
              intro h2
              have hcard : (G.incidenceSet v).ncard = 2 := by
                rw [← hll.degree_eq_ncard_incidenceSet]; exact h2
              obtain ⟨e1, e2, hne, hset⟩ := Set.ncard_eq_two.mp hcard
              have he1 : e1 ∈ G.incidenceSet v := by rw [hset]; exact Set.mem_insert _ _
              have he2 : e2 ∈ G.incidenceSet v := by
                rw [hset]; exact Set.mem_insert_of_mem _ rfl
              obtain ⟨v1, hlink1⟩ := (G.mem_incidenceSet v e1).1 he1
              obtain ⟨v2, hlink2⟩ := (G.mem_incidenceSet v e2).1 he2
              exact hD2 ⟨v, v1, v2, e1, e2, hne, h2, hlink1, hlink2⟩
            have hne1 : G.degree v ≠ 1 := by
              intro h1
              have hcard : (G.incidenceSet v).ncard = 1 := by
                rw [← hll.degree_eq_ncard_incidenceSet]; exact h1
              obtain ⟨e, hset⟩ := Set.ncard_eq_one.mp hcard
              have he : e ∈ G.incidenceSet v := by rw [hset]; exact Set.mem_singleton e
              obtain ⟨w, hlink⟩ := (G.mem_incidenceSet v e).1 he
              have hvw : v ≠ w := by
                intro h; rw [← h] at hlink; exact hll e v hlink
              have hbridge : G.IsBridge e := by
                refine ⟨v, w, hlink, ?_⟩
                intro hr
                have hadj : ∀ b, ¬ (G.deleteEdges {e}).Adj v b := by
                  rintro b ⟨f, hf⟩
                  rw [Graph.deleteEdges_isLink] at hf
                  obtain ⟨hfl, hfne⟩ := hf
                  have hfinc : f ∈ G.incidenceSet v := (G.mem_incidenceSet v f).2 hfl.inc_left
                  rw [hset] at hfinc
                  exact hfne hfinc
                rw [Graph.reachable_def, Relation.reflTransGen_iff_eq hadj] at hr
                exact hvw hr.symm
              exact hbr e hlink.edge_mem hbridge
            omega
          exact terminal_hasCDC H hV hE hbr hll hdeg

end Workspace.PriorWorkProofs.Jaeger

/-!
# Prior work invoked by the proof of the Cycle Double Cover Conjecture

The three results from the literature that *"A Proof of the Cycle Double Cover Conjecture"*
cites and uses as black boxes:

* `jaeger_cubic_reduction` — Jaeger [3, Proposition 4]: it suffices to treat loopless
  cubic graphs;
* `kilpatrick_jaeger_nowhere_zero_gamma_flow` — Kilpatrick [5], Jaeger [4]: the 8-flow
  theorem, i.e. every finite bridgeless graph has a nowhere-zero `Γ`-flow (`Γ = 𝔽₂³`);
* `tutte_group_flow` — Tutte [9]: for a finite abelian group `A` of order `k`, a graph has a
  nowhere-zero `A`-flow iff it has a nowhere-zero integer `k`-flow, with the corollary
  `tutte_gamma_flow_iff_integer_eight_flow` the paper uses (`A = Γ`, `k = 8`).

Each statement carries both `V(G).Finite` and `E(G).Finite`, both load-bearing on this
project's `finsum`/`ncard`-based definitions.
-/

open Graph
open scoped Graph
open Workspace.Types.Gamma Workspace.Types.Orientation

namespace Workspace.PriorWork

/-! ## Prior work A — reduction to the loopless cubic case -/

/-- **Prior work A (Jaeger [3, Proposition 4]) — reduction to the loopless cubic case.**

> In order to prove Theorem 1.1 it suffices to treat **loopless cubic** graphs: if every
> finite bridgeless loopless cubic multigraph has a cycle double cover, then every finite
> bridgeless multigraph has a cycle double cover.

The hypothesis quantifies over **all** vertex and edge types in the ambient universes,
not merely over the vertex and edge types of the graph in the conclusion: the reduction
replaces each vertex by a small gadget and so produces a cubic graph on a larger vertex
and edge type. Both statements are universally quantified over graphs, so this theorem
is an implication between two `∀`-statements. -/
theorem jaeger_cubic_reduction.{u, v}
    (H : ∀ (α : Type u) (β : Type v) (G : Graph α β),
      V(G).Finite → E(G).Finite → G.IsLoopless → G.IsCubic → G.Bridgeless →
        G.HasCycleDoubleCover) :
    ∀ (α : Type u) (β : Type v) (G : Graph α β),
      V(G).Finite → E(G).Finite → G.Bridgeless → G.HasCycleDoubleCover :=
  Workspace.PriorWorkProofs.Jaeger.jaeger_cubic_reduction_proof H

/-! ## Prior work B — the 8-flow theorem -/

/-- **Prior work B (Kilpatrick [5]; Jaeger [4]) — the 8-flow theorem.**

> Every finite bridgeless graph has a nowhere-zero `Γ`-flow, where `Γ = 𝔽₂³`.

Being a flow is a property relative to an orientation `O` of `G`; the statement is given
for an arbitrary orientation.

Proved (not admitted) as `Workspace.PriorWorkProofs.EightFlow.bridgeless_gamma_flow`; the only
admission on that path is `Workspace.PriorWork.nash_williams_three_edge_disjoint_spanning_trees`. -/
theorem kilpatrick_jaeger_nowhere_zero_gamma_flow {α β : Type*} (G : Graph α β)
    (hV : V(G).Finite) (hE : E(G).Finite) (hG : G.Bridgeless) (O : Orientation G) :
    ∃ f : β → Gamma, G.IsFlow O f ∧ G.IsNowhereZero f :=
  Workspace.PriorWorkProofs.EightFlow.bridgeless_gamma_flow G hV hE hG O

/-! ## Prior work C — Tutte's group-flow theorem -/

/-- **Prior work C (Tutte's group-flow theorem [9]).**

> For a finite abelian group `A` of order `k`, a graph has a nowhere-zero `A`-flow if and
> only if it has a nowhere-zero integer `k`-flow.

Here `Graph.IsIntegerKFlow O φ k` already builds in nowhere-zeroness, since it demands
`0 < |φ e| < k` on every edge of `G`. -/
theorem tutte_group_flow {α β : Type*} {A : Type*} [AddCommGroup A] [Finite A] {k : ℕ}
    (hA : Nat.card A = k) (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (O : Orientation G) :
    (∃ f : β → A, G.IsFlow O f ∧ G.IsNowhereZero f) ↔
      (∃ φ : β → ℤ, G.IsIntegerKFlow O φ (k : ℤ)) :=
  Workspace.PriorWorkProofs.Tutte.tutte_group_flow_proved hA G hV hE O

/-- **Prior work C, the corollary the paper actually uses** (Tutte [9], with `A = Γ` and
`k = |Γ| = 8`).

> In particular (with `A = Γ`, `k = 8`), a graph has a nowhere-zero `Γ`-flow if and only
> if it has a nowhere-zero integer `8`-flow. -/
theorem tutte_gamma_flow_iff_integer_eight_flow {α β : Type*} (G : Graph α β)
    (hV : V(G).Finite) (hE : E(G).Finite) (O : Orientation G) :
    (∃ f : β → Gamma, G.IsFlow O f ∧ G.IsNowhereZero f) ↔
      (∃ φ : β → ℤ, G.IsIntegerKFlow O φ 8) :=
  Workspace.PriorWorkProofs.Tutte.tutte_gamma_flow_iff_integer_eight_flow_proved G hV hE O

end Workspace.PriorWork

open Set

open scoped Graph

open Workspace.Types.Gamma

namespace Workspace.Facts.Lemma21

variable {α β : Type*} {G H : Graph α β} {P : β → Set Gamma} {e f : β} {v : α}

/-! ## Private helper lemmas -/

private lemma restrict_loopless (h : G.IsLoopless) (F : Set β) :
    (G.restrict F).IsLoopless :=
  fun e x hl => h e x (hl.mono Graph.restrict_le)

private lemma restrict_incidenceSet_eq_palette (G : Graph α β) (P : β → Set Gamma)
    (v : α) (s : Gamma) :
    (G.restrict {f | s ∈ P f}).incidenceSet v = G.paletteIncidenceSet P v s := by
  ext e
  simp only [Graph.mem_incidenceSet, Graph.restrict_inc, Graph.mem_paletteIncidenceSet,
    Set.mem_setOf_eq]

private lemma restrict_degree_eq (h : G.IsLoopless) (F : Set β) (v : α) :
    (G.restrict F).degree v = ((G.restrict F).incidenceSet v).ncard :=
  (restrict_loopless h F).degree_eq_ncard_incidenceSet v

private lemma sub_loopless {K : Graph α β} (h : G.IsLoopless) (hle : K ≤ G) :
    K.IsLoopless :=
  fun e x hl => h e x (hl.mono hle)

/-- For a subgraph `K ≤ H`, the edges incident to `x` in `H` that belong to `K`
are exactly the edges incident to `x` in `K`. -/
private lemma incidenceSet_inter_edgeSet_of_le {K : Graph α β} (hle : K ≤ G) (x : α) :
    G.incidenceSet x ∩ E(K) = K.incidenceSet x := by
  ext e
  simp only [Set.mem_inter_iff, Graph.mem_incidenceSet]
  constructor
  · rintro ⟨hHe, heK⟩
    obtain ⟨a, b, hlink⟩ := Graph.exists_isLink_of_mem_edgeSet heK
    rcases hHe.eq_or_eq_of_isLink (hlink.mono hle) with rfl | rfl
    · exact hlink.inc_left
    · exact hlink.inc_right
  · intro hKe
    exact ⟨hKe.mono hle, hKe.edge_mem⟩

/-- Deleting the edges of a subgraph `C` from `G` removes exactly the `C`-edges from
each incidence set. -/
private lemma restrict_diff_incidenceSet (G C : Graph α β) (x : α) :
    (G.restrict (E(G) \ E(C))).incidenceSet x = G.incidenceSet x \ E(C) := by
  ext e
  simp only [Graph.mem_incidenceSet, Graph.restrict_inc, Set.mem_diff]
  constructor
  · rintro ⟨hinc, -, hnC⟩; exact ⟨hinc, hnC⟩
  · rintro ⟨hinc, hnC⟩; exact ⟨hinc, hinc.edge_mem, hnC⟩

private lemma encard_mem_iff_ncard {X : Type*} {S : Set X} (hS : S.Finite) :
    S.encard ∈ ({0, 2} : Set ℕ∞) ↔ (S.ncard = 0 ∨ S.ncard = 2) := by
  rw [Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · rintro (h | h)
    · exact Or.inl ((Set.ncard_eq_zero hS).2 (Set.encard_eq_zero.1 h))
    · exact Or.inr (Set.ncard_eq_two.2 (Set.encard_eq_two.1 h))
  · rintro (h | h)
    · exact Or.inl (Set.encard_eq_zero.2 ((Set.ncard_eq_zero hS).1 h))
    · exact Or.inr (Set.encard_eq_two.2 (Set.ncard_eq_two.1 h))

private lemma edgeMultiplicity_add (D₁ D₂ : Multiset (Graph α β)) (e : β) :
    (D₁ + D₂).edgeMultiplicity e = D₁.edgeMultiplicity e + D₂.edgeMultiplicity e := by
  classical
  simp only [Multiset.edgeMultiplicity_def, Multiset.countP_add]

private lemma edgeMultiplicity_finsetSum {ι : Type*} (t : Finset ι)
    (D : ι → Multiset (Graph α β)) (e : β) :
    (∑ i ∈ t, D i).edgeMultiplicity e = ∑ i ∈ t, (D i).edgeMultiplicity e := by
  classical
  induction t using Finset.induction with
  | empty => simp
  | insert a t ha ih =>
    rw [Finset.sum_insert ha, Finset.sum_insert ha, edgeMultiplicity_add, ih]

/-! ## Facts used in the proof of Lemma 2.1 -/

theorem fact_2_1a (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (P : β → Set Gamma) :
    (∀ v ∈ V(G), ∀ s : Gamma, (G.paletteIncidenceSet P v s).encard ∈ ({0, 2} : Set ℕ∞)) ↔
      (∀ s : Gamma, ∀ v ∈ V(G), (G.restrict {f | s ∈ P f}).degree v = 0 ∨
        (G.restrict {f | s ∈ P f}).degree v = 2) := by
  have hkey : ∀ (s : Gamma) (v : α),
      (G.restrict {f | s ∈ P f}).degree v = (G.paletteIncidenceSet P v s).ncard := by
    intro s v
    rw [restrict_degree_eq hloop, restrict_incidenceSet_eq_palette]
  have hfin : ∀ (v : α) (s : Gamma), (G.paletteIncidenceSet P v s).Finite :=
    fun v s => hE.subset (G.paletteIncidenceSet_subset_edgeSet P v s)
  constructor
  · intro hL s v hv
    rw [hkey s v]
    exact (encard_mem_iff_ncard (hfin v s)).1 (hL v hv s)
  · intro hR v hv s
    rw [encard_mem_iff_ncard (hfin v s), ← hkey s v]
    exact hR s v hv

theorem fact_2_1b (hV : V(H).Finite) (hE : E(H).Finite) (hloop : H.IsLoopless)
    (hdeg : ∀ x ∈ V(H), H.degree x = 0 ∨ H.degree x = 2)
    (hv : v ∈ V(H)) (hvdeg : H.degree v = 2) :
    H.IsCycle (H.induce {x | H.Reachable v x}) := by
  -- X = component of v, C = induced subgraph
  have hXsub : {x | H.Reachable v x} ⊆ V(H) := by
    intro x hx
    simp only [Set.mem_setOf_eq] at hx
    rcases eq_or_ne x v with rfl | hne
    · exact hv
    · exact hx.right_mem_of_ne (Ne.symm hne)
  have hCle : H.induce {x | H.Reachable v x} ≤ H := Graph.induce_le hXsub
  have hCloop : (H.induce {x | H.Reachable v x}).IsLoopless :=
    fun e y hl => hloop e y (hl.mono hCle)
  have hvX : v ∈ {x | H.Reachable v x} := Graph.Reachable.rfl
  -- degree of every vertex of the component is 2 in H
  have hdeg2 : ∀ x ∈ {x | H.Reachable v x}, H.degree x = 2 := by
    intro x hx
    simp only [Set.mem_setOf_eq] at hx
    rcases eq_or_ne x v with rfl | hne
    · exact hvdeg
    · have hxV : x ∈ V(H) := hx.right_mem_of_ne (Ne.symm hne)
      rcases hdeg x hxV with h0 | h2
      · exfalso
        obtain ⟨c, hadj, -⟩ := (hx.symm.cases_head).resolve_left hne
        obtain ⟨e, hlink⟩ := hadj
        have heinc : e ∈ H.incidenceSet x := (H.mem_incidenceSet x e).2 hlink.inc_left
        have hfin : (H.incidenceSet x).Finite := hE.subset (H.incidenceSet_subset_edgeSet x)
        rw [hloop.degree_eq_ncard_incidenceSet, Set.ncard_eq_zero hfin] at h0
        rw [h0] at heinc
        exact absurd heinc (Set.notMem_empty e)
      · exact h2
  -- the incidence set of a component vertex is the same in C and in H
  have hincid : ∀ x ∈ {x | H.Reachable v x},
      (H.induce {x | H.Reachable v x}).incidenceSet x = H.incidenceSet x := by
    intro x hx
    simp only [Set.mem_setOf_eq] at hx
    ext e
    rw [Graph.mem_incidenceSet, Graph.mem_incidenceSet]
    constructor
    · intro hCe; exact hCe.mono hCle
    · intro hHe
      obtain ⟨y, hlink⟩ := hHe
      have hyX : H.Reachable v y := hx.tail hlink.adj
      exact ⟨y, by rw [Graph.induce_isLink]; exact ⟨hlink, hx, hyX⟩⟩
  refine Graph.IsCycle.mk hCle ?_ ?_
  · -- connectivity of the component
    refine Graph.connected_of_forall_reachable (x := v)
      (by rw [Graph.vertexSet_induce]; exact hvX) ?_
    intro y hy
    rw [Graph.vertexSet_induce] at hy
    simp only [Set.mem_setOf_eq] at hy
    induction hy with
    | refl => exact Graph.Reachable.rfl
    | tail hvb hby ih =>
      obtain ⟨e, hlink⟩ := hby
      have hCadj : (H.induce {x | H.Reachable v x}).Adj _ _ :=
        ⟨e, by rw [Graph.induce_isLink]; exact ⟨hlink, hvb, hvb.tail hlink.adj⟩⟩
      exact ih.tail hCadj
  · -- two-regularity of the component
    intro x hx
    rw [Graph.vertexSet_induce] at hx
    rw [hCloop.degree_eq_ncard_incidenceSet, hincid x hx,
      ← hloop.degree_eq_ncard_incidenceSet]
    exact hdeg2 x hx

/-- Strong induction on the number of edges: a finite loopless graph with all
degrees `0` or `2` decomposes into cycles. -/
private lemma decomp_aux (n : ℕ) : ∀ (K : Graph α β), E(K).ncard = n →
    V(K).Finite → E(K).Finite → K.IsLoopless →
    (∀ x ∈ V(K), K.degree x = 0 ∨ K.degree x = 2) →
    ∃ D : Multiset (Graph α β), (∀ C ∈ D, K.IsCycle C) ∧
      ∀ e ∈ E(K), D.edgeMultiplicity e = 1 := by
  induction n using Nat.strong_induction_on with
  | _ n ih =>
    intro K hn hVfin hEfin hloop hdeg
    rcases Set.eq_empty_or_nonempty E(K) with hEmpty | hNe
    · -- no edges: the empty decomposition works
      refine ⟨0, fun C hC => absurd hC (Multiset.notMem_zero C), fun e he => ?_⟩
      rw [hEmpty] at he; exact absurd he (Set.notMem_empty e)
    · -- pick an edge, peel off the cycle through one of its ends
      obtain ⟨e₀, he₀⟩ := hNe
      obtain ⟨x₀, y₀, hlink₀⟩ := Graph.exists_isLink_of_mem_edgeSet he₀
      have hx₀mem : x₀ ∈ V(K) := hlink₀.left_mem
      have hx₀deg2 : K.degree x₀ = 2 := by
        rcases hdeg x₀ hx₀mem with h0 | h2
        · exfalso
          have heinc : e₀ ∈ K.incidenceSet x₀ := (K.mem_incidenceSet x₀ e₀).2 hlink₀.inc_left
          have hfin : (K.incidenceSet x₀).Finite := hEfin.subset (K.incidenceSet_subset_edgeSet x₀)
          rw [hloop.degree_eq_ncard_incidenceSet, Set.ncard_eq_zero hfin] at h0
          rw [h0] at heinc; exact absurd heinc (Set.notMem_empty e₀)
        · exact h2
      set C₀ : Graph α β := K.induce {x | K.Reachable x₀ x} with hC₀def
      have hcyc₀ : K.IsCycle C₀ := fact_2_1b hVfin hEfin hloop hdeg hx₀mem hx₀deg2
      have hC₀le : C₀ ≤ K := hcyc₀.le
      have hC₀loop : C₀.IsLoopless := sub_loopless hloop hC₀le
      -- the peeled graph
      set K' : Graph α β := K.restrict (E(K) \ E(C₀)) with hK'def
      have hK'le : K' ≤ K := Graph.restrict_le
      have hloop' : K'.IsLoopless := restrict_loopless hloop _
      have hEH' : E(K') = E(K) \ E(C₀) := by
        rw [hK'def, Graph.edgeSet_restrict, Set.inter_eq_right.2 Set.diff_subset]
      have hVH' : V(K') = V(K) := by rw [hK'def, Graph.vertexSet_restrict]
      have hE'fin : E(K').Finite := by rw [hEH']; exact hEfin.diff
      -- degrees stay in {0,2} after peeling the cycle
      have hdeg' : ∀ x ∈ V(K'), K'.degree x = 0 ∨ K'.degree x = 2 := by
        intro x hx'
        rw [hVH'] at hx'
        have hHfin : (K.incidenceSet x).Finite := hEfin.subset (K.incidenceSet_subset_edgeSet x)
        have hinter : K.incidenceSet x ∩ E(C₀) = C₀.incidenceSet x :=
          incidenceSet_inter_edgeSet_of_le hC₀le x
        have hC₀sub : C₀.incidenceSet x ⊆ K.incidenceSet x := by
          rw [← hinter]; exact Set.inter_subset_left
        have hdiff_eq : K.incidenceSet x \ E(C₀) = K.incidenceSet x \ C₀.incidenceSet x := by
          rw [← hinter, Set.diff_self_inter]
        have h1 : K'.degree x = (K.incidenceSet x).ncard - (C₀.incidenceSet x).ncard := by
          rw [hloop'.degree_eq_ncard_incidenceSet, hK'def, restrict_diff_incidenceSet,
            hdiff_eq, Set.ncard_diff hC₀sub (hHfin.subset hC₀sub)]
        rw [← hloop.degree_eq_ncard_incidenceSet, ← hC₀loop.degree_eq_ncard_incidenceSet] at h1
        have hC₀val : C₀.degree x = 0 ∨ C₀.degree x = 2 := by
          by_cases hxC₀ : x ∈ V(C₀)
          · exact Or.inr (hcyc₀.isTwoRegular x hxC₀)
          · exact Or.inl (Graph.degree_eq_zero_of_notMem hxC₀)
        have hle : C₀.degree x ≤ K.degree x := by
          rw [hloop.degree_eq_ncard_incidenceSet, hC₀loop.degree_eq_ncard_incidenceSet]
          exact Set.ncard_le_ncard hC₀sub hHfin
        rcases hdeg x hx' with hh | hh <;> rw [h1] <;> omega
      -- fewer edges, so induction applies
      have hlt : E(K').ncard < n := by
        rw [← hn, hEH']
        obtain ⟨e₁, he₁⟩ := hcyc₀.edgeSet_nonempty
        have he₁H : e₁ ∈ E(K) := Graph.IsSubgraph.edgeSet_mono hC₀le he₁
        refine Set.ncard_lt_ncard ⟨Set.diff_subset, ?_⟩ hEfin
        intro hsub; exact (hsub he₁H).2 he₁
      obtain ⟨D', hD'cyc, hD'cover⟩ :=
        ih (E(K').ncard) hlt K' rfl (by rw [hVH']; exact hVfin) hE'fin hloop' hdeg'
      refine ⟨C₀ ::ₘ D', ?_, ?_⟩
      · intro C hC
        rw [Multiset.mem_cons] at hC
        rcases hC with rfl | hC
        · exact hcyc₀
        · exact (hD'cyc C hC).mono hK'le
      · intro e he
        by_cases heC₀ : e ∈ E(C₀)
        · have hz : D'.edgeMultiplicity e = 0 := by
            rw [Multiset.edgeMultiplicity_eq_zero_iff]
            intro C hC heC
            have hmem : e ∈ E(K') := Graph.IsSubgraph.edgeSet_mono (hD'cyc C hC).le heC
            rw [hEH'] at hmem; exact hmem.2 heC₀
          rw [Multiset.edgeMultiplicity_cons_of_mem _ heC₀, hz]
        · rw [Multiset.edgeMultiplicity_cons_of_notMem _ heC₀]
          apply hD'cover
          rw [hEH']; exact ⟨he, heC₀⟩

theorem fact_2_1b_decomposition (hV : V(H).Finite) (hE : E(H).Finite)
    (hloop : H.IsLoopless) (hdeg : ∀ x ∈ V(H), H.degree x = 0 ∨ H.degree x = 2) :
    ∃ D : Multiset (Graph α β), (∀ C ∈ D, H.IsCycle C) ∧
      ∀ e ∈ E(H), D.edgeMultiplicity e = 1 :=
  decomp_aux (E(H).ncard) H rfl hV hE hloop hdeg

theorem fact_2_1c (hV : V(G).Finite) (hE : E(G).Finite)
    (hP : G.IsTwoElementAssignment P) (he : e ∈ E(G)) :
    {s : Gamma | e ∈ E(G.restrict {f | s ∈ P f})}.encard = 2 := by
  have hset : {s : Gamma | e ∈ E(G.restrict {f | s ∈ P f})} = P e := by
    ext s
    simp only [Set.mem_setOf_eq, Graph.edgeSet_restrict, Set.mem_inter_iff]
    exact ⟨fun h => h.2, fun h => ⟨he, h⟩⟩
  rw [hset]
  exact hP.encard_palette e he

theorem fact_2_1d (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (hP : G.IsTwoElementAssignment P)
    (D : Gamma → Multiset (Graph α β))
    (hcyc : ∀ s : Gamma, ∀ C ∈ D s, (G.restrict {f | s ∈ P f}).IsCycle C)
    (hcover : ∀ s : Gamma, ∀ e ∈ E(G.restrict {f | s ∈ P f}), (D s).edgeMultiplicity e = 1) :
    G.IsCycleDoubleCover (∑ s : Gamma, D s) := by
  classical
  refine ⟨fun C hC => ?_, fun e he => ?_⟩
  · -- every member of the sum is a cycle of some M_s, hence of G
    rw [Multiset.mem_sum] at hC
    obtain ⟨s, -, hCs⟩ := hC
    exact (hcyc s C hCs).mono Graph.restrict_le
  · -- multiplicity of e is 2
    rw [edgeMultiplicity_finsetSum]
    have hper : ∀ s : Gamma, (D s).edgeMultiplicity e =
        (if e ∈ E(G.restrict {f | s ∈ P f}) then (1 : ℕ) else 0) := by
      intro s
      by_cases hmem : e ∈ E(G.restrict {f | s ∈ P f})
      · rw [if_pos hmem]; exact hcover s e hmem
      · rw [if_neg hmem]
        rw [Multiset.edgeMultiplicity_eq_zero_iff]
        intro C hC heC
        exact hmem (Graph.IsSubgraph.edgeSet_mono (hcyc s C hC).le heC)
    simp_rw [hper]
    have hfc := fact_2_1c hV hE hP he
    obtain ⟨a, b, hab, hs⟩ := Set.encard_eq_two.1 hfc
    rw [Finset.sum_boole]
    have hfilter : (Finset.univ.filter (fun s => e ∈ E(G.restrict {f | s ∈ P f}))) = {a, b} := by
      ext s
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert,
        Finset.mem_singleton]
      have hmem : s ∈ {s : Gamma | e ∈ E(G.restrict {f | s ∈ P f})} ↔ s ∈ ({a, b} : Set Gamma) := by
        rw [hs]
      simpa only [Set.mem_setOf_eq, Set.mem_insert_iff, Set.mem_singleton_iff] using hmem
    rw [hfilter]
    simp [Finset.card_pair hab]

/-! ## Remark 2.1e -/

theorem remark_2_1e (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (c : β → Fin 3) (hc : G.IsProper3EdgeColouring c)
    (e₁ e₂ : Gamma) (h₁ : e₁ ≠ 0) (h₂ : e₂ ≠ 0) (h₁₂ : e₁ ≠ e₂) :
    G.IsTwoElementAssignment
      (fun e ↦ if c e = 0 then {0, e₁} else if c e = 1 then {0, e₂} else {e₁, e₂}) := by
  set Q : β → Set Gamma :=
    fun e ↦ if c e = 0 then {0, e₁} else if c e = 1 then {0, e₂} else {e₁, e₂} with hQ
  refine ⟨?_, ?_⟩
  · -- each palette has exactly two elements
    intro e he
    show (Q e).encard = 2
    rw [hQ]
    by_cases hc0 : c e = 0
    · simp only [hc0, if_pos]
      exact Set.encard_pair (Ne.symm h₁)
    · by_cases hc1 : c e = 1
      · simp only [hc0, hc1, if_true, if_false, reduceIte]
        exact Set.encard_pair (Ne.symm h₂)
      · simp only [hc0, hc1, if_false, reduceIte]
        exact Set.encard_pair h₁₂
  · -- condition (1)
    intro v hv s
    have hdeg3 : G.degree v = 3 := hcubic v hv
    obtain ⟨a, ha_inc, ha_c⟩ := hc.exists_inc_colour hloop hv hdeg3 0
    obtain ⟨b, hb_inc, hb_c⟩ := hc.exists_inc_colour hloop hv hdeg3 1
    obtain ⟨d, hd_inc, hd_c⟩ := hc.exists_inc_colour hloop hv hdeg3 2
    have hab : a ≠ b := by rintro rfl; rw [ha_c] at hb_c; exact absurd hb_c (by decide)
    have had : a ≠ d := by rintro rfl; rw [ha_c] at hd_c; exact absurd hd_c (by decide)
    have hbd : b ≠ d := by rintro rfl; rw [hb_c] at hd_c; exact absurd hd_c (by decide)
    -- the three edges are exactly the incidence set
    have hincid_card : (G.incidenceSet v).ncard = 3 := by
      rw [← hloop.degree_eq_ncard_incidenceSet v, hdeg3]
    have hsub : ({a, b, d} : Set β) ⊆ G.incidenceSet v := by
      rw [Set.insert_subset_iff, Set.insert_subset_iff, Set.singleton_subset_iff]
      exact ⟨(G.mem_incidenceSet v a).2 ha_inc, (G.mem_incidenceSet v b).2 hb_inc,
        (G.mem_incidenceSet v d).2 hd_inc⟩
    have htriple_card : ({a, b, d} : Set β).ncard = 3 := by
      rw [Set.ncard_eq_three]; exact ⟨a, b, d, hab, had, hbd, rfl⟩
    have hincid_eq : G.incidenceSet v = ({a, b, d} : Set β) := by
      refine (Set.eq_of_subset_of_ncard_le hsub ?_
        (hE.subset (G.incidenceSet_subset_edgeSet v))).symm
      rw [hincid_card, htriple_card]
    -- palette values on the three edges
    have hPa : Q a = ({0, e₁} : Set Gamma) := by rw [hQ]; simp [ha_c]
    have hPb : Q b = ({0, e₂} : Set Gamma) := by rw [hQ]; simp [hb_c]
    have hPd : Q d = ({e₁, e₂} : Set Gamma) := by rw [hQ]; simp [hd_c]
    -- the palette-incidence set as a subset of {a,b,d}
    have hpalinc : G.paletteIncidenceSet Q v s = {x ∈ ({a, b, d} : Set β) | s ∈ Q x} := by
      ext x
      simp only [Graph.mem_paletteIncidenceSet, Set.mem_sep_iff]
      constructor
      · rintro ⟨hinc, hsx⟩
        have hx : x ∈ G.incidenceSet v := (G.mem_incidenceSet v x).2 hinc
        rw [hincid_eq] at hx
        exact ⟨hx, hsx⟩
      · rintro ⟨hx, hsx⟩
        have hx' : x ∈ G.incidenceSet v := by rw [hincid_eq]; exact hx
        exact ⟨(G.mem_incidenceSet v x).1 hx', hsx⟩
    rw [hpalinc]
    -- case analysis on which of 0, e₁, e₂ equals s
    by_cases hs0 : s = 0
    · have hset : {x ∈ ({a, b, d} : Set β) | s ∈ Q x} = ({a, b} : Set β) := by
        ext x
        simp only [Set.mem_sep_iff, Set.mem_insert_iff, Set.mem_singleton_iff]
        constructor
        · rintro ⟨hx, hsx⟩
          rcases hx with h | h | h
          · exact Or.inl h
          · exact Or.inr h
          · exfalso
            rw [h, hPd, hs0] at hsx
            simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hsx
            rcases hsx with hh | hh
            · exact h₁ hh.symm
            · exact h₂ hh.symm
        · rintro (h | h)
          · exact ⟨Or.inl h, by rw [h, hPa, hs0]; exact Set.mem_insert _ _⟩
          · exact ⟨Or.inr (Or.inl h), by rw [h, hPb, hs0]; exact Set.mem_insert _ _⟩
      rw [hset, Set.encard_pair hab]; exact Or.inr rfl
    · by_cases hse1 : s = e₁
      · have hset : {x ∈ ({a, b, d} : Set β) | s ∈ Q x} = ({a, d} : Set β) := by
          ext x
          simp only [Set.mem_sep_iff, Set.mem_insert_iff, Set.mem_singleton_iff]
          constructor
          · rintro ⟨hx, hsx⟩
            rcases hx with h | h | h
            · exact Or.inl h
            · exfalso
              rw [h, hPb, hse1] at hsx
              simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hsx
              rcases hsx with hh | hh
              · exact h₁ hh
              · exact h₁₂ hh
            · exact Or.inr h
          · rintro (h | h)
            · exact ⟨Or.inl h, by rw [h, hPa, hse1]; exact Set.mem_insert_of_mem _ rfl⟩
            · exact ⟨Or.inr (Or.inr h), by rw [h, hPd, hse1]; exact Set.mem_insert _ _⟩
        rw [hset, Set.encard_pair had]; exact Or.inr rfl
      · by_cases hse2 : s = e₂
        · have hset : {x ∈ ({a, b, d} : Set β) | s ∈ Q x} = ({b, d} : Set β) := by
            ext x
            simp only [Set.mem_sep_iff, Set.mem_insert_iff, Set.mem_singleton_iff]
            constructor
            · rintro ⟨hx, hsx⟩
              rcases hx with h | h | h
              · exfalso
                rw [h, hPa, hse2] at hsx
                simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hsx
                rcases hsx with hh | hh
                · exact h₂ hh
                · exact h₁₂ hh.symm
              · exact Or.inl h
              · exact Or.inr h
            · rintro (h | h)
              · exact ⟨Or.inr (Or.inl h), by rw [h, hPb, hse2]; exact Set.mem_insert_of_mem _ rfl⟩
              · exact ⟨Or.inr (Or.inr h), by rw [h, hPd, hse2]; exact Set.mem_insert_of_mem _ rfl⟩
          rw [hset, Set.encard_pair hbd]; exact Or.inr rfl
        · -- s ∉ {0, e₁, e₂}: the set is empty
          have hset : {x ∈ ({a, b, d} : Set β) | s ∈ Q x} = (∅ : Set β) := by
            ext x
            simp only [Set.mem_sep_iff, Set.mem_empty_iff_false, iff_false]
            rintro ⟨hx, hsx⟩
            rcases hx with h | h | h
            · rw [h, hPa] at hsx
              simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hsx
              rcases hsx with hh | hh
              · exact hs0 hh
              · exact hse1 hh
            · rw [h, hPb] at hsx
              simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hsx
              rcases hsx with hh | hh
              · exact hs0 hh
              · exact hse2 hh
            · rw [h, hPd] at hsx
              simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hsx
              rcases hsx with hh | hh
              · exact hse1 hh
              · exact hse2 hh
          rw [hset, Set.encard_empty]; exact Or.inl rfl

/-! ## Lemma 2.1 -/

theorem lemma_2_1 (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (hP : G.IsTwoElementAssignment P) :
    G.HasCycleDoubleCover := by
  have hdeg : ∀ s : Gamma, ∀ x ∈ V(G.restrict {f | s ∈ P f}),
      (G.restrict {f | s ∈ P f}).degree x = 0 ∨ (G.restrict {f | s ∈ P f}).degree x = 2 := by
    have hkey := (fact_2_1a hV hE hloop P).1 hP.encard_paletteIncidenceSet
    intro s x hx
    rw [Graph.vertexSet_restrict] at hx
    exact hkey s x hx
  have hdecomp : ∀ s : Gamma, ∃ D : Multiset (Graph α β),
      (∀ C ∈ D, (G.restrict {f | s ∈ P f}).IsCycle C) ∧
        ∀ e ∈ E(G.restrict {f | s ∈ P f}), D.edgeMultiplicity e = 1 := by
    intro s
    have hVs : V(G.restrict {f | s ∈ P f}).Finite := by
      rw [Graph.vertexSet_restrict]; exact hV
    have hEs : E(G.restrict {f | s ∈ P f}).Finite := by
      rw [Graph.edgeSet_restrict]; exact hE.subset Set.inter_subset_left
    exact fact_2_1b_decomposition hVs hEs (restrict_loopless hloop _) (hdeg s)
  choose D hD using hdecomp
  exact ⟨∑ s : Gamma, D s, fact_2_1d hV hE hloop hcubic hP D (fun s => (hD s).1)
    (fun s => (hD s).2)⟩

end Workspace.Facts.Lemma21

/-!
# Characteristic-two flows (§2) and the construction of the sets `P_e` (§5)

The facts of *"A Proof of the Cycle Double Cover Conjecture"* living in §2 (flows over
`Γ = 𝔽₂³`) and §5 (the construction of the palettes `P_e`).

For §2, being a `Γ`-flow is equivalent to the vanishing, at each vertex `v`, of the sum of
`f(e)` over the edge-*ends* at `v` — a loop counts twice, written literally as the scalar
`(if G.IsLoopAt e v then (2 : ℕ) else 1) • f e`, so the `if` is load-bearing. At a loopless
cubic vertex with incident edges `a, b, c` this reads `f(a) + f(b) + f(c) = 0`.

For §5 (`G` loopless cubic, `f` a nowhere-zero `Γ`-flow), the paper's local data — the
ordering `a, b, c` at each vertex, the shift `g_{v,e}` of (2), and `d_e = g_{u,e} + g_{v,e}` —
is packaged by `LocalShift G`, with derived `S.g` and `S.d`; `x, y, z` are the flow values at
`S.ord.edge v 0/1/2`. The local set of (3) at `(v, e, t)` is `{t + g_{v,e}, t + g_{v,e} + f(e)}`,
spelled out inline everywhere below.

Every statement about a graph carries both `V(G).Finite` and `E(G).Finite`, both load-bearing
on this file's `finsum`/`ncard`-based definitions (`fact_5b` is pure `𝔽₂` linear algebra and
carries neither).
-/

open Set

open scoped Graph

open Workspace.Types.Gamma
open Workspace.Types.Orientation
open Workspace.Types.LocalOrdering
open Workspace.Types.LocalShift

namespace Workspace.Facts.Construction

variable {α β : Type*} {G : Graph α β} {e : β} {u v : α}

/-- From `t = t + w` in an additive cancellative monoid, `w = 0`. -/
private lemma add_right_eq_zero_of_self_eq {t w : Gamma} (h : t = t + w) : w = 0 := by
  have hh : t + w = t + 0 := by rw [add_zero]; exact h.symm
  exact add_left_cancel hh

/-- **Characteristic two.** In `Γ`, `A = B` iff `A + B = 0` (since `B + B = 0`). -/
private lemma gamma_eq_iff_add_eq_zero (A B : Gamma) : A = B ↔ A + B = 0 := by
  constructor
  · rintro rfl; exact Gamma.add_self A
  · intro h
    have hh : A + B + B = B := by rw [h, zero_add]
    rwa [add_assoc, Gamma.add_self, add_zero] at hh

/-! ## §2 — the characteristic-two facts -/

open Classical in
/-- **The characteristic-two fact (§2).** *Because `Γ` has characteristic two,
`f : E(G) → Γ` is a `Γ`-flow with respect to some (equivalently, every) orientation of
`G` if and only if for every vertex `v` the sum of `f(e)` over all edge-ends at `v` is
`0`.*

This is the "some" half together with the orientation-free reformulation: for the
given orientation `O`, being a flow is equivalent to a condition in which `O` does not
appear. The right-hand sum ranges over the edge-**ends** at `v`, so a loop at `v`
contributes `2 • f e = f e + f e`, which is `0` in characteristic two, and a non-loop
edge incident to `v` contributes `1 • f e = f e`. -/
theorem gamma_flow_iff_endSum_zero (hV : V(G).Finite) (hE : E(G).Finite)
    (O : Orientation G) (f : β → Gamma) :
    G.IsFlow O f ↔
      ∀ v ∈ V(G),
        (∑ᶠ e ∈ G.incidenceSet v, (if G.IsLoopAt e v then (2 : ℕ) else 1) • f e) = 0 := by
  classical
  rw [Graph.isFlow_iff_finset_sum hE]
  refine forall_congr' (fun v => ?_)
  refine imp_congr_right (fun hv => ?_)
  set s := hE.toFinset with hs
  have hset : G.incidenceSet v = (↑(s.filter (fun e => G.Inc e v)) : Set β) := by
    ext e
    simp only [Graph.mem_incidenceSet, Finset.coe_filter, Set.mem_setOf_eq,
      Set.Finite.mem_toFinset, hs]
    exact ⟨fun h => ⟨h.edge_mem, h⟩, fun h => h.2⟩
  rw [hset, finsum_mem_coe_finset]
  have key : (∑ e ∈ s.filter (fun e => G.Inc e v),
        (if G.IsLoopAt e v then (2 : ℕ) else 1) • f e)
      = (∑ e ∈ s.filter (fun e => O.tail e = v), f e)
        + (∑ e ∈ s.filter (fun e => O.head e = v), f e) := by
    rw [Finset.sum_filter, Finset.sum_filter, Finset.sum_filter, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun e he => ?_)
    have heE : e ∈ E(G) := by rw [hs, Set.Finite.mem_toFinset] at he; exact he
    have hinc : G.Inc e v ↔ O.tail e = v ∨ O.head e = v := by
      rw [O.inc_iff heE]; exact or_congr eq_comm eq_comm
    have hloop : G.IsLoopAt e v ↔ O.tail e = v ∧ O.head e = v := by
      constructor
      · intro h; exact ⟨O.tail_eq_of_isLoopAt h, O.head_eq_of_isLoopAt h⟩
      · rintro ⟨h1, h2⟩
        have hlink := O.isLink_tail_head heE
        rw [h1, h2] at hlink
        exact hlink
    by_cases h1 : O.tail e = v <;> by_cases h2 : O.head e = v <;>
      simp [hinc, hloop, h1, h2, two_nsmul, one_nsmul, two_mul]
  rw [key, gamma_eq_iff_add_eq_zero]

/-- **The "some ⟺ every" half of the §2 fact.** *`f` is a `Γ`-flow with respect to
some (equivalently, every) orientation of `G`.*

Since the orientation-free condition of `gamma_flow_iff_endSum_zero` does not mention
the orientation, being a `Γ`-flow does not depend on which orientation is chosen. -/
theorem gamma_flow_orientation_independent (hV : V(G).Finite) (hE : E(G).Finite)
    (O O' : Orientation G) (f : β → Gamma) (hf : G.IsFlow O f) : G.IsFlow O' f := by
  exact (gamma_flow_iff_endSum_zero hV hE O' f).mpr
    ((gamma_flow_iff_endSum_zero hV hE O f).mp hf)

/-- **The loopless cubic specialisation (§2).** *At a vertex `v` of a loopless cubic
graph whose three incident edges are `a, b, c`, the flow condition reads
`f(a) + f(b) + f(c) = 0`.*

The three edges `a, b, c` at `v` are `ord.edge v 0`, `ord.edge v 1`, `ord.edge v 2`
for a local ordering `ord`, whose axioms say exactly that they enumerate
`G.incidenceSet v` without repetition. -/
theorem cubic_flow_eq (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (f : β → Gamma) (hf : G.IsFlow O f)
    (ord : LocalOrdering G) (hv : v ∈ V(G)) :
    f (ord.edge v 0) + f (ord.edge v 1) + f (ord.edge v 2) = 0 := by
  classical
  have h := (gamma_flow_iff_endSum_zero hV hE O f).mp hf v hv
  have hsum : (∑ᶠ e ∈ G.incidenceSet v, (if G.IsLoopAt e v then (2 : ℕ) else 1) • f e)
      = ∑ᶠ e ∈ G.incidenceSet v, f e := by
    refine finsum_mem_congr rfl (fun e _ => ?_)
    rw [if_neg (hloop e v), one_nsmul]
  rw [hsum] at h
  have htriple : G.incidenceSet v = {ord.edge v 0, ord.edge v 1, ord.edge v 2} := by
    rw [← ord.range_edge hv]
    ext x
    simp only [Set.mem_range, Set.mem_insert_iff, Set.mem_singleton_iff]
    constructor
    · rintro ⟨i, rfl⟩; fin_cases i <;> simp
    · rintro (rfl | rfl | rfl); exacts [⟨0, rfl⟩, ⟨1, rfl⟩, ⟨2, rfl⟩]
  have h01 : ord.edge v 0 ≠ ord.edge v 1 := ord.edge_ne_edge hv (by decide)
  have h02 : ord.edge v 0 ≠ ord.edge v 2 := ord.edge_ne_edge hv (by decide)
  have h12 : ord.edge v 1 ≠ ord.edge v 2 := ord.edge_ne_edge hv (by decide)
  have hcoe : ({ord.edge v 0, ord.edge v 1, ord.edge v 2} : Set β)
      = (↑({ord.edge v 0, ord.edge v 1, ord.edge v 2} : Finset β) : Set β) := by simp
  rw [htriple, hcoe, finsum_mem_coe_finset, Finset.sum_insert (by simp [h01, h02]),
    Finset.sum_insert (by simp [h12]), Finset.sum_singleton] at h
  rw [← add_assoc] at h
  exact h

/-- **The local notation of §5.** *Write `x = f(a)`, `y = f(b)`, `z = f(c)`. By the
characteristic-two flow equation, `x + y + z = 0`, so `z = x + y`; moreover `x, y, z`
are all nonzero and `x ≠ y`.*

Here `f` is a **nowhere-zero** `Γ`-flow, which is what makes `x`, `y` and `z` nonzero;
`x ≠ y` then follows because `x + y = z ≠ 0`. -/
theorem cubic_flow_distinct (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (f : β → Gamma) (hf : G.IsFlow O f)
    (hnz : G.IsNowhereZero f) (ord : LocalOrdering G) (hv : v ∈ V(G)) :
    f (ord.edge v 2) = f (ord.edge v 0) + f (ord.edge v 1) ∧
      f (ord.edge v 0) ≠ 0 ∧ f (ord.edge v 1) ≠ 0 ∧ f (ord.edge v 2) ≠ 0 ∧
      f (ord.edge v 0) ≠ f (ord.edge v 1) := by
  have heq := cubic_flow_eq hV hE hloop hcubic O f hf ord hv
  have hc : f (ord.edge v 2) = f (ord.edge v 0) + f (ord.edge v 1) := by
    rw [gamma_eq_iff_add_eq_zero]
    calc f (ord.edge v 2) + (f (ord.edge v 0) + f (ord.edge v 1))
        = f (ord.edge v 0) + f (ord.edge v 1) + f (ord.edge v 2) := by abel
      _ = 0 := heq
  have ha : f (ord.edge v 0) ≠ 0 := hnz _ (ord.edge_mem_edgeSet hv 0)
  have hb : f (ord.edge v 1) ≠ 0 := hnz _ (ord.edge_mem_edgeSet hv 1)
  have hcz : f (ord.edge v 2) ≠ 0 := hnz _ (ord.edge_mem_edgeSet hv 2)
  have hab : f (ord.edge v 0) ≠ f (ord.edge v 1) := by
    intro hcon
    apply hcz
    rw [hc, hcon, Gamma.add_self]
  exact ⟨hc, ha, hb, hcz, hab⟩

/-! ## §5 — Facts 5a–5d -/

/-- **Fact 5a, part (i): the local computation.** *With the notation above, the three
sets in (3) are `{t, t+x}`, `{t+x, t+z}`, and `{t, t+z}`.*

The three sets of (3) at `v` are `{t + g_{v,e}, t + g_{v,e} + f(e)}` for
`e = a, b, c`, i.e. for `e = S.ord.edge v i` with `i = 0, 1, 2`; and
`x = S.flow (S.ord.edge v 0)`, `z = S.flow (S.ord.edge v 2)`. The computation uses
equation (2) (`g_{v,a} = 0`, `g_{v,b} = x`, `g_{v,c} = 0`) and the flow relation
`z = x + y`. -/
theorem fact_5a (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (hv : v ∈ V(G)) (t : Gamma) :
    (({t + S.g v (S.ord.edge v 0), t + S.g v (S.ord.edge v 0) + S.flow (S.ord.edge v 0)}
        : Set Gamma) = {t, t + S.flow (S.ord.edge v 0)}) ∧
    (({t + S.g v (S.ord.edge v 1), t + S.g v (S.ord.edge v 1) + S.flow (S.ord.edge v 1)}
        : Set Gamma) = {t + S.flow (S.ord.edge v 0), t + S.flow (S.ord.edge v 2)}) ∧
    (({t + S.g v (S.ord.edge v 2), t + S.g v (S.ord.edge v 2) + S.flow (S.ord.edge v 2)}
        : Set Gamma) = {t, t + S.flow (S.ord.edge v 2)}) := by
  obtain ⟨hc, _, _, _, _⟩ :=
    cubic_flow_distinct hV hE hloop hcubic O S.flow hf hnz S.ord hv
  refine ⟨?_, ?_, ?_⟩
  · rw [S.g_edge_zero hv]; simp
  · rw [S.g_edge_one v, hc, add_assoc]
  · rw [S.g_edge_two hv]; simp

/-- **Fact 5a, part (ii): every vector occurs in zero or two of the local sets.**
*Hence every vector of `Γ` occurs in zero or two of them.*

The count is over the edges `e` incident to `v` — there are exactly three of them, and
they are the paper's `a, b, c` — whose local set `{t + g_{v,e}, t + g_{v,e} + f(e)}`
contains the given vector `s`. `Set.encard` is used so that the count means what it
says with no finiteness side condition. This is condition (1) of Lemma 2.1, locally. -/
theorem fact_5a_zero_or_two (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (hv : v ∈ V(G)) (t : Gamma) (s : Gamma) :
    {e ∈ G.incidenceSet v | s ∈ ({t + S.g v e, t + S.g v e + S.flow e} : Set Gamma)}.encard
      ∈ ({0, 2} : Set ℕ∞) := by
  classical
  obtain ⟨ha1, hb1, hc1⟩ := fact_5a hV hE hloop hcubic O S hf hnz hv t
  obtain ⟨hc, hx0, hy0, hz0, hxy⟩ :=
    cubic_flow_distinct hV hE hloop hcubic O S.flow hf hnz S.ord hv
  set a := S.ord.edge v 0 with ha_def
  set b := S.ord.edge v 1 with hb_def
  set c := S.ord.edge v 2 with hc_def
  have hab : a ≠ b := S.ord.edge_ne_edge hv (by decide)
  have hac : a ≠ c := S.ord.edge_ne_edge hv (by decide)
  have hbc : b ≠ c := S.ord.edge_ne_edge hv (by decide)
  have hne01 : (t : Gamma) ≠ t + S.flow a := fun h => hx0 (add_right_eq_zero_of_self_eq h)
  have hne02 : (t : Gamma) ≠ t + S.flow c := fun h => hz0 (add_right_eq_zero_of_self_eq h)
  have hne12 : t + S.flow a ≠ t + S.flow c := by
    intro h
    apply hy0
    have h' : S.flow a = S.flow c := add_left_cancel h
    exact add_right_eq_zero_of_self_eq (h'.trans hc)
  have htriple : G.incidenceSet v = ({a, b, c} : Set β) := by
    rw [← S.ord.range_edge hv]
    ext x
    simp only [Set.mem_range, Set.mem_insert_iff, Set.mem_singleton_iff]
    constructor
    · rintro ⟨i, rfl⟩; fin_cases i <;> simp [ha_def, hb_def, hc_def]
    · rintro (rfl | rfl | rfl)
      exacts [⟨0, ha_def.symm⟩, ⟨1, hb_def.symm⟩, ⟨2, hc_def.symm⟩]
  have hFmem : ∀ e, (e ∈ {e ∈ G.incidenceSet v |
        s ∈ ({t + S.g v e, t + S.g v e + S.flow e} : Set Gamma)}) ↔
      (e = a ∧ (s = t ∨ s = t + S.flow a))
        ∨ (e = b ∧ (s = t + S.flow a ∨ s = t + S.flow c))
        ∨ (e = c ∧ (s = t ∨ s = t + S.flow c)) := by
    intro e
    rw [Set.mem_sep_iff]
    constructor
    · rintro ⟨hmem, hs⟩
      rw [htriple] at hmem
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hmem
      rcases hmem with rfl | rfl | rfl
      · exact Or.inl ⟨rfl, by rw [ha1] at hs; simpa using hs⟩
      · exact Or.inr (Or.inl ⟨rfl, by rw [hb1] at hs; simpa using hs⟩)
      · exact Or.inr (Or.inr ⟨rfl, by rw [hc1] at hs; simpa using hs⟩)
    · rintro (⟨rfl, hs⟩ | ⟨rfl, hs⟩ | ⟨rfl, hs⟩)
      · exact ⟨by rw [htriple]; simp, by rw [ha1]; simpa using hs⟩
      · exact ⟨by rw [htriple]; simp, by rw [hb1]; simpa using hs⟩
      · exact ⟨by rw [htriple]; simp, by rw [hc1]; simpa using hs⟩
  by_cases hs0 : s = t
  · have hn1 : ¬ s = t + S.flow a := by intro h; rw [hs0] at h; exact hne01 h
    have hn2 : ¬ s = t + S.flow c := by intro h; rw [hs0] at h; exact hne02 h
    have hFeq : {e ∈ G.incidenceSet v |
        s ∈ ({t + S.g v e, t + S.g v e + S.flow e} : Set Gamma)} = ({a, c} : Set β) := by
      ext e; rw [hFmem e]
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff]
      constructor
      · rintro (⟨rfl, _⟩ | ⟨rfl, hor⟩ | ⟨rfl, _⟩)
        · exact Or.inl rfl
        · rcases hor with h | h; exacts [absurd h hn1, absurd h hn2]
        · exact Or.inr rfl
      · rintro (rfl | rfl)
        · exact Or.inl ⟨rfl, Or.inl hs0⟩
        · exact Or.inr (Or.inr ⟨rfl, Or.inl hs0⟩)
    rw [hFeq, Set.encard_pair hac]; simp
  · by_cases hs1 : s = t + S.flow a
    · have hn2 : ¬ s = t + S.flow c := by intro h; rw [hs1] at h; exact hne12 h
      have hFeq : {e ∈ G.incidenceSet v |
          s ∈ ({t + S.g v e, t + S.g v e + S.flow e} : Set Gamma)} = ({a, b} : Set β) := by
        ext e; rw [hFmem e]
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff]
        constructor
        · rintro (⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, hor⟩)
          · exact Or.inl rfl
          · exact Or.inr rfl
          · rcases hor with h | h; exacts [absurd h hs0, absurd h hn2]
        · rintro (rfl | rfl)
          · exact Or.inl ⟨rfl, Or.inr hs1⟩
          · exact Or.inr (Or.inl ⟨rfl, Or.inl hs1⟩)
      rw [hFeq, Set.encard_pair hab]; simp
    · by_cases hs2 : s = t + S.flow c
      · have hFeq : {e ∈ G.incidenceSet v |
            s ∈ ({t + S.g v e, t + S.g v e + S.flow e} : Set Gamma)} = ({b, c} : Set β) := by
          ext e; rw [hFmem e]
          simp only [Set.mem_insert_iff, Set.mem_singleton_iff]
          constructor
          · rintro (⟨rfl, hor⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩)
            · rcases hor with h | h; exacts [absurd h hs0, absurd h hs1]
            · exact Or.inl rfl
            · exact Or.inr rfl
          · rintro (rfl | rfl)
            · exact Or.inr (Or.inl ⟨rfl, Or.inr hs2⟩)
            · exact Or.inr (Or.inr ⟨rfl, Or.inr hs2⟩)
        rw [hFeq, Set.encard_pair hbc]; simp
      · have hFeq : {e ∈ G.incidenceSet v |
            s ∈ ({t + S.g v e, t + S.g v e + S.flow e} : Set Gamma)} = (∅ : Set β) := by
          ext e; rw [hFmem e]
          simp only [Set.mem_empty_iff_false, iff_false]
          rintro (⟨rfl, hor⟩ | ⟨rfl, hor⟩ | ⟨rfl, hor⟩)
          · rcases hor with h | h; exacts [hs0 h, hs1 h]
          · rcases hor with h | h; exacts [hs1 h, hs2 h]
          · rcases hor with h | h; exacts [hs0 h, hs2 h]
        rw [hFeq, Set.encard_empty]; simp

/-- **Fact 5b (agreement criterion).** *For any `p ∈ Γ`, `{A, A+p} = {B, B+p}`
precisely when `A + B ∈ {0, p}`.*

Pure `𝔽₂` linear algebra: no graph is involved, hence no finiteness hypothesis. -/
theorem fact_5b (A B p : Gamma) :
    ({A, A + p} : Set Gamma) = {B, B + p} ↔ A + B ∈ ({0, p} : Set Gamma) := by
  rw [Set.pair_eq_pair_iff]
  simp only [Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · rintro (⟨h1, _⟩ | ⟨h1, _⟩)
    · left; rw [h1]; exact Gamma.add_self B
    · right; rw [h1, add_comm B p, add_assoc, Gamma.add_self, add_zero]
  · rintro (h | h)
    · have hAB : A = B := (gamma_eq_iff_add_eq_zero A B).mpr h
      exact Or.inl ⟨hAB, by rw [hAB]⟩
    · have hA : A = B + p := by
        rw [gamma_eq_iff_add_eq_zero, ← add_assoc, h, Gamma.add_self]
      exact Or.inr ⟨hA, by rw [hA, add_assoc, Gamma.add_self, add_zero]⟩

/-- **Fact 5c (the system (4)).** *The local sets in (3) agree across every edge
precisely when there are `t_v ∈ Γ` and `ε_e ∈ 𝔽₂` satisfying
`t_u + t_v + ε_e f(e) = d_e` (`e = uv`).*

"The local sets agree across every edge" means: there is a family `t : V(G) → Γ` such
that for every edge `e` with ends `u` and `v`, the local set of (3) computed at `u`
equals the one computed at `v`. Obtained from Fact 5b with `A = t_u + g_{u,e}`,
`B = t_v + g_{v,e}`, `p = f(e)`, using `A + B = t_u + t_v + d_e`, the bit `ε_e`
recording whether that vector is `0` or `f(e)`. -/
theorem fact_5c (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) :
    (∃ t : α → Gamma, ∀ e ∈ E(G), ∀ u v, G.IsLink e u v →
        ({t u + S.g u e, t u + S.g u e + S.flow e} : Set Gamma)
          = {t v + S.g v e, t v + S.g v e + S.flow e}) ↔
      (∃ (t : α → Gamma) (ε : β → F2), ∀ e ∈ E(G), ∀ u v, G.IsLink e u v →
        t u + t v + ε e • S.flow e = S.d e) := by
  classical
  have hbit : ∀ a : F2, a = 0 ∨ a = 1 := by decide
  refine exists_congr (fun t => ?_)
  constructor
  · -- forward: sets agree ⟹ choose the bits ε
    intro hP
    have hex : ∀ e, ∃ w : F2, e ∈ E(G) → ∀ u v, G.IsLink e u v →
        t u + t v + w • S.flow e = S.d e := by
      intro e
      by_cases he : e ∈ E(G)
      · obtain ⟨u0, v0, hl0⟩ := G.exists_isLink_of_mem_edgeSet he
        have huv0 : u0 ≠ v0 := Graph.isLoopless_iff_forall_isLink_ne.mp hloop e u0 v0 hl0
        have hd0 : S.d e = S.g u0 e + S.g v0 e := S.d_eq_add hl0 huv0
        have hsets := hP e he u0 v0 hl0
        rw [fact_5b] at hsets
        have hABval : (t u0 + S.g u0 e) + (t v0 + S.g v0 e) = (t u0 + t v0) + S.d e := by
          rw [hd0]; abel
        rw [hABval] at hsets
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hsets
        rcases hsets with h | h
        · refine ⟨0, fun _ u v hl => ?_⟩
          have htt : t u + t v = t u0 + t v0 := by
            rcases hl.eq_and_eq_or_eq_and_eq hl0 with ⟨h1, h2⟩ | ⟨h1, h2⟩
            · rw [h1, h2]
            · rw [h1, h2]; abel
          rw [zero_smul, add_zero, htt]
          exact (gamma_eq_iff_add_eq_zero _ _).mpr h
        · refine ⟨1, fun _ u v hl => ?_⟩
          have htt : t u + t v = t u0 + t v0 := by
            rcases hl.eq_and_eq_or_eq_and_eq hl0 with ⟨h1, h2⟩ | ⟨h1, h2⟩
            · rw [h1, h2]
            · rw [h1, h2]; abel
          rw [one_smul, htt, ← h, ← add_assoc, Gamma.add_self, zero_add]
      · exact ⟨0, fun h => absurd h he⟩
    choose ε hε using hex
    exact ⟨ε, fun e he u v hl => hε e he u v hl⟩
  · -- reverse: a solution of (4) makes the sets agree
    rintro ⟨ε, hQ⟩ e he u v hl
    have huv : u ≠ v := Graph.isLoopless_iff_forall_isLink_ne.mp hloop e u v hl
    have hd : S.d e = S.g u e + S.g v e := S.d_eq_add hl huv
    have heq := hQ e he u v hl
    rw [fact_5b]
    have hAB : (t u + S.g u e) + (t v + S.g v e) = ε e • S.flow e := by
      have hstep : (t u + S.g u e) + (t v + S.g v e) = (t u + t v) + S.d e := by rw [hd]; abel
      rw [hstep, ← heq, ← add_assoc, Gamma.add_self, zero_add]
    rw [hAB]
    rcases hbit (ε e) with h0 | h1
    · rw [h0, zero_smul]; simp
    · rw [h1, one_smul]; simp

/-- **Fact 5d (assembly).** *Given a solution `(t, ε)` of (4), define
`P_e = {t_v + g_{v,e}, t_v + g_{v,e} + f(e)}` using either endpoint `v` of `e`. Then
(4) makes this definition independent of the chosen endpoint; `f(e) ≠ 0` makes the two
elements distinct, so `|P_e| = 2`; and Fact 5a gives condition (1).*

The conclusion has two parts: **(a)** endpoint-independence of the recipe, and **(b)** that any
`P` defined edgewise by it is a two-element assignment in the sense of Lemma 2.1 (`|P_e| = 2`
because `f(e) ≠ 0`, and condition (1) by Fact 5a). Values of `P` off `E(G)` are unconstrained,
as `Graph.IsTwoElementAssignment` never inspects them. -/
theorem fact_5d (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (t : α → Gamma) (ε : β → F2)
    (h4 : ∀ e ∈ E(G), ∀ u v, G.IsLink e u v → t u + t v + ε e • S.flow e = S.d e) :
    (∀ e ∈ E(G), ∀ u v, G.Inc e u → G.Inc e v →
        ({t u + S.g u e, t u + S.g u e + S.flow e} : Set Gamma)
          = {t v + S.g v e, t v + S.g v e + S.flow e}) ∧
      (∀ P : β → Set Gamma,
        (∀ e ∈ E(G), ∃ v, G.Inc e v ∧ P e = {t v + S.g v e, t v + S.g v e + S.flow e}) →
        G.IsTwoElementAssignment P) := by
  classical
  have hbit : ∀ a : F2, a = 0 ∨ a = 1 := by decide
  -- The local set of (3) read at either end of an edge agree, by (4) and Fact 5b.
  have palette_agree : ∀ e ∈ E(G), ∀ u w, G.IsLink e u w →
      ({t u + S.g u e, t u + S.g u e + S.flow e} : Set Gamma)
        = {t w + S.g w e, t w + S.g w e + S.flow e} := by
    intro e he u w hl
    have huw : u ≠ w := Graph.isLoopless_iff_forall_isLink_ne.mp hloop e u w hl
    have hd : S.d e = S.g u e + S.g w e := S.d_eq_add hl huw
    have heq := h4 e he u w hl
    rw [fact_5b]
    have hAB : (t u + S.g u e) + (t w + S.g w e) = ε e • S.flow e := by
      have hstep : (t u + S.g u e) + (t w + S.g w e) = (t u + t w) + S.d e := by rw [hd]; abel
      rw [hstep, ← heq, ← add_assoc, Gamma.add_self, zero_add]
    rw [hAB]
    rcases hbit (ε e) with h0 | h1
    · rw [h0, zero_smul]; simp
    · rw [h1, one_smul]; simp
  -- endpoint independence
  have hindep : ∀ e ∈ E(G), ∀ u v, G.Inc e u → G.Inc e v →
      ({t u + S.g u e, t u + S.g u e + S.flow e} : Set Gamma)
        = {t v + S.g v e, t v + S.g v e + S.flow e} := by
    intro e he u v hu hv
    obtain ⟨y, hlyu⟩ := hu
    rcases hv.eq_or_eq_of_isLink hlyu with rfl | rfl
    · rfl
    · exact palette_agree e he u v hlyu
  refine ⟨hindep, ?_⟩
  intro P hP
  constructor
  · -- every palette has exactly two elements, since `f e ≠ 0`
    intro e he
    obtain ⟨w, hw, hPe⟩ := hP e he
    rw [hPe]
    have hfe : S.flow e ≠ 0 := hnz e he
    have hne : t w + S.g w e ≠ t w + S.g w e + S.flow e := by
      intro hcontra
      exact hfe (add_right_eq_zero_of_self_eq hcontra)
    exact Set.encard_pair hne
  · -- condition (1), by Fact 5a
    intro v hv s
    have hsetPeq : G.paletteIncidenceSet P v s
        = {e ∈ G.incidenceSet v |
            s ∈ ({t v + S.g v e, t v + S.g v e + S.flow e} : Set Gamma)} := by
      ext e
      simp only [Graph.mem_paletteIncidenceSet, Set.mem_sep_iff, Graph.mem_incidenceSet]
      constructor
      · rintro ⟨hinc, hs⟩
        obtain ⟨w, hw, hPe⟩ := hP e hinc.edge_mem
        rw [hPe] at hs
        exact ⟨hinc, by rwa [hindep e hinc.edge_mem w v hw hinc] at hs⟩
      · rintro ⟨hinc, hs⟩
        obtain ⟨w, hw, hPe⟩ := hP e hinc.edge_mem
        refine ⟨hinc, ?_⟩
        rw [hPe]
        rwa [hindep e hinc.edge_mem w v hw hinc]
    rw [hsetPeq]
    exact fact_5a_zero_or_two hV hE hloop hcubic O S hf hnz hv (t v) s

end Workspace.Facts.Construction

/-!
# §6 — the proof of Lemma 2.2: duality, condition (5), and the double count

This file states, one theorem per paper sentence, the facts 6a–6j of *"A Proof of the Cycle
Double Cover Conjecture"*, together with the headline `Lemma 2.2` they establish: the system
(4) has a solution.

The paper's linear map `L : Γ^{V(G)} ⊕ 𝔽₂^{E(G)} ⟶ Γ^{E(G)}`,
`L(t, ε)_e = t_u + t_v + ε_e f(e)` (`e = uv`), is `SystemL.L`. The local data `g_{v,e}` of
(2) and `d_e = g_{u,e} + g_{v,e}` are `S.g` and `S.d` for a `LocalShift G`; the paper's
`a, b, c` at `v` are `S.ord.edge v 0/1/2` and `x, y, z` the flow values there.

Three auxiliary definitions render notation not present in the imported type files:
`dualPairing` (the action `η(w) = Σ_e η_e(w_e)` of a dual family on `Γ^{E(G)}`), `dualSum`
(the same sum for a total `w : β → Γ`), `Cond5` (condition (5)), and `nonzeroInd φ` (the
`𝔽₂`-indicator `1_{φ ≠ 0}` of Fact 6h).

Every statement about a graph carries both `V(G).Finite` and `E(G).Finite`; they are
load-bearing on this file's `finsum`/`ncard`-based definitions (`fact_6i` is pure linear
algebra and carries neither).
-/

open Set

open scoped Graph

open Workspace.Types.Gamma
open Workspace.Types.Orientation
open Workspace.Types.LocalOrdering
open Workspace.Types.LocalShift
open Workspace.Types.SystemL
open Workspace.Facts.Construction

namespace Workspace.Facts.Duality

variable {α β : Type*} {G : Graph α β} {e : β} {u v : α}

/-! ## Auxiliary definitions

These render the paper's notation; none of them is available in the imported type files. -/

/-- **The action of a dual family on `Γ^{E(G)}`.** *A dual vector to `Γ^{E(G)}` is written as
a family `η = (η_e)_{e ∈ E(G)}` with `η_e ∈ Γ*`; it acts by `η(w) = Σ_e η_e(w_e)`.*

The dual family is a map `η : β → Γ*`; only its values on `E(G)` are ever consulted, since
the sum ranges over the subtype `↥E(G)`. -/
noncomputable def dualPairing {G : Graph α β} (η : β → GammaDual) (w : ↥E(G) → Gamma) : F2 :=
  ∑ᶠ e : ↥E(G), η (e : β) (w e)

/-- `Σ_{e ∈ E(G)} η_e(w_e)` for a **total** edge function `w : β → Γ`, such as the paper's
`d = (d_e)_e`, which is `LocalShift.d`. -/
noncomputable def dualSum (G : Graph α β) (η : β → GammaDual) (w : β → Gamma) : F2 :=
  ∑ᶠ e ∈ E(G), η e (w e)

/-- The bridge between the two spellings of `Σ_e η_e(w_e)`: pairing `η` with the restriction
of a total `w : β → Γ` to `E(G)` is summing `η_e(w_e)` over `E(G)`. -/
theorem dualPairing_restrict (η : β → GammaDual) (w : β → Gamma) :
    dualPairing η (Set.restrict E(G) w) = dualSum G η w := by
  rw [dualPairing, dualSum]
  exact finsum_subtype_eq_finsum_cond (f := fun e => η e (w e)) (· ∈ E(G))

/-- **Condition (5)** of the paper:

  `η_e(f(e)) = 0`  (`e ∈ E(G)`),      `Σ_{e ∋ v} η_e = 0`  (`v ∈ V(G)`).

By Fact 6c this says exactly that the dual family `η` annihilates `im L`. -/
def Cond5 (G : Graph α β) (f : β → Gamma) (η : β → GammaDual) : Prop :=
  (∀ e ∈ E(G), η e (f e) = 0) ∧ (∀ v ∈ V(G), (∑ᶠ e ∈ G.incidenceSet v, η e) = 0)

open Classical in
/-- The paper's `1_{η ≠ 0}`: the bit of `𝔽₂` recording whether a dual vector is nonzero. -/
noncomputable def nonzeroInd (φ : GammaDual) : F2 := if φ ≠ 0 then 1 else 0

/-- Characteristic two on the `𝔽₂`-vector space `Γ*`: every dual vector is its own inverse. -/
private lemma gammaDual_add_self (φ : GammaDual) : φ + φ = 0 := by
  refine LinearMap.ext fun x => ?_
  simp only [LinearMap.add_apply, LinearMap.zero_apply]
  exact CharTwo.add_self_eq_zero (φ x)

/-! ## Private bookkeeping helpers (finsum double counting over the incidence relation) -/

/-- Summing `f` over a subset `s` of `t` is the same as summing the `s`-indicator of `f`
over `t`. -/
private lemma finsum_mem_subset_indicator {M : Type*} [AddCommMonoid M] {X : Type*}
    {s t : Set X} (hst : s ⊆ t) (f : X → M) :
    (∑ᶠ x ∈ s, f x) = ∑ᶠ x ∈ t, s.indicator f x := by
  rw [finsum_mem_def s f, finsum_mem_def t (s.indicator f), Set.indicator_indicator,
    Set.inter_eq_right.mpr hst]

open Classical in
/-- **The incidence double count.** Summing over edges and, for each edge, over its ends, is the
same as summing over vertices and, for each vertex, over its incident edges. -/
private lemma incidence_double_sum {M : Type*} [AddCommMonoid M] (hV : V(G).Finite)
    (hE : E(G).Finite) (F : β → α → M) :
    (∑ᶠ e ∈ E(G), ∑ᶠ w ∈ {w | G.Inc e w}, F e w)
      = ∑ᶠ v ∈ V(G), ∑ᶠ e ∈ G.incidenceSet v, F e v := by
  have h1 : ∀ e ∈ E(G), (∑ᶠ w ∈ {w | G.Inc e w}, F e w)
      = ∑ᶠ w ∈ V(G), {w | G.Inc e w}.indicator (F e) w := fun e _ =>
    finsum_mem_subset_indicator (fun w hw => Graph.Inc.vertex_mem hw) (F e)
  rw [finsum_mem_congr rfl h1, finsum_mem_comm _ hE hV]
  refine finsum_mem_congr rfl fun v hv => ?_
  rw [finsum_mem_subset_indicator (s := G.incidenceSet v) (t := E(G))
        (fun e he => he.edge_mem) (fun e => F e v)]
  refine finsum_mem_congr rfl fun e he => ?_
  simp only [Set.indicator_apply, Set.mem_setOf_eq, Graph.mem_incidenceSet]

/-- A `finsum` over a set of a function supported at a single point of the set. -/
private lemma finsum_mem_eq_single' {M : Type*} [AddCommMonoid M] {X : Type*} {s : Set X}
    {g : X → M} {a : X} (ha : a ∈ s) (h : ∀ x ∈ s, x ≠ a → g x = 0) :
    (∑ᶠ x ∈ s, g x) = g a := by
  classical
  rw [finsum_mem_def, finsum_eq_single (s.indicator g) a ?_, Set.indicator_of_mem ha]
  intro x hx
  rcases em (x ∈ s) with hxs | hxs
  · rw [Set.indicator_of_mem hxs]; exact h x hxs hx
  · rw [Set.indicator_of_notMem hxs]

/-- **The bridge between dual families and functionals on `Γ^{E(G)}`.** Every `𝔽₂`-linear
functional `φ` on the codomain `↥E(G) → Γ` of `L` is `dualPairing η` for some dual family
`η`.  Construct `η_b` as `φ` precomposed with the coordinate insertion `Pi.single b` (for
`b ∈ E(G)`), and `0` off `E(G)`. -/
private lemma exists_eta_of_functional (hE : E(G).Finite)
    (φ : (↥E(G) → Gamma) →ₗ[F2] F2) :
    ∃ η : β → GammaDual, ∀ w : ↥E(G) → Gamma, dualPairing η w = φ w := by
  classical
  haveI : Fintype ↥E(G) := hE.fintype
  refine ⟨fun b => if h : b ∈ E(G) then
      φ ∘ₗ (LinearMap.single F2 (fun _ : ↥E(G) => Gamma) ⟨b, h⟩) else 0, ?_⟩
  intro w
  rw [dualPairing, finsum_eq_sum_of_fintype]
  have hterm : ∀ e : ↥E(G), (fun b => if h : b ∈ E(G) then
      φ ∘ₗ (LinearMap.single F2 (fun _ : ↥E(G) => Gamma) ⟨b, h⟩) else 0) (e : β) (w e)
      = φ (Pi.single e (w e)) := by
    intro e
    simp only [dif_pos e.2, LinearMap.comp_apply, LinearMap.coe_single]
  rw [Finset.sum_congr rfl (fun e _ => hterm e), ← map_sum, LinearMap.sum_single_apply]

/-! ## Fact 6a — the duality criterion -/

/-- **Fact 6a (duality criterion).** *`d ∈ im L` if and only if every family `η` which takes
the value zero on `im L` also satisfies `Σ_e η_e(d_e) = 0`.*

"`η` takes the value zero on `im L`" is `∀ p, Σ_e η_e(L(p)_e) = 0`; the conclusion is
`Σ_e η_e(d_e) = 0`.  Both are the pairing `dualPairing`. -/
theorem fact_6a (hV : V(G).Finite) (hE : E(G).Finite) (Sys : SystemL G) (d : ↥E(G) → Gamma) :
    d ∈ LinearMap.range Sys.L ↔
      ∀ η : β → GammaDual,
        (∀ p : (α → Gamma) × (β → F2), dualPairing η (Sys.L p) = 0) →
          dualPairing η d = 0 := by
  classical
  haveI : Fintype ↥E(G) := hE.fintype
  haveI : FiniteDimensional F2 (↥E(G) → Gamma) := inferInstance
  set U : Submodule F2 (↥E(G) → Gamma) := LinearMap.range Sys.L with hU
  constructor
  · intro hd η hη
    obtain ⟨p, rfl⟩ := LinearMap.mem_range.mp hd
    exact hη p
  · intro hRHS
    rw [← Subspace.forall_mem_dualAnnihilator_apply_eq_zero_iff U d]
    intro φ hφ
    obtain ⟨η, hη⟩ := exists_eta_of_functional hE φ
    have hηann : ∀ p, dualPairing η (Sys.L p) = 0 := by
      intro p
      rw [hη]
      exact (Submodule.mem_dualAnnihilator φ).mp hφ (Sys.L p) (LinearMap.mem_range_self Sys.L p)
    rw [← hη d]
    exact hRHS η hηann

/-! ## Fact 6b — the expansion -/

/-- **Fact 6b (expansion).** *For every `(t, ε)`,*

  `Σ_e η_e(L(t,ε)_e) = Σ_v (Σ_{e ∋ v} η_e)(t_v) + Σ_e ε_e η_e(f(e))`.

Pure bookkeeping: expand `L(t,ε)_e = t_u + t_v + ε_e f(e)` by linearity of `η_e` and
exchange the order of summation.  No flow, looplessness or cubicness hypothesis is involved;
only the finiteness of the two index sets, which the exchange of summation needs. -/
theorem fact_6b (hV : V(G).Finite) (hE : E(G).Finite) (Sys : SystemL G)
    (η : β → GammaDual) (t : α → Gamma) (ε : β → F2) :
    dualPairing η (Sys.L (t, ε))
      = (∑ᶠ v ∈ V(G), (∑ᶠ e ∈ G.incidenceSet v, η e) (t v))
        + ∑ᶠ e ∈ E(G), ε e * η e (Sys.flow e) := by
  classical
  have hfe : Finite (↥E(G)) := hE.to_subtype
  have hpt : ∀ e : ↥E(G),
      η (e : β) (Sys.L (t, ε) e)
        = (∑ᶠ w ∈ {w | G.Inc (e : β) w}, η (e : β) (t w))
          + ε (e : β) * η (e : β) (Sys.flow (e : β)) := by
    intro e
    rw [Sys.L_apply, map_add]
    congr 1
    · exact AddMonoidHom.map_finsum_mem t (η (e : β)).toAddMonoidHom (setOf_inc_finite G (e : β))
    · rw [map_smul, smul_eq_mul]
  rw [dualPairing]
  simp_rw [hpt]
  rw [finsum_add_distrib (Set.toFinite _) (Set.toFinite _)]
  congr 1
  · rw [finsum_subtype_eq_finsum_cond
        (f := fun e => ∑ᶠ w ∈ {w | G.Inc e w}, η e (t w)) (· ∈ E(G))]
    rw [incidence_double_sum hV hE (fun e w => η e (t w))]
    refine finsum_mem_congr rfl fun v hv => ?_
    have hfin : (G.incidenceSet v).Finite := hE.subset fun e he => he.edge_mem
    let ev : GammaDual →+ F2 :=
      { toFun := fun φ => φ (t v), map_zero' := rfl, map_add' := fun a b => rfl }
    exact (AddMonoidHom.map_finsum_mem η ev hfin).symm
  · exact finsum_subtype_eq_finsum_cond
      (f := fun e => ε e * η e (Sys.flow e)) (· ∈ E(G))

/-! ## Fact 6c — the annihilator of `im L`, i.e. condition (5) -/

/-- **Fact 6c (annihilator of `im L`).** *Since the `t_v` and the `ε_e` may be chosen
independently, the quantity in Fact 6b vanishes for every `(t, ε)` precisely when*

  `η_e(f(e)) = 0` (`e ∈ E(G)`),      `Σ_{e ∋ v} η_e = 0` (`v ∈ V(G)`).      (5)

The left-hand side is "`η` takes the value zero on `im L`" — by Fact 6b, exactly the
vanishing of the quantity displayed there. -/
theorem fact_6c (hV : V(G).Finite) (hE : E(G).Finite) (Sys : SystemL G) (η : β → GammaDual) :
    (∀ p : (α → Gamma) × (β → F2), dualPairing η (Sys.L p) = 0) ↔ Cond5 G Sys.flow η := by
  classical
  constructor
  · intro h
    have key : ∀ (t : α → Gamma) (ε : β → F2),
        (∑ᶠ v ∈ V(G), (∑ᶠ e ∈ G.incidenceSet v, η e) (t v))
          + (∑ᶠ e ∈ E(G), ε e * η e (Sys.flow e)) = 0 :=
      fun t ε => (fact_6b hV hE Sys η t ε).symm.trans (h (t, ε))
    refine ⟨fun e0 he0 => ?_, fun v0 hv0 => ?_⟩
    · have hk := key 0 (Pi.single e0 1)
      have h1 : (∑ᶠ v ∈ V(G), (∑ᶠ e ∈ G.incidenceSet v, η e) ((0 : α → Gamma) v)) = 0 := by
        refine (finsum_mem_congr rfl fun v hv => ?_).trans (finsum_mem_zero _)
        simp
      have h2 : (∑ᶠ e ∈ E(G), (Pi.single e0 (1 : F2) : β → F2) e * η e (Sys.flow e))
          = η e0 (Sys.flow e0) := by
        refine finsum_mem_eq_single' he0 (fun e he hne => ?_) |>.trans ?_
        · rw [Pi.single_eq_of_ne hne, zero_mul]
        · rw [Pi.single_eq_same, one_mul]
      rw [h1, h2, zero_add] at hk
      exact hk
    · refine LinearMap.ext fun γ => ?_
      have hk := key (Pi.single v0 γ) 0
      have h2 : (∑ᶠ e ∈ E(G), (0 : β → F2) e * η e (Sys.flow e)) = 0 := by
        refine (finsum_mem_congr rfl fun e he => ?_).trans (finsum_mem_zero _)
        simp
      have h1 : (∑ᶠ v ∈ V(G), (∑ᶠ e ∈ G.incidenceSet v, η e) ((Pi.single v0 γ : α → Gamma) v))
          = (∑ᶠ e ∈ G.incidenceSet v0, η e) γ := by
        refine finsum_mem_eq_single' hv0 (fun v hv hne => ?_) |>.trans ?_
        · rw [Pi.single_eq_of_ne hne, map_zero]
        · rw [Pi.single_eq_same]
      rw [h1, h2, add_zero] at hk
      rw [LinearMap.zero_apply]
      exact hk
  · rintro ⟨he0, hv0⟩ p
    rw [fact_6b hV hE Sys η p.1 p.2]
    have h1 : (∑ᶠ v ∈ V(G), (∑ᶠ e ∈ G.incidenceSet v, η e) (p.1 v)) = 0 := by
      refine (finsum_mem_congr rfl fun v hv => ?_).trans (finsum_mem_zero _)
      rw [hv0 v hv, LinearMap.zero_apply]
    have h2 : (∑ᶠ e ∈ E(G), p.2 e * η e (Sys.flow e)) = 0 := by
      refine (finsum_mem_congr rfl fun e he => ?_).trans (finsum_mem_zero _)
      rw [he0 e he, mul_zero]
    rw [h1, h2, zero_add]

/-! ## Fact 6d — the reduction -/

/-- **Fact 6d (reduction).** *Consequently, it suffices to prove that every family `η`
satisfying (5) also satisfies*

  `Σ_e η_e(d_e) = 0`.                                                        (6)

Combining Facts 6a and 6c: if (6) holds for every `η` obeying (5), then `d ∈ im L`, i.e. the
system (4) is solvable. -/
theorem fact_6d (hV : V(G).Finite) (hE : E(G).Finite) (Sys : SystemL G)
    (h : ∀ η : β → GammaDual, Cond5 G Sys.flow η → dualPairing η Sys.rhsOn = 0) :
    Sys.HasSolution := by
  rw [Sys.hasSolution_iff_mem_range, fact_6a hV hE Sys Sys.rhsOn]
  intro η hη
  exact h η ((fact_6c hV hE Sys η).mp hη)

/-! ## Facts 6e–6h — the local analysis at a vertex

Throughout this section `v` is a vertex of a finite loopless cubic graph `G`, `S` is a local
shift whose `flow` is a nowhere-zero `Γ`-flow (with respect to an orientation `O`), and
`η` is a dual family satisfying (5).  The paper's `a, b, c` are `S.ord.edge v 0`,
`S.ord.edge v 1`, `S.ord.edge v 2`, and `x = f(a)`, `y = f(b)`, `z = f(c)` are
`S.flow (S.ord.edge v i)` for `i = 0, 1, 2`.  The scalar `λ` is `η_b(x)`, i.e.
`η (S.ord.edge v 1) (S.flow (S.ord.edge v 0))`. -/

/-- **Fact 6e (local form of (5)).** *Conditions (5) at `v` become*

  `η_a + η_b + η_c = 0,   η_a(x) = 0,   η_b(y) = 0,   η_c(z) = 0`.           (7)

The first equation is the vertex condition `Σ_{e ∋ v} η_e = 0` of (5), read through the local
ordering: `a, b, c` enumerate the edges at `v` without repetition.  The other three are the
edge condition `η_e(f(e)) = 0` of (5) at `e = a, b, c`, since `x = f(a)`, `y = f(b)`,
`z = f(c)`. -/
theorem fact_6e (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (η : β → GammaDual) (h5 : Cond5 G S.flow η)
    (hv : v ∈ V(G)) :
    η (S.ord.edge v 0) + η (S.ord.edge v 1) + η (S.ord.edge v 2) = 0 ∧
      η (S.ord.edge v 0) (S.flow (S.ord.edge v 0)) = 0 ∧
      η (S.ord.edge v 1) (S.flow (S.ord.edge v 1)) = 0 ∧
      η (S.ord.edge v 2) (S.flow (S.ord.edge v 2)) = 0 := by
  classical
  obtain ⟨he0, hv0⟩ := h5
  refine ⟨?_, he0 _ (S.ord.edge_mem_edgeSet hv 0), he0 _ (S.ord.edge_mem_edgeSet hv 1),
    he0 _ (S.ord.edge_mem_edgeSet hv 2)⟩
  have h01 : S.ord.edge v 0 ≠ S.ord.edge v 1 := S.ord.edge_ne_edge hv (by decide)
  have h02 : S.ord.edge v 0 ≠ S.ord.edge v 2 := S.ord.edge_ne_edge hv (by decide)
  have h12 : S.ord.edge v 1 ≠ S.ord.edge v 2 := S.ord.edge_ne_edge hv (by decide)
  have hthis := hv0 v hv
  rw [S.incidenceSet_eq_triple hv] at hthis
  have hcoe : ({S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} : Set β)
      = (↑({S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} : Finset β) : Set β) := by simp
  rw [hcoe, finsum_mem_coe_finset, Finset.sum_insert (by simp [h01, h02]),
    Finset.sum_insert (by simp [h12]), Finset.sum_singleton] at hthis
  rw [add_assoc]
  exact hthis

/-- **The characteristic-two flow equation at a vertex (local derivation of §2).** In a loopless
graph, the sum of a `Γ`-flow over the edges incident to a vertex vanishes: the incident edges
split as the disjoint union of the out- and in-edges, whose sums are equal by conservation, and
`a + a = 0` in characteristic two. -/
private lemma flow_incidence_sum_zero (hE : E(G).Finite) (hloop : G.IsLoopless)
    (O : Orientation G) (f : β → Gamma) (hf : G.IsFlow O f) (hv : v ∈ V(G)) :
    (∑ᶠ e ∈ G.incidenceSet v, f e) = 0 := by
  have hout : (G.outEdgeSet O v).Finite := hE.subset Graph.outEdgeSet_subset_edgeSet
  have hin : (G.inEdgeSet O v).Finite := hE.subset Graph.inEdgeSet_subset_edgeSet
  have hunion : G.incidenceSet v = G.outEdgeSet O v ∪ G.inEdgeSet O v := by
    ext e
    simp only [Graph.mem_incidenceSet, Graph.mem_outEdgeSet, Graph.mem_inEdgeSet, Set.mem_union]
    constructor
    · intro hinc
      have he := hinc.edge_mem
      rcases (O.inc_iff he).1 hinc with h | h
      · exact Or.inl ⟨he, h.symm⟩
      · exact Or.inr ⟨he, h.symm⟩
    · rintro (⟨he, ht⟩ | ⟨he, hh⟩)
      · rw [← ht]; exact O.inc_tail he
      · rw [← hh]; exact O.inc_head he
  have hdisj : Disjoint (G.outEdgeSet O v) (G.inEdgeSet O v) := by
    rw [Set.disjoint_left]
    rintro e ⟨he, ht⟩ ⟨-, hh⟩
    have hla : G.IsLoopAt e (O.tail e) :=
      (O.isLoopAt_tail_iff_tail_eq_head he).2 (ht.trans hh.symm)
    rw [ht] at hla
    exact hloop e v hla
  rw [hunion, finsum_mem_union hdisj hout hin]
  have hcons := hf v hv
  rw [Graph.outSum, Graph.inSum] at hcons
  rw [hcons]
  exact Gamma.add_self _

/-- **Fact 6f.** *Set `λ = η_b(x)`. Since `η_c = η_a + η_b` and `z = x + y`, we get
`0 = η_c(z) = η_a(y) + η_b(x)` (using `η_a(x) = η_b(y) = 0`). Hence `η_a(y) = λ`.*

In the notation of the file: `η_a(y) = η (S.ord.edge v 0) (S.flow (S.ord.edge v 1))` and
`λ = η_b(x) = η (S.ord.edge v 1) (S.flow (S.ord.edge v 0))`. -/
theorem fact_6f (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (η : β → GammaDual) (h5 : Cond5 G S.flow η)
    (hv : v ∈ V(G)) :
    η (S.ord.edge v 0) (S.flow (S.ord.edge v 1))
      = η (S.ord.edge v 1) (S.flow (S.ord.edge v 0)) := by
  obtain ⟨hsum, hax, hby, hcz⟩ := fact_6e hV hE hloop hcubic O S hf hnz η h5 hv
  obtain ⟨hz, -, -, -, -⟩ :=
    cubic_flow_distinct hV hE hloop hcubic O S.flow hf hnz S.ord hv
  -- `η_c = η_a + η_b` from `η_a + η_b + η_c = 0` in characteristic two.
  have hηc : η (S.ord.edge v 2) = η (S.ord.edge v 0) + η (S.ord.edge v 1) := by
    have h : η (S.ord.edge v 2) + (η (S.ord.edge v 0) + η (S.ord.edge v 1)) = 0 := by
      rw [← hsum]; abel
    have hs2 : (η (S.ord.edge v 0) + η (S.ord.edge v 1))
        + (η (S.ord.edge v 0) + η (S.ord.edge v 1)) = 0 := gammaDual_add_self _
    calc η (S.ord.edge v 2)
        = (η (S.ord.edge v 2) + (η (S.ord.edge v 0) + η (S.ord.edge v 1)))
            + (η (S.ord.edge v 0) + η (S.ord.edge v 1)) := by rw [add_assoc, hs2, add_zero]
      _ = η (S.ord.edge v 0) + η (S.ord.edge v 1) := by rw [h, zero_add]
  -- Evaluate `η_c(z) = 0` with `z = x + y`.
  have key : η (S.ord.edge v 0) (S.flow (S.ord.edge v 1))
      + η (S.ord.edge v 1) (S.flow (S.ord.edge v 0)) = 0 := by
    have hexp := hcz
    rw [hηc, hz, LinearMap.add_apply, map_add, map_add, hax, hby, zero_add, add_zero] at hexp
    exact hexp
  -- In characteristic two, `p + q = 0 → p = q`.
  have hqq : η (S.ord.edge v 1) (S.flow (S.ord.edge v 0))
      + η (S.ord.edge v 1) (S.flow (S.ord.edge v 0)) = 0 := CharTwo.add_self_eq_zero _
  exact add_right_cancel (key.trans hqq.symm)

/-- **Fact 6g (equation (8)).** *By (2), only the edge `b` contributes at `v`, and therefore*

  `Σ_{e ∋ v} η_e(g_{v,e}) = η_b(x) = λ`.                                     (8)

Indeed `g_{v,a} = g_{v,c} = 0` and `g_{v,b} = x = f(a)` by (2). -/
theorem fact_6g (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (η : β → GammaDual) (h5 : Cond5 G S.flow η)
    (hv : v ∈ V(G)) :
    (∑ᶠ e ∈ G.incidenceSet v, η e (S.g v e))
      = η (S.ord.edge v 1) (S.flow (S.ord.edge v 0)) := by
  classical
  have h01 : S.ord.edge v 0 ≠ S.ord.edge v 1 := S.ord.edge_ne_edge hv (by decide)
  have h02 : S.ord.edge v 0 ≠ S.ord.edge v 2 := S.ord.edge_ne_edge hv (by decide)
  have h12 : S.ord.edge v 1 ≠ S.ord.edge v 2 := S.ord.edge_ne_edge hv (by decide)
  have hcoe : ({S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} : Set β)
      = (↑({S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} : Finset β) : Set β) := by simp
  rw [S.incidenceSet_eq_triple hv, hcoe, finsum_mem_coe_finset,
    Finset.sum_insert (by simp [h01, h02]), Finset.sum_insert (by simp [h12]),
    Finset.sum_singleton]
  simp [S.g_edge_zero hv, S.g_edge_one v, S.g_edge_two hv]

/-- **Fact 6i (unique annihilating dual vector).** *In the `3`-dimensional `𝔽₂`-space `Γ`, for
a `2`-dimensional subspace `W ≤ Γ` there is exactly one nonzero `η ∈ Γ*` with `η|_W = 0`.*

Pure linear algebra: no graph, no finiteness hypothesis. -/
theorem fact_6i (W : Submodule F2 Gamma) (hW : Module.finrank F2 W = 2) :
    ∃! φ : GammaDual, φ ≠ 0 ∧ ∀ w ∈ W, φ w = 0 := by
  have hV3 : Module.finrank F2 Gamma = 3 := Gamma.finrank_eq
  have hann : Module.finrank F2 (W.dualAnnihilator : Submodule F2 GammaDual) = 1 := by
    have hadd := Subspace.finrank_add_finrank_dualAnnihilator_eq W
    rw [hW, hV3] at hadd
    omega
  obtain ⟨v, hv_ne, hv_span⟩ :=
    (finrank_eq_one_iff' (K := F2)
      (V := (W.dualAnnihilator : Submodule F2 GammaDual))).mp hann
  refine ⟨(v : GammaDual), ⟨?_, ?_⟩, ?_⟩
  · intro h
    exact hv_ne (Submodule.coe_eq_zero.mp h)
  · exact (Submodule.mem_dualAnnihilator _).mp v.property
  · rintro φ ⟨hφ_ne, hφ_ann⟩
    have hφmem : φ ∈ W.dualAnnihilator := (Submodule.mem_dualAnnihilator _).mpr hφ_ann
    obtain ⟨c, hc⟩ := hv_span ⟨φ, hφmem⟩
    have hc_ne : c ≠ 0 := by
      intro h0
      rw [h0, zero_smul] at hc
      exact hφ_ne (congrArg Subtype.val hc).symm
    have hc1 : c = 1 := (by decide : ∀ x : F2, x ≠ 0 → x = 1) c hc_ne
    rw [hc1, one_smul] at hc
    exact (congrArg Subtype.val hc).symm

/-- `1_{φ ≠ 0} = 1` when `φ ≠ 0`. -/
private lemma nonzeroInd_eq_one {φ : GammaDual} (h : φ ≠ 0) : nonzeroInd φ = 1 := by
  unfold nonzeroInd; exact if_pos h

/-- `1_{φ ≠ 0} = 0` when `φ = 0`. -/
private lemma nonzeroInd_eq_zero {φ : GammaDual} (h : φ = 0) : nonzeroInd φ = 0 := by
  unfold nonzeroInd; exact if_neg (by simp [h])

/-- For two dual vectors each equal to `0` or a fixed nonzero `φ₀`, the `𝔽₂`-sum of their
three indicators (theirs and their sum's) vanishes. -/
private lemma nonzeroInd_add_pair {φ₀ p q : GammaDual} (hφ₀ : φ₀ ≠ 0)
    (hp : p = 0 ∨ p = φ₀) (hq : q = 0 ∨ q = φ₀) :
    nonzeroInd p + nonzeroInd q + nonzeroInd (p + q) = 0 := by
  rcases hp with hp | hp <;> rcases hq with hq | hq <;> rw [hp, hq]
  · rw [nonzeroInd_eq_zero rfl, nonzeroInd_eq_zero (add_zero 0)]; rfl
  · rw [nonzeroInd_eq_zero rfl, nonzeroInd_eq_one hφ₀, nonzeroInd_eq_one (by rwa [zero_add])]
    decide
  · rw [nonzeroInd_eq_one hφ₀, nonzeroInd_eq_zero rfl, nonzeroInd_eq_one (by rwa [add_zero])]
    decide
  · rw [nonzeroInd_eq_one hφ₀, nonzeroInd_eq_zero (gammaDual_add_self φ₀)]
    decide

/-- **Fact 6h (interpretation of `λ`).** *`λ` is the parity of the number of nonzero members
of `{η_a, η_b, η_c}`.*

If `λ = 0`, all three dual vectors vanish on the two-dimensional space `W = ⟨x, y⟩`; by the
uniqueness of Fact 6i each is `0` or the unique nonzero annihilator, and their sum being zero
forces it to occur zero or two times. If `λ = 1`, all three are nonzero. The parity
`#{e ∋ v : η_e ≠ 0}` is written as the `𝔽₂`-sum `Σ_{e ∋ v} 1_{η_e ≠ 0}` over the three
distinct edges at `v`. -/
theorem fact_6h (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (η : β → GammaDual) (h5 : Cond5 G S.flow η)
    (hv : v ∈ V(G)) :
    η (S.ord.edge v 1) (S.flow (S.ord.edge v 0))
      = ∑ᶠ e ∈ G.incidenceSet v, nonzeroInd (η e) := by
  classical
  obtain ⟨hsum, hax, hby, hcz⟩ := fact_6e hV hE hloop hcubic O S hf hnz η h5 hv
  obtain ⟨hzxy, hxne, hyne, hzne, hxyne⟩ :=
    cubic_flow_distinct hV hE hloop hcubic O S.flow hf hnz S.ord hv
  have h6f := fact_6f hV hE hloop hcubic O S hf hnz η h5 hv
  -- `η_c = η_a + η_b` from `η_a + η_b + η_c = 0` in characteristic two.
  have hηc : η (S.ord.edge v 2) = η (S.ord.edge v 0) + η (S.ord.edge v 1) := by
    have h : η (S.ord.edge v 2) + (η (S.ord.edge v 0) + η (S.ord.edge v 1)) = 0 := by
      rw [← hsum]; abel
    have hs2 : (η (S.ord.edge v 0) + η (S.ord.edge v 1))
        + (η (S.ord.edge v 0) + η (S.ord.edge v 1)) = 0 := gammaDual_add_self _
    calc η (S.ord.edge v 2)
        = (η (S.ord.edge v 2) + (η (S.ord.edge v 0) + η (S.ord.edge v 1)))
            + (η (S.ord.edge v 0) + η (S.ord.edge v 1)) := by rw [add_assoc, hs2, add_zero]
      _ = η (S.ord.edge v 0) + η (S.ord.edge v 1) := by rw [h, zero_add]
  -- Expand the RHS over the three incident edges.
  have h01 : S.ord.edge v 0 ≠ S.ord.edge v 1 := S.ord.edge_ne_edge hv (by decide)
  have h02 : S.ord.edge v 0 ≠ S.ord.edge v 2 := S.ord.edge_ne_edge hv (by decide)
  have h12 : S.ord.edge v 1 ≠ S.ord.edge v 2 := S.ord.edge_ne_edge hv (by decide)
  have hcoe : ({S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} : Set β)
      = (↑({S.ord.edge v 0, S.ord.edge v 1, S.ord.edge v 2} : Finset β) : Set β) := by simp
  rw [S.incidenceSet_eq_triple hv, hcoe, finsum_mem_coe_finset,
    Finset.sum_insert (by simp [h01, h02]), Finset.sum_insert (by simp [h12]),
    Finset.sum_singleton]
  -- Case on `λ = η_b(x) ∈ 𝔽₂`.
  rcases (by decide : ∀ w : F2, w = 0 ∨ w = 1)
      (η (S.ord.edge v 1) (S.flow (S.ord.edge v 0))) with hL | hL
  · -- `λ = 0`: `η_a, η_b` annihilate `W = ⟨x, y⟩`, so each is `0` or the unique annihilator.
    set W : Submodule F2 Gamma :=
      Submodule.span F2 (Set.range ![S.flow (S.ord.edge v 0), S.flow (S.ord.edge v 1)]) with hWdef
    have hli : LinearIndependent F2
        ![S.flow (S.ord.edge v 0), S.flow (S.ord.edge v 1)] := by
      rw [LinearIndependent.pair_iff]
      intro s t hst
      rcases (by decide : ∀ w : F2, w = 0 ∨ w = 1) s with rfl | rfl <;>
        rcases (by decide : ∀ w : F2, w = 0 ∨ w = 1) t with rfl | rfl
      · exact ⟨rfl, rfl⟩
      · rw [zero_smul, one_smul, zero_add] at hst; exact absurd hst hyne
      · rw [one_smul, zero_smul, add_zero] at hst; exact absurd hst hxne
      · rw [one_smul, one_smul, ← hzxy] at hst; exact absurd hst hzne
    have hWrank : Module.finrank F2 W = 2 := by
      rw [hWdef, finrank_span_eq_card hli]; simp
    have hWann : ∀ φ : GammaDual, φ (S.flow (S.ord.edge v 0)) = 0 →
        φ (S.flow (S.ord.edge v 1)) = 0 → ∀ w ∈ W, φ w = 0 := by
      intro φ hφx hφy w hw
      have hle : W ≤ LinearMap.ker φ := by
        rw [hWdef, Submodule.span_le]
        rintro z ⟨i, rfl⟩
        fin_cases i
        · simpa [LinearMap.mem_ker] using hφx
        · simpa [LinearMap.mem_ker] using hφy
      exact LinearMap.mem_ker.mp (hle hw)
    obtain ⟨φ₀, hφ₀spec, huniq⟩ := fact_6i W hWrank
    have hφ₀ne : φ₀ ≠ 0 := hφ₀spec.1
    -- Package `η_a, η_b ∈ {0, φ₀}`.
    have hηa01 : η (S.ord.edge v 0) = 0 ∨ η (S.ord.edge v 0) = φ₀ := by
      by_cases h0 : η (S.ord.edge v 0) = 0
      · exact Or.inl h0
      · exact Or.inr (huniq _ ⟨h0, hWann _ hax (h6f.trans hL)⟩)
    have hηb01 : η (S.ord.edge v 1) = 0 ∨ η (S.ord.edge v 1) = φ₀ := by
      by_cases h0 : η (S.ord.edge v 1) = 0
      · exact Or.inl h0
      · exact Or.inr (huniq _ ⟨h0, hWann _ hL hby⟩)
    rw [hL, hηc, ← add_assoc]
    exact (nonzeroInd_add_pair hφ₀ne hηa01 hηb01).symm
  · -- `λ = 1`: all three of `η_a, η_b, η_c` are nonzero.
    have hηb_ne : η (S.ord.edge v 1) ≠ 0 := by
      intro h; rw [h] at hL; simp at hL
    have hηa_ne : η (S.ord.edge v 0) ≠ 0 := by
      intro h
      have hval := h6f.trans hL
      rw [h, LinearMap.zero_apply] at hval
      exact one_ne_zero hval.symm
    have hηc_ne : η (S.ord.edge v 2) ≠ 0 := by
      intro h
      have hcx : η (S.ord.edge v 2) (S.flow (S.ord.edge v 0)) = 1 := by
        rw [hηc, LinearMap.add_apply, hax, hL, zero_add]
      rw [h, LinearMap.zero_apply] at hcx
      exact one_ne_zero hcx.symm
    rw [hL, nonzeroInd_eq_one hηa_ne, nonzeroInd_eq_one hηb_ne, nonzeroInd_eq_one hηc_ne]
    decide

/-- **Fact 6h, equation (9).** *This together with (8) gives*

  `Σ_{e ∋ v} η_e(g_{v,e}) = Σ_{e ∋ v} 1_{η_e ≠ 0}`.                          (9)

Immediate from Fact 6g (equation (8)) and the `λ`-parity claim `fact_6h`. -/
theorem fact_6h_eq9 (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (η : β → GammaDual) (h5 : Cond5 G S.flow η)
    (hv : v ∈ V(G)) :
    (∑ᶠ e ∈ G.incidenceSet v, η e (S.g v e))
      = ∑ᶠ e ∈ G.incidenceSet v, nonzeroInd (η e) := by
  rw [fact_6g hV hE hloop hcubic O S hf hnz η h5 hv]
  exact fact_6h hV hE hloop hcubic O S hf hnz η h5 hv

/-! ## Fact 6j — the double count concluding (6) -/

/-- **Fact 6j, step 1.** *For `e = uv`, the definition `d_e = g_{u,e} + g_{v,e}` and linearity
of `η_e` give `η_e(d_e) = η_e(g_{u,e}) + η_e(g_{v,e})`.*

Looplessness is what makes the two ends `u`, `v` of `e` distinct, which is what
`LocalShift.d_eq_add` needs. -/
theorem fact_6j_edge (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (S : LocalShift G) (η : β → GammaDual) (h : G.IsLink e u v) :
    η e (S.d e) = η e (S.g u e) + η e (S.g v e) := by
  have huv : u ≠ v := Graph.isLoopless_iff_forall_isLink_ne.mp hloop e u v h
  rw [S.d_eq_add h huv, map_add]

/-- **Fact 6j, step 2 (the double count).** *Summing over all edges and grouping the two
endpoint terms at each vertex,*

  `Σ_e η_e(d_e) = Σ_v Σ_{e ∋ v} η_e(g_{v,e})`.

This is an exchange of the order of summation over the incident pairs `(v, e)`, needing only
the finiteness of `V(G)` and `E(G)`. -/
theorem fact_6j_double_count (hV : V(G).Finite) (hE : E(G).Finite) (S : LocalShift G)
    (η : β → GammaDual) :
    dualSum G η S.d = ∑ᶠ v ∈ V(G), ∑ᶠ e ∈ G.incidenceSet v, η e (S.g v e) := by
  rw [dualSum]
  have hpt : ∀ e ∈ E(G),
      η e (S.d e) = ∑ᶠ w ∈ {w | G.Inc e w}, η e (S.g w e) := by
    intro e he
    rw [S.d_def]
    exact AddMonoidHom.map_finsum_mem (fun w => S.g w e) (η e).toAddMonoidHom
      (setOf_inc_finite G e)
  rw [finsum_mem_congr rfl hpt,
    incidence_double_sum hV hE (fun e w => η e (S.g w e))]

/-- **Fact 6j, step 3.** *…and (9) gives
`Σ_v Σ_{e ∋ v} η_e(g_{v,e}) = Σ_v Σ_{e ∋ v} 1_{η_e ≠ 0}`.*

Apply equation (9) (`fact_6h_eq9`) at each vertex. -/
theorem fact_6j_eq9_sum (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (η : β → GammaDual) (h5 : Cond5 G S.flow η) :
    (∑ᶠ v ∈ V(G), ∑ᶠ e ∈ G.incidenceSet v, η e (S.g v e))
      = ∑ᶠ v ∈ V(G), ∑ᶠ e ∈ G.incidenceSet v, nonzeroInd (η e) := by
  refine finsum_mem_congr rfl fun v hv => ?_
  exact fact_6h_eq9 hV hE hloop hcubic O S hf hnz η h5 hv

/-- **Fact 6j, step 4.** *Each edge with `η_e ≠ 0` occurs twice in the last sum, once at each
endpoint. Hence it equals `2 Σ_e 1_{η_e ≠ 0} = 0` in `𝔽₂`.*

Looplessness is what makes "once at each endpoint" mean *twice*: a loop would be counted once
only.  The conclusion records both halves of the sentence — the value `2 • Σ_e 1_{η_e ≠ 0}`
and its vanishing in `𝔽₂`. -/
theorem fact_6j_two_mul (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (η : β → GammaDual) :
    (∑ᶠ v ∈ V(G), ∑ᶠ e ∈ G.incidenceSet v, nonzeroInd (η e))
        = (2 : ℕ) • (∑ᶠ e ∈ E(G), nonzeroInd (η e)) ∧
      ((2 : ℕ) • (∑ᶠ e ∈ E(G), nonzeroInd (η e)) : F2) = 0 := by
  refine ⟨?_, ?_⟩
  · rw [← incidence_double_sum hV hE (fun e _ => nonzeroInd (η e))]
    have hinner : ∀ e ∈ E(G),
        (∑ᶠ w ∈ {w | G.Inc e w}, nonzeroInd (η e))
          = nonzeroInd (η e) + nonzeroInd (η e) := by
      intro e he
      obtain ⟨u, v, hl⟩ := G.exists_isLink_of_mem_edgeSet he
      have huv : u ≠ v := Graph.isLoopless_iff_forall_isLink_ne.mp hloop e u v hl
      rw [LocalShift.setOf_inc_eq_pair hl, finsum_mem_pair huv]
    rw [finsum_mem_congr rfl hinner, finsum_mem_add_distrib hE, two_nsmul]
  · rw [two_nsmul]
    exact CharTwo.add_self_eq_zero _

/-- **Fact 6j — equation (6).** *This proves (6):*

  `Σ_e η_e(d_e) = 0`.                                                        (6)

The chain is `fact_6j_double_count`, then `fact_6j_eq9_sum` (i.e. equation (9)), then
`fact_6j_two_mul`. -/
theorem fact_6j (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) (η : β → GammaDual) (h5 : Cond5 G S.flow η) :
    dualSum G η S.d = 0 := by
  rw [fact_6j_double_count hV hE S η,
    fact_6j_eq9_sum hV hE hloop hcubic O S hf hnz η h5,
    (fact_6j_two_mul hV hE hloop η).1, (fact_6j_two_mul hV hE hloop η).2]

/-! ## Lemma 2.2 -/

/-- **Lemma 2.2.** *The system (4) has a solution.*

That is, for a finite loopless cubic multigraph `G` carrying a nowhere-zero `Γ`-flow `f` and a
local ordering — packaged as a `LocalShift G` with `S.flow = f` — the system

  `t_u + t_v + ε_e f(e) = d_e`   (`e = uv`),      `d_e = g_{u,e} + g_{v,e}`,   (4)

is solvable for `t : V(G) → Γ` and `ε : E(G) → 𝔽₂`.  By the duality criterion (Fact 6a) this
follows from equation (6) (`fact_6j`) via Fact 6d. -/
theorem lemma_2_2 (hV : V(G).Finite) (hE : E(G).Finite) (hloop : G.IsLoopless)
    (hcubic : G.IsCubic) (O : Orientation G) (S : LocalShift G) (hf : G.IsFlow O S.flow)
    (hnz : G.IsNowhereZero S.flow) :
    (SystemL.ofLocalShift S).HasSolution := by
  apply fact_6d hV hE (SystemL.ofLocalShift S)
  intro η h5
  rw [SystemL.ofLocalShift_flow] at h5
  show dualPairing η (SystemL.ofLocalShift S).rhsOn = 0
  rw [SystemL.rhsOn, SystemL.ofLocalShift_rhs, dualPairing_restrict]
  exact fact_6j hV hE hloop hcubic O S hf hnz η h5

end Workspace.Facts.Duality



open Graph
open scoped Graph
open Workspace.Types.Gamma Workspace.Types.Orientation
open Workspace.Types.LocalOrdering Workspace.Types.LocalShift Workspace.Types.SystemL

namespace Workspace.MainTheorem

variable {α β : Type*} {G : Graph α β} {P : β → Set Gamma} {v : α}

private theorem cubic_case_aux (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (hloop : G.IsLoopless) (hcubic : G.IsCubic) (hbr : G.Bridgeless) :
    G.HasCycleDoubleCover := by
  classical
  rcases Set.eq_empty_or_nonempty (V(G)) with hVe | ⟨v₀, hv₀⟩
  · have hEempty : E(G) = ∅ := by
      rw [Set.eq_empty_iff_forall_notMem]
      intro e he
      obtain ⟨x, y, hxy⟩ := Graph.exists_isLink_of_mem_edgeSet he
      have hx := hxy.left_mem
      rw [hVe] at hx
      exact absurd hx (Set.notMem_empty x)
    exact (Graph.isCycleDoubleCover_zero_iff.2 hEempty).hasCycleDoubleCover
  · haveI : Nonempty α := ⟨v₀⟩
    haveI : Nonempty β := nonempty_edgeType_of_isCubic hcubic hv₀
    obtain ⟨O⟩ := Orientation.exists_orientation G
    obtain ⟨ord⟩ := exists_localOrdering hloop hcubic
    obtain ⟨f, hf, hnz⟩ :=
      Workspace.PriorWork.kilpatrick_jaeger_nowhere_zero_gamma_flow G hV hE hbr O
    let S : LocalShift G := ⟨f, ord⟩
    have hSflow : S.flow = f := rfl
    have hfS : G.IsFlow O S.flow := by rw [hSflow]; exact hf
    have hnzS : G.IsNowhereZero S.flow := by rw [hSflow]; exact hnz
    have hsol := Workspace.Facts.Duality.lemma_2_2 hV hE hloop hcubic O S hfS hnzS
    rw [SystemL.hasSolution_def] at hsol
    obtain ⟨t, ε, hEq⟩ := hsol
    have h4 : ∀ e ∈ E(G), ∀ u w, G.IsLink e u w →
        t u + t w + ε e • S.flow e = S.d e := by
      intro e he u w huw
      have hne : u ≠ w := (Graph.isLoopless_iff_forall_isLink_ne.1 hloop) e u w huw
      have key := hEq e he
      rw [LocalShift.setOf_inc_eq_pair huw, finsum_mem_pair hne,
        SystemL.ofLocalShift_flow, SystemL.ofLocalShift_rhs] at key
      exact key
    obtain ⟨-, hP_build⟩ :=
      Workspace.Facts.Construction.fact_5d hV hE hloop hcubic O S hfS hnzS t ε h4
    let Pfun : β → Set Gamma := fun e =>
      if he : e ∈ E(G) then
        {t (Graph.exists_isLink_of_mem_edgeSet he).choose
            + S.g (Graph.exists_isLink_of_mem_edgeSet he).choose e,
          t (Graph.exists_isLink_of_mem_edgeSet he).choose
            + S.g (Graph.exists_isLink_of_mem_edgeSet he).choose e + S.flow e}
      else ∅
    have hPspec : ∀ e ∈ E(G), ∃ z, G.Inc e z ∧
        Pfun e = {t z + S.g z e, t z + S.g z e + S.flow e} := by
      intro e he
      refine ⟨(Graph.exists_isLink_of_mem_edgeSet he).choose, ?_, ?_⟩
      · exact (Graph.exists_isLink_of_mem_edgeSet he).choose_spec.choose_spec.inc_left
      · simp only [Pfun, dif_pos he]
    have hP : G.IsTwoElementAssignment Pfun := hP_build Pfun hPspec
    exact Workspace.Facts.Lemma21.lemma_2_1 hV hE hloop hcubic hP

theorem theorem_1_1 (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (hG : G.Bridgeless) :
    G.HasCycleDoubleCover := by
  exact Workspace.PriorWork.jaeger_cubic_reduction
    (fun α β G hV hE hloop hcubic hbr => cubic_case_aux G hV hE hloop hcubic hbr)
    α β G hV hE hG

theorem theorem_1_1_cubic_case (G : Graph α β) (hV : V(G).Finite) (hE : E(G).Finite)
    (hloop : G.IsLoopless) (hcubic : G.IsCubic) (hbr : G.Bridgeless) :
    G.HasCycleDoubleCover := by
  exact cubic_case_aux G hV hE hloop hcubic hbr

theorem theorem_1_1_of_cubic_case.{u, v}
    (H : ∀ (α : Type u) (β : Type v) (G : Graph α β),
      V(G).Finite → E(G).Finite → G.IsLoopless → G.IsCubic → G.Bridgeless →
        G.HasCycleDoubleCover) :
    ∀ (α : Type u) (β : Type v) (G : Graph α β),
      V(G).Finite → E(G).Finite → G.Bridgeless → G.HasCycleDoubleCover := by
  exact Workspace.PriorWork.jaeger_cubic_reduction H

end Workspace.MainTheorem
