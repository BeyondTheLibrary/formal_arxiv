# Shared guide for theorem-statement formalizers (Refuting the Direct Sum Conjecture)

You are writing **faithful Lean 4 theorem STATEMENTS** with bodies `:= by sorry`. Do NOT prove
anything. Every theorem body is `:= by sorry`. The goal is that each statement is a tight, faithful
rendering of the paper's claim, type-checking against the accepted types below. The file must
COMPILE (only `sorry` warnings allowed). Use `numina-lean` `lean_diagnostic_messages` to verify.
Read `/cmlscratch/asoltan3/goedel-agent/theorems/Refuting/lean_knowledge.md` first; append genuine
discoveries after. Never copy-paste a type definition — always `import` it. Do not edit type files.

## Accepted types (import `Workspace.Types.<Name>`; you may `open Workspace.Types.<Name>`)

- **Protocol**: `inductive Protocol (X Y Z : Type*)`; `Protocol.cost : Protocol X Y Z → ℕ`;
  `Protocol.eval : Protocol X Y Z → X → Y → Z`; `Protocol.Computes (P) (f) : Prop`.
- **CommComplexity**: `noncomputable def D {X Y Z : Type*} [Fintype X] [Fintype Y] (f : X → Y → Z) : ℕ`
  — deterministic communication complexity (minimum protocol depth computing `f`).
- **BoolMat**: `structure BoolMat where (m : ℕ) (n : ℕ) (e : Fin m → Fin n → Bool)`;
  `BoolMat.transpose : BoolMat → BoolMat`; `BoolMat.toFun (M) : Fin M.m → Fin M.n → Bool := M.e`.
- **MatComplexity**: `noncomputable def Dmat (M : BoolMat) : ℕ := D M.e`;
  `noncomputable def DSet (Φ : Set BoolMat) : ℕ` — minimum `Dmat` over `Φ` (i.e. `D(Φ)`).
- **Interlace**: `def interlace (A : BoolMat) (p : ℕ) : BoolMat` (= `⟨A⟩^p`, dims `A.m*p × A.n^p`);
  `def interlaceFun {X Y : Type*} (f : X → Y → Bool) (k : ℕ) : (Fin k × X) → (Fin k → Y) → Bool`
  (= `⟨f⟩^k`, value `f x (y component)`).
- **AlternatingGame**: `def phi (B : ℕ) : ℕ → BoolMat`
  (`phi B 0` = the 1×2 matrix `[1 0]`; `phi B (i+1) = (interlace (phi B i) B).transpose`).
- **Subgame**: `def IsSubgame (A B : BoolMat) : Prop` (A ⊑ B: a copy of A sits inside B via
  injective row/col selections); `def IsSubgameSet (Φ' Φ : Set BoolMat) : Prop`
  (`∀ M ∈ Φ, ∃ M' ∈ Φ', IsSubgame M' M`).
- **Extract**: `def extract (A : BoolMat) (R C : Finset ℕ) : BoolMat` (= `ε(A,R,C)`, dims `R.card × C.card`,
  sorted-order submatrix).
- **Equipartition**: `def IsEquipartitioned (R : Finset ℕ) (m : ℕ) (T : ℝ) (p : ℕ) : Prop`
  (each of the `p` blocks `[m·γ, m·(γ+1))` has exactly `⌈T⌉₊` elements of R).
- **QProjection**: `def digit (c n q : ℕ) : ℕ := (c / n^q) % n`;
  `def qProjection (R C : Finset ℕ) (m n p : ℕ) (Q : Finset ℕ) : Finset ℕ × Finset ℕ`
  (the Q-projection `(S,D)`).
- **Bracket**: `def bracket (M : BoolMat) (p : ℕ) (x y : ℝ) : Set BoolMat` (= `[M]_{p,x,y}`).
- **DirectSum**: `def directSum {X Y : Type*} (f : X → Y → Bool) (l : ℕ) : (Fin l → X) → (Fin l → Y) → (Fin l → Bool)`
  (= `f^l`).
- **Lambda**: `noncomputable def Lambda (M : BoolMat) (p : ℕ) (x y : ℝ) : ℕ` (= `Λ_M(p,x,y)`).

## Modeling conventions (use EXACTLY these renderings)

- `D(M)` for `M : BoolMat` ⟶ `Dmat M`.   `D(Φ)` for `Φ : Set BoolMat` ⟶ `DSet Φ`.
- `D([M]_{p,x,y})` ⟶ `DSet (bracket M p x y)`.   `Λ_M(p,x,y)` ⟶ `Lambda M p x y`.
- `D(f^l)` for a function `f : X → Y → Bool` ⟶ `D (directSum f l)`.
- `D(φ_i^l)` ⟶ `D (directSum (phi B i).e l)`  (the matrix's entry function `(phi B i).e`).
- `D((⟨f⟩^κ)^l)` ⟶ `D (directSum (interlaceFun f κ) l)`.
- transpose `Mᵀ` ⟶ `M.transpose`.   `⟨M⟩^p` ⟶ `interlace M p`.   `ε(A,R,C)` ⟶ `extract A R C`.
- `φ_i` ⟶ `phi B i`.   `⟨A⟩^{|Q|}` ⟶ `interlace A Q.card`.
- The paper fixes `B = Q = 255·2^{k-8}`, `k = 10000`, `a = 10` from Section 4 onward. For
  φ-specific lemmas, introduce at file scope:
  `private abbrev kk : ℕ := 10000`, `private abbrev aa : ℕ := 10`,
  `private abbrev Q : ℕ := 255 * 2 ^ (10000 - 8)`, and use `phi Q i`.
- Reals: parameters `x, y ∈ (0,1]` are `ℝ`. **Real powers with a real/rational exponent**
  (e.g. `y^a`, `y^{ρ^s}`, `y^{ℓ/p}`) use `Real.rpow` — write `Real.rpow y a` (the `^` operator is
  natural-power and is WRONG for these). `log` is base 2: `Real.logb 2 _`. `√` is `Real.sqrt`.
  Natural-number ceiling `⌈t⌉` (for a count or a quantity added to a `ℕ`-valued `D`) is
  `⌈t⌉₊ = Nat.ceil t`; floor is `⌊t⌋₊ = Nat.floor t`. (Use `Int.floor`/`Int.ceil` only if a value
  can be negative — here the floored/ceiled quantities are non-negative, so `Nat.floor`/`Nat.ceil`.)
- `|R|` (a cardinality) ⟶ `R.card : ℕ`; when compared to a real expression, cast `(R.card : ℝ)`.
- Preserve EVERY hypothesis of the paper's statement (sign/range conditions like `0 < x`,
  `x ≤ 1`, `1 ≤ p`, `δ ∈ {0,1}` rendered as `δ = 0 ∨ δ = 1` or `δ ≤ 1`, divisibility, etc.).
- For lemmas quantified "for any `m × n` matrix A", quantify over `A : BoolMat` (its dims are
  `A.m`, `A.n`). For results about a generic matrix `M`, quantify over `M : BoolMat`.
- `D(f^l) = D((fᵀ)^l)` style transposed-direct-sum: render `(fᵀ)^l` as
  `directSum (fun y x => f x y) l` (the swapped function).

## Output requirements
- One `theorem` per paper result, body `:= by sorry`, with a short doc-comment naming the paper
  result (e.g. `/-- Theorem 5.7 (One-Round Upper Bound). -/`).
- Keep names descriptive and unique within the file.
- Make sure `[Fintype X] [Fintype Y]` instances are present wherever `D` is applied to a function
  over abstract `X Y`.
- Verify the file compiles (no errors; `sorry` warnings OK) before reporting the path.
