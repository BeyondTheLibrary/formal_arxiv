import Mathlib
import Workspace.Types.BoolMat
import Workspace.Types.Interlace
import Workspace.Types.Subgame
import Workspace.Types.Extract
import Workspace.Types.Equipartition
import Workspace.Types.QProjection

open Workspace.Types.BoolMat
open Workspace.Types.Interlace
open Workspace.Types.Subgame
open Workspace.Types.Extract
open Workspace.Types.Equipartition
open Workspace.Types.QProjection

namespace Workspace.Projections

/-- Theorem 3.18 (Product Theorem — Chung 1986, EXTERNAL).
Let `U` be a finite set and `A_1,…,A_p ⊆ U` such that every element of `U` lies in at
least `k` of them. Let `F` be a family of subsets of `U` and `F_i = { F ∩ A_i : F ∈ F }`.
Then `|F|^k ≤ ∏_{i=1}^p |F_i|`. -/
theorem product_theorem
    {U : Type*} [Fintype U] [DecidableEq U] {p : ℕ}
    (A : Fin p → Finset U) (k : ℕ) (hk : 0 < k)
    (hcover : ∀ u : U, k ≤ (Finset.univ.filter (fun i => u ∈ A i)).card)
    (F : Finset (Finset U)) :
    (F.card) ^ k ≤ ∏ i, (F.image (· ∩ A i)).card := by
  sorry

/-- Corollary 3.19.
Let `U = [n] × [p]` and `F` a family of subsets of `U`. For any integer `1 ≤ ℓ ≤ p`
there exists `Q ⊆ [p]` with `|Q| = ℓ` such that `|F|^{ℓ/p} ≤ |F_Q|`, where
`F_Q = { F ∩ ([n] × Q) : F ∈ F }`, modeled as keeping pairs whose second coordinate
lies in `Q`. -/
theorem corollary_3_19
    {n p : ℕ} (F : Finset (Finset (Fin n × Fin p)))
    (ℓ : ℕ) (hℓ1 : 1 ≤ ℓ) (hℓp : ℓ ≤ p) :
    ∃ Q : Finset (Fin p), Q.card = ℓ ∧
      (F.card : ℝ) ^ ((ℓ : ℝ) / (p : ℝ)) ≤
        ((F.image (fun S => S.filter (fun z => z.2 ∈ Q))).card : ℝ) := by
  sorry

/-- Lemma 3.16 (Projection Lemma).
For any `m × n` matrix `A`, positive integer `p`, and selections `R ⊆ [m·p)`,
`C ⊆ [n^p)`, if `Q ⊆ [p)` is non-empty with Q-projection `(S, D)`, then
`ε(⟨A⟩^{|Q|}, S, D) ⊑ ε(⟨A⟩^p, R, C)`. -/
theorem projection_lemma
    (A : BoolMat) (p : ℕ)
    (R C : Finset ℕ)
    (hR : R ⊆ Finset.range (A.m * p))
    (hC : C ⊆ Finset.range (A.n ^ p))
    (Q : Finset ℕ)
    (hQ : Q ⊆ Finset.range p) (hQne : Q.Nonempty) :
    IsSubgame
      (extract (interlace A Q.card)
        (qProjection R C A.m A.n p Q).1 (qProjection R C A.m A.n p Q).2)
      (extract (interlace A p) R C) := by
  sorry

/-- Lemma 3.20 (Balancing Lemma).
For any `m × n` matrix `A`, positive integer `p`, selections `R ⊆ [m·p)`, `C ⊆ [n^p)`,
and any real `0 ≤ T < m` with `p·T ≤ |R|`, there exist `ℓ`, `S ⊆ [m·ℓ)`, `D ⊆ [n^ℓ)` with
`ℓ = ⌈ p·(1 − (1 − |R|/(p·m))/(1 − T/m)) ⌉`, such that `S` is `m,T,ℓ`-equipartitioned
whenever `ℓ ≥ 1`, `|D| ≥ |C| / n^{p-ℓ}`, and `ε(⟨A⟩^ℓ, S, D) ⊑ ε(⟨A⟩^p, R, C)`. -/
theorem balancing_lemma
    (A : BoolMat) (p : ℕ)
    (R C : Finset ℕ)
    (hR : R ⊆ Finset.range (A.m * p))
    (hC : C ⊆ Finset.range (A.n ^ p))
    (T : ℝ) (hT0 : 0 ≤ T) (hTm : T < A.m)
    (hRT : (p : ℝ) * T ≤ (R.card : ℝ)) :
    ∃ (ℓ : ℕ) (S D : Finset ℕ),
      S ⊆ Finset.range (A.m * ℓ) ∧ D ⊆ Finset.range (A.n ^ ℓ) ∧
      (ℓ : ℝ) = ⌈(p : ℝ) * (1 - (1 - (R.card : ℝ) / ((p : ℝ) * (A.m : ℝ)))
                  / (1 - T / (A.m : ℝ)))⌉₊ ∧
      (1 ≤ ℓ → IsEquipartitioned S A.m T ℓ) ∧
      (D.card : ℝ) ≥ (C.card : ℝ) / (A.n : ℝ) ^ (p - ℓ) ∧
      IsSubgame (extract (interlace A ℓ) S D) (extract (interlace A p) R C) := by
  sorry

/-- Lemma 3.21 (Product of Projections Lemma).
For any `m × n` matrix `A`, positive integer `p`, an `m,T,p`-equipartitioned `R ⊆ [m·p)`,
and `C ⊆ [n^p)`, for any partition `R = R₁ ∪ R₂` we can write `p = ℓ₁ + ℓ₂` such that there
exist `S₁ S₂ ⊆ ...`, `D₁ D₂ ⊆ ...` with `|D₁|·|D₂| ≥ |C|`, and for each `i ∈ {1,2}`:
whenever `ℓᵢ ≥ 1`, `Sᵢ` is `m, T/2, ℓᵢ`-equipartitioned and
`ε(⟨A⟩^{ℓᵢ}, Sᵢ, Dᵢ) ⊑ ε(⟨A⟩^p, Rᵢ, C)`. -/
theorem product_of_projections_lemma
    (A : BoolMat) (p : ℕ) (T : ℝ)
    (R C : Finset ℕ)
    (hR : R ⊆ Finset.range (A.m * p))
    (hRep : IsEquipartitioned R A.m T p)
    (hC : C ⊆ Finset.range (A.n ^ p))
    (R₁ R₂ : Finset ℕ) (hRpart : R₁ ∪ R₂ = R) (hRdisj : Disjoint R₁ R₂) :
    ∃ (ℓ₁ ℓ₂ : ℕ) (S₁ S₂ D₁ D₂ : Finset ℕ),
      ℓ₁ + ℓ₂ = p ∧
      D₁.card * D₂.card ≥ C.card ∧
      (1 ≤ ℓ₁ → S₁ ⊆ Finset.range (A.m * ℓ₁) ∧ D₁ ⊆ Finset.range (A.n ^ ℓ₁) ∧
        IsEquipartitioned S₁ A.m (T / 2) ℓ₁ ∧
        IsSubgame (extract (interlace A ℓ₁) S₁ D₁) (extract (interlace A p) R₁ C)) ∧
      (1 ≤ ℓ₂ → S₂ ⊆ Finset.range (A.m * ℓ₂) ∧ D₂ ⊆ Finset.range (A.n ^ ℓ₂) ∧
        IsEquipartitioned S₂ A.m (T / 2) ℓ₂ ∧
        IsSubgame (extract (interlace A ℓ₂) S₂ D₂) (extract (interlace A p) R₂ C)) := by
  sorry

/-- Lemma 3.22 (Maximum Projection Lemma).
For any `m × n` matrix `A`, positive integer `p`, an `m,T,p`-equipartitioned `R ⊆ [m·p)`,
and `C ⊆ [n^p)`, for any integer `1 ≤ ℓ < p` there exist `S ⊆ [m·ℓ)`, `D ⊆ [n^ℓ)` such that
`S` is `m,T,ℓ`-equipartitioned, `|D| ≥ |C|^{ℓ/p}`, and
`ε(⟨A⟩^ℓ, S, D) ⊑ ε(⟨A⟩^p, R, C)`. -/
theorem maximum_projection_lemma
    (A : BoolMat) (p : ℕ) (T : ℝ)
    (R C : Finset ℕ)
    (hR : R ⊆ Finset.range (A.m * p))
    (hRep : IsEquipartitioned R A.m T p)
    (hC : C ⊆ Finset.range (A.n ^ p))
    (ℓ : ℕ) (hℓ1 : 1 ≤ ℓ) (hℓp : ℓ < p) :
    ∃ (S D : Finset ℕ),
      S ⊆ Finset.range (A.m * ℓ) ∧
      D ⊆ Finset.range (A.n ^ ℓ) ∧
      IsEquipartitioned S A.m T ℓ ∧
      (D.card : ℝ) ≥ Real.rpow (C.card : ℝ) ((ℓ : ℝ) / (p : ℝ)) ∧
      IsSubgame (extract (interlace A ℓ) S D) (extract (interlace A p) R C) := by
  sorry

end Workspace.Projections
