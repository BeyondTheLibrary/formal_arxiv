import Mathlib
import Workspace.Types.BoolMat
import Workspace.Types.MatComplexity
import Workspace.Types.Interlace
import Workspace.Types.AlternatingGame
import Workspace.Types.Bracket
import Workspace.Types.Lambda

open Workspace.Types.BoolMat
open Workspace.Types.MatComplexity
open Workspace.Types.Interlace
open Workspace.Types.AlternatingGame
open Workspace.Types.Bracket
open Workspace.Types.Lambda

/-- The paper fixes `k = 10000`. -/
private abbrev kk : ℕ := 10000

/-- The paper fixes `a = 10`. -/
private abbrev aa : ℕ := 10

/-- The paper fixes `B = Q = 255 · 2^{k-8}` with `k = 10000`. -/
private abbrev Q : ℕ := 255 * 2 ^ (10000 - 8)

namespace Workspace.PhiBase

/-- Lemma 4.15 (Rank claim — uses the external log-rank lower bound).
For naturals `p` and reals `0 < x ≤ 1`, `0 < y ≤ 1` with `p + log₂ y > 0`,
`D([φ_0]_{p,x,y}) ≥ ⌈ log₂(p + log₂ y) ⌉`. Both logs are base 2. -/
theorem rank_claim
    (p : ℕ) (x y : ℝ)
    (hx0 : 0 < x) (hx1 : x ≤ 1) (hy0 : 0 < y) (hy1 : y ≤ 1)
    (hpos : (p : ℝ) + Real.logb 2 y > 0) :
    DSet (bracket (phi Q 0) p x y)
      ≥ ⌈Real.logb 2 ((p : ℝ) + Real.logb 2 y)⌉₊ := by
  sorry

/-- Lemma 4.16 (`φ_0` seed).
Let `Qp` be a positive integer, `0 < θ ≤ 1`, `0 < y ≤ 1`, `0 < x ≤ 1`, and
`q = ⌊Qp·θ⌋`. If `q ≥ 1`, then `D([⟨φ_0⟩^{Qp}]_{1,θ,y}) ≥ D([φ_0]_{q,x,y})`. -/
theorem phi_zero_seed
    (Qp : ℕ) (hQp : 0 < Qp)
    (θ y x : ℝ)
    (hθ0 : 0 < θ) (hθ1 : θ ≤ 1) (hy0 : 0 < y) (hy1 : y ≤ 1)
    (hx0 : 0 < x) (hx1 : x ≤ 1)
    (hq : 1 ≤ ⌊(Qp : ℝ) * θ⌋₊) :
    DSet (bracket (interlace (phi Q 0) Qp) 1 θ y)
      ≥ DSet (bracket (phi Q 0) (⌊(Qp : ℝ) * θ⌋₊) x y) := by
  sorry

/-- Lemma 4.17 (`φ_1` weak side condition).
For `k = 10000`, `a = 10`: `D([φ_1]_{1, 2^{-k-a}, 2^{-3}}) ≥ 1`. -/
theorem phi_one_weak_side_condition :
    DSet (bracket (phi Q 1) 1
      (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3))) ≥ 1 := by
  sorry

/-- Lemma 4.19 (`φ_1` lambda).
For `k = 10000`, `a = 10`: `Λ_{φ_1}(1, 2^{-k-a}, 2^{-3/8}) ≥ k`. -/
theorem phi_one_lambda :
    Lambda (phi Q 1) 1
      (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3 / 8)) ≥ 10000 := by
  sorry

end Workspace.PhiBase
