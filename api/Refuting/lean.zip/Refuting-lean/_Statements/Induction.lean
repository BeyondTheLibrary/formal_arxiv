import Mathlib
import Workspace.Types.BoolMat
import Workspace.Types.MatComplexity
import Workspace.Types.Bracket
import Workspace.Types.Lambda
import Workspace.Types.Interlace

namespace Workspace.Induction

open Workspace.Types.BoolMat
open Workspace.Types.MatComplexity
open Workspace.Types.Bracket
open Workspace.Types.Lambda
open Workspace.Types.Interlace

/-- **Lemma 4.8 (Iterated Partition Lemma).**
Let `2 < ρ`, `β := (ρ−1)/(ρ−2)`.  For any matrix `M`, integers `0 ≤ s ≤ k`,
integer `p ≥ 1`, reals `0 < x ≤ 2^{-k}`, `0 < y ≤ 1`, if
`D([M]_{p, x, y/4}) ≥ 1` and `(ρ−1)^k ≤ ρ^{k−s}`, then both
`Λ_M(⌊2^k β^s p⌋, 2^k x, y^{ρ^s}) ≥ k + Λ_M(p, x, y)` and
`D([M]_{⌊2^k β^s p⌋, 2^k x, y^{ρ^s}}) ≥ k + Λ_M(p, x, y)`. -/
theorem lemma_4_8_iterated_partition
    (ρ : ℝ) (hρ : 2 < ρ)
    (β : ℝ) (hβ : β = (ρ - 1) / (ρ - 2))
    (M : BoolMat) (s k : ℕ) (hsk : s ≤ k)
    (p : ℕ) (hp : 1 ≤ p)
    (x y : ℝ)
    (hx0 : 0 < x) (hxk : x ≤ Real.rpow 2 (-(k : ℝ)))
    (hy0 : 0 < y) (hy1 : y ≤ 1)
    (hseed : DSet (bracket M p x (y / 4)) ≥ 1)
    (hrung : Real.rpow (ρ - 1) (k : ℝ) ≤ Real.rpow ρ ((k : ℝ) - (s : ℝ))) :
    Lambda M
        (⌊Real.rpow 2 (k : ℝ) * Real.rpow β (s : ℝ) * (p : ℝ)⌋₊)
        (Real.rpow 2 (k : ℝ) * x)
        (Real.rpow y (Real.rpow ρ (s : ℝ)))
      ≥ k + Lambda M p x y
    ∧ DSet (bracket M
        (⌊Real.rpow 2 (k : ℝ) * Real.rpow β (s : ℝ) * (p : ℝ)⌋₊)
        (Real.rpow 2 (k : ℝ) * x)
        (Real.rpow y (Real.rpow ρ (s : ℝ))))
      ≥ k + Lambda M p x y := by
  sorry

/-- **Corollary 4.9 (Iterated partition seed).**
Under the hypotheses of Lemma 4.8, if for some real `H`,
`D([M]_{p,x,y}) ≥ H`, `D([M]_{p,x,y/2}) ≥ H−1`, `D([M]_{p,x,y/4}) ≥ H−2`, then
`D([M]_{⌊2^k β^s p⌋, 2^k x, y^{ρ^s}}) ≥ k + H`. -/
theorem cor_4_9_iterated_partition_seed
    (ρ : ℝ) (hρ : 2 < ρ)
    (β : ℝ) (hβ : β = (ρ - 1) / (ρ - 2))
    (M : BoolMat) (s k : ℕ) (hsk : s ≤ k)
    (p : ℕ) (hp : 1 ≤ p)
    (x y : ℝ)
    (hx0 : 0 < x) (hxk : x ≤ Real.rpow 2 (-(k : ℝ)))
    (hy0 : 0 < y) (hy1 : y ≤ 1)
    (hseed : DSet (bracket M p x (y / 4)) ≥ 1)
    (hrung : Real.rpow (ρ - 1) (k : ℝ) ≤ Real.rpow ρ ((k : ℝ) - (s : ℝ)))
    (H : ℝ)
    (hH0 : (DSet (bracket M p x y) : ℝ) ≥ H)
    (hH1 : (DSet (bracket M p x (y / 2)) : ℝ) ≥ H - 1)
    (hH2 : (DSet (bracket M p x (y / 4)) : ℝ) ≥ H - 2) :
    (DSet (bracket M
        (⌊Real.rpow 2 (k : ℝ) * Real.rpow β (s : ℝ) * (p : ℝ)⌋₊)
        (Real.rpow 2 (k : ℝ) * x)
        (Real.rpow y (Real.rpow ρ (s : ℝ)))) : ℝ)
      ≥ (k : ℝ) + H := by
  sorry

/-- **Lemma 4.10 (Seed collapse).**
For a matrix `M`, `3/8 < a`, integer `k ≥ 5`, if
`D([M]_{1, 2^{-k-a}, 2^{-3}}) ≥ 1`, then
`Λ_M(6, 2^{3-k-a}, 2^{-1}) ≥ 3 + Λ_M(1, 2^{-k-a}, 2^{-3/8})`. -/
theorem lemma_4_10_seed_collapse
    (M : BoolMat) (a : ℝ) (ha : 3 / 8 < a)
    (k : ℕ) (hk : 5 ≤ k)
    (hseed : DSet (bracket M 1
        (Real.rpow 2 (-(k : ℝ) - a)) (Real.rpow 2 (-3))) ≥ 1) :
    Lambda M 6 (Real.rpow 2 ((3 : ℝ) - (k : ℝ) - a)) (Real.rpow 2 (-1))
      ≥ 3 + Lambda M 1 (Real.rpow 2 (-(k : ℝ) - a)) (Real.rpow 2 (-3 / 8)) := by
  sorry

/-- **Theorem 4.11 (Induction step in `k`).**
For any `3/8 < a` and integer `5 ≤ k` with
`√(k+a) − 1 ≤ (k+a)^{1/2 − 1/(k−3)}`, set
`Q_k := ⌈ 2^k · (3·2^a − 3)/(2^{13/8}·2^a − 4) · ((√(k+a)−1)/(√(k+a)−2))^2 ⌉`.
For any matrix `M` with `m·2^{-a} ∈ ℕ`, if
`D([M]_{1, 2^{-k-a}, 2^{-3}}) ≥ 1`, then
`D([⟨M⟩^{Q_k}]_{1, 2^{-3/8}, 2^{-k-a}}) ≥ k + Λ_M(1, 2^{-k-a}, 2^{-3/8})`. -/
theorem thm_4_11_induction_step
    (a : ℝ) (ha : 3 / 8 < a)
    (k : ℕ) (hk : 5 ≤ k)
    (hside : Real.sqrt ((k : ℝ) + a) - 1
        ≤ Real.rpow ((k : ℝ) + a) (1 / 2 - 1 / ((k : ℝ) - 3)))
    (M : BoolMat)
    (hdiv : ∃ t : ℕ, (M.m : ℝ) * Real.rpow 2 (-a) = (t : ℝ))
    (hseed : DSet (bracket M 1
        (Real.rpow 2 (-(k : ℝ) - a)) (Real.rpow 2 (-3))) ≥ 1) :
    let Q_k : ℕ := ⌈Real.rpow 2 (k : ℝ)
        * ((3 * Real.rpow 2 a - 3) / (Real.rpow 2 (13 / 8) * Real.rpow 2 a - 4))
        * ((Real.sqrt ((k : ℝ) + a) - 1) / (Real.sqrt ((k : ℝ) + a) - 2)) ^ 2⌉₊
    DSet (bracket (interlace M Q_k) 1
        (Real.rpow 2 (-3 / 8)) (Real.rpow 2 (-(k : ℝ) - a)))
      ≥ k + Lambda M 1 (Real.rpow 2 (-(k : ℝ) - a)) (Real.rpow 2 (-3 / 8)) := by
  sorry

end Workspace.Induction
