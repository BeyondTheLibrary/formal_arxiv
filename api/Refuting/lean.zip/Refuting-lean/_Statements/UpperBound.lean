import Mathlib
import Workspace.Types.CommComplexity
import Workspace.Types.DirectSum
import Workspace.Types.Interlace
import Workspace.Types.AlternatingGame
import Workspace.Types.BoolMat

namespace Workspace.UpperBound

open Workspace.Types.CommComplexity
open Workspace.Types.DirectSum
open Workspace.Types.Interlace
open Workspace.Types.AlternatingGame
open Workspace.Types.BoolMat

/-- The fixed parameter `Q = 255 · 2^(k-8)` with `k = 10000`, used from Section 4
onward (where `B := Q := 255·2^{k-8}`). -/
private abbrev Q : ℕ := 255 * 2 ^ (10000 - 8)

/-- **Observation 5.2.** The deterministic communication complexity of the
direct sum `f^l` equals that of the direct sum of the transposed function
`(fᵀ)^l`: `D(f^l) = D((fᵀ)^l)`. -/
theorem observation_5_2 {X Y : Type*} [Fintype X] [Fintype Y]
    (f : X → Y → Bool) (l : ℕ) :
    D (directSum f l) = D (directSum (fun (y : Y) (x : X) => f x y) l) := by
  sorry

/-- **Lemma 5.6 (Subgame Lemma).** With Alice's interlaced inputs `xs i`
carrying component `(xs i).1 = u i` and data `(xs i).2`, the interlaced direct
sum equals the original direct sum evaluated at `σ x = fun i => (xs i).2` and
`τ_u y = fun i => ys i (u i)`:
`(⟨f⟩^κ)^l(x, y) = f^l(σ x, τ_u y)`. -/
theorem subgame_lemma_5_6 {X Y : Type*}
    (f : X → Y → Bool) (κ l : ℕ) (u : Fin l → Fin κ)
    (xs : Fin l → (Fin κ × X)) (ys : Fin l → (Fin κ → Y))
    (hu : ∀ i, (xs i).1 = u i) :
    directSum (interlaceFun f κ) l xs ys
      = directSum f l (fun i => (xs i).2) (fun i => ys i (u i)) := by
  sorry

/-- **Theorem 5.7 (One-Round Upper Bound).**
`D((⟨f⟩^κ)^l) ≤ D(f^l) + ⌈l · log₂ κ⌉`. -/
theorem one_round_upper_bound_5_7 {X Y : Type*} [Fintype X] [Fintype Y]
    (f : X → Y → Bool) (κ l : ℕ) :
    D (directSum (interlaceFun f κ) l)
      ≤ D (directSum f l) + ⌈(l : ℝ) * Real.logb 2 (κ : ℝ)⌉₊ := by
  sorry

/-- **Corollary 5.8 (Upper bound on the direct sum of `φ_i`).**
For `k = 10000`, any `i ≥ 0`, and any `h ≥ 1`:
`D(φ_i^{178h}) ≤ 178h + i·(178·k·h − h)`. -/
theorem upper_bound_directSum_phi_5_8 (i h : ℕ) (hh : 1 ≤ h) :
    D (directSum (phi Q i).e (178 * h))
      ≤ 178 * h + i * (178 * 10000 * h - h) := by
  sorry

end Workspace.UpperBound
