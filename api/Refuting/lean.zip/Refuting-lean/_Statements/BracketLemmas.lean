import Mathlib
import Workspace.Types.BoolMat
import Workspace.Types.Interlace
import Workspace.Types.Extract
import Workspace.Types.Subgame
import Workspace.Types.MatComplexity
import Workspace.Types.Bracket

namespace Workspace.BracketLemmas

open Workspace.Types.BoolMat
open Workspace.Types.Interlace
open Workspace.Types.Extract
open Workspace.Types.Subgame
open Workspace.Types.MatComplexity
open Workspace.Types.Bracket

/-- **Lemma 4.2 (Monotonicity Lemma).**  For an `m × n` matrix `M`, integers
`1 ≤ p' ≤ p`, and reals `0 < x' ≤ x ≤ 1`, `0 < y' ≤ y ≤ 1`:
`D([M]_{p',x',y'}) ≤ D([M]_{p,x,y})`. -/
theorem monotonicity (M : BoolMat) (p' p : ℕ) (x' x y' y : ℝ)
    (hp' : 1 ≤ p') (hpp : p' ≤ p)
    (hx'0 : 0 < x') (hx'x : x' ≤ x) (hx1 : x ≤ 1)
    (hy'0 : 0 < y') (hy'y : y' ≤ y) (hy1 : y ≤ 1) :
    DSet (bracket M p' x' y') ≤ DSet (bracket M p x y) := by
  sorry

/-- **Lemma 4.3 (Extended Product of Projection Lemma).**  Given
`g = ε(⟨M⟩^p, R, C) ∈ [M]_{p,x,y}` with rows `R`, columns `C`, and a partition
`R = R₁ ∪ R₂`, there exist `ℓ₁, ℓ₂, y₁, y₂, S₁, S₂, D₁, D₂` with `y₁·y₂ ≥ y`,
`ℓ₁ + ℓ₂ = p`, `yᵢ = |Dᵢ| / n^{ℓᵢ}`, and for each `i` with `ℓᵢ ≥ 1`:
`ε(⟨M⟩^{ℓᵢ}, Sᵢ, Dᵢ) ⊑ ε(⟨M⟩^p, Rᵢ, C)` and
`ε(⟨M⟩^{ℓᵢ}, Sᵢ, Dᵢ) ∈ [M]_{ℓᵢ, x/2, yᵢ}`. -/
theorem extended_product_of_projection
    (M : BoolMat) (p : ℕ) (x y : ℝ)
    (hx0 : 0 < x) (hx1 : x ≤ 1) (hy0 : 0 < y) (hy1 : y ≤ 1) (hn : 1 ≤ M.n)
    (R C : Finset ℕ)
    (hR_sub : R ⊆ Finset.range (M.m * p))
    (hR_equi : IsEquipartitioned R M.m ((M.m : ℝ) * x) p)
    (hC_sub : C ⊆ Finset.range (M.n ^ p))
    (hC_card : C.card = ⌈((M.n ^ p : ℕ) : ℝ) * y⌉₊)
    (R₁ R₂ : Finset ℕ) (hR_union : R₁ ∪ R₂ = R) (hR_disj : Disjoint R₁ R₂) :
    ∃ (ℓ₁ ℓ₂ : ℕ) (y₁ y₂ : ℝ) (S₁ S₂ D₁ D₂ : Finset ℕ),
      y₁ * y₂ ≥ y ∧
      ℓ₁ + ℓ₂ = p ∧
      y₁ = (D₁.card : ℝ) / (M.n : ℝ) ^ ℓ₁ ∧
      y₂ = (D₂.card : ℝ) / (M.n : ℝ) ^ ℓ₂ ∧
      y₁ ≤ 1 ∧ y₂ ≤ 1 ∧
      (1 ≤ ℓ₁ →
        IsSubgame (extract (interlace M ℓ₁) S₁ D₁) (extract (interlace M p) R₁ C) ∧
        (extract (interlace M ℓ₁) S₁ D₁) ∈ bracket M ℓ₁ (x / 2) y₁) ∧
      (1 ≤ ℓ₂ →
        IsSubgame (extract (interlace M ℓ₂) S₂ D₂) (extract (interlace M p) R₂ C) ∧
        (extract (interlace M ℓ₂) S₂ D₂) ∈ bracket M ℓ₂ (x / 2) y₂) := by
  sorry

/-- **Lemma 4.4 (Extended Maximum Projection Lemma).**  For all `1 ≤ ℓ ≤ p`:
`D([M]_{p,x,y}) ≥ D([M]_{ℓ, x, y^{ℓ/p}})`. -/
theorem extended_maximum_projection (M : BoolMat) (p ℓ : ℕ) (x y : ℝ)
    (hℓ1 : 1 ≤ ℓ) (hℓp : ℓ ≤ p) (hy0 : 0 < y) :
    DSet (bracket M p x y) ≥
      DSet (bracket M ℓ x (Real.rpow y ((ℓ : ℝ) / (p : ℝ)))) := by
  sorry

/-- **Lemma 4.5 (Extended Balancing Lemma).**  For an `m × n` matrix `M`,
integer `p`, `1 < α`, `0 < x < 1`, `0 < α·x ≤ 1`, `0 < y ≤ 1`, if `m·x ∈ ℕ`
and `p* = ⌊p·(α−1)·x/(1−x)⌋ ≥ 1`, then
`D([⟨M⟩^p]_{1, α·x, y}) ≥ D([M]_{p*, x, y})`. -/
theorem extended_balancing (M : BoolMat) (p : ℕ) (α x y : ℝ)
    (hα : 1 < α) (hx0 : 0 < x) (hx1 : x < 1)
    (hαx0 : 0 < α * x) (hαx1 : α * x ≤ 1)
    (hy0 : 0 < y) (hy1 : y ≤ 1)
    (hmx_int : ∃ t : ℕ, (M.m : ℝ) * x = (t : ℝ))
    (hpstar : ⌊(p : ℝ) * (α - 1) * x / (1 - x)⌋₊ ≥ 1) :
    DSet (bracket (interlace M p) 1 (α * x) y) ≥
      DSet (bracket M (⌊(p : ℝ) * (α - 1) * x / (1 - x)⌋₊) x y) := by
  sorry

/-- **Lemma 4.6 (Transpose of bracket).**  `D([M]_{1,x,y}) = D([Mᵀ]_{1,y,x})`. -/
theorem transpose_bracket (M : BoolMat) (x y : ℝ) :
    DSet (bracket M 1 x y) = DSet (bracket M.transpose 1 y x) := by
  sorry

/-- **Lemma 4.7 (Old Partition Lemma).**  For any matrix `M`, `0 < x ≤ 1/2`,
`0 < y ≤ 1`, and `δ ∈ {0,1}`, if `D([M]_{2p+δ, 2x, y}) ≥ 1`, then
`D([M]_{2p+δ, 2x, y}) ≥ 1 + min A (min B C)` where
`A = D([M]_{2p+δ, x, y})`,
`B = min_{ℓ ∈ [p), a ∈ [0,1]} max(D([M]_{p+δ+ℓ, x, y^a}), D([M]_{p−ℓ, x, y^{1−a}}))`,
`C = D([M]_{2p+δ, 2x, y/2})`. -/
theorem old_partition (M : BoolMat) (p δ : ℕ) (x y : ℝ)
    (hx0 : 0 < x) (hx12 : x ≤ 1 / 2) (hy0 : 0 < y) (hy1 : y ≤ 1)
    (hδ : δ ≤ 1)
    (hpos : DSet (bracket M (2 * p + δ) (2 * x) y) ≥ 1) :
    DSet (bracket M (2 * p + δ) (2 * x) y) ≥
      1 + min (DSet (bracket M (2 * p + δ) x y))
        (min
          (sInf { v : ℕ | ∃ (ℓ : ℕ) (a : ℝ),
              ℓ < p ∧ 0 ≤ a ∧ a ≤ 1 ∧
              v = max (DSet (bracket M (p + δ + ℓ) x (Real.rpow y a)))
                      (DSet (bracket M (p - ℓ) x (Real.rpow y (1 - a)))) })
          (DSet (bracket M (2 * p + δ) (2 * x) (y / 2)))) := by
  sorry

end Workspace.BracketLemmas
