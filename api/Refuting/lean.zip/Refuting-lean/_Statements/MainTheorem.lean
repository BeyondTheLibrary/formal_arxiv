import Mathlib
import Workspace.Types.BoolMat
import Workspace.Types.CommComplexity
import Workspace.Types.MatComplexity
import Workspace.Types.DirectSum
import Workspace.Types.Subgame
import Workspace.Types.AlternatingGame

open Workspace.Types.BoolMat
open Workspace.Types.CommComplexity
open Workspace.Types.MatComplexity
open Workspace.Types.DirectSum
open Workspace.Types.Subgame
open Workspace.Types.AlternatingGame

namespace Workspace.MainTheorem

/-- The fixed parameter `B = Q = 255 · 2^{k-8}` with `k = 10000`, used from Section 4 onward. -/
private abbrev Q : ℕ := 255 * 2 ^ (10000 - 8)

/-- Proposition 2.7 (Complexity Invariant to Transposition).
For any Boolean matrix `M`, `D(Mᵀ) = D(M)`. -/
theorem complexity_invariant_to_transposition (M : BoolMat) :
    Dmat M.transpose = Dmat M := by
  sorry

/-- Proposition 3.11 (Subgames Are Easier).
If `Φ' ⊑ Φ` then `D(Φ') ≤ D(Φ)`. The family `Φ` is assumed nonempty, matching the
paper's `D(Φ) = min_{f ∈ Φ} D(f)`, which is only well-defined for nonempty families. -/
theorem subgames_are_easier (Φ' Φ : Set BoolMat) (hΦ : Φ.Nonempty) (h : IsSubgameSet Φ' Φ) :
    DSet Φ' ≤ DSet Φ := by
  sorry

/-- Theorem 2.9 (Main Theorem — refutation of the Direct Sum Conjecture).
There exists a family `(f n)` of total functions `f n : {0,1}^n × {0,1}^n → {0,1}`
(modeled as `(Fin n → Bool) → (Fin n → Bool) → Bool`) such that for all `N, L, C ∈ ℕ`
there exist `n ≥ N` and `ℓ ≥ L` with `D(f n) > D((f n)^ℓ)/ℓ + C`, i.e. the per-instance
saving grows without bound. -/
theorem refutation_of_direct_sum_conjecture :
    ∃ f : (n : ℕ) → (Fin n → Bool) → (Fin n → Bool) → Bool,
      ∀ N L C : ℕ, ∃ n : ℕ, N ≤ n ∧ ∃ ℓ : ℕ, L ≤ ℓ ∧
        (D (f n) : ℝ) > (D (directSum (f n) ℓ) : ℝ) / (ℓ : ℝ) + (C : ℝ) := by
  sorry

/-- Theorem 5.10 (Quantitative / multiplicative consequence).
With `B = Q = 255 · 2^{10000-8}`, for all `i`,
`D(φ_i^{178}) ≤ 178 · D(φ_i) + 177`. -/
theorem multiplicative_consequence (i : ℕ) :
    D (directSum (phi Q i).e 178) ≤ 178 * Dmat (phi Q i) + 177 := by
  sorry

end Workspace.MainTheorem
