import Mathlib
import Workspace.Types.BoolMat
import Workspace.Types.AlternatingGame
import Workspace.Types.Bracket
import Workspace.Types.Lambda
import Workspace.Types.MatComplexity

open Workspace.Types.BoolMat
open Workspace.Types.AlternatingGame
open Workspace.Types.Bracket
open Workspace.Types.Lambda
open Workspace.Types.MatComplexity

/-- The paper fixes `B = Q = 255·2^{k-8}` with `k = 10000`, `a = 10` from Section 4 onward. -/
private abbrev Q : ℕ := 255 * 2 ^ (10000 - 8)

namespace Workspace.PhiInduction

/-- Lemma 4.12 (Row divisibility of `φ_i`). For `k = 10000`, `a = 10`, any `i ≥ 1`: both the
number of rows and the number of columns of `φ_i` are divisible by `2^{a+2}` (`= 2^{10+2}`). -/
theorem lemma_4_12_row_divisibility (i : ℕ) (hi : 1 ≤ i) :
    2 ^ (10 + 2) ∣ (phi Q i).m ∧ 2 ^ (10 + 2) ∣ (phi Q i).n := by
  sorry

/-- Lemma 4.13 (Shifted-rung arithmetic). For `k = 10000`, `a = 10`, `ρ = √(k+a)`,
`β = (ρ−1)/(ρ−2)`, `Q = 255·2^{k-8}`, and `k_j = k−j`, `a_j = a+j`,
`P_j = ⌊ Q · (2^{a−3/8} − 1)/(2^{a_j} − 1) ⌋` for `j ∈ {0,1,2}`: for each `j`,
`(ρ−1)^{k_j−3} ≤ ρ^{k_j−5}` and `P_j ≥ ⌊ 6·2^{k_j−3}·β^2 ⌋`. -/
theorem lemma_4_13_shifted_rung_arithmetic :
    ∀ j : ℕ, j < 3 →
      let ρ : ℝ := Real.sqrt (10000 + 10)
      let β : ℝ := (ρ - 1) / (ρ - 2)
      let k_j : ℕ := 10000 - j
      let a_j : ℕ := 10 + j
      let P_j : ℕ :=
        ⌊ (Q : ℝ) * ((Real.rpow 2 (10 - 3 / 8) - 1) / (Real.rpow 2 (a_j : ℝ) - 1)) ⌋₊
      Real.rpow (ρ - 1) ((k_j : ℝ) - 3) ≤ Real.rpow ρ ((k_j : ℝ) - 5) ∧
        P_j ≥ ⌊ 6 * Real.rpow 2 ((k_j : ℝ) - 3) * β ^ 2 ⌋₊ := by
  sorry

/-- Proposition 4.14 (φ-growth step). For `k = 10000`, `a = 10`, `η_j = 2^{-3/8-j}` (`j∈{0,1,2}`),
any `i ≥ 1`, if `D([φ_i]_{1, 2^{-k-a}, 2^{-3}}) ≥ 1`, then for each `j ∈ {0,1,2}`,
`D([φ_{i+1}]_{1, 2^{-k-a}, η_j}) ≥ k − j + Λ_{φ_i}(1, 2^{-k-a}, η_0)`; consequently
`Λ_{φ_{i+1}}(1, 2^{-k-a}, η_0) ≥ k + Λ_{φ_i}(1, 2^{-k-a}, η_0)`. -/
theorem proposition_4_14_phi_growth_step (i : ℕ) (hi : 1 ≤ i)
    (hside :
      DSet (bracket (phi Q i) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3))) ≥ 1) :
    (∀ j : ℕ, j < 3 →
        let η : ℕ → ℝ := fun j => Real.rpow 2 (-3 / 8 - (j : ℝ))
        DSet (bracket (phi Q (i + 1)) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (η j)) ≥
          10000 - j +
            Lambda (phi Q i) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3 / 8))) ∧
      Lambda (phi Q (i + 1)) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3 / 8)) ≥
        10000 + Lambda (phi Q i) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3 / 8)) := by
  sorry

/-- Lemma 4.18 (Weak side condition propagates). For `k = 10000`, `a = 10`, any `i ≥ 1`: if
`D([φ_i]_{1, 2^{-k-a}, 2^{-3}}) ≥ 1` then `D([φ_{i+1}]_{1, 2^{-k-a}, 2^{-3}}) ≥ 1`. -/
theorem lemma_4_18_weak_side_condition_propagates (i : ℕ) (hi : 1 ≤ i)
    (hside :
      DSet (bracket (phi Q i) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3))) ≥ 1) :
    DSet (bracket (phi Q (i + 1)) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3))) ≥ 1 := by
  sorry

/-- Corollary 4.20 (Bundled lower bound). For `k = 10000`, `a = 10`, any `i ≥ 1`:
`D([φ_i]_{1, 2^{-k-a}, 2^{-3}}) ≥ 1` and `Λ_{φ_i}(1, 2^{-k-a}, 2^{-3/8}) ≥ k·i`. -/
theorem corollary_4_20_bundled_lower_bound (i : ℕ) (hi : 1 ≤ i) :
    DSet (bracket (phi Q i) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3))) ≥ 1 ∧
      Lambda (phi Q i) 1 (Real.rpow 2 (-(10000 : ℝ) - 10)) (Real.rpow 2 (-3 / 8)) ≥ 10000 * i := by
  sorry

/-- Corollary 4.24 (Lower bound on `φ_i`). For `k = 10000`, `a = 10`, any `i ≥ 1`:
`D(φ_i) ≥ k·i`. -/
theorem corollary_4_24_lower_bound_phi (i : ℕ) (hi : 1 ≤ i) :
    Dmat (phi Q i) ≥ 10000 * i := by
  sorry

end Workspace.PhiInduction
