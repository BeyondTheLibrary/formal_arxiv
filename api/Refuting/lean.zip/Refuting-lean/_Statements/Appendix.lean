import Mathlib
import Workspace.Types.BoolMat
import Workspace.Types.Bracket
import Workspace.Types.MatComplexity
import Workspace.Types.Lambda

namespace Workspace.Appendix

open Workspace.Types.BoolMat
open Workspace.Types.Bracket
open Workspace.Types.MatComplexity
open Workspace.Types.Lambda

/-- Lemma A.1 (Partition recurrence).

For a matrix `M`, integer `p ≥ 1`, real `0 < τ ≤ 1`, `δ ∈ {0,1}`,
`0 < x ≤ 1/2`, `0 < y ≤ 1`, if `D([M]_{2p+δ, 2x, y}) ≥ 1`, then
```
D([M]_{2p+δ, 2x, y}) ≥ 1 + min(
    D([M]_{p+δ, x, y^{(p+δ)/(p(1+τ)+δ)}}),
    D([M]_{⌊p(1−τ)⌋+1, x, y^{τ/(1+τ)}}),
    D([M]_{2p+δ, 2x, y/2}) ).
``` -/
theorem lemma_A1_partition_recurrence
    (M : BoolMat) (p : ℕ) (hp : 1 ≤ p) (τ : ℝ) (hτ : 0 < τ ∧ τ ≤ 1)
    (δ : ℕ) (hδ : δ ≤ 1) (x y : ℝ)
    (hxy : 0 < x ∧ x ≤ 1 / 2 ∧ 0 < y ∧ y ≤ 1)
    (h1 : DSet (bracket M (2 * p + δ) (2 * x) y) ≥ 1) :
    DSet (bracket M (2 * p + δ) (2 * x) y) ≥
      1 + min
        (DSet (bracket M (p + δ) x
          (Real.rpow y (((p : ℝ) + δ) / ((p : ℝ) * (1 + τ) + δ)))))
        (min
          (DSet (bracket M (⌊(p : ℝ) * (1 - τ)⌋₊ + 1) x
            (Real.rpow y (τ / (1 + τ)))))
          (DSet (bracket M (2 * p + δ) (2 * x) (y / 2)))) := by
  sorry

/-- Lemma A.2 (Three-Rung Partition Lemma) — row inequality.

For a matrix `M`, `p ≥ 1`, `δ ∈ {0,1}`, `0 < x ≤ 1/2`, `0 < y ≤ 1`, assuming
`D([M]_{2p, 2x, y/4}) ≥ 1`:
`D([M]_{2p+δ, 2x, y}) ≥ 1 + min_{0≤j<3}( j + D([M]_{p+δ, x, y/2^j}) )`. -/
theorem lemma_A2_three_rung_row
    (M : BoolMat) (p : ℕ) (hp : 1 ≤ p) (δ : ℕ) (hδ : δ ≤ 1) (x y : ℝ)
    (hxy : 0 < x ∧ x ≤ 1 / 2 ∧ 0 < y ∧ y ≤ 1)
    (h1 : DSet (bracket M (2 * p) (2 * x) (y / 4)) ≥ 1) :
    DSet (bracket M (2 * p + δ) (2 * x) y) ≥
      1 + min
        (DSet (bracket M (p + δ) x y))
        (min
          (1 + DSet (bracket M (p + δ) x (y / 2)))
          (2 + DSet (bracket M (p + δ) x (y / 4)))) := by
  sorry

/-- Lemma A.2 (Three-Rung Partition Lemma) — column inequality.

For a matrix `M`, `p ≥ 1`, `δ ∈ {0,1}`, `0 < x ≤ 1/2`, `0 < y ≤ 1`, assuming
`D([M]_{2p, 2x, y/4}) ≥ 1`, for every `0 < τ ≤ 1`, with `u = y^{1/(1+τ)}`,
`v = y^{τ/(1+τ)}`:
`D([M]_{2p, 2x, y}) ≥ 1 + min( min_{0≤j<3}(j + D([M]_{p, x, u/2^j})),
min_{0≤j<3}(j + D([M]_{⌊p(1−τ)⌋+1, x, v/2^j})) )`. -/
theorem lemma_A2_three_rung_col
    (M : BoolMat) (p : ℕ) (hp : 1 ≤ p) (δ : ℕ) (hδ : δ ≤ 1) (x y : ℝ)
    (hxy : 0 < x ∧ x ≤ 1 / 2 ∧ 0 < y ∧ y ≤ 1)
    (h1 : DSet (bracket M (2 * p) (2 * x) (y / 4)) ≥ 1)
    (τ : ℝ) (hτ : 0 < τ ∧ τ ≤ 1) :
    DSet (bracket M (2 * p) (2 * x) y) ≥
      1 + min
        (let u := Real.rpow y (1 / (1 + τ));
         min
          (DSet (bracket M p x u))
          (min
            (1 + DSet (bracket M p x (u / 2)))
            (2 + DSet (bracket M p x (u / 4)))))
        (let v := Real.rpow y (τ / (1 + τ));
         min
          (DSet (bracket M (⌊(p : ℝ) * (1 - τ)⌋₊ + 1) x v))
          (min
            (1 + DSet (bracket M (⌊(p : ℝ) * (1 - τ)⌋₊ + 1) x (v / 2)))
            (2 + DSet (bracket M (⌊(p : ℝ) * (1 - τ)⌋₊ + 1) x (v / 4))))) := by
  sorry

/-- Lemma A.3 (Row ladder step).

Under `D([M]_{2p, 2x, y/4}) ≥ 1` (same hyps as A.2):
`Λ_M(2p+δ, 2x, y) ≥ 1 + Λ_M(p+δ, x, y)`. -/
theorem lemma_A3_row_ladder_step
    (M : BoolMat) (p : ℕ) (hp : 1 ≤ p) (δ : ℕ) (hδ : δ ≤ 1) (x y : ℝ)
    (hxy : 0 < x ∧ x ≤ 1 / 2 ∧ 0 < y ∧ y ≤ 1)
    (h1 : DSet (bracket M (2 * p) (2 * x) (y / 4)) ≥ 1) :
    Lambda M (2 * p + δ) (2 * x) y ≥ 1 + Lambda M (p + δ) x y := by
  sorry

/-- Lemma A.4 (Column ladder step).

Under `D([M]_{2p, 2x, y/4}) ≥ 1`, with `u = y^{1/(1+τ)}`, `v = y^{τ/(1+τ)}`,
`0 < τ ≤ 1`:
`Λ_M(2p, 2x, y) ≥ 1 + min( Λ_M(p, x, u), Λ_M(⌊p(1−τ)⌋+1, x, v) )`. -/
theorem lemma_A4_column_ladder_step
    (M : BoolMat) (p : ℕ) (hp : 1 ≤ p) (x y τ : ℝ)
    (hxyτ : 0 < x ∧ x ≤ 1 / 2 ∧ 0 < y ∧ y ≤ 1 ∧ 0 < τ ∧ τ ≤ 1)
    (h1 : DSet (bracket M (2 * p) (2 * x) (y / 4)) ≥ 1) :
    Lambda M (2 * p) (2 * x) y ≥
      1 + min
        (Lambda M p x (Real.rpow y (1 / (1 + τ))))
        (Lambda M (⌊(p : ℝ) * (1 - τ)⌋₊ + 1) x (Real.rpow y (τ / (1 + τ)))) := by
  sorry

end Workspace.Appendix
