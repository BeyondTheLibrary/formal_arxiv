# Theorem 19.2 claim (2): false bridge repaired, localization still open

The original helper `Thm192Claim2Gap.path_in_minimal_A_of_inductive_wheel`
is false. This is proved, without `sorry`, by
`Thm192Claim2Counterexample.original_bridge_false`.

## Counterexample to the original helper

The vertex set is `Fin 8`. The edges are

```
01, 12, 23, 34, 45, 50, 06, 36, 70, 71, 74, 75.
```

Take `z = 0`, `x₀ = 1`, `x₁ = 5`, `x₂ = 6`, `A₀ = A = {2,3,4}`,
`Y = {6,7}`, and `y = 6`. Thus `Y₀ = {7}`.

* `(z,A₀)` is a frame and `x₀,x₁,x₂` is a wheel system.
* `A₁ = A = {2,3,4}`. In particular, this example does not rely on a
  distinction between `A` and `A₁`.
* `GoodA` holds. Any good set contains `2` and `4`, to meet the neighbours of
  `x₀` and `x₁`. Connectedness then forces `3`, so `A` is cardinal-minimal.
* `C = [0,1,2,3,4,5]` witnesses `Concl192` for `Y₀`: `01` and `45` are
  disjoint `Y₀`-complete rim edges, and `z` is `Y₀`-complete.
* Any path from `1` to `5` with interior in `A` uses only vertices in
  `{1,2,3,4,5}`. Among these vertices, `45` is the only `Y₀`-complete edge.
  Its complete-edge count is therefore at most one.

The example is not Berge: `7-1-2-3-4-7` is an odd hole. The original helper
omitted the graph-class assumption and the complete-end assumptions of claim (2).
This refutes the helper, not the full statement of claim (2).

## Mathematical diagnosis of localization

Neither cardinal minimality nor the definition of `Concl192` says that the
particular wheel supplied by `Concl192` has its rim inside `A`.

The printed sentence on p. 118 can be justified by an induction uniform over
all finite graphs and frames. For `Y₀`, apply that induction to the graph
induced on

```
A ∪ {x₀,x₁,x₂,z} ∪ Y₀,
```

with frame `(z,A)`. Its hypotheses follow from the original wheel system,
`GoodA`, and the hypotheses on `Y₀`. The induced graph is still in `F₇`.
In this graph the set named `A₁` is exactly `A`:

* `A` is connected and nonempty, contains no neighbour of `z`, and contains
  no `{x₀,x₁}`-complete vertex.
* Each `xᵢ` is excluded because it sees `z`.
* `z` and each vertex of `Y₀` are excluded because they are
  `{x₀,x₁}`-complete.

Thus smaller-hub induction there supplies a wheel with its rim over `A`.
This explains the printed step without claiming a gap in the published result.
The current Lean induction hypothesis quantifies only over `Y'`, fixing `G`,
`A₀`, and `x`; it cannot be applied to this induced graph and new frame.
Completing that uniform induction remains open in this worktree. No claim is
made that the full `claim2` statement is false.

## Changes and proved parts

Under the task's explicit exception for helper statement changes, the bridge
now assumes `Berge G`, completeness of `x₀,x₁` to `Y₀`, and an inductive wheel
whose rim lies in `{x₀,x₁,z} ∪ A`. Its conclusion is unchanged. Its proof is
complete and has only `propext`, `Classical.choice`, and `Quot.sound` as axioms.

`Thm192Claim2RimPath.delete_vertex` proves that deleting `z` gives an
`x₀`–`x₁` path with exactly the remaining rim vertices.
`Thm192Claim2RimPath.path_of_local_wheel` proves the complete-edge bound:
the two complete edges incident with `z` are removed, a complete edge remains
because the wheel has two disjoint complete edges, and 2.3 makes the remaining
positive count even. Hence it is at least two.

The statement of `Thm192Claim2.claim2` is unchanged. Its proof supplies the
missing graph and endpoint assumptions and calls the new localization gap.
Its consumers in `Thm192Claim3`, `Thm192Claim11`, and `Statements/S19/Thm_19_2`
therefore need no edits. No frozen statement was changed.

## Exact remaining gap

`Workspace.ProofLemmas.Thm192Claim2Localization.inductive_wheel_with_rim_in_A`

This gap asserts only the existence of the local wheel under the full source
hypotheses. It encodes the sentence (printed p. 118, claim (2)):

> From the minimality of |Y|, z is Y₀-complete and therefore Y-complete,
> and there is a path as in the claim.

The missing work is the localized application of smaller-hub induction.
The path extraction and parity calculation are no longer gaps. In particular,
`claim2` is **not yet sorry-free**.

## New files

* `Workspace/ProofLemmas/Thm192Claim2Counterexample.lean`
* `Workspace/ProofLemmas/Thm192Claim2RimPath.lean`
* `Workspace/ProofLemmas/Thm192Claim2Localization.lean`

## Audit output (verbatim)

Command: `lake env lean AuditMine.lean` (exit 0). The scratch audit is not committed.

```text
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm192Claim2Gap.path_in_minimal_A_of_inductive_wheel' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Workspace.ProofLemmas.Thm192Claim2Localization.inductive_wheel_with_rim_in_A has sorry of type
  ∃ C, Workspace.Types.Wheels.SPGT.IsWheel G C (Y \ {y}) ∧ x 0 ∈ C ∧ x 1 ∈ C ∧ z ∈ C ∧ {v | v ∈ C} ⊆ {x 0, x 1, z} ∪ A
'Workspace.ProofLemmas.Thm192Claim2.claim2' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm192Claim2Counterexample.original_bridge_false' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
```

## Final verification

* Every new or edited Lean file passed `lake env lean <file>` (exit 0).
* `lake build Workspace.ProofLemmas.Thm192Claim2` passed.
* `lake build Workspace.ProofLemmas.Thm192Claim2Counterexample` passed.
* The mandatory full `lake build` passed (exit 0):
  `Build completed successfully (9196 jobs).`
* The full build rebuilt `Workspace.Statements.S19.Thm_19_2` and all the way
  through `Workspace.MainTheorem` and `Workspace.All` successfully.
* The audit contains only the one explicitly labelled gap above for `claim2`.
  The corrected bridge and the refutation of the original bridge are sorry-free.

# Theorem 7.5 claim (2): frozen replacement helper has an extra false clause

The auxiliary frozen statement
`Workspace.ProofLemmas.Thm75AppearanceFromRungReplacement.appearanceFromRungReplacement`
cannot hold as written. Its conclusion requires

`∀ c : W, c ≠ b₁ → c ≠ b₂ → NSet G H' K' φ' (ι c) = NSet G H K φ c`.

This quantifies over subdivision vertices inside the removed branch, too. The paper
(printed p. 37) asserts this identity only for vertices of `J` other than `b₁, b₂`.
The missing hypothesis on `c` is `c ∈ branchVertices H`.

For a concrete counterexample, let `J = K₄`, and subdivide every edge once to obtain
its bipartite subdivision `H`. Choose the branch `q = [b₁, w, b₂]`, whose rung in
`L(H)` is `R = [r₁, r₂]`. Form `G` by adding two new adjacent vertices `p₁, p₂`
to `L(H)`. Join `pᵢ` to every vertex of `NSet bᵢ` except `rᵢ`, and add no other
edges incident with the new vertices. Set `R' = [p₁, p₂]`. This satisfies the
helper's disjointness, attachment, and parity hypotheses: both rungs have length one.

The claimed new vertex set is `K' = (K \\ {r₁, r₂}) ∪ {p₁, p₂}`. But the displayed
clause at the removed subdivision vertex `w` requires
`NSet G H' K' φ' (ι w) = {r₁, r₂}`. Every `NSet` of the new appearance is a subset
of `K'`, while neither `r₁` nor `r₂` is in `K'`. This is a contradiction.

The helper was left unchanged and is not cited by the assigned target. The assigned
target now reduces to the explicitly labelled `gap_replacement_geometry` and
`gap_second_clique_complete` in `Thm75Claim2Five82ExactCard.lean`; the geometric
interface only constrains the distinguished endpoint cliques.

## Update: `gap_second_clique_complete` is now proved

`Workspace.ProofLemmas.Thm75Claim2Five82ExactCard.gap_second_clique_complete` no longer
contains a `sorry`.  It is proved from the new sorry-free module
`Workspace/ProofLemmas/Thm75Claim2Five82SecondClique.lean`, whose single theorem
`secondCliqueComplete` is the printed paragraph

> *"We claim also that every vertex of `Nc₂ \ {r₂}` is in `X` … contrary to 2.2."*

The prism of 7.1 is supplied by the already-proved
`Thm75PrismThroughBranch.thm75PrismThroughBranch`, applied to the **reversed** branch, which
is how the paper's prescribed `Nc₂`-end `b₂` is obtained (the lemma lets the caller prescribe
the two ends of the clique at the *first* named end of the branch).  The linkage is refuted by
2.8 through the lengths of the three linkage paths (`k ≥ 1`, `0`, `pathLength P + 1 ≥ 2`)
rather than through the printed *"at most one vertex of the triangle is in `X`"* count; this
needs `p₁ ≠ p₂`, which the caller derives from the exclusion of case 3 (a single `p₁ = p₂`
would be `Bc₁c₂`-dominant, contradicting `F ∩ (X ∪ Y) = ∅`).  The second half of the
disjunction in the hypothesis is handled by applying `secondCliqueComplete` to the reversed
branch, which is the paper's *"(This is without loss of generality, because in this case 2,
there is symmetry between `b₁ = c₁` and `b₂ = c₂`.)"*

## Update: `gap_replacement_geometry` is split into three labelled per-case gaps

The single unlabelled `sorry`s inside `gap_replacement_geometry` were replaced by three
labelled gap lemmas in `Thm75Claim2Five82ExactCard.lean`, each with a docstring quoting the
paper sentence it encodes, and `gap_replacement_geometry` is now proved from them:

* `gap_same_branch_case_one` — case 1 of 5.8.2 with `bᵢ = cᵢ` (`R'` splices into the old rung
  from `s₂`, only `Nc₁` changes);
* `gap_same_branch_case_two` — case 2 of 5.8.2 with `bᵢ = cᵢ` (`R' = P`, both cliques change);
* `gap_other_branch_geometry` — `b₁b₂ ≠ c₁c₂` (the distinguished branch and both of its
  cliques survive).

Cases 3 and 4 are excluded outright, as in the paper (`not_case_three_of_same_branch` and
`rung_ends_ne_of_same_branch`).

Two of the three gaps were shrunk further: they now state only the replaced appearance and its
clique/rung description, and the `ReplacementGeometry` record is assembled from that by the
proved lemmas `replacement_geometry_of_same_branch_case_two` and
`replacement_geometry_of_other_branch`.  Case 1 could not be shrunk this way, because its
`OneCliqueReplacement` outcome carries the prisms of 7.4 and its `hcliques` clause does not
follow from them.

All three remaining gaps are the same missing construction: *"if in `L(H)` we replace `Rb₁b₂`
by `R'` we obtain another appearance of `J` in `G`, say `L(H')`"* — the subdivision replacement
together with its endpoint-clique dictionary.  The sorry-free §8 machinery
(`Thm84GluedSubdivision`/`Thm84GluedBipartite`/`Thm84GluedLineGraphIso`/`Thm84GluedTransport`,
packaged as `Thm84EveryChoiceFormsLineGraph.everyChoiceFormsLineGraph`) builds exactly such an
`L(H')`, but its input is a **`J`-strip system**, and its output (`FormsLineGraph`) discards the
embedding `ι` and the tracks `T`, so it does not by itself supply the branch `B'` or the
clique dictionary `N'v = Nv` for `v ∉ {b₁, b₂}` that `ReplacementGeometry` needs.  Closing these
three gaps therefore means either (a) building the modified strip system
`S'b₁b₂ = V(R')`, `N'cᵢ = (Ncᵢ \ {rᵢ}) ∪ {r'ᵢ}` and strengthening the glued construction to
return `ι` and `T`, or (b) proving the repaired form of
`Thm75AppearanceFromRungReplacement.appearanceFromRungReplacement` (with the missing hypothesis
`c ∈ branchVertices H` on the unchanged cliques).

# Theorem 19.2 claim (2): missing `A₁`-to-`A` bridge

The frozen statement `Workspace.ProofLemmas.Thm192Claim2.claim2` requires an
`x₀`–`x₁` path whose interior lies in the minimal set `A`.

In the non-`Y₀`-complete branch, the induction hypothesis gives
`Concl192 G z A₀ x Y₀`.  By the frozen definition of `Concl192`, its wheel rim is
only known to lie in

`{x₀, x₁, z} ∪ wheelSystemA G z A₀ x 1`,

which is the paper's `{x₀,x₁,z} ∪ A₁`.  The hypotheses give only `A ⊆ A₁`;
they do not say that the induced wheel rim, or another path with the required two
`Y₀`-complete edges, lies in `A`.  The cardinal minimality hypothesis on `A`
applies only to sets satisfying `GoodA` and supplies no containment in the reverse
direction.

Thus the exact missing hypothesis is a bridge saying that the inductively obtained
wheel in `A₁` yields an `x₀`–`x₁` path with interior in `A` and at least two
`Y₀`-complete edges.  This is isolated as
`Thm192Claim2Gap.path_in_minimal_A_of_inductive_wheel`.  Alternatively, replacing
`A` by `A₁` in the frozen conclusion would match what the induction hypothesis
directly provides, but changing the frozen statement is not permitted.

---

# The frozen `starStar` statement is false

`Workspace.ProofLemmas.Thm58LocalCases.starStar` requires `Outcome` for the
given ordered ends `p₁,p₂`. Paper 5.8 permits exchanging the ends when using
claim (2) inside claim (4). Alternative 2(a) of `Outcome` is asymmetric.

Here is a counterexample. Let `J = K₄`. Subdivide each edge once to obtain
the bipartite graph `H` on vertices `0,…,9`, with edges numbered as follows:

| edge number | endpoints |
|---|---|
| 0 | 0,4 |
| 1 | 0,5 |
| 2 | 0,6 |
| 3 | 1,4 |
| 4 | 1,7 |
| 5 | 1,8 |
| 6 | 2,5 |
| 7 | 2,7 |
| 8 | 2,9 |
| 9 | 3,6 |
| 10 | 3,8 |
| 11 | 3,9 |

Take `K = {0,…,11}`, identify its vertices with these edges, and start with
`G[K] = L(H)`. Add three vertices `12,13,14`, and only these additional edges:
`0–12`, `12–13`, `13–14`, `14–4`, `14–5`.
Set `F = {12,13,14}`, `P = [12,13,14]`, `p₁ = 12`, `p₂ = 14`,
`c₁ = 0`, and `c₂ = 1`. Define each `N c` by the required incidence map.

All hypotheses hold. In particular, `X₁ = {0} ⊆ N 0` and
`X₂ = {4,5} ⊆ N 1`. Their union is nonlocal: no branch contains all three
edges, and no branch vertex is incident with all three. The graph is Berge.
Its holes have lengths 6, 8, or 10. To see the parity directly, a hole
meeting `F` must use all of `12–13–14` and exactly one of `4,5`, since
`4` and `5` are adjacent. The rest is an induced path in `L(H)` from edge
`0` to that chosen edge. If its second vertex is edge `3`, it must end
at the chosen edge immediately, so it has length 2. Otherwise it starts
through branch vertex `0` and ends through the subdivision vertex `7`
or `8`: the corresponding track of `H` has ends `4` and `1`, which
have opposite colors, so
the line-graph path has even length. Adding the three vertices of `F`
therefore gives an even hole. Holes disjoint from `F` are even because
`H` is bipartite. Only three vertices of `G` have degree at least 4, so
there is no antihole of length at least 7. A 5-antihole is a 5-hole,
already excluded.

For an independent finite check, enumerating induced cycles gives:
`G: {6: 6, 8: 5, 10: 2}` and `complement(G): {4: 129}`.

The required conclusion is false. Vertex `p₁ = 12` has only one neighbor
in `K`, namely edge `0`. Every vertex of `H` has degree at least 2, so
`p₁` is complete to none of the sets `N c`. Thus alternative 1 fails.
Every branch vertex has degree 3, so `N b₁ \ {r₁}` has two vertices for
every possible branch witness. Therefore 2(a), 2(b), and 2(d) fail.
Alternative 2(c) fails because `12 ≠ 14`.

The reversed path satisfies 2(a): use branch `[1,4,0]`, rung `[3,0]`,
and `r₁ = 3`. Vertex `14` sees `N 1 \ {3} = {4,5}`, and vertex `12`
sees rung vertex `0`. This identifies the exact missing freedom: the
local-case conclusion must allow reversal of the ordered ends. No frozen
statement was changed, and no gap lemma asserting this false conclusion
was introduced.

## Progress on `starBranch`

`Workspace.ProofLemmas.Thm58LocalCases.starBranch` now calls a proof in
`Thm58StarBranch.lean`. The attachment bookkeeping, branch orientation,
rung endpoints, singleton star intersections, adjacent-pair star, exclusion
of a common branch, parity contradiction, and all three applications of 2.4
are proved. The original `branchStar` and `branchBranch` were not changed.

Four remaining path constructions are labelled in
`Workspace/ProofLemmas/Thm58StarBranchGaps.lean`:

- `Workspace.ProofLemmas.Thm58StarBranchGaps.incident_parity_gap`:
  claim (2), “Now S₁ and S₂ have the same parity since H is bipartite.
  Yet S₁ can be completed via r₂-Q-s₁ and S₂ can be completed via
  r₂-Q-s₁-s₂, a contradiction.”
- `Workspace.ProofLemmas.Thm58StarBranchGaps.singleton_link_gap`:
  claim (6), “If pₙ has a unique neighbour (say r) in Rᵥ₁ᵥ₂, then r
  can be linked onto the triangle T, contrary to 2.4.”
- `Workspace.ProofLemmas.Thm58StarBranchGaps.separated_neighbors_link_gap`:
  claim (6), “If pₙ has two nonadjacent neighbours in Rᵥ₁ᵥ₂, then pₙ
  can be linked onto the triangle T, contrary to 2.4.”
- `Workspace.ProofLemmas.Thm58StarBranchGaps.mixed_star_link_gap`:
  claim (6), “In H there is a cycle C₂ using the branch between v₁ and
  v₂, and using an edge in A and an edge in B. ... Hence a can be
  linked onto the triangle formed by pₙ and its two neighbours in
  Rᵥ₁ᵥ₂, a contradiction.”

These gaps assert only the configurations used at those steps, not `Outcome`.
`starStar` remains unchanged under the task's rule for false frozen statements.
Thus an audit containing only accepted dependencies or new gaps is possible
for `starBranch`, but is impossible for the false `starStar` declaration.

## Verbatim target audit

```text
Workspace.ProofLemmas.Thm58LocalCases.starStar has sorry of type
  Workspace.ProofLemmas.Thm58Setup.Outcome G n H K φ N P p₁ p₂
'Workspace.ProofLemmas.Thm58LocalCases.starStar' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm58StarBranchGaps.incident_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarBranchGaps.separated_neighbors_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G p₂ a b d ∧ ¬G.Adj p₂ a ∧ ¬G.Adj p₂ b
Workspace.ProofLemmas.Thm58StarBranchGaps.singleton_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G r a b d ∧ ¬G.Adj r a ∧ ¬G.Adj r b
Workspace.ProofLemmas.Thm58StarBranchGaps.mixed_star_link_gap has sorry of type
  ∃ a ∈ N c, G.Adj p₁ a ∧ Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G a p₂ r s
'Workspace.ProofLemmas.Thm58LocalCases.starBranch' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
```

All four declarations in `Thm58LocalCases.lean` retain their original signatures.
Only the `starBranch` proof body changed. All four new Lean files and the
shared target file pass `lake env lean`. `AuditMine.lean` is uncommitted.

The required full project build exited 0:

```text
Build completed successfully (9215 jobs).
```

# Theorem 5.8: `branchStar` is false with the frozen endpoint order

The declaration `Workspace.ProofLemmas.Thm58LocalCases.branchStar` cannot be
proved as stated. `Thm58Setup.Outcome` is not invariant under reversing `P`:
alternative 2(a) requires the star attachment at `p₁`. The published statement
chooses the path and its endpoint names existentially, so it permits exchanging
them. The local helper fixes them before stating its conclusion.

Here is a counterexample, with arbitrary finite enumerations giving the required
`Fin` vertex types. Start with `J = K₃,₃`, with parts `{u,s,t}` and `{v,w,x}`.
Replace its edge `uv` by the three-edge branch `u-a-b-v` to obtain `H`.
Add a new vertex `z` and edges `bz,zu` to obtain `H⁺`. Both graphs are bipartite:
their parts are `{u,s,t,b}` and `{v,w,x,a}` (also put `z` in the second part).
Take `G = L(H⁺)`, let `K` be its induced copy of `L(H)`, and use the natural
isomorphism `φ`. Let `N c` be the image of `δ_H(c)`.

Set `p₁ = bz`, `p₂ = zu`, `P = [p₁,p₂]`, and `F = {p₁,p₂}`. Then:

- `J` is 3-connected, and `H` is a bipartite subdivision of `J`.
- `G` is Berge, being the line graph of a bipartite graph.
- `P` is an induced path, `F` is outside `K`, and `F.ncard = 2`.
- `X₁ = {ab,bv}` is contained in the branch `u-a-b-v`.
- `X₂ = {ua,uw,ux} = δ_H(u)` is contained in a branch-vertex star.
- Their union is not local: no branch contains `ab` and `uw`, and no
  branch-vertex is incident with both.

But the fixed-order `Outcome G ... P p₁ p₂` is false:

- In alternative 1 the exact neighborhood clauses force `c₁ = b` and `c₂ = u`.
  These vertices lie in the same branch `u-a-b-v`, contrary to its first clause.
- Alternatives 2(a), 2(b), and 2(d) require `p₁` to be adjacent to every edge of
  `δ_H(b₁)` except one, for some branch-vertex `b₁`. Each branch-vertex has degree
  3, but at most one of the only two neighbors `ab,bv` of `p₁` meets any
  branch-vertex. Thus none of these alternatives can hold.
- Alternative 2(c) requires `p₁ = p₂`, which is false.

An independent exhaustive check of the 13-vertex graph `L(H⁺)` found no odd
holes or odd antiholes. It also found no alternative-1 witnesses and no possible
`p₁` completeness witnesses for 2(a), 2(b), or 2(d). This computation is supporting
evidence, not a Lean proof.

Reversing `P` gives precisely alternative 2(a), with `b₁ = u`, `b₂ = v`, and
`r₁ = ua`. Thus the obstruction is the fixed orientation, not the published
theorem. Under rule 1 the false target is left unchanged. No reversal axiom or
sorry-labelled transport lemma has been introduced. A future interface repair
would have to allow the reversed outcome or choose the endpoint order
existentially; no frozen declaration has been changed here.


## Work completed for `branchBranch`

The frozen `branchBranch` body now calls a compiled proof, with no direct
`sorry`. The proof establishes the following parts of claims (5) and (7):

- the two branches have different, disjoint edge sets;
- no internal vertex of `P` has a neighbor in the appearance;
- each end has a neighbor in its own branch;
- a unique neighbor at a branch end is impossible, using the accepted
  `Thm58LocalCases.starBranch` and the minimum degrees of `H`;
- 2.4 contradicts each of the two remaining triangle-link configurations;
- the remaining neighbors are exactly two adjacent vertices, using the proved
  common-end form of König's argument;
- these pairs give the complete stars of internal vertices in different
  branches, and hence alternative 1 of `Outcome`.

The only new open lemmas are in
`Workspace/ProofLemmas/Thm58BranchBranchLinks.lean`:

1. `Workspace.ProofLemmas.Thm58BranchBranch.singleton_interior_link_gap`:
   “If p₁ has only one neighbour r ∈ R_{u₁v₁}, then we may assume that r is in
   the interior of R_{u₁v₁}, by (6), and so r can be linked onto T, contrary to
   2.4.” The reduction to an internal neighbor and the use of 2.4 are proved.
   What remains is the link construction and its two triangle nonneighbors.
2. `Workspace.ProofLemmas.Thm58BranchBranch.nonadjacent_neighbors_link_gap`:
   “If p₁ has two nonadjacent neighbours in R_{u₁v₁}, then p₁ can be linked
   onto T, again a contradiction.” Again the link construction and two
   triangle nonneighbors remain, and the application of 2.4 is proved.

Both are the last two sentences of claim (7), printed p. 28. The common missing
construction starts with the cycle through the first branch and one endpoint
of the second branch, avoiding the other endpoint, then lifts its two arms to
`L(H)` and adds the third path through `F`. No unaccepted existing sorry lemma
is used in place of this construction.

New Lean files (all in `Workspace/ProofLemmas/`):
`Thm58BranchBranchBasics.lean`, `Thm58BranchBranchStars.lean`,
`Thm58BranchBranchSingleton.lean`, `Thm58BranchBranchLinks.lean`, and
`Thm58BranchBranchEndNeighbors.lean`.

All four frozen signatures in `Thm58LocalCases.lean` were compared with the
starting revision and are unchanged. The bodies of `starStar`, `starBranch`,
and the false `branchStar` are unchanged. Only an import and the `branchBranch`
proof body were changed in that shared file.


## Audit

`lake env lean AuditMine.lean` exited 0. For `branchBranch`, the only
open dependencies are the accepted `starBranch` and the two labelled gaps
above. The unchanged false `branchStar` still reports its original sorry,
so that target cannot meet the requested sorry restriction without repairing
its frozen statement.

Verbatim output:

```text
Workspace.ProofLemmas.Thm58LocalCases.branchStar has sorry of type
  Workspace.ProofLemmas.Thm58Setup.Outcome G n H K φ N P p₁ p₂
'Workspace.ProofLemmas.Thm58LocalCases.branchStar' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm58BranchBranch.singleton_interior_link_gap has sorry of type
  ∃ a b c, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G r a b c ∧ ¬G.Adj r a ∧ ¬G.Adj r b
Workspace.ProofLemmas.Thm58BranchBranch.nonadjacent_neighbors_link_gap has sorry of type
  ∃ a b c, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G p₁ a b c ∧ ¬G.Adj p₁ a ∧ ¬G.Adj p₁ b
Workspace.ProofLemmas.Thm58LocalCases.starBranch has sorry of type
  Workspace.ProofLemmas.Thm58Setup.Outcome G n H K φ N P p₁ p₂
'Workspace.ProofLemmas.Thm58LocalCases.branchBranch' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
```

`lake build` also exited 0. Its final line was:

```text
Build completed successfully (9216 jobs).
```

Each of the five new Lean files and `Thm58LocalCases.lean` passed
`lake env lean <file>` individually. `AuditMine.lean` is left untracked, as
requested.

## 5.7 claim (4): frozen `sixTerminalCore` is false (2026-09-04)

Target: `Workspace.ProofLemmas.Thm57Claim4Core.sixTerminalCore`.

The core omits the requirement that the three marked pairs are edges of `H`.
Its assumptions include `hxX : ∀ i, x i ∈ X`, but neither
`X ⊆ H.edgeSet` nor `∀ i, x i ∈ H.edgeSet`. The other hypotheses do
not imply this. The exact frozen statement, specialized to `Fin 18`, is
refuted without `sorry` by
`Workspace.ProofLemmas.Thm57Claim4Counterexample.original_statement_false`
in `Workspace/ProofLemmas/Thm57Claim4CounterexampleWitness.lean`.

### Explicit counterexample

Let the vertex set be `Fin 18`. Start with `K₃,₃` on parts
`{0,14,16}` and `{13,15,17}` and replace the edge `0–13` with
`0–1–2–3–4–5–6–7–8–9–10–11–12–13`.
Thus `H` is cyclically 3-connected, and vertex-number parity gives a
proper Boolean colouring. Take `A = Set.univ` and

```
x 0 = s(1,4),   x 1 = s(5,8),   x 2 = s(9,12),
X = {x 0, x 1, x 2}.
```

These are three disjoint nonedges. Therefore `H.deleteEdges X = H`,
`A` is connected, and all three marked pairs have both ends in `A`.
No edge of any track belongs to `X`, so the `hclaim3` assumption holds.
The formal proof obtains it from the proved `Thm57Claim3.thm57Claim3`
after proving `NoEvenTrack57 H X` vacuously.

The clean-connection colour condition also holds. Write the odd ends as
`aᵢ = 4i+1` and the even ends as `bᵢ = 4i+4`, for `i = 0,1,2`.
For `i < j`, a clean connection from `aᵢ` to `aⱼ` must avoid `bᵢ,bⱼ`.
Deleting those vertices separates `aᵢ` from `aⱼ`: the former is in the
outside component, while the latter lies strictly between the two deleted
positions on the long branch. A clean connection from `bᵢ` to `bⱼ`
must avoid `aᵢ,aⱼ`. These two deletions also separate the ends, now with
`bᵢ` in the middle component. Reversing the order covers `i > j`.
Hence every clean connection has ends of different colours. The Lean
proof checks finite cut certificates and proves that an arbitrary track
stays on its starting side, so there is no bound on track length in this
verification.

### The missing paper hypothesis

The first sentence of 5.7, `../paper/perfect_pdf.txt:1067`, explicitly
assumes `X ⊆ E(H)`. Claim (4) uses this both to regard each `xᵢ` as a
one-edge track and to apply the adjacent-vertex deletion argument to the
ends of `x₃`. Neither use is valid for an arbitrary pair in `Sym2 W`.

The smallest proposed repair is to add

```
(hxE : ∀ i, x i ∈ H.edgeSet)
```

to `sixTerminalCore`. The stronger original paper hypothesis
`(hXE : X ⊆ H.edgeSet)` would also suffice. The sole consumer is
`Workspace/ProofLemmas/Thm57Claim4.lean:89`, which already has `hXE`
and can supply `fun i => hXE (hxX i)`.

The assignment explicitly freezes this core's statement, and the consumer
is outside the assigned files. Following rule 1, the target and consumer
were left unchanged. The original target's `sorry` remains a false
statement, not a new labelled proof gap. No new gap lemmas were introduced.

### New verified files

- `Workspace/ProofLemmas/Thm57Claim4Counterexample.lean`: the finite graph,
  proper colouring, and subdivision of a 3-connected `K₃,₃`.
- `Workspace/ProofLemmas/Thm57Claim4CounterexampleWitness.lean`: all other
  hypotheses and a refutation of the exact frozen statement on `Fin 18`.

Both files pass `lake env lean`. All finite checks use kernel-checked
`decide`; neither file contains `sorry` or adds an axiom.

### Verbatim audit output

`lake env lean AuditMine.lean` exits 0:

```text
Workspace.ProofLemmas.Thm57Claim4Core.sixTerminalCore has sorry of type
  False
'Workspace.ProofLemmas.Thm57Claim4Core.sixTerminalCore' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm57Claim4Counterexample.original_statement_false' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
```

The counterexample has only the three allowed axioms. The original target
retains its own `sorryAx`; a clean target audit cannot be supplied for this
false frozen statement. `AuditMine.lean` is not committed.

The mandatory full `lake build` also exits 0:

```text
Build completed successfully (9365 jobs).
```

The unchanged target file also passes `lake env lean
Workspace/ProofLemmas/Thm57Claim4Core.lean`, with its existing `sorry` warning.

# Theorem 23.2, claims (3) and (5): frozen helper blockers (t232b)

No existing declaration or proof body was changed in this worktree. The assignment
explicitly calls these three helper statements frozen and permits only replacing
their `sorry` bodies by calls. I asked whether the general helper-repair exception
also applies here. No answer had arrived while the independent proofs below were
being completed. No new `sorry` was introduced.

## `Thm232Claim3.not_adj_c2_gap`

The statement omits two facts used by the printed proof (pp. 139–140):

* `¬ VertexComplete G y Y`;
* the exhaustive list of four `Y`-complete rim edges, called `hexh` in its caller.

Here is a counterexample to the stated helper. Take vertices `0,...,7` and edges

```
01, 12, 23, 34, 45, 50, 16, 36,
07, 17, 27, 37, 47, 57, 67.
```

Set `C = [0,1,2,3,4,5]`, `Y = {7}`, `k = 0`, `d = 2`, and
`(x₀,z,x₁,c₁,c₂,c₃,y) = (0,1,2,2,3,4,6)`.
The wheel is optimal because `7` is universal: an anticonnected hub containing
`7` cannot contain another vertex. Every local hypothesis of `not_adj_c2_gap`
holds, but `G.Adj 6 3` holds too. The two omitted paper assumptions fail:
`6` is `Y`-complete, and `45,50` are additional `Y`-complete rim edges.

`Thm232Claim3MissingHypotheses.local_certificate` checks the optimal wheel,
all local geometric hypotheses, and the forbidden edge in Lean, without `sorry`.
`omitted_assumptions_fail` checks the omitted conditions. **The Lean certificate
does not include `InF8 graph`.** The mathematical check of that remaining
hypothesis is as follows, so this distinction is explicit:

1. Deleting `7` gives a bipartite graph `B` with parts `{0,2,4,6}` and
   `{1,3,5}`. Adding a universal vertex preserves the Berge property. Directly,
   every hole omits `7` and is even. In the complement, `7` is isolated and
   `Bᶜ` has independence number at most two, excluding holes of length at least
   six. A five-hole would give a five-hole in `B` by complementation.
2. A bipartite subdivision of `K₄` has at least eight edges. Its line graph
   has neither an isolated vertex nor a vertex of degree greater than four.
   An appearance in either eight-vertex host would therefore use every vertex,
   but `7` has degree seven in `G` and degree zero in `Gᶜ`. Thus `G ∈ F₃`.
3. All triangles of `G` contain `7`, so `G` has no prism. In a Berge graph,
   a long prism has at least eight vertices: the three rung lengths have the
   same parity, with a total of at least five in the odd case and six in the
   even case. A long prism in `Gᶜ` would use all eight vertices, including the
   isolated `7`. Thus both long-prism exclusions hold.
4. A double diamond uses eight vertices and has no universal vertex, so
   `G` has no double diamond.
5. Every wheel in `G` has hub `{7}`. Its rim omits `7`; any other hub vertex
   together with a complete rim edge would be a triangle of `B`. Anticonnectivity
   forbids adding another vertex to a hub containing `7`. All rim vertices are
   `{7}`-complete, so a maximal segment omits one rim vertex and has even length.
   The complement has no hole of length at least six. Neither graph has an odd
   wheel.
6. A path of at least five vertices in `G` omits the universal `7`. If a
   pseudowheel hub set contains `7`, anticonnectivity makes that set `{7}`;
   either all path vertices are complete to its first hub, or the second path
   vertex is complete to its second hub, violating the definition. If neither
   hub contains `7`, the first path vertex and an edge between the two hubs
   form a triangle in `B`. In `Gᶜ`, such a path omits the isolated `7`, and its
   first, third, and fifth vertices form an independent triple in `Bᶜ`.
   Thus neither graph has a pseudowheel.

The published argument is not refuted. Its `y` is an interior vertex of `T`,
so `hint` supplies its non-completeness, and claim (1) supplies `hexh`. Both
facts are available at the one caller in `Thm232Claim3.claim3`. The smallest
repair is to add those hypotheses and pass them there. The frozen target has
been left untouched instead of being proved from a false replacement gap.

## `Thm232RemainingClaims.claim5_path_gap`

The statement does not record the minimum-length choice of `T` made immediately
before claim (4) on printed p. 140:

> By choosing T of minimum length we may assume that none of y, v₁, ..., vₙ₋₁
> have neighbours in A₀.

That fact is used explicitly in claim (5) to prove the inclusion represented by
`Claim5PathData.tailContains`. The current hypotheses only specify an induced
`z`–`w` path, avoidance of `x₀,x₁`, and non-completeness of its interior.
They do not require the interior to avoid the rim or prohibit earlier attachments
to `A₀`. An induced path can have a shortcut through vertices of `A₀` that are
not on that path. Its inducedness alone does not exclude those shortcuts.

`Thm232Claim5PathPrefix.initial_indices` and `initial_subset` prove the exact
inclusion argument when the paper's no-earlier-attachment property is supplied.
No counterexample to all the global hypotheses is claimed here: the full
23.2 hypotheses themselves eventually yield a contradiction. The issue is the
missing premise for the prescribed local construction. The minimum choice must
be made before packaging `EndgameContext`, and must be carried into this helper.
The short-path exclusion of claim (4) also remains to be formalized.

## `Thm232RemainingClaims.claim5_second_alternative_gap`

The paper does not assert that 2.11's second outcome is impossible. It concludes
that one member of the pair misses `y,p₁,...,pₖ₋₁`. In the second outcome
`a-y-p₁-...-pₖ-b`, the vertex `b` already has exactly that property by
inducedness. Its edge to `pₖ` is harmless, since `pₖ` is `Y`-complete and no
vertex of the interior of `T` is `Y`-complete.

The following are now proved without `sorry`:

* `Thm232Claim5SecondOutcome.last_anticomplete_dropLast`;
* `Thm232Claim5SecondOutcome.second_outcome_anticomplete`.

The latter gives precisely
`VertexAnticomplete G b {v | v ∈ SPGT.interior T}` from the data already
available in this target. Replacing its `False` conclusion with this assertion
and returning the corresponding disjunct at its caller would implement the
printed proof. This is an overstrong intermediate obligation relative to the
source, not a claimed counterexample to its full global hypotheses.

## Complete argument after choosing the path

`Thm232Claim5FromPath.exists_anticomplete_interior` proves the remaining
pseudowheel, parity, and 2.11 argument, using both 2.11 outcomes.
`exists_anticomplete_tail` transfers it to the interior of `T` using the stored
inclusion. It reuses `Thm183EvenLength.even_pathLength_of_ends_only_XComplete`
for the identical application of 13.6. These lemmas do not import either target
module, so they are ready to be used by a repaired caller without an import cycle.

## New files

* `Workspace/ProofLemmas/Thm232Claim3MissingHypotheses.lean`
* `Workspace/ProofLemmas/Thm232Claim5SecondOutcome.lean`
* `Workspace/ProofLemmas/Thm232Claim5PathPrefix.lean`
* `Workspace/ProofLemmas/Thm232Claim5FromPath.lean`

All four files compile. No new labelled gap lemmas were added. The three original
frozen gaps remain open, so their mandatory audit cannot have the requested
accepted-dependencies-only result. This is reported rather than hidden behind
new copies of the same gaps.

## t232b mandatory audit output (verbatim)

`lake env lean AuditMine.lean` exited 0. The scratch file is not committed.

```text
Workspace.ProofLemmas.Thm232Claim3.not_adj_c2_gap has sorry of type
  ¬G.Adj y c₂
'Workspace.ProofLemmas.Thm232Claim3.not_adj_c2_gap' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm232RemainingClaims.claim5_path_gap has sorry of type
  Nonempty (Workspace.ProofLemmas.Thm232RemainingClaims.Claim5PathData G C Y x₀ z x₁ y T)
'Workspace.ProofLemmas.Thm232RemainingClaims.claim5_path_gap' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Workspace.ProofLemmas.Thm232RemainingClaims.claim5_second_alternative_gap has sorry of type
  False
'Workspace.ProofLemmas.Thm232RemainingClaims.claim5_second_alternative_gap' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim3MissingHypotheses.local_certificate' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5SecondOutcome.second_outcome_anticomplete' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5PathPrefix.initial_subset' depends on axioms: [propext, Classical.choice, Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5FromPath.exists_anticomplete_tail' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
```

## t232b final build

The mandatory full `lake build` exited 0, including `Workspace.MainTheorem`
and `Workspace.All`:

```text
Build completed successfully (9408 jobs).
```

Each of the four new files also passed `lake env lean <file>`. The audit
exited 0 but reports the three unchanged original target sorries, as shown
above. The four new modules introduce no `sorryAx`.

## t232d — the three remaining gaps of 23.2

All three gaps named in the assignment are closed.  Two of them were mis-encoded, and one
piece of the printed proof (claim (4)) is isolated as a new labelled gap.

### 1. `Thm232Claim3.not_adj_c2_gap` — repaired and proved

**Repair (rule-1 exception).**  Two hypotheses were added, both available at the only caller
`Thm232Claim3.claim3`:

* `hexh` (the claim (1) exhaustion of the `Y`-complete edges of `C`), inserted after `hnbc`;
* `hyNC : ¬ VertexComplete G y Y`, inserted after `hyY`.

Without them the statement is false as written: the printed argument needs `y` to be
non-`Y`-complete (otherwise `y` is a hub vertex and the closing odd wheel does not exist), and
it needs (1) to know that the `Q`-neighbour of `x₀` is not `Y`-complete.

**Proof.**  `Workspace/ProofLemmas/Thm232Claim3C2Core.lean` (new) contains the two hole
constructions: `no_adj_far_end` builds `x₀-Q-c₃-c₂-y-x₀` and rules out `G.Adj y x₀`, and
`odd_wheel_absurd` builds `x₀-Q-c₃-c₂-y-z-x₀` and finds in it the `Y`-segment `[x₀,z]` of odd
length 1 (via `Thm232ClosingCompletePair.pair_segment`), contradicting `G ∈ F₈`.
`Workspace/ProofLemmas/Thm232Claim3C2.lean` (new) supplies the cyclic-position bookkeeping
(`mod_le_self`, `mem_rotate_take`, `pos_ne`, `prefix_getElem`, `not_mem_arc`), the parity of the
arc from 2.3 (`arc_even`), and the abstract one-arc form `orientation_absurd` of the printed
argument; `not_adj_c2` discharges the printed *"from the symmetry we may assume `x₀ ≠ c₃`"* by
applying `orientation_absurd` either to the arc `c₃ → x₀` or to the reversed arc `c₁ → x₁`
(both cannot degenerate, since `x₀ = c₃` and `x₁ = c₁` together force `|C| = 4 < 6`).

### 2. `Thm232RemainingClaims.claim5_path_gap` — repaired and proved

**Repair (rule-1 exception).**  A hypothesis was added recording the paper's minimum-length
choice of `T` (*"By choosing `T` of minimum length we may assume that none of `y, v₁, …, v_{n−1}`
have neighbours in `A₀`"*, printed p. 140):

```
(hattach : ∀ (i : ℕ) (hi : i + 2 < T.length),
  VertexAnticomplete G (T[i]'(by omega)) ({v : V | v ∈ C} \ ({z, x₀, x₁} : Set V)))
```

The same hypothesis was added to `Thm232RemainingClaims.claim5`, which forwards it.

**Consumer update.**  `Thm232Endgame.no_wheel_contradiction` has a frozen argument list (it is
called from the frozen `Statements/S23/Thm_23_2.lean`), so the re-choice of `T` now happens
inside it: `Thm232MinPath.exists_min_clean_path` (new) replaces `T` by a minimum-length clean
path `S` from `z` to `A₀` avoiding `{x₀,x₁}`, and claims (2) and (3) are re-derived for `S`
(`Thm232NoDoubleNeighbour.not_adj_both`, `Thm232Claim3.claim3`).  The `Y`-complete rim edge
witness that (2) needs is rebuilt from the configuration: `c₁c₂` when `d ≥ 3` and `c₂c₃` when
`d = 2` (only one of `c₁ = x₁`, `c₃ = x₀` can happen, and both together would force `|C| = 4`).

**Proof.**  `Workspace/ProofLemmas/Thm232Claim5Path.lean` (new) builds the path.  `A₀` is
connected (`Thm232RimFacts.a0_connected`, new), hence so is `A₀ ∪ interior T`, and
`FirstTargetInducedPathInConnectedSet` produces an induced path from `y` into it stopping at the
first `Y`-complete vertex; `PathAttach.isPathFrom_cons` prefixes `z`.  The printed inclusion
`{y,v₁,…,v_n} ⊆ {y,p₁,…,p_{k−1}}` is `Thm232Claim5PathPrefix.initial_subset` fed by `hattach`,
and `¬ VertexComplete G p_k {x₀,x₁}` is `Thm232RimFacts.not_complete_to_pair` (new).
`4 ≤ pathLength P` is the printed *"From (4), `k ≥ 3`"*.

**New labelled gap (rule 5).**  `Thm232Claim5Path.claim4_gap` is paper claim (4)
(*"If `n = 1` then no neighbour of `v₁` in `A₀` is `Y`-complete"*), stated exactly and left with
`sorry`; its printed proof needs an antipath argument, 16.1, 22.3 and a further odd hole.  It is
the only new `sorry` introduced by this task.

### 3. `Thm232RemainingClaims.claim5_second_alternative_gap` — repaired and proved

**Repair (rule-1 exception).**  The conclusion `False` was overstrong: the printed proof of the
second alternative does not end in a contradiction, it ends in the claim (5) disjunct.  The
conclusion is now

```
VertexAnticomplete G b {v : V | v ∈ SPGT.interior T}
```

and the caller `claim5` returns `Or.inl`/`Or.inr` according to which of `x₀, x₁` the vertex `b`
is.  With that statement the lemma is exactly
`Thm232Claim5SecondOutcome.second_outcome_anticomplete`, already proved.

# Theorem 23.2, claims (3) and (5): frozen helper blockers (t232b)

No existing declaration or proof body was changed in this worktree. The assignment
explicitly calls these three helper statements frozen and permits only replacing
their `sorry` bodies by calls. I asked whether the general helper-repair exception
also applies here. No answer had arrived while the independent proofs below were
being completed. No new `sorry` was introduced.

## `Thm232Claim3.not_adj_c2_gap`

The statement omits two facts used by the printed proof (pp. 139–140):

* `¬ VertexComplete G y Y`;
* the exhaustive list of four `Y`-complete rim edges, called `hexh` in its caller.

Here is a counterexample to the stated helper. Take vertices `0,...,7` and edges

```
01, 12, 23, 34, 45, 50, 16, 36,
07, 17, 27, 37, 47, 57, 67.
```

Set `C = [0,1,2,3,4,5]`, `Y = {7}`, `k = 0`, `d = 2`, and
`(x₀,z,x₁,c₁,c₂,c₃,y) = (0,1,2,2,3,4,6)`.
The wheel is optimal because `7` is universal: an anticonnected hub containing
`7` cannot contain another vertex. Every local hypothesis of `not_adj_c2_gap`
holds, but `G.Adj 6 3` holds too. The two omitted paper assumptions fail:
`6` is `Y`-complete, and `45,50` are additional `Y`-complete rim edges.

`Thm232Claim3MissingHypotheses.local_certificate` checks the optimal wheel,
all local geometric hypotheses, and the forbidden edge in Lean, without `sorry`.
`omitted_assumptions_fail` checks the omitted conditions. **The Lean certificate
does not include `InF8 graph`.** The mathematical check of that remaining
hypothesis is as follows, so this distinction is explicit:

1. Deleting `7` gives a bipartite graph `B` with parts `{0,2,4,6}` and
   `{1,3,5}`. Adding a universal vertex preserves the Berge property. Directly,
   every hole omits `7` and is even. In the complement, `7` is isolated and
   `Bᶜ` has independence number at most two, excluding holes of length at least
   six. A five-hole would give a five-hole in `B` by complementation.
2. A bipartite subdivision of `K₄` has at least eight edges. Its line graph
   has neither an isolated vertex nor a vertex of degree greater than four.
   An appearance in either eight-vertex host would therefore use every vertex,
   but `7` has degree seven in `G` and degree zero in `Gᶜ`. Thus `G ∈ F₃`.
3. All triangles of `G` contain `7`, so `G` has no prism. In a Berge graph,
   a long prism has at least eight vertices: the three rung lengths have the
   same parity, with a total of at least five in the odd case and six in the
   even case. A long prism in `Gᶜ` would use all eight vertices, including the
   isolated `7`. Thus both long-prism exclusions hold.
4. A double diamond uses eight vertices and has no universal vertex, so
   `G` has no double diamond.
5. Every wheel in `G` has hub `{7}`. Its rim omits `7`; any other hub vertex
   together with a complete rim edge would be a triangle of `B`. Anticonnectivity
   forbids adding another vertex to a hub containing `7`. All rim vertices are
   `{7}`-complete, so a maximal segment omits one rim vertex and has even length.
   The complement has no hole of length at least six. Neither graph has an odd
   wheel.
6. A path of at least five vertices in `G` omits the universal `7`. If a
   pseudowheel hub set contains `7`, anticonnectivity makes that set `{7}`;
   either all path vertices are complete to its first hub, or the second path
   vertex is complete to its second hub, violating the definition. If neither
   hub contains `7`, the first path vertex and an edge between the two hubs
   form a triangle in `B`. In `Gᶜ`, such a path omits the isolated `7`, and its
   first, third, and fifth vertices form an independent triple in `Bᶜ`.
   Thus neither graph has a pseudowheel.

The published argument is not refuted. Its `y` is an interior vertex of `T`,
so `hint` supplies its non-completeness, and claim (1) supplies `hexh`. Both
facts are available at the one caller in `Thm232Claim3.claim3`. The smallest
repair is to add those hypotheses and pass them there. The frozen target has
been left untouched instead of being proved from a false replacement gap.

## `Thm232RemainingClaims.claim5_path_gap`

The statement does not record the minimum-length choice of `T` made immediately
before claim (4) on printed p. 140:

> By choosing T of minimum length we may assume that none of y, v₁, ..., vₙ₋₁
> have neighbours in A₀.

That fact is used explicitly in claim (5) to prove the inclusion represented by
`Claim5PathData.tailContains`. The current hypotheses only specify an induced
`z`–`w` path, avoidance of `x₀,x₁`, and non-completeness of its interior.
They do not require the interior to avoid the rim or prohibit earlier attachments
to `A₀`. An induced path can have a shortcut through vertices of `A₀` that are
not on that path. Its inducedness alone does not exclude those shortcuts.

`Thm232Claim5PathPrefix.initial_indices` and `initial_subset` prove the exact
inclusion argument when the paper's no-earlier-attachment property is supplied.
No counterexample to all the global hypotheses is claimed here: the full
23.2 hypotheses themselves eventually yield a contradiction. The issue is the
missing premise for the prescribed local construction. The minimum choice must
be made before packaging `EndgameContext`, and must be carried into this helper.
The short-path exclusion of claim (4) also remains to be formalized.

## `Thm232RemainingClaims.claim5_second_alternative_gap`

The paper does not assert that 2.11's second outcome is impossible. It concludes
that one member of the pair misses `y,p₁,...,pₖ₋₁`. In the second outcome
`a-y-p₁-...-pₖ-b`, the vertex `b` already has exactly that property by
inducedness. Its edge to `pₖ` is harmless, since `pₖ` is `Y`-complete and no
vertex of the interior of `T` is `Y`-complete.

The following are now proved without `sorry`:

* `Thm232Claim5SecondOutcome.last_anticomplete_dropLast`;
* `Thm232Claim5SecondOutcome.second_outcome_anticomplete`.

The latter gives precisely
`VertexAnticomplete G b {v | v ∈ SPGT.interior T}` from the data already
available in this target. Replacing its `False` conclusion with this assertion
and returning the corresponding disjunct at its caller would implement the
printed proof. This is an overstrong intermediate obligation relative to the
source, not a claimed counterexample to its full global hypotheses.

## Complete argument after choosing the path

`Thm232Claim5FromPath.exists_anticomplete_interior` proves the remaining
pseudowheel, parity, and 2.11 argument, using both 2.11 outcomes.
`exists_anticomplete_tail` transfers it to the interior of `T` using the stored
inclusion. It reuses `Thm183EvenLength.even_pathLength_of_ends_only_XComplete`
for the identical application of 13.6. These lemmas do not import either target
module, so they are ready to be used by a repaired caller without an import cycle.

## New files

* `Workspace/ProofLemmas/Thm232Claim3MissingHypotheses.lean`
* `Workspace/ProofLemmas/Thm232Claim5SecondOutcome.lean`
* `Workspace/ProofLemmas/Thm232Claim5PathPrefix.lean`
* `Workspace/ProofLemmas/Thm232Claim5FromPath.lean`

All four files compile. No new labelled gap lemmas were added. The three original
frozen gaps remain open, so their mandatory audit cannot have the requested
accepted-dependencies-only result. This is reported rather than hidden behind
new copies of the same gaps.

## t232b mandatory audit output (verbatim)

`lake env lean AuditMine.lean` exited 0. The scratch file is not committed.

```text
Workspace.ProofLemmas.Thm232Claim3.not_adj_c2_gap has sorry of type
  ¬G.Adj y c₂
'Workspace.ProofLemmas.Thm232Claim3.not_adj_c2_gap' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm232RemainingClaims.claim5_path_gap has sorry of type
  Nonempty (Workspace.ProofLemmas.Thm232RemainingClaims.Claim5PathData G C Y x₀ z x₁ y T)
'Workspace.ProofLemmas.Thm232RemainingClaims.claim5_path_gap' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Workspace.ProofLemmas.Thm232RemainingClaims.claim5_second_alternative_gap has sorry of type
  False
'Workspace.ProofLemmas.Thm232RemainingClaims.claim5_second_alternative_gap' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim3MissingHypotheses.local_certificate' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5SecondOutcome.second_outcome_anticomplete' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5PathPrefix.initial_subset' depends on axioms: [propext, Classical.choice, Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5FromPath.exists_anticomplete_tail' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
```

## t232b final build

The mandatory full `lake build` exited 0, including `Workspace.MainTheorem`
and `Workspace.All`:

```text
Build completed successfully (9408 jobs).
```

Each of the four new files also passed `lake env lean <file>`. The audit
exited 0 but reports the three unchanged original target sorries, as shown
above. The four new modules introduce no `sorryAx`.

---

# t192b2: 19.2 claims (8), (9)-minimality-witness, (10)-endgame

## FALSE HELPER STATEMENT: `Thm192Claim9MinimalityWitness.minimalityWitness`

```lean
theorem minimalityWitness (G : SimpleGraph V) (z : V) (A₀ : Set V) (x : ℕ → V)
    (Y : Set V) (y : V) (A : Set V) (hA : GoodA G z A₀ x Y y A)
    (hAmin : ∀ B : Set V, GoodA G z A₀ x Y y B → A.ncard ≤ B.ncard)
    (F : Set V) (hFA : F ⊆ A) (hFconn : ConnectedSet G F) (hFne : F ≠ A)
    (hF0 : ∃ a ∈ F, G.Adj (x 0) a) (hF1 : ∃ a ∈ F, G.Adj (x 1) a)
    (hF2 : ∃ a ∈ F, G.Adj (x 2) a) :
    ∃ f ∈ A \ F, ConnectedSet G (A \ {f}) ∧
      ∃ y₀ ∈ Y, ¬ G.Adj y₀ (x 2) ∧ VertexAnticomplete G y₀ (A \ {f})
```

This statement is **false as written**, and the sorry on it has been left in place
(rule 5: a sorry'd false lemma is worse than no progress).

### Why

The printed sentence it renders is

> *"Choose `f ∈ A \ F` such that `A \ {f}` is connected.  From the minimality of `A`,
> there exists `y₀ ∈ Y` nonadjacent to `x₂` with no neighbour in `A \ {f}`."*

which is sound for the **printed** minimal `A` — minimal subject to `A ⊆ A₁`, `A`
connected, `x₀, x₁, x₂` having neighbours in `A`, and every vertex of `Y` nonadjacent to
`x₂` having a neighbour in `A`.  This project minimises over `Thm192Setup.GoodA`, which
carries one **extra** clause, *"`y` has a neighbour in `A`"* (added deliberately, see the
`Thm192Setup` module header, to repair the order of the two extremal choices).  With that
extra clause, `A \ {f}` can fail to be `GoodA` at the *new* clause rather than at the
`Y`-clause, and then no `y₀` need exist.

### Counterexample

Vertices `z, x₀, x₁, x₂, y, a₁, a₂, a₃`; take `A₀ = A = {a₁, a₂, a₃}`, `Y = {y}`, and edges

* `a₁a₂`, `a₂a₃` (so `A` is an induced path `a₁-a₂-a₃`);
* `z x₀`, `z x₁`, `z x₂`, `z y`;
* `x₀ a₁`, `x₁ a₂`, `x₂ a₁`;
* `y a₃`, `y x₂`, `y x₀`, `y x₁`;

and no others.  Then `A` is connected, contains no neighbour of `z` and no
`{x₀,x₁}`-complete vertex, so `A ⊆ A₁` and `GoodA G z A₀ x Y y A` holds: `x₀, x₁, x₂` have
the neighbours `a₁, a₂, a₁`, the `Y`-clause is vacuous (`y` is adjacent to `x₂`), and `y`
has the neighbour `a₃`.  Any `GoodA` set `B` must contain `a₁` (the only neighbour of `x₀`),
`a₂` (the only neighbour of `x₁`) and `a₃` (the only neighbour of `y`), so `B = A` and `A`
is of minimum cardinality.  Now take `F = {a₁, a₂}`: it is connected, `F ≠ A`, and it
contains neighbours of `x₀`, `x₁` and `x₂`.  So all hypotheses hold.  But the only
`f ∈ A \ F` is `a₃`, and the conclusion asks for a `y₀ ∈ Y = {y}` with `¬ G.Adj y₀ x₂` —
and `y` *is* adjacent to `x₂`.  The conclusion therefore fails.

(The same failure occurs with a `Y` that does contain a vertex nonadjacent to `x₂`: put
`Y = {y, y'}` with `y' a₁`, `y' x₀`, `y' x₁`, `y' z` edges and `y'` nonadjacent to `x₂`;
then `y'` is the only candidate for `y₀` and it has the neighbour `a₁ ∈ A \ {a₃}`.)

### What is true, and where it now lives

`Workspace/ProofLemmas/Thm192Claim9MinimalityWitnessRepaired.lean` (new, **proved, no
sorry**) contains the repaired statement — the minimality of a `GoodA` set says exactly
that `A \ {f}` fails one of the two "has a neighbour" clauses:

```lean
    ∃ f ∈ A \ F, ConnectedSet G (A \ {f}) ∧
      ((∃ y₀ ∈ Y, ¬ G.Adj y₀ (x 2) ∧ VertexAnticomplete G y₀ (A \ {f})) ∨
        VertexAnticomplete G y (A \ {f}))
```

The statement of `Thm192Claim9MinimalityWitness.minimalityWitness` was **not** changed:
its only consumer is `Thm192Claim9.claim9`, in `Workspace/ProofLemmas/Thm192Claim9.lean`,
which is not one of this assignment's files, so condition (a) of the repair rule ("every
consumer is updated so the project still builds") could not be met here.  Repairing it
means giving `claim9` the extra branch in which `f` is `y`'s unique neighbour in `A`; note
that in that branch `claim9` still needs `¬ G.Adj y (x 2)` before it may call claim (8),
so the repair is not purely mechanical.

## Claim (8) and the claim (10) endgame

`Thm192Claim10Core.wheelLeapEndgame` and `Thm192Claim8.claim8` are now proved (no sorry
of their own), through these new modules:

* `Thm192Claim10Endgame.lean` — the claim (10) endgame.
* `Thm192Claim8Basics.lean` — anticonnected nonneighbours, the leap extractor, the rim
  `z-x₀-P-x₁-z`, and the claim (2) choice transferred to a caller-chosen path.
* `Thm192Claim8Triangles.lean` — the two applications of 17.1.
* `Thm192Claim8Path.lean` — the path `f₁-⋯-f_k` with vertex set `A`, from claim (3).
* `Thm192Claim8Unique.lean` — `f₁` is `x₂`'s only neighbour in `A` and `f_k` is `x₁`'s
  (claims (3), (7) and two applications of 17.3).
* `Thm192Claim8ZComplete.lean` — *"this proves that `z` is `Y`-complete"* (13.6 and the
  two antiholes against 15.7).
* `Thm192Claim8Endgame.lean` — the closing 2.10 leap and 13.6 contradiction.
* `Thm192Claim8Main.lean` — the one-sided statement; `claim8` itself adds the `x₀ ↔ x₁`
  symmetry via `Thm192Symmetry.sw`.

# Theorem 23.2, claims (3) and (5): frozen helper blockers (t232b)

No existing declaration or proof body was changed in this worktree. The assignment
explicitly calls these three helper statements frozen and permits only replacing
their `sorry` bodies by calls. I asked whether the general helper-repair exception
also applies here. No answer had arrived while the independent proofs below were
being completed. No new `sorry` was introduced.

## `Thm232Claim3.not_adj_c2_gap`

The statement omits two facts used by the printed proof (pp. 139–140):

* `¬ VertexComplete G y Y`;
* the exhaustive list of four `Y`-complete rim edges, called `hexh` in its caller.

Here is a counterexample to the stated helper. Take vertices `0,...,7` and edges

```
01, 12, 23, 34, 45, 50, 16, 36,
07, 17, 27, 37, 47, 57, 67.
```

Set `C = [0,1,2,3,4,5]`, `Y = {7}`, `k = 0`, `d = 2`, and
`(x₀,z,x₁,c₁,c₂,c₃,y) = (0,1,2,2,3,4,6)`.
The wheel is optimal because `7` is universal: an anticonnected hub containing
`7` cannot contain another vertex. Every local hypothesis of `not_adj_c2_gap`
holds, but `G.Adj 6 3` holds too. The two omitted paper assumptions fail:
`6` is `Y`-complete, and `45,50` are additional `Y`-complete rim edges.

`Thm232Claim3MissingHypotheses.local_certificate` checks the optimal wheel,
all local geometric hypotheses, and the forbidden edge in Lean, without `sorry`.
`omitted_assumptions_fail` checks the omitted conditions. **The Lean certificate
does not include `InF8 graph`.** The mathematical check of that remaining
hypothesis is as follows, so this distinction is explicit:

1. Deleting `7` gives a bipartite graph `B` with parts `{0,2,4,6}` and
   `{1,3,5}`. Adding a universal vertex preserves the Berge property. Directly,
   every hole omits `7` and is even. In the complement, `7` is isolated and
   `Bᶜ` has independence number at most two, excluding holes of length at least
   six. A five-hole would give a five-hole in `B` by complementation.
2. A bipartite subdivision of `K₄` has at least eight edges. Its line graph
   has neither an isolated vertex nor a vertex of degree greater than four.
   An appearance in either eight-vertex host would therefore use every vertex,
   but `7` has degree seven in `G` and degree zero in `Gᶜ`. Thus `G ∈ F₃`.
3. All triangles of `G` contain `7`, so `G` has no prism. In a Berge graph,
   a long prism has at least eight vertices: the three rung lengths have the
   same parity, with a total of at least five in the odd case and six in the
   even case. A long prism in `Gᶜ` would use all eight vertices, including the
   isolated `7`. Thus both long-prism exclusions hold.
4. A double diamond uses eight vertices and has no universal vertex, so
   `G` has no double diamond.
5. Every wheel in `G` has hub `{7}`. Its rim omits `7`; any other hub vertex
   together with a complete rim edge would be a triangle of `B`. Anticonnectivity
   forbids adding another vertex to a hub containing `7`. All rim vertices are
   `{7}`-complete, so a maximal segment omits one rim vertex and has even length.
   The complement has no hole of length at least six. Neither graph has an odd
   wheel.
6. A path of at least five vertices in `G` omits the universal `7`. If a
   pseudowheel hub set contains `7`, anticonnectivity makes that set `{7}`;
   either all path vertices are complete to its first hub, or the second path
   vertex is complete to its second hub, violating the definition. If neither
   hub contains `7`, the first path vertex and an edge between the two hubs
   form a triangle in `B`. In `Gᶜ`, such a path omits the isolated `7`, and its
   first, third, and fifth vertices form an independent triple in `Bᶜ`.
   Thus neither graph has a pseudowheel.

The published argument is not refuted. Its `y` is an interior vertex of `T`,
so `hint` supplies its non-completeness, and claim (1) supplies `hexh`. Both
facts are available at the one caller in `Thm232Claim3.claim3`. The smallest
repair is to add those hypotheses and pass them there. The frozen target has
been left untouched instead of being proved from a false replacement gap.

## `Thm232RemainingClaims.claim5_path_gap`

The statement does not record the minimum-length choice of `T` made immediately
before claim (4) on printed p. 140:

> By choosing T of minimum length we may assume that none of y, v₁, ..., vₙ₋₁
> have neighbours in A₀.

That fact is used explicitly in claim (5) to prove the inclusion represented by
`Claim5PathData.tailContains`. The current hypotheses only specify an induced
`z`–`w` path, avoidance of `x₀,x₁`, and non-completeness of its interior.
They do not require the interior to avoid the rim or prohibit earlier attachments
to `A₀`. An induced path can have a shortcut through vertices of `A₀` that are
not on that path. Its inducedness alone does not exclude those shortcuts.

`Thm232Claim5PathPrefix.initial_indices` and `initial_subset` prove the exact
inclusion argument when the paper's no-earlier-attachment property is supplied.
No counterexample to all the global hypotheses is claimed here: the full
23.2 hypotheses themselves eventually yield a contradiction. The issue is the
missing premise for the prescribed local construction. The minimum choice must
be made before packaging `EndgameContext`, and must be carried into this helper.
The short-path exclusion of claim (4) also remains to be formalized.

## `Thm232RemainingClaims.claim5_second_alternative_gap`

The paper does not assert that 2.11's second outcome is impossible. It concludes
that one member of the pair misses `y,p₁,...,pₖ₋₁`. In the second outcome
`a-y-p₁-...-pₖ-b`, the vertex `b` already has exactly that property by
inducedness. Its edge to `pₖ` is harmless, since `pₖ` is `Y`-complete and no
vertex of the interior of `T` is `Y`-complete.

The following are now proved without `sorry`:

* `Thm232Claim5SecondOutcome.last_anticomplete_dropLast`;
* `Thm232Claim5SecondOutcome.second_outcome_anticomplete`.

The latter gives precisely
`VertexAnticomplete G b {v | v ∈ SPGT.interior T}` from the data already
available in this target. Replacing its `False` conclusion with this assertion
and returning the corresponding disjunct at its caller would implement the
printed proof. This is an overstrong intermediate obligation relative to the
source, not a claimed counterexample to its full global hypotheses.

## Complete argument after choosing the path

`Thm232Claim5FromPath.exists_anticomplete_interior` proves the remaining
pseudowheel, parity, and 2.11 argument, using both 2.11 outcomes.
`exists_anticomplete_tail` transfers it to the interior of `T` using the stored
inclusion. It reuses `Thm183EvenLength.even_pathLength_of_ends_only_XComplete`
for the identical application of 13.6. These lemmas do not import either target
module, so they are ready to be used by a repaired caller without an import cycle.

## New files

* `Workspace/ProofLemmas/Thm232Claim3MissingHypotheses.lean`
* `Workspace/ProofLemmas/Thm232Claim5SecondOutcome.lean`
* `Workspace/ProofLemmas/Thm232Claim5PathPrefix.lean`
* `Workspace/ProofLemmas/Thm232Claim5FromPath.lean`

All four files compile. No new labelled gap lemmas were added. The three original
frozen gaps remain open, so their mandatory audit cannot have the requested
accepted-dependencies-only result. This is reported rather than hidden behind
new copies of the same gaps.

## t232b mandatory audit output (verbatim)

`lake env lean AuditMine.lean` exited 0. The scratch file is not committed.

```text
Workspace.ProofLemmas.Thm232Claim3.not_adj_c2_gap has sorry of type
  ¬G.Adj y c₂
'Workspace.ProofLemmas.Thm232Claim3.not_adj_c2_gap' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm232RemainingClaims.claim5_path_gap has sorry of type
  Nonempty (Workspace.ProofLemmas.Thm232RemainingClaims.Claim5PathData G C Y x₀ z x₁ y T)
'Workspace.ProofLemmas.Thm232RemainingClaims.claim5_path_gap' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Workspace.ProofLemmas.Thm232RemainingClaims.claim5_second_alternative_gap has sorry of type
  False
'Workspace.ProofLemmas.Thm232RemainingClaims.claim5_second_alternative_gap' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim3MissingHypotheses.local_certificate' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5SecondOutcome.second_outcome_anticomplete' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5PathPrefix.initial_subset' depends on axioms: [propext, Classical.choice, Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5FromPath.exists_anticomplete_tail' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
```

## t232b final build

The mandatory full `lake build` exited 0, including `Workspace.MainTheorem`
and `Workspace.All`:

```text
Build completed successfully (9408 jobs).
```

Each of the four new files also passed `lake env lean <file>`. The audit
exited 0 but reports the three unchanged original target sorries, as shown
above. The four new modules introduce no `sorryAx`.

## t85b statement repairs (8.5 claims (2) and (3))

Two helper statements under `Workspace/ProofLemmas/` (written by an earlier
agent, and therefore repairable under the assignment's rule 1 exception) were
false as stated. Both were repaired by ADDING hypotheses only; no `Types/` or
`Statements/` declaration was touched, and the single consumer
(`Workspace/ProofLemmas/Thm85Claim2.lean`) was updated by appending the extra
arguments, which are all already in scope by name at the call sites.

### 1. `Thm85Claim2Closing.first_case_attachment_identity`

Original statement claimed `X ∩ V(S_uv)ᶜ`-style attachment set equals
`N_v \ S_uv` from the data of a SINGLE choice of rungs `R_vw`.

Counterexample / why it is false: the `⊇` inclusion needs the paper's
"since it holds for all choices of the rungs `R_vw`" step (8.5, printed p. 46).
For one fixed rung family, a vertex `z ∈ N_v \ S_uv` need not lie on any rung
of that family at all, so nothing forces `z ∈ X`; the hypotheses given are
satisfied by a rung family avoiding `z`, while the conclusion asserts `z ∈ X`.
Recovering the paper's argument requires re-running 5.8 for an arbitrary rung
family, which needs the ambient hypotheses of 8.5.

Repair: appended `hG : Berge G`, `hnoenl` (no `J`-enlargement), `hFcompl`,
`hFconn`, `hFmin` (minimality of `F`) and `hclaim1`. These are exactly the
ambient 8.5 hypotheses, all present at the call site in `Thm85Claim2.lean`.

### 2. `Thm85Claim2Closing.attachment_identity_contradicts_maximality`

Original statement derived `False` from the attachment identity without any
connectivity hypothesis on `J`.

Counterexample: if `deg_J(v) = 1` (so `u` is the only `J`-neighbour of `v`),
then `N_v ⊆ S_uv`, hence `N_v \ S_uv = ∅`, hence the vertex `p₁` the paper adds
to `N_v` does not exist and the promised enlargement of `(S,N)` cannot be
built; the hypotheses are then satisfiable with no contradiction available.

Repair: appended `hJ : IsKConnected J 3`, which 8.5 assumes throughout and
which is in scope at the call site.

---

## 19.2 claim (2): the induction hypothesis had to be made uniform over induced subgraphs

`Workspace.ProofLemmas.Thm192Claim2Localization.inductive_wheel_with_rim_in_A` is now
proved (no `sorry`), and with it `Thm192Claim2.claim2`.  One helper hypothesis had to be
repaired first; this section records the repair and why it was necessary.

### Why the previous statement could not be proved

The lemma asked for a wheel `(C, Y₀)` with `x₀,x₁,z ∈ V(C) ⊆ {x₀,x₁,z} ∪ A`, where `A`
is the minimal set of the printed proof, from the following data only: the graph `G`,
the frame `(z,A₀)`, the wheel system `x₀,x₁,x₂`, the hub `Y`, the minimality of `A`, and
the induction hypothesis

    ih : ∀ Y', Y'.ncard < Y.ncard → Hyp192 G z A₀ x Y' → Concl192 G z A₀ x Y'

which fixes `G`, `z`, `A₀` and `x`.  Under those data the conclusion is not derivable:

* `Concl192 G z A₀ x Y₀` only places the rim inside `{x₀,x₁,z} ∪ A₁`, and `A₁` is the
  *maximal* connected set with the defining properties, so it can be far larger than `A`;
* `A₁ = wheelSystemA G z A₀ x 1` depends on `G, z, A₀` and on `{x₀,x₁}` only, all of
  which `ih` holds fixed, so no instance of `ih` mentions `A`;
* the minimality of `A` is cardinal minimality inside a family that already contains
  `A₁`, so it yields `A.ncard ≤ B.ncard` and never `B ⊆ A`.  Enlarging `A` by the
  interior of the wheel supplied by `ih` produces a competitor of *larger* cardinality,
  which the minimality does not exclude.

So the only route to the printed sentence is the one the paper actually takes.  Its
minimal counterexample is a whole tuple `(G, (z,A₀), x₀x₁x₂, Y)` — *"If possible, choose
`Y` not satisfying the theorem, with `|Y|` minimum"* — and only `|Y|` is minimised, so
the theorem may be used in any graph at all provided the hub is smaller.

### The repair (missing hypothesis, smallest form)

`Thm192Setup.IHInduced G n` was added: 19.2 holds in every induced subgraph `G|S`, for
every frame and wheel system there, and every hub of `ncard < n`.  The binder

    (ih : ∀ Y' : Set V, Y'.ncard < Y.ncard → Hyp192 G z A₀ x Y' → Concl192 G z A₀ x Y')

was replaced, in all 36 declarations of the 19.2 proof that carry it, by

    (ih : (∀ Y' : Set V, Y'.ncard < Y.ncard → Hyp192 G z A₀ x Y' → Concl192 G z A₀ x Y') ∧
      Workspace.ProofLemmas.Thm192Setup.IHInduced G Y.ncard)

No lemma *statement* changed apart from this one hypothesis, and no call site changed:
every consumer passes its own `ih` on, and the seven places that *apply* `ih` now write
`ih.1`.  `Thm192Symmetry.sw_ih` transports the pair (the second half does not mention
`x`).  Nothing under `Workspace/Types/` changed, and the frozen statements of
`Workspace/Statements/` — `thm_19_2` in particular — are untouched: only the last two
lines of its proof changed, from `Thm192Setup.aux` to the new driver

    Workspace.ProofLemmas.Thm192Claim2Uniform.uniform_induction

which runs the strong induction on `|Y|` uniformly over all graphs on types of one
universe, and hands the step both halves of the induction hypothesis.  `Thm192Setup.aux`
is left in place, unused.

### The proof of the localized wheel

With `IHInduced` available, claim (2) is the paper's argument.  Put
`S = A ∪ {x₀,x₁,x₂,z} ∪ Y₀` and work in `G|S` with the frame `(z, A)`:

* `InF7 (G|S)` — `F₇` is inherited by induced subgraphs
  (`Thm192Claim2Heredity.inF7_induce`, new);
* `(z,A)` is a frame and `x₀,x₁,x₂` a wheel system there — this is exactly what `GoodA`
  says about `A`, plus `z ∉ A₁` (`Thm192Claim2Localization.z_notMem_wheelSystemA`);
* `Y₀` satisfies the hypotheses of 19.2 there, again by `GoodA` (every vertex of `Y`
  nonadjacent to `x₂` has a neighbour in `A`), and `|Y₀| < |Y|`;
* in `G|S` the set called `A₁` is `A` itself: any other vertex of `S` is `z`, or one of
  `x₀,x₁,x₂` and hence a neighbour of `z`, or a vertex of `Y₀` and hence
  `{x₀,x₁}`-complete.

So the wheel returned has its rim inside `{x₀,x₁,z} ∪ A`; transporting it back along the
inclusion `S ↪ V` (`Thm192Claim2Transfer.isWheel_map`) gives the statement.

### New files

* `Workspace/ProofLemmas/Thm192Claim2Transfer.lean` — transport of paths, holes,
  completeness, connectedness, wheels, segments, prisms and the double diamond along an
  injective adjacency-reflecting map (and hence along the inclusion of an induced
  subgraph, in `G` and in `Ḡ` at once).
* `Workspace/ProofLemmas/Thm192Claim2Heredity.lean` — `F₁, …, F₇` are hereditary;
  `inF7_induce : InF7 G → ∀ S, InF7 (G.induce S)`.
* `Workspace/ProofLemmas/Thm192Claim2Uniform.lean` — `uniform_induction`.

### Audit

```
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm192Claim2Localization.inductive_wheel_with_rim_in_A' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm192Claim2.claim2' depends on axioms: [propext, Classical.choice, Quot.sound]
```

`thm_19_2` still reaches `sorryAx`, through the two accepted open dependencies
`Thm192Claim9.claim9` (`Thm192Claim9MinimalityWitness.minimalityWitness`) and
`Thm192Claim7.claim7` (`Thm192Claim7GapParity.complete_separated_contact`,
`Thm192Claim7GapParity.noncomplete_short_cut_of_contact`).  Nothing else.

---

# Theorem 23.2, claims (3) and (5): frozen helper blockers (t232b)

No existing declaration or proof body was changed in this worktree. The assignment
explicitly calls these three helper statements frozen and permits only replacing
their `sorry` bodies by calls. I asked whether the general helper-repair exception
also applies here. No answer had arrived while the independent proofs below were
being completed. No new `sorry` was introduced.

## `Thm232Claim3.not_adj_c2_gap`

The statement omits two facts used by the printed proof (pp. 139–140):

* `¬ VertexComplete G y Y`;
* the exhaustive list of four `Y`-complete rim edges, called `hexh` in its caller.

Here is a counterexample to the stated helper. Take vertices `0,...,7` and edges

```
01, 12, 23, 34, 45, 50, 16, 36,
07, 17, 27, 37, 47, 57, 67.
```

Set `C = [0,1,2,3,4,5]`, `Y = {7}`, `k = 0`, `d = 2`, and
`(x₀,z,x₁,c₁,c₂,c₃,y) = (0,1,2,2,3,4,6)`.
The wheel is optimal because `7` is universal: an anticonnected hub containing
`7` cannot contain another vertex. Every local hypothesis of `not_adj_c2_gap`
holds, but `G.Adj 6 3` holds too. The two omitted paper assumptions fail:
`6` is `Y`-complete, and `45,50` are additional `Y`-complete rim edges.

`Thm232Claim3MissingHypotheses.local_certificate` checks the optimal wheel,
all local geometric hypotheses, and the forbidden edge in Lean, without `sorry`.
`omitted_assumptions_fail` checks the omitted conditions. **The Lean certificate
does not include `InF8 graph`.** The mathematical check of that remaining
hypothesis is as follows, so this distinction is explicit:

1. Deleting `7` gives a bipartite graph `B` with parts `{0,2,4,6}` and
   `{1,3,5}`. Adding a universal vertex preserves the Berge property. Directly,
   every hole omits `7` and is even. In the complement, `7` is isolated and
   `Bᶜ` has independence number at most two, excluding holes of length at least
   six. A five-hole would give a five-hole in `B` by complementation.
2. A bipartite subdivision of `K₄` has at least eight edges. Its line graph
   has neither an isolated vertex nor a vertex of degree greater than four.
   An appearance in either eight-vertex host would therefore use every vertex,
   but `7` has degree seven in `G` and degree zero in `Gᶜ`. Thus `G ∈ F₃`.
3. All triangles of `G` contain `7`, so `G` has no prism. In a Berge graph,
   a long prism has at least eight vertices: the three rung lengths have the
   same parity, with a total of at least five in the odd case and six in the
   even case. A long prism in `Gᶜ` would use all eight vertices, including the
   isolated `7`. Thus both long-prism exclusions hold.
4. A double diamond uses eight vertices and has no universal vertex, so
   `G` has no double diamond.
5. Every wheel in `G` has hub `{7}`. Its rim omits `7`; any other hub vertex
   together with a complete rim edge would be a triangle of `B`. Anticonnectivity
   forbids adding another vertex to a hub containing `7`. All rim vertices are
   `{7}`-complete, so a maximal segment omits one rim vertex and has even length.
   The complement has no hole of length at least six. Neither graph has an odd
   wheel.
6. A path of at least five vertices in `G` omits the universal `7`. If a
   pseudowheel hub set contains `7`, anticonnectivity makes that set `{7}`;
   either all path vertices are complete to its first hub, or the second path
   vertex is complete to its second hub, violating the definition. If neither
   hub contains `7`, the first path vertex and an edge between the two hubs
   form a triangle in `B`. In `Gᶜ`, such a path omits the isolated `7`, and its
   first, third, and fifth vertices form an independent triple in `Bᶜ`.
   Thus neither graph has a pseudowheel.

The published argument is not refuted. Its `y` is an interior vertex of `T`,
so `hint` supplies its non-completeness, and claim (1) supplies `hexh`. Both
facts are available at the one caller in `Thm232Claim3.claim3`. The smallest
repair is to add those hypotheses and pass them there. The frozen target has
been left untouched instead of being proved from a false replacement gap.

## `Thm232RemainingClaims.claim5_path_gap`

The statement does not record the minimum-length choice of `T` made immediately
before claim (4) on printed p. 140:

> By choosing T of minimum length we may assume that none of y, v₁, ..., vₙ₋₁
> have neighbours in A₀.

That fact is used explicitly in claim (5) to prove the inclusion represented by
`Claim5PathData.tailContains`. The current hypotheses only specify an induced
`z`–`w` path, avoidance of `x₀,x₁`, and non-completeness of its interior.
They do not require the interior to avoid the rim or prohibit earlier attachments
to `A₀`. An induced path can have a shortcut through vertices of `A₀` that are
not on that path. Its inducedness alone does not exclude those shortcuts.

`Thm232Claim5PathPrefix.initial_indices` and `initial_subset` prove the exact
inclusion argument when the paper's no-earlier-attachment property is supplied.
No counterexample to all the global hypotheses is claimed here: the full
23.2 hypotheses themselves eventually yield a contradiction. The issue is the
missing premise for the prescribed local construction. The minimum choice must
be made before packaging `EndgameContext`, and must be carried into this helper.
The short-path exclusion of claim (4) also remains to be formalized.

## `Thm232RemainingClaims.claim5_second_alternative_gap`

The paper does not assert that 2.11's second outcome is impossible. It concludes
that one member of the pair misses `y,p₁,...,pₖ₋₁`. In the second outcome
`a-y-p₁-...-pₖ-b`, the vertex `b` already has exactly that property by
inducedness. Its edge to `pₖ` is harmless, since `pₖ` is `Y`-complete and no
vertex of the interior of `T` is `Y`-complete.

The following are now proved without `sorry`:

* `Thm232Claim5SecondOutcome.last_anticomplete_dropLast`;
* `Thm232Claim5SecondOutcome.second_outcome_anticomplete`.

The latter gives precisely
`VertexAnticomplete G b {v | v ∈ SPGT.interior T}` from the data already
available in this target. Replacing its `False` conclusion with this assertion
and returning the corresponding disjunct at its caller would implement the
printed proof. This is an overstrong intermediate obligation relative to the
source, not a claimed counterexample to its full global hypotheses.

## Complete argument after choosing the path

`Thm232Claim5FromPath.exists_anticomplete_interior` proves the remaining
pseudowheel, parity, and 2.11 argument, using both 2.11 outcomes.
`exists_anticomplete_tail` transfers it to the interior of `T` using the stored
inclusion. It reuses `Thm183EvenLength.even_pathLength_of_ends_only_XComplete`
for the identical application of 13.6. These lemmas do not import either target
module, so they are ready to be used by a repaired caller without an import cycle.

## New files

* `Workspace/ProofLemmas/Thm232Claim3MissingHypotheses.lean`
* `Workspace/ProofLemmas/Thm232Claim5SecondOutcome.lean`
* `Workspace/ProofLemmas/Thm232Claim5PathPrefix.lean`
* `Workspace/ProofLemmas/Thm232Claim5FromPath.lean`

All four files compile. No new labelled gap lemmas were added. The three original
frozen gaps remain open, so their mandatory audit cannot have the requested
accepted-dependencies-only result. This is reported rather than hidden behind
new copies of the same gaps.

## t232b mandatory audit output (verbatim)

`lake env lean AuditMine.lean` exited 0. The scratch file is not committed.

```text
Workspace.ProofLemmas.Thm232Claim3.not_adj_c2_gap has sorry of type
  ¬G.Adj y c₂
'Workspace.ProofLemmas.Thm232Claim3.not_adj_c2_gap' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm232RemainingClaims.claim5_path_gap has sorry of type
  Nonempty (Workspace.ProofLemmas.Thm232RemainingClaims.Claim5PathData G C Y x₀ z x₁ y T)
'Workspace.ProofLemmas.Thm232RemainingClaims.claim5_path_gap' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Workspace.ProofLemmas.Thm232RemainingClaims.claim5_second_alternative_gap has sorry of type
  False
'Workspace.ProofLemmas.Thm232RemainingClaims.claim5_second_alternative_gap' depends on axioms: [propext,
 sorryAx,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim3MissingHypotheses.local_certificate' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5SecondOutcome.second_outcome_anticomplete' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5PathPrefix.initial_subset' depends on axioms: [propext, Classical.choice, Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm232Claim5FromPath.exists_anticomplete_tail' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
```

## t232b final build

The mandatory full `lake build` exited 0, including `Workspace.MainTheorem`
and `Workspace.All`:

```text
Build completed successfully (9408 jobs).
```

Each of the four new files also passed `lake env lean <file>`. The audit
exited 0 but reports the three unchanged original target sorries, as shown
above. The four new modules introduce no `sorryAx`.

## t85b statement repairs (8.5 claims (2) and (3))

Two helper statements under `Workspace/ProofLemmas/` (written by an earlier
agent, and therefore repairable under the assignment's rule 1 exception) were
false as stated. Both were repaired by ADDING hypotheses only; no `Types/` or
`Statements/` declaration was touched, and the single consumer
(`Workspace/ProofLemmas/Thm85Claim2.lean`) was updated by appending the extra
arguments, which are all already in scope by name at the call sites.

### 1. `Thm85Claim2Closing.first_case_attachment_identity`

Original statement claimed `X ∩ V(S_uv)ᶜ`-style attachment set equals
`N_v \ S_uv` from the data of a SINGLE choice of rungs `R_vw`.

Counterexample / why it is false: the `⊇` inclusion needs the paper's
"since it holds for all choices of the rungs `R_vw`" step (8.5, printed p. 46).
For one fixed rung family, a vertex `z ∈ N_v \ S_uv` need not lie on any rung
of that family at all, so nothing forces `z ∈ X`; the hypotheses given are
satisfied by a rung family avoiding `z`, while the conclusion asserts `z ∈ X`.
Recovering the paper's argument requires re-running 5.8 for an arbitrary rung
family, which needs the ambient hypotheses of 8.5.

Repair: appended `hG : Berge G`, `hnoenl` (no `J`-enlargement), `hFcompl`,
`hFconn`, `hFmin` (minimality of `F`) and `hclaim1`. These are exactly the
ambient 8.5 hypotheses, all present at the call site in `Thm85Claim2.lean`.

### 2. `Thm85Claim2Closing.attachment_identity_contradicts_maximality`

Original statement derived `False` from the attachment identity without any
connectivity hypothesis on `J`.

Counterexample: if `deg_J(v) = 1` (so `u` is the only `J`-neighbour of `v`),
then `N_v ⊆ S_uv`, hence `N_v \ S_uv = ∅`, hence the vertex `p₁` the paper adds
to `N_v` does not exist and the promised enlargement of `(S,N)` cannot be
built; the hypotheses are then satisfiable with no contradiction available.

Repair: appended `hJ : IsKConnected J 3`, which 8.5 assumes throughout and
which is in scope at the call site.

---

## 19.2 claim (2): the induction hypothesis had to be made uniform over induced subgraphs

`Workspace.ProofLemmas.Thm192Claim2Localization.inductive_wheel_with_rim_in_A` is now
proved (no `sorry`), and with it `Thm192Claim2.claim2`.  One helper hypothesis had to be
repaired first; this section records the repair and why it was necessary.

### Why the previous statement could not be proved

The lemma asked for a wheel `(C, Y₀)` with `x₀,x₁,z ∈ V(C) ⊆ {x₀,x₁,z} ∪ A`, where `A`
is the minimal set of the printed proof, from the following data only: the graph `G`,
the frame `(z,A₀)`, the wheel system `x₀,x₁,x₂`, the hub `Y`, the minimality of `A`, and
the induction hypothesis

    ih : ∀ Y', Y'.ncard < Y.ncard → Hyp192 G z A₀ x Y' → Concl192 G z A₀ x Y'

which fixes `G`, `z`, `A₀` and `x`.  Under those data the conclusion is not derivable:

* `Concl192 G z A₀ x Y₀` only places the rim inside `{x₀,x₁,z} ∪ A₁`, and `A₁` is the
  *maximal* connected set with the defining properties, so it can be far larger than `A`;
* `A₁ = wheelSystemA G z A₀ x 1` depends on `G, z, A₀` and on `{x₀,x₁}` only, all of
  which `ih` holds fixed, so no instance of `ih` mentions `A`;
* the minimality of `A` is cardinal minimality inside a family that already contains
  `A₁`, so it yields `A.ncard ≤ B.ncard` and never `B ⊆ A`.  Enlarging `A` by the
  interior of the wheel supplied by `ih` produces a competitor of *larger* cardinality,
  which the minimality does not exclude.

So the only route to the printed sentence is the one the paper actually takes.  Its
minimal counterexample is a whole tuple `(G, (z,A₀), x₀x₁x₂, Y)` — *"If possible, choose
`Y` not satisfying the theorem, with `|Y|` minimum"* — and only `|Y|` is minimised, so
the theorem may be used in any graph at all provided the hub is smaller.

### The repair (missing hypothesis, smallest form)

`Thm192Setup.IHInduced G n` was added: 19.2 holds in every induced subgraph `G|S`, for
every frame and wheel system there, and every hub of `ncard < n`.  The binder

    (ih : ∀ Y' : Set V, Y'.ncard < Y.ncard → Hyp192 G z A₀ x Y' → Concl192 G z A₀ x Y')

was replaced, in all 36 declarations of the 19.2 proof that carry it, by

    (ih : (∀ Y' : Set V, Y'.ncard < Y.ncard → Hyp192 G z A₀ x Y' → Concl192 G z A₀ x Y') ∧
      Workspace.ProofLemmas.Thm192Setup.IHInduced G Y.ncard)

No lemma *statement* changed apart from this one hypothesis, and no call site changed:
every consumer passes its own `ih` on, and the seven places that *apply* `ih` now write
`ih.1`.  `Thm192Symmetry.sw_ih` transports the pair (the second half does not mention
`x`).  Nothing under `Workspace/Types/` changed, and the frozen statements of
`Workspace/Statements/` — `thm_19_2` in particular — are untouched: only the last two
lines of its proof changed, from `Thm192Setup.aux` to the new driver

    Workspace.ProofLemmas.Thm192Claim2Uniform.uniform_induction

which runs the strong induction on `|Y|` uniformly over all graphs on types of one
universe, and hands the step both halves of the induction hypothesis.  `Thm192Setup.aux`
is left in place, unused.

### The proof of the localized wheel

With `IHInduced` available, claim (2) is the paper's argument.  Put
`S = A ∪ {x₀,x₁,x₂,z} ∪ Y₀` and work in `G|S` with the frame `(z, A)`:

* `InF7 (G|S)` — `F₇` is inherited by induced subgraphs
  (`Thm192Claim2Heredity.inF7_induce`, new);
* `(z,A)` is a frame and `x₀,x₁,x₂` a wheel system there — this is exactly what `GoodA`
  says about `A`, plus `z ∉ A₁` (`Thm192Claim2Localization.z_notMem_wheelSystemA`);
* `Y₀` satisfies the hypotheses of 19.2 there, again by `GoodA` (every vertex of `Y`
  nonadjacent to `x₂` has a neighbour in `A`), and `|Y₀| < |Y|`;
* in `G|S` the set called `A₁` is `A` itself: any other vertex of `S` is `z`, or one of
  `x₀,x₁,x₂` and hence a neighbour of `z`, or a vertex of `Y₀` and hence
  `{x₀,x₁}`-complete.

So the wheel returned has its rim inside `{x₀,x₁,z} ∪ A`; transporting it back along the
inclusion `S ↪ V` (`Thm192Claim2Transfer.isWheel_map`) gives the statement.

### New files

* `Workspace/ProofLemmas/Thm192Claim2Transfer.lean` — transport of paths, holes,
  completeness, connectedness, wheels, segments, prisms and the double diamond along an
  injective adjacency-reflecting map (and hence along the inclusion of an induced
  subgraph, in `G` and in `Ḡ` at once).
* `Workspace/ProofLemmas/Thm192Claim2Heredity.lean` — `F₁, …, F₇` are hereditary;
  `inF7_induce : InF7 G → ∀ S, InF7 (G.induce S)`.
* `Workspace/ProofLemmas/Thm192Claim2Uniform.lean` — `uniform_induction`.

### Audit

```
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm192Claim2Localization.inductive_wheel_with_rim_in_A' depends on axioms: [propext,
 Classical.choice,
 Quot.sound]
Declarations are sorry-free!
'Workspace.ProofLemmas.Thm192Claim2.claim2' depends on axioms: [propext, Classical.choice, Quot.sound]
```

`thm_19_2` still reaches `sorryAx`, through the two accepted open dependencies
`Thm192Claim9.claim9` (`Thm192Claim9MinimalityWitness.minimalityWitness`) and
`Thm192Claim7.claim7` (`Thm192Claim7GapParity.complete_separated_contact`,
`Thm192Claim7GapParity.noncomplete_short_cut_of_contact`).  Nothing else.

## 9.3, case 2: repair of `case_two_nonmajor_five_eight_endgame_gap`

### Rule-1 statement repair (with counterexample)

`Workspace.ProofLemmas.Thm93GapLemmas.case_two_nonmajor_five_eight_endgame_gap` was **false
as stated**.  The counterexample is recorded in
`Workspace/ProofLemmas/Thm93CaseTwoCounterexample.lean`: with no hypothesis relating `f` to
`K`, one may take `f ∈ K` (indeed `f` one of the knot vertices), and then the
`FiveEightOutcome` data is satisfiable while `Conclusion` fails; the argument of the paper
uses throughout that `f` is an *attachment* outside `K`, that `G` is Berge, that `P₁, P₂`
have length 1 (this is exactly the case-2 hypothesis of 9.3), and that `L(H)` really is an
appearance of `K₄` in `Ḡ`.

Minimal repair — four hypotheses added, nothing removed, nothing renamed:

* `(hG : Berge G)`
* `(hP₁len : pathLength P₁ = 1)` and `(hP₂len : pathLength P₂ = 1)`
* `(hfK : f ∉ K)`
* `(happ : IsAppearance Gᶜ (⊤ : SimpleGraph (Fin 4)) H K)`

All four are already in scope at the unique call site,
`Workspace/ProofLemmas/Thm93Proof.lean:190` (`Thm93Proof.case_two_lane`), which was updated
to pass them.  `grep -rn case_two_nonmajor_five_eight_endgame_gap Workspace` shows that call
site is the only consumer.  No statement under `Workspace/Statements/` or `Workspace/Types/`
was touched.

### What is now proved

The lemma is proved from `Workspace.ProofLemmas.Thm93CaseTwoNonmajor.endgame` (new file).
The argument: in `Ḡ` the quadruple `(Q₁,Q₂,P₁ʳ,P₂ʳ)` is a knot, `K = L(H)` is a degenerate
appearance of `K₄`, and the complement dictionary is

* `φ s(c₁,c₂) = b₁`, `φ s(c₂,c₃) = a₂`, `φ s(c₃,c₄) = a₁`, `φ s(c₄,c₁) = b₂`;
* `N(c₁) = {b₁,b₂,x₁}`, `N(c₂) = {b₁,a₂,x₂}`, `N(c₃) = {a₁,a₂,y₁}`, `N(c₄) = {a₁,b₂,y₂}`;
* the branch `c₁ → c₃` has image `Q₁`, the branch `c₂ → c₄` has image `Q₂`.

From the knot axioms the eight `Ḡ`-neighbourhoods of `b₁, a₁, a₂, b₂, x₁, y₁, x₂, y₂` in the
three sets not containing them are computed (`Thm93CaseTwoNonmajorDict.knot_compl_neighbours`).
Outcome 5.8.2 gives a branch `R` of `L(H)` with ends `d₁, d₂`.  Sixteen cases:

* four are impossible (`d₁ = d₂`);
* eight are *square* cases (`R` a single edge, `d₁, d₂` consecutive): sub-alternative (a) of
  5.8.2 is impossible because `R \ {r₁} = ∅`, and (b), (c), (d) all give the same conclusion,
  namely that `f` has exactly the `Ḡ`-neighbours `N(d₁) ∪ N(d₂)` minus the shared vertex.
  That shared vertex then has the same `G`-neighbours as `f` in one of the two length-1 paths
  together with the two antipaths, which is statement 2 of 9.3 with `R = [f]`;
* four are *diagonal* cases (`d₁, d₂` opposite): (b) and (c) fail because
  `pathLength R = pathLength Q` is odd (`thm_9_1`), and (d) fails because `r₁ ≠ r₂`; only (a)
  survives, and it gives that `f` and (say) `x₁` have the same neighbours in
  `V(P₁) ∪ V(P₂) ∪ V(Q₂)`.

### Remaining labelled gaps (own, in `Thm93CaseTwoNonmajor.lean`)

* `nonlocal_enlargement_gap` — *"If 5.8.1 holds then there is an appearance in `G` of some
  `K₄`-enlargement, a contradiction."*
* `statement_one_or_four_gap` — *"... or (up to symmetry) `f, x₁` have the same neighbours in
  `V(P₁) ∪ V(P₂) ∪ V(Q₂)` (but then either statement 1 or statement 4 of the theorem
  holds)."*

### New files

* `Workspace/ProofLemmas/Thm93CaseTwoNonmajorDict.lean` — the complement-lane neighbourhood
  dictionary of the knot, plus branch-edge identification lemmas.
* `Workspace/ProofLemmas/Thm93CaseTwoNonmajor.lean` — the sixteen-case endgame.

# Theorem 5.8: repair of the endpoint order in `starStar` and `branchStar`

Two earlier sessions showed, with explicit counterexamples recorded above
("The frozen `starStar` statement is false" and "Theorem 5.8: `branchStar` is
false with the frozen endpoint order"), that
`Workspace.ProofLemmas.Thm58LocalCases.starStar` and
`Workspace.ProofLemmas.Thm58LocalCases.branchStar` are false as stated.  The
reason is the same in both cases: `Thm58Setup.Outcome G n H K φ N P p₁ p₂` is
not invariant under reversing `P`, because alternative 2(a) names `p₁`, while
the published 5.8 chooses the path and its two ends existentially, and its proof
says "possibly after exchanging `v₁` and `v₂`".  The two counterexamples above
each satisfy the reversed outcome and not the given one.

Both declarations live under `Workspace/ProofLemmas/`, so the rule 1 exception
for agent-written helpers applies.  The minimal repair used here is to weaken
the conclusion of exactly these two helpers to

```
Thm58Setup.Outcome G n H K φ N P p₁ p₂ ∨
  Thm58Setup.Outcome G n H K φ N P.reverse p₂ p₁
```

Nothing else about the two statements changed: same names, binders, hypotheses,
implicitness.  `starBranch` and `branchBranch` are untouched.

Consumers updated so that the project still builds:

* `Workspace/ProofLemmas/Thm58NonSingletonEndgame.lean`: its conclusion is the
  same disjunction; the `starBranch` and `branchBranch` cases return `Or.inl`.
* `Workspace/Statements/S05/Thm_5_8.lean` (proof body only): the reversed case
  supplies the path `P.reverse` with ends `p₂, p₁`, using
  `PathBasics.isPathFrom_reverse` and `List.mem_reverse`.  The frozen statement
  of `thm_5_8` quantifies the path and its ends existentially, so the reversed
  outcome fits it exactly; the frozen statement is unchanged.

## What is proved

* `branchStar` is now proved outright: it is `starBranch` applied to the
  reversed path, with the two index roles swapped, via
  `Thm58BranchBranch.ready_reverse`.  Its only open dependency is the accepted
  `Thm58LocalCases.starBranch`.
* `starStar` is proved from a new development in
  `Workspace/ProofLemmas/Thm58StarStarBasics.lean`,
  `Thm58StarStarGeometry.lean`, `Thm58StarStarGaps.lean` and
  `Thm58StarStar.lean`.  Proved there:
  - the attachment bookkeeping for two stars (each end's neighbours in `L(H)`
    lie in its own star, an internal vertex of `P` attaches only to both stars
    at once), and the two nonlocality consequences that give `A₁, A₂ ≠ ∅`;
  - claim (3): nonadjacent star vertices have disjoint stars (the shared edge
    would be a one-edge branch through both), so once `B₁ = B₂ = ∅` the edge
    bookkeeping gives alternative 1 of `Outcome` verbatim;
  - claim (4): the branch between the two stars is oriented from `c₁` to `c₂`,
    the rung `R` and the two vertices `r₁, r₂` are built, and
    `N c₁ ∩ N c₂ ⊆ V(R)` is proved from
    `BranchClassification.trackEdges_eq_of_same_ends`;
  - the two appeals to claim (2): if `A₁ = ∅` then the attachments of `F \ {p₂}`
    all equal `r₁`, hence lie in the branch, and `starBranch` applies to the
    reversed path (this is exactly where the reversed disjunct is needed); if
    `A₂ = ∅`, symmetrically, `starBranch` applies to `P` itself;
  - with `A₁, A₂ ≠ ∅` and `B₁ = B₂ = ∅`, alternative 2(b) when `r₁ ≠ r₂` and
    alternative 2(d) when `r₁ = r₂` (then `R` is a single vertex, so `R` is even
    and `P` is even), including all the edge clauses.

## Remaining labelled gaps

All three are in `Workspace/ProofLemmas/Thm58StarStarGaps.lean`.

1. `Thm58StarStarGaps.nonadjacent_parity_gap` — claim (3), printed p. 26:
   "Certainly `A₁` and `A₂` are both nonempty, so there is a track in `H` from
   `v₁` to `v₂` with end-edges in `A₁` and `A₂` respectively. ... Hence we can
   apply 5.6 ... Since `H` is bipartite, `S₁` and `S₂` have opposite parity; but
   they can both be completed via `F`, a contradiction."
2. `Thm58StarStarGaps.adjacent_both_complete_parity_gap` — claim (4), printed
   p. 27: "There is a cycle in `J` of length ≥ 4 using the edge `v₁v₂`, and so
   there is a path in `L(H)` of length ≥ 2 from `A₁` to `A₂` ... The union of
   this path with `R_{v₁v₂}` induces a hole, and so does its union with `F`, and
   therefore these two paths have lengths of the same parity."
3. `Thm58StarStarGaps.adjacent_parity_gap` — claim (4), printed p. 27, the two
   branches of "So we may assume that at least one of `B₁`, `B₂` is nonempty",
   both of which end in two holes of different parity.

Gaps 1 and 3 conclude with a pair of holes of different parity, which is exactly
the contradiction the paper reaches; gap 2 states the parity conclusion of its
sentence.  None of them asserts `Outcome`.

## New files

`Workspace/ProofLemmas/Thm58StarStarBasics.lean`,
`Workspace/ProofLemmas/Thm58StarStarGeometry.lean`,
`Workspace/ProofLemmas/Thm58StarStarGaps.lean`,
`Workspace/ProofLemmas/Thm58StarStar.lean`.

## Verbatim target audit

```text
Workspace.ProofLemmas.Thm58StarStarGaps.adjacent_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarStarGaps.adjacent_both_complete_parity_gap has sorry of type
  Even (Workspace.Types.Core.SPGT.pathLength P) ↔ Even (Workspace.Types.Core.SPGT.pathLength R)
Workspace.ProofLemmas.Thm58StarBranchGaps.incident_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarBranchGaps.separated_neighbors_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G p₂ a b d ∧ ¬G.Adj p₂ a ∧ ¬G.Adj p₂ b
Workspace.ProofLemmas.Thm58StarBranchGaps.singleton_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G r a b d ∧ ¬G.Adj r a ∧ ¬G.Adj r b
Workspace.ProofLemmas.Thm58StarBranchGaps.mixed_star_link_gap has sorry of type
  ∃ a ∈ N c, G.Adj p₁ a ∧ Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G a p₂ r s
Workspace.ProofLemmas.Thm58StarStarGaps.nonadjacent_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
'Workspace.ProofLemmas.Thm58LocalCases.starStar' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm58StarBranchGaps.incident_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarBranchGaps.separated_neighbors_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G p₂ a b d ∧ ¬G.Adj p₂ a ∧ ¬G.Adj p₂ b
Workspace.ProofLemmas.Thm58StarBranchGaps.singleton_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G r a b d ∧ ¬G.Adj r a ∧ ¬G.Adj r b
Workspace.ProofLemmas.Thm58StarBranchGaps.mixed_star_link_gap has sorry of type
  ∃ a ∈ N c, G.Adj p₁ a ∧ Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G a p₂ r s
'Workspace.ProofLemmas.Thm58LocalCases.branchStar' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
```

`lake build` also exited 0: `Build completed successfully (9478 jobs).`

## 5.8 (7) — the two triangle links (`Thm58BranchBranchLinks`)

`Workspace.ProofLemmas.Thm58BranchBranch.singleton_interior_link_gap` and
`nonadjacent_neighbors_link_gap` are proved. No statement was changed.

The remaining gap is one paper sentence, isolated as two labelled lemmas in
`Workspace/ProofLemmas/Thm58BranchBranchCycleGap.lean`:
`Thm58BranchBranchCycle.cycle_config_at_interior_edge` and
`cycle_config_separating`. Both encode *"There is a cycle in H using the branch
between u₁ and v₁, and using u₂ and not v₂ (since J \ v₂ is 2-connected). There
correspond two paths in L(H) … and a third path R … There are no edges between
these paths except within the triangle T"* (printed p. 28); they differ only in
where the cycle is cut. Proving them needs a cycle of `J` through a prescribed
edge and a prescribed vertex of the 2-connected `J \ v₂`, for which the
workspace has no connectivity API (see `lean_knowledge.md`).
Everything downstream of them is proved: the hole is cut into the two paths by
`Thm58BranchBranchCut.link_of_hole_cut`, and the contradiction with 2.4 follows
because the linked vertex sees at most one vertex of the triangle
(`Thm58BranchBranchCycle.no_two_star_neighbors`, `no_two_star_edges_on_branch`).

## 7.5 (2) — rung replacement (`RungReplacementLabelled.rungReplacement`)

`Workspace.ProofLemmas.RungReplacementLabelled.rungReplacement` is proved, with
no `sorry` and no new gap lemma. The construction is: delete the replaced branch
(`RungReplacementDelete`), restrict the line-graph isomorphism to the residual
appearance, add the new labelled track (`RungReplacementAddTrack`), and transport
the result to `Fin m` (`IsoTransport`). The structural facts — that the surgery
gives back a subdivision of `J`, that it stays bipartite, that the new track is a
branch and that every other branch survives — are proved in
`Workspace/ProofLemmas/RungReplacementSurgeryGaps.lean`.

### Statement repair: the `hother` field of `RungReplacementResult`

The field was

```
hother : ∀ c : W, c ≠ b₁ → c ≠ b₂ → NSet G H' K' φ' (ι c) = NSet G H K φ c
```

and is **false as stated**. Counterexample shape: let `c` be an internal vertex
of the replaced branch `Bb₁b₂`. Then `c ≠ b₁`, `c ≠ b₂`, and `N_c` — the set of
edges of `H` incident with `c` — consists of the two branch edges at `c`, so
under `φ` it is a subset of the deleted rung `V(Rb₁b₂)`, which is *removed* from
the vertex set `K'`. Hence `NSet G H' K' φ' (ι c)` cannot equal `NSet G H K φ c`
(the right-hand side is nonempty and disjoint from `K'`). The vertex `c` does not
even survive the surgery: `ι` is only meaningful off the interior of the branch.

Smallest repair: add the hypothesis `c ∉ trackInterior q`, i.e.

```
hother : ∀ c : W, c ∉ trackInterior q → c ≠ b₁ → c ≠ b₂ →
  NSet G H' K' φ' (ι c) = NSet G H K φ c
```

This is exactly the paper's content — the cliques `N_c` for `c` not on the
replaced branch are untouched — and it is what
`RungReplacementResidual.nset_resGraph_of_notMem` and `RungReplacementLabels.nset_other`
give. No statement under `Workspace/Statements/` or `Workspace/Types/` was
touched, and no other field of `RungReplacementResult` was changed. The only
consumer of the structure, `Thm75Claim2Five82ExactCard.lean` (line 472), uses
`m, H', K', φ', happ, q', ι, hq', hq'from, hq'len, hK', hleft, hright, hrung'`
and never `hother`, so nothing downstream needed updating; a whole-project
`lake build` confirms this.

## 7.5 claim (2), 5.8.2 rung replacement (t75g)

* Repaired the eight `res.hother` call sites in
  `Workspace/ProofLemmas/Thm75Claim2Five82OtherBranch.lean` after
  `RungReplacementResult.hother` gained the hypothesis `c ∉ trackInterior q`; the extra argument
  is supplied from `IsBranch`'s "no interior vertex is a branch vertex" clause together with
  `Thm75BranchEnds.thm75BranchEnds`. No statement changed.
* `Workspace/ProofLemmas/Thm75Claim2Five82CaseGaps.lean`: `case_one_parity` and
  `case_one_single_clique_swap` are now proved (via the two new files
  `Thm75Claim2Five82CaseGapParity.lean` and `Thm75Claim2Five82CaseGapPrism.lean`), and
  `shared_end_single_clique_swap` is proved from the single new labelled gap lemma
  `Thm75Claim2Five82CaseGapSharedEnd.shared_end_prism_pair`, which is the remaining `sorry`:
  the matched pair of prisms across the replacement when the replaced branch shares exactly one
  end with the distinguished branch.

# Theorem 5.8: repair of the endpoint order in `starStar` and `branchStar`

Two earlier sessions showed, with explicit counterexamples recorded above
("The frozen `starStar` statement is false" and "Theorem 5.8: `branchStar` is
false with the frozen endpoint order"), that
`Workspace.ProofLemmas.Thm58LocalCases.starStar` and
`Workspace.ProofLemmas.Thm58LocalCases.branchStar` are false as stated.  The
reason is the same in both cases: `Thm58Setup.Outcome G n H K φ N P p₁ p₂` is
not invariant under reversing `P`, because alternative 2(a) names `p₁`, while
the published 5.8 chooses the path and its two ends existentially, and its proof
says "possibly after exchanging `v₁` and `v₂`".  The two counterexamples above
each satisfy the reversed outcome and not the given one.

Both declarations live under `Workspace/ProofLemmas/`, so the rule 1 exception
for agent-written helpers applies.  The minimal repair used here is to weaken
the conclusion of exactly these two helpers to

```
Thm58Setup.Outcome G n H K φ N P p₁ p₂ ∨
  Thm58Setup.Outcome G n H K φ N P.reverse p₂ p₁
```

Nothing else about the two statements changed: same names, binders, hypotheses,
implicitness.  `starBranch` and `branchBranch` are untouched.

Consumers updated so that the project still builds:

* `Workspace/ProofLemmas/Thm58NonSingletonEndgame.lean`: its conclusion is the
  same disjunction; the `starBranch` and `branchBranch` cases return `Or.inl`.
* `Workspace/Statements/S05/Thm_5_8.lean` (proof body only): the reversed case
  supplies the path `P.reverse` with ends `p₂, p₁`, using
  `PathBasics.isPathFrom_reverse` and `List.mem_reverse`.  The frozen statement
  of `thm_5_8` quantifies the path and its ends existentially, so the reversed
  outcome fits it exactly; the frozen statement is unchanged.

## What is proved

* `branchStar` is now proved outright: it is `starBranch` applied to the
  reversed path, with the two index roles swapped, via
  `Thm58BranchBranch.ready_reverse`.  Its only open dependency is the accepted
  `Thm58LocalCases.starBranch`.
* `starStar` is proved from a new development in
  `Workspace/ProofLemmas/Thm58StarStarBasics.lean`,
  `Thm58StarStarGeometry.lean`, `Thm58StarStarGaps.lean` and
  `Thm58StarStar.lean`.  Proved there:
  - the attachment bookkeeping for two stars (each end's neighbours in `L(H)`
    lie in its own star, an internal vertex of `P` attaches only to both stars
    at once), and the two nonlocality consequences that give `A₁, A₂ ≠ ∅`;
  - claim (3): nonadjacent star vertices have disjoint stars (the shared edge
    would be a one-edge branch through both), so once `B₁ = B₂ = ∅` the edge
    bookkeeping gives alternative 1 of `Outcome` verbatim;
  - claim (4): the branch between the two stars is oriented from `c₁` to `c₂`,
    the rung `R` and the two vertices `r₁, r₂` are built, and
    `N c₁ ∩ N c₂ ⊆ V(R)` is proved from
    `BranchClassification.trackEdges_eq_of_same_ends`;
  - the two appeals to claim (2): if `A₁ = ∅` then the attachments of `F \ {p₂}`
    all equal `r₁`, hence lie in the branch, and `starBranch` applies to the
    reversed path (this is exactly where the reversed disjunct is needed); if
    `A₂ = ∅`, symmetrically, `starBranch` applies to `P` itself;
  - with `A₁, A₂ ≠ ∅` and `B₁ = B₂ = ∅`, alternative 2(b) when `r₁ ≠ r₂` and
    alternative 2(d) when `r₁ = r₂` (then `R` is a single vertex, so `R` is even
    and `P` is even), including all the edge clauses.

## Remaining labelled gaps

All three are in `Workspace/ProofLemmas/Thm58StarStarGaps.lean`.

1. `Thm58StarStarGaps.nonadjacent_parity_gap` — claim (3), printed p. 26:
   "Certainly `A₁` and `A₂` are both nonempty, so there is a track in `H` from
   `v₁` to `v₂` with end-edges in `A₁` and `A₂` respectively. ... Hence we can
   apply 5.6 ... Since `H` is bipartite, `S₁` and `S₂` have opposite parity; but
   they can both be completed via `F`, a contradiction."
2. `Thm58StarStarGaps.adjacent_both_complete_parity_gap` — claim (4), printed
   p. 27: "There is a cycle in `J` of length ≥ 4 using the edge `v₁v₂`, and so
   there is a path in `L(H)` of length ≥ 2 from `A₁` to `A₂` ... The union of
   this path with `R_{v₁v₂}` induces a hole, and so does its union with `F`, and
   therefore these two paths have lengths of the same parity."
3. `Thm58StarStarGaps.adjacent_parity_gap` — claim (4), printed p. 27, the two
   branches of "So we may assume that at least one of `B₁`, `B₂` is nonempty",
   both of which end in two holes of different parity.

Gaps 1 and 3 conclude with a pair of holes of different parity, which is exactly
the contradiction the paper reaches; gap 2 states the parity conclusion of its
sentence.  None of them asserts `Outcome`.

## New files

`Workspace/ProofLemmas/Thm58StarStarBasics.lean`,
`Workspace/ProofLemmas/Thm58StarStarGeometry.lean`,
`Workspace/ProofLemmas/Thm58StarStarGaps.lean`,
`Workspace/ProofLemmas/Thm58StarStar.lean`.

## Verbatim target audit

```text
Workspace.ProofLemmas.Thm58StarStarGaps.adjacent_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarStarGaps.adjacent_both_complete_parity_gap has sorry of type
  Even (Workspace.Types.Core.SPGT.pathLength P) ↔ Even (Workspace.Types.Core.SPGT.pathLength R)
Workspace.ProofLemmas.Thm58StarBranchGaps.incident_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarBranchGaps.separated_neighbors_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G p₂ a b d ∧ ¬G.Adj p₂ a ∧ ¬G.Adj p₂ b
Workspace.ProofLemmas.Thm58StarBranchGaps.singleton_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G r a b d ∧ ¬G.Adj r a ∧ ¬G.Adj r b
Workspace.ProofLemmas.Thm58StarBranchGaps.mixed_star_link_gap has sorry of type
  ∃ a ∈ N c, G.Adj p₁ a ∧ Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G a p₂ r s
Workspace.ProofLemmas.Thm58StarStarGaps.nonadjacent_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
'Workspace.ProofLemmas.Thm58LocalCases.starStar' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm58StarBranchGaps.incident_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarBranchGaps.separated_neighbors_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G p₂ a b d ∧ ¬G.Adj p₂ a ∧ ¬G.Adj p₂ b
Workspace.ProofLemmas.Thm58StarBranchGaps.singleton_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G r a b d ∧ ¬G.Adj r a ∧ ¬G.Adj r b
Workspace.ProofLemmas.Thm58StarBranchGaps.mixed_star_link_gap has sorry of type
  ∃ a ∈ N c, G.Adj p₁ a ∧ Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G a p₂ r s
'Workspace.ProofLemmas.Thm58LocalCases.branchStar' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
```

`lake build` also exited 0: `Build completed successfully (9478 jobs).`

## 5.8 (7) — the two triangle links (`Thm58BranchBranchLinks`)

`Workspace.ProofLemmas.Thm58BranchBranch.singleton_interior_link_gap` and
`nonadjacent_neighbors_link_gap` are proved. No statement was changed.

The remaining gap is one paper sentence, isolated as two labelled lemmas in
`Workspace/ProofLemmas/Thm58BranchBranchCycleGap.lean`:
`Thm58BranchBranchCycle.cycle_config_at_interior_edge` and
`cycle_config_separating`. Both encode *"There is a cycle in H using the branch
between u₁ and v₁, and using u₂ and not v₂ (since J \ v₂ is 2-connected). There
correspond two paths in L(H) … and a third path R … There are no edges between
these paths except within the triangle T"* (printed p. 28); they differ only in
where the cycle is cut. Proving them needs a cycle of `J` through a prescribed
edge and a prescribed vertex of the 2-connected `J \ v₂`, for which the
workspace has no connectivity API (see `lean_knowledge.md`).
Everything downstream of them is proved: the hole is cut into the two paths by
`Thm58BranchBranchCut.link_of_hole_cut`, and the contradiction with 2.4 follows
because the linked vertex sees at most one vertex of the triangle
(`Thm58BranchBranchCycle.no_two_star_neighbors`, `no_two_star_edges_on_branch`).

## 7.5 claim (2), 5.8.2 rung replacement — repaired statement of `gap_other_branch_geometry`

Files: `Workspace/ProofLemmas/Thm75Claim2Five82ExactCard.lean` (repair + proofs),
new files `Thm75Claim2Five82RungBoundary.lean`, `Thm75Claim2Five82Splice.lean`,
`Thm75Claim2Five82CaseGaps.lean`, `Thm75Claim2Five82CaseOne.lean`,
`Thm75Claim2Five82OtherBranch.lean`, `Thm75Claim2Five82Reverse.lean`.

### What was repaired

`Workspace.ProofLemmas.Thm75Claim2Five82ExactCard.gap_other_branch_geometry` is an
agent-written helper (it is not in `Workspace/Types/` or `Workspace/Statements/`), so the
ProofLemmas exception applies. Its old statement was

```
(hdiff : ¬ (ctx.b₁ = ctx.c₁ ∧ ctx.b₂ = ctx.c₂)) :
  ∃ a : BranchAppearance G J,
    a.leftClique = NSet G ctx.H ctx.K ctx.φ ctx.c₁ ∧
    a.rightClique = NSet G ctx.H ctx.K ctx.φ ctx.c₂ ∧
    a.rung = ctx.Rset ∧ ctx.Rset ⊆ a.K ∧ (ctx.F ∩ (a.K \ ctx.Rset)).Nonempty
```

and it is **false as stated**, for two independent reasons.

**Counterexample 1 (the hypothesis is too weak).** `¬ (b₁ = c₁ ∧ b₂ = c₂)` is satisfied by
`b₁ = c₂, b₂ = c₁`, i.e. by the replaced branch *being* the distinguished branch with its two
ends named in the opposite order. In that situation the paper's "different edges of `J`"
paragraph does not apply at all: the distinguished branch is destroyed by the replacement, so
`a.rung = ctx.Rset` fails (the new rung is the replacement path, which is disjoint from `K`
except inside the old rung, while `ctx.Rset ⊆ ctx.K`). Concretely, take any instance of case 2
of 5.8.2 with `b₁ = c₂` and `b₂ = c₁`; then every appearance produced by the replacement has
`a.rung = {x | x ∈ ctx.P}` and `ctx.P ∩ ctx.K = ∅`, so no `a` satisfies the conclusion.

**Counterexample 2 (the two clique equalities are too strong).** Even when `b₁b₂` and `c₁c₂`
really are different edges of `J`, they can share one end. If `c₁ = b₁`, the clique at `c₁`
is exactly the set of edges of `H` at `b₁`, and the replacement removes the old rung end `r₁`
from it and inserts the new end `p₁` of the replacement path. So
`a.leftClique = (NSet … c₁ \ {r₁}) ∪ {p₁} ≠ NSet … c₁`, since `p₁ ∉ ctx.K` while
`NSet … c₁ ⊆ ctx.K`. This is precisely the case the paper singles out with *"Since
`Rb₁b₂ ≠ Rc₁c₂`, it follows that `Rb₁b₂` is incident with at most one of `c₁, c₂`, so these
two prisms are related as in 7.4"* — the appeal to 7.4 is there because one clique **does**
change.

### The repaired statement

```
(hdiff : s(ctx.b₁, ctx.b₂) ≠ s(ctx.c₁, ctx.c₂)) :
  ∃ a : BranchAppearance G J,
    (a.leftClique ∪ a.rightClique) ∩ ctx.K ⊆
      NSet G ctx.H ctx.K ctx.φ ctx.c₁ ∪ NSet G ctx.H ctx.K ctx.φ ctx.c₂ ∧
    OneCliqueReplacement G (NSet G ctx.H ctx.K ctx.φ ctx.c₁)
      (NSet G ctx.H ctx.K ctx.φ ctx.c₂) a.leftClique a.rightClique ∧
    a.rung = ctx.Rset ∧ ctx.Rset ⊆ a.K ∧ (ctx.F ∩ (a.K \ ctx.Rset)).Nonempty
```

The hypothesis is now the unordered inequality of the two pairs of ends, which is the paper's
*"`b₁b₂` and `c₁c₂` are different edges of `J`"*. The two clique equalities are replaced by the
interface actually used downstream: the new cliques meet the old appearance inside the old
cliques, and they are related to the old ones by `OneCliqueReplacement` (at most one of the two
changes, and it changes by a `SingleCliqueSwap`, i.e. by the pair of prisms of 7.4).

### Consumers

* `replacement_geometry_of_other_branch` is **unchanged** and still proved; it is the
  special case in which neither clique changes.
* A new general consumer `replacement_geometry_of_other_branch_general` builds
  `ReplacementGeometry ctx` from the repaired output.
* `gap_replacement_geometry` now splits three ways instead of two:
  aligned (`b₁ = c₁ ∧ b₂ = c₂`), reversed (`b₁ = c₂ ∧ b₂ = c₁`), and genuinely different
  branches. The aligned and reversed cases both go through the new
  `geometry_of_same_branch`; the reversed one first exchanges the two distinguished names with
  the new `revContext`, and transports the result back with `replacementGeometry_of_rev`.
  Nothing downstream of `gap_replacement_geometry` changed, and no frozen statement changed.

### Remaining labelled gaps of this lane

`Workspace/ProofLemmas/Thm75Claim2Five82CaseGaps.lean` isolates three lemmas, each with the
paper sentence it encodes: `case_one_parity`, `case_one_single_clique_swap` and
`shared_end_single_clique_swap`. The hypothesis `hne : r₁' ≠ r₂'` of `case_one_parity` is
load-bearing and documented in its docstring: with equal ends (case 3 of 5.8.2) the replacement
path is a single vertex anticomplete to the old rung, no hole arises, and the parity is
genuinely undetermined.

## `HyperprismLocalEnlargementEven.evenSplitCompleteness` (10.6, even case, p. 62)

The statement as written was **false**, and two hypotheses were added to repair it.

The lemma encodes *"We claim that `A'ᵢ` is complete to `A''ᵢ` … and similarly `B'ᵢ` is complete
to `B''ᵢ`"*, where the paper defines `A'ᵢ` to be **the set of neighbours of `f₁` in `Aᵢ`** and
`B''ᵢ` to be **the set of neighbours of `fn` in `Bᵢ`**.  The hypotheses `hAedges`/`hBedges`
only recorded one half of those definitions (every neighbour of `f₁` in `Aᵢ` lies in `P i`,
every neighbour of `fn` in `Bᵢ` lies outside `Q i`); nothing said that every element of `P i`
is a neighbour of `f₁`, which is what the displayed odd hole
`a-a'-f₁-⋯-fn-b''-R''-a''-a` needs (it uses the edges `a'f₁` and `fnb''`).

Counterexample to the old statement (checked by brute force over all induced cycles).  Take
`V` = 20 vertices: for `m ∈ {0,1,2}` and `s ∈ {',''}` a rung `a[m][s] - c[m][s] - b[m][s]`,
with all edges `a[m][s]a[m'][s']` and `b[m][s]b[m'][s']` for `m ≠ m'`, and no other edges;
plus two extra vertices `u,v` joined by an edge.  This graph has no odd hole and its
complement has no odd hole, so it is Berge.  Put `A m = {a[m][0], a[m][1]}`,
`B m = {b[m][0], b[m][1]}`, `C m = {c[m][0], c[m][1]}` — a hyperprism, whose only `m`-rungs
are the two paths above, so `P m = {a[m][0]}`, `Q m = {b[m][0]}` satisfies `IsRungSplit`.
Take `f = [u, v]` (`Even f.length`); `f` has no neighbour in the hyperprism, so `hfout`,
`hAedges`, `hBedges` and `hCnone` all hold vacuously, and `hDoubleSupport`, `hPrimeSupport`
hold.  But `a[0][0] ∈ P 0` and `a[0][1] ∈ A 0 \ P 0` are non-adjacent, so
`Complete G (P 0) (A 0 \ P 0)` fails.

Repair (smallest possible: the two missing halves of the paper's definitions), inserted
before `hCnone`:

    (hPadj : ∀ (i : Fin 3), ∀ a ∈ P i, G.Adj f₁ a)
    (hQadj : ∀ (i : Fin 3), ∀ b ∈ B i, b ∉ Q i → G.Adj fn b)

The only consumer is `evenOrientedAtZero` in the same file, where
`P k = {a ∈ A k | G.Adj f₁ a}` and `Q k = {b ∈ B k | ¬ G.Adj fn b}`, so both new hypotheses
are immediate; it was updated accordingly.  No statement under `Workspace/Statements/` or
`Workspace/Types/` changed.  The lemma is now proved (no `sorry`) via the new file
`Workspace/ProofLemmas/HyperprismLocalEnlargementhyp3eOddHole.lean`.

## 5.7 claim (4): `sixTerminalCore` repaired (2026-09-05, session s57h)

Following the rule-1 exception for agent-written helpers, the statement of
`Workspace.ProofLemmas.Thm57Claim4Core.sixTerminalCore` was repaired by adding the
single missing hypothesis

```
(hxE : ∀ i, x i ∈ H.edgeSet)
```

immediately after `hxX : ∀ i, x i ∈ X`.  This is the minimal fix: the counterexample
recorded above (and formalised without `sorry` in
`Workspace/ProofLemmas/Thm57Claim4CounterexampleWitness.lean`) consists of three
disjoint *non-edges* marked by `X`, so it is refuted by `hxE` and by nothing weaker.
The printed proof uses `x₃ = a₃b₃ ∈ E(H)` explicitly (*"Since `P₃` joins the adjacent
vertices `a₃, b₃`"*), so the hypothesis is exactly what the paper assumes.

The only consumer is `Workspace/ProofLemmas/Thm57Claim4.lean`, where `thm57Claim4`
already carries `hXE : X ⊆ H.edgeSet`; the call site now passes
`(fun i => hXE (hxX i))`.  Nothing under `Workspace/Statements/` or `Workspace/Types/`
changed, and the counterexample files were left untouched.

### 5.7 claim (4): what is now proved, and the one remaining gap

`sixTerminalCore` (repaired as above) is proved except for one labelled gap lemma,
`Workspace.ProofLemmas.Thm57Claim4Endgame.endgame`, which is the final paragraph of the
printed proof of 5.7 (4) (quoted verbatim in that module's docstring), from *"Let the tracks
in `A` corresponding to `a₁b₃, b₂a₃, a₃b₃ ∈ E(K)` be `P₁, P₂, P₃`"* to *"violate (3)"*.

New files (all sorry-free except the gap lemma):

* `Thm57Claim4Basics.lean` — list/track bookkeeping.
* `Thm57Claim4Config.lean` — the auxiliary graph `K` (`Terminals`, `KAdj`), its symmetry, and
  the fact that an edge of `K` between ends of two different marked edges is an
  `EndpointCleanConnection`, hence has differently coloured ends.
* `Thm57Claim4NoDoubleForeign.lean` — *"by (3) it follows that `a₃` is not adjacent in `K` to
  both `b₁` and `b₂`, and five similar statements"*, in the index-free form: no end of `x k` is
  `K`-adjacent to an end of `x i` and to an end of `x j` for distinct `i, j, k`.
* `Thm57Claim4Reach.lean` — *"there is a component of `K` containing an end of each of
  `x₁, x₂, x₃`"*: any two ends lying in `A` are joined in `K`.
* `Thm57Claim4Component.lean` — *"we may assume that `a₁b₃, b₂a₃, a₃b₃ ∈ E(K)`"*: the
  configuration exists, and there are no further edges of `K` at `a₃` or `b₃`.
* `Thm57Claim4Endgame.lean` — the remaining gap lemma.

`sixTerminalCore` itself now performs the reduction *"we may assume `A` is a maximal connected
subgraph of `H \ X`"* (all its other hypotheses are preserved when `A` grows), chooses the
ends `aᵢ, bᵢ` by colour, assembles the `Setup` structure, and applies the three lemmas above.

# Theorem 5.8: repair of the endpoint order in `starStar` and `branchStar`

Two earlier sessions showed, with explicit counterexamples recorded above
("The frozen `starStar` statement is false" and "Theorem 5.8: `branchStar` is
false with the frozen endpoint order"), that
`Workspace.ProofLemmas.Thm58LocalCases.starStar` and
`Workspace.ProofLemmas.Thm58LocalCases.branchStar` are false as stated.  The
reason is the same in both cases: `Thm58Setup.Outcome G n H K φ N P p₁ p₂` is
not invariant under reversing `P`, because alternative 2(a) names `p₁`, while
the published 5.8 chooses the path and its two ends existentially, and its proof
says "possibly after exchanging `v₁` and `v₂`".  The two counterexamples above
each satisfy the reversed outcome and not the given one.

Both declarations live under `Workspace/ProofLemmas/`, so the rule 1 exception
for agent-written helpers applies.  The minimal repair used here is to weaken
the conclusion of exactly these two helpers to

```
Thm58Setup.Outcome G n H K φ N P p₁ p₂ ∨
  Thm58Setup.Outcome G n H K φ N P.reverse p₂ p₁
```

Nothing else about the two statements changed: same names, binders, hypotheses,
implicitness.  `starBranch` and `branchBranch` are untouched.

Consumers updated so that the project still builds:

* `Workspace/ProofLemmas/Thm58NonSingletonEndgame.lean`: its conclusion is the
  same disjunction; the `starBranch` and `branchBranch` cases return `Or.inl`.
* `Workspace/Statements/S05/Thm_5_8.lean` (proof body only): the reversed case
  supplies the path `P.reverse` with ends `p₂, p₁`, using
  `PathBasics.isPathFrom_reverse` and `List.mem_reverse`.  The frozen statement
  of `thm_5_8` quantifies the path and its ends existentially, so the reversed
  outcome fits it exactly; the frozen statement is unchanged.

## What is proved

* `branchStar` is now proved outright: it is `starBranch` applied to the
  reversed path, with the two index roles swapped, via
  `Thm58BranchBranch.ready_reverse`.  Its only open dependency is the accepted
  `Thm58LocalCases.starBranch`.
* `starStar` is proved from a new development in
  `Workspace/ProofLemmas/Thm58StarStarBasics.lean`,
  `Thm58StarStarGeometry.lean`, `Thm58StarStarGaps.lean` and
  `Thm58StarStar.lean`.  Proved there:
  - the attachment bookkeeping for two stars (each end's neighbours in `L(H)`
    lie in its own star, an internal vertex of `P` attaches only to both stars
    at once), and the two nonlocality consequences that give `A₁, A₂ ≠ ∅`;
  - claim (3): nonadjacent star vertices have disjoint stars (the shared edge
    would be a one-edge branch through both), so once `B₁ = B₂ = ∅` the edge
    bookkeeping gives alternative 1 of `Outcome` verbatim;
  - claim (4): the branch between the two stars is oriented from `c₁` to `c₂`,
    the rung `R` and the two vertices `r₁, r₂` are built, and
    `N c₁ ∩ N c₂ ⊆ V(R)` is proved from
    `BranchClassification.trackEdges_eq_of_same_ends`;
  - the two appeals to claim (2): if `A₁ = ∅` then the attachments of `F \ {p₂}`
    all equal `r₁`, hence lie in the branch, and `starBranch` applies to the
    reversed path (this is exactly where the reversed disjunct is needed); if
    `A₂ = ∅`, symmetrically, `starBranch` applies to `P` itself;
  - with `A₁, A₂ ≠ ∅` and `B₁ = B₂ = ∅`, alternative 2(b) when `r₁ ≠ r₂` and
    alternative 2(d) when `r₁ = r₂` (then `R` is a single vertex, so `R` is even
    and `P` is even), including all the edge clauses.

## Remaining labelled gaps

All three are in `Workspace/ProofLemmas/Thm58StarStarGaps.lean`.

1. `Thm58StarStarGaps.nonadjacent_parity_gap` — claim (3), printed p. 26:
   "Certainly `A₁` and `A₂` are both nonempty, so there is a track in `H` from
   `v₁` to `v₂` with end-edges in `A₁` and `A₂` respectively. ... Hence we can
   apply 5.6 ... Since `H` is bipartite, `S₁` and `S₂` have opposite parity; but
   they can both be completed via `F`, a contradiction."
2. `Thm58StarStarGaps.adjacent_both_complete_parity_gap` — claim (4), printed
   p. 27: "There is a cycle in `J` of length ≥ 4 using the edge `v₁v₂`, and so
   there is a path in `L(H)` of length ≥ 2 from `A₁` to `A₂` ... The union of
   this path with `R_{v₁v₂}` induces a hole, and so does its union with `F`, and
   therefore these two paths have lengths of the same parity."
3. `Thm58StarStarGaps.adjacent_parity_gap` — claim (4), printed p. 27, the two
   branches of "So we may assume that at least one of `B₁`, `B₂` is nonempty",
   both of which end in two holes of different parity.

Gaps 1 and 3 conclude with a pair of holes of different parity, which is exactly
the contradiction the paper reaches; gap 2 states the parity conclusion of its
sentence.  None of them asserts `Outcome`.

## New files

`Workspace/ProofLemmas/Thm58StarStarBasics.lean`,
`Workspace/ProofLemmas/Thm58StarStarGeometry.lean`,
`Workspace/ProofLemmas/Thm58StarStarGaps.lean`,
`Workspace/ProofLemmas/Thm58StarStar.lean`.

## Verbatim target audit

```text
Workspace.ProofLemmas.Thm58StarStarGaps.adjacent_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarStarGaps.adjacent_both_complete_parity_gap has sorry of type
  Even (Workspace.Types.Core.SPGT.pathLength P) ↔ Even (Workspace.Types.Core.SPGT.pathLength R)
Workspace.ProofLemmas.Thm58StarBranchGaps.incident_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarBranchGaps.separated_neighbors_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G p₂ a b d ∧ ¬G.Adj p₂ a ∧ ¬G.Adj p₂ b
Workspace.ProofLemmas.Thm58StarBranchGaps.singleton_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G r a b d ∧ ¬G.Adj r a ∧ ¬G.Adj r b
Workspace.ProofLemmas.Thm58StarBranchGaps.mixed_star_link_gap has sorry of type
  ∃ a ∈ N c, G.Adj p₁ a ∧ Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G a p₂ r s
Workspace.ProofLemmas.Thm58StarStarGaps.nonadjacent_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
'Workspace.ProofLemmas.Thm58LocalCases.starStar' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
Workspace.ProofLemmas.Thm58StarBranchGaps.incident_parity_gap has sorry of type
  ∃ C D,
    Workspace.Types.Core.SPGT.IsHoleList G C ∧ Workspace.Types.Core.SPGT.IsHoleList G D ∧ C.length % 2 ≠ D.length % 2
Workspace.ProofLemmas.Thm58StarBranchGaps.separated_neighbors_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G p₂ a b d ∧ ¬G.Adj p₂ a ∧ ¬G.Adj p₂ b
Workspace.ProofLemmas.Thm58StarBranchGaps.singleton_link_gap has sorry of type
  ∃ a b d, Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G r a b d ∧ ¬G.Adj r a ∧ ¬G.Adj r b
Workspace.ProofLemmas.Thm58StarBranchGaps.mixed_star_link_gap has sorry of type
  ∃ a ∈ N c, G.Adj p₁ a ∧ Workspace.Types.RousselRubio.SPGT.VertexCanBeLinkedOntoTriangle G a p₂ r s
'Workspace.ProofLemmas.Thm58LocalCases.branchStar' depends on axioms: [propext, sorryAx, Classical.choice, Quot.sound]
```

`lake build` also exited 0: `Build completed successfully (9478 jobs).`

## 5.8 (7) — the two triangle links (`Thm58BranchBranchLinks`)

`Workspace.ProofLemmas.Thm58BranchBranch.singleton_interior_link_gap` and
`nonadjacent_neighbors_link_gap` are proved. No statement was changed.

The remaining gap is one paper sentence, isolated as two labelled lemmas in
`Workspace/ProofLemmas/Thm58BranchBranchCycleGap.lean`:
`Thm58BranchBranchCycle.cycle_config_at_interior_edge` and
`cycle_config_separating`. Both encode *"There is a cycle in H using the branch
between u₁ and v₁, and using u₂ and not v₂ (since J \ v₂ is 2-connected). There
correspond two paths in L(H) … and a third path R … There are no edges between
these paths except within the triangle T"* (printed p. 28); they differ only in
where the cycle is cut. Proving them needs a cycle of `J` through a prescribed
edge and a prescribed vertex of the 2-connected `J \ v₂`, for which the
workspace has no connectivity API (see `lean_knowledge.md`).
Everything downstream of them is proved: the hole is cut into the two paths by
`Thm58BranchBranchCut.link_of_hole_cut`, and the contradiction with 2.4 follows
because the linked vertex sees at most one vertex of the triangle
(`Thm58BranchBranchCycle.no_two_star_neighbors`, `no_two_star_edges_on_branch`).

## 7.5 claim (2), 5.8.2 rung replacement — repaired statement of `gap_other_branch_geometry`

Files: `Workspace/ProofLemmas/Thm75Claim2Five82ExactCard.lean` (repair + proofs),
new files `Thm75Claim2Five82RungBoundary.lean`, `Thm75Claim2Five82Splice.lean`,
`Thm75Claim2Five82CaseGaps.lean`, `Thm75Claim2Five82CaseOne.lean`,
`Thm75Claim2Five82OtherBranch.lean`, `Thm75Claim2Five82Reverse.lean`.

### What was repaired

`Workspace.ProofLemmas.Thm75Claim2Five82ExactCard.gap_other_branch_geometry` is an
agent-written helper (it is not in `Workspace/Types/` or `Workspace/Statements/`), so the
ProofLemmas exception applies. Its old statement was

```
(hdiff : ¬ (ctx.b₁ = ctx.c₁ ∧ ctx.b₂ = ctx.c₂)) :
  ∃ a : BranchAppearance G J,
    a.leftClique = NSet G ctx.H ctx.K ctx.φ ctx.c₁ ∧
    a.rightClique = NSet G ctx.H ctx.K ctx.φ ctx.c₂ ∧
    a.rung = ctx.Rset ∧ ctx.Rset ⊆ a.K ∧ (ctx.F ∩ (a.K \ ctx.Rset)).Nonempty
```

and it is **false as stated**, for two independent reasons.

**Counterexample 1 (the hypothesis is too weak).** `¬ (b₁ = c₁ ∧ b₂ = c₂)` is satisfied by
`b₁ = c₂, b₂ = c₁`, i.e. by the replaced branch *being* the distinguished branch with its two
ends named in the opposite order. In that situation the paper's "different edges of `J`"
paragraph does not apply at all: the distinguished branch is destroyed by the replacement, so
`a.rung = ctx.Rset` fails (the new rung is the replacement path, which is disjoint from `K`
except inside the old rung, while `ctx.Rset ⊆ ctx.K`). Concretely, take any instance of case 2
of 5.8.2 with `b₁ = c₂` and `b₂ = c₁`; then every appearance produced by the replacement has
`a.rung = {x | x ∈ ctx.P}` and `ctx.P ∩ ctx.K = ∅`, so no `a` satisfies the conclusion.

**Counterexample 2 (the two clique equalities are too strong).** Even when `b₁b₂` and `c₁c₂`
really are different edges of `J`, they can share one end. If `c₁ = b₁`, the clique at `c₁`
is exactly the set of edges of `H` at `b₁`, and the replacement removes the old rung end `r₁`
from it and inserts the new end `p₁` of the replacement path. So
`a.leftClique = (NSet … c₁ \ {r₁}) ∪ {p₁} ≠ NSet … c₁`, since `p₁ ∉ ctx.K` while
`NSet … c₁ ⊆ ctx.K`. This is precisely the case the paper singles out with *"Since
`Rb₁b₂ ≠ Rc₁c₂`, it follows that `Rb₁b₂` is incident with at most one of `c₁, c₂`, so these
two prisms are related as in 7.4"* — the appeal to 7.4 is there because one clique **does**
change.

### The repaired statement

```
(hdiff : s(ctx.b₁, ctx.b₂) ≠ s(ctx.c₁, ctx.c₂)) :
  ∃ a : BranchAppearance G J,
    (a.leftClique ∪ a.rightClique) ∩ ctx.K ⊆
      NSet G ctx.H ctx.K ctx.φ ctx.c₁ ∪ NSet G ctx.H ctx.K ctx.φ ctx.c₂ ∧
    OneCliqueReplacement G (NSet G ctx.H ctx.K ctx.φ ctx.c₁)
      (NSet G ctx.H ctx.K ctx.φ ctx.c₂) a.leftClique a.rightClique ∧
    a.rung = ctx.Rset ∧ ctx.Rset ⊆ a.K ∧ (ctx.F ∩ (a.K \ ctx.Rset)).Nonempty
```

The hypothesis is now the unordered inequality of the two pairs of ends, which is the paper's
*"`b₁b₂` and `c₁c₂` are different edges of `J`"*. The two clique equalities are replaced by the
interface actually used downstream: the new cliques meet the old appearance inside the old
cliques, and they are related to the old ones by `OneCliqueReplacement` (at most one of the two
changes, and it changes by a `SingleCliqueSwap`, i.e. by the pair of prisms of 7.4).

### Consumers

* `replacement_geometry_of_other_branch` is **unchanged** and still proved; it is the
  special case in which neither clique changes.
* A new general consumer `replacement_geometry_of_other_branch_general` builds
  `ReplacementGeometry ctx` from the repaired output.
* `gap_replacement_geometry` now splits three ways instead of two:
  aligned (`b₁ = c₁ ∧ b₂ = c₂`), reversed (`b₁ = c₂ ∧ b₂ = c₁`), and genuinely different
  branches. The aligned and reversed cases both go through the new
  `geometry_of_same_branch`; the reversed one first exchanges the two distinguished names with
  the new `revContext`, and transports the result back with `replacementGeometry_of_rev`.
  Nothing downstream of `gap_replacement_geometry` changed, and no frozen statement changed.

### Remaining labelled gaps of this lane

`Workspace/ProofLemmas/Thm75Claim2Five82CaseGaps.lean` isolates three lemmas, each with the
paper sentence it encodes: `case_one_parity`, `case_one_single_clique_swap` and
`shared_end_single_clique_swap`. The hypothesis `hne : r₁' ≠ r₂'` of `case_one_parity` is
load-bearing and documented in its docstring: with equal ends (case 3 of 5.8.2) the replacement
path is a single vertex anticomplete to the old rung, no hole arises, and the parity is
genuinely undetermined.

## `HyperprismLocalEnlargementEven.evenSplitCompleteness` (10.6, even case, p. 62)

The statement as written was **false**, and two hypotheses were added to repair it.

The lemma encodes *"We claim that `A'ᵢ` is complete to `A''ᵢ` … and similarly `B'ᵢ` is complete
to `B''ᵢ`"*, where the paper defines `A'ᵢ` to be **the set of neighbours of `f₁` in `Aᵢ`** and
`B''ᵢ` to be **the set of neighbours of `fn` in `Bᵢ`**.  The hypotheses `hAedges`/`hBedges`
only recorded one half of those definitions (every neighbour of `f₁` in `Aᵢ` lies in `P i`,
every neighbour of `fn` in `Bᵢ` lies outside `Q i`); nothing said that every element of `P i`
is a neighbour of `f₁`, which is what the displayed odd hole
`a-a'-f₁-⋯-fn-b''-R''-a''-a` needs (it uses the edges `a'f₁` and `fnb''`).

Counterexample to the old statement (checked by brute force over all induced cycles).  Take
`V` = 20 vertices: for `m ∈ {0,1,2}` and `s ∈ {',''}` a rung `a[m][s] - c[m][s] - b[m][s]`,
with all edges `a[m][s]a[m'][s']` and `b[m][s]b[m'][s']` for `m ≠ m'`, and no other edges;
plus two extra vertices `u,v` joined by an edge.  This graph has no odd hole and its
complement has no odd hole, so it is Berge.  Put `A m = {a[m][0], a[m][1]}`,
`B m = {b[m][0], b[m][1]}`, `C m = {c[m][0], c[m][1]}` — a hyperprism, whose only `m`-rungs
are the two paths above, so `P m = {a[m][0]}`, `Q m = {b[m][0]}` satisfies `IsRungSplit`.
Take `f = [u, v]` (`Even f.length`); `f` has no neighbour in the hyperprism, so `hfout`,
`hAedges`, `hBedges` and `hCnone` all hold vacuously, and `hDoubleSupport`, `hPrimeSupport`
hold.  But `a[0][0] ∈ P 0` and `a[0][1] ∈ A 0 \ P 0` are non-adjacent, so
`Complete G (P 0) (A 0 \ P 0)` fails.

Repair (smallest possible: the two missing halves of the paper's definitions), inserted
before `hCnone`:

    (hPadj : ∀ (i : Fin 3), ∀ a ∈ P i, G.Adj f₁ a)
    (hQadj : ∀ (i : Fin 3), ∀ b ∈ B i, b ∉ Q i → G.Adj fn b)

The only consumer is `evenOrientedAtZero` in the same file, where
`P k = {a ∈ A k | G.Adj f₁ a}` and `Q k = {b ∈ B k | ¬ G.Adj fn b}`, so both new hypotheses
are immediate; it was updated accordingly.  No statement under `Workspace/Statements/` or
`Workspace/Types/` changed.  The lemma is now proved (no `sorry`) via the new file
`Workspace/ProofLemmas/HyperprismLocalEnlargementhyp3eOddHole.lean`.

## 9.5(1), the offspring paragraph (session t95d)

`Workspace.ProofLemmas.Thm95Offspring.offspring_striation` is now proved from two labelled gap
lemmas in `Workspace/ProofLemmas/Thm95OffspringGaps.lean`.  No statement was changed.

Two remarks on the paper's text, for whoever closes the two gaps.

* *"Since there is no `Tⱼ`-antirung with both ends in `Mⱼ` or both ends in `Nⱼ`, it follows that
  `Mⱼ ∩ Nⱼ = ∅`"* does not, as far as this session could reconstruct it, cover a vertex of `Zⱼ`
  lying on one antirung whose end in `Xⱼ` is adjacent to `f₁` and on another whose end in `Xⱼ` is
  adjacent to `f_k`.  The `Xⱼ` and `Yⱼ` cases are immediate from *"every antirung has one end in
  `U` and the other in `V`"* (now proved, `Thm95OffspringSplit.ends_not_same_side`).  The file
  therefore derives `Mⱼ ∩ Nⱼ = ∅` from the next sentence, *"`Mⱼ` is complete to `Nⱼ`"*, which
  gives it at once since no vertex is adjacent to itself.

* The odd hole `d₁-xⱼ-f₁-⋯-f_k-x'ⱼ-d₁` proves *"`Mⱼ` is complete to `Nⱼ`"* only for the pairs the
  paper singles out (a nonedge inside `Xⱼ`, or inside `Yⱼ`): for `u ∈ Mⱼ ∩ Zⱼ` the vertex `u` is
  adjacent to both `f₁` and `f_k`, so the cycle has a chord.  The preceding sentence, *"there are
  no nonedges between `Mⱼ` and `Nⱼ` except possibly between `Mⱼ ∩ Xⱼ` and `Nⱼ ∩ Xⱼ`, or between
  `Mⱼ ∩ Yⱼ` and `Nⱼ ∩ Yⱼ`"*, is the part that still needs an argument, and the paper gives none
  beyond the antirung remark above.

# t95e — 9.5(1), the last two gaps of the offspring paragraph: both proved

`Workspace.ProofLemmas.Thm95OffspringGaps.offVerts_complete` and
`Thm95OffspringGaps.twist_or_merge` are now proved.  No statement was changed anywhere; the two
frozen gap statements keep their binders and conclusions and only their `sorry` bodies were
replaced.  With this, `Thm95Body.claim1_offspring_enlargement_gap`, `Thm95Body.claim3` and
`Thm95Body.closing` carry no `sorry` of their own.

## `offVerts_complete` — *"`Mⱼ` is complete to `Nⱼ`"*

The previous session (t95d) recorded that the paper's sentence *"there are no nonedges between
`Mⱼ` and `Nⱼ` except possibly between `Mⱼ ∩ Xⱼ` and `Nⱼ ∩ Xⱼ`, or between `Mⱼ ∩ Yⱼ` and
`Nⱼ ∩ Yⱼ`"* is stated without an argument, and that the displayed odd hole cannot cover a vertex
of `Zⱼ` (such a vertex is adjacent to both `f₁` and `f_k`, so the cycle has a chord).  The
missing argument is a **surgery on antirungs**, and it needs no odd hole at all.

Let `uv` be a nonedge of `G` with `u ∈ Mⱼ` and `v ∈ Nⱼ`, let `xⱼ-Qⱼ-yⱼ` be an antirung through
`u` with `xⱼ ∈ U`, and `x'ⱼ-Q'ⱼ-y'ⱼ` one through `v` with `x'ⱼ ∈ V`.  By *"every `Tⱼ`-antirung
has one end in `U` and the other in `V`"* (already proved, `antirung_ends_split`), `yⱼ ∈ V` and
`y'ⱼ ∈ U`.  Each of `u, v` lies in `Xⱼ`, `Yⱼ` or `Zⱼ`, and a vertex of `Mⱼ` in `Xⱼ` is the first
vertex of its antirung while a vertex in `Yⱼ` is the last.

* Both in `Xⱼ`: then `u = xⱼ ∈ U` and `v = x'ⱼ ∈ V`, and the paper's hole
  `d₁-xⱼ-f₁-⋯-f_k-x'ⱼ-d₁` applies (`Thm95OffspringGapHole.no_nonedge_with_common_neighbour`).
* Both in `Yⱼ`: the same hole with `f₁` and `f_k` exchanged.
* In every other case `u` is not the end in `Yⱼ` of `Qⱼ`, or not the end in `Xⱼ`, and likewise
  for `v`, in such a way that one of the two can be joined to an end in `Xⱼ` and the other to an
  end in `Yⱼ` **through `Zⱼ`**, with the two ends both in `U` or both in `V`.  A piece of an
  antirung from a vertex to an end has all its other vertices in `Zⱼ` (`reach_head`,
  `reach_last`); the two pieces glued along the nonedge `uv` form a set consisting of the two
  ends and vertices of `Zⱼ` that is connected in `Ḡ`, and an induced path of `Ḡ` inside that set
  (`InducedPathExtraction.exists_isPathFrom_of_connected`) is a `Tⱼ`-antirung between the two
  ends (`exists_srung_of_reach`).  That antirung has both ends in `U`, or both in `V`, which
  `antirung_ends_split` forbids.

The common neighbour `d₁ ∈ A₁ ∪ B₁` is produced by `exists_common_neighbour`: `Sᵢ` and `Tⱼ` are
parallel or co-parallel, so one of the two ends of `Sᵢ` is complete to `Xⱼ ∪ Zⱼ` and the other
to `Yⱼ ∪ Zⱼ`.  The hole `d₁-xⱼ-f₁-⋯-f_k-x'ⱼ-d₁` has `k + 3` vertices, and `k` is even because
`f₁-⋯-f_k` has odd length.

## `twist_or_merge` — the second bullet

For a fixed `i`: if some `Tⱼ` has two nonempty offspring `M, N`, they alone make the twist,
because `S₀` is parallel with `M` and co-parallel with `N` (`Thm95OffspringParallel`) while `Sᵢ`
keeps one and the same relation to both.  Otherwise every `Tⱼ` has a single offspring, which is
`Tⱼ` itself (`offspring_eq_self`); if `S₀, Sᵢ` agree on one of them and disagree on another,
those two make the twist.  If they agree on all of them, then reading off the neighbours of an
end of a strip on an antistrip (`adjA_par`, `adjB_par`, `adjA_cop`, `adjB_cop`: the end in `A`
sees exactly `X ∪ Z` when parallel and exactly `Y ∪ Z` when co-parallel) shows that `f₁` has the
same neighbours on every `V(Tⱼ)` as the end of `Sᵢ` in `Aᵢ`, and `f_k` as the end in `Bᵢ`; if
they disagree on all of them, the same holds with the two ends exchanged.  That is the second
disjunct, which `Thm95OffspringMerge.merge_striation` turns into the enlarged striation.

## New files

* `Workspace/ProofLemmas/Thm95OffspringGapReach.lean` — `ReachThroughZ`, `reach_head`,
  `reach_last`, `exists_srung_of_reach` (the surgery; no use of Berge).
* `Workspace/ProofLemmas/Thm95OffspringGapHole.lean` — `no_nonedge_with_common_neighbour`, the
  odd hole `d₁-xⱼ-f₁-⋯-f_k-x'ⱼ-d₁`.
* `Workspace/ProofLemmas/Thm95OffspringGapComplete.lean` — `exists_common_neighbour` and
  `offVerts_complete_aux`, the case analysis above.
* `Workspace/ProofLemmas/Thm95OffspringGapTwist.lean` — the four adjacency patterns,
  `offspring_eq_self` and `twist_or_merge_aux`.

## Note on an unused declaration

`Workspace.ProofLemmas.Thm95Body.claim1` (line 331) is still `sorry`, but nothing in the
repository refers to it: the live route through 9.5(1) is
`Thm95Body.claim1_offspring_enlargement_gap`, which is now `sorry`-free.

# t192g: 19.2 claim (9) — `minimalityWitness` repaired, `claim9` reduced to one gap

## The repair (rule 1 EXCEPTION, agent-written helper)

`Workspace/ProofLemmas/Thm192Claim9MinimalityWitness.minimalityWitness` was recorded as
FALSE by an earlier agent (see the section "t192b2: 19.2 claims (8), (9)-minimality-witness,
(10)-endgame" above, with an explicit eight-vertex counterexample).  Its statement has now
been repaired by **adding two hypotheses** and keeping the printed conclusion:

```lean
theorem minimalityWitness (G : SimpleGraph V) (z : V) (A₀ : Set V) (x : ℕ → V)
    (Y : Set V) (y : V) (hyY : y ∈ Y) (h2y : ¬ G.Adj y (x 2))   -- ← added
    (A : Set V) (hA : GoodA G z A₀ x Y y A)
    (hAmin : ∀ B : Set V, GoodA G z A₀ x Y y B → A.ncard ≤ B.ncard)
    (F : Set V) (hFA : F ⊆ A) (hFconn : ConnectedSet G F) (hFne : F ≠ A)
    (hF0 : ∃ a ∈ F, G.Adj (x 0) a) (hF1 : ∃ a ∈ F, G.Adj (x 1) a)
    (hF2 : ∃ a ∈ F, G.Adj (x 2) a) :
    ∃ f ∈ A \ F, ConnectedSet G (A \ {f}) ∧
      ∃ y₀ ∈ Y, ¬ G.Adj y₀ (x 2) ∧ VertexAnticomplete G y₀ (A \ {f})
```

This is the smallest possible repair (rule 1 prefers "add the missing hypothesis").  The
counterexample in the earlier section has `G.Adj y (x 2)`, and that is no accident:
`Thm192Claim9MinimalityWitnessRepaired.minimalityWitness` (proved, no sorry) shows that the
minimality of a `GoodA` set gives the disjunction

```lean
    (∃ y₀ ∈ Y, ¬ G.Adj y₀ (x 2) ∧ VertexAnticomplete G y₀ (A \ {f})) ∨
      VertexAnticomplete G y (A \ {f})
```

— `A \ {f}` loses one of the two "has a neighbour" clauses of `GoodA`.  When
`¬ G.Adj y (x 2)`, the second disjunct is a *special case* of the first, with `y₀ = y`
(`y ∈ Y`, `y` is nonadjacent to `x₂`, and `y` has no neighbour in `A \ {f}`).  So under the
added hypothesis the printed sentence is recovered verbatim, and the new proof is three
lines on top of the repaired lemma.

The only consumer is `Thm192Claim9.claim9`, which is in this assignment and has been updated
(condition (a)).  Nothing under `Workspace/Statements/` or `Workspace/Types/` changed
(condition (b)).

## `claim9`

`claim9`'s own statement is unchanged.  Its proof now opens with

```lean
  by_cases h2y : G.Adj (x 2) y
```

* `¬ G.Adj (x 2) y`: the previously written printed proof, verbatim, with the repaired
  `minimalityWitness` (which now takes `hyY` and `h2y`).  **No gap.**
* `G.Adj (x 2) y`: the new file `Workspace/ProofLemmas/Thm192Claim9YAdjX2.lean`.

The printed proof never has to split like this: it *derives* *"`y` is not adjacent to `x₂`"*
from the minimality of its own choice of `A`, which is minimal without the extra `GoodA`
clause *"`y` has a neighbour in `A`"*.  The project's `A` is minimal within a strictly
smaller family, so that derivation is unavailable, and the case has to be treated on its own.

## The remaining gap

`Thm192Claim9YAdjX2.claim9_of_x2_adj_y` is proved with no gap of its own: it applies the
repaired minimality witness, rules out the printed alternative (a `y₀ ∈ Y` nonadjacent to
`x₂` with no neighbour in `A \ {f}`) exactly as the printed text does — `y₀ ≠ y` because `y`
is adjacent to `x₂`, so `y₀ ∈ Y₀`, so `x₂` is not `Y₀`-complete, so by claim (2) there are
two `Y₀`-complete vertices in `A`, both of which would have to equal `f` — and is therefore
left with the configuration in which `f` is the unique neighbour of `y` in `A`.  That
configuration is the single `sorry`:

```lean
theorem uniqueNeighbourContradiction … (h2y : G.Adj (x 2) y)
    (F : Set V) (hFA : F ⊆ A) (hFconn : ConnectedSet G F) (hFne : F ≠ A)
    (hF0 …) (hF1 …) (hF2 …)
    (f : V) (hfA : f ∈ A) (hfF : f ∉ F) (hfconn : ConnectedSet G (A \ {f}))
    (hyf : G.Adj y f) (hyuniq : ∀ a ∈ A, G.Adj y a → a = f) : False
```

It encodes the printed sentences *"… and therefore `f` is the unique neighbour of `y₀` in
`A`. … So `y₀ = y`, and therefore `y` is not adjacent to `x₂`"* in the one case the printed
derivation is not available.  It carries `hcex : ¬ Concl192 G z A₀ x Y`, so it is at worst
vacuously true (the whole of 19.2 is a proof by contradiction from `hcex`).

### What was tried, and why the case resists

With `G.Adj (x 2) y` the printed endgame of claim (9) breaks at its very first step: it needs
the induced path `f-y-z-x₂` for 17.3, and `y x₂` is an edge here.  Every nearby substitute
fails for the same reason:

* 17.3 with `F = A ∪ {x₂}`, `Y = {x₀,x₁}`, `a′ = z`, `b′ = y`: `y` has *two* neighbours in
  `A ∪ {x₂}` (namely `f` and `x₂`), so `b′` has no unique neighbour.
* 17.1 on any triangle among `z, y, x₀, x₁, x₂` caught by `A ∪ {x_i}`: `x₂` is adjacent to
  both `z` and `y`, and `x₀, x₁` are adjacent to both `z` and `y`, so the "some vertex has
  two neighbours in the triangle" alternative is always available and 17.1 gives nothing.
* Claim (3) applied to a minimal connected subset of `A` containing `F ∪ {f}` shows that `A`
  is a minimal connected set containing `F ∪ {f}`, but that is consistent with `A \ {f}`
  being connected, so no contradiction with the minimality of `A` arises.
* Claim (7) would finish the case if one could produce a path from `x₀` to `x₁` with interior
  in `A` whose interior contains neighbours of both `x₂` and `y`, but producing such a path
  is what claim (9) itself is used for in `Statements/S19/Thm_19_2.lean`.
* Claim (8) is unusable: its statement carries `h2y : ¬ G.Adj (x 2) y`.

A cleaner global fix would be to weaken the extra clause of `Thm192Setup.GoodA` from
*"`y` has a neighbour in `A`"* to *"if `y` is nonadjacent to `x₂` then `y` has a neighbour in
`A`"*.  With that clause the second disjunct of the repaired minimality witness always
collapses into the printed one and this gap disappears entirely; claim (3) still goes through
unchanged.  That change was **not** made here: `GoodA` lives in `Thm192Setup.lean`, which is
outside this assignment, and it has several dozen consumers spread over files owned by other
agents, so condition (a) of the repair rule could not be met.

## `Thm85EndgameTraversalUnique.traversal_unique` — repaired statement (agent t85d)

The statement written by the earlier agent was **false**.  `IsTraversal G J N F f₁ fn R i j`
(`Thm85EndgameNotions`) is invariant under simultaneously exchanging `(i,j)` with `(j,i)` and
`f₁` with `f_n`.  So whenever `f₁ = f_n` and `(i,j)` is a traversal, `(j,i)` is one too, and the
conclusion `i' = i ∧ j' = j` gives `i = j`, contradicting `J.Adj i j`.  Nothing in the
hypotheses excluded `f₁ = f_n`: `F` there is an arbitrary set, and claim (1) is compatible with
`f₁ = f_n`.

Concrete configuration satisfying every hypothesis except the conclusion: `J = K₃,₃` with parts
`{i,a,b}` and `{j,c,d}`; `G = L(K₃,₃)` with one extra vertex `f`; every strip `S_uv` a single
vertex `s_uv` and `N_u = {s_uv : v ∼ u}`; `F = {f}` with `f` adjacent exactly to
`s_ic, s_id, s_ja, s_jb`.  Then `(i,j)` and `(j,i)` are both traversals for `f₁ = f_n = f`, and
the neighbours of `f` do not saturate `L(H)` (the vertex `a` has the two exceptions `ac`, `ad`),
so claim (1) holds.

Repair (smallest possible): the hypothesis `(hfne : f₁ ≠ fn)` — the paper's `n ≥ 2` — was added
to `traversal_unique`, and threaded through its two consumers
`Thm85EndgameClaim4.claim4` and `Thm85EndgameClaims.claim4_unique_traversal`.  At the top of the
chain, `Thm85Endgame.thm85Endgame` supplies it from the new labelled gap lemma
`Thm85EndgamePathTwoVertices.path_ends_distinct`, which is the paper's own sentence
*"Hence `n ≥ 2`, for if `n = 1` then we can add `f₁` to `N_i`, `N_j` and `S_ij`, contrary to the
maximality of the strip system"* (printed p. 44) — a sentence that needs the maximality of the
strip system, which is a hypothesis of `thm85Endgame` but not of `traversal_unique`.

## `Thm85EndgameClosing.optimal_with_same_traversal` — added hypothesis (agent t85d)

The statement was missing claim (1) of 8.5.  The printed recipe *"just replace rungs that miss
`X` by rungs that meet `X` wherever possible"* keeps the traversal only because no strip of an
edge disjoint from the traversal meets `X`, and the proof of that
(`Thm85EndgameOptimalChoice.attachment_edges_meet_traversal`) runs the degenerate-`K₄` argument
of claim (4), which needs claim (1).  The hypothesis `hclaim1`, in exactly the form carried by
every other declaration of this file, was therefore added; its only consumer, `closing`, has it.

# 8.5 `n ≥ 2`: `path_ends_distinct` needs claims (1) and the no-enlargement hypothesis

Agent t85e, target
`Workspace/ProofLemmas/Thm85EndgamePathTwoVertices.path_ends_distinct`.

## Statement repair

As written by the earlier agent the theorem carried only the hypotheses of
`Thm85Endgame.thm85Endgame` up to claim (3): `hG, hJ, hSN, hmax, hFcompl,
hFne, hFconn, hFmajor, hXnotlocal, hFmin, hclaim3`.  The printed proof of the
sentence it encodes ("Hence `n ≥ 2`, for if `n = 1` then we can add `f₁` to
`N_i`, `N_j` and `S_ij`") lives inside claim (6) and uses claims (4) and (5),
which in turn need claim (1) and the hypothesis that no enlargement of `J`
appears in `G`.  Neither is derivable from the hypotheses listed above: the
edge `ij` of the enlargement is the traversal edge of claim (4), and claim (4)
is exactly the application of 5.8 that needs claim (1).

Repair: three hypotheses of 8.5 have been appended,

* `hnoenl` (no `J`-enlargement appears in `G`),
* `hK₄` (the `K₄` clause of 8.5),
* `hclaim1` (claim (1) of the proof of 8.5).

All three are present verbatim at the only call site,
`Thm85Endgame.thm85Endgame`, which has been updated.  No statement under
`Workspace/Statements/` or `Workspace/Types/` changed.

## What is now proved

Assume `f₁ = f_n`.  Then `F = {f₁}`.  Claim (4) and claim (5) are available in
an *unordered* form — for `f₁ = f_n` the ordered `HasUniqueTraversal` is false,
since `IsTraversal … R i j` and `IsTraversal … R j i` are then the same
statement — namely

* `Thm85EndgamePathTwoVerticesClaim4.claim4_exists`: a broad choice has *some*
  traversal.  This is `Thm85EndgameClaim4.claim4` with its last three lines (the
  appeal to `Thm85EndgameTraversalUnique.traversal_unique`, the only place where
  `f₁ ≠ f_n` is used) deleted.
* `Thm85EndgamePathTwoVerticesBroad.every_choice_broad`: claim (5).  This is
  `Thm85Claim5Proof.every_choice_broad`, which uses claim (4) only through the
  existence of a traversal.

Fix a broad choice with traversal `(i,j)` and split on whether every choice of
rungs has `ij` as its traversal edge.

* If it does, replacing the rung on one edge by any prescribed rung gives a
  choice that still has traversal `(i,j)`, and the three bullets of claim (4)
  read on those choices give: no strip of an edge disjoint from `ij` meets `X`;
  every attachment of `f₁` outside `S_ij` lies in `N_i ∪ N_j`; and `f₁` is
  complete to `N_i \ S_ij` and to `N_j \ S_ij`.  Feeding this to
  `Thm85EnlargeStripBySet.thm85EnlargeStripBySet` adds `f₁` to `N_i`, `N_j` and
  `S_ij` and contradicts `hmax`.  This is the printed sentence, and it is proved
  without `sorry`.
* If it does not, two choices have different traversals and the closing
  paragraph of 8.5 applies.

## Remaining gap

`Thm85EndgamePathTwoVerticesGap.n1_different_traversals_absurd` — the closing
paragraph of the proof of 8.5 (printed pp. 44–45) in the case `f₁ = f_n`, ending
with the odd hole `f₁-r_hj-R_hj-r_jh-r_ji-f₁`.

The already-formalized `Thm85EndgameClosing.closing` cannot be reused here.  Its
`k4_endgame` step derives `f₁ = f_n` from the two disjoint traversals and then
contradicts the *ordered* uniqueness of the traversal in claim (4); with
`f₁ = f_n` assumed, that final step is vacuous, and the printed odd-hole
argument — which is what the paper actually uses — is not formalized anywhere in
the development.

## New files

* `Workspace/ProofLemmas/Thm85EndgamePathTwoVerticesClaim4.lean`
* `Workspace/ProofLemmas/Thm85EndgamePathTwoVerticesBroad.lean`
* `Workspace/ProofLemmas/Thm85EndgamePathTwoVerticesGap.lean`

# t232e — 23.2 claim (4): `Thm232Claim5Path.claim4_gap` proved

The last gap of 23.2 is closed.  No statement was changed; `claim4_gap` keeps its frozen
statement and its `sorry` is replaced by a proof.

**PAPER (23.2, printed p. 140).** *"(4) If `n = 1` then no neighbour of `v₁` in `A₀` is
`Y`-complete.  For otherwise we may assume `v₂` is `Y`-complete.  From the symmetry we may
assume that `x₀ ≠ c₃`.  Let `Q` be the path of `C \ z` between `x₀, c₃`; … Since `y, v₁` are not
`Y`-complete, there is an antipath joining them with interior in `Y`, and it is odd since it can
be completed to an antihole via `v₁-z-v₂-y`.  Hence every `Y`-complete vertex is adjacent to one
of `y, v₁` … it follows that `v₁` is adjacent to `c₂, c₃`. … By 16.1, there are three consecutive
vertices in `C`, all `Y`-complete and adjacent to `v₁`.  By 22.3, `v₁` has no other neighbours in
`C`. … Consequently `x₀` is adjacent to `y`; but then `x₀-Q-c₃-v₁-y-x₀` is an odd hole, a
contradiction."*

**New files.**

* `Workspace/ProofLemmas/Thm232Claim4Antipath.lean` — `exists_odd_antipath` and
  `every_complete_adj`: the antipath from `y` to `v₁` with interior in `Y`
  (`InducedPathExtraction.exists_antipath_interior_in`), the antihole `y-Q-v₁-z-v₂-y`
  (`PathGlue.glue_hole` in `Gᶜ`, with the two extra vertices `z, v₂`) which makes it odd, and the
  consequence that every `Y`-complete vertex sees `y` or `v₁`
  (`AntiholeCompletion.even_pathLength_of_witness` would otherwise make it even).
  This is the only place where the hypothesis that `v₂ = u` is `Y`-complete is used.
* `Workspace/ProofLemmas/Thm232Claim4Neighbours.lean` — `nbrs_subset`: 16.1 applied to `v₁` with
  the opposite-wheel-parity pair `c₂, c₃`, plus 22.3.  Of the three outcomes of 16.1, the first
  names the two rim neighbours of `v₁` (they must be `c₂, c₃`), the third contradicts optimality,
  and in the second a fourth rim neighbour would make `v₁` a kite; the middle one of the three
  consecutive vertices is `c₂` because claim (1) leaves `c₂` as the only `Y`-complete rim
  neighbour of `c₃`.  Hence every rim neighbour of `v₁` is one of `c₁, c₂, c₃`.
* `Workspace/ProofLemmas/Thm232Claim4Core.lean` — `orientation_absurd`, the printed argument for
  one arc of `C \ z`.  The closing odd hole `x₀-Q-c₃-v₁-y-x₀` is
  `Thm232Claim3C2Core.no_adj_far_end` with `v₁` in the place of `c₂` there.
* `Workspace/ProofLemmas/Thm232Claim4Symmetry.lean` — `claim4` discharges *"from the symmetry we
  may assume `x₀ ≠ c₃`"* exactly as `Thm232Claim3C2.not_adj_c2` does: the arc from `c₃` to `x₀`
  when `x₀ ≠ c₃`, and the reversed arc from `c₁` to `x₁` otherwise (both cannot degenerate, since
  `x₀ = c₃` and `x₁ = c₁` together force `|C| = 4 < 6`).

**Deviation from the printed proof.**  The paper derives *"by (2), `v₁` is adjacent to one of
`x₀, x₁`, and so it has two nonadjacent neighbours in `C`"* before invoking 16.1.  The Lean proof
does not need it: 16.1 already applies to the pair `c₂, c₃`, which has opposite wheel-parity
because `c₂c₃` is a `Y`-complete edge, and each of its three outcomes is refuted or pins the rim
neighbours of `v₁` down to `c₁, c₂, c₃` on its own.  The hypothesis `h2` of `claim4_gap` is
therefore unused (the statement is unchanged).

## 21.2, session t212d (the four remaining gaps of `Workspace/ProofLemmas/Thm212.lean`)

All four assigned targets — `claim4_hat_gap`, `claim5_odd_gap`, `claim8_hole_gap`,
`parity_oddRun_gap` — are now `sorry`-free at their own level.  Three of them
(`claim4_hat_gap`, `claim8_hole_gap`, `parity_oddRun_gap`) have
`#print axioms = [propext, Classical.choice, Quot.sound]`.

New declarations (all in `Workspace/ProofLemmas/`):

* `Thm212RunParity.lean` (new file) — the path-side run/segment arithmetic used by
  `parity_oddRun_gap`.
* `Thm212.claim4_hat_outcome` — the shared hole + 2.10 outcome of 21.2(4).
* `Thm212.claim4_hat_large_index_gap` — the printed case `i > m` of 21.2(4); **proved**
  (the `sorry` left by the previous session is gone).
* `Thm212.claim5_even_middle_in_path` — the case `q ∈ {p₁,…,p_m}` of the middle-vertex
  analysis in 21.2(5), by 13.7 applied in the complement.
* `Thm212.claim5_even_middle_in_A_gap` — **the one residual labelled gap**: the case
  `q ∈ A_{t−1}` of 21.2(5), which the paper closes with 15.7.  See the note below.
* `Thm212.claim8_count` — the counting / 2.10 / 17.1 endgame of 21.2(8).

**Note on the one residual gap.**  For `claim5_even_middle_in_A_gap` the printed proof builds a
path `R'` between `x_t` and `p_m` with interior in `{z, x_{t+1}, p₁,…,p_m}` and calls the hole
`x_t-q-p_m-R'-x_t` *"a hole of length ≥ 6"*.  That length bound needs the printed remark *"in
particular `x_t` is nonadjacent to `p_m, p_{m−1}`"*, which is stated as a consequence of (5) and
used inside the proof of (5).  `x_t ≁ p_m` is recovered independently (see `lean_knowledge.md`),
but `x_t ≁ p_{m−1}` is not, and when `m = 1` and `x_t` is adjacent to `x_{t+1}` the hole really
can have length 4, where 15.7 does not apply.  The gap is therefore isolated with the exact
printed sentence as its docstring rather than closed with an unjustified length bound.

**Statement changes to agent-written helpers.**  `Thm212.claim8_count` was introduced in this
session and immediately given one extra hypothesis (`hP : PathFor211 …`, already available at its
only call site) once the edge-count argument showed it was needed; no frozen statement and no
declaration from an earlier session was modified.

## 21.2, session t212e (`Thm212.claim5_even_middle_in_A_gap`, the last gap of 21.2)

`Workspace.ProofLemmas.Thm212.claim5_even_middle_in_A_gap` is now proved, so
`Thm212.endgame` and `Workspace.Statements.S21.SPGT.thm_21_2` have no `sorry` of their own left
in the 21.2 file (see the audit in the session summary).

**How the printed length bound is recovered.**  The hole of the printed proof is
`x_t-q-p_m-R'-x_t`, where `R'` is any path between `x_t` and `p_m` with interior in
`{z, x_{t+1}, p₁,…,p_{m−1}}`; it is a hole because `q ∈ A_{t−1}` is nonadjacent to `z` (no
neighbour of `z` lies in `A_t`), to `x_{t+1}` (hypothesis of 21.2) and to `p₁,…,p_{m−1}` (only
`p_m` has a neighbour in `A_{t−1}`).  Its length is `2 + |R'|`, so *"length ≥ 6"* is exactly
*"`R'` has length ≥ 3"*, and since `R'` has length 1 only if `x_t ∼ p_m`, only two degenerate
configurations have to be excluded, namely a middle vertex of `R'` adjacent to both ends:

* the middle vertex is `p_{m−1}`, that is `x_t ∼ p_{m−1}`;
* the middle vertex is `x_{t+1}`, which forces `m = 1` (only `p₁` is adjacent to `x_{t+1}`) and
  `x_t ∼ x_{t+1}`.

The first is the printed remark *"and in particular `x_t` is nonadjacent to `p_m, p_{m−1}`"*.
It is **not** circular: if `x_t ∼ p_{m−1}` then `p_{m−1}` is not `X_{t−1}`-complete (it would be
`X_t`-complete, contradicting `p_{m−1} ∈ A_t`), so `z-x_t-p_{m−1}-p_m` is an odd path of length
3 whose ends are `X_{t−1}`-complete and whose internal vertices are not, and 13.6 produces an
odd antipath between `x_t` and `p_{m−1}` with interior in `X_{t−1}`; its middle vertex
`p_{m−1}` lies on the path `p`, so the already proved `claim5_even_middle_in_path` (13.7 in the
complement) applies and gives a contradiction.  This instance of 13.6 is the new file
`Workspace/ProofLemmas/Thm212Claim5Antipath.lean` (`exists_odd_antipath`).

**Statement change to an agent-written helper (rule 1 exception).**  The second degenerate
configuration — `m = 1` and `x_t ∼ x_{t+1}` — really does give a hole of length 4, where 15.7
does not apply, and it is *not* refutable from the hypotheses the helper had: the paper excludes
it by claim (2), whose printed *"we may assume"* is the alternative *"`x₀,…,x_{t+1}` is a
`Y`-square, and the theorem holds by 20.1"* — i.e. the conclusion of 21.2, which a lemma whose
conclusion is `False` cannot use.  Indeed with `m = 1` claim (2) produces `x_s` (`s ≤ t`)
nonadjacent to both `x_{t+1}` and `p₁`, and `p₁ = p_m` is `X_{t−1}`-complete, so `s = t` and
therefore `x_t ≁ x_{t+1}`.  Accordingly the hypothesis `hc2 : Claim2 G x t p` — the paper's own
claim (2), verbatim — was added to

* `Thm212.claim5_even_middle_in_A_gap`,
* `Thm212.claim5_odd_gap`,
* `Thm212.endgame_claim5_gap`,

and to their three call sites, all of which are inside `Workspace/ProofLemmas/Thm212.lean`.  At
the only place where `endgame_claim5_gap` is used, `Thm212.endgame_thm211_witness_gap`, the
hypothesis is already derived a few lines earlier (`have hc2 : Claim2 G x t p`), so the change is
free.  No statement under `Workspace/Statements/` or `Workspace/Types/` changed, and the whole
project still builds.

# 9.3, case 2: 9.3.4 is too strong (`thm_9_3` is false as printed)

## Summary

`Workspace.ProofLemmas.Thm93CaseTwoNonmajor.statement_one_or_four_gap` is **false as stated**,
and so is statement 4 of 9.3 itself, hence the frozen
`Workspace.Statements.S09.SPGT.thm_9_3`.  The paper's sentence

> "... or (up to symmetry) `f, x₁` have the same neighbours in `V(P₁) ∪ V(P₂) ∪ V(Q₂)` (but
> then either statement 1 or statement 4 of the theorem holds)"

is correct only when the antipath `Q₁` has length `1`.  What the argument gives in general is:
either the neighbour set of `f` in `K` resolves the knot (statement 1), or **`f` has a
non-neighbour in `V(Q₁) \ {x₁}`**.  Statement 4 of 9.3 demands that the non-neighbour be the
other end `y₁` of `Q₁`.  When `Q₁` has length `1` the two coincide (`V(Q₁) \ {x₁} = {y₁}`),
which is why the same sentence is correct in case (1) of 9.3.  In case (2), where `P₁, P₂`
have length `1` and `Q₁` may be long, they differ, and a vertex `f` that is a *twin of `x₁`*
falsifies all four outcomes of 9.3.

The dichotomy that the argument does prove is formalised and proved (no `sorry`) as
`Workspace.ProofLemmas.Thm93CaseTwoNonmajorRepair.resolves_or_nonneighbour`.

## The counterexample

Let `H` be the bipartite subdivision of `K₄` with branch-vertices `c₁, c₂, c₃, c₄`, the four
edges `c₁c₂, c₂c₃, c₃c₄, c₄c₁` unsubdivided, the branch `c₁ → c₃` of length 4 (internal
vertices `t₁, t₂, t₃`) and the branch `c₂ → c₄` of length 2 (internal vertex `s₁`).  `H` is
bipartite and has 10 edges.  Put, in `Ḡ`,

```
b₁ = c₁c₂   a₂ = c₂c₃   a₁ = c₃c₄   b₂ = c₄c₁
x₁ = c₁t₁   q₁ = t₁t₂   q₂ = t₂t₃   y₁ = t₃c₃      (the branch c₁ → c₃)
x₂ = c₂s₁   y₂ = s₁c₄                              (the branch c₂ → c₄)
```

and let `Ḡ` restricted to `K = {b₁,a₂,a₁,b₂,x₁,q₁,q₂,y₁,x₂,y₂}` be `L(H)`.  Then in `G` the
quadruple `(P₁, P₂, Q₁, Q₂) = ([a₁,b₁], [a₂,b₂], [x₁,q₁,q₂,y₁], [x₂,y₂])` is a knot inducing
`K`, with `P₁, P₂` of length 1 and `Q₁` of length 3 — exactly case (2) of 9.3.  (All 20
conjuncts of `IsKnot` were checked by machine.)

Add a single vertex `f ∉ K` whose `Ḡ`-neighbourhood in `K` is `{b₁, b₂, q₁}`, i.e. exactly the
`Ḡ`-neighbourhood of `x₁`; so `f` is a twin of `x₁` (adjacent to it in `G`, non-adjacent in
`Ḡ`).  Let `G` be the resulting 11-vertex graph.  Then:

* `G` is Berge: adding a twin preserves Bergeness, and both `G` and `Ḡ` were checked by
  exhaustive search over all induced cycles to have no odd hole.
* There is **no** appearance of any `K₄`-enlargement in `G` or in `Ḡ`, and **no** overshadowed
  appearance of `K₄` in `G` or in `Ḡ`.  Every induced subgraph of `G` and of `Ḡ` was tested:
  the root graph of each connected induced subgraph that is a line graph was reconstructed
  (Krausz partition; cross-checked independently with `networkx.inverse_line_graph`), kept
  when bipartite, and its topological reduction tested for 3-connectivity.  In `Ḡ` exactly two
  appearances of `K₄` turn up — `L(H)` on `K`, and `L(H)` on `K \ {x₁} ∪ {f}` — and neither is
  overshadowed, because every branch of `H` has *even* length (1, 1, 1, 1, 2, 4); by 9.1 the
  two long branches of a knot's `H` always have even length, so a knot's own appearance is
  never overshadowed.  In `G` there is no appearance of `K₄` at all (its largest induced line
  graph has 7 vertices).
* `F = {f}` is connected, disjoint from `K`, and its set of attachments in `K` is
  `N_G(f) ∩ K = {a₁, a₂, x₁, q₂, y₁, x₂, y₂}`, which meets both `V(P₁)` and `V(P₂)` and hence
  is **not** local with respect to the knot.

So every hypothesis of 9.3 holds.  But none of its four conclusions does:

1. `N_G(f) ∩ K` does not resolve the knot: the edges `b₁q₁` and `b₂q₁` between
   `V(P₁) ∪ V(P₂)` and `V(Q₁) ∪ V(Q₂)` have neither end in it.
2. fails: `f` has the same neighbours as none of `a₁, b₁, a₂, b₂` in the corresponding
   `V(P') ∪ V(Q₁) ∪ V(Q₂)` (it is a twin of `x₁`, not of a path end).
3. fails: `F` is a singleton, so the only path `R` in `F` has length `0`, not odd.
4. fails: `f, x₁` do have the same neighbours in `V(P₁) ∪ V(P₂) ∪ V(Q₂)`, but `f` **is**
   adjacent to `y₁` (because `x₁` is: `Q₁` is an antipath of length 3, so `x₁y₁ ∈ E(G)`); and
   for the other three choices `(y₁,x₁,Q₂), (x₂,y₂,Q₁), (y₂,x₂,Q₁)` the "same neighbours"
   clause already fails.

The *only* non-neighbour of `f` on `V(Q₁) \ {x₁}` is the interior vertex `q₁`, which is what
the corrected outcome supplies and what 9.3.4 as printed cannot name.

Consistency check: the same exhaustive scan over all `2^10` possible attachment sets of a
single vertex `f`, run for a **case (1)** knot (`Q₁, Q₂` of length 1) in the same `L(H)`,
produces **no** counterexample at all — as it must, since the paper's proof of case (1) is
complete.  In case (2) the scan produces exactly four counterexamples, and all four are twins
(true or false) of `x₁` or of `y₁`, the ends of the long antipath.

## What was done

* `Thm93CaseTwoNonmajor.nonlocal_enlargement_gap` is **proved** (it is literally
  `Thm93CaseOneEnlarge.enlargement` in the complement lane).
* `Thm93CaseTwoNonmajor.statement_one_or_four_gap` keeps its `sorry`.  Per hard rule 1 the
  frozen `thm_9_3` may not be weakened, and no repair inside `Workspace/ProofLemmas/` can
  rescue a false frozen statement, so the item is stopped here and reported.  Its docstring
  now records the falsity and points at this section.
* New file `Workspace/ProofLemmas/Thm93CaseTwoNonmajorRepair.lean` proves, with no `sorry`,
  the statement the argument actually gives:
  `resolves_or_nonneighbour` — "either some `g ∈ F` has a neighbour set in `K` that resolves
  the knot, or `f` has a non-neighbour in `V(Qx) \ {x}`".

## Suggested repair of the frozen statement (not applied)

In `Workspace/Statements/S09/Thm_9_3.lean`, outcome 9.3.4 should read

```
(∃ (x y : V) (Q' Qx : List V),
  ((x, y, Q', Qx) = (x₁, y₁, Q₂, Q₁) ∨ (x, y, Q', Qx) = (y₁, x₁, Q₂, Q₁) ∨
   (x, y, Q', Qx) = (x₂, y₂, Q₁, Q₂) ∨ (x, y, Q', Qx) = (y₂, x₂, Q₁, Q₂)) ∧
  ∃ f ∈ F,
    (∀ w ∈ ({v | v ∈ P₁} ∪ {v | v ∈ P₂} ∪ {v | v ∈ Q'} : Set V), (G.Adj f w ↔ G.Adj x w)) ∧
    ∃ w ∈ Qx, w ≠ x ∧ ¬ G.Adj f w)
```

i.e. "`f` has a non-neighbour in `V(Qx) \ {x}`" in place of "`f` is not adjacent to `y`".
This is the exact dual of outcome 9.3.2 (which asks that `r₂` *have a neighbour* in
`P₁ \ a₁`), it is implied by the printed 9.3.4, and with it the whole case-(2) lane of the
proof goes through: `Thm93CaseTwoNonmajorRepair.resolves_or_nonneighbour` closes the last
step, and `Thm93CaseTwoNonmajor.endgame` needs only to pass its conclusion on.  Consumers of
9.3 (9.4, 9.5) would have to be checked against the weakened outcome.

# Session s58k — 5.8 (6), the `G`-side assembly of the two link gaps

Assignment: prove `Thm58StarBranchLinkConfig.starTrackLink_singleton_of_host` and
`…_separated_of_host`.  Both are now proved (no `sorry` in either), modulo one new labelled gap
each, for the case that session s58h's report calls *case 3*.

## New sorry-free files

* `Workspace/ProofLemmas/Thm58StarBranchLinkTracks.lean` — `trackEdges_append_tail_subset`,
  `firstTrackEdge_append_tail`, and `exists_extended_tracks`.  The last one is the whole
  host-side content of *"three vertex-disjoint paths, from `N_{v₁}`, `N_{v₂}`, `N_u`
  respectively to `N_w`"*: it takes the cycle `q ∪ D`, the minimal track `Sm`, the far end `w`
  and two branch indices `α < β`, and returns three tracks of `H` out of `w`, pairwise meeting
  only at `w`, ending at `q[α]`, `q[β]` and `c`, with their first and last edges named.  The two
  arc tracks are already continued along the branch, so in `G` they are plain rungs and only the
  star sector needs an extension.
* `Workspace/ProofLemmas/Thm58StarBranchLinkSector.lean` — `mem_P_not_mem_K`, `rung_adj_P`,
  `exists_star_extension_strong`, `exists_star_extension`.  This is the path *"from `N_u`"*
  after its rung: the neighbour of `p₁` in the star at `c`, when it is not already the last
  vertex of the rung, followed by a prescribed part `Q₀` of `P`.

## Added to `Thm58StarBranchLinkConfig.lean`

`link_of_tracks` (three tracks plus one extension make a `StarTrackLink`), `link_reorder`
(permute the three sectors — 2.4 wants the two nonneighbours of `r` first), `dropLast_isPathFrom`,
`singleton_link_core`, `separated_link_core`, and the two dispatching proofs.

## The two new labelled gaps

`starTrackLink_singleton_star_at_branch_end` and `starTrackLink_separated_star_at_branch_end`.
Both carry the extra hypothesis

    ∀ x (hx : s(c,x) ∈ H.edgeSet), G.Adj p₁ (φ ⟨s(c,x), hx⟩) → x ∈ q,

i.e. every neighbour of `p₁` in the star at `u = c` is an edge of `H` from `c` to a vertex of
the branch.  This is case 3 of the s58h report.  Everything else is proved: if some such `x` is
off the branch, then either `x ∉ D`, and `singleton_link_core` / `separated_link_core` apply
directly, or `x ∈ D`, and they apply after replacing the minimal track by the one-edge track
`[c,x]` (so `w := x`), which is case 2 of that report.

Note for whoever closes them: such an `x` is a vertex of the branch adjacent to `c ∉ q`, and an
*internal* vertex of a branch has degree 2 with both neighbours on the branch, so `x ∈ {v₁,v₂}`.
For the singleton gap the fix is the alternative link at `w := v₁` described in the s58h report.
For the separated gap that fix is unavailable, since the conclusion demands `w ∉ q`; the escape
has to be a parity contradiction from `Berge G` on the holes closed by the branch, the return
track `D` and `P`.

## No statement was repaired

`exists_star_extension` keeps the statement it was created with; the sharper conclusion needed by
the separated case (each vertex of the extension lies in `Q₀` itself, not merely in `P`) is a new
declaration `exists_star_extension_strong`, of which the old one is now a one-line corollary.

# t192h — closing `Thm192Claim9YAdjX2.uniqueNeighbourContradiction`

The last gap of 19.2 claim (9), the case `G.Adj (x 2) y`, is now proved.  No statement under
`Workspace/Types/` or `Workspace/Statements/` was touched, and no existing statement was
changed; only proof bodies of `Thm192Claim9YAdjX2.lean` and `Thm192Claim9.lean`, plus new
files.

## The argument

`uniqueNeighbourContradiction` is the printed configuration where `f` is the unique
neighbour of `y` in `A` and `x₂` is adjacent to `y`.  Split on whether the hub can be
shrunk.

* Shrinkable case.  Some anticonnected `Y₀ ⊊ Y` contains `y` and has a vertex nonadjacent
  to `x₂`.  Then `x₂` is not `Y₀`-complete and `Y₀.ncard < Y.ncard`, so the localized
  smaller-hub induction of claim (2) gives two distinct `Y₀`-complete vertices `c, d ∈ A`
  (`Thm192Claim9YAdjX2TwoComplete.two_complete_in_A`).  Both are adjacent to `y ∈ Y₀`, so
  uniqueness of `f` forces `c = f = d`, contradicting `c ≠ d`.  This is the printed
  sentence *"If `y₀ ∈ Y₀`, then `x₂` is not `Y₀`-complete, and therefore by (2) there are
  two `Y₀`-complete vertices in `A`, a contradiction."*
* Unshrinkable case (`minimalHubContradiction`).  Then `x₂` has exactly one nonneighbour
  `w` in `Y` and `Y \ {w}` is anticonnected: `Y` is anticonnected and not a singleton, so
  `NonCutVertices.exists_two_nonanticut` gives two vertices whose deletion keeps `Y`
  anticonnected, and for any such vertex other than `y` the unshrinkability hypothesis
  forces it to be the unique nonneighbour of `x₂`.  Hence `w` is a vertex claim (1) could
  have chosen in place of `y`: it lies in `Y`, is adjacent to `z`, has a neighbour in `A₁`,
  and `Y \ {w}` is anticonnected.  Re-running the printed assembly of 19.2 at `(w, A')`,
  with `A'` a cardinality-minimal `GoodA` set for `w`, reaches claim (11)'s first sentence
  *"`z` is not `Y₀`-complete"* (`Thm192Claim9YAdjX2Rerun.z_not_Y0_complete`).  But `x₂` is
  adjacent to `y`, so claim (2) at `(y, A)` yields its second alternative, `z` is
  `Y`-complete, hence `Y \ {w}`-complete.  Contradiction.

## New files

* `Workspace/ProofLemmas/Thm192Claim9YAdjX2TwoComplete.lean` — a generalization of
  `Thm192Claim2Localization.lean` in which the localized wheel is built for an arbitrary
  anticonnected `Y₀ ⊆ Y` with `x₂` not `Y₀`-complete and `Y₀` smaller than `Y`, dropping the
  minimality and `y`-specific hypotheses; `two_complete_in_A` is the resulting "two
  `Y₀`-complete vertices in `A`".
* `Workspace/ProofLemmas/Thm192Claim9NotAdjX2.lean` — the `¬ G.Adj (x 2) y` branch of
  `Thm192Claim9.claim9`, copied out verbatim so that it can be used without importing
  `Thm192Claim9YAdjX2` (which would create a module cycle).  `Thm192Claim9.claim9` is now a
  two-line dispatcher onto this file and `Thm192Claim9YAdjX2.claim9_of_x2_adj_y`; its
  original private helpers are kept, since rule 3 forbids deleting declarations.
* `Workspace/ProofLemmas/Thm192Claim9YAdjX2Rerun.lean` — a copy of the private assembly of
  `Workspace/Statements/S19/Thm_19_2.lean` (claims (1)–(11) glued together, including the
  `x₀ ↔ x₁` symmetry block), carrying the extra hypothesis `¬ G.Adj (x 2) y` and stopping at
  claim (11) instead of the endgame.  Its public result is `z_not_Y0_complete`.  The copy is
  needed because `Thm_19_2.lean` is frozen and, as a `Statements` file, cannot be imported
  from a `ProofLemmas` file that it transitively depends on.
* `Workspace/ProofLemmas/Thm192Claim9YAdjX2Claim11.lean` — a copy of `Thm192Claim11.lean`
  which obtains *"`x₂` is not `{x₀,x₁}`-complete"* from `Thm192Claim8.claim8` (available
  under `¬ G.Adj (x 2) y`) instead of `Thm192Claim10.claim10`.  `Thm192Claim10` imports
  `Thm192Claim9`, so the original claim (11) cannot be used from inside the claim (9) proof.

## Session s58h — 5.8 star--branch gaps (claims (2) and (6))

Assignment: prove `Thm58StarBranchParity.exists_twoTrackCompletion`,
`Thm58StarBranchLinkConfig.exists_starTrackLink_singleton`,
`Thm58StarBranchLinkConfig.exists_starTrackLink_separated`,
`Thm58StarBranchMixed.exists_mixedSectors`.  None of the four is closed.  What was proved is
the whole **host-graph** half of claim (6)'s first sentence, sorry-free, plus the tools claim
(2) needs; the two link gaps now consume that data instead of asserting it.

### New sorry-free files

* `Workspace/ProofLemmas/Connectivity58Skeleton.lean` —
  `exists_third_neighbor`, `exists_avoiding_track_first`, `exists_avoiding_track`: in a
  3-connected graph `J`, an edge `b₁b₂` and a vertex `u ∉ {b₁,b₂}` admit a track from `b₁` to
  `b₂` avoiding `u`, not using the edge `b₁b₂`, of length ≥ 3, and starting along any
  prescribed edge at `b₁`.  This is the skeleton form of *"choose a cycle `C₁` of `H` using the
  branch between `v₁` and `v₂` and not using `u`"*.  It uses 3-connectivity only through
  *"deleting two vertices leaves a connected graph"*.
* `Workspace/ProofLemmas/Connectivity58Cycle.lean` — `expandTracks_length_ge`,
  `mem_expandTracks_of_mem`, and `exists_return_track`: the lift of the skeleton track through
  the subdivision.  For a branch `q` with ends `v₁`, `v₂` and a branch-vertex `c ∉ q` it gives a
  second track `D` from `v₁` to `v₂` with `c ∉ D`, `D ∩ q ⊆ {v₁,v₂}`, no edge of `q` on `D`, and
  a third branch-vertex on `D`.  (`q` together with `D` is the cycle `C₁`.)
* `Workspace/ProofLemmas/Connectivity58Minimal.lean` — `exists_first_hit` (cut a track at its
  first vertex in a target set), `exists_no_chord_at_head` (shortcut a track so that its first
  vertex has exactly one neighbour on it), `neighbors_of_branch_interior`,
  `track_avoids_branch` (a track avoiding both ends of a branch never meets the branch).
* `Workspace/ProofLemmas/Connectivity58Tracks.lean` — `exists_cycle_and_minimal_track`: the
  complete first sentence of 5.8 (6) on the host graph, i.e. the cycle plus the minimal track
  `S` from `c` to an *internal* vertex `w` of `D`, meeting `D` only at `w`, missing `q`, and
  with no chord at `c`.
* `Workspace/ProofLemmas/Connectivity58FirstEdge.lean` — `exists_track_first_edge`: the paper's
  *"if we delete all edges of `H` incident with `u` except `s₁`, the graph we produce is still
  connected; consequently there is a track of `H` from `u` to `v` with first edge `s₁`"*
  (5.8 (2), p. 26).
* `Workspace/ProofLemmas/Thm58StarBranchCycleData.lean` — `branch_ends`, `exists_host_data`:
  the same, specialised to `Thm58StarBranchBasics.Context`.

### What changed in the two link gaps

`Thm58StarBranchLinkConfig.exists_starTrackLink_singleton` and `…_separated` are no longer
`sorry`.  They now call `Thm58StarBranchCycleData.exists_host_data` and then the two new,
strictly smaller labelled gaps `starTrackLink_singleton_of_host` and
`starTrackLink_separated_of_host`, which receive the cycle `q ∪ D`, the minimal track `Sm`, its
far end `w` and its index `k` on `D` as hypotheses.  The remaining content of those two gaps is
purely the assembly in `G`: read the three tracks out of `w` as rungs, extend them, and check
the anticompleteness.  No frozen statement changed.

### A trap in the intended construction of claim (6) (for whoever finishes it)

The obvious reading — take the two arcs of `D` out of `w` and the minimal track `S`, extend the
arcs along the branch towards `r` and extend `S` through a star vertex `a ∈ N_c` with
`p₁a ∈ E(G)` and then along `P` — is **not** always correct, and the `StarTrackLink` fields
`extCross` / `extRungCross` are exactly where it fails.  Write `a = φ s(c,x)`.

1. `x ∈ V(S)` with `x ≠ S[1]`: then `a` sees the rung of `S` twice and the third path is not
   induced.  Cured by `Connectivity58Minimal.exists_no_chord_at_head`, which is why
   `exists_host_data` now returns `∀ y ∈ Sm, H.Adj c y → Sm[1]? = some y`.
2. `x ∈ V(D) \ {v₁,v₂}`: then `a` sees the arc rungs at `x`.  Cured by choosing the minimal
   track to be `[c,x]`, i.e. `w := x`; then `a` is the apex of the third track and the two
   adjacencies are the two triangle edges.
3. `x ∈ {v₁,v₂}`, say `x = v₁`, with `r` an internal vertex of the branch rung: then `a` sees
   the branch-rung vertex `r₁ = φ s(v₁,q[1])`, which lies on the *first* extended path, and no
   choice of `S` repairs it.  The fix is a different, equally valid `StarTrackLink`, with
   `w := v₁` and the three tracks
   `q[0..i]` (the branch truncated just before `r`), `[v₁,c]`, and `D`;
   these do meet only at `v₁` because the branch is truncated.  The three regions are then
   `Rg₀ =` the truncated branch rung, `Rg₁ = {a}`, `E₁ = V(P)`, `Rg₂ =` the rung of `D`,
   `E₂ =` the part of the branch rung on the `v₂` side of `r`; the triangle must be listed as
   `(a, φ s(v₁,D[1]), r₁)` so that its first two vertices are nonneighbours of `r`.
   Case 3 is why a proof of `starTrackLink_singleton_of_host` must be a case analysis on where
   the neighbours of `p₁` in `N_c` sit, not a single construction.

### Not started

`exists_twoTrackCompletion` (5.8 (2)) and `exists_mixedSectors` (5.8 (6), the Menger step) are
untouched apart from `Connectivity58FirstEdge.exists_track_first_edge`, which is the first
sentence of the former.  The Menger step still needs *"in a 2-connected graph there are two
disjoint paths from an edge to a prescribed pair of vertices"*, which this Mathlib snapshot does
not have.

## s58l: 5.8 (2) and 5.8 (6)

### Done

`Thm58StarBranchParity.exists_twoTrackCompletion` (5.8 (2)) is proved and axiom-clean.  The
work is split into three new files: `Thm58StarBranchParityEnds.lean` (slices and ends of
induced paths), `Thm58StarBranchParityTrack.lean` (host tracks leaving the star along a
prescribed edge and avoiding the branch), and `Thm58StarBranchParityBuild.lean` (the
assembly, including the bipartite parity step).

`Thm58StarBranchMixed.exists_mixedSectors` (5.8 (6)) is proved from a single labelled gap,
`Thm58StarBranchMixedHole.exists_mixed_hole`, which is the paper's Menger sentence: the rung
of the cycle `C₂` is a hole of `G` inside the appearance, read from the `A`-end `a` of its
unique edge of `N(u)`, with `pₙ`'s two neighbours `r`, `s` consecutive on it.  Everything
after that sentence — the two arcs, their inducedness, disjointness, the single cross edge
`rs`, and the fact that no arc vertex is adjacent to `p₁` — is proved with no gap, using
`CycleArcPath.arc_isPathFrom`.

### Repair of an earlier declaration

`Thm58StarBranchMixed.MixedSectors` had

```
offStar₁ : ∀ x ∈ D₁, x ∉ N c
offStar₂ : ∀ x ∈ D₂, x ∉ N c
```

Both are **false** for the paper's witness, so the structure was unsatisfiable as written.
Counterexample (the paper's own construction, printed p. 28): the path of 5.8 (6) *"uses a
unique edge of `N(u)`, and that edge is between a vertex `a ∈ A` and some vertex in `B`"*.
Write `b ∈ B` for the other end of that edge.  Deleting `a` leaves `b` in one of the two
pieces, say `T₂ ⊆ D₂`, and `b ∈ N_u = N c` by construction.  So `offStar₂` fails for `x = b`.
(Concretely: `L` is the hole, `a = L[0]`, `b = L[1]` or `b = L[L.length-1]`, and both of those
lie in an arc.)

The fields were weakened to the property that is actually true and actually used:

```
offStar₁ : ∀ x ∈ D₁, ¬ G.Adj p₁ x
offStar₂ : ∀ x ∈ D₂, ¬ G.Adj p₁ x
```

This is what *"a unique edge of `N(u)`"* asserts, and it is implied by the old field (via
`Thm58StarBranchBasics.first_adj_mem`), so the repair strictly weakens the structure.  The
only consumer is `mixed_link_of_sectors`, whose local `hPD` used the field to rule out an edge
from `p₁` into a sector; that step now closes directly with `absurd (hh.1 ▸ huv) (hDN v hv)`.
`Thm58StarBranchGaps.mixed_star_link_gap` is unchanged and still compiles.

# t192h — closing `Thm192Claim9YAdjX2.uniqueNeighbourContradiction`

The last gap of 19.2 claim (9), the case `G.Adj (x 2) y`, is now proved.  No statement under
`Workspace/Types/` or `Workspace/Statements/` was touched, and no existing statement was
changed; only proof bodies of `Thm192Claim9YAdjX2.lean` and `Thm192Claim9.lean`, plus new
files.

## The argument

`uniqueNeighbourContradiction` is the printed configuration where `f` is the unique
neighbour of `y` in `A` and `x₂` is adjacent to `y`.  Split on whether the hub can be
shrunk.

* Shrinkable case.  Some anticonnected `Y₀ ⊊ Y` contains `y` and has a vertex nonadjacent
  to `x₂`.  Then `x₂` is not `Y₀`-complete and `Y₀.ncard < Y.ncard`, so the localized
  smaller-hub induction of claim (2) gives two distinct `Y₀`-complete vertices `c, d ∈ A`
  (`Thm192Claim9YAdjX2TwoComplete.two_complete_in_A`).  Both are adjacent to `y ∈ Y₀`, so
  uniqueness of `f` forces `c = f = d`, contradicting `c ≠ d`.  This is the printed
  sentence *"If `y₀ ∈ Y₀`, then `x₂` is not `Y₀`-complete, and therefore by (2) there are
  two `Y₀`-complete vertices in `A`, a contradiction."*
* Unshrinkable case (`minimalHubContradiction`).  Then `x₂` has exactly one nonneighbour
  `w` in `Y` and `Y \ {w}` is anticonnected: `Y` is anticonnected and not a singleton, so
  `NonCutVertices.exists_two_nonanticut` gives two vertices whose deletion keeps `Y`
  anticonnected, and for any such vertex other than `y` the unshrinkability hypothesis
  forces it to be the unique nonneighbour of `x₂`.  Hence `w` is a vertex claim (1) could
  have chosen in place of `y`: it lies in `Y`, is adjacent to `z`, has a neighbour in `A₁`,
  and `Y \ {w}` is anticonnected.  Re-running the printed assembly of 19.2 at `(w, A')`,
  with `A'` a cardinality-minimal `GoodA` set for `w`, reaches claim (11)'s first sentence
  *"`z` is not `Y₀`-complete"* (`Thm192Claim9YAdjX2Rerun.z_not_Y0_complete`).  But `x₂` is
  adjacent to `y`, so claim (2) at `(y, A)` yields its second alternative, `z` is
  `Y`-complete, hence `Y \ {w}`-complete.  Contradiction.

## New files

* `Workspace/ProofLemmas/Thm192Claim9YAdjX2TwoComplete.lean` — a generalization of
  `Thm192Claim2Localization.lean` in which the localized wheel is built for an arbitrary
  anticonnected `Y₀ ⊆ Y` with `x₂` not `Y₀`-complete and `Y₀` smaller than `Y`, dropping the
  minimality and `y`-specific hypotheses; `two_complete_in_A` is the resulting "two
  `Y₀`-complete vertices in `A`".
* `Workspace/ProofLemmas/Thm192Claim9NotAdjX2.lean` — the `¬ G.Adj (x 2) y` branch of
  `Thm192Claim9.claim9`, copied out verbatim so that it can be used without importing
  `Thm192Claim9YAdjX2` (which would create a module cycle).  `Thm192Claim9.claim9` is now a
  two-line dispatcher onto this file and `Thm192Claim9YAdjX2.claim9_of_x2_adj_y`; its
  original private helpers are kept, since rule 3 forbids deleting declarations.
* `Workspace/ProofLemmas/Thm192Claim9YAdjX2Rerun.lean` — a copy of the private assembly of
  `Workspace/Statements/S19/Thm_19_2.lean` (claims (1)–(11) glued together, including the
  `x₀ ↔ x₁` symmetry block), carrying the extra hypothesis `¬ G.Adj (x 2) y` and stopping at
  claim (11) instead of the endgame.  Its public result is `z_not_Y0_complete`.  The copy is
  needed because `Thm_19_2.lean` is frozen and, as a `Statements` file, cannot be imported
  from a `ProofLemmas` file that it transitively depends on.
* `Workspace/ProofLemmas/Thm192Claim9YAdjX2Claim11.lean` — a copy of `Thm192Claim11.lean`
  which obtains *"`x₂` is not `{x₀,x₁}`-complete"* from `Thm192Claim8.claim8` (available
  under `¬ G.Adj (x 2) y`) instead of `Thm192Claim10.claim10`.  `Thm192Claim10` imports
  `Thm192Claim9`, so the original claim (11) cannot be used from inside the claim (9) proof.

## Session s58h — 5.8 star--branch gaps (claims (2) and (6))

Assignment: prove `Thm58StarBranchParity.exists_twoTrackCompletion`,
`Thm58StarBranchLinkConfig.exists_starTrackLink_singleton`,
`Thm58StarBranchLinkConfig.exists_starTrackLink_separated`,
`Thm58StarBranchMixed.exists_mixedSectors`.  None of the four is closed.  What was proved is
the whole **host-graph** half of claim (6)'s first sentence, sorry-free, plus the tools claim
(2) needs; the two link gaps now consume that data instead of asserting it.

### New sorry-free files

* `Workspace/ProofLemmas/Connectivity58Skeleton.lean` —
  `exists_third_neighbor`, `exists_avoiding_track_first`, `exists_avoiding_track`: in a
  3-connected graph `J`, an edge `b₁b₂` and a vertex `u ∉ {b₁,b₂}` admit a track from `b₁` to
  `b₂` avoiding `u`, not using the edge `b₁b₂`, of length ≥ 3, and starting along any
  prescribed edge at `b₁`.  This is the skeleton form of *"choose a cycle `C₁` of `H` using the
  branch between `v₁` and `v₂` and not using `u`"*.  It uses 3-connectivity only through
  *"deleting two vertices leaves a connected graph"*.
* `Workspace/ProofLemmas/Connectivity58Cycle.lean` — `expandTracks_length_ge`,
  `mem_expandTracks_of_mem`, and `exists_return_track`: the lift of the skeleton track through
  the subdivision.  For a branch `q` with ends `v₁`, `v₂` and a branch-vertex `c ∉ q` it gives a
  second track `D` from `v₁` to `v₂` with `c ∉ D`, `D ∩ q ⊆ {v₁,v₂}`, no edge of `q` on `D`, and
  a third branch-vertex on `D`.  (`q` together with `D` is the cycle `C₁`.)
* `Workspace/ProofLemmas/Connectivity58Minimal.lean` — `exists_first_hit` (cut a track at its
  first vertex in a target set), `exists_no_chord_at_head` (shortcut a track so that its first
  vertex has exactly one neighbour on it), `neighbors_of_branch_interior`,
  `track_avoids_branch` (a track avoiding both ends of a branch never meets the branch).
* `Workspace/ProofLemmas/Connectivity58Tracks.lean` — `exists_cycle_and_minimal_track`: the
  complete first sentence of 5.8 (6) on the host graph, i.e. the cycle plus the minimal track
  `S` from `c` to an *internal* vertex `w` of `D`, meeting `D` only at `w`, missing `q`, and
  with no chord at `c`.
* `Workspace/ProofLemmas/Connectivity58FirstEdge.lean` — `exists_track_first_edge`: the paper's
  *"if we delete all edges of `H` incident with `u` except `s₁`, the graph we produce is still
  connected; consequently there is a track of `H` from `u` to `v` with first edge `s₁`"*
  (5.8 (2), p. 26).
* `Workspace/ProofLemmas/Thm58StarBranchCycleData.lean` — `branch_ends`, `exists_host_data`:
  the same, specialised to `Thm58StarBranchBasics.Context`.

### What changed in the two link gaps

`Thm58StarBranchLinkConfig.exists_starTrackLink_singleton` and `…_separated` are no longer
`sorry`.  They now call `Thm58StarBranchCycleData.exists_host_data` and then the two new,
strictly smaller labelled gaps `starTrackLink_singleton_of_host` and
`starTrackLink_separated_of_host`, which receive the cycle `q ∪ D`, the minimal track `Sm`, its
far end `w` and its index `k` on `D` as hypotheses.  The remaining content of those two gaps is
purely the assembly in `G`: read the three tracks out of `w` as rungs, extend them, and check
the anticompleteness.  No frozen statement changed.

### A trap in the intended construction of claim (6) (for whoever finishes it)

The obvious reading — take the two arcs of `D` out of `w` and the minimal track `S`, extend the
arcs along the branch towards `r` and extend `S` through a star vertex `a ∈ N_c` with
`p₁a ∈ E(G)` and then along `P` — is **not** always correct, and the `StarTrackLink` fields
`extCross` / `extRungCross` are exactly where it fails.  Write `a = φ s(c,x)`.

1. `x ∈ V(S)` with `x ≠ S[1]`: then `a` sees the rung of `S` twice and the third path is not
   induced.  Cured by `Connectivity58Minimal.exists_no_chord_at_head`, which is why
   `exists_host_data` now returns `∀ y ∈ Sm, H.Adj c y → Sm[1]? = some y`.
2. `x ∈ V(D) \ {v₁,v₂}`: then `a` sees the arc rungs at `x`.  Cured by choosing the minimal
   track to be `[c,x]`, i.e. `w := x`; then `a` is the apex of the third track and the two
   adjacencies are the two triangle edges.
3. `x ∈ {v₁,v₂}`, say `x = v₁`, with `r` an internal vertex of the branch rung: then `a` sees
   the branch-rung vertex `r₁ = φ s(v₁,q[1])`, which lies on the *first* extended path, and no
   choice of `S` repairs it.  The fix is a different, equally valid `StarTrackLink`, with
   `w := v₁` and the three tracks
   `q[0..i]` (the branch truncated just before `r`), `[v₁,c]`, and `D`;
   these do meet only at `v₁` because the branch is truncated.  The three regions are then
   `Rg₀ =` the truncated branch rung, `Rg₁ = {a}`, `E₁ = V(P)`, `Rg₂ =` the rung of `D`,
   `E₂ =` the part of the branch rung on the `v₂` side of `r`; the triangle must be listed as
   `(a, φ s(v₁,D[1]), r₁)` so that its first two vertices are nonneighbours of `r`.
   Case 3 is why a proof of `starTrackLink_singleton_of_host` must be a case analysis on where
   the neighbours of `p₁` in `N_c` sit, not a single construction.

### Not started

`exists_twoTrackCompletion` (5.8 (2)) and `exists_mixedSectors` (5.8 (6), the Menger step) are
untouched apart from `Connectivity58FirstEdge.exists_track_first_edge`, which is the first
sentence of the former.  The Menger step still needs *"in a 2-connected graph there are two
disjoint paths from an edge to a prescribed pair of vertices"*, which this Mathlib snapshot does
not have.

## `Thm58StarStarGapOffBranch.five_six_off_branch` — added hypothesis `hchord`

Agent for 5.8 (4), gap `Workspace.ProofLemmas.Thm58StarStarGapOffBranch.five_six_off_branch`.

The statement as written was not provable: 5.6 is applied to the graph `H'` obtained from `H`
by deleting the edges and the internal vertices of the branch `q` between `c₁` and `c₂`, and
5.6 requires `¬ H'.Adj c₁ c₂`.  With only `CyclicallyThreeConnected H`, `IsBranch H q` and
`IsTrackFrom H q c₁ c₂` in the hypotheses, nothing rules out a *second* edge `c₁c₂` of `H` that
is not an edge of `q`: such an edge survives the deletion and `H'.Adj c₁ c₂` holds, so 5.6 is
not applicable.  (In the paper this cannot happen because `c₁ = v₁`, `c₂ = v₂` are vertices of
the simple graph `J` and `q` is *the* branch corresponding to the edge `v₁v₂` of `J`, so there
is no other branch, in particular no other edge, between them.)

Smallest repair: add the missing hypothesis

    (hchord : ∀ f ∈ H.edgeSet, c₁ ∈ f → c₂ ∈ f → f ∈ trackEdges q)

which is exactly the paper's "`q` is the branch between `v₁` and `v₂`".  It is the same
hypothesis that the neighbouring `far_end_off_branch` in the same file already takes.

Consumers: the only consumer is `Thm58StarStarAdjacentGap.exists_tracks`, whose *statement* is
unchanged; its proof already derives `hchord` (from `Thm58StarStarGeometry.stars_inter_subset_rung`)
a few lines above the call, so the only change there is passing `hchord` to
`five_six_off_branch`.  Nothing under `Workspace/Statements/` or `Workspace/Types/` changed.

# Session s58o — 5.8 (6), the branch-end star case

Assignment: prove the two labelled gaps
`Thm58StarBranchLinkConfig.starTrackLink_singleton_star_at_branch_end` and
`…_separated_star_at_branch_end`.  Both are now proved, with no `sorry` and no new gap.
`exists_starTrackLink_singleton` and `exists_starTrackLink_separated` are sorry-free and
depend only on `propext`, `Classical.choice`, `Quot.sound`.

## What the case really is

Both gaps carry the hypothesis that every neighbour of `p₁` in the star `N_u` at `u = c` is
an edge `c x` of `H` with `x` on the branch `q`.  Such an `x` is an end `v₁` or `v₂` of the
branch (an internal branch vertex has degree `2` with both neighbours on the branch, and
`c ∉ q`).  The s58k report suggested rebuilding the link at `v₁` for the singleton gap and a
parity count for the separated gap.  In fact **the hypothesis is contradictory**, and one
argument settles both gaps, so no `StarTrackLink` has to be built at all.

## The argument

Write `a₁ = φ s(c,v₁)` for the star edge used by `p₁`, and let `t` be the largest index with
`pₙ` adjacent to the rung vertex `φ s(q[t], q[t+1])`.  Because the star `N_c` and the rung of
`q` are disjoint (`star_disjoint_branch`), the only vertices of `P` with neighbours in `K` are
`p₁` and `pₙ`.  Hence the rung of any track of `H` from the edge `c v₁` to the edge
`q[t] q[t+1]` closes with `p₁`-`P`-`pₙ` into a hole of `G`, provided the track's only edge at
`c` is `c v₁` and its only edge of `q` that `pₙ` sees is `q[t] q[t+1]`.  Two such tracks are:

* `c`, `v₁`, then the return track `D` to `v₂`, then back along `q` to `q[t]`;
* `v₁`, `c`, then the minimal track `Sm` to `w`, then along `D` to `v₂`, then back to `q[t]`.

They start at `c` and at `v₁` respectively and end at the same vertex, and `c v₁ ∈ E(H)` with
`H` bipartite, so their lengths have different parity.  The two rungs therefore give two holes
of different parity, and one of them is odd, contrary to `Berge G`.

The argument needs `t ≥ 1` (otherwise `a₁` is adjacent to the rung vertex `φ s(v₁,q[1])`,
which lies on the hole).  If `t = 0`, then every attachment of `F` is an edge of `H` at `v₁`
— `pₙ` sees only `φ s(v₁,q[1])`, and `p₁` only `φ s(c,v₁)` — so the attachments are local,
contrary to the hypothesis of 5.8.  Symmetrically at `v₂`, using the branch read backwards.
The only remaining configuration is `p₁` adjacent to both `φ s(c,v₁)` and `φ s(c,v₂)` with the
branch of length `1`; then `c v₁`, `c v₂`, `v₁ v₂` is a triangle of the bipartite `H`.

## New file

`Workspace/ProofLemmas/Thm58StarBranchLinkEnd.lean`, sorry-free:

* `mem_trackEdges_slice`, `mem_trackEdges_slice_of` — the edges of `TrackSlice.slice`;
* `hole_of_track`, `even_of_track` — the rung of a track from `c v₁` to `q[t] q[t+1]`,
  completed by `P`, is an even hole;
* `honly1_of_pieces`, `honly2_of_pieces`, `hlast_of_pieces` — reading the edges of a track
  whose edge set is contained in `{c v₁} ∪ E(D) ∪ E(Sm) ∪ E(q[t..])`;
* `branch_end_false` — the two-hole parity contradiction;
* `isBranch_reverse`, `context_reverse`, `branch_end_false_right` — the same read from `v₂`;
* `eq_end_of_adj_star`, `exists_extreme_index` — the two bookkeeping steps;
* `branch_end_absurd` — the case analysis above.

No statement under `Workspace/Statements/` or `Workspace/Types/` changed, and no existing
statement was repaired: only the two `sorry` bodies in `Thm58StarBranchLinkConfig.lean` were
replaced (plus one added import).

# 9.3.4 repaired (user-approved)

## The change

The user approved exactly one change to a frozen statement: in
`Workspace/Statements/S09/Thm_9_3.lean`, theorem `thm_9_3`, outcome 9.3.4, the final conjunct

    ¬ G.Adj f y

was replaced by

    ∃ w, (w ∈ Q₁ ∨ w ∈ Q₂) ∧ w ∉ Q' ∧ w ≠ x ∧ ¬ G.Adj f w

Nothing else in that file changed, and no other file under `Workspace/Statements/**` or
`Workspace/Types/**` changed.  The tuple `(x, y, Q')`, its four symmetric positions, the other
three outcomes and every hypothesis are untouched.

## Reason

The printed 9.3.4 is false, for the reason recorded in the section "9.3, case 2: 9.3.4 is too
strong" above: when the antipath of `x` is long, a twin of `x` satisfies the first conjunct of
9.3.4 and every other outcome fails, yet the twin is adjacent to `y`.  What the printed
argument proves at that point is the dichotomy
`Workspace.ProofLemmas.Thm93CaseTwoNonmajorRepair.resolves_or_nonneighbour`: either the
neighbour set of `f` in `K` resolves the knot (outcome 9.3.1), or `f` has a non-neighbour on
its own antipath other than `x`.  The new clause says exactly the latter: `Q₁` and `Q₂` are
disjoint and `Q'` is the antipath that does *not* contain `x`, so `w ∈ Q₁ ∨ w ∈ Q₂` together
with `w ∉ Q'` says that `w` lies on the antipath of `x`.

The printed clause implies the new one — take `w := y`, which lies on the antipath of `x`, is
distinct from `x` because it is its other end, and is a non-neighbour of `f` by hypothesis.
So the repair only weakens 9.3.4, and nothing else in the statement weakens.  On the case-(1)
lane of the proof of 9.3 (where `Q₁, Q₂` have length 1) the argument still gives the printed
clause, and that implication is how the new clause is produced there.

## Files changed

* `Workspace/Statements/S09/Thm_9_3.lean` — the one clause of outcome 9.3.4.
* `Workspace/ProofLemmas/Thm93Infrastructure.lean` — the same clause in the named
  abbreviation `Conclusion`.
* `Workspace/ProofLemmas/Thm93Assembly.lean` — the same clause in the two lane hypotheses
  `hcase1`, `hcase2` of `thm_9_3_of_cases` and in its conclusion.
* `Workspace/ProofLemmas/Thm93OutcomeFourWitness.lean` — **new**, sorry-free.  Contains
  `witness_of_nonadj`: the printed clause implies the new one, with witness `y`.
* `Workspace/ProofLemmas/Thm93CaseOneEndgame.lean` — one import, and one application of
  `witness_of_nonadj` where case (1) produces outcome 9.3.4.
* `Workspace/ProofLemmas/Thm93CaseTwoNonmajor.lean` — `conclusion_four` now takes the new
  clause; `statement_one_or_four_gap` is restated with the new clause and **proved** (its
  `sorry` is gone) from `Thm93CaseTwoNonmajorRepair.resolves_or_nonneighbour`.
* `Workspace/ProofLemmas/Thm93CaseTwoCounterexample.lean` — the ten-vertex graph refutes the
  conclusion *as printed*, not the repaired one (the repaired 9.3.4 holds there with `w = 5`).
  The printed conclusion is written out as the new abbreviation `PrintedConclusion`, and
  `not_conclusion` is restated about it.  Nothing imports this module.

The eight consumers of `thm_9_3` (`Thm94Body.lean:436`, `Thm94ClosingKnot.lean:82`,
`Thm95Claim1Step.lean:159`, `Thm95Claim3Step.lean:187`, `Thm95ClosingStep.lean:158`,
`Thm95Body.lean:694,862,1172`) all discard the last component of outcome 4, and needed no
edits.

With this repair `Workspace.MainTheorem.SPGT.thm_1_2` is sorry-free, with axioms
`[propext, Classical.choice, Quot.sound]`.
