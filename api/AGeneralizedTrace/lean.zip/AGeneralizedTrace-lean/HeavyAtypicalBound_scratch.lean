import Mathlib
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.CentralBinomialLowerTailWide

open Workspace.Types.AlternatingSumExpression

set_option maxHeartbeats 32000000

-- bin symmetry as a lemma
lemma binPMFInt_symm (n : ℕ) (k : ℤ) (h0 : 0 ≤ k) (h1 : k ≤ n) :
    binPMFInt n (1/2) k = binPMFInt n (1/2) ((n : ℤ) - k) := by
  unfold binPMFInt
  rw [if_pos ⟨h0, h1⟩]
  rw [if_pos ⟨by linarith, by linarith⟩]
  unfold binPMF
  have hkN : k.toNat ≤ n := by
    have : (k.toNat : ℤ) ≤ (n : ℤ) := by
      rw [Int.toNat_of_nonneg h0]; exact h1
    exact_mod_cast this
  have hnkN : ((n : ℤ) - k).toNat ≤ n := by
    have : (((n:ℤ) - k).toNat : ℤ) ≤ (n : ℤ) := by
      rw [Int.toNat_of_nonneg (by linarith : (0:ℤ) ≤ (n:ℤ) - k)]; linarith
    exact_mod_cast this
  rw [if_pos hkN]
  rw [if_pos hnkN]
  have h_eq : ((n : ℤ) - k).toNat = n - k.toNat := by
    have h_eq_int : (((n : ℤ) - k).toNat : ℤ) = ((n - k.toNat : ℕ) : ℤ) := by
      rw [Int.toNat_of_nonneg (by linarith : (0:ℤ) ≤ (n:ℤ) - k)]
      rw [Nat.cast_sub hkN]
      rw [Int.toNat_of_nonneg h0]
    exact_mod_cast h_eq_int
  rw [h_eq]
  rw [Nat.choose_symm hkN]
  rw [show (1 - (1/2 : ℝ)) = 1/2 from by ring]
  rw [show (n - (n - k.toNat) : ℕ) = k.toNat from by omega]
  ring

-- Sum over Icc a b reindex via subtraction.
-- ∑_{r ∈ Icc a b} f(r) = ∑_{r ∈ Icc (c - b) (c - a)} f(c - r)  for any c.
-- More useful: ∑_{r ∈ Icc a b} bin(n, 1/2, r + n/2) over r ∈ rB1 maps to ...

-- For Piece B's rB1 part: bound ∑_{r ∈ Icc((n/8) - (n/16) + 1, (n/4))} bin(n, 1/2, r + n/2).
-- For n%8=1, use binPMFInt_flip_n8mod1: bin(n, 1/2, r + n/2) = bin(n, 1/2, (1-r) + n/2).

lemma binPMFInt_flip_n8mod1 (n : ℕ) (h_n8 : n % 8 = 1) (r : ℤ)
    (h_r_lb : -((n : ℤ) / 4) ≤ r) (h_r_ub : r ≤ (n : ℤ) / 4) :
    binPMFInt n (1/2) (r + (n : ℤ) / 2) = binPMFInt n (1/2) ((1 - r) + (n : ℤ) / 2) := by
  have hn_pos : 0 < n := by
    have : n % 8 = 1 := h_n8
    omega
  have hn_int_nn : (0 : ℤ) ≤ (n : ℤ) := by exact_mod_cast Nat.zero_le n
  have h_n2_nn : (0 : ℤ) ≤ (n : ℤ) / 2 := by omega
  have h_n4_le_n2 : (n : ℤ) / 4 ≤ (n : ℤ) / 2 := by omega
  have h_n_minus_2n2_eq_1 : (n : ℤ) - 2 * ((n : ℤ) / 2) = 1 := by
    have h_mod2 : n % 2 = 1 := by omega
    have h_int_mod2 : (n : ℤ) % 2 = 1 := by exact_mod_cast h_mod2
    omega
  have h_lb : 0 ≤ r + (n : ℤ) / 2 := by linarith
  have h_ub : r + (n : ℤ) / 2 ≤ (n : ℤ) := by
    have : (n : ℤ) / 4 + (n : ℤ) / 2 ≤ (n : ℤ) := by omega
    linarith
  rw [binPMFInt_symm n (r + (n : ℤ) / 2) h_lb h_ub]
  congr 1
  linarith

-- Reindex sum: ∑_{r ∈ Icc a b} bin(n, 1/2, r + n/2) = ∑_{r' ∈ Icc (1-b) (1-a)} bin(n, 1/2, r' + n/2)
-- when -(n/4) ≤ a ≤ b ≤ n/4 and n%8 = 1.
lemma sum_binPMFInt_reindex_flip
    (n : ℕ) (h_n8 : n % 8 = 1)
    (a b : ℤ) (h_lb : -((n : ℤ) / 4) ≤ a) (h_ub : b ≤ (n : ℤ) / 4) (h_ab : a ≤ b) :
    ∑ r ∈ Finset.Icc a b, binPMFInt n (1/2) (r + (n : ℤ) / 2) =
      ∑ r ∈ Finset.Icc (1 - b) (1 - a), binPMFInt n (1/2) (r + (n : ℤ) / 2) := by
  -- Use Finset.sum_bij with the bijection ψ : r ↦ 1 - r.
  apply Finset.sum_bij (fun (r : ℤ) (_ : r ∈ Finset.Icc a b) => 1 - r)
  · intros r hr
    rw [Finset.mem_Icc] at hr ⊢
    omega
  · intros r1 hr1 r2 hr2 h_eq; linarith
  · intros r' hr'
    rw [Finset.mem_Icc] at hr'
    refine ⟨1 - r', ?_, by ring⟩
    rw [Finset.mem_Icc]
    omega
  · intros r hr
    rw [Finset.mem_Icc] at hr
    have h_r_lb : -((n : ℤ) / 4) ≤ r := by linarith
    have h_r_ub : r ≤ (n : ℤ) / 4 := by linarith
    -- Need: bin(n, 1/2, r + n/2) = bin(n, 1/2, (1 - r) + n/2)
    exact binPMFInt_flip_n8mod1 n h_n8 r h_r_lb h_r_ub

-- Test
example (n : ℕ) (hn : (10^12 : ℕ) ≤ n) (h_n8 : n % 8 = 1) :
    ∑ r ∈ Finset.Icc ((n : ℤ)/8 - (n : ℤ)/16 + 1) ((n : ℤ)/4),
        binPMFInt n (1/2) (r + (n : ℤ) / 2)
    ≤ ∑ r ∈ Finset.Icc (-((n : ℤ) / 4)) (-((n : ℤ) / 16)),
        binPMFInt n (1/2) (r + (n : ℤ) / 2) := by
  have hn_int_nn : (0 : ℤ) ≤ (n : ℤ) := by exact_mod_cast Nat.zero_le n
  have h_n4_int : (0 : ℤ) ≤ (n : ℤ) / 4 := by omega
  have h_n16_int : (0 : ℤ) ≤ (n : ℤ) / 16 := by omega
  have h_n8_int : (0 : ℤ) ≤ (n : ℤ) / 8 := by omega
  have h_a_lb : -((n : ℤ) / 4) ≤ (n : ℤ)/8 - (n : ℤ)/16 + 1 := by omega
  have h_b_ub : ((n : ℤ)/4) ≤ (n : ℤ) / 4 := le_refl _
  have h_ab : (n : ℤ)/8 - (n : ℤ)/16 + 1 ≤ (n : ℤ)/4 := by omega
  rw [sum_binPMFInt_reindex_flip n h_n8 _ _ h_a_lb h_b_ub h_ab]
  -- Now: ∑ r ∈ Icc (1 - n/4) (1 - (n/8 - n/16 + 1)), bin(n, 1/2, r + n/2)
  --    = ∑ r ∈ Icc (1 - n/4) ((n/16) - (n/8)), bin(n, 1/2, r + n/2)
  -- Want: ≤ ∑ r ∈ Icc (-(n/4)) (-(n/16)), bin(n, 1/2, r + n/2)
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intros r hr
    rw [Finset.mem_Icc] at hr ⊢
    have h1 : 1 - (n : ℤ) / 4 ≤ r := hr.1
    have h2 : r ≤ 1 - ((n : ℤ)/8 - (n : ℤ)/16 + 1) := hr.2
    constructor
    · linarith
    · -- r ≤ (n/16) - (n/8) ≤ -(n/16) (since 2(n/16) ≤ n/8)
      have h_2n16_le_n8 : 2 * ((n : ℤ)/16) ≤ (n : ℤ)/8 := by omega
      linarith
  · intros r _ _
    unfold binPMFInt
    split_ifs
    · unfold binPMF
      split_ifs
      · apply mul_nonneg
        apply mul_nonneg
        · exact_mod_cast Nat.zero_le _
        · exact pow_nonneg (by norm_num) _
        · exact pow_nonneg (by norm_num) _
      · le_refl 0 |>.symm ▸ le_refl 0
    · le_refl 0 |>.symm ▸ le_refl 0
