import Mathlib
import Workspace.Types.BinVec
import Workspace.Types.PartialDeletionProcess

example (n : ℕ) : ((n / 4 : ℕ) : ℤ) = (n / 4 : ℤ) := by
  push_cast
  ring

example (n : ℕ) (r : ℤ) (h : 0 ≤ r + (n / 4 : ℤ)) : 0 ≤ r + ((n / 4 : ℕ) : ℤ) := by
  have : ((n / 4 : ℕ) : ℤ) = (n / 4 : ℤ) := by push_cast; ring
  linarith

-- Test n/2 + n/2 ≤ n for ℕ
example (n : ℕ) : n / 2 + n / 2 ≤ n := by omega

-- The condition we need
example (n : ℕ) (r : ℤ) (j : Fin (n / 2))
    (hlo : 0 ≤ r + (n / 4 : ℤ))
    (hhi : r + (n / 4 : ℤ) ≤ (n / 2 : ℤ)) :
    ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) < (n : ℤ) := by
  have hjlt : ((j : ℕ) : ℤ) < ((n / 2 : ℕ) : ℤ) := by exact_mod_cast j.is_lt
  have hcast4 : ((n / 4 : ℕ) : ℤ) = (n / 4 : ℤ) := by push_cast; ring
  have hcast2 : ((n / 2 : ℕ) : ℤ) = (n / 2 : ℤ) := by push_cast; ring
  have hsum : (n / 2 : ℤ) + (n / 2 : ℤ) ≤ (n : ℤ) := by
    have : n / 2 + n / 2 ≤ n := by omega
    exact_mod_cast this
  linarith
