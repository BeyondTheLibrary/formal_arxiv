import Mathlib
import Workspace.Types.BinVec
import Workspace.Types.Trace
import Workspace.Types.DelProb
import Workspace.Types.PartialDeletionProcess
import Workspace.Types.LengthsOnlyProcess

open Workspace.Types.BinVec
open Workspace.Types.Trace
open Workspace.Types.DelProb
open Workspace.Types.DeletionChannel
open Workspace.Types.PartialDeletionProcess
open Workspace.Types.LengthsOnlyProcess

example (n : ℕ) (b : BinVec n) (m : Fin n → Bool) :
    (restrict b m).length = (Finset.univ.filter (fun i : Fin n => m i = true)).card := by
  unfold restrict
  rw [List.length_filterMap_eq_countP]
  -- Now (List.finRange n).countP ((fun i => if m i = true then some (b.bit i) else none) ·).isSome
  sorry

example (n : ℕ) (b : BinVec n) (m : Fin n → Bool) :
    (restrict b m).length ≤ n := by
  unfold restrict
  exact (List.length_filterMap_le _ _).trans (by simp)

-- Test: Two traces with same .bits are equal
example (n : ℕ) (t₁ t₂ : Trace n) (h : t₁.bits = t₂.bits) : t₁ = t₂ := by
  cases t₁; cases t₂; simp_all

-- Try via swap of tsum with finset sum
-- We use tsum_eq_sum' with the support:
-- The summand vanishes outside the (finite) image of a function on (Fin n → Bool).

-- Build an auxiliary function: from each μ (that's a valid prefix mask), produces a Trace.
-- For our proof, we need: ∑'_t f(t) = ∑_t∈S f(t) where S is the (finite) image.

-- Actually it's enough to use tsum_eq_sum.
-- support of (fun t => if t.bits.length = z then prefixWeight n b δ r t else 0)
-- ⊆ { t | ∃ μ, restrict b μ = t.bits ∧ isPrefixMask n r μ }
-- Each such t is determined by its bits, which equals restrict b μ for some μ.

-- Given decidableEq for Trace n is needed for the explicit Finset, build it.
example (n : ℕ) : DecidableEq (Trace n) := by
  intro t₁ t₂
  cases t₁ with | mk b₁ h₁ =>
  cases t₂ with | mk b₂ h₂ =>
  exact decidable_of_iff (b₁ = b₂) (by
    constructor
    · intro h; subst h; rfl
    · intro h; injection h)
