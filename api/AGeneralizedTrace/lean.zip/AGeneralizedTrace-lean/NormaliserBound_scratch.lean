import Mathlib
import Workspace.Types.AlternatingSumExpression

set_option maxHeartbeats 400000

-- Try to prove 2 * c' ≤ 1/32 where c' = 1 / (4 * e^2 * √(2π))
-- equivalent to 2 * e^2 * √(2π) ≥ 32

example : (2 : ℝ) * (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) ≤ 1 / 32 := by
  have he : (2.7182818283 : ℝ) < Real.exp 1 := Real.exp_one_gt_d9
  have hpi : (3.1415 : ℝ) < Real.pi := Real.pi_gt_d4
  have hexp2_lower : (7 : ℝ) < Real.exp 2 := by
    have h1 : Real.exp 2 = Real.exp 1 * Real.exp 1 := by
      rw [← Real.exp_add]; ring_nf
    rw [h1]
    nlinarith [he]
  have hexp2_pos : 0 < Real.exp 2 := Real.exp_pos 2
  have hpi2_pos : (0 : ℝ) < 2 * Real.pi := by positivity
  have hsqrt_pos : 0 < Real.sqrt (2 * Real.pi) := Real.sqrt_pos.mpr hpi2_pos
  have hsqrt_lower : (2.5 : ℝ) < Real.sqrt (2 * Real.pi) := by
    have : (2.5 : ℝ)^2 < 2 * Real.pi := by nlinarith [hpi]
    have h25 : (0 : ℝ) ≤ 2.5 := by norm_num
    have hrhs : (0 : ℝ) ≤ 2 * Real.pi := le_of_lt hpi2_pos
    have := Real.sqrt_lt_sqrt (by norm_num) this
    have hsq : Real.sqrt ((2.5 : ℝ)^2) = 2.5 := by
      rw [Real.sqrt_sq h25]
    linarith [this, hsq.symm.trans_le (le_of_lt this)]
  -- 4 * exp 2 * √(2π) > 4 * 7 * 2.5 = 70 > 64
  have h4e2sqrt_pos : 0 < 4 * Real.exp 2 * Real.sqrt (2 * Real.pi) := by positivity
  have h4e2sqrt : (64 : ℝ) < 4 * Real.exp 2 * Real.sqrt (2 * Real.pi) := by
    have : (4 : ℝ) * 7 * 2.5 = 70 := by norm_num
    nlinarith [hexp2_lower, hsqrt_lower, hexp2_pos, hsqrt_pos]
  -- Now want 2 / (4 * exp 2 * √(2π)) ≤ 1/32
  rw [mul_one_div, div_le_div_iff₀ h4e2sqrt_pos (by norm_num : (0:ℝ) < 32)]
  linarith
