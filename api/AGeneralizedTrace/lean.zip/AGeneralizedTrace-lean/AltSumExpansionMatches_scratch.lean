import Mathlib
import Workspace.Types.BinVec
import Workspace.Types.AlternatingSumExpression

open scoped BigOperators
open Workspace.Types.BinVec
open Workspace.Types.AlternatingSumExpression

-- Forward map: BinVec N -> Finset ℕ via support image
noncomputable def fwd (N : ℕ) (m : BinVec N) : Finset ℕ :=
  ((Finset.univ : Finset (Fin N)).filter (fun j => m.bit j = true)).image (fun j => j.val + 1)

-- Inverse: Finset ℕ -> BinVec N
noncomputable def bwd (N : ℕ) (ℓ : Finset ℕ) : BinVec N :=
  ⟨fun j => decide ((j.val + 1) ∈ ℓ)⟩

-- Step: bijection from BinVec N to powerset of (Icc 1 N)
example (N : ℕ) (f : Finset ℕ → ℝ) :
    ∑ m : BinVec N, f (fwd N m) = ∑ ℓ ∈ (Finset.Icc 1 N).powerset, f ℓ := by
  apply Finset.sum_nbij' (i := fun m => fwd N m) (j := fun ℓ => bwd N ℓ)
  · -- i sends s to t
    intro m _
    simp only [Finset.mem_powerset, fwd]
    intro x hx
    simp only [Finset.mem_image, Finset.mem_filter, Finset.mem_univ, true_and] at hx
    obtain ⟨j, _hj, rfl⟩ := hx
    simp only [Finset.mem_Icc]
    exact ⟨Nat.succ_le_succ (Nat.zero_le _), Nat.succ_le_of_lt j.isLt⟩
  · -- j sends t to s (anything is in univ)
    intro ℓ _
    exact Finset.mem_univ _
  · -- left inverse: bwd (fwd m) = m
    intro m _
    simp only [bwd, fwd]
    obtain ⟨bit⟩ := m
    congr 1
    funext j
    simp only [Finset.mem_image, Finset.mem_filter, Finset.mem_univ, true_and]
    by_cases h : bit j = true
    · rw [h]
      simp only [decide_eq_true_iff]
      exact ⟨j, h, rfl⟩
    · have h' : bit j = false := Bool.not_eq_true _ |>.mp h
      rw [h']
      simp only [decide_eq_false_iff_not, not_exists, not_and]
      intro k hk hkj
      have hkj' : k = j := Fin.ext (Nat.succ.inj hkj)
      rw [hkj'] at hk
      rw [hk] at h'
      exact Bool.true_eq_false_eq_False h'.symm
  · -- right inverse: fwd (bwd ℓ) = ℓ
    intro ℓ hℓ
    simp only [fwd, bwd, Finset.mem_powerset] at hℓ ⊢
    apply Finset.ext
    intro x
    simp only [Finset.mem_image, Finset.mem_filter, Finset.mem_univ, true_and,
      decide_eq_true_iff]
    constructor
    · rintro ⟨j, hjmem, rfl⟩
      exact hjmem
    · intro hx
      have hx' := hℓ hx
      simp only [Finset.mem_Icc] at hx'
      refine ⟨⟨x - 1, ?_⟩, ?_, ?_⟩
      · omega
      · simp only
        have : x - 1 + 1 = x := by omega
        rw [this]; exact hx
      · simp only
        omega
  · -- function values match
    intro m _
    rfl
