import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.DelProb
import Workspace.Types.BinVec
import Workspace.Types.Trace
import Workspace.Types.CoinFlipDist
import Workspace.Types.DeletionChannel
import Workspace.Types.TraceDist
import Workspace.Types.TVDistance
import Workspace.PriorWork.DataProcessingTV
import Workspace.ProofLemmas.TraceDeletionKernel
import Workspace.ProofLemmas.TVMonotoneInDelta
import Workspace.ProofLemmas.PartialDominatesBindForm
import Workspace.ProofLemmas.CoinFlipDistExists
import Workspace.ProofLemmas.DeletionChannelExists
import Workspace.ProofLemmas.DeletionSegmentFactorization
import Workspace.ProofLemmas.TraceDeletionListCompose
import Workspace.ProofLemmas.RestrictSegmentFactorization

/-!
# De-axiomatizing `pad_preserves_tv` (DPI route)

This file works toward replacing the axiom
`Workspace.Types.TraceDistAxioms.pad_preserves_tv` with a proved theorem
`pad_preserves_tv_thm` of a byte-identical signature.

## The mathematics (the route)

For `m ≤ n`, `Spad` zero-extends `S` (coordinate `i < m` equals `S.p i`, `i ≥ m`
equals `0`).  A zero coordinate of the input emits the bit `false` *deterministically*
under the coin-flip stage (the Bernoulli `true`-factor is `ENNReal.ofReal (S.p i) =
ENNReal.ofReal 0 = 0`).  Hence the padded coin-flip distribution concentrates on
binary vectors `b' ++ false^(n-m)`.

Running the rate-`δ` deletion channel on `fullTrace (b' ++ false^(n-m)) =
(fullTrace b') ++ false^(n-m)` factors as:

  * delete the first `m` positions (this reproduces the *unpadded* trace
    distribution `td_S.toPMF`), independently of
  * delete the trailing `false^(n-m)` block, which yields `false^z` with
    `z ~ Binomial(n-m, 1-δ)`, appended to the kept prefix.

This second factor is a Markov kernel `Z : Trace m → PMF (Trace n)` that is
**independent of `S`**: `Z t` is the law of "`t` with a deleted run of `n-m`
zeros appended".  Concretely, `Z t = (traceDelete δ on the all-false length
`n-m` trace) .map (append onto t.bits)`.

This gives the **forward bind identities**
    `td_pad.toPMF  = td_S.toPMF.bind Z`,
    `td_pad'.toPMF = td_S'.toPMF.bind Z`,
from which `Workspace.PriorWork.DataProcessingTV Z td_S.toPMF td_S'.toPMF`
gives directly the `≤` direction
    `TVDistance td_pad td_pad' ≤ TVDistance td_S td_S'`.

The `≥` direction (needed for the EQUALITY asserted by the axiom) is the
genuinely hard step.  There is NO inverse PMF kernel `W` with `Z ∘ W = id` on
generic PMFs (a trace `τ ++ 0^z` collides with `τ' ++ 0^{z'}` whenever
`τ ++ 0^z = τ' ++ 0^{z'}`, so trailing zeros cannot be unambiguously stripped).
Equality holds ONLY by *realizability*: `td_S, td_S'` are genuine length-`m`
trace distributions at the same `δ`, whose own output already has a
binomial-compatible trailing-zero structure, so the appended block does not
create new collisions that distinguish the two sides.  This is a research-grade
information-processing identity with no Mathlib support and is isolated below as
the single remaining `sorry` (`pad_tv_reverse`).

## What is proved sorry-free in this file

* `appendFalseTrace` / `Z` — the forward append-deleted-zeros kernel (a genuine
  `PMF`, total mass 1 by construction).
* `coinflip_tail_collapse` — for a zero-padded `Spad`, the coin-flip mass of any
  `b` with a `true` bit in the padded tail is `0`.
* The `≤` direction is reduced to the forward bind identity and `DataProcessingTV`.

The forward bind identity `pad_bind_identity` and the reverse inequality
`pad_tv_reverse` are the two combinatorial walls; each is isolated with a single
`sorry` and a precise statement of what remains.
-/

namespace PadPreservesTV

open Workspace.Types.ProbVec
open Workspace.Types.DelProb
open Workspace.Types.BinVec
open Workspace.Types.Trace
open Workspace.Types.CoinFlipDist
open Workspace.Types.DeletionChannel
open Workspace.Types.TraceDist
open Workspace.Types.TVDistance
open TraceDeletionKernel
open TVMonotoneInDelta
open DeletionSegmentFactorization
open TraceDeletionListCompose
open PartialDominatesBindForm

open scoped Classical

/-! ### The forward append-deleted-zeros kernel `Z` -/

/-- The all-false binary vector of length `k`. -/
def falseBinVec (k : ℕ) : BinVec k := ⟨fun _ => false⟩

/-- Embed a `Trace m` as a `Trace n` (for `m ≤ n`) by keeping its bits unchanged.
The length bound is preserved since `t.bits.length ≤ m ≤ n`. -/
def embedTrace {m n : ℕ} (h : m ≤ n) (t : Trace m) : Trace n :=
  ⟨t.bits, le_trans t.length_le h⟩

/-- Append a (deleted) trace `tail : Trace k` after the prefix `t : Trace m`,
producing a `Trace n` provided `m + k ≤ n` (so the concatenated length is `≤ n`). -/
def appendTrace {m k n : ℕ} (hmk : m + k ≤ n) (t : Trace m) (tail : Trace k) :
    Trace n :=
  ⟨t.bits ++ tail.bits, by
    have h1 : (t.bits ++ tail.bits).length = t.bits.length + tail.bits.length := by
      rw [List.length_append]
    rw [h1]
    have := t.length_le
    have := tail.length_le
    omega⟩

/-- **The forward kernel.**  For `m ≤ n`, `Z δ h t : PMF (Trace n)` appends to
`t` a deleted run of `n - m` zeros: it runs the rate-`δ` deletion channel on the
all-false trace of length `n - m` and appends the (all-false) survivor block to
`t`.  This kernel is independent of the underlying probability vector. -/
noncomputable def Z {m n : ℕ} (h : m ≤ n) (δ : DelProb) (t : Trace m) :
    PMF (Trace n) :=
  (traceDelete δ.val δ.pos.le δ.lt_one.le
      (fullTrace (falseBinVec (n - m)))).map
    (fun tail => appendTrace (by omega : m + (n - m) ≤ n) t tail)

/-! ### Coin-flip tail collapse for the padded distribution -/

/-- **Tail collapse.**  If `Spad : ProbVec n` is zero on every coordinate `i ≥ m`
(`hpad`), then any binary vector `b` whose bit at some padded coordinate `i ≥ m`
is `true` has coin-flip mass `0`: the Bernoulli `true`-factor there is
`ENNReal.ofReal (Spad.p i) = ENNReal.ofReal 0 = 0`, killing the whole product. -/
lemma coinflip_tail_collapse {n m : ℕ} (hnm : m ≤ n) {Spad : ProbVec n}
    (hpad : ∀ i : Fin n, m ≤ i.val → Spad.p i = 0)
    (cfd : CoinFlipDist n Spad) (b : BinVec n)
    (i : Fin n) (hi : m ≤ i.val) (hbit : b.bit i = true) :
    cfd.toPMF b = 0 := by
  rw [cfd.prod_factorisation b]
  apply Finset.prod_eq_zero (Finset.mem_univ i)
  rw [hbit]
  simp only [if_true]
  rw [hpad i hi]
  exact ENNReal.ofReal_zero

/-! ### Helper infrastructure for the forward bind identity -/

/-- The all-false `fullTrace` has bits equal to a `replicate`-block of `false`. -/
lemma fullTrace_falseBinVec_bits (k : ℕ) :
    (fullTrace (falseBinVec k)).bits = List.replicate k false := by
  rw [fullTrace_bits]
  exact List.ofFn_const k false

/-- The zero-extension of a binary vector `b' : BinVec m` to `BinVec n` (for `m ≤ n`):
keep the first `m` bits, set the rest to `false`. -/
def padVec {n m : ℕ} (hnm : m ≤ n) (b' : BinVec m) : BinVec n :=
  ⟨fun i => if h : i.val < m then b'.bit ⟨i.val, h⟩ else false⟩

@[simp] lemma padVec_bit_lt {n m : ℕ} (hnm : m ≤ n) (b' : BinVec m)
    (i : Fin n) (h : i.val < m) :
    (padVec hnm b').bit i = b'.bit ⟨i.val, h⟩ := by
  simp only [padVec, dif_pos h]

@[simp] lemma padVec_bit_ge {n m : ℕ} (hnm : m ≤ n) (b' : BinVec m)
    (i : Fin n) (h : m ≤ i.val) :
    (padVec hnm b').bit i = false := by
  simp only [padVec, dif_neg (not_lt.mpr h)]

/-- **Bits of the padded full trace split as a concatenation.**
`fullTrace (padVec b')` has bits `ofFn b'.bit ++ replicate (n-m) false`. -/
lemma padVec_fullTrace_bits {n m : ℕ} (hnm : m ≤ n) (b' : BinVec m) :
    (fullTrace (padVec hnm b')).bits
      = List.ofFn b'.bit ++ List.replicate (n - m) false := by
  rw [fullTrace_bits]
  apply List.ext_getElem
  · rw [List.length_ofFn, List.length_append, List.length_ofFn, List.length_replicate]
    omega
  · intro i h1 h2
    rw [List.length_ofFn] at h1
    rw [List.getElem_ofFn]
    by_cases hi : i < m
    · rw [List.getElem_append_left (by rw [List.length_ofFn]; exact hi)]
      rw [List.getElem_ofFn]
      rw [padVec_bit_lt hnm b' ⟨i, h1⟩ hi]
    · rw [List.getElem_append_right (by rw [List.length_ofFn]; omega)]
      rw [List.getElem_replicate]
      rw [padVec_bit_ge hnm b' ⟨i, h1⟩ (Nat.not_lt.mp hi)]

/-- **Coin-flip mass agreement.**  For a zero-padded `Spad` agreeing with `S` on the
first `m` coordinates, the padded coin-flip mass of `padVec b'` equals the unpadded
coin-flip mass of `b'`. -/
lemma padVec_coinflip {n m : ℕ} (hnm : m ≤ n)
    {S : ProbVec m} {Spad : ProbVec n}
    (hag : ∀ i : Fin m, Spad.p ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩ = S.p i)
    (hpad : ∀ i : Fin n, m ≤ i.val → Spad.p i = 0)
    (cfdpad : CoinFlipDist n Spad) (cfd_S : CoinFlipDist m S) (b' : BinVec m) :
    cfdpad.toPMF (padVec hnm b') = cfd_S.toPMF b' := by
  rw [cfdpad.prod_factorisation, cfd_S.prod_factorisation]
  -- Reindex the `Fin n` product through `Fin (m + (n - m))`.
  have hmn : m + (n - m) = n := by omega
  rw [← Equiv.prod_comp (finCongr hmn)
      (fun i : Fin n => ENNReal.ofReal
        (if (padVec hnm b').bit i then Spad.p i else 1 - Spad.p i))]
  rw [Fin.prod_univ_add]
  -- Tail block collapses to 1.
  have htail : (∏ i : Fin (n - m), ENNReal.ofReal
      (if (padVec hnm b').bit (finCongr hmn (Fin.natAdd m i)) then
          Spad.p (finCongr hmn (Fin.natAdd m i))
        else 1 - Spad.p (finCongr hmn (Fin.natAdd m i)))) = 1 := by
    apply Finset.prod_eq_one
    intro i _
    have hge : m ≤ (finCongr hmn (Fin.natAdd m i)).val := by
      simp [finCongr, Fin.natAdd]
    rw [padVec_bit_ge hnm b' _ hge]
    rw [if_neg (by simp)]
    rw [hpad _ hge]
    simp
  rw [htail, mul_one]
  -- Prefix block matches the unpadded product.
  apply Finset.prod_congr rfl
  intro i _
  have hlt : (finCongr hmn (Fin.castAdd (n - m) i)).val < m := by
    simp [finCongr, Fin.castAdd, Fin.castLE]
  rw [padVec_bit_lt hnm b' _ hlt]
  have hval : (finCongr hmn (Fin.castAdd (n - m) i)).val = i.val := by
    simp [finCongr, Fin.castAdd, Fin.castLE]
  have hSp : Spad.p (finCongr hmn (Fin.castAdd (n - m) i)) = S.p i := by
    have := hag i
    rw [← this]
    congr 1
  have hbit : (⟨(finCongr hmn (Fin.castAdd (n - m) i)).val, hlt⟩ : Fin m) = i := by
    apply Fin.ext; exact hval
  rw [hbit, hSp]

/-- `padVec` is injective. -/
lemma padVec_injective {n m : ℕ} (hnm : m ≤ n) :
    Function.Injective (padVec (n := n) (m := m) hnm) := by
  intro a b hab
  obtain ⟨fa⟩ := a
  obtain ⟨fb⟩ := b
  simp only [BinVec.mk.injEq]
  funext i
  have : (padVec hnm ⟨fa⟩).bit ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩
       = (padVec hnm ⟨fb⟩).bit ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩ := by rw [hab]
  rwa [padVec_bit_lt hnm ⟨fa⟩ _ i.isLt, padVec_bit_lt hnm ⟨fb⟩ _ i.isLt] at this

/-- If `b` is not in the range of `padVec`, it has a `true` bit at a padded coord. -/
lemma exists_true_of_not_mem_range {n m : ℕ} (hnm : m ≤ n) (b : BinVec n)
    (hb : b ∉ Set.range (padVec (n := n) (m := m) hnm)) :
    ∃ i : Fin n, m ≤ i.val ∧ b.bit i = true := by
  by_contra hcon
  push Not at hcon
  apply hb
  refine ⟨⟨fun i => b.bit ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩⟩, ?_⟩
  obtain ⟨fb⟩ := b
  simp only [padVec, BinVec.mk.injEq]
  funext i
  by_cases hi : i.val < m
  · rw [dif_pos hi]
  · rw [dif_neg hi]
    have := hcon i (Nat.not_lt.mp hi)
    simp only [Bool.not_eq_true] at this
    exact this.symm

/-- **Coin-flip support concentration.**  Summing any weight `F` against the padded
coin-flip distribution reduces to a sum over `padVec b'` weighted by the unpadded
coin-flip distribution: all non-padded vectors have zero padded coin-flip mass. -/
lemma coinflip_concentrated {n m : ℕ} (hnm : m ≤ n)
    {S : ProbVec m} {Spad : ProbVec n}
    (hag : ∀ i : Fin m, Spad.p ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩ = S.p i)
    (hpad : ∀ i : Fin n, m ≤ i.val → Spad.p i = 0)
    (cfdpad : CoinFlipDist n Spad) (cfd_S : CoinFlipDist m S)
    (F : BinVec n → ENNReal) :
    ∑' b : BinVec n, cfdpad.toPMF b * F b
      = ∑' b' : BinVec m, cfd_S.toPMF b' * F (padVec hnm b') := by
  rw [tsum_fintype, tsum_fintype]
  symm
  apply Fintype.sum_of_injective (padVec hnm) (padVec_injective hnm)
    (fun b' => cfd_S.toPMF b' * F (padVec hnm b'))
    (fun b => cfdpad.toPMF b * F b)
  · intro b hb
    obtain ⟨i, hi, hbit⟩ := exists_true_of_not_mem_range hnm b hb
    rw [coinflip_tail_collapse hnm hpad cfdpad b i hi hbit, zero_mul]
  · intro b'
    rw [padVec_coinflip hnm hag hpad cfdpad cfd_S b']

/-- **Mask-split for the padded full-trace deletion sum.**  The whole-string
keep-set sum over `Fin n → Bool` masks of the zero-padded vector `padVec hnm b'`
factors, for ANY observable `F` of the kept list, into the product of a prefix
mask sum (over `Fin m → Bool`, against `b'`) and a suffix mask sum (over
`Fin (n-m) → Bool`, against the all-false block `falseBinVec (n-m)`), with the
kept lists CONCATENATED inside `F`.  Spatial analogue of the temporal mask split;
proved by mirroring `RestrictSegmentFactorization.restrict_channel_sum_factor`'s
`Fin.appendEquiv` reindex, transported across `m + (n-m) = n`. -/
lemma traceDelete_padVec_mask_split {n m : ℕ} (hnm : m ≤ n) (δ : DelProb)
    (b' : BinVec m) (F : List Bool → ENNReal) :
    (∑ msk : Fin n → Bool,
        F (restrict (padVec hnm b') msk)
          * ∏ i, RestrictSegmentFactorization.wfac δ.val (msk i))
      = ∑ mskL : Fin m → Bool, ∑ mskR : Fin (n - m) → Bool,
          F (restrict b' mskL ++ restrict (falseBinVec (n - m)) mskR)
            * ((∏ i, RestrictSegmentFactorization.wfac δ.val (mskL i))
               * (∏ i, RestrictSegmentFactorization.wfac δ.val (mskR i))) := by
  have hmn : m + (n - m) = n := by omega
  let e : (Fin (m + (n - m)) → Bool) ≃ (Fin n → Bool) :=
    Equiv.arrowCongr (finCongr hmn) (Equiv.refl Bool)
  -- Reindex the outer `Fin n → Bool` mask sum across `m + (n-m) = n`.
  rw [← e.sum_comp
        (fun msk : Fin n → Bool =>
          F (restrict (padVec hnm b') msk)
            * ∏ i, RestrictSegmentFactorization.wfac δ.val (msk i))]
  -- The padded vector, viewed over `Fin (m + (n-m))`.
  set bb : BinVec (m + (n - m)) :=
    ⟨fun j => (padVec hnm b').bit (finCongr hmn j)⟩ with hbb
  -- Per-mask cast of the kept list and the weight product.
  have hres : ∀ (i : Fin (m + (n - m)) → Bool),
      restrict (padVec hnm b') (e i) = restrict bb i := by
    intro i
    rw [RestrictSegmentFactorization.restrict_eq_keepWith,
      RestrictSegmentFactorization.restrict_eq_keepWith]
    refine congr_arg₂ _ (List.ofFn_congr hmn.symm (padVec hnm b').bit) ?_
    rw [List.ofFn_congr hmn.symm (e i)]; congr 1
  have hprod : ∀ (i : Fin (m + (n - m)) → Bool),
      (∏ j : Fin n, RestrictSegmentFactorization.wfac δ.val (e i j))
        = ∏ k, RestrictSegmentFactorization.wfac δ.val (i k) := by
    intro i
    exact (finCongr hmn).symm.prod_comp
      (fun k => RestrictSegmentFactorization.wfac δ.val (i k))
  simp only [hres, hprod]
  -- Now the sum runs over `Fin (m + (n-m)) → Bool` against `bb`.  Mirror the
  -- `restrict_channel_sum_factor` reindex with `g = F` left un-factored.
  rw [← (Fin.appendEquiv (α := Bool) m (n - m)).sum_comp
        (fun msk => F (restrict bb msk)
          * ∏ k, RestrictSegmentFactorization.wfac δ.val (msk k))]
  rw [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro m₁ _
  apply Finset.sum_congr rfl
  intro m₂ _
  have happ : (Fin.appendEquiv (α := Bool) m (n - m)) (m₁, m₂)
      = Fin.append m₁ m₂ := by
    funext a; rw [Fin.appendEquiv_apply]
  rw [happ]
  rw [Fin.prod_univ_add (fun k => RestrictSegmentFactorization.wfac δ.val
        (Fin.append m₁ m₂ k))]
  -- Split `restrict bb (append m₁ m₂)` into prefix/suffix restrictions.
  have hsplit := RestrictSegmentFactorization.restrict_split
    (n₁ := m) (n₂ := n - m) bb (Fin.append m₁ m₂)
  simp only [Fin.append_left, Fin.append_right] at hsplit ⊢
  rw [hsplit]
  -- Identify the prefix vector with `b'` and the suffix vector with `falseBinVec`.
  have hpre : (⟨fun i => bb.bit (Fin.castAdd (n - m) i)⟩ : BinVec m) = b' := by
    apply congrArg BinVec.mk
    funext i
    show bb.bit (Fin.castAdd (n - m) i) = b'.bit i
    rw [hbb]
    show (padVec hnm b').bit (finCongr hmn (Fin.castAdd (n - m) i)) = b'.bit i
    rw [padVec_bit_lt hnm b' _ (by simp [i.isLt])]
    congr 1
  have hsuf : (⟨fun i => bb.bit (Fin.natAdd m i)⟩ : BinVec (n - m))
      = falseBinVec (n - m) := by
    apply congrArg BinVec.mk
    funext i
    show bb.bit (Fin.natAdd m i) = (falseBinVec (n - m)).bit i
    rw [hbb]
    show (padVec hnm b').bit (finCongr hmn (Fin.natAdd m i)) = false
    rw [padVec_bit_ge hnm b' _ (by simp)]
  rw [hpre, hsuf]

/-- **Spatial-split deletion factorization (the genuine combinatorial core).**
For a zero-extended binary vector `padVec b'`, running the rate-`δ` deletion
channel on its full trace equals: run the channel on the unpadded full trace
`fullTrace b'`, then push the result through the append-deleted-zeros kernel `Z`.

This is the spatial analogue of a temporal-composition law: `fullTrace (padVec b')`
has bits `ofFn b'.bit ++ replicate (n-m) false`, and the independent-bit deletion
of a concatenation factors (`keepWith_append`) into the concatenation of the two
block deletions.  The trailing-block deletion is exactly `Z`.  This factorization
is INDEPENDENT of any realizability assumption (it is pure combinatorics of the
deletion channel), unlike the reverse TV inequality `pad_tv_reverse`. -/
lemma traceDelete_padVec_factor {n m : ℕ} (hnm : m ≤ n) (δ : DelProb)
    (b' : BinVec m) :
    traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace (padVec hnm b'))
      = (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace b')).bind (Z hnm δ) := by
  apply PMF.ext
  intro τ
  -- LHS into restrict/wfac form, then mask-split.
  rw [traceDelete_fullTrace_restrict_form (padVec hnm b') δ τ]
  rw [traceDelete_padVec_mask_split hnm δ b'
        (fun l => if l = τ.bits then (1 : ENNReal) else 0)]
  -- Expand the RHS bind + map.
  rw [PMF.bind_apply]
  -- `Z` evaluated at `τ`, expanded via `PMF.map_apply`.
  have hZ : ∀ t : Trace m, (Z hnm δ t : Trace n → ENNReal) τ
      = ∑' tail : Trace (n - m),
          (if τ = appendTrace (by omega : m + (n - m) ≤ n) t tail then
              (traceDelete δ.val δ.pos.le δ.lt_one.le
                (fullTrace (falseBinVec (n - m))) : Trace (n - m) → ENNReal) tail
            else 0) := by
    intro t
    show ((traceDelete δ.val δ.pos.le δ.lt_one.le
        (fullTrace (falseBinVec (n - m)))).map
        (fun tail => appendTrace (by omega : m + (n - m) ≤ n) t tail)) τ = _
    rw [PMF.map_apply]
  -- Rewrite the bind summand using `hZ` and the restrict/wfac form of the prefix deletion.
  rw [tsum_congr (fun t => by
        rw [hZ t, traceDelete_fullTrace_restrict_form b' δ t])]
  -- Point-mass collapse helper: a `tsum` against a bit-list indicator pins the trace.
  have collapse : ∀ {k : ℕ} (l : List Bool) (hl : l.length ≤ k) (G : Trace k → ENNReal),
      (∑' t : Trace k, (if l = t.bits then (1 : ENNReal) else 0) * G t) = G ⟨l, hl⟩ := by
    intro k l hl G
    rw [tsum_eq_single ⟨l, hl⟩]
    · rw [if_pos rfl, one_mul]
    · intro t ht
      have : l ≠ t.bits := by
        intro h
        exact ht (by cases t; cases h; rfl)
      rw [if_neg this, zero_mul]
  -- Length bounds for building the pinned traces.
  have hlenL : ∀ mskL : Fin m → Bool, (restrict b' mskL).length ≤ m := by
    intro mskL
    unfold restrict
    exact (List.length_filterMap_le _ _).trans (by simp)
  have hlenR : ∀ mskR : Fin (n - m) → Bool,
      (restrict (falseBinVec (n - m)) mskR).length ≤ n - m := by
    intro mskR
    unfold restrict
    exact (List.length_filterMap_le _ _).trans (by simp)
  -- Abbreviate the tail-inner sum as `Inner t`.
  set Inner : Trace m → ENNReal := fun t =>
    ∑' tail : Trace (n - m),
      (if τ = appendTrace (by omega : m + (n - m) ≤ n) t tail then
          (traceDelete δ.val δ.pos.le δ.lt_one.le
            (fullTrace (falseBinVec (n - m))) : Trace (n - m) → ENNReal) tail
        else 0) with hInner
  -- Collapse the outer `∑' t` against the prefix-restrict indicator.
  have hcollapseT :
      (∑' t : Trace m,
          (∑ mskL : Fin m → Bool,
            (if restrict b' mskL = t.bits then (1 : ENNReal) else 0)
              * ∏ i, RestrictSegmentFactorization.wfac δ.val (mskL i)) * Inner t)
        = ∑ mskL : Fin m → Bool,
            (∏ i, RestrictSegmentFactorization.wfac δ.val (mskL i))
              * Inner ⟨restrict b' mskL, hlenL mskL⟩ := by
    rw [tsum_congr (fun t => Finset.sum_mul ..)]
    rw [Summable.tsum_finsetSum (fun mskL _ => ENNReal.summable)]
    apply Finset.sum_congr rfl
    intro mskL _
    have hreorder : ∀ t : Trace m,
        ((if restrict b' mskL = t.bits then (1 : ENNReal) else 0)
          * ∏ i, RestrictSegmentFactorization.wfac δ.val (mskL i)) * Inner t
        = (∏ i, RestrictSegmentFactorization.wfac δ.val (mskL i))
            * ((if restrict b' mskL = t.bits then (1 : ENNReal) else 0) * Inner t) := by
      intro t; ring
    rw [tsum_congr hreorder, ENNReal.tsum_mul_left,
      collapse (restrict b' mskL) (hlenL mskL) Inner]
  rw [hcollapseT]
  -- Expand `Inner` at the pinned prefix trace: collapse the tail `∑' tail` against
  -- the suffix-restrict indicator.
  have hInnerEq : ∀ mskL : Fin m → Bool,
      Inner ⟨restrict b' mskL, hlenL mskL⟩
        = ∑ mskR : Fin (n - m) → Bool,
            (if τ = appendTrace (by omega : m + (n - m) ≤ n)
                ⟨restrict b' mskL, hlenL mskL⟩ ⟨restrict (falseBinVec (n - m)) mskR, hlenR mskR⟩
              then (1 : ENNReal) else 0)
              * ∏ i, RestrictSegmentFactorization.wfac δ.val (mskR i) := by
    intro mskL
    rw [hInner]
    simp only
    -- Expand the inner deletion mass over the suffix block.
    rw [tsum_congr (fun tail => by
          rw [traceDelete_fullTrace_restrict_form (falseBinVec (n - m)) δ tail])]
    -- Distribute the `τ = append`-indicator into the `∑ mskR`, then swap sums.
    rw [tsum_congr (fun tail => Finset.ite_sum_zero _ _ _)]
    rw [Summable.tsum_finsetSum (fun mskR _ => ENNReal.summable)]
    apply Finset.sum_congr rfl
    intro mskR _
    -- Reshape each `tail`-term so the suffix-restrict indicator multiplies on the outside.
    have hreorder2 : ∀ tail : Trace (n - m),
        (if τ = appendTrace (by omega : m + (n - m) ≤ n) ⟨restrict b' mskL, hlenL mskL⟩ tail
            then (if restrict (falseBinVec (n - m)) mskR = tail.bits then (1 : ENNReal) else 0)
                  * ∏ i, RestrictSegmentFactorization.wfac δ.val (mskR i)
            else 0)
        = (if restrict (falseBinVec (n - m)) mskR = tail.bits then (1 : ENNReal) else 0)
            * ((∏ i, RestrictSegmentFactorization.wfac δ.val (mskR i))
                * (if τ = appendTrace (by omega : m + (n - m) ≤ n) ⟨restrict b' mskL, hlenL mskL⟩ tail
                    then (1 : ENNReal) else 0)) := by
      intro tail
      by_cases hr : restrict (falseBinVec (n - m)) mskR = tail.bits
      · simp only [hr, if_true, one_mul]
        by_cases hp : τ = appendTrace (by omega : m + (n - m) ≤ n) ⟨restrict b' mskL, hlenL mskL⟩ tail
        · simp only [hp, if_true, mul_one]
        · simp only [hp, if_false, mul_zero]
      · simp only [hr, if_false, zero_mul, ite_self]
    rw [tsum_congr hreorder2,
      collapse (restrict (falseBinVec (n - m)) mskR) (hlenR mskR)
        (fun tail => (∏ i, RestrictSegmentFactorization.wfac δ.val (mskR i))
          * (if τ = appendTrace (by omega : m + (n - m) ≤ n)
              ⟨restrict b' mskL, hlenL mskL⟩ tail then (1 : ENNReal) else 0))]
    ring
  -- Match the two double sums term by term.
  apply Finset.sum_congr rfl
  intro mskL _
  rw [hInnerEq mskL, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro mskR _
  -- The two keep-indicators agree: `appendTrace` concatenates the bit lists.
  have hind : (if restrict b' mskL ++ restrict (falseBinVec (n - m)) mskR = τ.bits
        then (1 : ENNReal) else 0)
      = (if τ = appendTrace (by omega : m + (n - m) ≤ n)
          ⟨restrict b' mskL, hlenL mskL⟩ ⟨restrict (falseBinVec (n - m)) mskR, hlenR mskR⟩
        then (1 : ENNReal) else 0) := by
    have hbits : (appendTrace (by omega : m + (n - m) ≤ n)
        ⟨restrict b' mskL, hlenL mskL⟩ ⟨restrict (falseBinVec (n - m)) mskR, hlenR mskR⟩).bits
        = restrict b' mskL ++ restrict (falseBinVec (n - m)) mskR := rfl
    by_cases h : restrict b' mskL ++ restrict (falseBinVec (n - m)) mskR = τ.bits
    · rw [if_pos h, if_pos]
      cases τ with
      | mk bits hlen =>
        simp only at h ⊢
        rw [hbits] at *
        subst h
        rfl
    · rw [if_neg h, if_neg]
      intro hcon
      exact h (by rw [← hbits, ← hcon])
  rw [hind]
  ring

/-! ### The forward bind identity (combinatorial wall #1) -/

/-- **Forward bind identity.**  The padded trace distribution equals the unpadded
one pushed through the append-deleted-zeros kernel `Z`.

This is the first combinatorial wall.  Its proof goes:

1. Canonicalise both sides via `traceDist_canonical` /
   `PartialDominatesBindForm.traceDist_toPMF_eq`, so
   `td_pad.toPMF τ = ∑' b, cfdpad b · traceDelete δ (fullTrace b) τ`.

2. By `coinflip_tail_collapse`, the sum collapses to `b = b' ++ false^(n-m)`,
   and by the agreement hypothesis `hag` the coin-flip mass of such `b` equals
   the unpadded coin-flip mass of `b'` (the tail factors are all
   `ofReal (1 - 0) = 1`).

3. `fullTrace (b' ++ false^(n-m)) = fullTrace b' ++ false^(n-m)`, and the
   rate-`δ` deletion of a concatenation factors as the convolution of the two
   independent block deletions (a `traceDelete`-over-concatenation lemma, the
   analogue of `TraceDeletionKernel.traceDelete_compose` but for a *spatial*
   split rather than a temporal one).  The trailing block deletes to `false^z`,
   giving exactly the kernel `Z`.

The spatial-split deletion factorization is the missing infrastructure (no
Mathlib support; the existing `TraceDeletionListCompose.master` handles temporal
composition, not a concatenation split).  Isolated as a single `sorry`. -/
lemma pad_bind_identity {n m : ℕ} (hnm : m ≤ n)
    {S : ProbVec m} {Spad : ProbVec n} {δ : DelProb}
    (hag : ∀ i : Fin m, Spad.p ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩ = S.p i)
    (hpad : ∀ i : Fin n, m ≤ i.val → Spad.p i = 0)
    (td_pad : TraceDist n Spad δ) (td_S : TraceDist m S δ) :
    td_pad.toPMF = td_S.toPMF.bind (Z hnm δ) := by
  -- Coin-flip witnesses for both the padded and unpadded distributions.
  let cfdpad : CoinFlipDist n Spad := (CoinFlipDistExists Spad).some
  let cfd_S : CoinFlipDist m S := (CoinFlipDistExists S).some
  apply PMF.ext
  intro τ
  -- LHS: canonicalise the padded trace distribution, then collapse the
  -- coin-flip support to padded vectors `padVec b'`.
  rw [traceDist_toPMF_eq td_pad cfdpad τ]
  rw [coinflip_concentrated hnm hag hpad cfdpad cfd_S
        (fun b => (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace b) : Trace n → ENNReal) τ)]
  -- Now LHS = ∑' b', cfd_S b' · traceDelete δ (fullTrace (padVec b')) τ.
  -- Apply the spatial-split factorization per b'.
  have hfac : ∀ b' : BinVec m,
      (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace (padVec hnm b')) : Trace n → ENNReal) τ
        = ∑' t : Trace m,
            (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace b') : Trace m → ENNReal) t
              * (Z hnm δ t : Trace n → ENNReal) τ := by
    intro b'
    rw [traceDelete_padVec_factor hnm δ b', PMF.bind_apply]
  -- RHS: expand the bind, then expand td_S via the same canonical form.
  rw [PMF.bind_apply]
  conv_rhs =>
    rw [show (fun t : Trace m => (td_S.toPMF t) * (Z hnm δ t : Trace n → ENNReal) τ)
          = (fun t : Trace m =>
              (∑' b' : BinVec m, cfd_S.toPMF b'
                * (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace b') : Trace m → ENNReal) t)
              * (Z hnm δ t : Trace n → ENNReal) τ)
        from funext (fun t => by rw [traceDist_toPMF_eq td_S cfd_S t])]
  -- Both sides are now double tsums; reduce by Fubini (ENNReal: unconditional).
  have hlhs : (∑' b' : BinVec m, cfd_S.toPMF b'
        * (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace (padVec hnm b')) : Trace n → ENNReal) τ)
      = ∑' b' : BinVec m, ∑' t : Trace m,
          cfd_S.toPMF b'
            * ((traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace b') : Trace m → ENNReal) t
              * (Z hnm δ t : Trace n → ENNReal) τ) := by
    apply tsum_congr
    intro b'
    rw [hfac b', ENNReal.tsum_mul_left]
  have hrhs : (∑' t : Trace m,
        (∑' b' : BinVec m, cfd_S.toPMF b'
          * (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace b') : Trace m → ENNReal) t)
          * (Z hnm δ t : Trace n → ENNReal) τ)
      = ∑' t : Trace m, ∑' b' : BinVec m,
          cfd_S.toPMF b'
            * ((traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace b') : Trace m → ENNReal) t
              * (Z hnm δ t : Trace n → ENNReal) τ) := by
    apply tsum_congr
    intro t
    rw [← ENNReal.tsum_mul_right]
    apply tsum_congr
    intro b'
    ring
  rw [hlhs, hrhs, ENNReal.tsum_comm]

/-! ### The ≤ direction (clean, from the forward bind identity + DPI) -/

/-- **`≤` direction.**  Granting the forward bind identities, the data-processing
inequality (`Workspace.PriorWork.DataProcessingTV`) for the shared kernel `Z`
gives that padding cannot increase the TV distance.  This step is sorry-free
*modulo* `pad_bind_identity`. -/
lemma pad_tv_le {n m : ℕ} (hnm : m ≤ n)
    {S S' : ProbVec m} {Spad Spad' : ProbVec n} {δ : DelProb}
    (hag : ∀ i : Fin m, Spad.p ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩ = S.p i)
    (hpad : ∀ i : Fin n, m ≤ i.val → Spad.p i = 0)
    (hag' : ∀ i : Fin m, Spad'.p ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩ = S'.p i)
    (hpad' : ∀ i : Fin n, m ≤ i.val → Spad'.p i = 0)
    (td_pad : TraceDist n Spad δ) (td_pad' : TraceDist n Spad' δ)
    (td_S : TraceDist m S δ) (td_S' : TraceDist m S' δ) :
    TVDistance td_pad.toPMF td_pad'.toPMF ≤ TVDistance td_S.toPMF td_S'.toPMF := by
  have hb : td_pad.toPMF = td_S.toPMF.bind (Z hnm δ) :=
    pad_bind_identity hnm hag hpad td_pad td_S
  have hb' : td_pad'.toPMF = td_S'.toPMF.bind (Z hnm δ) :=
    pad_bind_identity hnm hag' hpad' td_pad' td_S'
  have hdpi :=
    DataProcessingTV (α := Trace m) (β := Trace n) (Z hnm δ) td_S.toPMF td_S'.toPMF
  rw [TVDistance, TVDistance, hb, hb']
  exact hdpi

/-! ### The ≥ direction (combinatorial wall #2: realizability) -/

/-- **`≥` direction (realizability).**  This is the genuinely hard half of the
equality.  `DataProcessingTV` only gives `≤`; the reverse needs that the kernel
`Z` is *information-preserving on realizable inputs*.

Concretely: `td_S, td_S'` are genuine rate-`δ` length-`m` trace distributions, so
their outputs already carry a binomial-compatible trailing-zero law.  Appending a
fresh `Binomial(n-m, 1-δ)` run of zeros via `Z` does not merge any pair of
distinct realizable masses (a `τ ++ 0^z = τ' ++ 0^{z'}` collision between the two
sides can only occur with matching binomial weights, so the absolute differences
`|td_S τ - td_S' τ|` transfer term-by-term).  Hence the TV is preserved exactly
rather than merely non-increased.

There is NO inverse kernel realizing this (trailing zeros are ambiguous for
generic PMFs — the explicit counterexample is in `lean_knowledge.md`); the
argument is intrinsically a realizability statement about trace distributions and
has no Mathlib support.  Isolated as a single `sorry`. -/
lemma pad_tv_reverse {n m : ℕ} (hnm : m ≤ n)
    {S S' : ProbVec m} {Spad Spad' : ProbVec n} {δ : DelProb}
    (hag : ∀ i : Fin m, Spad.p ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩ = S.p i)
    (hpad : ∀ i : Fin n, m ≤ i.val → Spad.p i = 0)
    (hag' : ∀ i : Fin m, Spad'.p ⟨i.val, lt_of_lt_of_le i.isLt hnm⟩ = S'.p i)
    (hpad' : ∀ i : Fin n, m ≤ i.val → Spad'.p i = 0)
    (td_pad : TraceDist n Spad δ) (td_pad' : TraceDist n Spad' δ)
    (td_S : TraceDist m S δ) (td_S' : TraceDist m S' δ) :
    TVDistance td_S.toPMF td_S'.toPMF ≤ TVDistance td_pad.toPMF td_pad'.toPMF := by
  -- Realizability-based reverse data-processing inequality.  See docstring.
  sorry

/-! ### Main theorem -/

/-- **De-axiomatized `pad_preserves_tv`.**  Signature byte-identical to the axiom
`Workspace.Types.TraceDistAxioms.pad_preserves_tv` (modulo `axiom`→`theorem` and
the name).  Equality follows by antisymmetry from `pad_tv_le` and
`pad_tv_reverse`. -/
theorem pad_preserves_tv_thm :
    ∀ {n m : ℕ} (_hnm : m ≤ n)
      {S S' : ProbVec m} {Spad Spad' : ProbVec n}
      {δ : DelProb}
      (_h_S : ∀ i : Fin m, Spad.p ⟨i.val, lt_of_lt_of_le i.isLt _hnm⟩ = S.p i)
      (_h_pad : ∀ i : Fin n, m ≤ i.val → Spad.p i = 0)
      (_h_S' : ∀ i : Fin m, Spad'.p ⟨i.val, lt_of_lt_of_le i.isLt _hnm⟩ = S'.p i)
      (_h_pad' : ∀ i : Fin n, m ≤ i.val → Spad'.p i = 0)
      (td_pad : TraceDist n Spad δ) (td_pad' : TraceDist n Spad' δ)
      (td_S : TraceDist m S δ) (td_S' : TraceDist m S' δ),
    TVDistance td_pad.toPMF td_pad'.toPMF =
      TVDistance td_S.toPMF td_S'.toPMF := by
  intro n m hnm S S' Spad Spad' δ h_S h_pad h_S' h_pad' td_pad td_pad' td_S td_S'
  apply le_antisymm
  · exact pad_tv_le hnm h_S h_pad h_S' h_pad' td_pad td_pad' td_S td_S'
  · exact pad_tv_reverse hnm h_S h_pad h_S' h_pad' td_pad td_pad' td_S td_S'

end PadPreservesTV
