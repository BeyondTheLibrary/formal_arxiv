import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.LInfDistance
import Workspace.Types.L1Distance

/-!
# Padding-transfer building blocks (Front 4)

Sorry-free standalone real-analysis / `ProbVec` lemmas supporting a faithful
replacement of the patch axiom `lowerBoundWitness_pad`.  The paper only needs a
zero-padding reduction from `m ≡ 1 (mod 8)` to general `n` with `m ≤ n`; the
honest ingredients are:

* zero-padding a `ProbVec` (extend with zeros on fresh coordinates);
* ℓ¹ is unchanged by zero-padding (the new coordinates contribute `0`);
* ℓ∞ does not decrease under zero-padding (the original coordinates survive);
* `√n` / `√m` slack for `m ≤ n ≤ m + 7`, `m ≥ 10^12`.

Everything here compiles `sorry`-free.  No existing file is modified.
-/

namespace Workspace.ProofLemmas.PaddingTransfer

open Workspace.Types.ProbVec
open Workspace.Types.LInfDistance
open Workspace.Types.L1Distance

/-! ## Target 3 / 4 — pure real-arithmetic `√` slack -/

/-- Monotonicity of `√` along `ℕ`: `m ≤ n → √m ≤ √n`. -/
theorem sqrt_m_le_sqrt_n (m n : ℕ) (hmn : m ≤ n) :
    Real.sqrt (m : ℝ) ≤ Real.sqrt (n : ℝ) := by
  apply Real.sqrt_le_sqrt
  exact_mod_cast hmn

/-- The constant-rescaling slack the patch hand-waves: for `n ≤ m + 7` and
`m ≥ 10^12` we have `√n ≤ 2 √m`.  (The `2` is wildly generous; even `√n ≤ √m·(1+ε)`
holds, but `2` is all the reduction needs and is robust.) -/
theorem sqrt_n_le_two_sqrt_m (m n : ℕ) (hmn : n ≤ m + 7) (hm : 10 ^ 12 ≤ m) :
    Real.sqrt (n : ℝ) ≤ 2 * Real.sqrt (m : ℝ) := by
  rw [show (2 : ℝ) = Real.sqrt 4 by
    rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
  rw [← Real.sqrt_mul (by norm_num)]
  apply Real.sqrt_le_sqrt
  have hn : (n : ℝ) ≤ (m : ℝ) + 7 := by exact_mod_cast hmn
  have hm' : (10 : ℝ) ^ 12 ≤ (m : ℝ) := by exact_mod_cast hm
  nlinarith

/-- Constant-arithmetic fact a faithful padding reduction needs: a witness on the
`√m` scale survives onto the `√n` scale with half the constant.  Concretely, if
`c1 · √m ≤ X` and `m ≤ n` then `(c1 / 2) · √n ≤ X` would be FALSE in general
(√n could be huge); the correct direction is an UPPER-bound transfer.  For the
ℓ¹ upper bound `X ≤ cC1 · √m` with `√n ≤ 2 √m`, we get `X ≤ cC1 · √m ≤ cC1 · √n`
only when `√m ≤ √n` — which is exactly `sqrt_m_le_sqrt_n`.  This lemma packages
the genuinely useful slack: `cC1 · √m ≤ cC1 · √n` for `0 ≤ cC1`, `m ≤ n`. -/
theorem const_sqrt_mono (cC1 : ℝ) (hc : 0 ≤ cC1) (m n : ℕ) (hmn : m ≤ n) :
    cC1 * Real.sqrt (m : ℝ) ≤ cC1 * Real.sqrt (n : ℝ) := by
  apply mul_le_mul_of_nonneg_left _ hc
  exact sqrt_m_le_sqrt_n m n hmn

/-- Lower-bound transfer with the patch's constant-halving slack: if
`c1 · √m ≤ X` and `m ≤ n ≤ m + 7`, `m ≥ 10^12`, then `(c1 / 2) · √n ≤ X`.
Indeed `(c1/2)·√n ≤ (c1/2)·(2√m) = c1·√m ≤ X`.  This is the *faithful* version of
the constant rescaling the patch axiom hand-waves. -/
theorem lb_sqrt_transfer (c1 X : ℝ) (hc : 0 ≤ c1) (m n : ℕ)
    (_hmn_le : m ≤ n) (hmn : n ≤ m + 7) (hm : 10 ^ 12 ≤ m)
    (hlb : c1 * Real.sqrt (m : ℝ) ≤ X) :
    (c1 / 2) * Real.sqrt (n : ℝ) ≤ X := by
  have hstep : (c1 / 2) * Real.sqrt (n : ℝ) ≤ (c1 / 2) * (2 * Real.sqrt (m : ℝ)) := by
    apply mul_le_mul_of_nonneg_left (sqrt_n_le_two_sqrt_m m n hmn hm)
    linarith
  have heq : (c1 / 2) * (2 * Real.sqrt (m : ℝ)) = c1 * Real.sqrt (m : ℝ) := by ring
  linarith [hstep, heq.le, hlb]

/-! ## Target 2 — ℓ¹ is invariant under zero-padding -/

/-- Zero-pad a `ProbVec n` to length `n + k`: keep the first `n` coordinates,
set the fresh `k` coordinates to `0`. -/
def pad {n : ℕ} (S : ProbVec n) (k : ℕ) : ProbVec (n + k) where
  p := Fin.append S.p (fun _ : Fin k => (0 : ℝ))
  nonneg := by
    intro i
    refine Fin.addCases ?_ ?_ i
    · intro j; simp [Fin.append_left]; exact S.nonneg j
    · intro j; simp [Fin.append_right]
  le_one := by
    intro i
    refine Fin.addCases ?_ ?_ i
    · intro j; simp [Fin.append_left]; exact S.le_one j
    · intro j; simp [Fin.append_right]

/-- The padded vector agrees with the original on the embedded coordinates. -/
theorem pad_left {n : ℕ} (S : ProbVec n) (k : ℕ) (j : Fin n) :
    (pad S k).p (Fin.castAdd k j) = S.p j := by
  simp [pad, Fin.append_left]

/-- The padded vector is `0` on the fresh coordinates. -/
theorem pad_right {n : ℕ} (S : ProbVec n) (k : ℕ) (j : Fin k) :
    (pad S k).p (Fin.natAdd n j) = 0 := by
  simp [pad, Fin.append_right]

/-- ℓ¹ under zero-padding: padding with zeros adds nothing to the ℓ¹ distance. -/
theorem l1_pad {n : ℕ} (S S' : ProbVec n) (k : ℕ) :
    L1Distance (pad S k) (pad S' k) = L1Distance S S' := by
  unfold L1Distance
  rw [Fin.sum_univ_add]
  have hleft : ∀ j : Fin n,
      |(pad S k).p (Fin.castAdd k j) - (pad S' k).p (Fin.castAdd k j)|
        = |S.p j - S'.p j| := by
    intro j; rw [pad_left, pad_left]
  have hright : ∀ j : Fin k,
      |(pad S k).p (Fin.natAdd n j) - (pad S' k).p (Fin.natAdd n j)| = 0 := by
    intro j; rw [pad_right, pad_right]; simp
  rw [Finset.sum_congr rfl (fun j _ => hleft j),
      Finset.sum_congr rfl (fun j _ => hright j)]
  simp

/-! ## Target 1 — ℓ∞ does not decrease under zero-padding -/

/-- Every coordinate's separation is bounded by the ℓ∞ distance, for any
positive length `p`.  This is the `sup'` membership fact, packaged so it applies
to a length `n + 1 + k` that is not syntactically of the form `_ + 1`. -/
theorem coord_le_linf {p : ℕ} (A B : ProbVec p) (hp : 0 < p) (i : Fin p) :
    |A.p i - B.p i| ≤ LInfDistance A B := by
  obtain ⟨q, rfl⟩ : ∃ q, p = q + 1 := ⟨p - 1, by omega⟩
  exact Finset.le_sup' (fun i => |A.p i - B.p i|) (Finset.mem_univ i)

/-- A single original coordinate's separation lower-bounds the padded ℓ∞ distance.
Stated for `n + 1` so the padded length `n + 1 + k` is positive. -/
theorem linf_pad_ge_coord {n : ℕ} (S S' : ProbVec (n + 1)) (k : ℕ) (j : Fin (n + 1)) :
    |S.p j - S'.p j| ≤ LInfDistance (pad S k) (pad S' k) := by
  have hpos : 0 < n + 1 + k := by omega
  have hcoord : |(pad S k).p (Fin.castAdd k j) - (pad S' k).p (Fin.castAdd k j)|
      = |S.p j - S'.p j| := by rw [pad_left, pad_left]
  rw [← hcoord]
  exact coord_le_linf (pad S k) (pad S' k) hpos (Fin.castAdd k j)

/-- ℓ∞ does not decrease under zero-padding: the padded ℓ∞ distance is at least
the original ℓ∞ distance.  (The original `sup'` is over the embedded coordinates,
each of which is dominated by the padded `sup'`.) -/
theorem linf_pad_ge {n : ℕ} (S S' : ProbVec (n + 1)) (k : ℕ) :
    LInfDistance S S' ≤ LInfDistance (pad S k) (pad S' k) := by
  show (Finset.univ : Finset (Fin (n + 1))).sup'
      Finset.univ_nonempty (fun i => |S.p i - S'.p i|)
      ≤ LInfDistance (pad S k) (pad S' k)
  apply Finset.sup'_le
  intro j _
  exact linf_pad_ge_coord S S' k j

end Workspace.ProofLemmas.PaddingTransfer
