import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.LowerBoundConstants
import Workspace.Types.LowerBoundWitness
import Workspace.Types.DelProb
import Workspace.Types.TraceDist
import Workspace.Types.TVDistance
import Workspace.ProofLemmas.OddPaddingWitness

/--
`SublemmaOddPaddingReduction` states the zero-padding reduction from the paper:
if there exist constants `c_δ, c_∞, c_1, C_1, c_tv > 0` and a threshold
`\tilde n_0` such that the conclusion of the main theorem (existence of
length-`m` witnesses) holds for every `m ≥ \tilde n_0` with `m ≡ 1 (mod 8)`,
then the same conclusion holds for every `n ≥ \tilde n_0 + 7` with possibly
slightly different constants (each expressible as a constant multiple of the
original constants), via the zero-padding construction.

Concretely: given `Cmod : LowerBoundConstants` for which length-`m` witnesses
exist whenever `Cmod.n0 ≤ m` and `m % 8 = 1`, this lemma produces a (possibly
different) constants bundle `Cfull : LowerBoundConstants` for which length-`n`
witnesses exist for every `Cfull.n0 ≤ n` (with no parity restriction on `n`).
-/
theorem SublemmaOddPaddingReduction :
    ∀ (Cmod : Workspace.Types.LowerBoundConstants.LowerBoundConstants),
      (∀ (m : ℕ), Cmod.n0 ≤ m → m % 8 = 1 →
         Nonempty (Workspace.Types.LowerBoundWitness.LowerBoundWitness Cmod m)) →
      ∃ (Cfull : Workspace.Types.LowerBoundConstants.LowerBoundConstants),
        ∀ (n : ℕ), Cfull.n0 ≤ n →
          Nonempty (Workspace.Types.LowerBoundWitness.LowerBoundWitness Cfull n) := by
  exact Workspace.ProofLemmas.OddPaddingWitness.lowerBoundWitness_pad_thm
