import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.DelProb
import Workspace.Types.TraceDist
import Workspace.Types.TVDistance
import Workspace.Types.LInfDistance
import Workspace.Types.L1Distance
import Workspace.Types.LowerBoundConstants
import Workspace.Types.LowerBoundWitness
import Workspace.Types.TraceDistAxioms
import Workspace.ProofLemmas.PaddingTransfer
import Workspace.ProofLemmas.TraceDistExists

open Workspace.Types.ProbVec
open Workspace.Types.DelProb
open Workspace.Types.TraceDist
open Workspace.Types.TVDistance
open Workspace.Types.LInfDistance
open Workspace.Types.L1Distance
open Workspace.Types.LowerBoundConstants
open Workspace.Types.LowerBoundWitness

namespace Workspace.ProofLemmas.OddPaddingWitness

/-- Direct zero-padding of a `ProbVec m` to `ProbVec n` (for `m ≤ n`):
keep coordinate `i` if `i < m`, set it to `0` otherwise. -/
def padTo (m n : ℕ) (h : m ≤ n) (S : ProbVec m) : ProbVec n where
  p := fun i => if h2 : i.val < m then S.p ⟨i.val, h2⟩ else 0
  nonneg := by
    intro i
    by_cases h2 : i.val < m
    · simp only [h2, dif_pos]; exact S.nonneg _
    · simp only [h2, dif_neg, not_false_iff]; rfl
  le_one := by
    intro i
    by_cases h2 : i.val < m
    · simp only [h2, dif_pos]; exact S.le_one _
    · simp only [h2, dif_neg, not_false_iff]; norm_num

/-- On embedded coordinates the padded vector agrees with the original. -/
theorem padTo_agree (m n : ℕ) (h : m ≤ n) (S : ProbVec m) (i : Fin m) :
    (padTo m n h S).p ⟨i.val, lt_of_lt_of_le i.isLt h⟩ = S.p i := by
  simp only [padTo]
  rw [dif_pos i.isLt]

/-- On fresh coordinates the padded vector is `0`. -/
theorem padTo_zero (m n : ℕ) (h : m ≤ n) (S : ProbVec m) (i : Fin n) (hi : m ≤ i.val) :
    (padTo m n h S).p i = 0 := by
  simp only [padTo]
  rw [dif_neg (by omega)]

/-- The padded coordinate as a function of the raw index `j : ℕ`. -/
theorem padTo_coord (m n : ℕ) (h : m ≤ n) (S : ProbVec m) (i : Fin n) :
    (padTo m n h S).p i = if h2 : i.val < m then S.p ⟨i.val, h2⟩ else 0 := rfl

/-- ℓ¹ distance is invariant under direct zero-padding. -/
theorem l1_padTo (m n : ℕ) (h : m ≤ n) (S S' : ProbVec m) :
    L1Distance (padTo m n h S) (padTo m n h S') = L1Distance S S' := by
  unfold L1Distance
  -- Define the ℕ-indexed summand.
  set g : ℕ → ℝ :=
    fun j => |(if h2 : j < m then S.p ⟨j, h2⟩ else 0) - (if h2 : j < m then S'.p ⟨j, h2⟩ else 0)|
    with hg
  -- LHS: Fin n sum equals range n sum of g.
  have hLHS : (∑ i : Fin n, |(padTo m n h S).p i - (padTo m n h S').p i|)
      = ∑ j ∈ Finset.range n, g j := by
    rw [← Fin.sum_univ_eq_sum_range g n]
    apply Finset.sum_congr rfl
    intro i _
    simp only [hg, padTo_coord]
  -- RHS: Fin m sum equals range m sum of g.
  have hRHS : (∑ i : Fin m, |S.p i - S'.p i|) = ∑ j ∈ Finset.range m, g j := by
    rw [← Fin.sum_univ_eq_sum_range g m]
    apply Finset.sum_congr rfl
    intro i _
    simp only [hg, dif_pos i.isLt]
  -- Tail of range n (i.e. [m, n)) contributes 0.
  have htail : (∑ j ∈ Finset.range n, g j) = ∑ j ∈ Finset.range m, g j := by
    symm
    apply Finset.sum_subset (Finset.range_subset_range.mpr h)
    intro j _ hjm
    rw [Finset.mem_range, not_lt] at hjm
    simp only [hg, dif_neg (by omega : ¬ j < m), sub_zero, abs_zero]
  rw [hLHS, hRHS, htail]

/-- ℓ∞ distance does not decrease under direct zero-padding (for positive `m`). -/
theorem linf_padTo_ge (m n : ℕ) (h : m ≤ n) (hm : 0 < m) (S S' : ProbVec m) :
    LInfDistance S S' ≤ LInfDistance (padTo m n h S) (padTo m n h S') := by
  obtain ⟨q, rfl⟩ : ∃ q, m = q + 1 := ⟨m - 1, by omega⟩
  have hn : 0 < n := by omega
  -- Original sup' is bounded by padded sup' since each coord embeds.
  show (Finset.univ : Finset (Fin (q + 1))).sup'
      Finset.univ_nonempty (fun i => |S.p i - S'.p i|)
      ≤ LInfDistance (padTo (q + 1) n h S) (padTo (q + 1) n h S')
  apply Finset.sup'_le
  intro j _
  -- |S.p j - S'.p j| equals the padded coord at the embedded index.
  have hagS := padTo_agree (q + 1) n h S j
  have hagS' := padTo_agree (q + 1) n h S' j
  rw [← hagS, ← hagS']
  exact Workspace.ProofLemmas.PaddingTransfer.coord_le_linf
    (padTo (q + 1) n h S) (padTo (q + 1) n h S') hn
    ⟨j.val, lt_of_lt_of_le j.isLt h⟩

open Workspace.Types.LowerBoundConstants in
/-- Faithful replacement of the `lowerBoundWitness_pad` axiom. -/
theorem lowerBoundWitness_pad_thm :
    ∀ (Cmod : Workspace.Types.LowerBoundConstants.LowerBoundConstants),
      (∀ (m : ℕ), Cmod.n0 ≤ m → m % 8 = 1 →
         Nonempty (Workspace.Types.LowerBoundWitness.LowerBoundWitness Cmod m)) →
      ∃ (Cfull : Workspace.Types.LowerBoundConstants.LowerBoundConstants),
        ∀ (n : ℕ), Cfull.n0 ≤ n →
          Nonempty (Workspace.Types.LowerBoundWitness.LowerBoundWitness Cfull n) := by
  intro Cmod hwit
  refine ⟨{
    cDelta := 2 * Cmod.cDelta
    cInf := Cmod.cInf
    c1 := Cmod.c1 / 2
    cC1 := 2 * Cmod.cC1
    cTv := Cmod.cTv / 2
    n0 := max Cmod.n0 (10 ^ 12) + 7
    cDelta_pos := by have := Cmod.cDelta_pos; linarith
    cInf_pos := Cmod.cInf_pos
    c1_pos := by have := Cmod.c1_pos; linarith
    cC1_pos := by have := Cmod.cC1_pos; linarith
    cTv_pos := by have := Cmod.cTv_pos; linarith
    c1_le_cC1 := by
      nlinarith [Cmod.c1_pos, Cmod.cC1_pos, Cmod.c1_le_cC1]
  }, ?_⟩
  intro n hn
  -- hn : max Cmod.n0 (10^12) + 7 ≤ n
  simp only at hn
  -- choose m ≡ 1 (mod 8), m ≤ n, n - m ≤ 7, m ≥ Cmod.n0, m ≥ 10^12
  set m : ℕ := n - ((n + 7) % 8) with hm_def
  have hm_mod1 : m % 8 = 1 := by simp only [hm_def]; omega
  have hnm7 : n ≤ m + 7 := by simp only [hm_def]; omega
  have hmn : m ≤ n := by simp only [hm_def]; omega
  have hm_n0 : Cmod.n0 ≤ m := by simp only [hm_def]; omega
  have hm_big : (10 : ℕ) ^ 12 ≤ m := by simp only [hm_def]; omega
  have hm_pos : 0 < m := by omega
  have hn_pos : 0 < n := by omega
  -- obtain the modular witness
  obtain ⟨W⟩ := hwit m hm_n0 hm_mod1
  -- sqrt positivity facts
  have hsqm_pos : 0 < Real.sqrt (m : ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast hm_pos)
  have hsqn_pos : 0 < Real.sqrt (n : ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast hn_pos)
  -- the padded probability vectors
  set Sp : ProbVec n := padTo m n hmn W.S with hSp
  set Sp' : ProbVec n := padTo m n hmn W.S' with hSp'
  -- agreement / zero lemmas for the TV transfer
  have hagS : ∀ i : Fin m, Sp.p ⟨i.val, lt_of_lt_of_le i.isLt hmn⟩ = W.S.p i := by
    intro i; simp only [hSp]; exact padTo_agree m n hmn W.S i
  have hzS : ∀ i : Fin n, m ≤ i.val → Sp.p i = 0 := by
    intro i hi; simp only [hSp]; exact padTo_zero m n hmn W.S i hi
  have hagS' : ∀ i : Fin m, Sp'.p ⟨i.val, lt_of_lt_of_le i.isLt hmn⟩ = W.S'.p i := by
    intro i; simp only [hSp']; exact padTo_agree m n hmn W.S' i
  have hzS' : ∀ i : Fin n, m ≤ i.val → Sp'.p i = 0 := by
    intro i hi; simp only [hSp']; exact padTo_zero m n hmn W.S' i hi
  -- L1 transfer equality
  have hL1 : L1Distance Sp Sp' = L1Distance W.S W.S' := by
    simp only [hSp, hSp']; exact l1_padTo m n hmn W.S W.S'
  refine ⟨{
    S := Sp
    S' := Sp'
    n_ge_n0 := by simp only; omega
    linf_sep := ?_
    l1_lb := ?_
    l1_ub := ?_
    tv_decay := ?_
  }⟩
  · -- linf_sep : Cmod.cInf ≤ LInfDistance Sp Sp'
    simp only
    calc Cmod.cInf ≤ LInfDistance W.S W.S' := W.linf_sep
      _ ≤ LInfDistance Sp Sp' := by
          simp only [hSp, hSp']; exact linf_padTo_ge m n hmn hm_pos W.S W.S'
  · -- l1_lb : (Cmod.c1 / 2) * √n ≤ L1Distance Sp Sp'
    simp only
    rw [hL1]
    exact Workspace.ProofLemmas.PaddingTransfer.lb_sqrt_transfer
      Cmod.c1 (L1Distance W.S W.S') (le_of_lt Cmod.c1_pos) m n hmn hnm7 hm_big W.l1_lb
  · -- l1_ub : L1Distance Sp Sp' ≤ (2 * Cmod.cC1) * √n
    simp only
    rw [hL1]
    have h1 : L1Distance W.S W.S' ≤ Cmod.cC1 * Real.sqrt (m : ℝ) := W.l1_ub
    have h2 : Cmod.cC1 * Real.sqrt (m : ℝ) ≤ Cmod.cC1 * Real.sqrt (n : ℝ) :=
      Workspace.ProofLemmas.PaddingTransfer.const_sqrt_mono
        Cmod.cC1 (le_of_lt Cmod.cC1_pos) m n hmn
    have h3 : Cmod.cC1 * Real.sqrt (n : ℝ) ≤ 2 * Cmod.cC1 * Real.sqrt (n : ℝ) := by
      nlinarith [Cmod.cC1_pos, hsqn_pos]
    linarith
  · -- tv_decay
    intro δ hδ td1 td2
    simp only at hδ ⊢
    -- hδ : (2 * Cmod.cDelta) / √n ≤ δ.val
    -- need: TVDistance td1.toPMF td2.toPMF ≤ exp (-(Cmod.cTv/2) * √n)
    -- √n ≤ 2 √m
    have hsqrt_nm : Real.sqrt (n : ℝ) ≤ 2 * Real.sqrt (m : ℝ) :=
      Workspace.ProofLemmas.PaddingTransfer.sqrt_n_le_two_sqrt_m m n hnm7 hm_big
    -- derive the cDelta bound for W: Cmod.cDelta / √m ≤ δ.val
    have hδ_W : Cmod.cDelta / Real.sqrt (m : ℝ) ≤ δ.val := by
      have hstep : Cmod.cDelta / Real.sqrt (m : ℝ)
          ≤ (2 * Cmod.cDelta) / Real.sqrt (n : ℝ) := by
        rw [div_le_div_iff₀ hsqm_pos hsqn_pos]
        nlinarith [Cmod.cDelta_pos, hsqrt_nm, hsqm_pos, hsqn_pos]
      linarith
    -- manufacture trace distributions on W.S, W.S'
    obtain ⟨tdS⟩ := traceDist_exists W.S δ
    obtain ⟨tdS'⟩ := traceDist_exists W.S' δ
    -- pad_preserves_tv: equate the padded TV with the unpadded TV
    have htv : Workspace.Types.TVDistance.TVDistance td1.toPMF td2.toPMF
        = Workspace.Types.TVDistance.TVDistance tdS.toPMF tdS'.toPMF := by
      exact Workspace.Types.TraceDistAxioms.pad_preserves_tv hmn
        hagS hzS hagS' hzS' td1 td2 tdS tdS'
    rw [htv]
    -- decay bound on the unpadded side
    have hdecay : Workspace.Types.TVDistance.TVDistance tdS.toPMF tdS'.toPMF
        ≤ Real.exp (-Cmod.cTv * Real.sqrt (m : ℝ)) :=
      W.tv_decay δ hδ_W tdS tdS'
    -- exp(-cTv √m) ≤ exp(-(cTv/2) √n)
    have hexp : Real.exp (-Cmod.cTv * Real.sqrt (m : ℝ))
        ≤ Real.exp (-(Cmod.cTv / 2) * Real.sqrt (n : ℝ)) := by
      apply Real.exp_le_exp.mpr
      nlinarith [hsqrt_nm, Cmod.cTv_pos, Real.sqrt_nonneg (m : ℝ)]
    linarith

end Workspace.ProofLemmas.OddPaddingWitness
