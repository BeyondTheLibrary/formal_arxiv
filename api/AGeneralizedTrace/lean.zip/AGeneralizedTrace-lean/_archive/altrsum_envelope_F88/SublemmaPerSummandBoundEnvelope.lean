import Mathlib
import Workspace.Types.AlternatingSumExpression
import Workspace.PriorWork.AltRSumEnvelopeBound

namespace Workspace.ProofLemmas

set_option maxHeartbeats 8000000

/-- Typical-z envelope per-summand bound: a direct restatement of the (now sound,
typical-z-restricted) §3.1 inner bound `AltRSumEnvelopeBound`. The RHS carries the faithful
polynomial prefactor `polyN n δ` (F27 soundness fix). -/
theorem SublemmaPerSummandBoundEnvelope :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
      ∀ (δ : ℝ), (320 : ℝ) / Real.sqrt n ≤ δ → δ ≤ 1 / 2 →
      let c' : ℝ := 1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))
      let α : ℝ := (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n
      let n_h : ℕ := n / 2
      let envelopeW : Finset ℕ → ℝ := fun ℓ =>
        ∑ r ∈ Finset.Icc (-((n : ℤ) / 4)) ((n : ℤ) / 4),
          ∏ j ∈ ℓ,
            Workspace.Types.AlternatingSumExpression.ellFactor n α r j
      ∀ (ℓ : Finset ℕ), ℓ ⊆ Finset.Icc 1 n_h →
      Workspace.Types.AlternatingSumExpression.sameParity ℓ →
        (∑ zMinus ∈ Finset.Ico (n / 16) (n_h + 1),
          ∑ zPlus ∈ Finset.Ico (n / 16) (n_h + 1),
            |Workspace.Types.AlternatingSumExpression.altRSum n δ α
              zMinus zPlus ℓ|)
          ≤ 2 * polyN n δ * envelopeW ℓ * Real.exp (-Real.sqrt n) := by
  exact AltRSumEnvelopeBound

end Workspace.ProofLemmas
