import Mathlib
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.SublemmaPerSummandBoundEnvelope
import Workspace.ProofLemmas.LightEnvelopeBound
import Workspace.PriorWork.AltRSumLightAtypicalBound

set_option maxHeartbeats 4000000

open Classical

theorem LightContributionBound :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
    ∀ (δ : ℝ), (320 : ℝ) / Real.sqrt n ≤ δ → δ ≤ 1 / 2 →
      let c' : ℝ := 1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))
      let α : ℝ := (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n
      let n_h : ℕ := n / 2
      let S_er : ℤ → ℕ → ℝ := fun r j =>
        ((1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n) *
          Workspace.Types.AlternatingSumExpression.binPMFInt n (1/2)
            (r + ((n : ℤ) / 4) + (j : ℤ))
      let widetildeMu_er : ℤ → Finset ℕ → ℝ := fun r x =>
        ∏ j ∈ Finset.Icc 1 (n / 2),
          (if j ∈ x then S_er r j else (1 - S_er r j))
      let P_L : Finset (Finset ℕ) :=
        ((Finset.Icc 1 n_h).powerset).filter (fun ℓ =>
          Workspace.Types.AlternatingSumExpression.sameParity ℓ ∧
          ∀ r ∈ Finset.Icc (-((n : ℤ) / 4)) ((n : ℤ) / 4),
            widetildeMu_er r ℓ < Real.exp (-(Real.sqrt n / 2)))
      ∑ ℓ ∈ P_L,
          ∑ zMinus ∈ Finset.range (n / 2 + 1),
            ∑ zPlus ∈ Finset.range (n / 2 + 1),
              |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|
        ≤ (1 : ℝ) / 8 * Real.exp (-(Real.sqrt n / 4)) := by
  intro n hn hmod δ hδ_lb hδ_ub
  -- Unfold all let-bindings
  simp only
  set c' : ℝ := 1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi)) with hc'_def
  set α : ℝ := c' * Real.sqrt n with hα_def
  set n_h : ℕ := n / 2 with hn_h_def
  -- Define the helpers
  set S_er : ℤ → ℕ → ℝ := fun r j =>
        α * Workspace.Types.AlternatingSumExpression.binPMFInt n (1/2)
            (r + ((n : ℤ) / 4) + (j : ℤ)) with hS_er_def
  set widetildeMu_er : ℤ → Finset ℕ → ℝ := fun r x =>
        ∏ j ∈ Finset.Icc 1 (n / 2),
          (if j ∈ x then S_er r j else (1 - S_er r j)) with hwidetildeMu_def
  set envelopeW : Finset ℕ → ℝ := fun ℓ =>
        ∑ r ∈ Finset.Icc (-((n : ℤ) / 4)) ((n : ℤ) / 4),
          ∏ j ∈ ℓ,
            Workspace.Types.AlternatingSumExpression.ellFactor n α r j with henvelopeW_def
  set P_L : Finset (Finset ℕ) :=
        ((Finset.Icc 1 n_h).powerset).filter (fun ℓ =>
          Workspace.Types.AlternatingSumExpression.sameParity ℓ ∧
          ∀ r ∈ Finset.Icc (-((n : ℤ) / 4)) ((n : ℤ) / 4),
            widetildeMu_er r ℓ < Real.exp (-(Real.sqrt n / 2))) with hP_L_def
  -- positivity facts
  have h_sqrt_n_nonneg : 0 ≤ Real.sqrt n := Real.sqrt_nonneg _
  have h_n_pos : (0 : ℝ) < n := by
    have h1 : (10 ^ 12 : ℕ) ≤ n := hn
    have h2 : (0 : ℕ) < n := Nat.lt_of_lt_of_le (by norm_num : (0 : ℕ) < 10 ^ 12) h1
    exact_mod_cast h2
  have hn_ge : (10 ^ 12 : ℝ) ≤ n := by exact_mod_cast hn
  have h_sqrt_n_ge : (10 ^ 6 : ℝ) ≤ Real.sqrt n := by
    have h_sq : (10 ^ 6 : ℝ) ^ 2 ≤ (n : ℝ) := by
      have : ((10 : ℝ) ^ 6) ^ 2 = 10 ^ 12 := by ring
      rw [this]; exact hn_ge
    have h_pos : (0 : ℝ) ≤ 10 ^ 6 := by norm_num
    calc (10 ^ 6 : ℝ) = Real.sqrt ((10 ^ 6) ^ 2) := by
            rw [Real.sqrt_sq h_pos]
      _ ≤ Real.sqrt n := Real.sqrt_le_sqrt h_sq
  -- n/16 ≤ n/2+1 (for the inner Ico-split).
  have h_n16_le : n / 16 ≤ n / 2 + 1 := by
    have h1 : n / 16 ≤ n / 2 := Nat.div_le_div_left (by norm_num) (by norm_num)
    omega
  -- Per-ℓ rebracketing of the full inner z-double-sum into typical + atypical.
  -- Exactly mirrors AltSumThreeWayDecomposition's h_inner_split.
  have h_inner_decomp : ∀ ℓ : Finset ℕ,
      (∑ zMinus ∈ Finset.range (n / 2 + 1),
          ∑ zPlus ∈ Finset.range (n / 2 + 1),
            |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
        = (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
              ∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
          +
          ((∑ zMinus ∈ Finset.range (n / 16),
              ∑ zPlus ∈ Finset.range (n / 2 + 1),
                |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
            +
           (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
              ∑ zPlus ∈ Finset.range (n / 16),
                |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)) := by
    intro ℓ
    simp only [Finset.range_eq_Ico]
    rw [← Finset.sum_Ico_consecutive (fun zMinus =>
          ∑ zPlus ∈ Finset.Ico 0 (n / 2 + 1),
            |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
          (Nat.zero_le _) h_n16_le]
    have h_inner_split :
        (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
            ∑ zPlus ∈ Finset.Ico 0 (n / 2 + 1),
              |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
          = (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                ∑ zPlus ∈ Finset.Ico 0 (n / 16),
                  |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
            + (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                ∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                  |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|) := by
      rw [← Finset.sum_add_distrib]
      apply Finset.sum_congr rfl
      intro zMinus _
      rw [← Finset.sum_Ico_consecutive (fun zPlus =>
            |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
            (Nat.zero_le _) h_n16_le]
    rw [h_inner_split]
    ring
  -- Sum the rebracketing over ℓ ∈ P_L:
  -- T_III = (∑_ℓ typical) + (∑_ℓ atypical).
  have h_split_sum :
      (∑ ℓ ∈ P_L,
          ∑ zMinus ∈ Finset.range (n / 2 + 1),
            ∑ zPlus ∈ Finset.range (n / 2 + 1),
              |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
        = (∑ ℓ ∈ P_L,
              ∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                ∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                  |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
          + (∑ ℓ ∈ P_L,
              ((∑ zMinus ∈ Finset.range (n / 16),
                  ∑ zPlus ∈ Finset.range (n / 2 + 1),
                    |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
                +
               (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                  ∑ zPlus ∈ Finset.range (n / 16),
                    |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|))) := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro ℓ _
    exact h_inner_decomp ℓ
  rw [h_split_sum]
  -- ===== TYPICAL PART =====
  -- Step 1: Apply SublemmaPerSummandBoundEnvelope (typical-z restricted) to get per-ℓ bound.
  have hPerSummand := Workspace.ProofLemmas.SublemmaPerSummandBoundEnvelope n hn hmod δ hδ_lb hδ_ub
  simp only at hPerSummand
  -- Step 2: Apply LightEnvelopeBound.
  have hLightEnv := LightEnvelopeBound n hn hmod
  simp only at hLightEnv
  -- subset / sameParity properties of P_L
  have h_PL_subset : ∀ ℓ ∈ P_L, ℓ ⊆ Finset.Icc 1 (n / 2) := by
    intro ℓ hℓ
    rw [hP_L_def] at hℓ
    simp only [Finset.mem_filter, Finset.mem_powerset] at hℓ
    exact hℓ.1
  have h_PL_sameParity : ∀ ℓ ∈ P_L,
      Workspace.Types.AlternatingSumExpression.sameParity ℓ := by
    intro ℓ hℓ
    rw [hP_L_def] at hℓ
    simp only [Finset.mem_filter, Finset.mem_powerset] at hℓ
    exact hℓ.2.1
  -- F27 soundness fix: per-summand RHS now carries the polynomial prefactor `polyN n δ`.
  have h_typ_step1 :
      (∑ ℓ ∈ P_L,
          ∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
            ∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
              |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
        ≤ ∑ ℓ ∈ P_L, 2 * polyN n δ * envelopeW ℓ * Real.exp (-Real.sqrt n) := by
    apply Finset.sum_le_sum
    intro ℓ hℓ
    exact hPerSummand ℓ (h_PL_subset ℓ hℓ) (h_PL_sameParity ℓ hℓ)
  have h_factor :
      ∑ ℓ ∈ P_L, 2 * polyN n δ * envelopeW ℓ * Real.exp (-Real.sqrt n)
        = 2 * polyN n δ * (∑ ℓ ∈ P_L, envelopeW ℓ) * Real.exp (-Real.sqrt n) := by
    rw [show (∑ ℓ ∈ P_L, 2 * polyN n δ * envelopeW ℓ * Real.exp (-Real.sqrt n))
            = 2 * polyN n δ * Real.exp (-Real.sqrt n) * (∑ ℓ ∈ P_L, envelopeW ℓ) from by
          rw [Finset.mul_sum]; congr 1; ext ℓ; ring]
    ring
  have h_exp_pos : 0 < Real.exp (-Real.sqrt n) := Real.exp_pos _
  -- δ ∈ (0, 1/2].
  have hδ_pos : (0 : ℝ) < δ := by
    have : (0:ℝ) < 320 / Real.sqrt n := by positivity
    linarith
  -- polyN n δ ≥ 0 and polyN n δ ≤ 6000 n^3.
  have h_polyN_nn : (0 : ℝ) ≤ polyN n δ := by
    have h1mδpos : (0:ℝ) < 1 - δ := by linarith
    unfold polyN
    have hpe : (0:ℝ) ≤ ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3 := by
      have hpi : (3:ℝ) < Real.pi := Real.pi_gt_three
      apply div_nonneg
      · apply mul_nonneg
        apply mul_nonneg
        · positivity
        · linarith
        · positivity
      · positivity
    have hpf : (0:ℝ) ≤ 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 := by positivity
    have hpref : (0:ℝ) ≤ ((n : ℝ) / 2 + 1) ^ 2 := by positivity
    exact mul_nonneg hpref (by linarith)
  have h_polyN_bound : polyN n δ ≤ 6000 * (n : ℝ) ^ 3 := by
    unfold polyN
    have hn1 : (1:ℝ) ≤ n := by nlinarith [hn_ge]
    have hperExp : ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
        ≤ 2400 * ((n:ℝ) + 1) := by
      have hpi : Real.pi < 3.15 := Real.pi_lt_d2
      have hpipos : (0:ℝ) < Real.pi := Real.pi_pos
      have h1mδpos : (0:ℝ) < 1 - δ := by linarith
      have hcube : (1:ℝ)/8 ≤ (1 - δ) ^ 3 := by nlinarith [h1mδpos, sq_nonneg (1-δ)]
      have hmp1 : (0:ℝ) ≤ (n:ℝ) + 1 := by linarith
      rw [div_le_iff₀ (by positivity)]
      have hconst : (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 ≤ 280 := by
        nlinarith [hpi, hpipos]
      have hL : ((n:ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 ≤ ((n:ℝ) + 1) * 280 := by
        rw [mul_assoc]; exact mul_le_mul_of_nonneg_left hconst hmp1
      have hR : ((n:ℝ) + 1) * 280 ≤ 2400 * ((n:ℝ) + 1) * (1 - δ) ^ 3 := by nlinarith [hcube, hmp1]
      linarith [hL, hR]
    have hperFou : 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 ≤ 800 := by
      have hpi : Real.pi < 3.15 := Real.pi_lt_d2
      have hpipos : (0:ℝ) < Real.pi := Real.pi_pos
      have h1mδpos : (0:ℝ) < 1 - δ := by linarith
      have h1mδ : (1:ℝ)/2 ≤ 1 - δ := by linarith
      rw [div_le_iff₀ (by positivity)]
      nlinarith [hpi, hpipos, h1mδ, h1mδpos, mul_pos h1mδpos h1mδpos]
    have hsum_le : (((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
          + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2) ≤ 2400 * ((n:ℝ)+1) + 800 := by linarith
    have hpref : ((n : ℝ) / 2 + 1) ^ 2 ≤ (n:ℝ)^2 := by nlinarith [hn1, h_n_pos]
    have hpref_nn : (0:ℝ) ≤ ((n : ℝ) / 2 + 1) ^ 2 := by positivity
    have hsum_nn : (0:ℝ) ≤ 2400 * ((n:ℝ)+1) + 800 := by positivity
    calc ((n : ℝ) / 2 + 1) ^ 2 *
            (((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
              + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2)
        ≤ ((n : ℝ) / 2 + 1) ^ 2 * (2400 * ((n:ℝ)+1) + 800) :=
          mul_le_mul_of_nonneg_left hsum_le hpref_nn
      _ ≤ (n:ℝ)^2 * (2400 * ((n:ℝ)+1) + 800) :=
          mul_le_mul_of_nonneg_right hpref hsum_nn
      _ ≤ 6000 * (n:ℝ)^3 := by nlinarith [hn1, h_n_pos, sq_nonneg ((n:ℝ))]
  -- Typical numeric assembly: 2·polyN·(∑env)·e^{-√n} ≤ (1/16) e^{-√n/4}.
  have h_typ_final :
      2 * polyN n δ * (∑ ℓ ∈ P_L, envelopeW ℓ) * Real.exp (-Real.sqrt n)
        ≤ (1 : ℝ) / 16 * Real.exp (-(Real.sqrt n / 4)) := by
    set sumE : ℝ := ∑ ℓ ∈ P_L, envelopeW ℓ with hsumE
    have hexp_nn : (0 : ℝ) ≤ Real.exp (-Real.sqrt n) := h_exp_pos.le
    -- Step A: 2·polyN·sumE ≤ 2·polyN·(n·e^{-√n/32})
    have hstepA : 2 * polyN n δ * sumE
        ≤ 2 * polyN n δ * ((n:ℝ) * Real.exp (-(Real.sqrt n / 32))) := by
      have h2p_nn : (0:ℝ) ≤ 2 * polyN n δ := by positivity
      exact mul_le_mul_of_nonneg_left hLightEnv h2p_nn
    have hstepB : 2 * polyN n δ * ((n:ℝ) * Real.exp (-(Real.sqrt n / 32)))
        ≤ 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32)) := by
      have hne : (n:ℝ) * Real.exp (-(Real.sqrt n / 32)) ≥ 0 := by positivity
      have h1 : 2 * polyN n δ ≤ 12000 * (n:ℝ)^3 := by linarith [h_polyN_bound]
      calc 2 * polyN n δ * ((n:ℝ) * Real.exp (-(Real.sqrt n / 32)))
          ≤ (12000 * (n:ℝ)^3) * ((n:ℝ) * Real.exp (-(Real.sqrt n / 32))) :=
            mul_le_mul_of_nonneg_right h1 hne
        _ = 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32)) := by ring
    have hstepC : 2 * polyN n δ * sumE * Real.exp (-Real.sqrt n)
        ≤ 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32)) * Real.exp (-Real.sqrt n) := by
      have h1 : 2 * polyN n δ * sumE ≤ 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32)) :=
        hstepA.trans hstepB
      exact mul_le_mul_of_nonneg_right h1 hexp_nn
    have hcombine : 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32)) * Real.exp (-Real.sqrt n)
        = 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n)) := by
      rw [mul_assoc (12000 * (n:ℝ)^4), ← Real.exp_add]
    have hfinal : 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n))
        ≤ (1:ℝ) / 16 * Real.exp (-(Real.sqrt n / 4)) := by
      rw [show (1:ℝ)/16 * Real.exp (-(Real.sqrt n / 4))
              = Real.exp (-(Real.sqrt n / 4)) / 16 from by ring]
      rw [le_div_iff₀ (by norm_num : (0:ℝ) < 16)]
      rw [show 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n)) * 16
            = 192000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n)) from by ring]
      have h_eq : -(Real.sqrt n / 4)
          = (-(Real.sqrt n / 32) + (-Real.sqrt n)) + (Real.sqrt n * 25 / 32) := by ring
      rw [h_eq, Real.exp_add (-(Real.sqrt n / 32) + (-Real.sqrt n)) (Real.sqrt n * 25 / 32)]
      have hexp_neg_pos : 0 < Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n)) := Real.exp_pos _
      have h_main : 192000 * (n:ℝ)^4 ≤ Real.exp (Real.sqrt n * 25 / 32) := by
        set t : ℝ := Real.sqrt n with ht_def
        have h_n_eq : (n:ℝ) = t^2 := by rw [ht_def, sq, Real.mul_self_sqrt h_n_pos.le]
        have ht_pos : (0:ℝ) < t := by rw [ht_def]; exact Real.sqrt_pos.mpr h_n_pos
        rw [h_n_eq]
        set y : ℝ := t * 25 / 32 with hy_def
        have h_y_nonneg : 0 ≤ y := by rw [hy_def]; positivity
        have h_cubic : y ^ 11 / (Nat.factorial 11 : ℝ) ≤ Real.exp y :=
          Real.pow_div_factorial_le_exp y h_y_nonneg 11
        have h_fact11 : (Nat.factorial 11 : ℝ) = 39916800 := by norm_num [Nat.factorial]
        rw [h_fact11] at h_cubic
        have ht3 : (10:ℝ)^18 ≤ t^3 := by
          have hge : (10:ℝ)^6 ≤ t := by rw [ht_def]; exact h_sqrt_n_ge
          calc (10:ℝ)^18 = ((10:ℝ)^6)^3 := by ring
            _ ≤ t^3 := by gcongr
        have h_intermediate : 192000 * (t^2)^4 ≤ y ^ 11 / 39916800 := by
          rw [hy_def]
          nlinarith [ht3, ht_pos, pow_pos ht_pos 8, pow_pos ht_pos 3, pow_pos ht_pos 11,
            mul_pos (pow_pos ht_pos 8) (pow_pos ht_pos 3)]
        linarith [h_cubic, h_intermediate]
      calc 192000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n))
          ≤ Real.exp (Real.sqrt n * 25 / 32) * Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n)) :=
            mul_le_mul_of_nonneg_right h_main hexp_neg_pos.le
        _ = Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n)) * Real.exp (Real.sqrt n * 25 / 32) := by
            ring
    calc 2 * polyN n δ * sumE * Real.exp (-Real.sqrt n)
        ≤ 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32)) * Real.exp (-Real.sqrt n) := hstepC
      _ = 12000 * (n:ℝ)^4 * Real.exp (-(Real.sqrt n / 32) + (-Real.sqrt n)) := hcombine
      _ ≤ (1 : ℝ) / 16 * Real.exp (-(Real.sqrt n / 4)) := hfinal
  have h_typical_bound :
      (∑ ℓ ∈ P_L,
          ∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
            ∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
              |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
        ≤ (1 : ℝ) / 16 * Real.exp (-(Real.sqrt n / 4)) := by
    calc
      _ ≤ ∑ ℓ ∈ P_L, 2 * polyN n δ * envelopeW ℓ * Real.exp (-Real.sqrt n) := h_typ_step1
      _ = 2 * polyN n δ * (∑ ℓ ∈ P_L, envelopeW ℓ) * Real.exp (-Real.sqrt n) := h_factor
      _ ≤ (1 : ℝ) / 16 * Real.exp (-(Real.sqrt n / 4)) := h_typ_final
  -- ===== ATYPICAL PART =====
  have h_atypical_bound :
      (∑ ℓ ∈ P_L,
          ((∑ zMinus ∈ Finset.range (n / 16),
              ∑ zPlus ∈ Finset.range (n / 2 + 1),
                |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)
            +
           (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
              ∑ zPlus ∈ Finset.range (n / 16),
                |Workspace.Types.AlternatingSumExpression.altRSum n δ α zMinus zPlus ℓ|)))
        ≤ (1 : ℝ) / 16 * Real.exp (-(Real.sqrt n / 4)) := by
    have hat := AltRSumLightAtypicalBound n hn hmod δ hδ_lb hδ_ub
    simp only at hat
    exact hat
  -- Assemble: typical + atypical ≤ (1/16 + 1/16) exp(-√n/4) = (1/8) exp(-√n/4).
  have h_final_eq : (1 : ℝ) / 16 * Real.exp (-(Real.sqrt n / 4))
      + (1 : ℝ) / 16 * Real.exp (-(Real.sqrt n / 4))
      = (1 : ℝ) / 8 * Real.exp (-(Real.sqrt n / 4)) := by ring
  linarith [h_typical_bound, h_atypical_bound, h_final_eq]
