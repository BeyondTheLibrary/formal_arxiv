-- CONDITIONAL §3.1 typical-z envelope assembly, derived by SUMMING the per-(z₋,z₊)
-- Fourier bound `AltRSumFourierBound` over the typical deletion range.
--
-- This file builds the SOUND, CONDITIONAL bridge that de-axiomatizes `AltRSumEnvelopeBound`
-- once (a) `AltRSumFourierBound` is proved (which itself awaits Lemma 7), and (b) an envelope
-- lower bound is supplied. It is NOT an axiom: `altRSum_envelope_of_fourier` is a `theorem`,
-- proved sorry-free, taking the per-term Fourier conclusion as a hypothesis `hpt`.
--
-- IMPORTANT FAITHFULNESS / SOUNDNESS NOTE (reported back to the orchestrator).
-- The per-term Fourier bound `|altRSum| ≤ B_exp(z₋,z₊) + B_Fou` carries NO dependence on the
-- envelope `envelopeW(ℓ) = ∑_r ∏_{j∈ℓ} ellFactor`. Summing it over the (≤ (n/2)²) typical
-- terms therefore yields a bound of the form `poly(n) · exp(-√n)`, where
--   poly(n) := T² · (perExp + perFou),
--   T       := card (Ico (n/16) (n/2+1))  (≤ n/2 + 1),
--   perExp  := e · (n+1)·(2π-2)·(2π)²/(1-δ)³,   -- the `e` folds the Nat-floor corner slack
--   perFou  := 4·(2π)²/(1-δ)².
-- The target RHS of `AltRSumEnvelopeBound` is `2 · envelopeW(ℓ) · exp(-√n)` — with NO poly(n)
-- factor. Because `ellFactor = αX/(1-αX)` with `X = binPMFInt n (1/2) (·)` a PMF value that is
-- exponentially small in the tails, each product `∏_{j∈ℓ} ellFactor` (and hence `envelopeW(ℓ)`)
-- can be made arbitrarily small. So `poly(n) ≤ 2 · envelopeW(ℓ)` does NOT hold unconditionally;
-- there is a genuine `poly(n)` constant gap between what the per-term Fourier bound delivers and
-- the `2·envelopeW` RHS as currently stated in `AltRSumEnvelopeBound`. This conditional theorem
-- therefore makes the gap EXPLICIT by taking it as the hypothesis
--   `henv : poly(n) ≤ 2 · envelopeW ℓ`.
-- (See the report: `AltRSumEnvelopeBound`'s `2·envelopeW·e^{-√n}` RHS most likely needs a
-- poly(n) factor — i.e. should read `poly(n)·envelopeW·e^{-√n}` or `poly(n)·e^{-√n}` — for the
-- §3.1 sum-of-Lemma-8 derivation to close. Flagged as a faithfulness check.)
import Mathlib
import Workspace.Types.AlternatingSumExpression

open Workspace.Types.AlternatingSumExpression

namespace Workspace.PriorWork.AltRSumEnvelopeFromFourier

set_option maxHeartbeats 1000000

/-- The polynomial pre-factor obtained by summing the per-term Fourier bound over the typical
deletion grid. `T` is the side length of the grid `Ico (n/16) (n/2+1)`; `perExp` and `perFou`
are the per-term `B_exp`/`B_Fou` coefficients after replacing every `exp(-…)` on the typical
range by `exp(-√n)` (with a harmless extra factor `e` on `perExp` covering the Nat-floor
corner slack `δ·z/20 ≥ √n - 1`). -/
noncomputable def polyN (n : ℕ) (δ : ℝ) : ℝ :=
  let T : ℝ := ((Finset.Ico (n / 16) (n / 2 + 1)).card : ℝ)
  let perExp : ℝ :=
    Real.exp 1 * (((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3)
  let perFou : ℝ := 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2
  T ^ 2 * (perExp + perFou)

/--
**Conditional §3.1 typical-z envelope assembly (sum of `AltRSumFourierBound`).**

Takes the per-(z₋,z₊) Fourier bound `hpt` as a hypothesis and an envelope lower bound `henv`,
and proves the typical-z `AltRSumEnvelopeBound` conclusion. Sorry-free.

The key calc on the typical range (`z ≥ n/16`, `δ ≥ 320/√n`):
  `δ·z/20 ≥ (320/√n)·((n/16) - 1)/20 = √n - 16/√n ≥ √n - 1`  ⟹  `e^{-δz/20} ≤ e·e^{-√n}`,
and `n/150 ≥ √n` for `n ≥ 22500`, so `e^{-n/150} ≤ e^{-√n} ≤ e·e^{-√n}`. Hence each
`B_exp(z₋,z₊) ≤ perExp·e^{-√n}` and `B_Fou = perFou·e^{-√n}`. Summing over the `T²` typical
terms gives `≤ poly(n)·e^{-√n}`, and `henv : poly(n) ≤ 2·envelopeW ℓ` lifts this to the
target. -/
theorem altRSum_envelope_of_fourier :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
    ∀ (δ : ℝ), (320 : ℝ) / Real.sqrt n ≤ δ → δ ≤ 1 / 2 →
    let c' : ℝ := 1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))
    let α : ℝ := c' * Real.sqrt n
    let n_h : ℕ := n / 2
    let envelopeW : Finset ℕ → ℝ := fun ℓ =>
      ∑ r ∈ Finset.Icc (-((n : ℤ) / 4)) ((n : ℤ) / 4),
        ∏ j ∈ ℓ, ellFactor n α r j
    ∀ (ℓ : Finset ℕ), ℓ ⊆ Finset.Icc 1 n_h → sameParity ℓ →
    -- Per-term Fourier bound (the conclusion of `AltRSumFourierBound`), taken as a hypothesis:
    (∀ zMinus zPlus : ℕ, zMinus < n / 2 + 1 → zPlus < n / 2 + 1 →
        |altRSum n δ α zMinus zPlus ℓ|
          ≤ ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 *
              (max (max (Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ))
                        (Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)))
                   (Real.exp (-((n : ℝ) / 150))))
            + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * Real.exp (-Real.sqrt (n : ℝ))) →
    -- Envelope lower bound bridging the poly(n) gap (see file header):
    polyN n δ ≤ 2 * envelopeW ℓ →
      (∑ zMinus ∈ Finset.Ico (n / 16) (n_h + 1),
        ∑ zPlus ∈ Finset.Ico (n / 16) (n_h + 1),
          |altRSum n δ α zMinus zPlus ℓ|)
        ≤ 2 * envelopeW ℓ * Real.exp (-Real.sqrt n) := by
  intro n hn hmod δ hδlb hδub c' α n_h envelopeW ℓ hℓsub hℓpar hpt henv
  -- ── Basic numeric facts ──────────────────────────────────────────────
  have hn' : (10 : ℝ) ^ 12 ≤ (n : ℝ) := by
    have h := (Nat.cast_le (α := ℝ)).mpr hn
    push_cast at h; linarith
  have hnpos : (0 : ℝ) < n := by
    have : (0:ℝ) < (10:ℝ)^12 := by positivity
    linarith
  have hsqrt_pos : (0 : ℝ) < Real.sqrt n := Real.sqrt_pos.mpr hnpos
  -- √n is large: √n = √n, and (√n)² = n ≥ 10^12, so √n ≥ 10^6.
  have hsqrt_sq : Real.sqrt n ^ 2 = (n : ℝ) := Real.sq_sqrt hnpos.le
  have hsqrt_ge : (10 : ℝ) ^ 6 ≤ Real.sqrt n := by
    have hle : (10:ℝ)^6 ≤ Real.sqrt ((10:ℝ)^12) := by
      rw [show ((10:ℝ)^12) = ((10:ℝ)^6)^2 by ring, Real.sqrt_sq (by positivity)]
    exact hle.trans (Real.sqrt_le_sqrt hn')
  -- δ ∈ (0, 1/2], 1 - δ ∈ [1/2, 1).
  have hδ_pos : (0 : ℝ) < δ := by
    have : (0:ℝ) < 320 / Real.sqrt n := by positivity
    linarith
  have h1mδ_pos : (0 : ℝ) < 1 - δ := by linarith
  have hinv_ge1 : (1 : ℝ) ≤ 1 / (1 - δ) := by
    rw [le_div_iff₀ h1mδ_pos]; linarith
  have hexp_pos : (0 : ℝ) < Real.exp (-Real.sqrt n) := Real.exp_pos _
  -- π facts.
  have hpi : (3 : ℝ) < Real.pi := by linarith [Real.pi_gt_three]
  have h2π2_pos : (0 : ℝ) < 2 * Real.pi - 2 := by linarith
  -- ── Abbreviations matching `polyN` ──────────────────────────────────
  set T : ℝ := ((Finset.Ico (n / 16) (n / 2 + 1)).card : ℝ) with hT
  set perExp : ℝ :=
    Real.exp 1 * (((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3)
    with hperExp
  set perFou : ℝ := 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 with hperFou
  have hperExp_nonneg : (0 : ℝ) ≤ perExp := by rw [hperExp]; positivity
  have hperFou_nonneg : (0 : ℝ) ≤ perFou := by rw [hperFou]; positivity
  have hT_nonneg : (0 : ℝ) ≤ T := by rw [hT]; positivity
  -- ── KEY per-term bound on the typical range ─────────────────────────
  have hterm : ∀ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
               ∀ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                 |altRSum n δ α zMinus zPlus ℓ| ≤ (perExp + perFou) * Real.exp (-Real.sqrt n) := by
    intro zMinus hzM zPlus hzP
    rw [Finset.mem_Ico] at hzM hzP
    have hbnd := hpt zMinus zPlus hzM.2 hzP.2
    -- For z ≥ n/16:  exp(-(δ z /20)) ≤ exp(1) · exp(-√n).
    have key_exp : ∀ z : ℕ, n / 16 ≤ z →
        Real.exp (-(δ * (z : ℝ) / 20)) ≤ Real.exp 1 * Real.exp (-Real.sqrt n) := by
      intro z hz
      rw [← Real.exp_add]
      apply Real.exp_le_exp.mpr
      -- need -(δ z /20) ≤ 1 - √n, i.e. √n ≤ δ z /20 + 1.
      set s : ℝ := Real.sqrt n with hs
      -- z ≥ n/16 (Nat) ⟹ 16·(z:ℝ) ≥ (n:ℝ) - 15.
      have h16z : (n : ℝ) - 15 ≤ 16 * (z : ℝ) := by
        have hzn : (n / 16 : ℕ) ≤ z := hz
        have hnat : n ≤ z * 16 + 15 := by omega
        have hc := (Nat.cast_le (α := ℝ)).mpr hnat
        push_cast at hc
        linarith [hc]
      -- δ·z ≥ (320/s)·z  (z ≥ 0).
      have hδz : (320 / s) * (z : ℝ) ≤ δ * (z : ℝ) :=
        mul_le_mul_of_nonneg_right hδlb (by positivity)
      -- multiply the target's pieces by s > 0 to clear the division.
      -- Goal: √n ≤ δ z /20 + 1, i.e. s ≤ δ z /20 + 1.
      -- We show s·s ≤ (δ z /20 + 1)·s  via  s² = n ≤ δ z s /20 + s, then divide by s.
      have hs_pos : (0 : ℝ) < s := by rw [hs]; exact hsqrt_pos
      have hs_sq : s ^ 2 = (n : ℝ) := by rw [hs]; exact hsqrt_sq
      -- (320/s)·z·s = 320 z ; so δ z · s ≥ 320 z.
      have hδzs : 320 * (z : ℝ) ≤ δ * (z : ℝ) * s := by
        have hmul := mul_le_mul_of_nonneg_right hδz hs_pos.le
        -- (320/s)·z·s = 320·z  (since s ≠ 0).
        have hcancel : (320 / s) * (z : ℝ) * s = 320 * (z : ℝ) := by
          field_simp
        rw [hcancel] at hmul
        linarith [hmul]
      -- s ≥ 16 (since s ≥ 10^6).
      have hs16 : (16 : ℝ) ≤ s := by rw [hs]; nlinarith [hsqrt_ge]
      -- Now: δ z s /20 ≥ 320 z /20 = 16 z ≥ n - 15 ≥ n - s = s² - s = s(s-1).
      -- So δ z s /20 ≥ s(s-1), divide by s: δ z /20 ≥ s - 1, i.e. s ≤ δ z /20 + 1.
      have hbig : s * (s - 1) ≤ δ * (z : ℝ) / 20 * s := by
        have h1 : s * (s - 1) ≤ 16 * (z : ℝ) := by nlinarith [h16z, hs16, hs_sq]
        have h2 : (16 : ℝ) * (z : ℝ) ≤ δ * (z : ℝ) / 20 * s := by nlinarith [hδzs]
        linarith [h1, h2]
      -- divide hbig by s > 0.
      have hfin : s - 1 ≤ δ * (z : ℝ) / 20 :=
        le_of_mul_le_mul_right (by nlinarith [hbig]) hs_pos
      linarith [hfin]
    -- exp(-n/150) ≤ exp(1)·exp(-√n)  (since n/150 ≥ √n for n ≥ 22500).
    have key_n150 : Real.exp (-((n : ℝ) / 150)) ≤ Real.exp 1 * Real.exp (-Real.sqrt n) := by
      rw [← Real.exp_add]
      apply Real.exp_le_exp.mpr
      -- need -n/150 ≤ 1 - √n, i.e. √n ≤ n/150 + 1. Since n = (√n)², √n ≤ (√n)²/150 + 1.
      have hle : Real.sqrt n ≤ (n : ℝ) / 150 + 1 := by
        nlinarith [hsqrt_ge, hsqrt_pos, hsqrt_sq]
      linarith [hle]
    -- The full max is ≤ exp(1)·exp(-√n)/(1-δ).
    have hmax_bnd :
        (max (max (Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ))
                  (Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)))
             (Real.exp (-((n : ℝ) / 150))))
          ≤ Real.exp 1 * Real.exp (-Real.sqrt n) / (1 - δ) := by
      apply max_le
      · apply max_le
        · gcongr
          exact key_exp zMinus hzM.1
        · gcongr
          exact key_exp zPlus hzP.1
      · -- exp(-n/150) ≤ exp(1)exp(-√n) ≤ exp(1)exp(-√n)/(1-δ).
        calc Real.exp (-((n : ℝ) / 150))
            ≤ Real.exp 1 * Real.exp (-Real.sqrt n) := key_n150
          _ ≤ Real.exp 1 * Real.exp (-Real.sqrt n) / (1 - δ) := by
                rw [le_div_iff₀ h1mδ_pos]
                nlinarith [Real.exp_pos (1:ℝ), hexp_pos, h1mδ_pos, hδ_pos,
                           mul_pos (Real.exp_pos (1:ℝ)) hexp_pos]
    -- Now bound the B_exp coefficient · max.
    set Cexp : ℝ := ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2
      with hCexp
    have hCexp_nonneg : (0 : ℝ) ≤ Cexp := by rw [hCexp]; positivity
    -- B_exp = Cexp · max ≤ Cexp · (e·e^{-√n}/(1-δ)) = perExp · e^{-√n}.
    have hBexp_le : Cexp *
        (max (max (Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ))
                  (Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)))
             (Real.exp (-((n : ℝ) / 150))))
        ≤ perExp * Real.exp (-Real.sqrt n) := by
      calc Cexp * _
          ≤ Cexp * (Real.exp 1 * Real.exp (-Real.sqrt n) / (1 - δ)) :=
            mul_le_mul_of_nonneg_left hmax_bnd hCexp_nonneg
        _ = perExp * Real.exp (-Real.sqrt n) := by
            rw [hperExp, hCexp]; field_simp
    -- B_Fou = perFou · e^{-√n} exactly.
    have hBfou_eq : 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * Real.exp (-Real.sqrt (n : ℝ))
        = perFou * Real.exp (-Real.sqrt n) := rfl
    -- Combine.
    calc |altRSum n δ α zMinus zPlus ℓ|
        ≤ Cexp *
            (max (max (Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ))
                      (Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)))
                 (Real.exp (-((n : ℝ) / 150))))
            + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * Real.exp (-Real.sqrt (n : ℝ)) := hbnd
      _ ≤ perExp * Real.exp (-Real.sqrt n) + perFou * Real.exp (-Real.sqrt n) := by
            rw [hBfou_eq]; linarith [hBexp_le]
      _ = (perExp + perFou) * Real.exp (-Real.sqrt n) := by ring
  -- ── Sum the per-term bound over the typical grid ────────────────────
  -- Each inner sum ≤ T · (perExp+perFou)·e^{-√n}; outer ≤ T² · (...).
  have hsum :
      (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
        ∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
          |altRSum n δ α zMinus zPlus ℓ|)
        ≤ T ^ 2 * ((perExp + perFou) * Real.exp (-Real.sqrt n)) := by
    have hC_nonneg : (0 : ℝ) ≤ (perExp + perFou) * Real.exp (-Real.sqrt n) := by positivity
    calc (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
            ∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
              |altRSum n δ α zMinus zPlus ℓ|)
        ≤ ∑ _zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
            (T * ((perExp + perFou) * Real.exp (-Real.sqrt n))) := by
          apply Finset.sum_le_sum
          intro zMinus hzM
          calc (∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1), |altRSum n δ α zMinus zPlus ℓ|)
              ≤ ∑ _zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
                  ((perExp + perFou) * Real.exp (-Real.sqrt n)) := by
                apply Finset.sum_le_sum
                intro zPlus hzP
                exact hterm zMinus hzM zPlus hzP
            _ = T * ((perExp + perFou) * Real.exp (-Real.sqrt n)) := by
                rw [Finset.sum_const, hT, nsmul_eq_mul]
      _ = T * (T * ((perExp + perFou) * Real.exp (-Real.sqrt n))) := by
          rw [Finset.sum_const, hT, nsmul_eq_mul]
      _ = T ^ 2 * ((perExp + perFou) * Real.exp (-Real.sqrt n)) := by ring
  -- ── Bridge via the envelope lower bound `henv` ──────────────────────
  -- polyN n δ = T² (perExp+perFou); henv : polyN ≤ 2 envelopeW ℓ.
  have hpolyN_eq : polyN n δ = T ^ 2 * (perExp + perFou) := by
    rw [polyN, hT, hperExp, hperFou]
  have henv' : T ^ 2 * (perExp + perFou) ≤ 2 * envelopeW ℓ := by
    rw [← hpolyN_eq]; exact henv
  -- T²(perExp+perFou)·e^{-√n} ≤ 2·envelopeW·e^{-√n}.
  calc (∑ zMinus ∈ Finset.Ico (n / 16) (n / 2 + 1),
          ∑ zPlus ∈ Finset.Ico (n / 16) (n / 2 + 1),
            |altRSum n δ α zMinus zPlus ℓ|)
      ≤ T ^ 2 * ((perExp + perFou) * Real.exp (-Real.sqrt n)) := hsum
    _ = (T ^ 2 * (perExp + perFou)) * Real.exp (-Real.sqrt n) := by ring
    _ ≤ 2 * envelopeW ℓ * Real.exp (-Real.sqrt n) :=
        mul_le_mul_of_nonneg_right henv' hexp_pos.le

end Workspace.PriorWork.AltRSumEnvelopeFromFourier
