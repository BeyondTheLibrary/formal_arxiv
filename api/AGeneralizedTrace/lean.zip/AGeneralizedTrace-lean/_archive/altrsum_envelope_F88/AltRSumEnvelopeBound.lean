-- Cited from: §3.1 assembly of arXiv:2412.00674v1 (proof of thm:lower-detail, lines
-- 414-420), specialized to the TYPICAL deletion range. The paper restricts to the event
-- z₋, z₊ ≥ n/16 (which holds except with probability e^{-Ω(n)}, line 418) and then sums
-- Lemma 8 (lem:r-func-bound) over the rare-support realizations of Lemma 11 (lem:rare),
-- weighted by the envelope ∑_r ∏_{j∈ℓ} ellFactor. For z₋, z₊ ≥ n/16 and δ ≥ 320/√n the
-- Lemma 8 bound is O(n·e^{-√n}) (since e^{-δz/20} ≤ e^{-√n}); accumulating it over the
-- rare-support envelope yields the per-ℓ bound below. This is the SOUND, faithful form of
-- the inner §3.1 bound: it restricts to the TYPICAL z-range, where the dominant B_exp term
-- of Lemma 8 is genuinely e^{-√n}-small. (The previous full-z-range form was unsound: for
-- small z, B_exp ≈ poly(n), not e^{-√n}, so the full-z envelope bound is false.) The
-- ATYPICAL z-range (z₋ < n/16 or z₊ < n/16) is handled separately, as the paper does, by
-- AltRSumLightAtypicalBound (the e^{-Ω(n)} additive absorption of line 418).
--
-- SOUNDNESS FIX (F27 re-investigation, 2026-06). The previous RHS `2·envelopeW(ℓ)·e^{-√n}`
-- was TOO STRONG (unsound): the `envelopeW` (k-way ℓ¹ rare-support weight) and the `e^{-√n}`
-- Fourier decay come from mutually exclusive routes, so the bound was missing a `poly(n)`
-- factor. Concretely, summing the honest per-(z₋,z₊) Fourier bound (`AltRSumFourierBound`,
-- coefficient ≈ (n+1)(2π-2)(2π)²/(1-δ)² · e^{-√n}) over the T² typical z-grid yields a
-- prefactor `poly(n) = T²·(perExp+perFou)` that the bare `2·envelopeW` cannot absorb
-- (envelopeW = ∑_r ∏_{j∈ℓ} ellFactor can be arbitrarily small, since ellFactor = αX/(1-αX)
-- with X = binPMFInt exp-small in the tails). The FAITHFUL corrected RHS therefore carries
-- the polynomial prefactor: `2·polyN·envelopeW(ℓ)·e^{-√n}` with
--   polyN := (n/2+1)²·(perExp + perFou),
--   perExp := (n+1)(2π-2)(2π)²/(1-δ)³,   perFou := 4(2π)²/(1-δ)².
-- This is exactly the prefactor proved (conditionally, sorry-free) in
-- `AltRSumEnvelopeFromFourier.altRSum_envelope_of_fourier`. The consumer
-- `LightContributionBound` still closes with huge slack, because
--   ∑_{ℓ∈P_L} 2·polyN·envelopeW·e^{-√n} ≤ 2·polyN·e^{-√n}·(n·e^{-√n/32})  (LightEnvelopeBound)
--   ≤ (1/16)·e^{-√n/4}  (polyN is poly(n), absorbed by the e^{√n·25/32} slack).
--
-- Paper label: §3.1 assembly inner bound (Lemma 8 typical-z sum weighted by Lemma 11 rare-support)
-- NL statement: Let n ∈ ℕ with n ≥ 10^12 and n % 8 = 1. Let δ ∈ ℝ with 320/√n ≤ δ ≤ 1/2,
-- α := c'·√n where c' := 1/(4 e² √(2π)), n_h := n/2. Define the polynomial prefactor
-- polyN(n,δ) := (n/2+1)² · ((n+1)(2π-2)(2π)²/(1-δ)³ + 4(2π)²/(1-δ)²) and the envelope
-- envelopeW(ℓ) := ∑_{r ∈ Finset.Icc (-(n/4)) (n/4)} ∏_{j ∈ ℓ} ellFactor n α r j. Then for
-- every same-parity ℓ ⊆ Finset.Icc 1 n_h, the L¹-summed inner alternating r-sum, RESTRICTED
-- to the typical deletion range z₋, z₊ ∈ {n/16, ..., n/2}, is bounded by the envelope:
--   ∑_{z₋ ∈ Ico (n/16) (n_h+1)} ∑_{z₊ ∈ Ico (n/16) (n_h+1)} |altRSum n δ α z₋ z₊ ℓ|
--     ≤ 2 · polyN(n,δ) · envelopeW(ℓ) · exp(-√n).
import Mathlib
import Workspace.Types.AlternatingSumExpression

/-- Polynomial prefactor for the §3.1 typical-z envelope bound. Obtained by summing the
per-(z₋,z₊) Fourier bound over the typical deletion grid `Ico (n/16) (n/2+1)` (side length
`≤ n/2+1`): `polyN = (n/2+1)² · (perExp + perFou)` with the per-term `B_exp`/`B_Fou`
coefficients `perExp = (n+1)(2π-2)(2π)²/(1-δ)³` and `perFou = 4(2π)²/(1-δ)²`. See the
soundness note in this file's header and `AltRSumEnvelopeFromFourier`. -/
noncomputable def polyN (n : ℕ) (δ : ℝ) : ℝ :=
  let perExp : ℝ := ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
  let perFou : ℝ := 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2
  ((n : ℝ) / 2 + 1) ^ 2 * (perExp + perFou)

/--
**Typical-z envelope (L¹) form of the §3.1 inner bound on altRSum.**
§3.1 assembly of the paper (proof of `thm:lower-detail`, lines 414-420), restricted to the
TYPICAL deletion range `z₋, z₊ ≥ n/16`. On this range (which holds except with probability
`e^{-Ω(n)}`), the dominant `B_exp` term of Lemma 8 satisfies `e^{-δz/20} ≤ e^{-√n}` for
`δ ≥ 320/√n`, so Lemma 8's bound is `O(n · e^{-√n})`. Accumulating it over the rare-support
realizations of Lemma 11, weighted by the envelope `∑_r ∏_{j∈ℓ} ellFactor`, yields the per-ℓ
bound below.

For `n ≥ 10^{12}` with `n ≡ 1 (mod 8)`, `δ ∈ [320/√n, 1/2]`, `α := c' · √n` with
`c' := 1/(4 e² √(2π))`, `n_h := n/2`, the polynomial prefactor `polyN n δ`, and the envelope
`envelopeW(ℓ) := ∑_{r ∈ Icc(-(n/4), n/4)} ∏_{j ∈ ℓ} ellFactor n α r j`, every same-parity
`ℓ ⊆ {1, ..., n_h}` satisfies

  ∑_{z₋ = n/16}^{n_h} ∑_{z₊ = n/16}^{n_h}
      |altRSum n δ α z₋ z₊ ℓ|
    ≤ 2 · polyN n δ · envelopeW(ℓ) · exp(-√n).

This is the SOUND, faithful form of the inner §3.1 bound: it covers ONLY the typical
z-range. The atypical range is absorbed separately by `AltRSumLightAtypicalBound`, matching
the paper's `e^{-Ω(n)}` additive treatment (line 418).
-/
axiom AltRSumEnvelopeBound :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
    ∀ (δ : ℝ), (320 : ℝ) / Real.sqrt n ≤ δ → δ ≤ 1 / 2 →
    let c' : ℝ := 1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))
    let α : ℝ := c' * Real.sqrt n
    let n_h : ℕ := n / 2
    let envelopeW : Finset ℕ → ℝ := fun ℓ =>
      ∑ r ∈ Finset.Icc (-((n : ℤ) / 4)) ((n : ℤ) / 4),
        ∏ j ∈ ℓ,
          Workspace.Types.AlternatingSumExpression.ellFactor n α r j
    ∀ (ℓ : Finset ℕ), ℓ ⊆ Finset.Icc 1 n_h →
    Workspace.Types.AlternatingSumExpression.sameParity ℓ →
      (∑ zMinus ∈ Finset.Ico (n / 16) (n_h + 1),
        ∑ zPlus ∈ Finset.Ico (n / 16) (n_h + 1),
          |Workspace.Types.AlternatingSumExpression.altRSum n δ α
            zMinus zPlus ℓ|)
        ≤ 2 * polyN n δ * envelopeW ℓ * Real.exp (-Real.sqrt n)
