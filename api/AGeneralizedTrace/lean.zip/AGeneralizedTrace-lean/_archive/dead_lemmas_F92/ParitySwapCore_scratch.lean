import Mathlib

open scoped BigOperators

/-- Marginalization helper: sum over all bit-functions of a product of per-coordinate
weights, restricted to those that match a fixed pattern `m` on an injective window `e`,
equals the product over the window of the matched weights times the product over the
complement of the marginal (sum over both bit values). We phrase the RHS uniformly via
`Fintype.prod_sum`. -/
theorem marg_helper {n k : ℕ} (e : Fin k → Fin n) (he : Function.Injective e)
    (g : Fin n → Bool → ℝ) (m : Fin k → Bool) :
    (∑ x : Fin n → Bool,
        (∏ i : Fin n, g i (x i)) *
        (∏ j : Fin k, (if x (e j) = m j then (1 : ℝ) else 0)))
      = ∏ i : Fin n,
          (∑ c : Bool, g i c *
            (∏ j : Fin k, (if e j = i then (if c = m j then (1:ℝ) else 0) else 1))) := by
  -- define per-coordinate weight
  classical
  set wt : Fin n → Bool → ℝ :=
    fun i c => ∏ j : Fin k, (if e j = i then (if c = m j then (1:ℝ) else 0) else 1) with hwt
  -- RHS via Fintype.prod_sum
  rw [Fintype.prod_sum (fun i c => g i c * wt i c)]
  apply Finset.sum_congr rfl
  intro x _
  -- Goal: (∏ i, g i (x i)) * (∏ j, if x (e j) = m j then 1 else 0) = ∏ i, g i (x i) * wt i (x i)
  rw [Finset.prod_mul_distrib]
  congr 1
  -- Goal: (∏ j, if x (e j) = m j then 1 else 0) = ∏ i, wt i (x i)
  show (∏ j : Fin k, (if x (e j) = m j then (1:ℝ) else 0))
      = ∏ i : Fin n, ∏ j : Fin k, (if e j = i then (if x i = m j then (1:ℝ) else 0) else 1)
  rw [Finset.prod_comm]
  apply Finset.prod_congr rfl
  intro j _
  -- Goal: (if x (e j) = m j then 1 else 0) = ∏ i, (if e j = i then (if x i = m j then 1 else 0) else 1)
  rw [Finset.prod_eq_single (e j)]
  · simp
  · intro i _ hi
    rw [if_neg (by exact fun h => hi h.symm)]
  · intro h; exact absurd (Finset.mem_univ (e j)) h

/-- The marginalized form simplifies to the window product when each coordinate's
two weights sum to 1 and `e` is injective. -/
theorem marg_helper2 {n k : ℕ} (e : Fin k → Fin n) (he : Function.Injective e)
    (g : Fin n → Bool → ℝ) (m : Fin k → Bool)
    (hmarg : ∀ i : Fin n, g i true + g i false = 1) :
    (∑ x : Fin n → Bool,
        (∏ i : Fin n, g i (x i)) *
        (∏ j : Fin k, (if x (e j) = m j then (1 : ℝ) else 0)))
      = ∏ j : Fin k, g (e j) (m j) := by
  classical
  rw [marg_helper e he g m]
  -- Abbreviate the per-coordinate marginalized factor.
  set F : Fin n → ℝ := fun i =>
      (∑ c : Bool, g i c *
        (∏ j : Fin k, (if e j = i then (if c = m j then (1:ℝ) else 0) else 1))) with hF
  -- Off the image of `e`, F i = 1.
  have hF_off : ∀ i : Fin n, (¬ ∃ j, e j = i) → F i = 1 := by
    intro i hex
    show (∑ c : Bool, g i c *
        (∏ j : Fin k, (if e j = i then (if c = m j then (1:ℝ) else 0) else 1))) = 1
    have hinner : ∀ c : Bool,
        (∏ j : Fin k, (if e j = i then (if c = m j then (1:ℝ) else 0) else 1)) = 1 := by
      intro c
      apply Finset.prod_eq_one
      intro j _
      rw [if_neg]; intro hej; exact hex ⟨j, hej⟩
    simp only [hinner, mul_one]
    rw [Fintype.sum_bool]; linarith [hmarg i]
  -- On `e j`, F (e j) = g (e j) (m j).
  have hF_on : ∀ j : Fin k, F (e j) = g (e j) (m j) := by
    intro j₀
    show (∑ c : Bool, g (e j₀) c *
        (∏ j : Fin k, (if e j = e j₀ then (if c = m j then (1:ℝ) else 0) else 1)))
        = g (e j₀) (m j₀)
    have hinner : ∀ c : Bool,
        (∏ j : Fin k, (if e j = e j₀ then (if c = m j then (1:ℝ) else 0) else 1))
        = (if c = m j₀ then (1:ℝ) else 0) := by
      intro c
      rw [Finset.prod_eq_single j₀]
      · rw [if_pos rfl]
      · intro j _ hj
        rw [if_neg]; intro hej; exact hj (he hej)
      · intro h; exact absurd (Finset.mem_univ _) h
    rw [Fintype.sum_bool, hinner true, hinner false]
    rcases hm : m j₀ with _ | _
    · simp [hm]
    · simp [hm]
  -- Reindex: ∏ i, F i = ∏ i ∈ image e univ, F i (since F = 1 off image), and the latter = ∏ j, F (e j).
  rw [← Finset.prod_filter_mul_prod_filter_not Finset.univ (fun i => ∃ j, e j = i)]
  rw [Finset.prod_eq_one (s := Finset.univ.filter (fun i => ¬ ∃ j, e j = i)) ?_]
  · rw [mul_one]
    -- ∏ i ∈ filter (∃ j, e j = i), F i = ∏ j, F (e j) = ∏ j, g (e j) (m j)
    have himg : (Finset.univ.filter (fun i : Fin n => ∃ j, e j = i))
        = Finset.image e Finset.univ := by
      ext i; simp [Finset.mem_image]
    rw [himg]
    rw [Finset.prod_image (fun a _ b _ hab => he hab)]
    apply Finset.prod_congr rfl
    intro j _; exact hF_on j
  · intro i hi
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hi
    exact hF_off i hi

