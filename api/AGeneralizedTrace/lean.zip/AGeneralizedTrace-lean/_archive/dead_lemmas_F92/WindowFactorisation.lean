import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.BinVec
import Workspace.Types.CoinFlipDist
import Workspace.Types.PartialDeletionProcess

open Workspace.Types.ProbVec
open Workspace.Types.BinVec
open Workspace.Types.CoinFlipDist
open Workspace.Types.PartialDeletionProcess

theorem WindowFactorisation :
    ∀ {n : ℕ}, (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
      ∀ (b : Workspace.Types.BinVec.BinVec n) (r : ℤ)
        (hr : ∀ j : Fin (n / 2),
            0 ≤ ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) ∧
            ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) < (n : ℤ)),
        -- Part (i): indicator characterisation.
        (∀ (m : Workspace.Types.BinVec.BinVec (n / 2)),
            Workspace.Types.PartialDeletionProcess.middleIndicator n b m r =
              (if (∀ j : Fin (n / 2),
                    b.bit ⟨(((n / 4 : ℕ) : ℤ) + r + (j : ℕ)).toNat,
                      by
                        have hj := hr j
                        have h0 : ((((n / 4 : ℕ) : ℤ) + r + (j : ℕ)).toNat : ℤ)
                            = ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) :=
                          Int.toNat_of_nonneg hj.1
                        have hcast : ((((n / 4 : ℕ) : ℤ) + r + (j : ℕ)).toNat : ℤ) < (n : ℤ) := by
                          rw [h0]; exact hj.2
                        exact_mod_cast hcast⟩
                    = m.bit j)
                then (1 : ENNReal) else 0)) ∧
        -- Part (ii): coin-flip product factorisation along the prefix/middle/suffix split.
        (∀ (S : Workspace.Types.ProbVec.ProbVec n)
            (cfd : Workspace.Types.CoinFlipDist.CoinFlipDist n S),
            cfd.toPMF b =
              (∏ i : Fin n,
                ENNReal.ofReal (if b.bit i then S.p i else 1 - S.p i))) := by
  intro n hn hmod b r hr
  refine ⟨?_, ?_⟩
  · -- Part (i)
    intro m
    unfold Workspace.Types.PartialDeletionProcess.middleIndicator
    rw [dif_pos hr]
  · -- Part (ii)
    intro S cfd
    exact cfd.prod_factorisation b
