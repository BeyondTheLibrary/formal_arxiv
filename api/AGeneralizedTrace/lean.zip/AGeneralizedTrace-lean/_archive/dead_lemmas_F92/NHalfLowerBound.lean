import Mathlib

open Real

/-- For every natural number `n` with `n ≥ 10^12`,
`((n - 1) / 2 : ℝ) ≥ (n : ℝ) / 3`, where `(n - 1) / 2` on the left is
natural-number truncated division cast to `ℝ`. -/
theorem NHalfLowerBound :
    ∀ (n : ℕ), n ≥ 10 ^ 12 →
      ((((n - 1) / 2 : ℕ) : ℝ)) ≥ (n : ℝ) / 3 := by
  intro n hn
  have hn1 : n ≥ 1 := by omega
  -- Nat-level: 2 * ((n - 1) / 2) ≥ n - 2, equivalently 2 * ((n-1)/2) + 2 ≥ n.
  have hk : 2 * ((n - 1) / 2) + 1 ≥ n - 1 := by
    have h := Nat.div_add_mod (n - 1) 2
    have hmod : (n - 1) % 2 ≤ 1 := by omega
    omega
  have hk' : 2 * ((n - 1) / 2) + 2 ≥ n := by omega
  -- Cast to ℝ.
  have hcast : (2 : ℝ) * (((n - 1) / 2 : ℕ) : ℝ) + 2 ≥ (n : ℝ) := by
    have hcast0 : ((2 * ((n - 1) / 2) + 2 : ℕ) : ℝ) ≥ ((n : ℕ) : ℝ) := by
      exact_mod_cast hk'
    push_cast at hcast0
    linarith
  have h2 : (n : ℝ) ≥ 10 ^ 12 := by exact_mod_cast hn
  nlinarith
