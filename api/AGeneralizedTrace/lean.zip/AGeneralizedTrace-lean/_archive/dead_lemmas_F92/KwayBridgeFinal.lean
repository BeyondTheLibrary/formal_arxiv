import Mathlib
import Workspace.ProofLemmas.GenvConvergence
import Workspace.ProofLemmas.HFourierKwayBoundFromMGFAndLogConcavity
import Workspace.ProofLemmas.MGFOfIteratedConvolution

open scoped Real Complex
open MeasureTheory intervalIntegral

set_option maxHeartbeats 4000000

/-!
# Final assembly of the k ≥ 1 bridge for Lemma 7 (`SublemmaFourierKway`)

This file composes the three unconditional foundations into the k ≥ 1 bridge:

1. `GenvConvergence.T4_modulus_le_circPowR_uncond` :
   `‖∑'_r (∏ j, factor n (ℓ j) r) · e^{-iξr}‖ ≤ circPowR (Genv n) k ξ`.
2. `PeriodicBaseKfoldPeriodisation.periodise_kfold` (with `g := Genv n`) :
   `circPowR (Genv n) k ξ ≤ ∑'_s linPow Genv0 k (ξ + 2πs)`, where
   `Genv0 := Genv n · 1_{[-π,π]}`.
3. `HFourierKwayBoundFromMGFAndLogConcavity` (with `h := linPow Genv0 k`) :
   `∑'_s linPow Genv0 k (ξ + 2πs) ≤ 2 e^{-√n}` for `2 ≤ |ξ| ≤ π`.

## Status of the chain (2026-06-14)

* Step 1 (`T4_modulus_le_circPowR_uncond`) — DONE, sorry-free.
* Step 2 (`periodise_kfold`, base `Genv n`) — the inequality is available; its 6
  Tonelli/integrability side-conditions are discharge-able from `Genv_continuous`,
  `Genv_periodic`, `Genv_nonneg`.
* Step 3 (`HFourierKwayBoundFromMGFAndLogConcavity`, `h := linPow Genv0 k`) — its
  two MGF hypotheses reduce, via `linPow_Genv0_mgf`
  (`∫ e^{√n η} linPow Genv0 (b+1) = (∫ e^{√n ξ} Genv0)^{b+1}`) and
  nonnegativity (so `∫_{Ici 0} ≤ ∫_{Ici 1} ≤ ∫_ℝ`), to the SINGLE remaining gate:

      hGenv0_mgf_le_one :  (∫ ξ, Real.exp (Real.sqrt n * ξ) * Genv0 n ξ) ≤ 1.

  Steps 1 of the gate (weighted single-factor MGF `g(√n) ≤ e²·√(8π/n)`,
  `GenvConvergence.Gweight_le`) and 2 (calibration `α·g(√n) ≤ 1/2`,
  `GenvConvergence.alphaGweight_le_half`) are PROVED sorry-free.

  The gate itself is NOT closed: `Genv0 = Genv·1_{[-π,π]}` is the indicator
  restriction of the CIRCULAR self-convolution series `Genv`, and the exponential
  weight `e^{√n ξ}` is not `2π`-periodic, so the weighted-window induction
  `∫_{-π}^π e^{√n ξ} circPowR(Bbase)(b+1) ξ ≤ g(√n)·(Gint/2π)^b` breaks at the
  shift step (`∫_{-π-η}^{π-η} e^{√n ζ} Bbase ζ dζ` has an η-dependent window that
  cannot be moved to `[-π,π]`).  Closing it requires the paper's f→h *unwrapping*:
  re-baseing the periodisation on the LINEAR series `∑_b (α·Bbase0)^{*b}`
  (`Bbase0 = Bbase·1_{[-π,π]}`), for which `∫ e^{√n}(α Bbase0)^{*b} = (α g(√n))^b`
  factors (`MGFOfConvolution`) and `∑_{b≥1}(α g)^b = α g/(1-α g) ≤ 1` by Step 2.
  That is a structural change to the Step-1/Step-2 chain base and is left open.
-/

namespace KwayBridgeFinal

open GenvConvergence
open T4ToCircPowRPeriodic
open PeriodicBaseKfoldPeriodisation

/-- The compact-support base of the periodisation: `Genv n` restricted to `[-π,π]`. -/
noncomputable def Genv0 (n : ℕ) : ℝ → ℝ :=
  fun x => if |x| ≤ Real.pi then Genv n x else 0

theorem Genv0_nonneg (n : ℕ) (x : ℝ) : 0 ≤ Genv0 n x := by
  unfold Genv0
  split_ifs
  · exact Genv_nonneg n x
  · exact le_refl 0

theorem Genv0_supp (n : ℕ) : ∀ x, |x| > Real.pi → Genv0 n x = 0 := by
  intro x hx
  unfold Genv0
  rw [if_neg (not_le.mpr hx)]

/-- `Genv0 n` equals the indicator of `{x | |x| ≤ π}` applied to `Genv n`. -/
theorem Genv0_eq_indicator (n : ℕ) :
    Genv0 n = Set.indicator {x : ℝ | |x| ≤ Real.pi} (Genv n) := by
  funext x
  unfold Genv0
  by_cases h : |x| ≤ Real.pi
  · have hmem : x ∈ {x : ℝ | |x| ≤ Real.pi} := h
    rw [Set.indicator_of_mem hmem, if_pos h]
  · have hnmem : x ∉ {x : ℝ | |x| ≤ Real.pi} := h
    rw [Set.indicator_of_notMem hnmem, if_neg h]

theorem Genv0_integrable (n : ℕ) (hn : 1 ≤ n) :
    MeasureTheory.Integrable (Genv0 n) := by
  rw [Genv0_eq_indicator]
  apply MeasureTheory.IntegrableOn.integrable_indicator
  · -- IntegrableOn Genv n on the (compact-contained) set {|x| ≤ π}.
    have hms : MeasurableSet {x : ℝ | |x| ≤ Real.pi} :=
      measurableSet_le (Measurable.abs measurable_id) measurable_const
    have hsubset : {x : ℝ | |x| ≤ Real.pi} ⊆ Set.Icc (-Real.pi) Real.pi := by
      intro x hx
      simp only [Set.mem_setOf_eq] at hx
      rw [Set.mem_Icc]
      exact abs_le.mp hx
    have hint_Icc : MeasureTheory.IntegrableOn (Genv n) (Set.Icc (-Real.pi) Real.pi) :=
      (Genv_continuous n hn).continuousOn.integrableOn_compact isCompact_Icc
    exact hint_Icc.mono_set hsubset
  · exact measurableSet_le (Measurable.abs measurable_id) measurable_const

/-! ## Properties of the iterated linear self-convolution `linPow (Genv0 n)`. -/

/-- The recurrence form for `b ≥ 1` matching `MGFOfIteratedConvolution`. -/
theorem linPow_Genv0_rec (n : ℕ) : ∀ b : ℕ, 1 ≤ b → ∀ η : ℝ,
    linPow (Genv0 n) (b + 1) η = ∫ y, linPow (Genv0 n) b y * Genv0 n (η - y) := by
  intro b hb η
  obtain ⟨b', rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.one_le_iff_ne_zero.mp hb)
  rw [show b' + 1 + 1 = b' + 2 from rfl, linPow_succ_succ]

theorem linPow_Genv0_nn (n : ℕ) : ∀ b : ℕ, 1 ≤ b → ∀ η, 0 ≤ linPow (Genv0 n) b η := by
  intro b _ η
  exact linPow_nn (Genv0 n) (Genv0_nonneg n) b η

/-- Each `linPow (Genv0 n) b` is integrable: a `b`-fold convolution of an
integrable function. -/
theorem linPow_Genv0_int (n : ℕ) (hn : 1 ≤ n) :
    ∀ b : ℕ, 1 ≤ b → MeasureTheory.Integrable (linPow (Genv0 n) b) := by
  have hG0_int := Genv0_integrable n hn
  intro b hb
  obtain ⟨b', rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.one_le_iff_ne_zero.mp hb)
  clear hb
  induction b' with
  | zero =>
    show MeasureTheory.Integrable (linPow (Genv0 n) 1)
    rw [linPow_one]
    exact hG0_int
  | succ k ih =>
    -- linPow (Genv0 n) (k+1+1) = convolution (linPow (Genv0 n) (k+1)) (Genv0 n) (lsmul) volume
    have heq : linPow (Genv0 n) (k + 1 + 1) =
        MeasureTheory.convolution (linPow (Genv0 n) (k + 1)) (Genv0 n)
          (ContinuousLinearMap.lsmul ℝ ℝ) MeasureTheory.volume := by
      funext η
      rw [show k + 1 + 1 = k + 2 from rfl, linPow_succ_succ]
      rw [MeasureTheory.convolution_lsmul]
      simp [smul_eq_mul]
    rw [heq]
    exact MeasureTheory.Integrable.integrable_convolution
      (ContinuousLinearMap.lsmul ℝ ℝ) ih hG0_int

/-- `linPow (Genv0 n) b` vanishes outside `[-bπ, bπ]` (support of a `b`-fold
convolution of a function supported in `[-π,π]`). -/
theorem linPow_Genv0_supp (n : ℕ) :
    ∀ b : ℕ, 1 ≤ b → ∀ x, |x| > (b : ℝ) * Real.pi → linPow (Genv0 n) b x = 0 := by
  intro b hb
  obtain ⟨b', rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.one_le_iff_ne_zero.mp hb)
  clear hb
  induction b' with
  | zero =>
    intro x hx
    show linPow (Genv0 n) 1 x = 0
    rw [linPow_one]
    apply Genv0_supp
    have h_cast : ((Nat.succ 0 : ℕ) : ℝ) * Real.pi = Real.pi := by push_cast; ring
    rw [h_cast] at hx
    linarith
  | succ k ih =>
    intro x hx
    have hk1 : (1 : ℕ) ≤ k + 1 := Nat.succ_le_succ (Nat.zero_le _)
    rw [linPow_Genv0_rec n (k + 1) hk1 x]
    have h_pointwise : ∀ y, linPow (Genv0 n) (k + 1) y * Genv0 n (x - y) = 0 := by
      intro y
      by_cases hy : |y| > ((k + 1 : ℕ) : ℝ) * Real.pi
      · rw [ih y hy, zero_mul]
      · push_neg at hy
        have h_xy : |x - y| > Real.pi := by
          have h_abs : |x| - |y| ≤ |x - y| := abs_sub_abs_le_abs_sub _ _
          have h_cast_succ : ((k + 1 + 1 : ℕ) : ℝ) * Real.pi
              = ((k + 1 : ℕ) : ℝ) * Real.pi + Real.pi := by push_cast; ring
          rw [h_cast_succ] at hx
          linarith
        rw [Genv0_supp n (x - y) h_xy, mul_zero]
    rw [show (fun y => linPow (Genv0 n) (k + 1) y * Genv0 n (x - y)) = (fun _ => (0 : ℝ)) by
      funext y; exact h_pointwise y]
    simp

/-! ## MGF factorization of the iterated convolution `linPow (Genv0 n)`. -/

/-- **MGF factorization.**  For every `t` and `b`,
`∫ e^{tη} linPow (Genv0 n) (b+1) η = (∫ e^{tξ} Genv0 n ξ)^{b+1}`.
This is `MGFOfIteratedConvolution` specialised to the compactly-supported base
`Genv0 n` (support `[-π,π]`) and its iterated linear self-convolution `linPow`. -/
theorem linPow_Genv0_mgf (n : ℕ) (hn : 1 ≤ n) (t : ℝ) : ∀ b : ℕ,
    (∫ η, Real.exp (t * η) * linPow (Genv0 n) (b + 1) η)
      = (∫ ξ, Real.exp (t * ξ) * Genv0 n ξ) ^ (b + 1) :=
  MGFOfIteratedConvolution (Genv0 n) (Genv0_nonneg n) (Genv0_integrable n hn)
    Real.pi Real.pi_pos (Genv0_supp n)
    (linPow (Genv0 n)) (linPow_one (Genv0 n)) (linPow_Genv0_rec n)
    (linPow_Genv0_nn n) (linPow_Genv0_int n hn) (linPow_Genv0_supp n) t

end KwayBridgeFinal
