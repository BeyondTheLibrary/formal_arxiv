import Mathlib
import Workspace.ProofLemmas.OneMinusDeltaNonneg
import Workspace.ProofLemmas.SqrtArgNonneg
import Workspace.ProofLemmas.AddOneLeExpNegOnUnitInterval
import Workspace.ProofLemmas.PowMonoBaseLeBaseNonneg
import Workspace.ProofLemmas.ExpDeltaOver20PowZ
import Workspace.ProofLemmas.ExpDeltaZSlack

set_option maxHeartbeats 4000000

open Real

namespace Workspace.ProofLemmas

/-- For every real `ξ` with `1/3 ≤ |ξ|` and `|ξ| ≤ π`, `1 - cos ξ ≥ 1/19`. -/
private theorem OneMinusCosLowerBoundThird
    (ξ : ℝ) (hlow : (1 : ℝ) / 3 ≤ |ξ|) (hhigh : |ξ| ≤ Real.pi) :
    1 - Real.cos ξ ≥ 1 / 19 := by
  -- Reduce to the nonnegative variable y = |ξ| using cos_abs.
  rw [show Real.cos ξ = Real.cos |ξ| from (Real.cos_abs ξ).symm]
  set y := |ξ|
  have hy_pos : 0 < y := by
    have := abs_nonneg ξ
    linarith
  have h_cos_eq : Real.cos y = 1 - 2 * Real.sin (y/2) ^ 2 := by
    conv_lhs => rw [show y = 2 * (y/2) by ring]
    exact Real.cos_two_mul_eq_one_sub (y/2)
  rw [h_cos_eq]
  have hy2_pos : 0 < y/2 := by linarith
  have hy2_lb : 1/6 ≤ y/2 := by linarith
  have hy2_ub : y/2 ≤ Real.pi/2 := by linarith
  -- sin is monotone on [0, π/2]; use Real.sin_le_sin_of_le_of_le_pi_div_two
  have hsin_mono : Real.sin (1/6) ≤ Real.sin (y/2) := by
    apply Real.sin_le_sin_of_le_of_le_pi_div_two
    · linarith
    · exact hy2_ub
    · linarith
  -- sin(1/6) ≥ 1/6 - (1/6)^3/4 by Real.sin_gt_sub_cube.
  have hsin_16_lb : Real.sin (1/6) ≥ 1/6 - (1/6)^3/4 := by
    have h := Real.sin_gt_sub_cube (x := 1/6) (by norm_num) (by norm_num)
    linarith
  have hsin_lb_strong : Real.sin (y/2) ≥ 1/6 - (1/6)^3/4 := by linarith
  have hsin_lb_pos : (0:ℝ) ≤ 1/6 - (1/6)^3/4 := by norm_num
  have hsin_sq_lb : Real.sin (y/2) ^ 2 ≥ (1/6 - (1/6)^3/4)^2 := by
    nlinarith [hsin_lb_strong, hsin_lb_pos]
  -- (1/6 - 1/864)² = (143/864)² ≈ 0.02740 ≥ 1/38, so 2·sin²(y/2) ≥ 1/19.
  nlinarith [hsin_sq_lb]

/-- Adapter version of `KeyDecayInequality` with the looser threshold `|ξ| ≥ 1/3`. -/
private theorem KeyDecayInequalityThird
    (δ : ℝ) (hδpos : 0 < δ) (hδle : δ ≤ 1 / 2)
    (ξ : ℝ) (hξlo : (1 : ℝ) / 3 ≤ |ξ|) (hξhi : |ξ| ≤ Real.pi) :
    Real.exp (δ / 20) * (1 - δ) ≤ Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
  have hδle1 : δ ≤ 1 := le_trans hδle (by norm_num)
  have h1mδ : 0 ≤ 1 - δ := OneMinusDeltaNonneg δ hδle1
  have hsqrtArg : 0 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 := SqrtArgNonneg δ ξ
  have hLHSnn : 0 ≤ Real.exp (δ / 20) * (1 - δ) :=
    mul_nonneg (le_of_lt (Real.exp_pos _)) h1mδ
  apply Real.le_sqrt_of_sq_le
  -- Step A: (1 - δ/20) ≤ exp (-δ/20).
  have hδ20le1 : δ / 20 ≤ 1 := by linarith
  have hδ20nn : 0 ≤ δ / 20 := by linarith
  have hExpNeg : 1 - δ / 20 ≤ Real.exp (-(δ / 20)) :=
    AddOneLeExpNegOnUnitInterval (δ / 20) hδ20nn hδ20le1
  have h1mδ20nn : 0 ≤ 1 - δ / 20 := by linarith
  have hExpNegPos : 0 < Real.exp (-(δ / 20)) := Real.exp_pos _
  have hSq : (1 - δ / 20) ^ 2 ≤ Real.exp (-(δ / 20)) ^ 2 := by
    have := mul_le_mul hExpNeg hExpNeg h1mδ20nn (le_of_lt hExpNegPos)
    nlinarith [hExpNeg, h1mδ20nn, hExpNegPos.le]
  have hExpSq : Real.exp (-(δ / 20)) ^ 2 = Real.exp (-(δ / 10)) := by
    rw [sq, ← Real.exp_add]
    ring_nf
  have hSq' : (1 - δ / 20) ^ 2 ≤ Real.exp (-(δ / 10)) := by
    rw [← hExpSq]; exact hSq
  -- Step B: cos ξ ≤ 18/19 from `OneMinusCosLowerBoundThird`.
  have hCosUB : Real.cos ξ ≤ 18 / 19 := by
    have := OneMinusCosLowerBoundThird ξ hξlo hξhi
    linarith
  -- Step C: polynomial inequality (1 - δ)^2 ≤ (1 - δ/20)^2 * (1 - 36δ/19 + δ^2).
  have hLowerArg : 1 - 2 * δ * (18/19) + δ ^ 2 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 := by
    have hδpos' : 0 ≤ δ := le_of_lt hδpos
    nlinarith [hCosUB, hδpos']
  have hPoly : (1 - δ) ^ 2 ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * (18/19) + δ ^ 2) := by
    have hδpos' : 0 ≤ δ := le_of_lt hδpos
    nlinarith [hδpos', hδle, sq_nonneg δ, sq_nonneg (1 - δ), sq_nonneg (1 - δ / 20),
               mul_nonneg hδpos' hδpos', mul_self_nonneg δ]
  have hPoly' : (1 - δ) ^ 2 ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
    have hsq20nn : 0 ≤ (1 - δ / 20) ^ 2 := sq_nonneg _
    calc (1 - δ) ^ 2
        ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * (18/19) + δ ^ 2) := hPoly
      _ ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
          exact mul_le_mul_of_nonneg_left hLowerArg hsq20nn
  have hExp10pos : 0 < Real.exp (δ / 10) := Real.exp_pos _
  have hExpInv : Real.exp (δ / 10) * Real.exp (-(δ / 10)) = 1 := by
    rw [← Real.exp_add]
    ring_nf
    exact Real.exp_zero
  have hOneSqMul : Real.exp (δ / 10) * (1 - δ) ^ 2 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 := by
    have h1mδsq_nn : 0 ≤ (1 - δ) ^ 2 := sq_nonneg _
    have hStepHelper : (1 - δ) ^ 2 ≤ Real.exp (-(δ / 10)) * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
      calc (1 - δ) ^ 2
          ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := hPoly'
        _ ≤ Real.exp (-(δ / 10)) * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
            exact mul_le_mul_of_nonneg_right hSq' hsqrtArg
    have := mul_le_mul_of_nonneg_left hStepHelper (le_of_lt hExp10pos)
    have heq : Real.exp (δ / 10) * (Real.exp (-(δ / 10)) * (1 - 2 * δ * Real.cos ξ + δ ^ 2))
             = 1 - 2 * δ * Real.cos ξ + δ ^ 2 := by
      rw [← mul_assoc, hExpInv, one_mul]
    linarith [this, heq.le, heq.ge]
  have hexp_split : Real.exp (δ / 20) ^ 2 = Real.exp (δ / 10) := by
    rw [sq, ← Real.exp_add]
    ring_nf
  have hLHSsq : (Real.exp (δ / 20) * (1 - δ)) ^ 2 = Real.exp (δ / 10) * (1 - δ) ^ 2 := by
    rw [mul_pow, hexp_split]
  rw [hLHSsq]
  exact hOneSqMul

/-- Sublemma adapting parts (b'), (c') of `SublemmaFourierThree` to the looser
threshold `|ξ| ≥ 1/3`. -/
theorem SublemmaFourierThreeBcThird :
    -- (b') T₂ decay for `|ξ| ≥ 1/3`:
    (∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ), |ξ| ≤ Real.pi → (1 / 3 : ℝ) ≤ |ξ| →
          (1 - δ) ^ (z + 1) * Real.exp (δ * (z : ℝ) / 20)
            ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1)) ∧
    -- (c') T₃ decay for `|ξ| ≥ 1/3` (twin of (b')).
    (∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ), |ξ| ≤ Real.pi → (1 / 3 : ℝ) ≤ |ξ| →
          (1 - δ) ^ (z + 1) * Real.exp (δ * (z : ℝ) / 20)
            ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1)) := by
  have part_bc' :
      ∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ), |ξ| ≤ Real.pi → (1 / 3 : ℝ) ≤ |ξ| →
          (1 - δ) ^ (z + 1) * Real.exp (δ * (z : ℝ) / 20)
            ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1) := by
    intro δ hδ_pos hδ_le z ξ hξ_pi hξ_third
    have hδ_le_one : δ ≤ 1 := by linarith
    have h_one_minus_delta_nonneg : 0 ≤ 1 - δ := OneMinusDeltaNonneg δ hδ_le_one
    have h_key : Real.exp (δ / 20) * (1 - δ) ≤
        Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2) :=
      KeyDecayInequalityThird δ hδ_pos hδ_le ξ hξ_third hξ_pi
    have h_lhs_nonneg : 0 ≤ Real.exp (δ / 20) * (1 - δ) :=
      mul_nonneg (Real.exp_pos _).le h_one_minus_delta_nonneg
    have h_pow : (Real.exp (δ / 20) * (1 - δ)) ^ (z + 1) ≤
        (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1) :=
      PowMonoBaseLeBaseNonneg _ _ h_lhs_nonneg h_key (z + 1)
    have h_distrib : (Real.exp (δ / 20) * (1 - δ)) ^ (z + 1) =
        Real.exp (δ * ((z : ℝ) + 1) / 20) * (1 - δ) ^ (z + 1) := by
      rw [mul_pow, ExpDeltaOver20PowZ z δ]
    rw [h_distrib] at h_pow
    have h_pow_nonneg : 0 ≤ (1 - δ) ^ (z + 1) := pow_nonneg h_one_minus_delta_nonneg _
    have h_slack : Real.exp (δ * (z : ℝ) / 20) ≤ Real.exp (δ * ((z : ℝ) + 1) / 20) := by
      have h := ExpDeltaZSlack z δ hδ_pos hδ_le
      convert h using 2
    calc (1 - δ) ^ (z + 1) * Real.exp (δ * (z : ℝ) / 20)
        ≤ (1 - δ) ^ (z + 1) * Real.exp (δ * ((z : ℝ) + 1) / 20) :=
          mul_le_mul_of_nonneg_left h_slack h_pow_nonneg
      _ = Real.exp (δ * ((z : ℝ) + 1) / 20) * (1 - δ) ^ (z + 1) := by ring
      _ ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1) := h_pow
  exact ⟨part_bc', part_bc'⟩

end Workspace.ProofLemmas
