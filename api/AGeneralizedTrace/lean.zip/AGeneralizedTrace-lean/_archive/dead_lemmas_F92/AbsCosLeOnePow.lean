import Mathlib

open Real

/-- For every real number `t` and every natural number `m`, `|cos t|^m ≤ 1`. -/
theorem AbsCosLeOnePow :
    ∀ (t : ℝ) (m : ℕ), |Real.cos t| ^ m ≤ 1 := by
  intro t m
  apply pow_le_one₀
  · exact abs_nonneg _
  · exact Real.abs_cos_le_one t
