import Mathlib

open MeasureTheory

namespace Workspace.ProofLemmas.UnimodalLatticeSumBound

/-!
# Unimodal lattice-sum bound

For a nonnegative, integrable function `f : ℝ → ℝ` that is monotone
(nondecreasing) up to a lattice peak index `p` and antitone (nonincreasing)
after it, the lattice sum over `{0, …, N-1}` (shifted by `x₀`) is bounded by the
peak value plus the whole-line integral:

  `∑_{i ∈ range N} f (x₀ + i) ≤ f (x₀ + p) + ∫_ℝ f`.

This is the discrete-vs-continuous comparison used to bound `∑ √p_i` by an
integral of the Gaussian envelope (toward Fact 9 of Rivkin–Valiant–Valiant
2024). The proof splits `range N` at the peak index `p`, applies
`MonotoneOn.sum_le_integral` on the increasing part and
`AntitoneOn.sum_le_integral` on the decreasing part, absorbs the single peak
step into `f (x₀ + p)`, and finally enlarges the finite integral to the whole
line using nonnegativity.
-/

/-- Splitting `Finset.range N` at `p < N` into `[0,p)`, the singleton `{p}`,
and `(p, N)`. -/
theorem sum_split_at (f : ℝ → ℝ) (x₀ : ℝ) (N p : ℕ) (hp : p < N) :
    (∑ i ∈ Finset.range N, f (x₀ + (i : ℝ)))
      = (∑ i ∈ Finset.range p, f (x₀ + (i : ℝ)))
        + f (x₀ + (p : ℝ))
        + (∑ i ∈ Finset.range (N - 1 - p), f (x₀ + ((p : ℝ) + 1 + (i : ℝ)))) := by
  conv_lhs => rw [show N = (p + 1) + (N - 1 - p) by omega]
  rw [Finset.sum_range_add, Finset.sum_range_succ]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  push_cast; ring_nf

/-- **Core unimodal bound.** `f` nonneg everywhere, integrable on `ℝ`, monotone
on `[x₀, x₀+p]`, antitone on `[x₀+p, x₀+N]`.  Then the lattice sum is at most
`f (x₀+p) + ∫_ℝ f`. -/
theorem unimodal_sum_le_peak_add_integral
    (f : ℝ → ℝ) (x₀ : ℝ) (N p : ℕ) (hp : p < N)
    (hf_nonneg : ∀ x, 0 ≤ f x)
    (hf_int : Integrable f)
    (hmono : MonotoneOn f (Set.Icc x₀ (x₀ + (p : ℝ))))
    (hanti : AntitoneOn f (Set.Icc (x₀ + (p : ℝ)) (x₀ + (N : ℝ)))) :
    (∑ i ∈ Finset.range N, f (x₀ + (i : ℝ)))
      ≤ f (x₀ + (p : ℝ)) + ∫ x, f x := by
  have hp_le : (p : ℝ) ≤ (N : ℝ) := by exact_mod_cast (le_of_lt hp)
  -- Increasing part: ∑_{i<p} f(x₀+i) ≤ ∫_{x₀}^{x₀+p} f.
  have hinc : (∑ i ∈ Finset.range p, f (x₀ + (i : ℝ)))
      ≤ ∫ x in x₀..x₀ + (p : ℝ), f x := by
    have := MonotoneOn.sum_le_integral (x₀ := x₀) (a := p) (f := f) hmono
    simpa using this
  -- Decreasing part.
  set x₁ : ℝ := x₀ + (p : ℝ) with hx₁
  set M : ℕ := N - 1 - p with hM
  have hM_le : ((M : ℝ)) ≤ (N : ℝ) - (p : ℝ) := by
    have h1 : (N - 1 - p : ℕ) ≤ N - p := by omega
    have h2 : ((N - p : ℕ) : ℝ) = (N : ℝ) - (p : ℝ) := by rw [Nat.cast_sub (by omega)]
    rw [hM]
    calc ((N - 1 - p : ℕ) : ℝ) ≤ ((N - p : ℕ) : ℝ) := by exact_mod_cast h1
      _ = (N : ℝ) - (p : ℝ) := h2
  have hxM_le : x₁ + (M : ℝ) ≤ x₀ + (N : ℝ) := by rw [hx₁]; linarith
  have hanti' : AntitoneOn f (Set.Icc x₁ (x₁ + (M : ℝ))) := by
    apply hanti.mono
    exact Set.Icc_subset_Icc (le_refl _) hxM_le
  have hdec_cmp := AntitoneOn.sum_le_integral (x₀ := x₁) (a := M) (f := f) hanti'
  -- LHS of hdec_cmp matches our shifted sum.
  have hlhs : (∑ i ∈ Finset.range M, f (x₁ + ((i + 1 : ℕ) : ℝ)))
      = (∑ i ∈ Finset.range (N - 1 - p), f (x₀ + ((p : ℝ) + 1 + (i : ℝ)))) := by
    rw [hM]
    apply Finset.sum_congr rfl
    intro i _
    rw [hx₁]; push_cast; ring_nf
  rw [hlhs] at hdec_cmp
  -- Enlarge ∫_{x₁}^{x₁+M} f to ∫_{x₁}^{x₀+N} f (f ≥ 0, larger interval).
  have hf_intble : ∀ a b : ℝ, IntervalIntegrable f volume a b :=
    fun a b => hf_int.intervalIntegrable
  have hae_nonneg : ∀ a b : ℝ, 0 ≤ᵐ[volume.restrict (Set.Ioc a b)] f :=
    fun a b => ae_of_all _ (fun x => hf_nonneg x)
  have hx₁_le : x₁ ≤ x₁ + (M : ℝ) := by
    have : (0 : ℝ) ≤ (M : ℝ) := Nat.cast_nonneg _
    linarith
  have hdec_ext : (∫ x in x₁..(x₁ + (M : ℝ)), f x) ≤ ∫ x in x₁..(x₀ + (N : ℝ)), f x := by
    apply intervalIntegral.integral_mono_interval (le_refl x₁) hx₁_le hxM_le
    · exact hae_nonneg _ _
    · exact hf_intble _ _
  have hdec : (∑ i ∈ Finset.range (N - 1 - p), f (x₀ + ((p : ℝ) + 1 + (i : ℝ))))
      ≤ ∫ x in x₁..(x₀ + (N : ℝ)), f x := le_trans hdec_cmp hdec_ext
  -- Combine the two integrals into ∫_{x₀}^{x₀+N}.
  have hadd : (∫ x in x₀..x₁, f x) + (∫ x in x₁..(x₀ + (N : ℝ)), f x)
      = ∫ x in x₀..(x₀ + (N : ℝ)), f x :=
    intervalIntegral.integral_add_adjacent_intervals (hf_intble _ _) (hf_intble _ _)
  -- Bound ∫_{x₀}^{x₀+N} by ∫_ℝ.
  have hx₀_le : x₀ ≤ x₀ + (N : ℝ) := by
    have : (0 : ℝ) ≤ (N : ℝ) := Nat.cast_nonneg _
    linarith
  have hfin_le : (∫ x in x₀..(x₀ + (N : ℝ)), f x) ≤ ∫ x, f x := by
    rw [intervalIntegral.integral_of_le hx₀_le]
    exact MeasureTheory.setIntegral_le_integral hf_int (ae_of_all _ (fun x => hf_nonneg x))
  -- Assemble.
  rw [sum_split_at f x₀ N p hp]
  have : (∑ i ∈ Finset.range p, f (x₀ + (i : ℝ)))
        + f (x₀ + (p : ℝ))
        + (∑ i ∈ Finset.range (N - 1 - p), f (x₀ + ((p : ℝ) + 1 + (i : ℝ))))
      ≤ (∫ x in x₀..x₁, f x) + f (x₀ + (p : ℝ)) + (∫ x in x₁..(x₀ + (N : ℝ)), f x) := by
    have hinc' : (∑ i ∈ Finset.range p, f (x₀ + (i : ℝ))) ≤ ∫ x in x₀..x₁, f x := by
      rw [hx₁]; exact hinc
    linarith [hinc', hdec]
  calc (∑ i ∈ Finset.range p, f (x₀ + (i : ℝ)))
        + f (x₀ + (p : ℝ))
        + (∑ i ∈ Finset.range (N - 1 - p), f (x₀ + ((p : ℝ) + 1 + (i : ℝ))))
      ≤ (∫ x in x₀..x₁, f x) + f (x₀ + (p : ℝ)) + (∫ x in x₁..(x₀ + (N : ℝ)), f x) := this
    _ = f (x₀ + (p : ℝ)) + ((∫ x in x₀..x₁, f x) + (∫ x in x₁..(x₀ + (N : ℝ)), f x)) := by ring
    _ = f (x₀ + (p : ℝ)) + (∫ x in x₀..(x₀ + (N : ℝ)), f x) := by rw [hadd]
    _ ≤ f (x₀ + (p : ℝ)) + ∫ x, f x := by linarith [hfin_le]

end Workspace.ProofLemmas.UnimodalLatticeSumBound
