import Mathlib
import Workspace.ProofLemmas.OneMinusDeltaNonneg
import Workspace.ProofLemmas.SqrtArgNonneg
import Workspace.ProofLemmas.SqrtSqLowerBound

/-- For every real `δ` with `0 < δ ≤ 1/2` and every real `ξ`,
    `1 - δ ≤ sqrt (1 - 2 * δ * cos ξ + δ^2)`. -/
theorem SqrtRBoundsOneMinusDelta :
    ∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
      ∀ (ξ : ℝ), 1 - δ ≤ Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
  intro δ hδpos hδhalf ξ
  -- We have (1 - δ)^2 ≤ 1 - 2δ cos ξ + δ^2
  have h_sq : (1 - δ) ^ 2 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 :=
    SqrtSqLowerBound δ hδpos hδhalf ξ
  -- Apply Real.le_sqrt_of_sq_le
  exact Real.le_sqrt_of_sq_le h_sq
