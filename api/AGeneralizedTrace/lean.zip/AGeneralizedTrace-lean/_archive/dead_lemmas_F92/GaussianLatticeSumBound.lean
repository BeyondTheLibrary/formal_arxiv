import Mathlib

open MeasureTheory

namespace Workspace.ProofLemmas.GaussianLatticeSumBound

/-!
# Gaussian lattice-sum bound

Toward Fact 9 (Rivkin–Valiant–Valiant 2024).  Let `g n x := exp(-(x - n/2)² / n)`
be the (unnormalised) Gaussian with peak at `x = n/2`, "variance scale" `n`.

We prove:

* `gauss_integral` : `∫_ℝ g n = √(π n)`  (for `n ≥ 1`).
* `gauss_le_one`   : `g n x ≤ 1` for all `x`.
* `gauss_lattice_sum_le` :
    `∑_{i ∈ range (n+1)} g n i ≤ 2 + √(π n)`.

The lattice-sum bound is the unimodal comparison: the Gaussian is increasing on
`(-∞, n/2]` and decreasing on `[n/2, ∞)`, so the sum over `{0,…,n}` is at most
the integral over `ℝ` plus the two central lattice terms straddling the peak
`n/2` (each `≤ 1`).  We use the standard `MonotoneOn.sum_le_integral` /
`AntitoneOn.sum_le_integral` comparisons on the two monotone halves split at the
integer `p := n/2` (nat division) on the left and `p+1` on the right; the two
terms `g n p` and `g n (p+1)` are the budget.

The constant `2` rather than `1` is the price of a non-lattice peak for odd `n`;
for even `n` the peak is a lattice point and the sharp budget is `1`, but the
uniform `+2` is what we carry forward.
-/

/-- The (unnormalised) Gaussian envelope shape with peak `n/2`, scale `n`. -/
noncomputable def g (n : ℕ) (x : ℝ) : ℝ := Real.exp (-(x - (n : ℝ) / 2) ^ 2 / (n : ℝ))

theorem g_nonneg (n : ℕ) (x : ℝ) : 0 ≤ g n x := (Real.exp_pos _).le

theorem g_le_one (n : ℕ) (hn : 1 ≤ n) (x : ℝ) : g n x ≤ 1 := by
  unfold g
  rw [show (1 : ℝ) = Real.exp 0 by rw [Real.exp_zero]]
  apply Real.exp_le_exp.mpr
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  have hsq : 0 ≤ (x - (n : ℝ) / 2) ^ 2 := sq_nonneg _
  have hdiv : 0 ≤ (x - (n : ℝ) / 2) ^ 2 / (n : ℝ) := div_nonneg hsq hn'.le
  rw [neg_div]
  linarith

/-- `g n` is integrable on `ℝ`. -/
theorem g_integrable (n : ℕ) (hn : 1 ≤ n) : Integrable (g n) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  -- g n x = exp(-(1/n) (x - n/2)²); a shifted/scaled Gaussian.
  have hcomp : (g n) = (fun x => Real.exp (-(1 / (n : ℝ)) * (x - (n : ℝ) / 2) ^ 2)) := by
    funext x; unfold g; congr 1; field_simp
  rw [hcomp]
  have hbase : Integrable (fun y => Real.exp (-(1 / (n : ℝ)) * y ^ 2)) :=
    integrable_exp_neg_mul_sq (by positivity)
  have := hbase.comp_sub_right ((n : ℝ) / 2)
  simpa using this

/-- `∫_ℝ g n = √(π n)`. -/
theorem gauss_integral (n : ℕ) (hn : 1 ≤ n) :
    (∫ x, g n x) = Real.sqrt (Real.pi * (n : ℝ)) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  have hcomp : (g n) = (fun x => Real.exp (-(1 / (n : ℝ)) * (x - (n : ℝ) / 2) ^ 2)) := by
    funext x; unfold g; congr 1; field_simp
  rw [hcomp]
  -- shift invariance then integral_gaussian
  have hshift : (∫ x, Real.exp (-(1 / (n : ℝ)) * (x - (n : ℝ) / 2) ^ 2))
        = ∫ x, Real.exp (-(1 / (n : ℝ)) * x ^ 2) := by
    have := MeasureTheory.integral_add_right_eq_self (μ := (volume : Measure ℝ))
      (fun y => Real.exp (-(1 / (n : ℝ)) * y ^ 2)) (-( (n : ℝ) / 2))
    simpa [sub_eq_add_neg] using this
  rw [hshift, integral_gaussian]
  rw [show Real.pi / (1 / (n : ℝ)) = Real.pi * (n : ℝ) by field_simp]

/-- `g n` is monotone (nondecreasing) on `(-∞, n/2]`. -/
theorem gauss_monotone_left (n : ℕ) (hn : 1 ≤ n) :
    MonotoneOn (g n) (Set.Iic ((n : ℝ) / 2)) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  intro x hx y hy hxy
  unfold g
  apply Real.exp_le_exp.mpr
  rw [neg_div, neg_div, neg_le_neg_iff]
  rw [div_le_div_iff_of_pos_right hn']
  -- (y - n/2)² ≤ (x - n/2)² since both ≤ n/2, y ≥ x means |y-n/2| ≤ |x-n/2|.
  have hx2 : x ≤ (n : ℝ) / 2 := hx
  have hy2 : y ≤ (n : ℝ) / 2 := hy
  nlinarith [hxy, hx2, hy2]

/-- `g n` is antitone (nonincreasing) on `[n/2, ∞)`. -/
theorem gauss_antitone_right (n : ℕ) (hn : 1 ≤ n) :
    AntitoneOn (g n) (Set.Ici ((n : ℝ) / 2)) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  intro x hx y hy hxy
  unfold g
  apply Real.exp_le_exp.mpr
  rw [neg_div, neg_div, neg_le_neg_iff]
  rw [div_le_div_iff_of_pos_right hn']
  have hx2 : (n : ℝ) / 2 ≤ x := hx
  have hy2 : (n : ℝ) / 2 ≤ y := hy
  nlinarith [hxy, hx2, hy2]

/-- **Gaussian lattice-sum bound (the step-3 estimate toward Fact 9).**
`∑_{i ∈ range (n+1)} g n i ≤ 2 + √(π n)` for `n ≥ 1`.

Split the sum at the central indices `p := n/2` and `p+1`: the left tail
`{0,…,p-1}` is dominated by `∫_0^p g` (monotone), the right tail
`{p+2,…,n}` by `∫_{p+1}^{n} g` (antitone), and the two central terms `g p`,
`g (p+1)` are each `≤ 1`.  The two interval integrals together are `≤ ∫_ℝ g =
√(π n)`. -/
theorem gauss_lattice_sum_le (n : ℕ) (hn : 1 ≤ n) :
    (∑ i ∈ Finset.range (n + 1), g n (i : ℝ)) ≤ 2 + Real.sqrt (Real.pi * (n : ℝ)) := by
  have hn' : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn
  set p : ℕ := n / 2 with hp
  -- p ≤ n/2 ≤ p+1 (real)
  have hp_le_half : (p : ℝ) ≤ (n : ℝ) / 2 := by
    rw [hp]; rw [le_div_iff₀ (by norm_num : (0:ℝ) < 2)]
    have : 2 * (n / 2) ≤ n := Nat.mul_div_le n 2
    calc ((n / 2 : ℕ) : ℝ) * 2 = ((2 * (n / 2) : ℕ) : ℝ) := by push_cast; ring
      _ ≤ (n : ℝ) := by exact_mod_cast this
  have hhalf_le_p1 : (n : ℝ) / 2 ≤ (p : ℝ) + 1 := by
    rw [hp]; rw [div_le_iff₀ (by norm_num : (0:ℝ) < 2)]
    have : n ≤ 2 * (n / 2) + 1 := by omega
    calc (n : ℝ) ≤ ((2 * (n / 2) + 1 : ℕ) : ℝ) := by exact_mod_cast this
      _ = ((n / 2 : ℕ) : ℝ) * 2 + 1 := by push_cast; ring
      _ ≤ ((n / 2 : ℕ) : ℝ) * 2 + 2 := by linarith
      _ = (((n / 2 : ℕ) : ℝ) + 1) * 2 := by ring
  have hp1_le_n : p + 1 ≤ n := by omega
  -- integrability and nonnegativity
  have hg_int := g_integrable n hn
  have hg_nn := g_nonneg n
  have hf_intble : ∀ a b : ℝ, IntervalIntegrable (g n) volume a b :=
    fun a b => hg_int.intervalIntegrable
  set M : ℕ := n - (p + 1) with hM
  have hM_eq : (p + 1) + M = n := by omega
  have hMcast : ((p : ℝ) + 1) + (M : ℝ) = (n : ℝ) := by
    have : ((p + 1 + M : ℕ) : ℝ) = (n : ℝ) := by exact_mod_cast hM_eq
    push_cast at this; linarith
  -- Decompose the sum.
  have hdecomp : (∑ i ∈ Finset.range (n + 1), g n (i : ℝ))
      = (∑ i ∈ Finset.range p, g n (i : ℝ))
        + g n (p : ℝ) + g n ((p : ℝ) + 1)
        + (∑ j ∈ Finset.range M, g n (((p : ℝ) + 1) + ((j : ℝ) + 1))) := by
    have hsplit : n + 1 = (p + 1 + 1) + M := by omega
    rw [hsplit, Finset.sum_range_add, Finset.sum_range_succ, Finset.sum_range_succ]
    have hb1 : g n ((p + 1 : ℕ) : ℝ) = g n ((p : ℝ) + 1) := by norm_cast
    rw [hb1]
    congr 1
    apply Finset.sum_congr rfl
    intro j _; congr 1; push_cast; ring
  -- LEFT: ∑_{i<p} g i ≤ ∫_0^p g.
  have hmono : MonotoneOn (g n) (Set.Icc (0 : ℝ) (0 + (p : ℝ))) := by
    apply (gauss_monotone_left n hn).mono
    intro x hx
    simp only [zero_add, Set.mem_Icc] at hx
    exact Set.mem_Iic.mpr (le_trans hx.2 hp_le_half)
  have hleft : (∑ i ∈ Finset.range p, g n ((i : ℝ))) ≤ ∫ x in (0:ℝ)..(p : ℝ), g n x := by
    have := MonotoneOn.sum_le_integral (x₀ := (0:ℝ)) (a := p) (f := g n) hmono
    simpa using this
  -- RIGHT: ∑_{j < M} g ((p+1)+(j+1)) ≤ ∫_{p+1}^{p+1+M} g.
  have hanti : AntitoneOn (g n) (Set.Icc ((p : ℝ) + 1) (((p : ℝ) + 1) + (M : ℝ))) := by
    apply (gauss_antitone_right n hn).mono
    intro x hx
    simp only [Set.mem_Icc] at hx
    exact Set.mem_Ici.mpr (le_trans hhalf_le_p1 hx.1)
  have hright_cmp := AntitoneOn.sum_le_integral (x₀ := ((p : ℝ) + 1)) (a := M) (f := g n) hanti
  have hright : (∑ j ∈ Finset.range M, g n (((p : ℝ) + 1) + ((j : ℝ) + 1)))
      ≤ ∫ x in ((p : ℝ) + 1)..(n : ℝ), g n x := by
    rw [← hMcast]
    have hcast : (∑ j ∈ Finset.range M, g n (((p : ℝ) + 1) + ((j + 1 : ℕ) : ℝ)))
        = (∑ j ∈ Finset.range M, g n (((p : ℝ) + 1) + ((j : ℝ) + 1))) := by
      apply Finset.sum_congr rfl; intro j _; push_cast; ring_nf
    rw [hcast] at hright_cmp
    exact hright_cmp
  -- combine integrals: ∫_0^p + ∫_{p+1}^{n} ≤ ∫_ℝ g.
  have hp_le_p1 : (0:ℝ) ≤ (p : ℝ) := Nat.cast_nonneg _
  have h0_le_n : (0:ℝ) ≤ (n : ℝ) := Nat.cast_nonneg _
  -- ∫_0^p g ≤ ∫_{Ioc 0 p} g ≤ ∫_ℝ g  and similarly for the right; but the two
  -- intervals are disjoint, so add: ∫_0^p + ∫_{p+1}^n ≤ ∫_0^n ≤ ∫_ℝ.
  have hint_p_le_p1 : (∫ x in (0:ℝ)..(p : ℝ), g n x) ≤ ∫ x in (0:ℝ)..((p:ℝ)+1), g n x := by
    apply intervalIntegral.integral_mono_interval (le_refl _) hp_le_p1 (by linarith)
    · exact ae_of_all _ (fun x => hg_nn x)
    · exact hf_intble _ _
  have hadd : (∫ x in (0:ℝ)..((p:ℝ)+1), g n x) + (∫ x in ((p : ℝ) + 1)..(n : ℝ), g n x)
      = ∫ x in (0:ℝ)..(n : ℝ), g n x :=
    intervalIntegral.integral_add_adjacent_intervals (hf_intble _ _) (hf_intble _ _)
  have hint_n_le_R : (∫ x in (0:ℝ)..(n : ℝ), g n x) ≤ ∫ x, g n x := by
    rw [intervalIntegral.integral_of_le h0_le_n]
    exact MeasureTheory.setIntegral_le_integral hg_int (ae_of_all _ (fun x => hg_nn x))
  have hint_total : (∫ x in (0:ℝ)..(p : ℝ), g n x) + (∫ x in ((p : ℝ) + 1)..(n : ℝ), g n x)
      ≤ ∫ x, g n x := by
    calc (∫ x in (0:ℝ)..(p : ℝ), g n x) + (∫ x in ((p : ℝ) + 1)..(n : ℝ), g n x)
        ≤ (∫ x in (0:ℝ)..((p:ℝ)+1), g n x) + (∫ x in ((p : ℝ) + 1)..(n : ℝ), g n x) := by
          linarith [hint_p_le_p1]
      _ = ∫ x in (0:ℝ)..(n : ℝ), g n x := hadd
      _ ≤ ∫ x, g n x := hint_n_le_R
  -- central terms ≤ 1
  have hcp : g n (p : ℝ) ≤ 1 := g_le_one n hn _
  have hcp1 : g n ((p : ℝ) + 1) ≤ 1 := g_le_one n hn _
  -- assemble
  rw [hdecomp]
  have hsumbound : (∑ i ∈ Finset.range p, g n (i : ℝ))
        + (∑ j ∈ Finset.range M, g n (((p : ℝ) + 1) + ((j : ℝ) + 1)))
      ≤ ∫ x, g n x := by linarith [hleft, hright, hint_total]
  rw [gauss_integral n hn] at hsumbound
  linarith [hcp, hcp1, hsumbound]

/-! ## General peak / scale version

`gc s c x := exp(-(x - c)² / s)`: Gaussian with arbitrary peak `c` and scale
`s > 0`.  This is what the upper binomial envelope feeds into: there the peak is
`c = n/2` but the scale is `2n` (envelope exponent constant `1`, halved by the
square root), so the fixed `g n` above (scale `n`) does not match. -/

/-- General Gaussian with peak `c`, scale `s`. -/
noncomputable def gc (s c : ℝ) (x : ℝ) : ℝ := Real.exp (-(x - c) ^ 2 / s)

theorem gc_nonneg (s c x : ℝ) : 0 ≤ gc s c x := (Real.exp_pos _).le

theorem gc_le_one (s : ℝ) (hs : 0 < s) (c x : ℝ) : gc s c x ≤ 1 := by
  unfold gc
  rw [show (1 : ℝ) = Real.exp 0 by rw [Real.exp_zero]]
  apply Real.exp_le_exp.mpr
  rw [neg_div]
  have : 0 ≤ (x - c) ^ 2 / s := div_nonneg (sq_nonneg _) hs.le
  linarith

theorem gc_integrable (s : ℝ) (hs : 0 < s) (c : ℝ) : Integrable (gc s c) := by
  have hcomp : (gc s c) = (fun x => Real.exp (-(1 / s) * (x - c) ^ 2)) := by
    funext x; unfold gc; congr 1; field_simp
  rw [hcomp]
  have hbase : Integrable (fun y => Real.exp (-(1 / s) * y ^ 2)) :=
    integrable_exp_neg_mul_sq (by positivity)
  have := hbase.comp_sub_right c
  simpa using this

theorem gc_integral (s : ℝ) (hs : 0 < s) (c : ℝ) :
    (∫ x, gc s c x) = Real.sqrt (Real.pi * s) := by
  have hcomp : (gc s c) = (fun x => Real.exp (-(1 / s) * (x - c) ^ 2)) := by
    funext x; unfold gc; congr 1; field_simp
  rw [hcomp]
  have hshift : (∫ x, Real.exp (-(1 / s) * (x - c) ^ 2))
        = ∫ x, Real.exp (-(1 / s) * x ^ 2) := by
    have := MeasureTheory.integral_add_right_eq_self (μ := (volume : Measure ℝ))
      (fun y => Real.exp (-(1 / s) * y ^ 2)) (-c)
    simpa [sub_eq_add_neg] using this
  rw [hshift, integral_gaussian]
  rw [show Real.pi / (1 / s) = Real.pi * s by field_simp]

theorem gc_monotone_left (s : ℝ) (hs : 0 < s) (c : ℝ) :
    MonotoneOn (gc s c) (Set.Iic c) := by
  intro x hx y hy hxy
  unfold gc
  apply Real.exp_le_exp.mpr
  rw [neg_div, neg_div, neg_le_neg_iff, div_le_div_iff_of_pos_right hs]
  have hx' : x ≤ c := hx
  have hy' : y ≤ c := hy
  nlinarith [hxy, hx', hy']

theorem gc_antitone_right (s : ℝ) (hs : 0 < s) (c : ℝ) :
    AntitoneOn (gc s c) (Set.Ici c) := by
  intro x hx y hy hxy
  unfold gc
  apply Real.exp_le_exp.mpr
  rw [neg_div, neg_div, neg_le_neg_iff, div_le_div_iff_of_pos_right hs]
  have hx' : c ≤ x := hx
  have hy' : c ≤ y := hy
  nlinarith [hxy, hx', hy']

/-- **General Gaussian lattice-sum bound.** For peak `c ∈ [0, n)` and scale
`s > 0`: `∑_{i ∈ range (n+1)} gc s c i ≤ 2 + √(π s)`.

(The application always has `c = n/2 < n` for `n ≥ 1`, so the strict `c < n` is
not a real restriction.) -/
theorem gc_lattice_sum_le (s : ℝ) (hs : 0 < s) (c : ℝ) (n : ℕ) (hn : 1 ≤ n)
    (hc0 : 0 ≤ c) (hcn : c < (n : ℝ)) :
    (∑ i ∈ Finset.range (n + 1), gc s c (i : ℝ)) ≤ 2 + Real.sqrt (Real.pi * s) := by
  set p : ℕ := ⌊c⌋₊ with hp
  have hp_le_c : (p : ℝ) ≤ c := by rw [hp]; exact Nat.floor_le hc0
  have hc_lt_p1 : c < (p : ℝ) + 1 := by rw [hp]; exact Nat.lt_floor_add_one c
  have hp_lt_n : p < n := by
    have hpc : (p : ℝ) < (n : ℝ) := lt_of_le_of_lt hp_le_c hcn
    exact_mod_cast hpc
  have hp1_le_n : p + 1 ≤ n := hp_lt_n
  have hg_int := gc_integrable s hs c
  have hg_nn := gc_nonneg s c
  have hf_intble : ∀ a b : ℝ, IntervalIntegrable (gc s c) volume a b :=
    fun a b => hg_int.intervalIntegrable
  set M : ℕ := n - (p + 1) with hM
  have hM_eq : (p + 1) + M = n := by omega
  have hMcast : ((p : ℝ) + 1) + (M : ℝ) = (n : ℝ) := by
    have : ((p + 1 + M : ℕ) : ℝ) = (n : ℝ) := by exact_mod_cast hM_eq
    push_cast at this; linarith
  -- Decompose the sum.
  have hdecomp : (∑ i ∈ Finset.range (n + 1), gc s c (i : ℝ))
      = (∑ i ∈ Finset.range p, gc s c (i : ℝ))
        + gc s c (p : ℝ) + gc s c ((p : ℝ) + 1)
        + (∑ j ∈ Finset.range M, gc s c (((p : ℝ) + 1) + ((j : ℝ) + 1))) := by
    have hsplit : n + 1 = (p + 1 + 1) + M := by omega
    rw [hsplit, Finset.sum_range_add, Finset.sum_range_succ, Finset.sum_range_succ]
    have hb1 : gc s c ((p + 1 : ℕ) : ℝ) = gc s c ((p : ℝ) + 1) := by norm_cast
    rw [hb1]
    congr 1
    apply Finset.sum_congr rfl
    intro j _; congr 1; push_cast; ring
  -- LEFT
  have hmono : MonotoneOn (gc s c) (Set.Icc (0 : ℝ) (0 + (p : ℝ))) := by
    apply (gc_monotone_left s hs c).mono
    intro x hx
    simp only [zero_add, Set.mem_Icc] at hx
    exact Set.mem_Iic.mpr (le_trans hx.2 hp_le_c)
  have hleft : (∑ i ∈ Finset.range p, gc s c ((i : ℝ))) ≤ ∫ x in (0:ℝ)..(p : ℝ), gc s c x := by
    have := MonotoneOn.sum_le_integral (x₀ := (0:ℝ)) (a := p) (f := gc s c) hmono
    simpa using this
  -- RIGHT
  have hanti : AntitoneOn (gc s c) (Set.Icc ((p : ℝ) + 1) (((p : ℝ) + 1) + (M : ℝ))) := by
    apply (gc_antitone_right s hs c).mono
    intro x hx
    simp only [Set.mem_Icc] at hx
    have : c ≤ (p : ℝ) + 1 := le_of_lt hc_lt_p1
    exact Set.mem_Ici.mpr (le_trans this hx.1)
  have hright_cmp := AntitoneOn.sum_le_integral (x₀ := ((p : ℝ) + 1)) (a := M) (f := gc s c) hanti
  have hright : (∑ j ∈ Finset.range M, gc s c (((p : ℝ) + 1) + ((j : ℝ) + 1)))
      ≤ ∫ x in ((p : ℝ) + 1)..(n : ℝ), gc s c x := by
    rw [← hMcast]
    have hcast : (∑ j ∈ Finset.range M, gc s c (((p : ℝ) + 1) + ((j + 1 : ℕ) : ℝ)))
        = (∑ j ∈ Finset.range M, gc s c (((p : ℝ) + 1) + ((j : ℝ) + 1))) := by
      apply Finset.sum_congr rfl; intro j _; push_cast; ring_nf
    rw [hcast] at hright_cmp
    exact hright_cmp
  -- combine integrals
  have hp_le_p1 : (0:ℝ) ≤ (p : ℝ) := Nat.cast_nonneg _
  have h0_le_n : (0:ℝ) ≤ (n : ℝ) := Nat.cast_nonneg _
  have hint_p_le_p1 : (∫ x in (0:ℝ)..(p : ℝ), gc s c x) ≤ ∫ x in (0:ℝ)..((p:ℝ)+1), gc s c x := by
    apply intervalIntegral.integral_mono_interval (le_refl _) hp_le_p1 (by linarith)
    · exact ae_of_all _ (fun x => hg_nn x)
    · exact hf_intble _ _
  have hadd : (∫ x in (0:ℝ)..((p:ℝ)+1), gc s c x) + (∫ x in ((p : ℝ) + 1)..(n : ℝ), gc s c x)
      = ∫ x in (0:ℝ)..(n : ℝ), gc s c x :=
    intervalIntegral.integral_add_adjacent_intervals (hf_intble _ _) (hf_intble _ _)
  have hint_n_le_R : (∫ x in (0:ℝ)..(n : ℝ), gc s c x) ≤ ∫ x, gc s c x := by
    rw [intervalIntegral.integral_of_le h0_le_n]
    exact MeasureTheory.setIntegral_le_integral hg_int (ae_of_all _ (fun x => hg_nn x))
  have hint_total : (∫ x in (0:ℝ)..(p : ℝ), gc s c x) + (∫ x in ((p : ℝ) + 1)..(n : ℝ), gc s c x)
      ≤ ∫ x, gc s c x := by
    calc (∫ x in (0:ℝ)..(p : ℝ), gc s c x) + (∫ x in ((p : ℝ) + 1)..(n : ℝ), gc s c x)
        ≤ (∫ x in (0:ℝ)..((p:ℝ)+1), gc s c x) + (∫ x in ((p : ℝ) + 1)..(n : ℝ), gc s c x) := by
          linarith [hint_p_le_p1]
      _ = ∫ x in (0:ℝ)..(n : ℝ), gc s c x := hadd
      _ ≤ ∫ x, gc s c x := hint_n_le_R
  have hcp : gc s c (p : ℝ) ≤ 1 := gc_le_one s hs c _
  have hcp1 : gc s c ((p : ℝ) + 1) ≤ 1 := gc_le_one s hs c _
  rw [hdecomp]
  have hsumbound : (∑ i ∈ Finset.range p, gc s c (i : ℝ))
        + (∑ j ∈ Finset.range M, gc s c (((p : ℝ) + 1) + ((j : ℝ) + 1)))
      ≤ ∫ x, gc s c x := by linarith [hleft, hright, hint_total]
  rw [gc_integral s hs c] at hsumbound
  linarith [hcp, hcp1, hsumbound]

end Workspace.ProofLemmas.GaussianLatticeSumBound
