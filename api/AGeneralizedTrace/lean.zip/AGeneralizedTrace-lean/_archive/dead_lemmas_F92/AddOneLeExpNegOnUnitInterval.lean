import Mathlib

open Real

/-- For every real number `x` with `0 ≤ x ≤ 1`, `1 - x ≤ exp (-x)`. -/
theorem AddOneLeExpNegOnUnitInterval :
    ∀ (x : ℝ), 0 ≤ x → x ≤ 1 → 1 - x ≤ Real.exp (-x) := by
  intro x _ _
  have h := Real.add_one_le_exp (-x)
  linarith
