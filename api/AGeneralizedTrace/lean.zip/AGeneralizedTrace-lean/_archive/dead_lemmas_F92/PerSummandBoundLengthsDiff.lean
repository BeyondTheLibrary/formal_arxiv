import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.DelProb
import Workspace.Types.BinVec
import Workspace.Types.LengthsOnlyProcess
import Workspace.Types.PartialDeletionProcess
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.MixedParityVanishes
import Workspace.ProofLemmas.ParitySwapBijection
import Workspace.ProofLemmas.BinomialPmfMaxBound

open Workspace.Types.BinVec

/-- Helper: the geometric factor `α · B` is at most `1` (in fact far below it),
where `α = c' · √n` with `c' = 1/(4·e²·√(2π))` and `B = C(n,k)·2⁻ⁿ`.  This is the
Stirling envelope `B ≤ √(2/(πn))` combined with the explicit constant.  It gives the
denominator `1 − α·B` a definite sign for the nonnegativity argument. -/
private lemma alphaB_le_one (n : ℕ) (hn1 : 1 ≤ n) (k : ℕ) :
    (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n *
        ((Nat.choose n k : ℝ) * (2 ^ n : ℝ)⁻¹) ≤ 1 := by
  set c' : ℝ := 1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi)) with hc'
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn1
  have hpi : (0 : ℝ) < Real.pi := Real.pi_pos
  have hexp : (0 : ℝ) < Real.exp 2 := Real.exp_pos 2
  have hsqrt2pi : (0 : ℝ) < Real.sqrt (2 * Real.pi) :=
    Real.sqrt_pos.mpr (by positivity)
  have hdenpos : (0 : ℝ) < 4 * Real.exp 2 * Real.sqrt (2 * Real.pi) := by positivity
  have hc'pos : (0 : ℝ) < c' := by rw [hc']; positivity
  -- Stirling envelope for the binomial pmf.
  have hB : ((Nat.choose n k : ℝ) * (2 ^ n : ℝ)⁻¹) ≤ Real.sqrt (2 / (Real.pi * n)) :=
    BinomialPmfMaxBound n hn1 k
  have hBnn : (0 : ℝ) ≤ (Nat.choose n k : ℝ) * (2 ^ n : ℝ)⁻¹ := by positivity
  have hcoef_nn : (0 : ℝ) ≤ c' * Real.sqrt n := by positivity
  -- Chain through the envelope.
  have hstep : c' * Real.sqrt n * ((Nat.choose n k : ℝ) * (2 ^ n : ℝ)⁻¹)
      ≤ c' * Real.sqrt n * Real.sqrt (2 / (Real.pi * n)) := by
    apply mul_le_mul_of_nonneg_left hB hcoef_nn
  refine le_trans hstep ?_
  -- `√n · √(2/(πn)) = √(2/π)`.
  have hmul : Real.sqrt n * Real.sqrt (2 / (Real.pi * n)) = Real.sqrt (2 / Real.pi) := by
    rw [← Real.sqrt_mul (le_of_lt hnpos)]
    congr 1
    field_simp
  have hrew : c' * Real.sqrt n * Real.sqrt (2 / (Real.pi * n))
      = c' * Real.sqrt (2 / Real.pi) := by
    rw [mul_assoc, hmul]
  rw [hrew]
  -- Now bound `c' · √(2/π) ≤ 1`.
  rw [hc', one_div, inv_mul_le_iff₀ hdenpos, mul_one]
  -- Goal: `√(2/π) ≤ 4·e²·√(2π)`.
  have h1 : Real.sqrt (2 / Real.pi) ≤ 1 := by
    rw [show (1 : ℝ) = Real.sqrt 1 by rw [Real.sqrt_one]]
    apply Real.sqrt_le_sqrt
    rw [div_le_one hpi]
    linarith [Real.pi_gt_d2]
  have h2 : (1 : ℝ) ≤ 4 * Real.exp 2 * Real.sqrt (2 * Real.pi) := by
    have he : (1 : ℝ) ≤ Real.exp 2 := by
      have := Real.add_one_le_exp (2 : ℝ); linarith
    have hs : (1 : ℝ) ≤ Real.sqrt (2 * Real.pi) := by
      rw [show (1 : ℝ) = Real.sqrt 1 by rw [Real.sqrt_one]]
      apply Real.sqrt_le_sqrt
      nlinarith [Real.pi_gt_d2]
    nlinarith [hs, he, Real.exp_pos 2, hsqrt2pi]
  linarith [h1, h2]

/--
`PerSummandBoundLengthsDiff` — faithful per-summand bound on the difference of the
even/odd lengths-only probabilities at a fixed middle mask `m` and fixed prefix /
suffix lengths `zMinus, zPlus`.

The absolute difference of the two probabilities is bounded by the NON-alternating,
nonnegative partial-deletion-process sum:

    |P_even(m, z₋, z₊) − P_odd(m, z₋, z₊)|
      ≤ ∑_r offsetWeight(n,r) · prefixWeight(n,δ,r,z₋) · suffixWeight(n,δ,r,z₊)
            · ∏_{j ∈ ℓ} α·B(j) / (1 − α·B(j))

with `ℓ := {j : Fin (n/2) | m.bit j = true}` and
`B(j) = C(n, (n/4 + r + j).toNat) · 2⁻ⁿ`. This is exactly the conclusion of
`ParitySwapBijection` (the paper's Lemma-6 bound, arXiv:2412.00674v1 lines 287-289),
which is the form the paper actually supports at this step. The lemma holds
UNCONDITIONALLY on `m`: in the same-parity case it is `ParitySwapBijection`, and in
the mixed-parity case the two probabilities coincide (`MixedParityVanishes`), so the
left side is `0`, which is bounded by the manifestly nonnegative right side.

FAITHFULNESS FIX (history): the previous version of this lemma claimed the bound
`|P_even − P_odd| ≤ 2 · |altRSum …|` and routed through `MixedParityVanishes`,
`ParitySwapBijection`, and `EllShiftReindex` chained via `le_trans`. That statement
was removed as UNFAITHFUL: the paper (arXiv:2412.00674v1, Lemma 6, deletion.tex
line 304) only relates the difference of probabilities to the alternating sum up to
an O(1) multiplicative factor AND an `e^{−Ω(n)}` additive term; the bare `2 · |altRSum|`
with no additive term and an arbitrary constant `2` has no justification. Moreover the
`8√δ · |altRSum|` form of `EllShiftReindex` it relied on was itself removed (that file
is now a pure reindexing equality), so the old proof route no longer typechecks. The
import of `Workspace.ProofLemmas.EllShiftReindex` was therefore dropped; it is not
needed for this faithful form.
-/
theorem PerSummandBoundLengthsDiff :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
      ∀ (Se So : Workspace.Types.ProbVec.ProbVec n),
        (∀ i : Fin n, Se.p i =
          (if (i.val) % 2 = 0
           then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) *
                Real.sqrt n *
                ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
           else 0)) →
        (∀ i : Fin n, So.p i =
          (if (i.val) % 2 = 1
           then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) *
                Real.sqrt n *
                ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
           else 0)) →
        ∀ (δ : Workspace.Types.DelProb.DelProb),
          (320 : ℝ) / Real.sqrt n ≤ δ.val → δ.val ≤ 1 / 2 →
          ∀ (lenE : Workspace.Types.LengthsOnlyProcess.LengthsOnlyProcess n Se δ)
            (lenO : Workspace.Types.LengthsOnlyProcess.LengthsOnlyProcess n So δ),
          ∀ (m : Workspace.Types.BinVec.BinVec (n / 2)) (zMinus zPlus : ℕ),
            let α : ℝ :=
              (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n
            let ell_m : Finset (Fin (n / 2)) :=
              (Finset.univ : Finset (Fin (n / 2))).filter
                (fun j => m.bit j = true)
            |((lenE.toPMF (m, zMinus, zPlus)).toReal)
                - ((lenO.toPMF (m, zMinus, zPlus)).toReal)|
              ≤ ∑ r ∈ Finset.Icc (-((n / 4 : ℕ) : ℤ)) ((n / 4 : ℕ) : ℤ),
                  (Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
                  (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
                  (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal *
                  (∏ j ∈ ell_m,
                    α *
                      ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                        (2 ^ n : ℝ)⁻¹) /
                    (1 -
                      α *
                        ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                          (2 ^ n : ℝ)⁻¹))) := by
  intro n hn hmod Se So hSe hSo δ hδ_lb hδ_ub lenE lenO m zMinus zPlus
  simp only
  -- Case-split: either there exist mixed-parity bits, or all bits have same parity
  by_cases hmix : ∃ j₁ j₂ : Fin (n / 2),
      m.bit j₁ = true ∧ m.bit j₂ = true ∧ (j₁.val) % 2 ≠ (j₂.val) % 2
  · -- Mixed parity case: LHS = 0, so the bound reduces to RHS ≥ 0.
    have heq := MixedParityVanishes n hn (by omega : n % 2 = 1) Se So hSe hSo δ hδ_lb hδ_ub
                  lenE lenO m hmix zMinus zPlus
    rw [heq, sub_self, abs_zero]
    -- The right side is a sum of nonnegative products.
    apply Finset.sum_nonneg
    intro r _
    apply mul_nonneg
    apply mul_nonneg
    apply mul_nonneg
    · exact ENNReal.toReal_nonneg
    · exact ENNReal.toReal_nonneg
    · exact ENNReal.toReal_nonneg
    -- The inner product is nonnegative: in the mixed-parity case it equals
    -- ParitySwapBijection's RHS factor.  We give a direct nonnegativity argument.
    apply Finset.prod_nonneg
    intro j _
    have hn1 : 1 ≤ n := by omega
    have hnum : (0 : ℝ) ≤
        (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n *
          ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
            (2 ^ n : ℝ)⁻¹) := by positivity
    have hle := alphaB_le_one n hn1 (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat
    apply div_nonneg hnum
    linarith [hle]
  · -- Same-parity case: exactly ParitySwapBijection's conclusion.
    push Not at hmix
    have hparity_eq : ∀ j₁ ∈ (Finset.univ : Finset (Fin (n / 2))).filter
                          (fun j => m.bit j = true),
                      ∀ j₂ ∈ (Finset.univ : Finset (Fin (n / 2))).filter
                          (fun j => m.bit j = true),
                      (j₁.val) % 2 = (j₂.val) % 2 := by
      intro j₁ hj₁ j₂ hj₂
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hj₁ hj₂
      exact hmix j₁ j₂ hj₁ hj₂
    have h1 := ParitySwapBijection n hn hmod Se So hSe hSo δ hδ_lb hδ_ub
                lenE lenO m hparity_eq zMinus zPlus
    simp only at h1
    exact h1
