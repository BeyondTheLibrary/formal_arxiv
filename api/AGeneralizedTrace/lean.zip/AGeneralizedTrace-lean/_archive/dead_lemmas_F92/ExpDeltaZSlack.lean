import Mathlib

/-- For every natural number `z` and every real `δ` with `0 < δ ≤ 1/2`,
    `exp (δ * z / 20) ≤ exp (δ * (z + 1) / 20)`. -/
theorem ExpDeltaZSlack :
    ∀ (z : ℕ) (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
      Real.exp (δ * z / 20) ≤ Real.exp (δ * (z + 1) / 20) := by
  intro z δ hδpos hδle
  apply Real.exp_le_exp.mpr
  have hz : (0 : ℝ) ≤ z := by exact_mod_cast Nat.zero_le z
  have : δ * z ≤ δ * (z + 1) := by
    have : (z : ℝ) ≤ (z : ℝ) + 1 := by linarith
    nlinarith [hδpos]
  linarith
