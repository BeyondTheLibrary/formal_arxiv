import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.BinVec
import Workspace.ProofLemmas.SublemmaSqrtSum
import Workspace.Types.StirlingAxioms

open Workspace.Types.ProbVec
open Workspace.Types.BinVec

/--
Lemma 11 of the paper (Rare-support split).

Fix `c' := 1 / (4 e² √(2π))`, `α := c' · √n`, and the product-Bernoulli
measure `μ(x) := ∏_i (S.p i)^{x_i}(1 - S.p i)^{1-x_i}` on `{0,1}^n`
associated with a probability vector `S : ProbVec n`.

For every `n ≥ 10^12`, the support `{0,1}^n` splits into a "heavy" set
`H := {x : μ(x) ≥ exp(-√n / 2)}` and a "light" set
`L := {x : μ(x) < exp(-√n / 2)}` such that:

(a) `|H| ≤ exp(√n / 2)` — pigeonhole bound from total mass `≤ 1`.

(b) `μ(L) ≤ exp(-√n / 16)` — Cauchy–Schwarz applied to the
    `L^{1/2}` bound from `SublemmaSqrtSum.b`.

The statement is given for an arbitrary `S : ProbVec n` so that it can be
applied to both witnesses `S_e` and `S_o` from `SublemmaWitnessConstruction`.
The proof will require the witness-construction hypothesis to invoke
`SublemmaSqrtSum.b`; that hypothesis is added by the prover, not the
statement.

The Bernoulli product is encoded as
`∏ i, if x i then S.p i else 1 - S.p i`, summed/filtered over
`x : Fin n → Bool`.
-/
theorem SublemmaRareSupport :
    -- (a) Heavy-set count bound — universal pigeonhole, holds for any S.
    (∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n →
      ∀ (S : ProbVec n),
        ((Finset.filter
            (fun x : Fin n → Bool =>
              Real.exp (- Real.sqrt (n : ℝ) / 2)
                ≤ ∏ i : Fin n, if x i then S.p i else 1 - S.p i)
            Finset.univ).card : ℝ)
            ≤ Real.exp (Real.sqrt (n : ℝ) / 2)) ∧
    -- (b) Light-set total mass bound — requires the witness construction.
    (∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
      ∀ (Se : ProbVec n),
        (∀ i : Fin n, Se.p i =
          (if (i.val) % 2 = 0
            then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n *
                 ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
            else 0)) →
        (∑ x ∈ (Finset.filter
                  (fun x : Fin n → Bool =>
                    (∏ i : Fin n, if x i then Se.p i else 1 - Se.p i)
                      < Real.exp (- Real.sqrt (n : ℝ) / 2))
                  Finset.univ),
            (∏ i : Fin n, if x i then Se.p i else 1 - Se.p i))
            ≤ Real.exp (- Real.sqrt (n : ℝ) / 16)) := by
  refine ⟨?partA, ?partB⟩
  case partA =>
    -- Pigeonhole on the heavy set.
    intro n _ S
    classical
    set H : Finset (Fin n → Bool) := Finset.filter
          (fun x : Fin n → Bool =>
            Real.exp (- Real.sqrt (n : ℝ) / 2)
              ≤ ∏ i : Fin n, if x i then S.p i else 1 - S.p i)
          Finset.univ with hHdef
    set μ : (Fin n → Bool) → ℝ :=
      fun x => ∏ i : Fin n, if x i then S.p i else 1 - S.p i with hμdef
    -- Total mass of the product Bernoulli equals 1.
    have htotal : (∑ x : Fin n → Bool, μ x) = 1 := by
      simp only [hμdef]
      rw [← Fintype.prod_sum
          (fun (i : Fin n) (b : Bool) => if b then S.p i else 1 - S.p i)]
      apply Finset.prod_eq_one
      intro i _
      rw [Fintype.sum_bool]
      simp
    -- μ x ≥ 0 pointwise.
    have hμnn : ∀ x, 0 ≤ μ x := by
      intro x
      apply Finset.prod_nonneg
      intro i _
      by_cases h : x i
      · simp [h, S.nonneg]
      · simp [h]; linarith [S.le_one i]
    -- Sum over H ≤ total = 1.
    have hHmass : (∑ x ∈ H, μ x) ≤ 1 := by
      calc (∑ x ∈ H, μ x)
          ≤ ∑ x : Fin n → Bool, μ x := by
            apply Finset.sum_le_univ_sum_of_nonneg
            intro x; exact hμnn x
        _ = 1 := htotal
    -- Each x ∈ H satisfies the threshold.
    have hthresh : ∀ x ∈ H, Real.exp (- Real.sqrt (n : ℝ) / 2) ≤ μ x := by
      intro x hx
      simp only [hHdef, Finset.mem_filter, Finset.mem_univ, true_and] at hx
      exact hx
    -- |H| · exp(-√n/2) ≤ ∑_{x ∈ H} μ x.
    have hcount : (H.card : ℝ) * Real.exp (- Real.sqrt (n : ℝ) / 2)
        ≤ ∑ x ∈ H, μ x := by
      rw [show (H.card : ℝ) * Real.exp (- Real.sqrt (n : ℝ) / 2)
            = ∑ _x ∈ H, Real.exp (- Real.sqrt (n : ℝ) / 2) from by
          rw [Finset.sum_const]; ring]
      exact Finset.sum_le_sum hthresh
    -- Combine to bound |H|.
    have hpos : 0 < Real.exp (- Real.sqrt (n : ℝ) / 2) := Real.exp_pos _
    have hbound : (H.card : ℝ) * Real.exp (- Real.sqrt (n : ℝ) / 2) ≤ 1 :=
      le_trans hcount hHmass
    have hcardbound : (H.card : ℝ) ≤ 1 / Real.exp (- Real.sqrt (n : ℝ) / 2) := by
      rw [le_div_iff₀ hpos]
      exact hbound
    -- Rewrite 1 / exp(-√n/2) = exp(√n/2).
    rw [show Real.exp (Real.sqrt (n : ℝ) / 2)
          = 1 / Real.exp (- Real.sqrt (n : ℝ) / 2) by
        rw [one_div, ← Real.exp_neg]; congr 1; ring]
    exact hcardbound
  case partB =>
    -- Cauchy–Schwarz reduction using SublemmaSqrtSum.b.
    intro n hn hmod Se hSe
    classical
    -- We use n ≥ 10^12 only to get n ≥ 1.
    have hn1 : 1 ≤ n := by
      have : (1 : ℕ) ≤ 10 ^ 12 := by norm_num
      exact this.trans hn
    -- Sqrt-sum bound from SublemmaSqrtSum.b.
    have hsqrt : (∑ x : Fin n → Bool,
          Real.sqrt (∏ i : Fin n, if x i then Se.p i else 1 - Se.p i))
          ≤ Real.exp (Real.sqrt n / (2 * Real.exp 1)) :=
      SublemmaSqrtSum.2 n hn1 hmod Se hSe
    set μ : (Fin n → Bool) → ℝ :=
      fun x => ∏ i : Fin n, if x i then Se.p i else 1 - Se.p i with hμdef
    -- Define light set L.
    set L : Finset (Fin n → Bool) := Finset.filter
            (fun x : Fin n → Bool => μ x < Real.exp (- Real.sqrt (n : ℝ) / 2))
            Finset.univ with hLdef
    -- Pointwise non-negativity of μ.
    have hμnn : ∀ x, 0 ≤ μ x := by
      intro x
      apply Finset.prod_nonneg
      intro i _
      by_cases h : x i
      · simp [h, Se.nonneg]
      · simp [h]; linarith [Se.le_one i]
    -- For x ∈ L: μ(x) ≤ exp(-√n/4) · √μ(x).
    have hLbound : ∀ x ∈ L, μ x ≤ Real.exp (- Real.sqrt (n : ℝ) / 4) * Real.sqrt (μ x) := by
      intro x hx
      simp only [hLdef, Finset.mem_filter, Finset.mem_univ, true_and] at hx
      -- hx : μ x < exp(-√n/2)
      have hμx_le : μ x ≤ Real.exp (- Real.sqrt (n : ℝ) / 2) := le_of_lt hx
      have h1 : Real.sqrt (μ x) ≤ Real.sqrt (Real.exp (- Real.sqrt (n : ℝ) / 2)) :=
        Real.sqrt_le_sqrt hμx_le
      -- √(exp y) = exp(y/2); use y = -√n/2 so y/2 = -√n/4.
      have h2 : Real.sqrt (Real.exp (- Real.sqrt (n : ℝ) / 2))
              = Real.exp (- Real.sqrt (n : ℝ) / 4) := by
        rw [← Real.exp_half (- Real.sqrt (n : ℝ) / 2)]
        congr 1; ring
      have h3 : Real.sqrt (μ x) ≤ Real.exp (- Real.sqrt (n : ℝ) / 4) := h1.trans h2.le
      -- μ x = √μ(x) · √μ(x).
      have hsqrtnn : 0 ≤ Real.sqrt (μ x) := Real.sqrt_nonneg _
      have hsq : μ x = Real.sqrt (μ x) * Real.sqrt (μ x) :=
        (Real.mul_self_sqrt (hμnn x)).symm
      calc μ x = Real.sqrt (μ x) * Real.sqrt (μ x) := hsq
        _ ≤ Real.exp (- Real.sqrt (n : ℝ) / 4) * Real.sqrt (μ x) := by
            apply mul_le_mul_of_nonneg_right h3 hsqrtnn
    -- Sum bound using the per-element bound.
    have hsum1 : (∑ x ∈ L, μ x)
        ≤ ∑ x ∈ L, Real.exp (- Real.sqrt (n : ℝ) / 4) * Real.sqrt (μ x) :=
      Finset.sum_le_sum hLbound
    -- Pull the constant out.
    have hsum2 : (∑ x ∈ L, Real.exp (- Real.sqrt (n : ℝ) / 4) * Real.sqrt (μ x))
        = Real.exp (- Real.sqrt (n : ℝ) / 4) * (∑ x ∈ L, Real.sqrt (μ x)) := by
      rw [Finset.mul_sum]
    -- ∑_{x ∈ L} √μ(x) ≤ ∑_x √μ(x).
    have hsum3 : (∑ x ∈ L, Real.sqrt (μ x))
        ≤ ∑ x : Fin n → Bool, Real.sqrt (μ x) := by
      apply Finset.sum_le_univ_sum_of_nonneg
      intro x
      exact Real.sqrt_nonneg _
    have hexp_pos : 0 < Real.exp (- Real.sqrt (n : ℝ) / 4) := Real.exp_pos _
    have hsum4 : Real.exp (- Real.sqrt (n : ℝ) / 4) * (∑ x ∈ L, Real.sqrt (μ x))
        ≤ Real.exp (- Real.sqrt (n : ℝ) / 4)
          * Real.exp (Real.sqrt (n : ℝ) / (2 * Real.exp 1)) := by
      apply mul_le_mul_of_nonneg_left _ (le_of_lt hexp_pos)
      exact hsum3.trans hsqrt
    -- Combine into:  ∑_L μ ≤ exp(-√n/4) · exp(√n/(2e)).
    have hcombined : (∑ x ∈ L, μ x)
        ≤ Real.exp (- Real.sqrt (n : ℝ) / 4)
          * Real.exp (Real.sqrt (n : ℝ) / (2 * Real.exp 1)) := by
      calc (∑ x ∈ L, μ x)
          ≤ ∑ x ∈ L, Real.exp (- Real.sqrt (n : ℝ) / 4) * Real.sqrt (μ x) := hsum1
        _ = Real.exp (- Real.sqrt (n : ℝ) / 4) * (∑ x ∈ L, Real.sqrt (μ x)) := hsum2
        _ ≤ Real.exp (- Real.sqrt (n : ℝ) / 4)
            * Real.exp (Real.sqrt (n : ℝ) / (2 * Real.exp 1)) := hsum4
    -- Combine the exponents:
    -- exp(-√n/4) · exp(√n/(2e)) = exp(-√n/4 + √n/(2e)) ≤ exp(-√n/16).
    have hexp_combine :
        Real.exp (- Real.sqrt (n : ℝ) / 4)
          * Real.exp (Real.sqrt (n : ℝ) / (2 * Real.exp 1))
        = Real.exp (- Real.sqrt (n : ℝ) / 4
            + Real.sqrt (n : ℝ) / (2 * Real.exp 1)) := by
      rw [← Real.exp_add]
    rw [hexp_combine] at hcombined
    -- Need: -√n/4 + √n/(2e) ≤ -√n/16.
    -- Equivalent to: √n · (-1/4 + 1/(2e) + 1/16) ≤ 0.
    -- Suffices: -1/4 + 1/(2e) + 1/16 ≤ 0, i.e. 1/(2e) ≤ 3/16.
    -- 1/(2e) ≤ 3/16 ↔ 16 ≤ 6e, holds since e > 8/3.
    have hsqrt_nn : 0 ≤ Real.sqrt (n : ℝ) :=
      Real.sqrt_nonneg _
    have he9 : 2.7182818283 < Real.exp 1 := Real.exp_one_gt_d9
    have he_pos : 0 < Real.exp 1 := Real.exp_pos 1
    have h2e_pos : 0 < 2 * Real.exp 1 := by linarith
    have hbound_const : 1 / (2 * Real.exp 1) ≤ 3 / 16 := by
      rw [div_le_div_iff₀ h2e_pos (by norm_num : (0:ℝ) < 16)]
      nlinarith [he9]
    have hexp_ineq :
        - Real.sqrt (n : ℝ) / 4 + Real.sqrt (n : ℝ) / (2 * Real.exp 1)
          ≤ - Real.sqrt (n : ℝ) / 16 := by
      -- Rewrite divisions as multiplications by reciprocals.
      have hkey :
          Real.sqrt (n : ℝ) / (2 * Real.exp 1)
            ≤ Real.sqrt (n : ℝ) * (3 / 16) := by
        have hmul : Real.sqrt (n : ℝ) * (1 / (2 * Real.exp 1))
              ≤ Real.sqrt (n : ℝ) * (3 / 16) :=
          mul_le_mul_of_nonneg_left hbound_const hsqrt_nn
        calc Real.sqrt (n : ℝ) / (2 * Real.exp 1)
            = Real.sqrt (n : ℝ) * (1 / (2 * Real.exp 1)) := by
              rw [div_eq_mul_inv, one_div]
          _ ≤ Real.sqrt (n : ℝ) * (3 / 16) := hmul
      -- Now linear arithmetic on the inequality.
      linarith [hkey, hsqrt_nn]
    have hexp_final :
        Real.exp (- Real.sqrt (n : ℝ) / 4
            + Real.sqrt (n : ℝ) / (2 * Real.exp 1))
          ≤ Real.exp (- Real.sqrt (n : ℝ) / 16) :=
      Real.exp_le_exp.mpr hexp_ineq
    exact hcombined.trans hexp_final
