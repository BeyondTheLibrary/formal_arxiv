import Mathlib

open Real

/-- For every real `c` and every natural `m`,
`(exp (-c)) ^ m = exp (-c * m)`. -/
theorem PowExpDecay :
    ∀ (c : ℝ) (m : ℕ), (Real.exp (-c)) ^ m = Real.exp (-c * m) := by
  intro c m
  rw [← Real.exp_nat_mul]
  ring_nf
