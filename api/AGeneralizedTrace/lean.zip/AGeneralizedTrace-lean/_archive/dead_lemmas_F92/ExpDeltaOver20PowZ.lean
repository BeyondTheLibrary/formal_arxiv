import Mathlib

/-- For every natural number `z` and every real `δ`,
    `(exp (δ / 20)) ^ (z + 1) = exp (δ * (z + 1) / 20)`. -/
theorem ExpDeltaOver20PowZ :
    ∀ (z : ℕ) (δ : ℝ),
      (Real.exp (δ / 20)) ^ (z + 1) = Real.exp (δ * (z + 1) / 20) := by
  intro z δ
  rw [← Real.exp_nat_mul]
  congr 1
  push_cast
  ring
