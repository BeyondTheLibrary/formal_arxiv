import Mathlib
import Workspace.Types.StirlingAxioms
import Workspace.ProofLemmas.BinomialLowerEnvelope

open Workspace.Types.StirlingAxioms

namespace Workspace.ProofLemmas.BinomialUpperEnvelope

set_option maxHeartbeats 1600000

/-!
# Upper Gaussian envelope for the centred binomial pmf

Mirror of `BinomialLowerEnvelope`, but in the UPPER direction. We telescope the
sharp per-step upper bound on the log-ratio
`log(C(n,j+1)/C(n,j)) ≤ (n-2j-1)/(j+1)` (from
`StirlingAxioms.binom_log_ratio_step_bound`, which uses `log r ≤ r-1`).

The key estimate (even `n = 2m`, mode `m`, `m ≤ k ≤ n`): with `d := k - m`,

  `log(C(n,k)/C(n,m)) ≤ -(d²)/k ≤ -(d²)/(2m) = -(k-m)²/n`,

so `C(n,k)·2^{-n} ≤ C(n,m)·2^{-n} · exp(-(k-m)²/n) ≤ √(2/(πn)) · exp(-(k-n/2)²/n)`.

This is the SOUND upper Gaussian envelope with exponent constant `c = 1` (in the
`(k-n/2)²/n` normalisation), i.e. `exp(-(k-n/2)²/n)`. The asymptotically sharp
constant is `c = 2`, but `c = 2` is provably FALSE for finite `n` (see the
deleted-axiom note in `StirlingAxioms`); `c = 1` is what telescoping the exact
`log r ≤ r - 1` step bound yields without slack tricks.
-/

/-- Per-step UPPER bound on the log-ratio: for `j < n`,
`log(C(n,j+1)/C(n,j)) ≤ (n - 2j - 1)/(j + 1)`. (Restatement of
`binom_log_ratio_step_bound`, valid for ALL `j < n`, not only past the mode,
since `log r ≤ r - 1` holds for every positive `r`.) -/
theorem log_ratio_step_le (n j : ℕ) (hj : j < n) :
    Real.log ((Nat.choose n (j + 1) : ℝ) / (Nat.choose n j : ℝ))
      ≤ ((n : ℝ) - 2 * (j : ℝ) - 1) / ((j : ℝ) + 1) := by
  rw [BinomialLowerEnvelope.ratio_step_eq n j hj]
  have hjn : (j : ℝ) < (n : ℝ) := by exact_mod_cast hj
  have hnj_pos : (0 : ℝ) < (n : ℝ) - (j : ℝ) := by linarith
  have hj1_pos : (0 : ℝ) < (j : ℝ) + 1 := by positivity
  set r : ℝ := ((n : ℝ) - (j : ℝ)) / ((j : ℝ) + 1) with hr
  have hr_pos : 0 < r := by rw [hr]; positivity
  have hlog : Real.log r ≤ r - 1 := Real.log_le_sub_one_of_pos hr_pos
  have heq : r - 1 = ((n : ℝ) - 2 * (j : ℝ) - 1) / ((j : ℝ) + 1) := by
    rw [hr]; field_simp; ring
  rw [heq] at hlog
  exact hlog

/-- Telescoping UPPER bound on the log-ratio from the mode `m` up to `k`
(`m ≤ k ≤ n`): with `d := k - m`,
`log(C(n,k)/C(n,m)) ≤ ∑_{i<d} (n - 2(m+i) - 1)/((m+i) + 1)`. -/
theorem log_ratio_mode_to_k_le (n m k : ℕ) (hmk : m ≤ k) (hkn : k ≤ n) :
    Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ))
      ≤ ∑ i ∈ Finset.range (k - m),
          (((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / (((m : ℝ) + (i : ℝ)) + 1)) := by
  set f : ℕ → ℝ := fun j => Real.log (Nat.choose n j : ℝ) with hf
  have hpos : ∀ j, j ≤ n → (0 : ℝ) < (Nat.choose n j : ℝ) := by
    intro j hj
    have : 0 < Nat.choose n j := Nat.choose_pos hj
    exact_mod_cast this
  have hsplit : Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ)) = f k - f m := by
    rw [Real.log_div (ne_of_gt (hpos k hkn)) (ne_of_gt (hpos m (le_trans hmk hkn)))]
  rw [hsplit]
  have htele : f k - f m = ∑ i ∈ Finset.range (k - m), (f (m + i + 1) - f (m + i)) := by
    have hsr := Finset.sum_range_sub (fun i => f (m + i)) (k - m)
    simp only [Nat.add_zero] at hsr
    rw [show m + (k - m) = k by omega] at hsr
    rw [← hsr]
    apply Finset.sum_congr rfl
    intro i _
    rw [show m + i + 1 = m + (i + 1) by omega]
  rw [htele]
  apply Finset.sum_le_sum
  intro i hi
  rw [Finset.mem_range] at hi
  have hji : m + i < n := by omega
  have hstep := log_ratio_step_le n (m + i) hji
  have hdiff : f (m + i + 1) - f (m + i)
      = Real.log ((Nat.choose n (m + i + 1) : ℝ) / (Nat.choose n (m + i) : ℝ)) := by
    rw [hf]
    simp only []
    rw [Real.log_div (ne_of_gt (hpos (m + i + 1) (by omega))) (ne_of_gt (hpos (m + i) (by omega)))]
  rw [hdiff]
  refine le_trans hstep ?_
  apply le_of_eq
  push_cast
  ring

/-- **Telescope-to-quadratic, even `n`.** For `n = 2m`, `m ≤ k ≤ n` (`d := k - m`):
`log(C(2m,k)/C(2m,m)) ≤ -(k - m)²/(2m)`.

Each telescoped term `(n - 2(m+i) - 1)/((m+i)+1)` has a NONPOSITIVE numerator
`-(2i+1)` (since `n = 2m`) and a denominator `(m+i)+1 ≤ k`; dividing a nonpositive
number by a SMALLER positive denominator makes it MORE negative, so
`term ≤ (-(2i+1))/k`. Summing, `∑ ≤ (-d²)/k ≤ (-d²)/(2m)` since `k ≤ 2m`. -/
theorem log_ratio_quadratic_upper_even (m k : ℕ) (hmk : m ≤ k) (hk : k ≤ 2 * m)
    (hm : 1 ≤ m) :
    Real.log ((Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ))
      ≤ -(((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ))) := by
  set n := 2 * m with hn
  have hkn : k ≤ n := by rw [hn]; omega
  have hbase := log_ratio_mode_to_k_le n m k hmk hkn
  set d := k - m with hd
  have hdk : (d : ℝ) = (k : ℝ) - (m : ℝ) := by rw [hd, Nat.cast_sub hmk]
  have hk_pos : (0 : ℝ) < (k : ℝ) := by
    have : 1 ≤ k := by omega
    exact_mod_cast this
  -- Each term ≤ (-(2i+1))/k.
  have hterm : ∀ i ∈ Finset.range d,
      ((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / (((m : ℝ) + (i : ℝ)) + 1)
        ≤ ((0 : ℝ) - 2 * (i : ℝ) - 1) / (k : ℝ) := by
    intro i hi
    rw [Finset.mem_range] at hi
    -- numerator = -(2i+1) ≤ 0 (using n = 2m)
    have hnum_eq : (n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1 = (0 : ℝ) - 2 * (i : ℝ) - 1 := by
      rw [hn]; push_cast; ring
    rw [hnum_eq]
    have hnum_nonpos : ((0 : ℝ) - 2 * (i : ℝ) - 1) ≤ 0 := by
      have : (0:ℝ) ≤ (i:ℝ) := Nat.cast_nonneg _
      linarith
    -- denominator (m+i)+1 ∈ (0, k], so dividing the nonpos numerator by the
    -- SMALLER denominator gives a MORE negative (≤) value.
    have hden_pos : (0 : ℝ) < ((m : ℝ) + (i : ℝ)) + 1 := by positivity
    have hden_le_k : ((m : ℝ) + (i : ℝ)) + 1 ≤ (k : ℝ) := by
      have : m + i + 1 ≤ k := by omega
      calc ((m : ℝ) + (i : ℝ)) + 1 = ((m + i + 1 : ℕ) : ℝ) := by push_cast; ring
        _ ≤ (k : ℝ) := by exact_mod_cast this
    -- a ≤ 0, 0 < b ≤ c ⟹ a/c ≤ a/b
    rw [div_le_div_iff₀ hden_pos hk_pos]
    nlinarith [hnum_nonpos, hden_le_k, hk_pos, hden_pos]
  have hsum_le : (∑ i ∈ Finset.range d,
        ((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / (((m : ℝ) + (i : ℝ)) + 1))
      ≤ (∑ i ∈ Finset.range d, ((0 : ℝ) - 2 * (i : ℝ) - 1) / (k : ℝ)) :=
    Finset.sum_le_sum hterm
  -- evaluate RHS sum = (-d²)/k
  have hrhs : (∑ i ∈ Finset.range d, ((0 : ℝ) - 2 * (i : ℝ) - 1) / (k : ℝ))
      = (-(d : ℝ)^2) / (k : ℝ) := by
    rw [← Finset.sum_div, BinomialLowerEnvelope.telescope_gauss_sum 0 d]
    rw [show (d : ℝ) * 0 - (d : ℝ)^2 = -(d : ℝ)^2 by ring]
  rw [hrhs] at hsum_le
  -- chain: log ≤ ∑ ≤ -d²/k ≤ -d²/(2m)
  have hstep1 : Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ))
      ≤ (-(d : ℝ)^2) / (k : ℝ) := le_trans hbase hsum_le
  have hd_sq_nonneg : (0 : ℝ) ≤ (d : ℝ)^2 := sq_nonneg _
  have h2m_pos : (0 : ℝ) < 2 * (m : ℝ) := by
    have : (0:ℝ) < (m:ℝ) := by exact_mod_cast hm
    linarith
  have hk_le_2m : (k : ℝ) ≤ 2 * (m : ℝ) := by
    have := hk; rw [hn] at hkn
    calc (k : ℝ) ≤ ((2 * m : ℕ) : ℝ) := by exact_mod_cast hk
      _ = 2 * (m : ℝ) := by push_cast; ring
  have hstep2 : (-(d : ℝ)^2) / (k : ℝ) ≤ -((d : ℝ)^2 / (2 * (m : ℝ))) := by
    rw [neg_div, neg_le_neg_iff, div_le_div_iff₀ h2m_pos hk_pos]
    nlinarith [hd_sq_nonneg, hk_le_2m, hk_pos]
  calc Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ))
      ≤ (-(d : ℝ)^2) / (k : ℝ) := hstep1
    _ ≤ -((d : ℝ)^2 / (2 * (m : ℝ))) := hstep2
    _ = -(((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ))) := by rw [hdk]

/-- **Upper Gaussian envelope, right tail, even `n = 2m`.** For `m ≤ k ≤ 2m`:
`C(2m,k)·2^{-2m} ≤ √(2/(π·2m)) · exp(-(k - m)²/(2m))`. -/
theorem binom_pmf_upper_envelope_right (m k : ℕ) (hmk : m ≤ k) (hk : k ≤ 2 * m)
    (hm : 1 ≤ m) :
    ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹)
      ≤ Real.sqrt (2 / (Real.pi * ((2 * m : ℕ) : ℝ)))
        * Real.exp (-(((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ)))) := by
  have hn1 : 1 ≤ 2 * m := by omega
  have hkn : k ≤ 2 * m := hk
  set E : ℝ := Real.exp (-(((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ)))) with hE
  have hE_pos : 0 < E := Real.exp_pos _
  have hCm_pos : (0 : ℝ) < (Nat.choose (2 * m) m : ℝ) := by
    have : 0 < Nat.choose (2 * m) m := Nat.choose_pos (by omega)
    exact_mod_cast this
  -- mode value ≤ √(2/(π·2m))  (central_binomial_pmf_upper_bound)
  have hmode := central_binomial_pmf_upper_bound (n := 2 * m) hn1 m
  -- log-ratio ⟹ ratio ≤ E
  have hlog := log_ratio_quadratic_upper_even m k hmk hk hm
  have hCk_nonneg : (0 : ℝ) ≤ (Nat.choose (2 * m) k : ℝ) := by positivity
  have hratio_pos : (0 : ℝ) < (Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ) := by
    have : 0 < Nat.choose (2 * m) k := Nat.choose_pos hkn
    have h2 : (0 : ℝ) < (Nat.choose (2 * m) k : ℝ) := by exact_mod_cast this
    positivity
  have hratio_le : (Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ) ≤ E := by
    rw [hE, ← Real.exp_log hratio_pos]
    apply Real.exp_le_exp.mpr
    linarith [hlog]
  -- C(2m,k)·2^{-2m} = ratio · (C(2m,m)·2^{-2m})
  have hkey : (Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹
      = ((Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ))
          * ((Nat.choose (2 * m) m : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹) := by
    field_simp
  rw [hkey]
  have hmode_nonneg : (0 : ℝ) ≤ (Nat.choose (2 * m) m : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹ := by positivity
  have hG_nonneg : (0 : ℝ) ≤ Real.sqrt (2 / (Real.pi * ((2 * m : ℕ) : ℝ))) := Real.sqrt_nonneg _
  calc ((Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ))
          * ((Nat.choose (2 * m) m : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹)
      ≤ E * ((Nat.choose (2 * m) m : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹) :=
        mul_le_mul_of_nonneg_right hratio_le hmode_nonneg
    _ ≤ E * Real.sqrt (2 / (Real.pi * ((2 * m : ℕ) : ℝ))) :=
        mul_le_mul_of_nonneg_left hmode hE_pos.le
    _ = Real.sqrt (2 / (Real.pi * ((2 * m : ℕ) : ℝ))) * E := by ring

/-- **Upper Gaussian envelope, even `n = 2m`, all coordinates.** For every
`k ≤ 2m`: `C(2m,k)·2^{-2m} ≤ √(2/(π·2m)) · exp(-(k - m)²/(2m))`.
Both tails handled (right tail directly, left tail by `C(2m,k)=C(2m,2m-k)`). -/
theorem binom_pmf_upper_envelope_even (m k : ℕ) (hm : 1 ≤ m) (hk : k ≤ 2 * m) :
    ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹)
      ≤ Real.sqrt (2 / (Real.pi * ((2 * m : ℕ) : ℝ)))
        * Real.exp (-(((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ)))) := by
  rcases Nat.lt_or_ge k m with hkm | hmk
  · -- left tail: use k' = 2m - k ≥ m.
    set k' := 2 * m - k with hk'
    have hmk' : m ≤ k' := by omega
    have hk'2m : k' ≤ 2 * m := by omega
    have hsymm : Nat.choose (2 * m) k = Nat.choose (2 * m) k' := by
      rw [hk', Nat.choose_symm hk]
    have hdev : ((k' : ℝ) - (m : ℝ))^2 = ((k : ℝ) - (m : ℝ))^2 := by
      have : (k' : ℝ) = 2 * (m : ℝ) - (k : ℝ) := by
        rw [hk', Nat.cast_sub hk]; push_cast; ring
      rw [this]; ring
    have hright := binom_pmf_upper_envelope_right m k' hmk' hk'2m hm
    rw [hdev] at hright
    rw [hsymm]
    exact hright
  · exact binom_pmf_upper_envelope_right m k hmk hk hm

end Workspace.ProofLemmas.BinomialUpperEnvelope
