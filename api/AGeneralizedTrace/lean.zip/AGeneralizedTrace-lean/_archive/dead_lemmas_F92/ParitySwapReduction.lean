import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.DelProb
import Workspace.Types.BinVec
import Workspace.Types.CoinFlipDist
import Workspace.Types.LengthsOnlyProcess
import Workspace.Types.PartialDeletionProcess
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.LengthsOnlyDifferenceClosedForm
import Workspace.ProofLemmas.CoinFlipDistExists

open Workspace.Types.BinVec

/-- Triangle-inequality assembly: the `ParitySwapBijection` bound follows from a
per-`r` "core" bound on the `b`-marginal of the coin-flip difference times the
middle indicator. The hypothesis `hcore` is the genuine algebraic heart (proved
elsewhere / still open); this lemma supplies the surrounding reduction sorry-free. -/
theorem ParitySwapReduction :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
    ∀ (Se So : Workspace.Types.ProbVec.ProbVec n),
      (∀ i : Fin n, Se.p i =
        (if (i.val) % 2 = 0
         then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) *
              Real.sqrt n *
              ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
         else 0)) →
      (∀ i : Fin n, So.p i =
        (if (i.val) % 2 = 1
         then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) *
              Real.sqrt n *
              ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
         else 0)) →
      ∀ (δ : Workspace.Types.DelProb.DelProb),
        (320 : ℝ) / Real.sqrt n ≤ δ.val → δ.val ≤ 1 / 2 →
        ∀ (lenE : Workspace.Types.LengthsOnlyProcess.LengthsOnlyProcess n Se δ)
          (lenO : Workspace.Types.LengthsOnlyProcess.LengthsOnlyProcess n So δ),
        ∀ (m : Workspace.Types.BinVec.BinVec (n / 2)),
          ∀ (zMinus zPlus : ℕ),
            let α : ℝ :=
              (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n
            let ell : Finset (Fin (n / 2)) :=
              (Finset.univ : Finset (Fin (n / 2))).filter
                (fun j => m.bit j = true)
            -- per-r CORE hypothesis: for every Ce, Co coin-flip dists for Se, So,
            -- the absolute b-marginal of (Ce - Co) against the middle indicator is
            -- bounded by the alternating-product factor.
            (∀ (Ce : Workspace.Types.CoinFlipDist.CoinFlipDist n Se)
               (Co : Workspace.Types.CoinFlipDist.CoinFlipDist n So)
               (r : ℤ), r ∈ Finset.Icc (-((n / 4 : ℕ) : ℤ)) ((n / 4 : ℕ) : ℤ) →
              |∑ b : Workspace.Types.BinVec.BinVec n,
                  ((Ce.toPMF b).toReal - (Co.toPMF b).toReal) *
                    (Workspace.Types.PartialDeletionProcess.middleIndicator n b m r).toReal|
                ≤ ∏ j ∈ ell,
                    α *
                      ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                        (2 ^ n : ℝ)⁻¹) /
                    (1 -
                      α *
                        ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                          (2 ^ n : ℝ)⁻¹))) →
            |((lenE.toPMF (m, zMinus, zPlus)).toReal)
                - ((lenO.toPMF (m, zMinus, zPlus)).toReal)|
              ≤ ∑ r ∈ Finset.Icc (-((n / 4 : ℕ) : ℤ)) ((n / 4 : ℕ) : ℤ),
                  (Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
                  (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
                  (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal *
                  (∏ j ∈ ell,
                    α *
                      ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                        (2 ^ n : ℝ)⁻¹) /
                    (1 -
                      α *
                        ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                          (2 ^ n : ℝ)⁻¹))) := by
  intro n hn hmod Se So hSe hSo δ hδlb hδub lenE lenO m zMinus zPlus
  intro α ell hcore
  -- obtain coin-flip distributions
  obtain ⟨Ce⟩ := CoinFlipDistExists Se
  obtain ⟨Co⟩ := CoinFlipDistExists So
  -- closed form for the difference
  have hclosed := LengthsOnlyDifferenceClosedForm n hn hmod Se So hSe hSo δ hδlb hδub
    lenE lenO Ce Co m zMinus zPlus
  -- Reconcile the two Icc forms: ((n/4:ℕ):ℤ) = (↑n)/4
  have hcast4 : ((n / 4 : ℕ) : ℤ) = (n : ℤ) / 4 := by push_cast; ring
  have hIcc : Finset.Icc (-(n / 4 : ℤ)) ((n / 4 : ℤ))
      = Finset.Icc (-((n / 4 : ℕ) : ℤ)) ((n / 4 : ℕ) : ℤ) := by
    rw [hcast4]
  -- rewrite closed form to the (n/4:ℕ) Icc form
  rw [hIcc] at hclosed
  -- abbreviations for the b-independent factors
  set Icc := Finset.Icc (-((n / 4 : ℕ) : ℤ)) ((n / 4 : ℕ) : ℤ) with hIccdef
  -- The closed form: difference = ∑_b ∑_r (Ce-Co)·offset·prefix·suffix·middle
  -- Swap to ∑_r ∑_b and factor out the b-independent factors.
  have hswap :
      (∑ b : Workspace.Types.BinVec.BinVec n,
        ∑ r ∈ Icc,
          ((Ce.toPMF b).toReal - (Co.toPMF b).toReal) *
            (Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
            (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
            (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal *
            (Workspace.Types.PartialDeletionProcess.middleIndicator n b m r).toReal)
      = ∑ r ∈ Icc,
          ((Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
            (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
            (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal) *
            (∑ b : Workspace.Types.BinVec.BinVec n,
              ((Ce.toPMF b).toReal - (Co.toPMF b).toReal) *
                (Workspace.Types.PartialDeletionProcess.middleIndicator n b m r).toReal) := by
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl (fun r _ => ?_)
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl (fun b _ => ?_)
    ring
  rw [hclosed, hswap]
  -- triangle inequality
  refine le_trans (Finset.abs_sum_le_sum_abs _ _) ?_
  refine Finset.sum_le_sum (fun r hr => ?_)
  -- the three weights are nonneg (toReal of ENNReal)
  have hoff_nn : (0:ℝ) ≤ (Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal :=
    ENNReal.toReal_nonneg
  have hpre_nn : (0:ℝ) ≤ (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal :=
    ENNReal.toReal_nonneg
  have hsuf_nn : (0:ℝ) ≤ (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal :=
    ENNReal.toReal_nonneg
  have hfac_nn : (0:ℝ) ≤
      (Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
        (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
        (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal := by
    positivity
  rw [abs_mul, abs_of_nonneg hfac_nn]
  -- bound the b-sum via hcore
  have hbound := hcore Ce Co r hr
  calc
    ((Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
        (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
        (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal) *
        |∑ b : Workspace.Types.BinVec.BinVec n,
          ((Ce.toPMF b).toReal - (Co.toPMF b).toReal) *
            (Workspace.Types.PartialDeletionProcess.middleIndicator n b m r).toReal|
        ≤ ((Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
            (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
            (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal) *
            (∏ j ∈ ell,
              α *
                ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                  (2 ^ n : ℝ)⁻¹) /
              (1 -
                α *
                  ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                    (2 ^ n : ℝ)⁻¹))) := by
          exact mul_le_mul_of_nonneg_left hbound hfac_nn
    _ = (Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
          (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
          (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal *
          (∏ j ∈ ell,
            α *
              ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                (2 ^ n : ℝ)⁻¹) /
            (1 -
              α *
                ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                  (2 ^ n : ℝ)⁻¹))) := by ring
