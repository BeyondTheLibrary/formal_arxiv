import Mathlib
import Workspace.Types.StirlingAxioms
import Workspace.ProofLemmas.BinomialLowerEnvelope
import Workspace.ProofLemmas.BinomialUpperEnvelope

open Workspace.Types.StirlingAxioms

namespace Workspace.ProofLemmas.BinomialUpperEnvelopeOdd

set_option maxHeartbeats 1600000

/-!
# Upper Gaussian envelope for the centred binomial pmf — ODD `n = 2m+1`

Mirror of `BinomialUpperEnvelope` (even case) for odd `n = 2m+1`.  The mode is the
*lattice* point `m+1` (equivalently `m`, by symmetry), and the Gaussian is centred
at the *half-integer* `(2m+1)/2 = m + 1/2`.

Telescoping the sharp per-step bound `log(C(n,j+1)/C(n,j)) ≤ (n-2j-1)/(j+1)`
(`BinomialUpperEnvelope.log_ratio_step_le`) from the mode `m+1` up to `k` gives,
with `d := k - (m+1)`,

  `log(C(2m+1,k)/C(2m+1,m+1)) ≤ -(d² + d)/(2m+1)`.

The Gaussian deviation at `k` is `k - (2m+1)/2 = d + 1/2`, so
`(d + 1/2)² = d² + d + 1/4`.  Hence the telescoped exponent `-(d²+d)/(2m+1)`
is exactly `1/(4(2m+1))` *larger* (less negative) than the target Gaussian
exponent `-(d+1/2)²/(2m+1)`.  This `1/(4n)` gap is absorbed by the strict
slack between the true mode value and `G := √(2/(πn))`:

  `C(2m+1,m+1)·2^{-(2m+1)} ≤ 1/(√π·√(m+1)) ≤ G·exp(-1/(4(2m+1)))`,

the last step reducing (after squaring and `exp(-x) ≥ 1-x`) to the manifestly
positive polynomial inequality `16m² + 9m + 1 ≥ 0`.  Combining,

  `C(2m+1,k)·2^{-(2m+1)} ≤ G·exp(-(k - (2m+1)/2)²/(2m+1))`,

the SOUND odd-`n` Gaussian envelope with exponent constant `c = 1`.
-/

/-- **Telescope-to-quadratic, odd `n = 2m+1`, right tail.** For `m+1 ≤ k ≤ 2m+1`
(`d := k - (m+1)`):
`log(C(2m+1,k)/C(2m+1,m+1)) ≤ -((d² + d)/(2m+1))`.

Each telescoped term `(n - 2(m'+i) - 1)/((m'+i)+1)` (mode `m' = m+1`, `n = 2m+1`)
has numerator `-(2i+2) ≤ 0` and denominator `(m+i+2) ≤ n` (since `i ≤ m-1`); dividing
a nonpositive number by the LARGER denominator `n` makes it less negative, so
`term ≤ -(2i+2)/n`.  Summing, `∑ = -(d²+d)/n`. -/
theorem log_ratio_quadratic_upper_odd (m k : ℕ) (hmk : m + 1 ≤ k) (hk : k ≤ 2 * m + 1)
    (hm : 1 ≤ m) :
    Real.log ((Nat.choose (2 * m + 1) k : ℝ) / (Nat.choose (2 * m + 1) (m + 1) : ℝ))
      ≤ -((((k : ℝ) - ((m : ℝ) + 1))^2 + ((k : ℝ) - ((m : ℝ) + 1))) / (2 * (m : ℝ) + 1)) := by
  set n := 2 * m + 1 with hn
  have hkn : k ≤ n := by rw [hn]; omega
  have hbase := BinomialUpperEnvelope.log_ratio_mode_to_k_le n (m + 1) k hmk hkn
  push_cast at hbase
  set d := k - (m + 1) with hd
  have hdk : (d : ℝ) = (k : ℝ) - ((m : ℝ) + 1) := by
    rw [hd, Nat.cast_sub hmk]; push_cast; ring
  have hn_pos : (0 : ℝ) < (n : ℝ) := by rw [hn]; positivity
  have hn_eq : (n : ℝ) = 2 * (m : ℝ) + 1 := by rw [hn]; push_cast; ring
  -- Each term ≤ (-1 - 2i - 1)/n = (-(2i+2))/n, using denominator ≤ n.
  have hterm : ∀ i ∈ Finset.range d,
      ((n : ℝ) - 2 * (((m : ℝ) + 1) + (i : ℝ)) - 1) / ((((m : ℝ) + 1) + (i : ℝ)) + 1)
        ≤ ((-1 : ℝ) - 2 * (i : ℝ) - 1) / (n : ℝ) := by
    intro i hi
    rw [Finset.mem_range] at hi
    -- numerator = -(2i+2) ≤ 0  (using n = 2m+1)
    have hnum_eq : (n : ℝ) - 2 * (((m : ℝ) + 1) + (i : ℝ)) - 1 = (-1 : ℝ) - 2 * (i : ℝ) - 1 := by
      rw [hn_eq]; ring
    rw [hnum_eq]
    have hnum_nonpos : ((-1 : ℝ) - 2 * (i : ℝ) - 1) ≤ 0 := by
      have : (0:ℝ) ≤ (i:ℝ) := Nat.cast_nonneg _
      linarith
    have hden_pos : (0 : ℝ) < (((m : ℝ) + 1) + (i : ℝ)) + 1 := by positivity
    -- denominator (m+1+i)+1 = m+i+2 ≤ n = 2m+1, since i ≤ d-1 ≤ m-1.
    have hi_le : i + 1 ≤ d := by omega
    have hden_le_n : (((m : ℝ) + 1) + (i : ℝ)) + 1 ≤ (n : ℝ) := by
      have hdm : d ≤ m := by omega
      have : m + i + 2 ≤ n := by rw [hn]; omega
      calc (((m : ℝ) + 1) + (i : ℝ)) + 1 = ((m + i + 2 : ℕ) : ℝ) := by push_cast; ring
        _ ≤ (n : ℝ) := by exact_mod_cast this
    rw [div_le_div_iff₀ hden_pos hn_pos]
    nlinarith [hnum_nonpos, hden_le_n, hn_pos, hden_pos]
  have hsum_le : (∑ i ∈ Finset.range d,
        ((n : ℝ) - 2 * (((m : ℝ) + 1) + (i : ℝ)) - 1) / ((((m : ℝ) + 1) + (i : ℝ)) + 1))
      ≤ (∑ i ∈ Finset.range d, ((-1 : ℝ) - 2 * (i : ℝ) - 1) / (n : ℝ)) :=
    Finset.sum_le_sum hterm
  -- evaluate RHS sum = (-(d²+d))/n
  have hrhs : (∑ i ∈ Finset.range d, ((-1 : ℝ) - 2 * (i : ℝ) - 1) / (n : ℝ))
      = (-((d : ℝ)^2 + (d : ℝ))) / (n : ℝ) := by
    rw [← Finset.sum_div, BinomialLowerEnvelope.telescope_gauss_sum (-1) d]
    rw [show (d : ℝ) * (-1) - (d : ℝ)^2 = -((d : ℝ)^2 + (d : ℝ)) by ring]
  rw [hrhs] at hsum_le
  -- chain and convert d to (k - (m+1))
  have hstep1 : Real.log ((Nat.choose n k : ℝ) / (Nat.choose n (m + 1) : ℝ))
      ≤ (-((d : ℝ)^2 + (d : ℝ))) / (n : ℝ) := le_trans hbase hsum_le
  have hfinal : (-((d : ℝ)^2 + (d : ℝ))) / (n : ℝ)
      = -((((k : ℝ) - ((m : ℝ) + 1))^2 + ((k : ℝ) - ((m : ℝ) + 1))) / (2 * (m : ℝ) + 1)) := by
    rw [hdk, hn_eq]; ring
  rw [hfinal] at hstep1
  exact hstep1

/-! ## Tight odd mode bound via Mathlib's `Stirling`

`C(2m+1,m+1)·2^{-(2m+1)} ≤ 1/(√π·√(m+1))`.  Re-derived here (the analogous
`clb_core_upper` in `StirlingAxioms` is `private`) from the exact identity
`centralBinom k · stirlingSeq(k)² · √k = stirlingSeq(2k)·4^k` together with
`stirlingSeq(2k) ≤ stirlingSeq(k)` (antitonicity) and `√π ≤ stirlingSeq(k)`. -/

open Stirling in
/-- `C(2m+1,m+1)·2^{-(2m+1)} ≤ 1/(√π·√(m+1))`, the tight Stirling mode bound for
odd `n = 2m+1`. -/
theorem central_binom_odd_mode_bound (m : ℕ) (hm : 1 ≤ m) :
    ((Nat.choose (2 * m + 1) (m + 1) : ℝ) * (2 ^ (2 * m + 1) : ℝ)⁻¹)
      ≤ 1 / (Real.sqrt Real.pi * Real.sqrt ((m : ℝ) + 1)) := by
  set k : ℕ := m + 1 with hk
  have hk1 : 1 ≤ k := by omega
  have hkR : (0:ℝ) < (k:ℝ) := by exact_mod_cast hk1
  -- centralBinom k ≤ 4^k / (√π · √k), re-derived.
  have hcore : (Nat.centralBinom k : ℝ) ≤ (4:ℝ)^k / (Real.sqrt Real.pi * Real.sqrt k) := by
    set c : ℝ := (Nat.centralBinom k : ℝ) with hc
    set D : ℝ := ((k:ℝ) / Real.exp 1) ^ k with hD
    set Sk : ℝ := stirlingSeq k with hSk
    set S2k : ℝ := stirlingSeq (2*k) with hS2k
    have hDpos : 0 < D := by rw [hD]; positivity
    have hfact_stirling : ∀ j : ℕ, 1 ≤ j →
        (Nat.factorial j : ℝ) = stirlingSeq j * (Real.sqrt (2 * j) * ((j : ℝ) / Real.exp 1) ^ j) := by
      intro j hj
      have hpos : (0 : ℝ) < Real.sqrt (2 * j) * ((j : ℝ) / Real.exp 1) ^ j := by
        apply mul_pos
        · apply Real.sqrt_pos.mpr; positivity
        · positivity
      rw [Stirling.stirlingSeq]; field_simp
    have hfk : (Nat.factorial k : ℝ) = Sk * (Real.sqrt (2 * k) * D) := hfact_stirling k hk1
    have hf2k : (Nat.factorial (2*k) : ℝ) = S2k * (Real.sqrt (2 * ((2*k:ℕ):ℝ)) * (((2*k:ℕ):ℝ) / Real.exp 1) ^ (2*k)) :=
      hfact_stirling (2*k) (by omega)
    have hpow : (((2*k:ℕ):ℝ) / Real.exp 1) ^ (2*k) = (4:ℝ)^k * D^2 := by
      rw [hD]
      rw [show ((2*k:ℕ):ℝ) = 2 * (k:ℝ) by push_cast; ring]
      rw [mul_div_assoc, mul_pow]
      rw [show ((2:ℝ)^(2*k)) = 4^k by rw [pow_mul]; norm_num]
      rw [show (2*k) = k*2 by ring, pow_mul]
    have hsq4 : Real.sqrt (2 * ((2*k:ℕ):ℝ)) = 2 * Real.sqrt k := by
      rw [show (2 * ((2*k:ℕ):ℝ) : ℝ) = (2:ℝ)^2 * k by push_cast; ring, Real.sqrt_mul (by positivity), Real.sqrt_sq (by norm_num)]
    have hsq2 : Real.sqrt (2 * (k:ℝ)) ^ 2 = 2 * k := by
      rw [Real.sq_sqrt (by positivity)]
    have hcid : c * ((Nat.factorial k : ℝ))^2 = (Nat.factorial (2*k) : ℝ) := by
      have h := Nat.choose_mul_factorial_mul_factorial (Nat.le_mul_of_pos_left k (by norm_num : 0 < 2))
      rw [hc, Nat.centralBinom_eq_two_mul_choose]
      have h2 : 2 * k - k = k := by omega
      rw [h2] at h
      have := congrArg (Nat.cast : ℕ → ℝ) h
      push_cast at this; nlinarith [this]
    have hSkpos : 0 < Sk := by
      rw [hSk, show k = (k-1)+1 by omega]
      have h := Stirling.stirlingSeq'_pos (k-1)
      simpa [Function.comp] using h
    have hS2kpos : 0 < S2k := by
      rw [hS2k, show 2*k = (2*k-1)+1 by omega]
      have h := Stirling.stirlingSeq'_pos (2*k-1)
      simpa [Function.comp] using h
    have hsqkpos : 0 < Real.sqrt k := Real.sqrt_pos.mpr hkR
    have hsqk_sq : Real.sqrt k ^ 2 = k := Real.sq_sqrt hkR.le
    have hkey : c * Sk^2 * Real.sqrt k = S2k * (4:ℝ)^k := by
      have e1 : c * (Sk * (Real.sqrt (2 * k) * D))^2
          = S2k * (2 * Real.sqrt k * ((4:ℝ)^k * D^2)) := by
        rw [← hfk]
        rw [hcid, hf2k, hsq4, hpow]
      have hD2 : 0 < D^2 := by positivity
      have e2 : (Sk * (Real.sqrt (2 * k) * D))^2 = Sk^2 * (2 * k) * D^2 := by
        have : Real.sqrt (2 * (k:ℝ))^2 = 2 * k := hsq2
        ring_nf
        ring_nf at this
        nlinarith [this]
      rw [e2] at e1
      have hcancel : c * Sk^2 * (2*k) = S2k * (2 * Real.sqrt k * (4:ℝ)^k) := by
        have hD2ne : D^2 ≠ 0 := ne_of_gt hD2
        field_simp at e1 ⊢
        nlinarith [e1, hD2]
      have hk_eq : (k:ℝ) = Real.sqrt k * Real.sqrt k := by nlinarith [hsqk_sq]
      have hfac : (c * Sk^2 * Real.sqrt k - S2k * (4:ℝ)^k) * (2 * Real.sqrt k) = 0 := by
        have expand : (c * Sk^2 * Real.sqrt k - S2k * (4:ℝ)^k) * (2 * Real.sqrt k)
            = c * Sk^2 * (2 * (Real.sqrt k * Real.sqrt k)) - S2k * (2 * Real.sqrt k * (4:ℝ)^k) := by ring
        rw [expand, ← hk_eq]; linarith [hcancel]
      have hne : (2 * Real.sqrt k) ≠ 0 := by positivity
      have hz : c * Sk^2 * Real.sqrt k - S2k * (4:ℝ)^k = 0 :=
        (mul_eq_zero.mp hfac).resolve_right hne
      linarith [hz]
    have hS2k_le_Sk : S2k ≤ Sk := by
      rw [hS2k, hSk]
      have h := Stirling.stirlingSeq'_antitone (a := k-1) (b := 2*k-1) (by omega)
      simp only [Function.comp] at h
      rwa [show (k-1).succ = k by omega, show (2*k-1).succ = 2*k by omega] at h
    have hsqrtpi_le : Real.sqrt Real.pi ≤ Sk := by
      rw [hSk]; exact Stirling.sqrt_pi_le_stirlingSeq (by omega)
    have hpipos : 0 < Real.sqrt Real.pi := Real.sqrt_pos.mpr Real.pi_pos
    have h4pos : (0:ℝ) < (4:ℝ)^k := by positivity
    have hcnn : 0 ≤ c := by rw [hc]; positivity
    rw [le_div_iff₀ (by positivity)]
    have hSk2 : 0 < Sk^2 := by positivity
    have key2 : c * (Real.sqrt Real.pi * Real.sqrt k) * Sk^2 = Real.sqrt Real.pi * (S2k * (4:ℝ)^k) := by
      nlinarith [hkey]
    have ineq : Real.sqrt Real.pi * (S2k * (4:ℝ)^k) ≤ (4:ℝ)^k * Sk^2 := by
      nlinarith [mul_le_mul hsqrtpi_le hS2k_le_Sk hS2kpos.le hSkpos.le, h4pos, sq_nonneg Sk]
    nlinarith [key2, ineq, hSk2, mul_nonneg hcnn (mul_nonneg hpipos.le hsqkpos.le)]
  -- Bridge: 2·C(2m+1,m) = centralBinom(m+1), and C(2m+1,m+1)=C(2m+1,m).
  have hbridge : 2 * Nat.choose (2*m+1) m = Nat.centralBinom (m+1) := by
    rw [Nat.centralBinom_eq_two_mul_choose]
    have hsymm : Nat.choose (2*m+1) (m+1) = Nat.choose (2*m+1) m := by
      rw [← Nat.choose_symm (by omega : m+1 ≤ 2*m+1)]; congr 1; omega
    have hpascal := Nat.choose_succ_succ (2*m+1) m
    show 2 * (2*m+1).choose m = (2*(m+1)).choose (m+1)
    rw [show 2*(m+1) = (2*m+1)+1 by ring, hpascal, hsymm]; ring
  have hsymm2 : Nat.choose (2*m+1) (m+1) = Nat.choose (2*m+1) m := by
    rw [← Nat.choose_symm (by omega : m+1 ≤ 2*m+1)]; congr 1; omega
  have hbinR : (Nat.choose (2*m+1) (m+1) : ℝ) = (Nat.centralBinom (m+1) : ℝ) / 2 := by
    rw [hsymm2]
    have := congrArg (Nat.cast : ℕ → ℝ) hbridge
    push_cast at this; linarith [this]
  rw [hbinR]
  have hpow2 : ((2:ℝ)^(2*m+1)) = 2 * (4:ℝ)^m := by rw [pow_succ, pow_mul]; ring_nf
  rw [hpow2]
  -- LHS = centralBinom(m+1) · (4^(m+1))⁻¹
  have hlhs_eq : (Nat.centralBinom (m+1) : ℝ) / 2 * (2 * (4:ℝ)^m)⁻¹
      = (Nat.centralBinom (m+1) : ℝ) * ((4:ℝ)^(m+1))⁻¹ := by
    rw [pow_succ]; field_simp; ring
  rw [hlhs_eq]
  have hkpow : ((4:ℝ)^(m+1))⁻¹ = ((4:ℝ)^k)⁻¹ := by rw [hk]
  rw [hkpow]
  have hkmR : Real.sqrt ((m : ℝ) + 1) = Real.sqrt (k : ℝ) := by
    rw [hk]; push_cast; ring_nf
  rw [hkmR]
  have h4kpos : (0:ℝ) < (4:ℝ)^k := by positivity
  have hpipos : 0 < Real.sqrt Real.pi := Real.sqrt_pos.mpr Real.pi_pos
  have hsqkpos : 0 < Real.sqrt (k:ℝ) := Real.sqrt_pos.mpr hkR
  rw [mul_inv_le_iff₀ h4kpos]
  rw [div_mul_eq_mul_div, le_div_iff₀ (by positivity)]
  -- goal: centralBinom k · (√π·√k) ≤ 1 · 4^k = 4^k ... arrange via hcore
  have := hcore
  rw [le_div_iff₀ (by positivity)] at this
  nlinarith [this, hpipos, hsqkpos, mul_pos hpipos hsqkpos]

/-- **Mode-gap bound, odd `n = 2m+1`.** `1/(√π·√(m+1)) ≤ √(2/(π(2m+1)))·exp(-1/(4(2m+1)))`.

Reduces (after squaring and `exp(-x) ≥ 1-x`) to `16m²+9m+1 ≥ 0`. -/
theorem mode_le_G_exp (m : ℕ) (hm : 1 ≤ m) :
    1 / (Real.sqrt Real.pi * Real.sqrt ((m : ℝ) + 1))
      ≤ Real.sqrt (2 / (Real.pi * (2 * (m : ℝ) + 1)))
          * Real.exp (-(1 / (4 * (2 * (m : ℝ) + 1)))) := by
  have hmR : (1:ℝ) ≤ (m:ℝ) := by exact_mod_cast hm
  set n : ℝ := 2 * (m : ℝ) + 1 with hn
  have hn_pos : 0 < n := by rw [hn]; positivity
  have hpi : 0 < Real.pi := Real.pi_pos
  have hm1 : (0:ℝ) < (m:ℝ) + 1 := by positivity
  -- exp lower bound: exp(-1/(4n)) ≥ 1 - 1/(4n) > 0
  have hx_pos : (0:ℝ) < 1 / (4 * n) := by positivity
  have hexp_ge : (1 : ℝ) - 1 / (4 * n) ≤ Real.exp (-(1 / (4 * n))) := by
    have h := Real.add_one_le_exp (-(1 / (4 * n)))
    linarith [h]
  have hlin_pos : (0:ℝ) < 1 - 1 / (4 * n) := by
    have h4n : (1:ℝ) < 4 * n := by rw [hn]; nlinarith [hmR]
    have : 1 / (4 * n) < 1 := by
      rw [div_lt_one (by positivity)]; exact h4n
    linarith
  -- It suffices to bound by G·(1 - 1/(4n)) ≤ G·exp(...)
  set G : ℝ := Real.sqrt (2 / (Real.pi * n)) with hG
  have hG_pos : 0 < G := by rw [hG]; apply Real.sqrt_pos.mpr; positivity
  have hLpos : (0:ℝ) < 1 / (Real.sqrt Real.pi * Real.sqrt ((m : ℝ) + 1)) := by
    apply div_pos one_pos; positivity
  refine le_trans ?_ (mul_le_mul_of_nonneg_left hexp_ge hG_pos.le)
  -- Now: 1/(√π√(m+1)) ≤ G·(1-1/(4n)).  LHS = √(1/(π(m+1))).
  have hLeq : 1 / (Real.sqrt Real.pi * Real.sqrt ((m : ℝ) + 1))
      = Real.sqrt (1 / (Real.pi * ((m : ℝ) + 1))) := by
    rw [← Real.sqrt_mul hpi.le, one_div, ← Real.sqrt_inv, one_div]
  rw [hLeq]
  -- RHS ≥ 0; use Real.sqrt_le_left style: √a ≤ b  ⟺  a ≤ b²  (b ≥ 0).
  have hRHS_nonneg : (0:ℝ) ≤ G * (1 - 1 / (4 * n)) := mul_nonneg hG_pos.le hlin_pos.le
  apply Real.sqrt_le_iff.mpr
  refine ⟨hRHS_nonneg, ?_⟩
  -- (G·(1-1/(4n)))² = (2/(πn))·(1-1/(4n))²
  have hRHSsq : (G * (1 - 1 / (4 * n)))^2 = (2 / (Real.pi * n)) * (1 - 1 / (4 * n))^2 := by
    rw [mul_pow, hG, Real.sq_sqrt (by positivity)]
  rw [hRHSsq]
  -- goal: 1/(π(m+1)) ≤ (2/(πn))·(1-1/(4n))², with n = 2m+1.
  -- Establish it as a cleared-denominator polynomial inequality.
  have hMnn : (0:ℝ) ≤ (m:ℝ) := by positivity
  have hcleared : 1 / (Real.pi * ((m : ℝ) + 1))
      ≤ 2 / (Real.pi * n) * (1 - 1 / (4 * n)) ^ 2 := by
    rw [hn]
    -- RHS = (m+1)(4n-1)²/(8 n³) ; LHS = 1/(π(m+1)).  Clear π and powers.
    have hrhs_eq : 2 / (Real.pi * (2 * (m:ℝ) + 1)) * (1 - 1 / (4 * (2 * (m:ℝ) + 1))) ^ 2
        = (4 * (2 * (m:ℝ) + 1) - 1)^2
            / (Real.pi * (8 * (2 * (m:ℝ) + 1)^3)) := by
      rw [eq_div_iff (by positivity)]
      field_simp
      ring
    rw [hrhs_eq]
    rw [div_le_div_iff₀ (by positivity : (0:ℝ) < Real.pi * ((m:ℝ) + 1))
        (by positivity : (0:ℝ) < Real.pi * (8 * (2 * (m:ℝ) + 1)^3))]
    -- goal: 1 · (π·8n³) ≤ (4n-1)² · (π(m+1)).  Since (4n-1)²(m+1) - 8n³ = 16m²+9m+1 ≥ 0.
    nlinarith [hMnn, sq_nonneg (m:ℝ), Real.pi_pos,
      mul_nonneg hMnn hMnn,
      mul_nonneg (mul_nonneg (by norm_num : (0:ℝ) ≤ 16) (mul_nonneg hMnn hMnn)) Real.pi_pos.le,
      mul_pos Real.pi_pos (by positivity : (0:ℝ) < (m:ℝ)+1)]
  exact hcleared

/-- **Upper Gaussian envelope, right tail, odd `n = 2m+1`.** For `m+1 ≤ k ≤ 2m+1`:
`C(2m+1,k)·2^{-(2m+1)} ≤ √(2/(π(2m+1)))·exp(-(k - (2m+1)/2)²/(2m+1))`. -/
theorem binom_pmf_upper_envelope_odd_right (m k : ℕ) (hmk : m + 1 ≤ k) (hk : k ≤ 2 * m + 1)
    (hm : 1 ≤ m) :
    ((Nat.choose (2 * m + 1) k : ℝ) * (2 ^ (2 * m + 1) : ℝ)⁻¹)
      ≤ Real.sqrt (2 / (Real.pi * ((2 * m + 1 : ℕ) : ℝ)))
        * Real.exp (-(((k : ℝ) - ((2 * (m : ℝ) + 1) / 2))^2 / (2 * (m : ℝ) + 1))) := by
  have hn1 : 1 ≤ 2 * m + 1 := by omega
  have hkn : k ≤ 2 * m + 1 := hk
  set G : ℝ := Real.sqrt (2 / (Real.pi * ((2 * m + 1 : ℕ) : ℝ))) with hG
  set GExp : ℝ := Real.exp (-(((k : ℝ) - ((2 * (m : ℝ) + 1) / 2))^2 / (2 * (m : ℝ) + 1))) with hGExp
  have hG_pos : 0 < G := by
    rw [hG]; apply Real.sqrt_pos.mpr; positivity
  -- mode value bound: M = C(2m+1,m+1)·2^{-(2m+1)} ≤ 1/(√π√(m+1))
  have hmode := central_binom_odd_mode_bound m hm
  set B : ℝ := 1 / (Real.sqrt Real.pi * Real.sqrt ((m : ℝ) + 1)) with hB
  have hB_pos : 0 < B := by rw [hB]; apply div_pos one_pos; positivity
  -- mode gap: B ≤ G · exp(-1/(4(2m+1)))
  have hgap := mode_le_G_exp m hm
  have hG_eq : Real.sqrt (2 / (Real.pi * (2 * (m : ℝ) + 1))) = G := by
    rw [hG]; congr 2; push_cast; ring
  rw [hG_eq] at hgap
  -- log-ratio ⟹ ratio ≤ exp(-(d²+d)/n)
  have hlog := log_ratio_quadratic_upper_odd m k hmk hk hm
  set d : ℝ := (k : ℝ) - ((m : ℝ) + 1) with hd
  have hCmode_pos : (0 : ℝ) < (Nat.choose (2 * m + 1) (m + 1) : ℝ) := by
    have : 0 < Nat.choose (2 * m + 1) (m + 1) := Nat.choose_pos (by omega)
    exact_mod_cast this
  have hratio_pos : (0 : ℝ) < (Nat.choose (2 * m + 1) k : ℝ) / (Nat.choose (2 * m + 1) (m + 1) : ℝ) := by
    have : 0 < Nat.choose (2 * m + 1) k := Nat.choose_pos hkn
    have h2 : (0 : ℝ) < (Nat.choose (2 * m + 1) k : ℝ) := by exact_mod_cast this
    positivity
  set RExp : ℝ := Real.exp (-((d^2 + d) / (2 * (m : ℝ) + 1))) with hRExp
  have hRExp_pos : 0 < RExp := Real.exp_pos _
  have hratio_le : (Nat.choose (2 * m + 1) k : ℝ) / (Nat.choose (2 * m + 1) (m + 1) : ℝ) ≤ RExp := by
    rw [hRExp, ← Real.exp_log hratio_pos]
    apply Real.exp_le_exp.mpr
    rw [hd]
    linarith [hlog]
  -- C(2m+1,k)·2^{-n} = ratio · M
  have hkey : (Nat.choose (2 * m + 1) k : ℝ) * (2 ^ (2 * m + 1) : ℝ)⁻¹
      = ((Nat.choose (2 * m + 1) k : ℝ) / (Nat.choose (2 * m + 1) (m + 1) : ℝ))
          * ((Nat.choose (2 * m + 1) (m + 1) : ℝ) * (2 ^ (2 * m + 1) : ℝ)⁻¹) := by
    field_simp
  rw [hkey]
  set M : ℝ := (Nat.choose (2 * m + 1) (m + 1) : ℝ) * (2 ^ (2 * m + 1) : ℝ)⁻¹ with hM
  have hM_nonneg : 0 ≤ M := by rw [hM]; positivity
  -- exponent identity: GExp = RExp · exp(-1/(4(2m+1)))
  have hExpId : GExp = RExp * Real.exp (-(1 / (4 * (2 * (m : ℝ) + 1)))) := by
    rw [hGExp, hRExp, ← Real.exp_add]
    congr 1
    rw [hd]
    have hnpos : (2 * (m:ℝ) + 1) ≠ 0 := by positivity
    field_simp
    ring
  -- chain: ratio·M ≤ RExp·B ≤ RExp·(G·exp(-1/(4n))) = G·(RExp·exp(-1/(4n))) = G·GExp
  calc ((Nat.choose (2 * m + 1) k : ℝ) / (Nat.choose (2 * m + 1) (m + 1) : ℝ)) * M
      ≤ RExp * M := mul_le_mul_of_nonneg_right hratio_le hM_nonneg
    _ ≤ RExp * B := mul_le_mul_of_nonneg_left (le_trans hmode (le_refl _)) hRExp_pos.le
    _ ≤ RExp * (G * Real.exp (-(1 / (4 * (2 * (m : ℝ) + 1))))) :=
        mul_le_mul_of_nonneg_left hgap hRExp_pos.le
    _ = G * (RExp * Real.exp (-(1 / (4 * (2 * (m : ℝ) + 1))))) := by ring
    _ = G * GExp := by rw [hExpId]

/-- **Upper Gaussian envelope, odd `n = 2m+1`, all coordinates.** For every
`k ≤ 2m+1`: `C(2m+1,k)·2^{-(2m+1)} ≤ √(2/(π(2m+1)))·exp(-(k - (2m+1)/2)²/(2m+1))`.
Right tail (`k ≥ m+1`) directly; left tail by `C(2m+1,k)=C(2m+1,2m+1-k)`. -/
theorem binom_pmf_upper_envelope_odd (m k : ℕ) (hm : 1 ≤ m) (hk : k ≤ 2 * m + 1) :
    ((Nat.choose (2 * m + 1) k : ℝ) * (2 ^ (2 * m + 1) : ℝ)⁻¹)
      ≤ Real.sqrt (2 / (Real.pi * ((2 * m + 1 : ℕ) : ℝ)))
        * Real.exp (-(((k : ℝ) - ((2 * (m : ℝ) + 1) / 2))^2 / (2 * (m : ℝ) + 1))) := by
  rcases Nat.lt_or_ge k (m + 1) with hkm | hmk
  · -- left tail: k ≤ m. Use k' = 2m+1-k ≥ m+1.
    set k' := 2 * m + 1 - k with hk'
    have hmk' : m + 1 ≤ k' := by omega
    have hk'2m : k' ≤ 2 * m + 1 := by omega
    have hsymm : Nat.choose (2 * m + 1) k = Nat.choose (2 * m + 1) k' := by
      rw [hk', Nat.choose_symm hk]
    have hdev : ((k' : ℝ) - ((2 * (m : ℝ) + 1) / 2))^2 = ((k : ℝ) - ((2 * (m : ℝ) + 1) / 2))^2 := by
      have hk'R : (k' : ℝ) = (2 * (m : ℝ) + 1) - (k : ℝ) := by
        rw [hk', Nat.cast_sub hk]; push_cast; ring
      rw [hk'R]; ring
    have hright := binom_pmf_upper_envelope_odd_right m k' hmk' hk'2m hm
    rw [hdev] at hright
    rw [hsymm]
    exact hright
  · exact binom_pmf_upper_envelope_odd_right m k hmk hk hm

end Workspace.ProofLemmas.BinomialUpperEnvelopeOdd
