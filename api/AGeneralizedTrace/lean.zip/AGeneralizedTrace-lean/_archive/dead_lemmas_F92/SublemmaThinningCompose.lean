import Mathlib
import Workspace.Types.BinVec
import Workspace.Types.Trace
import Workspace.Types.DelProb
import Workspace.Types.DeletionChannel

open Workspace.Types.BinVec
open Workspace.Types.Trace
open Workspace.Types.DelProb
open Workspace.Types.DeletionChannel

/--
**Sublemma: Composition of two independent Bernoulli deletion stages.**

For any `0 < δ₁ ≤ δ₂ < 1` (encoded by `δ₁ δ₂ : DelProb` with `δ₁.val ≤ δ₂.val`)
and `q : DelProb` defined by `q.val = (δ₂.val - δ₁.val) / (1 - δ₁.val)`,
running an independent rate-`δ₁` deletion followed by an independent rate-`q`
deletion produces the same trace distribution as a single rate-`δ₂`
deletion.

The lemma is stated at the level of the keep-set sum representation of
the trace PMF (as in
`Workspace.Types.DeletionChannel.DeletionChannel.pmf_eq_keep_set_sum`):
the single-stage keep-set sum at rate `δ₂` equals the iterated two-stage
keep-set sum (combining masks `m₁` from the rate-`δ₁` stage and `m₂` from
the rate-`q` stage by pointwise conjunction `fun i => m₁ i ∧ m₂ i`).

Equivalently — and this is the per-coordinate identity that drives the
proof — `1 - δ₂.val = (1 - δ₁.val) * (1 - q.val)`.
-/
theorem SublemmaThinningCompose :
    ∀ (n : ℕ) (b : BinVec n) (δ₁ δ₂ q : DelProb)
      (_h_le : δ₁.val ≤ δ₂.val)
      (_h_q : q.val = (δ₂.val - δ₁.val) / (1 - δ₁.val))
      (τ : Trace n),
      (∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1 : ENNReal) else 0) *
            ∏ i : Fin n,
              (if m i then ENNReal.ofReal (1 - δ₂.val)
               else ENNReal.ofReal δ₂.val))
        =
      (∑ m₁ : Fin n → Bool, ∑ m₂ : Fin n → Bool,
          (if restrict b (fun i => m₁ i ∧ m₂ i) = τ.bits then (1 : ENNReal) else 0) *
            ∏ i : Fin n,
              ((if m₁ i then ENNReal.ofReal (1 - δ₁.val)
                else ENNReal.ofReal δ₁.val) *
               (if m₂ i then ENNReal.ofReal (1 - q.val)
                else ENNReal.ofReal q.val))) := by
  intro n b δ₁ δ₂ q _h_le h_q τ
  -- Numerical preliminaries from DelProb constraints.
  have hδ₁_pos : 0 < δ₁.val := δ₁.pos
  have hδ₁_lt : δ₁.val < 1 := δ₁.lt_one
  have hδ₂_pos : 0 < δ₂.val := δ₂.pos
  have hδ₂_lt : δ₂.val < 1 := δ₂.lt_one
  have hq_pos : 0 < q.val := q.pos
  have hq_lt : q.val < 1 := q.lt_one
  have h1mδ₁_pos : (0:ℝ) < 1 - δ₁.val := by linarith
  have h1mδ₁_nn : (0:ℝ) ≤ 1 - δ₁.val := h1mδ₁_pos.le
  have h1mδ₂_pos : (0:ℝ) < 1 - δ₂.val := by linarith
  have h1mδ₂_nn : (0:ℝ) ≤ 1 - δ₂.val := h1mδ₂_pos.le
  have h1mq_pos : (0:ℝ) < 1 - q.val := by linarith
  have h1mq_nn : (0:ℝ) ≤ 1 - q.val := h1mq_pos.le
  have hq_nn : (0:ℝ) ≤ q.val := hq_pos.le
  have hδ₁_nn : (0:ℝ) ≤ δ₁.val := hδ₁_pos.le
  have hδ₂_nn : (0:ℝ) ≤ δ₂.val := hδ₂_pos.le
  have h1mδ₁_ne : (1:ℝ) - δ₁.val ≠ 0 := ne_of_gt h1mδ₁_pos
  -- Per-coordinate identity 1: (1-δ₁)(1-q) = 1-δ₂.
  have key_true :
      ENNReal.ofReal (1 - δ₁.val) * ENNReal.ofReal (1 - q.val)
        = ENNReal.ofReal (1 - δ₂.val) := by
    rw [← ENNReal.ofReal_mul h1mδ₁_nn]
    congr 1
    rw [h_q]
    field_simp
    ring
  -- Per-coordinate identity 2: δ₁·q + δ₁·(1-q) + (1-δ₁)·q = δ₂.
  have key_false :
      ENNReal.ofReal δ₁.val * ENNReal.ofReal q.val
        + ENNReal.ofReal δ₁.val * ENNReal.ofReal (1 - q.val)
        + ENNReal.ofReal (1 - δ₁.val) * ENNReal.ofReal q.val
        = ENNReal.ofReal δ₂.val := by
    rw [← ENNReal.ofReal_mul hδ₁_nn, ← ENNReal.ofReal_mul hδ₁_nn,
        ← ENNReal.ofReal_mul h1mδ₁_nn]
    rw [← ENNReal.ofReal_add (by positivity) (mul_nonneg hδ₁_nn h1mq_nn)]
    rw [← ENNReal.ofReal_add (by positivity) (mul_nonneg h1mδ₁_nn hq_nn)]
    congr 1
    rw [h_q]
    field_simp
    ring
  set w₁ : Bool → ENNReal := fun a => if a then ENNReal.ofReal (1 - δ₁.val) else ENNReal.ofReal δ₁.val with hw₁
  set wq : Bool → ENNReal := fun a => if a then ENNReal.ofReal (1 - q.val) else ENNReal.ofReal q.val with hwq
  set w₂ : Bool → ENNReal := fun a => if a then ENNReal.ofReal (1 - δ₂.val) else ENNReal.ofReal δ₂.val with hw₂
  -- Per-coordinate identity (the heart of the proof):
  --   For each Bool c, ∑ a b, [a ∧ b = c] * (w₁ a * wq b) = w₂ c.
  have per_coord : ∀ c : Bool,
      (∑ s : Bool × Bool,
        (if (s.1 && s.2) = c then (1:ENNReal) else 0) * (w₁ s.1 * wq s.2)) = w₂ c := by
    intro c
    rw [show (∑ s : Bool × Bool,
              (if (s.1 && s.2) = c then (1:ENNReal) else 0) * (w₁ s.1 * wq s.2))
          = ∑ a : Bool, ∑ b : Bool,
              (if (a && b) = c then (1:ENNReal) else 0) * (w₁ a * wq b)
          from Fintype.sum_prod_type _]
    cases c with
    | true =>
      simp only [hw₁, hw₂, hwq, Fintype.sum_bool, Bool.and_true, Bool.and_false]
      simp
      exact key_true
    | false =>
      simp only [hw₁, hw₂, hwq, Fintype.sum_bool, Bool.and_true, Bool.and_false]
      simp
      rw [← key_false]
      ring
  -- Cleanup: rewrite (decide (a = true ∧ b = true)) as (a && b).
  have decide_and : ∀ (a b : Bool),
      decide (a = true ∧ b = true) = (a && b) := by
    intros a b; cases a <;> cases b <;> simp
  -- Rewrite RHS to use w₁/wq notation and replace decide-form with &&.
  have rhs_eq :
      (∑ m₁ : Fin n → Bool, ∑ m₂ : Fin n → Bool,
          (if restrict b (fun i => decide (m₁ i = true ∧ m₂ i = true)) = τ.bits
            then (1 : ENNReal) else 0) *
            ∏ i : Fin n,
              ((if m₁ i then ENNReal.ofReal (1 - δ₁.val) else ENNReal.ofReal δ₁.val) *
               (if m₂ i then ENNReal.ofReal (1 - q.val) else ENNReal.ofReal q.val)))
        =
      (∑ m₁ : Fin n → Bool, ∑ m₂ : Fin n → Bool,
          (if restrict b (fun i => m₁ i && m₂ i) = τ.bits then (1 : ENNReal) else 0) *
            ∏ i : Fin n, (w₁ (m₁ i) * wq (m₂ i))) := by
    apply Finset.sum_congr rfl
    intro m₁ _
    apply Finset.sum_congr rfl
    intro m₂ _
    have hfun : (fun i => decide (m₁ i = true ∧ m₂ i = true)) = (fun i => m₁ i && m₂ i) :=
      funext (fun i => decide_and (m₁ i) (m₂ i))
    rw [hfun]
  rw [rhs_eq]
  -- Rewrite LHS using w₂.
  have lhs_eq :
      (∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1 : ENNReal) else 0) *
            ∏ i : Fin n,
              (if m i then ENNReal.ofReal (1 - δ₂.val) else ENNReal.ofReal δ₂.val))
        =
      (∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1 : ENNReal) else 0) *
            ∏ i : Fin n, w₂ (m i)) := rfl
  rw [lhs_eq]
  -- Combine the iterated sum on the RHS into a sum over pairs of functions.
  rw [show (∑ m₁ : Fin n → Bool, ∑ m₂ : Fin n → Bool,
            (if restrict b (fun i => m₁ i && m₂ i) = τ.bits then (1:ENNReal) else 0) *
              ∏ i : Fin n, (w₁ (m₁ i) * wq (m₂ i)))
        = ∑ p : (Fin n → Bool) × (Fin n → Bool),
            (if restrict b (fun i => p.1 i && p.2 i) = τ.bits then (1:ENNReal) else 0) *
              ∏ i : Fin n, (w₁ (p.1 i) * wq (p.2 i))
        from (Fintype.sum_prod_type' _).symm]
  -- Reindex via the equiv (Fin n → Bool) × (Fin n → Bool) ≃ (Fin n → Bool × Bool).
  let e : ((Fin n → Bool) × (Fin n → Bool)) ≃ (Fin n → Bool × Bool) :=
    { toFun := fun p i => (p.1 i, p.2 i)
      invFun := fun g => (fun i => (g i).1, fun i => (g i).2)
      left_inv := fun p => by ext <;> rfl
      right_inv := fun g => by ext i <;> rfl }
  rw [show (∑ p : (Fin n → Bool) × (Fin n → Bool),
            (if restrict b (fun i => p.1 i && p.2 i) = τ.bits then (1:ENNReal) else 0) *
              ∏ i : Fin n, (w₁ (p.1 i) * wq (p.2 i)))
        = ∑ g : Fin n → Bool × Bool,
            (if restrict b (fun i => (g i).1 && (g i).2) = τ.bits then (1:ENNReal) else 0) *
              ∏ i : Fin n, (w₁ (g i).1 * wq (g i).2)
        from (Equiv.sum_comp e (fun g =>
          (if restrict b (fun i => (g i).1 && (g i).2) = τ.bits then (1:ENNReal) else 0) *
            ∏ i : Fin n, (w₁ (g i).1 * wq (g i).2)))]
  -- Apply per_coord pointwise inside the product on the LHS.
  have lhs_expand :
      (∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1:ENNReal) else 0) *
            ∏ i : Fin n, w₂ (m i))
        = (∑ m : Fin n → Bool,
            (if restrict b m = τ.bits then (1:ENNReal) else 0) *
              ∏ i : Fin n, ∑ s : Bool × Bool,
                (if (s.1 && s.2) = m i then (1:ENNReal) else 0) * (w₁ s.1 * wq s.2)) := by
    apply Finset.sum_congr rfl
    intro m _
    congr 1
    apply Finset.prod_congr rfl
    intro i _
    rw [per_coord (m i)]
  rw [lhs_expand]
  -- Convert ∏ i, ∑ s, F i s into ∑ g, ∏ i, F i (g i) via Fintype.prod_sum.
  have prod_sum_step :
      (∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1:ENNReal) else 0) *
            ∏ i : Fin n, ∑ s : Bool × Bool,
              (if (s.1 && s.2) = m i then (1:ENNReal) else 0) * (w₁ s.1 * wq s.2))
        = (∑ m : Fin n → Bool,
            (if restrict b m = τ.bits then (1:ENNReal) else 0) *
              ∑ g : Fin n → Bool × Bool, ∏ i : Fin n,
                (if ((g i).1 && (g i).2) = m i then (1:ENNReal) else 0) *
                  (w₁ (g i).1 * wq (g i).2)) := by
    apply Finset.sum_congr rfl
    intro m _
    congr 1
    exact Fintype.prod_sum (fun (i : Fin n) (s : Bool × Bool) =>
      (if (s.1 && s.2) = m i then (1:ENNReal) else 0) * (w₁ s.1 * wq s.2))
  rw [prod_sum_step]
  -- Pull (if restrict b m = τ.bits then 1 else 0) inside the g-sum, then swap sums.
  have pull_in :
      (∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1:ENNReal) else 0) *
            ∑ g : Fin n → Bool × Bool, ∏ i : Fin n,
              (if ((g i).1 && (g i).2) = m i then (1:ENNReal) else 0) *
                (w₁ (g i).1 * wq (g i).2))
        = (∑ m : Fin n → Bool, ∑ g : Fin n → Bool × Bool,
            (if restrict b m = τ.bits then (1:ENNReal) else 0) *
              ∏ i : Fin n,
                (if ((g i).1 && (g i).2) = m i then (1:ENNReal) else 0) *
                  (w₁ (g i).1 * wq (g i).2)) := by
    apply Finset.sum_congr rfl
    intro m _
    rw [Finset.mul_sum]
  rw [pull_in]
  -- Swap the sums: ∑ m, ∑ g, ... = ∑ g, ∑ m, ...
  rw [Finset.sum_comm]
  -- Now combine the inner ∑ m, [restrict b m = τ.bits] * ∏ i, [g_i match m_i] * w
  -- into a single product (since the indicators in the product determine m uniquely
  -- when nonzero — namely m i = (g i).1 && (g i).2).
  apply Finset.sum_congr rfl
  intro g _
  -- Goal:
  --   ∑ m, (if restrict b m = τ.bits then 1 else 0) *
  --       ∏ i, (if ((g i).1 && (g i).2) = m i then 1 else 0) * (w₁ (g i).1 * wq (g i).2)
  --   = (if restrict b (fun i => (g i).1 && (g i).2) = τ.bits then 1 else 0) *
  --       ∏ i, (w₁ (g i).1 * wq (g i).2)
  -- The sum has a unique nonzero summand at m = (fun i => (g i).1 && (g i).2).
  rw [Finset.sum_eq_single (fun i => (g i).1 && (g i).2)]
  · -- The summand at m = AND-of-g equals the RHS.
    have prod_split :
        (∏ i : Fin n,
            (if ((g i).1 && (g i).2) = ((g i).1 && (g i).2) then (1:ENNReal) else 0) *
              (w₁ (g i).1 * wq (g i).2))
          = ∏ i : Fin n, (w₁ (g i).1 * wq (g i).2) := by
      apply Finset.prod_congr rfl
      intro i _
      simp
    rw [prod_split]
  · -- For m ≠ AND-of-g, some coordinate differs and the product has a 0 factor.
    intros m _ hm
    -- Find a coordinate where m i ≠ (g i).1 && (g i).2.
    have hex : ∃ i, ((g i).1 && (g i).2) ≠ m i := by
      by_contra hne
      push_neg at hne
      apply hm
      funext i
      exact (hne i).symm
    obtain ⟨i, hi⟩ := hex
    have hzero : (∏ j : Fin n,
        (if ((g j).1 && (g j).2) = m j then (1:ENNReal) else 0) *
          (w₁ (g j).1 * wq (g j).2)) = 0 := by
      apply Finset.prod_eq_zero (Finset.mem_univ i)
      simp [hi]
    rw [hzero, mul_zero]
  · -- Empty case (impossible since the index set is Finset.univ).
    intro h
    exact absurd (Finset.mem_univ _) h
