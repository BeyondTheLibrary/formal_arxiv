import Mathlib

/-- For every real `δ` and every real `ξ`, `0 ≤ 1 - 2 * δ * cos ξ + δ^2`. -/
theorem SqrtArgNonneg :
    ∀ (δ ξ : ℝ), 0 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 := by
  intro δ ξ
  have h1 : Real.cos ξ ≤ 1 := Real.cos_le_one ξ
  have h2 : -1 ≤ Real.cos ξ := Real.neg_one_le_cos ξ
  -- (δ - cos ξ)^2 + (1 - cos²ξ) ≥ 0, but simpler: (δ - 1)^2 ≤ ... requires sin²+cos²=1
  -- Actually 1 - 2δ cos ξ + δ² ≥ 1 - 2δ + δ² = (1-δ)² when cos ξ ≤ 1 and δ ≥ 0,
  -- but δ may be negative. Use (δ - cos ξ)^2 = δ² - 2δ cos ξ + cos²ξ, so
  -- 1 - 2δ cos ξ + δ² = (δ - cos ξ)^2 + (1 - cos²ξ) = (δ - cos ξ)^2 + sin²ξ ≥ 0
  have hsin : Real.sin ξ ^ 2 + Real.cos ξ ^ 2 = 1 := Real.sin_sq_add_cos_sq ξ
  nlinarith [sq_nonneg (δ - Real.cos ξ), sq_nonneg (Real.sin ξ), hsin]
