import Mathlib

open scoped BigOperators

set_option maxHeartbeats 4000000

/-!
# Abstract multiplicity-expansion engine (Lemma 7, Step 1 — combinatorial core)

This file isolates the purely-combinatorial / `tsum`-algebraic skeleton shared by
the *circular* and *linear* multiplicity expansions, abstracting away the concrete
convolution.  The data are:

* a coefficient `α : ℝ` (the per-factor weight `αC n`);
* a base power family `P : ℕ → ℝ` giving the value `pow base m ξ` at a FIXED point
  `ξ` (so `P m = (pow base m) ξ`).  In the applications `P m = circPowR (Bbase n) m ξ`
  or `P m = linPow (Bbase0 n) m ξ`.

The series envelope value is `S := ∑' b, α^(b+1) · P (b+1)` (= `Genv n ξ` resp.
`Glin n ξ`), and the `k`-fold convolution power value is some `T k`.  The two facts
the analytic layer must supply are:

* `base k = 1` :  `T 1 = S`  (after reindexing);
* the convolution step, expressed numerically once `pow_add` has collapsed the inner
  convolution: `T (k+1) = ∑' B, ∑' a, (coef k B) * (α^(a+1) * P (B + (a+1)))` for the
  IH coefficients `coef k`.

This file proves the resulting coefficient is the binomial multiplicity
`Nat.choose (B-1) (k-1)` and packages the hockey-stick collapse.  The heavy
analytic interchanges live in the concrete files.
-/

namespace MultiplicityExpansionCore

/-- The multiplicity coefficient: `mult k B = C(B-1, k-1)` for `B ≥ k ≥ 1`, written
in the shift-free index `B = k + m` (number of *extra* factors `m ≥ 0`) as
`C(k + m - 1, k - 1)`.  Indexed by `m` it is `multM k m`. -/
def multM (k m : ℕ) : ℕ := Nat.choose (k + m - 1) (k - 1)

/-- `multM 1 m = 1` (single factor: exactly one composition). -/
theorem multM_one (m : ℕ) : multM 1 m = 1 := by
  unfold multM
  simp

/-- Hockey-stick collapse in the `m`-index.  For `k ≥ 1`,
`∑_{i=0}^{m} multM k i = multM (k+1) m`, i.e.
`∑_{i=0}^{m} C(k+i-1, k-1) = C(k+m, k)`. -/
theorem multM_succ_sum (k : ℕ) (hk : 1 ≤ k) (m : ℕ) :
    (∑ i ∈ Finset.range (m + 1), multM k i) = multM (k + 1) m := by
  unfold multM
  -- C(k-1) of (k-1) ... rewrite k-1 = K so k = K+1
  obtain ⟨K, rfl⟩ := Nat.exists_eq_add_of_le hk  -- k = 1 + K
  -- Now k = 1 + K, k - 1 = K, (k+1)-1 = K+1.
  have hk1 : 1 + K - 1 = K := by omega
  have hk2 : 1 + K + 1 - 1 = K + 1 := by omega
  simp only [hk1, hk2]
  -- ∑_{i=0}^m C(1+K+i-1, K) = ∑_{i=0}^m C(K+i, K) = C(1+K+m, K+1)
  have hidx : ∀ i ∈ Finset.range (m + 1), (1 + K + i - 1).choose K = (i + K).choose K := by
    intro i _; congr 1; omega
  rw [Finset.sum_congr rfl hidx]
  -- Nat.sum_range_add_choose : ∑ i ∈ range (n+1), (i+k).choose k = (n+k+1).choose (k+1)
  rw [Nat.sum_range_add_choose m K]
  congr 1
  omega

/-- **Numerical regrouping of a nonnegative double `tsum` by the sum index.**
For a nonnegative summable family `F : ℕ → ℕ → ℝ`,
`∑'_B ∑'_a F B a = ∑'_C ∑_{p ∈ antidiagonal C} F p.1 p.2`. -/
theorem tsum_tsum_regroup (F : ℕ → ℕ → ℝ)
    (hsumm : Summable (fun p : ℕ × ℕ => F p.1 p.2)) :
    (∑' B : ℕ, ∑' a : ℕ, F B a)
      = ∑' C : ℕ, ∑ p ∈ Finset.antidiagonal C, F p.1 p.2 := by
  rw [← hsumm.tsum_prod]
  -- pull back along the sigma ≃ product equiv
  rw [← (Finset.sigmaAntidiagonalEquivProd (A := ℕ)).tsum_eq (fun p : ℕ × ℕ => F p.1 p.2)]
  -- the summand factors through the equiv; rewrite it as a sigma-indexed family
  have hsumm_sigma : Summable
      (fun x : (C : ℕ) × ↥(Finset.antidiagonal C) =>
        F (Finset.sigmaAntidiagonalEquivProd x).1 (Finset.sigmaAntidiagonalEquivProd x).2) :=
    hsumm.comp_injective (Finset.sigmaAntidiagonalEquivProd (A := ℕ)).injective
  rw [hsumm_sigma.tsum_sigma]
  -- inner: ∑' (b : antidiagonal C), F (↑b).1 (↑b).2 = ∑ p ∈ antidiagonal C, F p.1 p.2
  apply tsum_congr
  intro C
  rw [tsum_eq_sum (s := Finset.univ) (by intro b hb; exact absurd (Finset.mem_univ b) hb)]
  rw [← Finset.sum_attach (Finset.antidiagonal C) (fun p => F p.1 p.2)]
  apply Finset.sum_congr rfl
  intro b _
  rw [Finset.sigmaAntidiagonalEquivProd_apply]

/-- **The scalar/combinatorial collapse of the induction step.**

Given the IH coefficient `multM k B · α^(k+B)` on the `(k+B)`-fold base power and the
Series term `α^(a+1) · Pb (·+(a+1))`, after `pow_add` has collapsed the inner
convolution to a single base power `Pb ((k+B)+(a+1))`, the double `tsum` over `(B,a)`
regroups (by the total extra-factor index `m = B + a`) into the single `tsum` with
coefficient `multM (k+1) m · α^((k+1)+m)`, by the hockey-stick `multM_succ_sum`.

`Pb m` plays the role of `pow base m ξ` at a fixed `ξ`; the hypothesis `hsumm` is the
joint summability of the (nonnegative) double family. -/
theorem step_collapse (α : ℝ) (_hα : 0 ≤ α) (Pb : ℕ → ℝ) (_hPb : ∀ m, 0 ≤ Pb m)
    (k : ℕ) (hk : 1 ≤ k)
    (hsumm : Summable (fun p : ℕ × ℕ =>
      ((multM k p.1 : ℝ) * α ^ (k + p.1)) * (α ^ (p.2 + 1) * Pb ((k + p.1) + (p.2 + 1))))) :
    (∑' B : ℕ, ∑' a : ℕ,
        ((multM k B : ℝ) * α ^ (k + B)) * (α ^ (a + 1) * Pb ((k + B) + (a + 1))))
      = ∑' m : ℕ, ((multM (k + 1) m : ℝ) * α ^ ((k + 1) + m)) * Pb ((k + 1) + m) := by
  set F : ℕ → ℕ → ℝ := fun B a =>
    ((multM k B : ℝ) * α ^ (k + B)) * (α ^ (a + 1) * Pb ((k + B) + (a + 1))) with hF
  -- regroup the double sum by C = B + a
  rw [tsum_tsum_regroup F hsumm]
  -- per-C inner finite sum equals the target term at m = C
  apply tsum_congr
  intro C
  -- The inner antidiagonal sum: each (B,a) with B+a=C contributes
  --   multM k B · α^(k+B) · α^(a+1) · Pb ((k+B)+(a+1))
  -- and (k+B)+(a+1) = (k+1)+(B+a) = (k+1)+C, α^(k+B)·α^(a+1)=α^((k+1)+C).
  have hterm : ∀ p ∈ Finset.antidiagonal C,
      F p.1 p.2 = (multM k p.1 : ℝ) * (α ^ ((k + 1) + C) * Pb ((k + 1) + C)) := by
    intro p hp
    rw [Finset.mem_antidiagonal] at hp
    simp only [hF]
    have hidx : (k + p.1) + (p.2 + 1) = (k + 1) + C := by omega
    have hpow : α ^ (k + p.1) * α ^ (p.2 + 1) = α ^ ((k + 1) + C) := by
      rw [← pow_add, hidx]
    rw [hidx]
    -- goal: multM·α^(k+p.1)·(α^(p.2+1)·Pb(..)) = multM·(α^((k+1)+C)·Pb(..))
    rw [show (multM k p.1 : ℝ) * α ^ (k + p.1) * (α ^ (p.2 + 1) * Pb ((k + 1) + C))
        = (multM k p.1 : ℝ) * (α ^ (k + p.1) * α ^ (p.2 + 1)) * Pb ((k + 1) + C) by ring,
      hpow]
    ring
  rw [Finset.sum_congr rfl hterm]
  -- pull the common factor α^((k+1)+C)·Pb((k+1)+C) out of the finite sum
  rw [← Finset.sum_mul]
  -- ∑_{p ∈ antidiagonal C} (multM k p.1 : ℝ) = (∑_{i=0}^{C} multM k i : ℝ) = multM (k+1) C
  have hcoef : (∑ p ∈ Finset.antidiagonal C, (multM k p.1 : ℝ))
      = (multM (k + 1) C : ℝ) := by
    rw [Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk (fun p => (multM k p.1 : ℝ)) C]
    simp only
    rw [← Nat.cast_sum]
    rw [show (∑ i ∈ Finset.range (C + 1), multM k i) = multM (k + 1) C from multM_succ_sum k hk C]
  rw [hcoef]
  ring

end MultiplicityExpansionCore
