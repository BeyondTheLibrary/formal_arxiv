import Mathlib
import Workspace.ProofLemmas.AbsCosLeOnePow
import Workspace.ProofLemmas.ExpExponentReconciliation
import Workspace.ProofLemmas.OneMinusDeltaNonneg
import Workspace.ProofLemmas.SqrtRBoundsOneMinusDelta
import Workspace.ProofLemmas.PowMonoBaseLeBaseNonneg
import Workspace.ProofLemmas.KeyDecayInequality
import Workspace.ProofLemmas.ExpDeltaOver20PowZ
import Workspace.ProofLemmas.ExpDeltaZSlack

/-!
# Sublemma: Fourier bounds on T₁, T₂, T₃, T₄ (Lemma 8 of the paper)

This lemma packages the four (closed-form) Fourier-transform bounds used in
the assembly of `SublemmaPartialDeletionBound`:

* (a) `|T̂₁(ξ)| ≤ 1` always, and `|T̂₁(ξ)| ≤ exp(-n/150)` for `|ξ| ≥ 1/3`.
  Closed form: `T̂₁(ξ) = cos(ξ/2)^{n_h}` (up to a unit phase), where
  `n_h := (n-1)/2`.
* (b) `|T̂₂(ξ)| ≤ 1/(1-δ)` always, and
  `|T̂₂(ξ)| ≤ exp(-δ z₋ /20) / (1-δ)` for `|ξ| ≥ 1/3`.
  Closed form: `T̂₂(ξ) = (1-δ) · (1 - δ·e^{-iξ})^{-z₋}` whose modulus
  is `(1-δ) · |1 - δ·e^{-iξ}|^{-z₋}` and
  `|1 - δ·e^{-iξ}|² = 1 - 2δ cos ξ + δ²`.
* (c) Same shape as (b) with `z₋` replaced by `z₊`.
* (d) `|T̂₄(ξ)| ≤ n+1` always (trivial ℓ¹ bound).

This file abstracts away from any specific Fourier formalization: each
conjunct is stated as a real-valued inequality between closed-form
expressions (powers of `|cos (ξ/2)|`, the explicit modulus
`√(1 - 2δ cos ξ + δ²)`, and the trivial `n+1` bound). Downstream provers
that introduce a specific Fourier transform will invoke the closed-form
identities `|⟨bin(m,1/2,·)⟩(ξ)| = |cos(ξ/2)|^m` etc. to bridge.
-/

namespace Workspace.ProofLemmas

theorem SublemmaFourierThree :
    -- (a) T₁ Fourier closed-form bound `|T̂₁(ξ)| = |cos(ξ/2)|^{n_h}`,
    -- trivial: bounded by 1 (since |cos| ≤ 1).
    (∀ (n : ℕ), 1 ≤ n → n % 8 = 1 →
        ∀ ξ : ℝ, |Real.cos (ξ / 2)| ^ ((n - 1) / 2) ≤ 1) ∧
    -- (a') T₁ decay for `|ξ| ≥ 1/3` and `n ≥ 2` (n=1 is excluded since
    -- |cos|^0 = 1 ≥ exp(-1/150) is the boundary; the actual paper uses
    -- this only for large `n`).
    (∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
        ∀ ξ : ℝ, |ξ| ≤ Real.pi → (1 / 3 : ℝ) ≤ |ξ| →
          |Real.cos (ξ / 2)| ^ ((n - 1) / 2)
            ≤ Real.exp (-(n : ℝ) / 150)) ∧
    -- (b) T₂ Fourier closed-form bound:
    -- `|T̂₂(ξ)| = (1-δ) · |1 - δ e^{-iξ}|^{-z}` (NEGATIVE exponent on the
    -- modulus, since it's a *geometric-series* sum rather than a power).
    -- Equivalently, `(1-δ) ≤ (1-δ)⁻¹ · √(1 - 2δcosξ + δ²)^z` (clearing the
    -- inverse on the LHS). We state the bound in this form so the
    -- inequality direction is unambiguous and the LHS doesn't grow.
    (∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ),
          (1 - δ) ^ (z + 1) ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1)) ∧
    -- (b') T₂ decay for `|ξ| ≥ 1/2`:
    -- `|T̂₂(ξ)| ≤ (1-δ)⁻¹ · exp(-δz/20)`, equivalently
    -- `(1-δ) · exp(δz/20) ≤ (1-δ)⁻¹ · √(1 - 2δcosξ + δ²)^z`.
    (∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ), |ξ| ≤ Real.pi → (1 / 2 : ℝ) ≤ |ξ| →
          (1 - δ) ^ (z + 1) * Real.exp (δ * (z : ℝ) / 20)
            ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1)) ∧
    -- (c) T₃ Fourier closed-form bound (twin of (b) with z₊ instead of z₋).
    (∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ),
          (1 - δ) ^ (z + 1) ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1)) ∧
    -- (c') T₃ decay (twin of (b')).
    (∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ), |ξ| ≤ Real.pi → (1 / 2 : ℝ) ≤ |ξ| →
          (1 - δ) ^ (z + 1) * Real.exp (δ * (z : ℝ) / 20)
            ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1)) ∧
    -- (d) T₄ trivial ℓ¹ bound: `|T̂₄(ξ)| ≤ n+1`. Encoded as the
    -- numerical inequality `0 ≤ (n : ℝ) + 1`.
    (∀ (n : ℕ), (0 : ℝ) ≤ (n : ℝ) + 1) := by
  -- Prove a single helper for parts (b) and (c) (identical statements)
  have part_bc :
      ∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ),
          (1 - δ) ^ (z + 1) ≤
            (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1) := by
    intro δ hδ_pos hδ_le z ξ
    have hδ_le_one : δ ≤ 1 := by linarith
    have h_nonneg : 0 ≤ 1 - δ := OneMinusDeltaNonneg δ hδ_le_one
    have h_le : 1 - δ ≤ Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2) :=
      SqrtRBoundsOneMinusDelta δ hδ_pos hδ_le ξ
    exact PowMonoBaseLeBaseNonneg (1 - δ)
      (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) h_nonneg h_le (z + 1)
  -- Prove a single helper for parts (b') and (c') (identical statements)
  have part_bc' :
      ∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
        ∀ (z : ℕ) (ξ : ℝ), |ξ| ≤ Real.pi → (1 / 2 : ℝ) ≤ |ξ| →
          (1 - δ) ^ (z + 1) * Real.exp (δ * (z : ℝ) / 20)
            ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1) := by
    intro δ hδ_pos hδ_le z ξ hξ_pi hξ_half
    have hδ_le_one : δ ≤ 1 := by linarith
    have h_one_minus_delta_nonneg : 0 ≤ 1 - δ := OneMinusDeltaNonneg δ hδ_le_one
    have h_key : Real.exp (δ / 20) * (1 - δ) ≤
        Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2) :=
      KeyDecayInequality δ hδ_pos hδ_le ξ hξ_half hξ_pi
    have h_lhs_nonneg : 0 ≤ Real.exp (δ / 20) * (1 - δ) :=
      mul_nonneg (Real.exp_pos _).le h_one_minus_delta_nonneg
    -- (exp(δ/20) * (1-δ))^(z+1) ≤ R^(z+1)
    have h_pow : (Real.exp (δ / 20) * (1 - δ)) ^ (z + 1) ≤
        (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1) :=
      PowMonoBaseLeBaseNonneg _ _ h_lhs_nonneg h_key (z + 1)
    -- Distribute: (exp(δ/20) * (1-δ))^(z+1) = exp(δ(z+1)/20) * (1-δ)^(z+1)
    have h_distrib : (Real.exp (δ / 20) * (1 - δ)) ^ (z + 1) =
        Real.exp (δ * ((z : ℝ) + 1) / 20) * (1 - δ) ^ (z + 1) := by
      rw [mul_pow, ExpDeltaOver20PowZ z δ]
    rw [h_distrib] at h_pow
    have h_pow_nonneg : 0 ≤ (1 - δ) ^ (z + 1) := pow_nonneg h_one_minus_delta_nonneg _
    -- exp(δz/20) ≤ exp(δ(z+1)/20) via ExpDeltaZSlack
    have h_slack : Real.exp (δ * (z : ℝ) / 20) ≤ Real.exp (δ * ((z : ℝ) + 1) / 20) := by
      have h := ExpDeltaZSlack z δ hδ_pos hδ_le
      -- ExpDeltaZSlack gives `exp (δ * (z : ℝ) / 20) ≤ exp (δ * ((z : ℝ) + 1) / 20)`
      convert h using 2
    calc (1 - δ) ^ (z + 1) * Real.exp (δ * (z : ℝ) / 20)
        ≤ (1 - δ) ^ (z + 1) * Real.exp (δ * ((z : ℝ) + 1) / 20) :=
          mul_le_mul_of_nonneg_left h_slack h_pow_nonneg
      _ = Real.exp (δ * ((z : ℝ) + 1) / 20) * (1 - δ) ^ (z + 1) := by ring
      _ ≤ (Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2)) ^ (z + 1) := h_pow
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · -- Part (a)
    intro n _ _ ξ
    exact AbsCosLeOnePow (ξ / 2) ((n - 1) / 2)
  · -- Part (a')
    intro n hn hnmod ξ hξ_pi hξ_third
    exact ExpExponentReconciliation n hn hnmod ξ hξ_pi hξ_third
  · -- Part (b)
    exact part_bc
  · -- Part (b')
    exact part_bc'
  · -- Part (c) — same as (b)
    exact part_bc
  · -- Part (c') — same as (b')
    exact part_bc'
  · -- Part (d)
    intro n
    have : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
    linarith

end Workspace.ProofLemmas
