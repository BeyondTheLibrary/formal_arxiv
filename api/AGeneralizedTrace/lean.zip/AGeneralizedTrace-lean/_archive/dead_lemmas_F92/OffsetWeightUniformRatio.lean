import Mathlib
import Workspace.Types.StirlingAxioms
import Workspace.Types.PartialDeletionProcess
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.OffsetWeightFterm

/-!
# Uniform-in-`r` ratio bound `offsetWeight n r ≤ C · binPMFInt n (1/2) (r + n/2)`

This file proves, uniformly over the offset window `r ∈ [-n/4, n/4]` (with `4 ∣ n`,
`n ≥ 4`), the ratio bound

  `offsetWeight n r ≤ (4 / √π) · binPMFInt n (1/2) (r + n/2)`.

The numerator `offsetWeight n r = bin(n/2, 1/2, r + n/4)` and the denominator
`binPMFInt n (1/2) (r + n/2) = bin(n, 1/2, r + n/2)` both have *the same* deviation
`r` from their respective modes (`n/4` and `n/2`). A flat-upper / Gaussian-lower
envelope split has a residual exponent that GROWS in `r`, so it fails at the edges.

Instead we prove the bound by **ratio monotonicity**. Writing `q := n/4`, the ratio
`R(r) := offsetWeight(r) / bin(n,1/2,r+n/2)` is (after cancelling the `r`-independent
`2`-powers) proportional to `g(k) := C(2q, k) / C(4q, q + k)` with `k = q + r`. Its
one-step ratio

  `g(k+1)/g(k) = ((2q-k)/(k+1)) · ((q+k+1)/(3q-k))`

is `≤ 1` exactly for `k ≥ q` and `≥ 1` exactly for `k ≤ q`, so `g` is maximised at
`k = q`, i.e. `R` is maximised at `r = 0`. The central value is bounded by the proven
`OffsetWeightFterm.offsetWeight_le_central_factor`, giving the uniform constant
`C = 4/√π ≈ 2.2568 < 4` (absorbable into `paper_lemma_6`'s factor-4 slack).

All results are sorry-free.
-/

namespace Workspace.ProofLemmas.OffsetWeightUniformRatio

open Workspace.Types.StirlingAxioms
open Workspace.Types.PartialDeletionProcess
open Workspace.Types.AlternatingSumExpression

set_option maxHeartbeats 1600000

/-- Positivity of a binomial coefficient cast to `ℝ`, for `k ≤ n`. -/
private lemma choose_pos_real (n k : ℕ) (h : k ≤ n) : (0 : ℝ) < (Nat.choose n k : ℝ) := by
  have : 0 < Nat.choose n k := Nat.choose_pos h
  exact_mod_cast this

/-- **One-step monotonicity of `g(k) = C(2q,k)/C(4q,q+k)` on the right side.**
For `q ≤ k` and `k < 2q`:
`C(2q,k+1)·C(4q,q+k) ≤ C(2q,k)·C(4q,q+k+1)`. -/
private lemma cross_step_right (q k : ℕ) (hq : 1 ≤ q) (hk : q ≤ k) (hk2 : k < 2 * q) :
    (Nat.choose (2 * q) (k + 1) : ℝ) * (Nat.choose (4 * q) (q + k) : ℝ)
      ≤ (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q) (q + k + 1) : ℝ) := by
  have hk2q : k < 2 * q := hk2
  have hqk4 : q + k < 4 * q := by omega
  -- ratio recurrences
  have hnum := binom_ratio_succ (2 * q) k hk2q
  -- C(2q,k+1) = C(2q,k) * (2q-k)/(k+1)
  have hden := binom_ratio_succ (4 * q) (q + k) hqk4
  -- C(4q,q+k+1) = C(4q,q+k) * (4q-(q+k))/(q+k+1)
  rw [hnum, hden]
  have hCk : (0 : ℝ) < (Nat.choose (2 * q) k : ℝ) := choose_pos_real _ _ (by omega)
  have hDk : (0 : ℝ) < (Nat.choose (4 * q) (q + k) : ℝ) := choose_pos_real _ _ (by omega)
  have hsub2 : ((2 * q - k : ℕ) : ℝ) = (2 * q : ℝ) - (k : ℝ) := by
    have : k ≤ 2 * q := by omega
    push_cast [Nat.cast_sub this]; ring
  have hsub4 : ((4 * q - (q + k) : ℕ) : ℝ) = (3 * q : ℝ) - (k : ℝ) := by
    have : q + k ≤ 4 * q := by omega
    push_cast [Nat.cast_sub this]; ring
  rw [hsub2, hsub4]
  have hk1 : (0 : ℝ) < (k : ℝ) + 1 := by positivity
  have hqk1 : (0 : ℝ) < (q : ℝ) + (k : ℝ) + 1 := by positivity
  push_cast
  have hqR : (1 : ℝ) ≤ (q : ℝ) := by exact_mod_cast hq
  have hkR : (q : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have hAD : (0 : ℝ) ≤ (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q) (q + k) : ℝ) :=
    mul_nonneg hCk.le hDk.le
  -- polynomial cross inequality (2q-k)(q+k+1) ≤ (3q-k)(k+1)
  have hpoly : ((2 * q : ℝ) - (k : ℝ)) * ((q : ℝ) + (k : ℝ) + 1)
      ≤ ((3 * q : ℝ) - (k : ℝ)) * ((k : ℝ) + 1) := by nlinarith [hqR, hkR]
  rw [div_mul_eq_mul_div, mul_div_assoc' (Nat.choose (2 * q) k : ℝ),
      div_le_div_iff₀ hk1 hqk1]
  nlinarith [mul_le_mul_of_nonneg_left hpoly hAD, hCk, hDk, hk1, hqk1]

/-- **One-step monotonicity of `g(k) = C(2q,k)/C(4q,q+k)` on the left side.**
For `k < q`:
`C(2q,k)·C(4q,q+k+1) ≤ C(2q,k+1)·C(4q,q+k)`. -/
private lemma cross_step_left (q k : ℕ) (hq : 1 ≤ q) (hk : k < q) :
    (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q) (q + k + 1) : ℝ)
      ≤ (Nat.choose (2 * q) (k + 1) : ℝ) * (Nat.choose (4 * q) (q + k) : ℝ) := by
  have hk2q : k < 2 * q := by omega
  have hqk4 : q + k < 4 * q := by omega
  have hnum := binom_ratio_succ (2 * q) k hk2q
  have hden := binom_ratio_succ (4 * q) (q + k) hqk4
  rw [hnum, hden]
  have hCk : (0 : ℝ) < (Nat.choose (2 * q) k : ℝ) := choose_pos_real _ _ (by omega)
  have hDk : (0 : ℝ) < (Nat.choose (4 * q) (q + k) : ℝ) := choose_pos_real _ _ (by omega)
  have hsub2 : ((2 * q - k : ℕ) : ℝ) = (2 * q : ℝ) - (k : ℝ) := by
    have : k ≤ 2 * q := by omega
    push_cast [Nat.cast_sub this]; ring
  have hsub4 : ((4 * q - (q + k) : ℕ) : ℝ) = (3 * q : ℝ) - (k : ℝ) := by
    have : q + k ≤ 4 * q := by omega
    push_cast [Nat.cast_sub this]; ring
  rw [hsub2, hsub4]
  have hk1 : (0 : ℝ) < (k : ℝ) + 1 := by positivity
  have hqk1 : (0 : ℝ) < (q : ℝ) + (k : ℝ) + 1 := by positivity
  push_cast
  have hqR : (1 : ℝ) ≤ (q : ℝ) := by exact_mod_cast hq
  have hkR : (k : ℝ) + 1 ≤ (q : ℝ) := by
    have : k + 1 ≤ q := hk
    exact_mod_cast this
  have hAD : (0 : ℝ) ≤ (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q) (q + k) : ℝ) :=
    mul_nonneg hCk.le hDk.le
  -- polynomial cross inequality (reverse): (3q-k)(k+1) ≤ (2q-k)(q+k+1)
  have hpoly : ((3 * q : ℝ) - (k : ℝ)) * ((k : ℝ) + 1)
      ≤ ((2 * q : ℝ) - (k : ℝ)) * ((q : ℝ) + (k : ℝ) + 1) := by nlinarith [hqR, hkR]
  rw [div_mul_eq_mul_div, mul_div_assoc' (Nat.choose (2 * q) k : ℝ),
      div_le_div_iff₀ hqk1 hk1]
  nlinarith [mul_le_mul_of_nonneg_left hpoly hAD, hCk, hDk, hk1, hqk1]

/-- **Right-side global monotonicity.** For `q ≤ k ≤ 2q`:
`C(2q,k)·C(4q,2q) ≤ C(2q,q)·C(4q,q+k)`. -/
private lemma cross_mono_right (q : ℕ) (hq : 1 ≤ q) :
    ∀ k, q ≤ k → k ≤ 2 * q →
      (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
        ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + k) : ℝ) := by
  intro k hk hk2
  -- induct on d = k - q
  obtain ⟨d, rfl⟩ : ∃ d, k = q + d := ⟨k - q, by omega⟩
  clear hk
  induction d with
  | zero =>
    simp only [Nat.add_zero]
    rw [show q + q = 2 * q by ring]
  | succ d ih =>
    have hk2' : q + d ≤ 2 * q := by omega
    have hkd2 : q + d < 2 * q := by omega
    have hstep := cross_step_right q (q + d) hq (by omega) hkd2
    -- hstep : C(2q,q+d+1)·C(4q,q+(q+d)) ≤ C(2q,q+d)·C(4q,q+(q+d)+1)
    have ihd := ih hk2'
    -- ihd : C(2q,q+d)·C(4q,2q) ≤ C(2q,q)·C(4q,q+(q+d))
    have hDpos : (0 : ℝ) < (Nat.choose (4 * q) (q + (q + d)) : ℝ) :=
      choose_pos_real _ _ (by omega)
    have hD2pos : (0 : ℝ) < (Nat.choose (4 * q) (2 * q) : ℝ) :=
      choose_pos_real _ _ (by omega)
    have hCqpos : (0 : ℝ) < (Nat.choose (2 * q) q : ℝ) := choose_pos_real _ _ (by omega)
    have hDp1pos : (0 : ℝ) < (Nat.choose (4 * q) (q + (q + d) + 1) : ℝ) :=
      choose_pos_real _ _ (by omega)
    -- hA = hstep multiplied on the right by C(4q,2q)
    have hA : (Nat.choose (2 * q) (q + d + 1) : ℝ) * (Nat.choose (4 * q) (q + (q + d)) : ℝ)
        * (Nat.choose (4 * q) (2 * q) : ℝ)
        ≤ (Nat.choose (2 * q) (q + d) : ℝ) * (Nat.choose (4 * q) (q + (q + d) + 1) : ℝ)
        * (Nat.choose (4 * q) (2 * q) : ℝ) :=
      mul_le_mul_of_nonneg_right hstep hD2pos.le
    -- hB = ihd multiplied on the right by C(4q,q+(q+d)+1)
    have hB : (Nat.choose (2 * q) (q + d) : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
        * (Nat.choose (4 * q) (q + (q + d) + 1) : ℝ)
        ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + (q + d)) : ℝ)
        * (Nat.choose (4 * q) (q + (q + d) + 1) : ℝ) :=
      mul_le_mul_of_nonneg_right ihd hDp1pos.le
    -- combine: cancel via key * D
    have key : (Nat.choose (2 * q) (q + d + 1) : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
        * (Nat.choose (4 * q) (q + (q + d)) : ℝ)
        ≤ ((Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + (q + d) + 1) : ℝ))
        * (Nat.choose (4 * q) (q + (q + d)) : ℝ) := by
      nlinarith [hA, hB]
    have hgoal : (Nat.choose (2 * q) (q + d + 1) : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
        ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + (q + d) + 1) : ℝ) :=
      le_of_mul_le_mul_right key hDpos
    rw [show q + (q + d) + 1 = q + (q + d + 1) by omega] at hgoal
    exact hgoal

/-- **Left-side global monotonicity.** For `k ≤ q`:
`C(2q,k)·C(4q,2q) ≤ C(2q,q)·C(4q,q+k)`. -/
private lemma cross_mono_left (q : ℕ) (hq : 1 ≤ q) :
    ∀ k, k ≤ q →
      (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
        ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + k) : ℝ) := by
  -- prove the family ∀ j, (goal at k = q - j), by induction on j (downward in k)
  suffices h : ∀ j, (Nat.choose (2 * q) (q - j) : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
      ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + (q - j)) : ℝ) by
    intro k hk
    have := h (q - k)
    rw [show q - (q - k) = k by omega] at this
    exact this
  intro j
  induction j with
  | zero =>
    simp only [Nat.sub_zero]
    rw [show q + q = 2 * q by ring]
  | succ j ih =>
    by_cases hjq : j + 1 ≤ q
    · -- k0 := q - (j+1) < q ; step relates k0 and q - j = k0 + 1
      set k0 := q - (j + 1) with hk0
      have hk0q : k0 < q := by omega
      have hstep := cross_step_left q k0 hq hk0q
      -- cross_step_left: C(2q,k0)·C(4q,q+k0+1) ≤ C(2q,k0+1)·C(4q,q+k0)
      have hk01 : k0 + 1 = q - j := by omega
      have hqk01 : q + k0 + 1 = q + (q - j) := by omega
      rw [hk01] at hstep
      rw [hqk01] at hstep
      -- hstep : C(2q,k0)·C(4q,q+(q-j)) ≤ C(2q,q-j)·C(4q,q+k0)
      have hD2 : (0 : ℝ) < (Nat.choose (4 * q) (2 * q) : ℝ) := choose_pos_real _ _ (by omega)
      have hDqj : (0 : ℝ) < (Nat.choose (4 * q) (q + (q - j)) : ℝ) :=
        choose_pos_real _ _ (by omega)
      have hDk0 : (0 : ℝ) < (Nat.choose (4 * q) (q + k0) : ℝ) := choose_pos_real _ _ (by omega)
      -- hA = hstep * C(4q,2q)
      have hA : (Nat.choose (2 * q) k0 : ℝ) * (Nat.choose (4 * q) (q + (q - j)) : ℝ)
          * (Nat.choose (4 * q) (2 * q) : ℝ)
          ≤ (Nat.choose (2 * q) (q - j) : ℝ) * (Nat.choose (4 * q) (q + k0) : ℝ)
          * (Nat.choose (4 * q) (2 * q) : ℝ) :=
        mul_le_mul_of_nonneg_right hstep hD2.le
      -- hB = ih * C(4q,q+k0)
      have hB : (Nat.choose (2 * q) (q - j) : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
          * (Nat.choose (4 * q) (q + k0) : ℝ)
          ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + (q - j)) : ℝ)
          * (Nat.choose (4 * q) (q + k0) : ℝ) :=
        mul_le_mul_of_nonneg_right ih hDk0.le
      have key : (Nat.choose (2 * q) k0 : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
          * (Nat.choose (4 * q) (q + (q - j)) : ℝ)
          ≤ ((Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + k0) : ℝ))
          * (Nat.choose (4 * q) (q + (q - j)) : ℝ) := by
        nlinarith [hA, hB]
      have hgoal : (Nat.choose (2 * q) k0 : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
          ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + k0) : ℝ) :=
        le_of_mul_le_mul_right key hDqj
      -- goal is at q - (j+1) = k0
      exact hgoal
    · -- j + 1 > q, so q - (j+1) = q - j (both are 0); reduce to ih
      rw [show q - (j + 1) = q - j by omega]
      exact ih

/-- **Cross-multiplied global monotonicity.** For `0 ≤ k ≤ 2q` (with `q ≥ 1`):
`C(2q,k)·C(4q,2q) ≤ C(2q,q)·C(4q,q+k)`. The function `g(k) = C(2q,k)/C(4q,q+k)`
is maximised at `k = q`. -/
private lemma cross_mono (q k : ℕ) (hq : 1 ≤ q) (hk : k ≤ 2 * q) :
    (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q) (2 * q) : ℝ)
      ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q) (q + k) : ℝ) := by
  rcases Nat.lt_or_ge k q with h | h
  · exact cross_mono_left q hq k (le_of_lt h)
  · exact cross_mono_right q hq k h hk

/-- Integer-division facts used by the window lemmas: for `4 ∣ n`,
`(↑n)/4 = ↑(n/4)`, `(↑n)/2 = ↑(n/2)`, `n/2 = 2·(n/4)`, `n = 4·(n/4)`. -/
private lemma divfacts (n : ℕ) (h4 : 4 ∣ n) :
    ((n : ℤ) / 4 = ((n / 4 : ℕ) : ℤ)) ∧ ((n : ℤ) / 2 = ((n / 2 : ℕ) : ℤ))
      ∧ (n / 2 = 2 * (n / 4)) ∧ (n = 4 * (n / 4)) := by
  obtain ⟨t, rfl⟩ := h4
  refine ⟨?_, ?_, ?_, ?_⟩
  · push_cast; omega
  · push_cast; omega
  · omega
  · omega

/-- Real-valued form of `offsetWeight n r` on the support window `|r| ≤ n/4`
(with `4 ∣ n`): `offsetWeight n r = C(n/2, (r + n/4).toNat) · (1/2)^(n/2)`. -/
private lemma offsetWeight_toReal_window (n : ℕ) (r : ℤ) (h4 : 4 ∣ n)
    (hlo : -(n / 4 : ℤ) ≤ r) (hhi : r ≤ (n / 4 : ℤ)) :
    (offsetWeight n r).toReal
      = (Nat.choose (n / 2) ((r + ((n / 4 : ℕ) : ℤ)).toNat) : ℝ) * (1 / 2 : ℝ) ^ (n / 2) := by
  obtain ⟨hq4, hq2, h2q, _⟩ := divfacts n h4
  rw [hq4] at hlo hhi
  unfold offsetWeight
  have hkge : (0 : ℤ) ≤ r + ((n / 4 : ℕ) : ℤ) := by omega
  have hkle : r + ((n / 4 : ℕ) : ℤ) ≤ ((n / 2 : ℕ) : ℤ) := by
    rw [show ((n / 2 : ℕ) : ℤ) = 2 * ((n / 4 : ℕ) : ℤ) by exact_mod_cast h2q]; omega
  rw [dif_pos ⟨hkge, hkle⟩, ENNReal.toReal_mul, ENNReal.toReal_natCast]
  congr 1
  rw [ENNReal.toReal_pow, ENNReal.toReal_ofReal (by norm_num : (0:ℝ) ≤ 1 / 2)]

/-- Real-valued form of `binPMFInt n (1/2) (r + n/2)` on the support window
`|r| ≤ n/4` (with `4 ∣ n`):
`= C(n, (r + n/2).toNat) · (1/2)^n`. -/
private lemma binPMFInt_window (n : ℕ) (r : ℤ) (h4 : 4 ∣ n)
    (hlo : -(n / 4 : ℤ) ≤ r) (hhi : r ≤ (n / 4 : ℤ)) :
    binPMFInt n (1 / 2) (r + (n / 2 : ℤ))
      = (Nat.choose n ((r + (n / 2 : ℤ)).toNat) : ℝ) * (1 / 2 : ℝ) ^ n := by
  obtain ⟨hq4, hq2, h2q, h4q⟩ := divfacts n h4
  rw [hq4] at hlo hhi
  unfold binPMFInt
  have hq2' : (n : ℤ) / 2 = 2 * ((n / 4 : ℕ) : ℤ) := by
    rw [hq2]; exact_mod_cast h2q
  have hkge : (0 : ℤ) ≤ r + (n : ℤ) / 2 := by rw [hq2']; omega
  have hkle : r + (n : ℤ) / 2 ≤ (n : ℤ) := by
    rw [hq2', show (n : ℤ) = 4 * ((n / 4 : ℕ) : ℤ) by exact_mod_cast h4q]; omega
  rw [if_pos ⟨hkge, hkle⟩]
  unfold binPMF
  have htoNat_le : (r + (n : ℤ) / 2).toNat ≤ n := by
    have : (r + (n : ℤ) / 2).toNat ≤ ((n : ℤ)).toNat := by
      apply Int.toNat_le_toNat; omega
    simpa using this
  rw [if_pos htoNat_le]
  have h2 : (1 : ℝ) - 1 / 2 = 1 / 2 := by norm_num
  rw [h2, mul_assoc, ← pow_add]
  congr 2
  omega

/-- Positivity of `binPMFInt n (1/2) (r + n/2)` on the support window. -/
private lemma binPMFInt_window_pos (n : ℕ) (r : ℤ) (h4 : 4 ∣ n)
    (hlo : -(n / 4 : ℤ) ≤ r) (hhi : r ≤ (n / 4 : ℤ)) :
    0 < binPMFInt n (1 / 2) (r + (n / 2 : ℤ)) := by
  rw [binPMFInt_window n r h4 hlo hhi]
  obtain ⟨hq4, hq2, h2q, h4q⟩ := divfacts n h4
  have hidx : (r + (n : ℤ) / 2).toNat ≤ n := by
    have hq2' : (n : ℤ) / 2 = 2 * ((n / 4 : ℕ) : ℤ) := by rw [hq2]; exact_mod_cast h2q
    rw [hq4] at hlo hhi
    have : (r + (n : ℤ) / 2).toNat ≤ ((n : ℤ)).toNat := by
      apply Int.toNat_le_toNat
      rw [hq2', show (n : ℤ) = 4 * ((n / 4 : ℕ) : ℤ) by exact_mod_cast h4q]; omega
    simpa using this
  have := choose_pos_real n ((r + (n : ℤ) / 2).toNat) hidx
  positivity

/-- **Uniform-in-`r` ratio bound (main result).**

For `n ≥ 4` with `4 ∣ n` and every offset `r` in the window `-(n/4) ≤ r ≤ n/4`,

`offsetWeight n r ≤ (4 / √π) · binPMFInt n (1/2) (r + n/2)`.

The constant `C = 4/√π ≈ 2.2568 < 4` is uniform in `r` and absorbable into
`paper_lemma_6`'s factor-4 slack. The proof routes through ratio monotonicity
(`cross_mono`: the ratio is maximised at `r = 0`) and the proven central-coordinate
bound `OffsetWeightFterm.offsetWeight_le_central_factor`. -/
theorem offsetWeight_le_uniform_factor (n : ℕ) (hn : 4 ≤ n) (h4 : 4 ∣ n) (r : ℤ)
    (hlo : -(n / 4 : ℤ) ≤ r) (hhi : r ≤ (n / 4 : ℤ)) :
    (offsetWeight n r).toReal
      ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) (r + (n / 2 : ℤ)) := by
  obtain ⟨hq4, hq2, h2q, h4q⟩ := divfacts n h4
  set q := n / 4 with hq
  have hq1 : 1 ≤ q := by omega
  -- n/2 = 2q, n = 4q
  have hn2 : n / 2 = 2 * q := h2q
  have hn4 : n = 4 * q := h4q
  rw [hq4] at hlo hhi
  -- abbreviate the choose index of the numerator
  set k := (r + (q : ℤ)).toNat with hk
  have hk_le : k ≤ 2 * q := by rw [hk]; omega
  have hk_eq : (r + ((q : ℕ) : ℤ)) = (k : ℤ) := by
    rw [hk, Int.toNat_of_nonneg (by omega)]
  have hq2' : (n : ℤ) / 2 = 2 * (q : ℤ) := by rw [hq2]; exact_mod_cast h2q
  -- index of the numerator: (r + ↑(n/4)).toNat = k
  have hidx_num : (r + ((n / 4 : ℕ) : ℤ)).toNat = k := by
    rw [← hq, hk]
  -- index of the denominator: (r + n/2).toNat = q + k
  have hidx_den : (r + (n : ℤ) / 2).toNat = q + k := by
    rw [hq2', hk]; omega
  -- numerator real form
  have hNum : (offsetWeight n r).toReal
      = (Nat.choose (2 * q) k : ℝ) * (1 / 2 : ℝ) ^ (2 * q) := by
    rw [offsetWeight_toReal_window n r h4 (by rw [hq4]; omega) (by rw [hq4]; omega),
        hidx_num, hn2]
  -- denominator real form
  have hDen : binPMFInt n (1 / 2) (r + (n / 2 : ℤ))
      = (Nat.choose (4 * q) (q + k) : ℝ) * (1 / 2 : ℝ) ^ (4 * q) := by
    rw [binPMFInt_window n r h4 (by rw [hq4]; omega) (by rw [hq4]; omega), hidx_den, hn4]
  -- central forms at r = 0
  have hNum0 : (offsetWeight n 0).toReal
      = (Nat.choose (2 * q) q : ℝ) * (1 / 2 : ℝ) ^ (2 * q) := by
    rw [OffsetWeightFterm.offsetWeight_zero_toReal, hn2]
  have hDen0 : binPMFInt n (1 / 2) ((n : ℤ) / 2)
      = (Nat.choose (4 * q) (2 * q) : ℝ) * (1 / 2 : ℝ) ^ (4 * q) := by
    rw [OffsetWeightFterm.binPMFInt_central, hn2, hn4]
  -- central-coordinate bound (worst case): offsetWeight(0) ≤ (4/√π)·binPMFInt(n/2)
  have hcentral := OffsetWeightFterm.offsetWeight_le_central_factor n hn h4
  -- cross monotonicity: C(2q,k)·C(4q,2q) ≤ C(2q,q)·C(4q,q+k)
  have hmono := cross_mono q k hq1 hk_le
  -- positivity facts
  have hpowpos2 : (0 : ℝ) < (1 / 2 : ℝ) ^ (2 * q) := by positivity
  have hpowpos4 : (0 : ℝ) < (1 / 2 : ℝ) ^ (4 * q) := by positivity
  have hCqpos : (0 : ℝ) < (Nat.choose (2 * q) q : ℝ) := choose_pos_real _ _ (by omega)
  have hD2pos : (0 : ℝ) < (Nat.choose (4 * q) (2 * q) : ℝ) := choose_pos_real _ _ (by omega)
  have hDqkpos : (0 : ℝ) < (Nat.choose (4 * q) (q + k) : ℝ) := choose_pos_real _ _ (by omega)
  have hCkpos : (0 : ℝ) ≤ (Nat.choose (2 * q) k : ℝ) := (choose_pos_real _ _ hk_le).le
  have hsqpi : (0 : ℝ) < Real.sqrt Real.pi := Real.sqrt_pos.mpr Real.pi_pos
  have hconst : (0 : ℝ) < 4 / Real.sqrt Real.pi := by positivity
  -- denominator value positivity
  have hDenpos : 0 < binPMFInt n (1 / 2) (r + (n / 2 : ℤ)) := by
    rw [hDen]; positivity
  have hDen0pos : 0 < binPMFInt n (1 / 2) ((n : ℤ) / 2) := by
    rw [hDen0]; positivity
  -- Key cross-multiplied chain:
  --   offsetWeight(r)·binPMFInt(n/2) ≤ offsetWeight(0)·binPMFInt(r+n/2)
  have hstep1 : (offsetWeight n r).toReal * binPMFInt n (1 / 2) ((n : ℤ) / 2)
      ≤ (offsetWeight n 0).toReal * binPMFInt n (1 / 2) (r + (n / 2 : ℤ)) := by
    rw [hNum, hDen, hNum0, hDen0]
    -- C(2q,k)·2^{-2q}·(C(4q,2q)·2^{-4q}) ≤ C(2q,q)·2^{-2q}·(C(4q,q+k)·2^{-4q})
    have := mul_le_mul_of_nonneg_right hmono (mul_pos hpowpos2 hpowpos4).le
    nlinarith [this, hpowpos2, hpowpos4, hCkpos, hD2pos, hCqpos, hDqkpos]
  --   offsetWeight(0)·binPMFInt(r+n/2) ≤ (4/√π)·binPMFInt(n/2)·binPMFInt(r+n/2)
  have hstep2 : (offsetWeight n 0).toReal * binPMFInt n (1 / 2) (r + (n / 2 : ℤ))
      ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) ((n : ℤ) / 2)
          * binPMFInt n (1 / 2) (r + (n / 2 : ℤ)) := by
    apply mul_le_mul_of_nonneg_right hcentral hDenpos.le
  -- combine: offsetWeight(r)·D0 ≤ (4/√π)·D0·D(r), divide by D0 > 0
  have hcombined : (offsetWeight n r).toReal * binPMFInt n (1 / 2) ((n : ℤ) / 2)
      ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) (r + (n / 2 : ℤ))
          * binPMFInt n (1 / 2) ((n : ℤ) / 2) := by
    calc (offsetWeight n r).toReal * binPMFInt n (1 / 2) ((n : ℤ) / 2)
        ≤ (offsetWeight n 0).toReal * binPMFInt n (1 / 2) (r + (n / 2 : ℤ)) := hstep1
      _ ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) ((n : ℤ) / 2)
            * binPMFInt n (1 / 2) (r + (n / 2 : ℤ)) := hstep2
      _ = (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) (r + (n / 2 : ℤ))
            * binPMFInt n (1 / 2) ((n : ℤ) / 2) := by ring
  -- cancel the positive factor binPMFInt(n/2)
  exact le_of_mul_le_mul_right hcombined hDen0pos

end Workspace.ProofLemmas.OffsetWeightUniformRatio
