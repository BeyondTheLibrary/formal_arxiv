import Mathlib

/-- For every real `δ` with `δ ≤ 1`, `0 ≤ 1 - δ`. -/
theorem OneMinusDeltaNonneg :
    ∀ (δ : ℝ), δ ≤ 1 → 0 ≤ 1 - δ := by
  intro δ hδ
  linarith
