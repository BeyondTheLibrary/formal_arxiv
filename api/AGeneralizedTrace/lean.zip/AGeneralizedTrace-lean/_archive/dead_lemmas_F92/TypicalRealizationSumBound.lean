-- Typical-z realization sum bound.  Aggregates the per-summand typical-z bound
-- `altRSum_typical_le` over the realization set `Hset` and the typical z-grid
-- `G n` (z with `z < n/2+1` and real threshold `n/16 ≤ z`).  Pure Finset
-- arithmetic: per-summand ≤ Btyp·e^{-√n}, then card-bounded triple sum.
import Mathlib
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.AltRSumTypicalLe

set_option maxHeartbeats 4000000

namespace Workspace.ProofLemmas.TypicalRealizationSumBound

open scoped BigOperators
open Workspace.Types.AlternatingSumExpression
open Workspace.ProofLemmas.AltRSumTypicalLe

/-- Typical z-grid: `z < n/2+1` (via `range`) and real threshold `n/16 ≤ z`
(via filter).  Both guards match `altRSum_typical_le`'s z-hypotheses exactly. -/
noncomputable def G (n : ℕ) : Finset ℕ :=
  (Finset.range (n / 2 + 1)).filter (fun z => (n : ℝ) / 16 ≤ (z : ℝ))

/-- **Typical-z realization sum bound.**
Summing the per-summand typical bound over the realization set `Hset` and the
typical z-grid `G n` gives a clean `card · card² · Btyp · e^{-√n}` bound. -/
theorem typical_realization_sum_bound
    (n : ℕ) (hn : (10:ℕ)^12 ≤ n) (hn8 : n % 8 = 1)
    (δ : ℝ) (hδlb : 320 / Real.sqrt n ≤ δ) (hδub : δ ≤ 1/2)
    (Hset : Finset (Finset ℕ))
    (hHsub : ∀ ℓ ∈ Hset, ℓ ⊆ Finset.Icc 1 (n/2) ∧ sameParity ℓ)
    (hHcard : (Hset.card : ℝ) ≤ Real.exp (Real.sqrt n / 2)) :
    let α : ℝ := (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n
    (∑ ℓ ∈ Hset, ∑ zM ∈ G n, ∑ zP ∈ G n, |altRSum n δ α zM zP ℓ|)
      ≤ (Hset.card : ℝ) * ((G n).card : ℝ)^2
          * (((n:ℝ)+1)*(2*Real.pi-2)*(2*Real.pi)^2/(1-δ)^3 + 4*(2*Real.pi)^2/(1-δ)^2)
          * Real.exp (-Real.sqrt n) := by
  intro α
  -- Abbreviations.
  set B : ℝ := ((n:ℝ)+1)*(2*Real.pi-2)*(2*Real.pi)^2/(1-δ)^3
      + 4*(2*Real.pi)^2/(1-δ)^2 with hB
  set E : ℝ := Real.exp (-Real.sqrt n) with hE
  -- Basic positivity facts.
  have hn1 : 1 ≤ n := le_trans (by norm_num) hn
  have hnR_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn1
  have hsqrt_pos : 0 < Real.sqrt n := Real.sqrt_pos.mpr hnR_pos
  have h320_pos : (0 : ℝ) < 320 / Real.sqrt (n : ℝ) := by positivity
  have hδ_pos : 0 < δ := lt_of_lt_of_le h320_pos hδlb
  have hδ1 : δ < 1 := by linarith
  have hD : (0 : ℝ) < 1 - δ := by linarith
  have hpi : (1 : ℝ) < Real.pi := by linarith [Real.pi_gt_three]
  have hE_nn : 0 ≤ E := (Real.exp_pos _).le
  have hB_nn : 0 ≤ B := by
    rw [hB]
    have h1 : 0 ≤ ((n:ℝ)+1)*(2*Real.pi-2)*(2*Real.pi)^2/(1-δ)^3 := by
      apply div_nonneg
      · apply mul_nonneg; apply mul_nonneg
        · positivity
        · linarith
        · positivity
      · positivity
    have h2 : 0 ≤ 4*(2*Real.pi)^2/(1-δ)^2 := by positivity
    linarith
  have hBE_nn : 0 ≤ B * E := mul_nonneg hB_nn hE_nn
  -- STEP 1: per-summand bound.
  have hpersum : ∀ ℓ ∈ Hset, ∀ zM ∈ G n, ∀ zP ∈ G n,
      |altRSum n δ α zM zP ℓ| ≤ B * E := by
    intro ℓ hℓ zM hzM zP hzP
    obtain ⟨hℓsub, hℓpar⟩ := hHsub ℓ hℓ
    rw [G, Finset.mem_filter, Finset.mem_range] at hzM hzP
    obtain ⟨hzM_hi, hzM_lo⟩ := hzM
    obtain ⟨hzP_hi, hzP_lo⟩ := hzP
    have key := altRSum_typical_le n hn hn8 δ hδlb hδub zM zP
      hzM_lo hzM_hi hzP_lo hzP_hi ℓ hℓsub hℓpar
    simp only at key
    -- key's α matches our α (same expression); B, E definitionally equal RHS.
    rw [hB, hE]
    exact key
  -- STEP 2: inner zP sum.
  have hstep2 : ∀ ℓ ∈ Hset, ∀ zM ∈ G n,
      (∑ zP ∈ G n, |altRSum n δ α zM zP ℓ|) ≤ ((G n).card : ℝ) * (B * E) := by
    intro ℓ hℓ zM hzM
    have := Finset.sum_le_card_nsmul (G n)
      (fun zP => |altRSum n δ α zM zP ℓ|) (B * E)
      (fun zP hzP => hpersum ℓ hℓ zM hzM zP hzP)
    simpa [nsmul_eq_mul] using this
  -- STEP 3: inner zM sum → double z-sum ≤ card² · (B·E).
  have hstep3 : ∀ ℓ ∈ Hset,
      (∑ zM ∈ G n, ∑ zP ∈ G n, |altRSum n δ α zM zP ℓ|)
        ≤ ((G n).card : ℝ)^2 * (B * E) := by
    intro ℓ hℓ
    calc (∑ zM ∈ G n, ∑ zP ∈ G n, |altRSum n δ α zM zP ℓ|)
        ≤ ∑ zM ∈ G n, ((G n).card : ℝ) * (B * E) :=
          Finset.sum_le_sum (fun zM hzM => hstep2 ℓ hℓ zM hzM)
      _ = ((G n).card : ℝ) * (((G n).card : ℝ) * (B * E)) := by
          rw [Finset.sum_const, nsmul_eq_mul]
      _ = ((G n).card : ℝ)^2 * (B * E) := by ring
  -- STEP 4: outer ℓ sum.
  have hstep4 :
      (∑ ℓ ∈ Hset, ∑ zM ∈ G n, ∑ zP ∈ G n, |altRSum n δ α zM zP ℓ|)
        ≤ (Hset.card : ℝ) * (((G n).card : ℝ)^2 * (B * E)) := by
    calc (∑ ℓ ∈ Hset, ∑ zM ∈ G n, ∑ zP ∈ G n, |altRSum n δ α zM zP ℓ|)
        ≤ ∑ ℓ ∈ Hset, ((G n).card : ℝ)^2 * (B * E) :=
          Finset.sum_le_sum (fun ℓ hℓ => hstep3 ℓ hℓ)
      _ = (Hset.card : ℝ) * (((G n).card : ℝ)^2 * (B * E)) := by
          rw [Finset.sum_const, nsmul_eq_mul]
  -- Rearrange to target shape.
  calc (∑ ℓ ∈ Hset, ∑ zM ∈ G n, ∑ zP ∈ G n, |altRSum n δ α zM zP ℓ|)
      ≤ (Hset.card : ℝ) * (((G n).card : ℝ)^2 * (B * E)) := hstep4
    _ = (Hset.card : ℝ) * ((G n).card : ℝ)^2 * B * E := by ring

end Workspace.ProofLemmas.TypicalRealizationSumBound
