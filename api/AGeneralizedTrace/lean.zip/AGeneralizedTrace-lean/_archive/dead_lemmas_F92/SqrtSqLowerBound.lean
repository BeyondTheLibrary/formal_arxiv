import Mathlib

/-- For every real `δ` with `0 < δ ≤ 1/2` and every real `ξ`,
    `(1 - δ)^2 ≤ 1 - 2 * δ * cos ξ + δ^2`. -/
theorem SqrtSqLowerBound :
    ∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
      ∀ (ξ : ℝ), (1 - δ) ^ 2 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 := by
  intro δ hδpos hδhalf ξ
  have h1 : Real.cos ξ ≤ 1 := Real.cos_le_one ξ
  -- (1 - δ)^2 = 1 - 2δ + δ², so we need 1 - 2δ + δ² ≤ 1 - 2δ cos ξ + δ²
  -- i.e. -2δ ≤ -2δ cos ξ, i.e. 2δ cos ξ ≤ 2δ. Since δ > 0 and cos ξ ≤ 1, this holds.
  nlinarith [h1, hδpos]
