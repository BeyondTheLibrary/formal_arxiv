import Mathlib
import Workspace.Types.StirlingAxioms

/-!
# BinomialLowerEnvelope — a SOUND Gaussian lower envelope for the binomial pmf

The deleted `central_binomial_pmf_gaussian_lower_bound` used the asymptotic
constant `2` in the exponent with prefactor `√(2/(πn))`, which is FALSE for
finite `n` (the binomial decays faster than that Gaussian in the tails).

This file proves an honest lower envelope with provable constants
`c₀ = 1/2`, `C₀ = 4`, valid on the *bulk* `|k - n/2| ≤ n/4` for **even** `n`
(the case the downstream `offsetWeight` ratio needs, where `4 ∣ n`):

  `C(n,k) · 2^(-n) ≥ (1/(2√n)) · exp(-4·(k - n/2)²/n)`.

It is built from the proven Stirling mode bound
`central_binomial_pmf_lower_bound` (`C(n,⌊n/2⌋)·2^(-n) ≥ 1/(2√n)`) and the
telescoping ratio recurrence developed in `StirlingAxioms.lean`:

  `log(C(n,k)/C(n,m)) = ∑_{j=m}^{k-1} log((n-j)/(j+1))
     ≥ ∑_{j=m}^{k-1} (n-2j-1)/(n-j)
     ≥ (1/(n-k+1))·∑_{j=m}^{k-1} (n-2j-1) = -(k-m)²/(n-k+1) ≥ -4(k-m)²/n`,

where `m = n/2`.  The constants are verified numerically to be sound (the
worst-case ratio LHS/RHS over the bulk is `√2 > 1`).

The constant `C₀ = 4` is genuinely needed (and `c₀ = 1/2`): the binomial decays
like `exp(-n·KL)` in the tails, faster than any Gaussian, so a Gaussian lower
envelope can only hold with a *large enough* constant in front of the squared
deviation and on a bounded region; on the full range `[0,n]` no Gaussian lower
envelope holds with constant `< 4 ln 2`. We restrict to the bulk and use `C₀=4`.
-/

namespace Workspace.ProofLemmas.BinomialLowerEnvelope

open Workspace.Types.StirlingAxioms

set_option maxHeartbeats 1600000

/-- Auxiliary: dividing a nonpositive numerator by a larger positive denominator
gives a larger (less negative) value. -/
theorem div_le_div_iff_of_neg_aux {a b c : ℝ} (ha : a ≤ 0) (hb : 0 < b) (hc : 0 < c)
    (hbc : b ≤ c) : a / b ≤ a / c := by
  rw [div_le_div_iff₀ hb hc]
  nlinarith [ha, hbc, hb, hc]

/-- Gauss telescoping identity over `ℝ`:
`∑_{i=0}^{d-1} (N - 2 i - 1) = d·N - d²`.  Used with `N = 0` to get `-d²`. -/
theorem telescope_gauss_sum (N : ℝ) (d : ℕ) :
    (∑ i ∈ Finset.range d, (N - 2 * (i : ℝ) - 1))
      = (d : ℝ) * N - (d : ℝ)^2 := by
  induction d with
  | zero => simp
  | succ d ih =>
    rw [Finset.sum_range_succ, ih]
    push_cast
    ring

/-- Per-step ratio of the binomial pmf as a clean quotient:
for `j < n`, `C(n,j+1)/C(n,j) = (n - j)/(j + 1)`. -/
theorem ratio_step_eq (n j : ℕ) (hj : j < n) :
    (Nat.choose n (j + 1) : ℝ) / (Nat.choose n j : ℝ)
      = ((n : ℝ) - (j : ℝ)) / ((j : ℝ) + 1) := by
  have h := binom_ratio_succ n j hj
  have hjpos : (0 : ℝ) < (Nat.choose n j : ℝ) := by
    have : 0 < Nat.choose n j := Nat.choose_pos (le_of_lt hj)
    exact_mod_cast this
  rw [h]
  have hkn : ((n - j : ℕ) : ℝ) = (n : ℝ) - (j : ℝ) := by
    have : j ≤ n := le_of_lt hj
    push_cast [Nat.cast_sub this]; ring
  rw [hkn]
  push_cast
  field_simp

/-- Per-step LOWER bound on the log-ratio (the direction needed for a lower
envelope): for `j < n`, `(n - 2j - 1)/(n - j) ≤ log(C(n,j+1)/C(n,j))`.

Uses `log r ≥ 1 - 1/r` on the positive ratio `r = (n-j)/(j+1)`. -/
theorem log_ratio_step_ge (n j : ℕ) (hj : j < n) :
    ((n : ℝ) - 2 * (j : ℝ) - 1) / ((n : ℝ) - (j : ℝ))
      ≤ Real.log ((Nat.choose n (j + 1) : ℝ) / (Nat.choose n j : ℝ)) := by
  rw [ratio_step_eq n j hj]
  have hjn : (j : ℝ) < (n : ℝ) := by exact_mod_cast hj
  have hnj_pos : (0 : ℝ) < (n : ℝ) - (j : ℝ) := by linarith
  have hj1_pos : (0 : ℝ) < (j : ℝ) + 1 := by positivity
  set r : ℝ := ((n : ℝ) - (j : ℝ)) / ((j : ℝ) + 1) with hr
  have hr_pos : 0 < r := by rw [hr]; positivity
  have hlog : 1 - 1 / r ≤ Real.log r := by
    have h := Real.add_one_le_exp (-(Real.log r))
    rw [Real.exp_neg, Real.exp_log hr_pos] at h
    rw [one_div]
    linarith [h]
  have heq : 1 - 1 / r = ((n : ℝ) - 2 * (j : ℝ) - 1) / ((n : ℝ) - (j : ℝ)) := by
    rw [hr, one_div, inv_div]
    field_simp
    ring
  rw [heq] at hlog
  exact hlog

/-- Telescoping lower bound on the log-ratio from the mode `m` up to `k`
(`m ≤ k ≤ n`): with `d := k - m`,
`log(C(n,k)/C(n,m)) ≥ ∑_{i<d} (n - 2(m+i) - 1)/(n - m - i)`. -/
theorem log_ratio_mode_to_k_ge (n m k : ℕ) (hmk : m ≤ k) (hkn : k ≤ n) :
    Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ))
      ≥ ∑ i ∈ Finset.range (k - m),
          (((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / ((n : ℝ) - (m : ℝ) - (i : ℝ))) := by
  set f : ℕ → ℝ := fun j => Real.log (Nat.choose n j : ℝ) with hf
  have hpos : ∀ j, j ≤ n → (0 : ℝ) < (Nat.choose n j : ℝ) := by
    intro j hj
    have : 0 < Nat.choose n j := Nat.choose_pos hj
    exact_mod_cast this
  have hsplit : Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ)) = f k - f m := by
    rw [Real.log_div (ne_of_gt (hpos k hkn)) (ne_of_gt (hpos m (le_trans hmk hkn)))]
  rw [hsplit, ge_iff_le]
  have htele : f k - f m = ∑ i ∈ Finset.range (k - m), (f (m + i + 1) - f (m + i)) := by
    have hsr := Finset.sum_range_sub (fun i => f (m + i)) (k - m)
    simp only [Nat.add_zero] at hsr
    rw [show m + (k - m) = k by omega] at hsr
    rw [← hsr]
    apply Finset.sum_congr rfl
    intro i _
    rw [show m + i + 1 = m + (i + 1) by omega]
  rw [htele]
  apply Finset.sum_le_sum
  intro i hi
  rw [Finset.mem_range] at hi
  have hji : m + i < n := by omega
  have hstep := log_ratio_step_ge n (m + i) hji
  have hdiff : f (m + i + 1) - f (m + i)
      = Real.log ((Nat.choose n (m + i + 1) : ℝ) / (Nat.choose n (m + i) : ℝ)) := by
    rw [hf]
    simp only []
    rw [Real.log_div (ne_of_gt (hpos (m + i + 1) (by omega))) (ne_of_gt (hpos (m + i) (by omega)))]
  rw [hdiff]
  refine le_trans ?_ hstep
  apply le_of_eq
  push_cast
  ring

/-- **Telescope-to-quadratic, even `n`.** For `n = 2m` and `m ≤ k ≤ 3n/4`
(so `d := k - m ≤ n/4`):
`log(C(n,k)/C(n,m)) ≥ -(d²)/(n - k + 1) ≥ -4·d²/n`. -/
theorem log_ratio_quadratic_even (m k : ℕ) (hmk : m ≤ k) (hk34 : k ≤ m + m / 2)
    (hm : 1 ≤ m) :
    Real.log ((Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ))
      ≥ -(4 * ((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ))) := by
  set n := 2 * m with hn
  have hkn : k ≤ n := by rw [hn]; omega
  have hbase := log_ratio_mode_to_k_ge n m k hmk hkn
  -- the telescope sum, with n = 2m, has terms (-2i - 1)/(m - i)
  set d := k - m with hd
  -- denominator lower bound:  m - i ≥ (n - k + 1)  for i < d, and (n - k + 1) > 0
  have hnk1_pos : (0 : ℝ) < ((n : ℝ) - (k : ℝ) + 1) := by
    have : (k : ℝ) ≤ (n : ℝ) := by exact_mod_cast hkn
    linarith
  -- Sum lower bound term-by-term:
  --   (n - 2(m+i) - 1)/(n - m - i) ≥ (n - 2(m+i) - 1)/(n - k + 1)   [neg num / larger denom]
  have hterm : ∀ i ∈ Finset.range d,
      ((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / ((n : ℝ) - (k : ℝ) + 1)
        ≤ ((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / ((n : ℝ) - (m : ℝ) - (i : ℝ)) := by
    intro i hi
    rw [Finset.mem_range] at hi
    -- num = n - 2m - 2i - 1 = -2i - 1 (since n = 2m) ≤ 0
    have hnum_nonpos : ((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) ≤ 0 := by
      rw [hn]; push_cast; linarith [Nat.cast_nonneg (α := ℝ) i]
    -- denominators: 0 < (n - k + 1) ≤ (n - m - i)
    have hden_hi_pos : (0 : ℝ) < ((n : ℝ) - (m : ℝ) - (i : ℝ)) := by
      have hi' : (i : ℝ) < (d : ℝ) := by exact_mod_cast hi
      have hdk : (d : ℝ) = (k : ℝ) - (m : ℝ) := by
        rw [hd, Nat.cast_sub hmk]
      have hkn' : (k : ℝ) ≤ (n : ℝ) := by exact_mod_cast hkn
      -- n - m - i > n - m - d = n - k ≥ 0
      rw [hn]; push_cast
      rw [hn] at hkn'; push_cast at hkn'
      rw [hd] at hi'; rw [Nat.cast_sub hmk] at hi'
      linarith
    have hle_den : ((n : ℝ) - (k : ℝ) + 1) ≤ ((n : ℝ) - (m : ℝ) - (i : ℝ)) := by
      have hi' : (i : ℝ) ≤ (d : ℝ) - 1 := by
        have : i ≤ d - 1 := by omega
        have hd1 : 1 ≤ d := by omega
        have := (by exact_mod_cast this : (i : ℝ) ≤ ((d - 1 : ℕ) : ℝ))
        rw [Nat.cast_sub hd1] at this; push_cast at this; linarith
      have hdk : (d : ℝ) = (k : ℝ) - (m : ℝ) := by
        rw [hd, Nat.cast_sub hmk]
      -- n - m - i ≥ n - m - (d - 1) = n - m - d + 1 = n - k + 1
      have : (n : ℝ) - (m : ℝ) - (i : ℝ) ≥ (n : ℝ) - (m : ℝ) - ((d : ℝ) - 1) := by linarith
      rw [hdk] at this; linarith
    -- divide nonpositive numerator by larger denom -> larger (less negative)
    exact div_le_div_iff_of_neg_aux hnum_nonpos hnk1_pos hden_hi_pos hle_den
  -- sum of lower-bound terms:
  have hsum_ge : (∑ i ∈ Finset.range d,
        ((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / ((n : ℝ) - (k : ℝ) + 1))
      ≤ (∑ i ∈ Finset.range d,
          (((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / ((n : ℝ) - (m : ℝ) - (i : ℝ)))) :=
    Finset.sum_le_sum hterm
  -- evaluate ∑ (n - 2(m+i) - 1)/(n-k+1) = (∑ (n - 2(m+i) - 1))/(n-k+1)
  have hconst : (∑ i ∈ Finset.range d,
        ((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / ((n : ℝ) - (k : ℝ) + 1))
      = (∑ i ∈ Finset.range d, ((0 : ℝ) - 2 * (i : ℝ) - 1)) / ((n : ℝ) - (k : ℝ) + 1) := by
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro i _
    rw [hn]; push_cast; ring_nf
  rw [hconst, telescope_gauss_sum 0 d] at hsum_ge
  -- (0·d - d²) = -d²
  have hgauss : ((d : ℝ) * 0 - (d : ℝ)^2) = -(d : ℝ)^2 := by ring
  rw [hgauss] at hsum_ge
  -- so log-ratio ≥ -d²/(n-k+1)
  have hstep1 : Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ))
      ≥ -(d : ℝ)^2 / ((n : ℝ) - (k : ℝ) + 1) := by
    calc Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ))
        ≥ (∑ i ∈ Finset.range d,
            (((n : ℝ) - 2 * ((m : ℝ) + (i : ℝ)) - 1) / ((n : ℝ) - (m : ℝ) - (i : ℝ)))) := hbase
      _ ≥ -(d : ℝ)^2 / ((n : ℝ) - (k : ℝ) + 1) := hsum_ge
  -- now -d²/(n-k+1) ≥ -4d²/n   (since 0 < n/4 < n-k+1, i.e. n ≤ 4(n-k+1))
  have hd_sq_nonneg : (0 : ℝ) ≤ (d : ℝ)^2 := sq_nonneg _
  have hn_pos : (0 : ℝ) < (n : ℝ) := by
    rw [hn]; push_cast; have : (0:ℝ) < (m:ℝ) := by exact_mod_cast hm
    linarith
  -- n ≤ 4(n - k + 1)  ⟺  4k ≤ 3n + 4.  k ≤ m + m/2 ≤ 3m + ... ; with n = 2m: 4k ≤ 8m? need 4k ≤ 3n+4 = 6m+4.
  have hk_le : 4 * (k : ℝ) ≤ 3 * (n : ℝ) + 4 := by
    have hk34' : (k : ℝ) ≤ (m : ℝ) + ((m / 2 : ℕ) : ℝ) := by exact_mod_cast hk34
    have hm2 : ((m / 2 : ℕ) : ℝ) ≤ (m : ℝ) / 2 := by
      have : 2 * (m / 2) ≤ m := Nat.mul_div_le m 2
      have := (by exact_mod_cast this : (2 : ℝ) * ((m / 2 : ℕ) : ℝ) ≤ (m : ℝ))
      linarith
    rw [hn]; push_cast; linarith
  have hn_le_4 : (n : ℝ) ≤ 4 * ((n : ℝ) - (k : ℝ) + 1) := by linarith
  have hstep2 : -(d : ℝ)^2 / ((n : ℝ) - (k : ℝ) + 1) ≥ -(4 * (d : ℝ)^2 / (n : ℝ)) := by
    rw [ge_iff_le, neg_div, neg_le_neg_iff, div_le_div_iff₀ hnk1_pos hn_pos]
    nlinarith [hd_sq_nonneg, hn_le_4]
  -- combine, and rewrite d² = (k - m)², n = 2m
  have hd_eq : (d : ℝ) = (k : ℝ) - (m : ℝ) := by rw [hd, Nat.cast_sub hmk]
  calc Real.log ((Nat.choose n k : ℝ) / (Nat.choose n m : ℝ))
      ≥ -(d : ℝ)^2 / ((n : ℝ) - (k : ℝ) + 1) := hstep1
    _ ≥ -(4 * (d : ℝ)^2 / (n : ℝ)) := hstep2
    _ = -(4 * ((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ))) := by rw [hd_eq, hn]; push_cast; ring

/-- **Right-tail Gaussian lower envelope, even `n`.** For `n = 2m`, `m ≤ k`,
`k ≤ 3n/4` and `m ≥ 1`:
`C(n,k)·2^(-n) ≥ (1/(2√n))·exp(-4·(k - n/2)²/n)`. -/
theorem binom_pmf_lower_envelope_right (m k : ℕ) (hmk : m ≤ k) (hk34 : k ≤ m + m / 2)
    (hm : 1 ≤ m) :
    ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹)
      ≥ (1 / (2 * Real.sqrt (2 * m))) * Real.exp (-(4 * ((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ)))) := by
  have hn1 : 1 ≤ 2 * m := by omega
  have hkn : k ≤ 2 * m := by omega
  set E : ℝ := Real.exp (-(4 * ((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ)))) with hE
  have hE_pos : 0 < E := Real.exp_pos _
  -- mode positivity
  have hCm_pos : (0 : ℝ) < (Nat.choose (2 * m) m : ℝ) := by
    have : 0 < Nat.choose (2 * m) m := Nat.choose_pos (by omega)
    exact_mod_cast this
  -- mode lower bound:  C(2m, (2m)/2)·2^{-(2m)} ≥ 1/(2√(2m)), and (2m)/2 = m
  have hmode0 := central_binomial_pmf_lower_bound hn1
  have hndiv : (2 * m) / 2 = m := by omega
  rw [hndiv] at hmode0
  have hsq2m : Real.sqrt ((2 * m : ℕ)) = Real.sqrt (2 * (m : ℝ)) := by push_cast; rfl
  have hmode : ((Nat.choose (2 * m) m : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹) ≥ 1 / (2 * Real.sqrt (2 * (m : ℝ))) := by
    rw [hsq2m] at hmode0; exact hmode0
  -- log ratio bound  ⟹  ratio ≥ E
  have hlog := log_ratio_quadratic_even m k hmk hk34 hm
  have hratio_pos : (0 : ℝ) < (Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ) := by
    have : 0 < Nat.choose (2 * m) k := Nat.choose_pos hkn
    have h2 : (0 : ℝ) < (Nat.choose (2 * m) k : ℝ) := by exact_mod_cast this
    positivity
  have hratio_ge : (Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ) ≥ E := by
    rw [hE, ge_iff_le, ← Real.exp_log hratio_pos]
    apply Real.exp_le_exp.mpr
    linarith [hlog]
  -- C(2m,k)·2^{-2m} = (C(2m,k)/C(2m,m))·(C(2m,m)·2^{-2m})
  have hkey : (Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹
      = ((Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ))
          * ((Nat.choose (2 * m) m : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹) := by
    field_simp
  rw [hkey]
  calc (1 / (2 * Real.sqrt (2 * (m : ℝ)))) * E
      = E * (1 / (2 * Real.sqrt (2 * (m : ℝ)))) := by ring
    _ ≤ E * ((Nat.choose (2 * m) m : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹) :=
        mul_le_mul_of_nonneg_left hmode hE_pos.le
    _ ≤ ((Nat.choose (2 * m) k : ℝ) / (Nat.choose (2 * m) m : ℝ))
          * ((Nat.choose (2 * m) m : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹) :=
        mul_le_mul_of_nonneg_right hratio_ge (by positivity)

/-- **Full-bulk Gaussian lower envelope, even `n = 2m`.** For every `k` with
`|k - m| ≤ m/2` (i.e. `m/2 ≤ k ≤ m + m/2`, the central half of the support):
`C(2m,k)·2^(-2m) ≥ (1/(2√(2m)))·exp(-4·(k - m)²/(2m))`.

Both tails are handled: the right tail by `binom_pmf_lower_envelope_right`, the
left tail (`k < m`) by the symmetry `C(2m,k) = C(2m, 2m-k)` (deviation `|k-m|`
is preserved). This is the SOUND replacement for the deleted false Gaussian
lower bound; constants `c₀ = 1/2`, `C₀ = 4`. -/
theorem binom_pmf_lower_envelope_bulk (m k : ℕ) (hm : 1 ≤ m)
    (hlo : m - m / 2 ≤ k) (hhi : k ≤ m + m / 2) :
    ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹)
      ≥ (1 / (2 * Real.sqrt (2 * m))) * Real.exp (-(4 * ((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ)))) := by
  rcases Nat.lt_or_ge k m with hkm | hmk
  · -- left tail: k < m.  Use C(2m,k) = C(2m, 2m-k) and apply the right tail at k' = 2m-k.
    have hk2m : k ≤ 2 * m := by omega
    set k' := 2 * m - k with hk'
    have hsymm : Nat.choose (2 * m) k = Nat.choose (2 * m) k' := by
      rw [hk', Nat.choose_symm hk2m]
    have hmk' : m ≤ k' := by omega
    have hhi' : k' ≤ m + m / 2 := by omega
    have hright := binom_pmf_lower_envelope_right m k' hmk' hhi' hm
    -- deviation preserved: (k' - m)² = (k - m)²
    have hdev : ((k' : ℝ) - (m : ℝ))^2 = ((k : ℝ) - (m : ℝ))^2 := by
      have hk'R : (k' : ℝ) = 2 * (m : ℝ) - (k : ℝ) := by
        rw [hk', Nat.cast_sub hk2m]; push_cast; ring
      rw [hk'R]; ring
    rw [hdev] at hright
    -- goal: C(2m,k)·... ≥ ...(k-m)... ; hright: C(2m,k')·... ≥ ...(k-m)...
    rw [hsymm]
    exact hright
  · -- right tail: m ≤ k
    exact binom_pmf_lower_envelope_right m k hmk hhi hm

end Workspace.ProofLemmas.BinomialLowerEnvelope
