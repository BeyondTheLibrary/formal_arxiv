import Mathlib
import Workspace.Types.AlternatingSumExpression

open scoped BigOperators

namespace SuffixOffByOneIntegratedProof

open Workspace.Types.AlternatingSumExpression

/-- Sum of binomial PMF values is 1 over the natural support. -/
private lemma sum_binPMF_eq_one (M : ℕ) (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1) :
    ∑ z ∈ Finset.range (M + 1), binPMF M p z = 1 := by
  have h1 : (1 : ℝ) = (p + (1 - p))^M := by ring_nf
  have hadd : (p + (1 - p))^M = ∑ m ∈ Finset.range (M + 1),
      p ^ m * (1 - p) ^ (M - m) * (M.choose m : ℝ) := add_pow p (1 - p) M
  rw [h1, hadd]
  apply Finset.sum_congr rfl
  intro z hz
  simp only [Finset.mem_range] at hz
  unfold binPMF
  rw [if_pos (Nat.lt_succ_iff.mp hz)]
  ring

/-- Extended range still sums to 1. -/
private lemma sum_binPMF_range_succ_eq_one (M : ℕ) (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1) :
    ∑ z ∈ Finset.range (M + 2), binPMF M p z = 1 := by
  rw [Finset.sum_range_succ]
  have h_top : binPMF M p (M + 1) = 0 := by
    unfold binPMF
    rw [if_neg (by omega : ¬ (M + 1 ≤ M))]
  rw [h_top, add_zero, sum_binPMF_eq_one M p hp hp1]

/-- binPMF is nonnegative when 0 ≤ p ≤ 1. -/
private lemma binPMF_nonneg (M : ℕ) (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1) (z : ℕ) :
    0 ≤ binPMF M p z := by
  unfold binPMF
  split_ifs with h
  · have h1 : 0 ≤ (M.choose z : ℝ) := Nat.cast_nonneg _
    have h2 : 0 ≤ p ^ z := pow_nonneg hp z
    have h3 : 0 ≤ (1 - p) ^ (M - z) := pow_nonneg (by linarith) _
    positivity
  · exact le_refl 0

/-- Recurrence at z=0. -/
private lemma binPMF_diff_zero (M : ℕ) (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1) :
    binPMF (M + 1) p 0 - binPMF M p 0 = -p * binPMF M p 0 := by
  unfold binPMF
  rw [if_pos (Nat.zero_le _), if_pos (Nat.zero_le _)]
  simp only [Nat.choose_zero_right, Nat.cast_one, one_mul, pow_zero, Nat.sub_zero]
  -- Goal: (1-p)^(M+1) - (1-p)^M = -p * (1-p)^M
  -- (1-p)^(M+1) = (1-p) * (1-p)^M
  rw [pow_succ]
  ring

/-- Recurrence at z+1 with 1 ≤ z+1 ≤ M+1. -/
private lemma binPMF_diff_succ (M : ℕ) (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1)
    (z : ℕ) (hz : z + 1 ≤ M + 1) :
    binPMF (M + 1) p (z + 1) - binPMF M p (z + 1)
      = -p * binPMF M p (z + 1) + p * binPMF M p z := by
  by_cases hzM : z + 1 ≤ M
  · -- z+1 ≤ M
    unfold binPMF
    rw [if_pos (by omega : z + 1 ≤ M + 1), if_pos hzM, if_pos (by omega : z ≤ M)]
    -- Pascal: C(M+1, z+1) = C(M, z) + C(M, z+1)
    have h_pascal : ((M + 1).choose (z + 1) : ℝ) = (M.choose z : ℝ) + (M.choose (z + 1) : ℝ) := by
      rw [Nat.choose_succ_succ']
      push_cast
      ring
    rw [h_pascal]
    -- Exponent simplifications. Note `M+1 - (z+1) = M - z` in ℕ.
    have h1 : (M + 1) - (z + 1) = M - z := by omega
    -- And `M - z = (M - (z+1)) + 1` since z+1 ≤ M.
    have h2 : M - z = (M - (z + 1)) + 1 := by omega
    rw [h1, h2, pow_succ]
    ring
  · -- z+1 = M+1, so z = M
    have hzeq : M = z := by omega
    subst hzeq
    -- After subst, the goal uses M in place of z. (subst replaces the local var.)
    unfold binPMF
    rw [if_pos (le_refl (M + 1)), if_neg (Nat.not_succ_le_self M), if_pos (le_refl M)]
    simp only [Nat.choose_self, Nat.cast_one, one_mul, Nat.sub_self, pow_zero, mul_one]
    rw [pow_succ]
    ring

/-- |diff at z=0| = p * binPMF M p 0. -/
private lemma abs_binPMF_diff_zero (M : ℕ) (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1) :
    |binPMF (M + 1) p 0 - binPMF M p 0| = p * binPMF M p 0 := by
  rw [binPMF_diff_zero M p hp hp1]
  rw [abs_of_nonpos]
  · ring
  · have h := binPMF_nonneg M p hp hp1 0
    nlinarith

/-- |diff at z+1| ≤ p * binPMF M p (z+1) + p * binPMF M p z. -/
private lemma abs_binPMF_diff_succ (M : ℕ) (p : ℝ) (hp : 0 ≤ p) (hp1 : p ≤ 1)
    (z : ℕ) (hz : z + 1 ≤ M + 1) :
    |binPMF (M + 1) p (z + 1) - binPMF M p (z + 1)|
      ≤ p * binPMF M p (z + 1) + p * binPMF M p z := by
  rw [binPMF_diff_succ M p hp hp1 z hz]
  have hb1 : 0 ≤ binPMF M p (z + 1) := binPMF_nonneg M p hp hp1 (z + 1)
  have hb2 : 0 ≤ binPMF M p z := binPMF_nonneg M p hp hp1 z
  have h1 : 0 ≤ p * binPMF M p (z + 1) := mul_nonneg hp hb1
  have h2 : 0 ≤ p * binPMF M p z := mul_nonneg hp hb2
  rw [abs_le]
  constructor
  · linarith
  · linarith

theorem suffix_off_by_one_integrated_lemma :
    ∀ (M : ℕ) (p : ℝ), 1 ≤ M → 0 ≤ p → p ≤ 1 →
      (∑ z ∈ Finset.range (M + 2),
        |binPMF (M + 1) p z - binPMF M p z|)
      ≤ 2 * Real.sqrt p := by
  intro M p hM hp hp1
  have h_bound : (∑ z ∈ Finset.range (M + 2),
      |binPMF (M + 1) p z - binPMF M p z|) ≤ 2 * p := by
    -- Split sum at z = 0
    rw [Finset.sum_range_succ' (fun z => |binPMF (M + 1) p z - binPMF M p z|) (M + 1)]
    -- Now: ∑ z ∈ range(M+1), |diff at z+1| + |diff at 0|
    rw [abs_binPMF_diff_zero M p hp hp1]
    have h_sum_succ : (∑ z ∈ Finset.range (M + 1),
        |binPMF (M + 1) p (z + 1) - binPMF M p (z + 1)|)
      ≤ ∑ z ∈ Finset.range (M + 1), (p * binPMF M p (z + 1) + p * binPMF M p z) := by
      apply Finset.sum_le_sum
      intro z hz
      simp only [Finset.mem_range] at hz
      exact abs_binPMF_diff_succ M p hp hp1 z (by omega)
    have h_rhs : (∑ z ∈ Finset.range (M + 1), (p * binPMF M p (z + 1) + p * binPMF M p z))
        = p * (∑ z ∈ Finset.range (M + 1), binPMF M p (z + 1))
        + p * (∑ z ∈ Finset.range (M + 1), binPMF M p z) := by
      rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
    have h_shift : (∑ z ∈ Finset.range (M + 1), binPMF M p (z + 1))
        = 1 - binPMF M p 0 := by
      have hone : (∑ z ∈ Finset.range (M + 2), binPMF M p z) = 1 :=
        sum_binPMF_range_succ_eq_one M p hp hp1
      rw [Finset.sum_range_succ'] at hone
      linarith
    have h_full : (∑ z ∈ Finset.range (M + 1), binPMF M p z) = 1 := sum_binPMF_eq_one M p hp hp1
    have h_b0 : 0 ≤ binPMF M p 0 := binPMF_nonneg M p hp hp1 0
    calc (∑ z ∈ Finset.range (M + 1),
            |binPMF (M + 1) p (z + 1) - binPMF M p (z + 1)|) + p * binPMF M p 0
        ≤ (∑ z ∈ Finset.range (M + 1), (p * binPMF M p (z + 1) + p * binPMF M p z))
            + p * binPMF M p 0 := by linarith
      _ = p * (1 - binPMF M p 0) + p * 1 + p * binPMF M p 0 := by
            rw [h_rhs, h_shift, h_full]
      _ = 2 * p := by ring
  -- 2p ≤ 2 √p
  have h_sqrt : 2 * p ≤ 2 * Real.sqrt p := by
    have hp_le_sqrt : p ≤ Real.sqrt p := by
      apply Real.le_sqrt_of_sq_le
      nlinarith
    linarith
  linarith

end SuffixOffByOneIntegratedProof

theorem SuffixOffByOneIntegrated :
    ∀ (M : ℕ) (p : ℝ), 1 ≤ M → 0 ≤ p → p ≤ 1 →
      (∑ z ∈ Finset.range (M + 2),
        |Workspace.Types.AlternatingSumExpression.binPMF (M + 1) p z
          - Workspace.Types.AlternatingSumExpression.binPMF M p z|)
      ≤ 2 * Real.sqrt p :=
  SuffixOffByOneIntegratedProof.suffix_off_by_one_integrated_lemma
