import Mathlib
import Workspace.ProofLemmas.OneMinusDeltaNonneg
import Workspace.ProofLemmas.SqrtArgNonneg
import Workspace.ProofLemmas.AddOneLeExpNegOnUnitInterval
import Workspace.ProofLemmas.OneMinusCosLowerBound

open Real

/-- For every real `δ` with `0 < δ ≤ 1/2` and every real `ξ` with `1/2 ≤ |ξ|`
and `|ξ| ≤ π`,
`exp (δ/20) * (1 - δ) ≤ sqrt (1 - 2 * δ * cos ξ + δ^2)`. -/
theorem KeyDecayInequality :
    ∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
      ∀ (ξ : ℝ), (1 : ℝ) / 2 ≤ |ξ| → |ξ| ≤ Real.pi →
        Real.exp (δ / 20) * (1 - δ) ≤ Real.sqrt (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
  intro δ hδpos hδle ξ hξlo hξhi
  -- Basic facts.
  have hδle1 : δ ≤ 1 := le_trans hδle (by norm_num)
  have h1mδ : 0 ≤ 1 - δ := OneMinusDeltaNonneg δ hδle1
  have hsqrtArg : 0 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 := SqrtArgNonneg δ ξ
  -- LHS is nonneg.
  have hLHSnn : 0 ≤ Real.exp (δ / 20) * (1 - δ) :=
    mul_nonneg (le_of_lt (Real.exp_pos _)) h1mδ
  -- Reduce to squared inequality via `Real.le_sqrt_of_sq_le`.
  apply Real.le_sqrt_of_sq_le
  -- Goal: (exp (δ/20) * (1 - δ))^2 ≤ 1 - 2 * δ * cos ξ + δ^2
  -- Step A: (1 - δ/20) ≤ exp (-δ/20).
  have hδ20le1 : δ / 20 ≤ 1 := by linarith
  have hδ20nn : 0 ≤ δ / 20 := by linarith
  have hExpNeg : 1 - δ / 20 ≤ Real.exp (-(δ / 20)) :=
    AddOneLeExpNegOnUnitInterval (δ / 20) hδ20nn hδ20le1
  -- Both `1 - δ/20` and `exp(-(δ/20))` are nonneg; square.
  have h1mδ20nn : 0 ≤ 1 - δ / 20 := by linarith
  have hExpNegPos : 0 < Real.exp (-(δ / 20)) := Real.exp_pos _
  -- (1 - δ/20)^2 ≤ exp(-(δ/20))^2 = exp(-(δ/10)).
  have hSq : (1 - δ / 20) ^ 2 ≤ Real.exp (-(δ / 20)) ^ 2 := by
    have := mul_le_mul hExpNeg hExpNeg h1mδ20nn (le_of_lt hExpNegPos)
    nlinarith [hExpNeg, h1mδ20nn, hExpNegPos.le]
  -- exp(-(δ/20))^2 = exp(-(δ/10)).
  have hExpSq : Real.exp (-(δ / 20)) ^ 2 = Real.exp (-(δ / 10)) := by
    rw [sq, ← Real.exp_add]
    ring_nf
  -- So (1 - δ/20)^2 ≤ exp(-(δ/10)).
  have hSq' : (1 - δ / 20) ^ 2 ≤ Real.exp (-(δ / 10)) := by
    rw [← hExpSq]; exact hSq
  -- Step B: cos ξ ≤ 17/18 from `OneMinusCosLowerBound`.
  have hCosUB : Real.cos ξ ≤ 17 / 18 := by
    have := OneMinusCosLowerBound ξ hξlo hξhi
    linarith
  -- Step C: polynomial inequality
  --   (1 - δ)^2 ≤ (1 - δ/20)^2 * (1 - 2*δ*cos ξ + δ^2).
  -- Using cos ξ ≤ 17/18, it suffices to bound by
  -- (1 - δ/20)^2 * (1 - 17δ/9 + δ^2).
  have hLowerArg : 1 - 2 * δ * (17/18) + δ ^ 2 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 := by
    have hδpos' : 0 ≤ δ := le_of_lt hδpos
    nlinarith [hCosUB, hδpos']
  -- The squared LHS uses (1 - δ/20)^2 ≤ exp(-(δ/10)). We want to chain:
  --   exp (δ/10) * (1 - δ)^2 ≤ 1 - 2*δ*cos ξ + δ^2.
  -- Equivalently: (exp(δ/20) * (1 - δ))^2 ≤ 1 - 2*δ*cos ξ + δ^2.
  -- We split: (exp(δ/20)*(1-δ))^2 = exp(δ/10) * (1-δ)^2.
  -- Then bound exp(δ/10) * (1-δ)^2 ≤ (1-δ)^2 / (1 - δ/20)^2 ... hmm,
  -- using 1/(1 - δ/20)^2 ≥ exp(δ/10) is not the direct direction.
  -- Use: exp(-(δ/10)) ≥ (1 - δ/20)^2, so exp(δ/10) ≤ 1/(1-δ/20)^2.
  -- That gives exp(δ/10)*(1-δ)^2 ≤ (1-δ)^2 / (1-δ/20)^2.
  -- We need (1-δ)^2 / (1-δ/20)^2 ≤ 1 - 2*δ*cos ξ + δ^2,
  --   i.e., (1-δ)^2 ≤ (1-δ/20)^2 * (1 - 2*δ*cos ξ + δ^2).
  -- Final polynomial inequality:
  have hPoly : (1 - δ) ^ 2 ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * (17/18) + δ ^ 2) := by
    have hδpos' : 0 ≤ δ := le_of_lt hδpos
    nlinarith [hδpos', hδle, sq_nonneg δ, sq_nonneg (1 - δ), sq_nonneg (1 - δ / 20),
               mul_nonneg hδpos' hδpos', mul_self_nonneg δ]
  -- Combine: (1-δ)^2 ≤ (1-δ/20)^2 * (1 - 2δ cos ξ + δ^2)
  have hPoly' : (1 - δ) ^ 2 ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
    have hsq20nn : 0 ≤ (1 - δ / 20) ^ 2 := sq_nonneg _
    calc (1 - δ) ^ 2
        ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * (17/18) + δ ^ 2) := hPoly
      _ ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
          exact mul_le_mul_of_nonneg_left hLowerArg hsq20nn
  -- Now combine with hSq': (1-δ/20)^2 ≤ exp(-(δ/10)).
  -- We get exp(δ/10) * (1-δ)^2 ≤ 1 - 2*δ*cos ξ + δ^2.
  have hExp10pos : 0 < Real.exp (δ / 10) := Real.exp_pos _
  have hExpInv : Real.exp (δ / 10) * Real.exp (-(δ / 10)) = 1 := by
    rw [← Real.exp_add]
    ring_nf
    exact Real.exp_zero
  have hOneSqMul : Real.exp (δ / 10) * (1 - δ) ^ 2 ≤ 1 - 2 * δ * Real.cos ξ + δ ^ 2 := by
    -- From hPoly' and hSq': (1-δ)^2 ≤ exp(-(δ/10)) * (1 - 2δ cos ξ + δ^2)
    have h1mδsq_nn : 0 ≤ (1 - δ) ^ 2 := sq_nonneg _
    have hStepHelper : (1 - δ) ^ 2 ≤ Real.exp (-(δ / 10)) * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
      calc (1 - δ) ^ 2
          ≤ (1 - δ / 20) ^ 2 * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := hPoly'
        _ ≤ Real.exp (-(δ / 10)) * (1 - 2 * δ * Real.cos ξ + δ ^ 2) := by
            exact mul_le_mul_of_nonneg_right hSq' hsqrtArg
    -- Multiply both sides by exp(δ/10) > 0.
    have := mul_le_mul_of_nonneg_left hStepHelper (le_of_lt hExp10pos)
    -- exp(δ/10) * (1-δ)^2 ≤ exp(δ/10) * (exp(-(δ/10)) * RHS) = RHS.
    have heq : Real.exp (δ / 10) * (Real.exp (-(δ / 10)) * (1 - 2 * δ * Real.cos ξ + δ ^ 2))
             = 1 - 2 * δ * Real.cos ξ + δ ^ 2 := by
      rw [← mul_assoc, hExpInv, one_mul]
    linarith [this, heq.le, heq.ge]
  -- Finally: (exp(δ/20) * (1 - δ))^2 = exp(δ/10) * (1 - δ)^2.
  have hexp_split : Real.exp (δ / 20) ^ 2 = Real.exp (δ / 10) := by
    rw [sq, ← Real.exp_add]
    ring_nf
  have hLHSsq : (Real.exp (δ / 20) * (1 - δ)) ^ 2 = Real.exp (δ / 10) * (1 - δ) ^ 2 := by
    rw [mul_pow, hexp_split]
  rw [hLHSsq]
  exact hOneSqMul
