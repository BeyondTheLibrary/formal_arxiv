import Mathlib

open Real

/-- For every real number `t` with `0 ≤ t ≤ π/2`, `cos t ≤ 1 - t^2/4`. -/
theorem CosQuadraticUpperBound :
    ∀ (t : ℝ), 0 ≤ t → t ≤ Real.pi / 2 → Real.cos t ≤ 1 - t ^ 2 / 4 := by
  intro t ht0 ht1
  -- Use the identity cos(2u) = 1 - 2 sin²(u) with u = t/2
  have htid : t = 2 * (t/2) := by ring
  rw [htid, Real.cos_two_mul_eq_one_sub]
  rcases eq_or_lt_of_le ht0 with rfl | ht0_pos
  · simp
  -- Now 0 < t. Establish t/2 ∈ (0, 1].
  have ht2_pos : 0 < t / 2 := by linarith
  have hpi_le : Real.pi ≤ 4 := Real.pi_le_four
  have ht2_le_one : t / 2 ≤ 1 := by linarith
  -- Apply Real.sin_gt_sub_cube: sin u > u - u^3 / 4 for 0 < u ≤ 1.
  have hsin_lb : (t/2) - (t/2)^3 / 4 < Real.sin (t/2) :=
    Real.sin_gt_sub_cube ht2_pos ht2_le_one
  have hu_sq_le_one : (t/2)^2 ≤ 1 := by nlinarith
  have hlb_nn : 0 ≤ (t/2) - (t/2)^3 / 4 := by nlinarith [hu_sq_le_one]
  have hsin_pos : 0 ≤ Real.sin (t/2) := by linarith
  -- Square the lower bound on sin.
  have hsin_sq : ((t/2) - (t/2)^3 / 4)^2 ≤ Real.sin (t/2) ^ 2 := by
    nlinarith [hsin_lb, hlb_nn, hsin_pos]
  -- Key arithmetic inequality: (t/2)^2 ≤ 2 * ((t/2) - (t/2)^3/4)^2
  have key : (t/2)^2 ≤ 2 * ((t/2) - (t/2)^3 / 4)^2 := by
    nlinarith [hu_sq_le_one, sq_nonneg (t/2), ht2_pos.le, sq_nonneg ((t/2)^2 - 1),
               mul_self_nonneg (t/2)]
  -- Combine.
  nlinarith [hsin_sq, key]
