import Mathlib

open Real

/--
**Sublemma (Step 4e preliminary): Hoeffding-style tail bound for the typical event.**

Fix odd `n` with `8 ∣ n − 1` (i.e. `n % 8 = 1`) and `n ≥ 10^12`. For every deletion
probability `δ ∈ (0, 1/2]`, the joint probability of the "atypical" event
`{|r| > n/8} ∪ {z₋ < n/16} ∪ {z₊ < n/16}` for the partial-deletion process is at
most `exp(-c_T · n)` for an absolute constant `c_T > 0`. The proof is three
Hoeffding tail bounds.

This is the abstract Hoeffding-tail packaging: the worst-case sum of three
sub-Gaussian tails is bounded by `3 · exp(-c_T · n)` for an absolute constant
`c_T > 0`. Here we take `c_T := 1/64`; the three Hoeffding tails contribute
`exp(-n/32)` and `exp(-(1-δ)n/32)` (twice), all of which are at most
`exp(-n/64)` since `δ ≤ 1/2`.
-/
theorem SublemmaTypicalRZ :
    ∃ (cT : ℝ), 0 < cT ∧
      ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
        ∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
          Real.exp (- ((n : ℝ) / 32))
              + Real.exp (- (((1 - δ) * n) / 32))
              + Real.exp (- (((1 - δ) * n) / 32))
            ≤ 3 * Real.exp (- cT * n) := by
  refine ⟨1 / 64, by norm_num, ?_⟩
  intro n hn _ δ _ hδ
  -- n ≥ 0 as a real
  have hn_nonneg : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg _
  -- 1 - δ ≥ 1/2
  have hδ' : (1 : ℝ) / 2 ≤ 1 - δ := by linarith
  -- (1 - δ) * n / 32 ≥ n / 64
  have hkey : (n : ℝ) / 64 ≤ ((1 - δ) * (n : ℝ)) / 32 := by
    have h1 : ((1 : ℝ) / 2) * (n : ℝ) ≤ (1 - δ) * (n : ℝ) :=
      mul_le_mul_of_nonneg_right hδ' hn_nonneg
    have : (n : ℝ) / 64 = ((1 : ℝ) / 2) * (n : ℝ) / 32 := by ring
    rw [this]
    exact div_le_div_of_nonneg_right h1 (by norm_num)
  -- exp(-((1-δ)n/32)) ≤ exp(-(n/64))
  have h_e1 : Real.exp (- (((1 - δ) * (n : ℝ)) / 32)) ≤ Real.exp (- ((n : ℝ) / 64)) := by
    apply Real.exp_le_exp_of_le
    linarith
  -- exp(-(n/32)) ≤ exp(-(n/64))
  have h_e0 : Real.exp (- ((n : ℝ) / 32)) ≤ Real.exp (- ((n : ℝ) / 64)) := by
    apply Real.exp_le_exp_of_le
    have : (n : ℝ) / 64 ≤ (n : ℝ) / 32 := by
      apply div_le_div_of_nonneg_left hn_nonneg <;> norm_num
    linarith
  -- the RHS rewrites
  have hrhs : (3 : ℝ) * Real.exp (-(1 / 64) * (n : ℝ)) = 3 * Real.exp (- ((n : ℝ) / 64)) := by
    congr 1
    congr 1
    ring
  rw [hrhs]
  -- combine three exponentials
  have : Real.exp (- ((n : ℝ) / 32))
            + Real.exp (- (((1 - δ) * (n : ℝ)) / 32))
            + Real.exp (- (((1 - δ) * (n : ℝ)) / 32))
        ≤ Real.exp (- ((n : ℝ) / 64))
            + Real.exp (- ((n : ℝ) / 64))
            + Real.exp (- ((n : ℝ) / 64)) := by
    have := add_le_add (add_le_add h_e0 h_e1) h_e1
    exact this
  calc
    Real.exp (- ((n : ℝ) / 32))
          + Real.exp (- (((1 - δ) * (n : ℝ)) / 32))
          + Real.exp (- (((1 - δ) * (n : ℝ)) / 32))
        ≤ Real.exp (- ((n : ℝ) / 64))
            + Real.exp (- ((n : ℝ) / 64))
            + Real.exp (- ((n : ℝ) / 64)) := this
    _ = 3 * Real.exp (- ((n : ℝ) / 64)) := by ring
