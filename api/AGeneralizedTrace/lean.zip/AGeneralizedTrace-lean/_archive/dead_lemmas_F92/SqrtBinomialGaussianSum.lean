import Mathlib
import Workspace.Types.StirlingAxioms
import Workspace.ProofLemmas.BinomialUpperEnvelope
import Workspace.ProofLemmas.GaussianLatticeSumBound

open Workspace.ProofLemmas

namespace Workspace.ProofLemmas.SqrtBinomialGaussianSum

set_option maxHeartbeats 1600000

/-!
# `∑ √p_i` for the centred binomial pmf (even `n`): the honest slack bound

Toward Fact 9 (Rivkin–Valiant–Valiant 2024):
`∑_{i=0}^{n} √(C(n,i)·2^{-n}) ≤ (2π n)^{1/4}`.

This file proves the EVEN-`n` case of the achievable (non-tight) bound

  `∑_{i=0}^{2m} √(C(2m,i)·2^{-2m})  ≤  √2 · (2π·2m)^{1/4} + 2·(2/(π·2m))^{1/4}`.

### Why not the tight RHS?

The route is: (1) upper Gaussian envelope `p_k ≤ G·exp(-(k-m)²/(2m))` with
`G = √(2/(πn))` — proved in `BinomialUpperEnvelope`, exponent constant `c = 1`;
(2) `√p_k ≤ √G·exp(-(k-m)²/(4m))`; (3) the unimodal lattice-sum bound
`∑ exp(-(k-m)²/(4m)) ≤ 2 + √(π·4m) = 2 + √(2πn)` from
`GaussianLatticeSumBound.gc_lattice_sum_le`; (4) combine.

With `√G·√(2πn) = √2·(2πn)^{1/4}` and the residual two central terms contributing
`2·√G = 2·(2/(πn))^{1/4}`, the bound is `√2·(2πn)^{1/4} + 2·(2/(πn))^{1/4}`.

The leading factor `√2 ≈ 1.414` is the unavoidable price of the SOUND envelope
constant `c = 1`: the tight RHS needs the exponent constant `c = 2`, but `c = 2`
is provably FALSE for finite `n` (see the deleted-axiom note in `StirlingAxioms`).
For any provable `c < 2` the leading factor is `√(2/c) > 1`. Hence `(2π n)^{1/4}`
on the nose is unreachable by this elementary envelope+lattice route; the exact
extra factor is `√2` (plus a vanishing additive `O(n^{-1/4})`).
-/

/-- `gG n := √(√(2/(πn)))`, the square root of the peak bound `G = √(2/(πn))`. -/
noncomputable def sqrtG (n : ℕ) : ℝ := Real.sqrt (Real.sqrt (2 / (Real.pi * (n : ℝ))))

/-- Per-coordinate: `√(C(2m,k)·2^{-2m}) ≤ sqrtG (2m) · gc (4m) m k` (even `n`). -/
theorem sqrt_pmf_le_envelope (m k : ℕ) (hm : 1 ≤ m) (hk : k ≤ 2 * m) :
    Real.sqrt ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹)
      ≤ sqrtG (2 * m) * GaussianLatticeSumBound.gc (4 * (m : ℝ)) (m : ℝ) (k : ℝ) := by
  have hm' : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm
  -- envelope: p_k ≤ G · exp(-(k-m)²/(2m))
  have henv := BinomialUpperEnvelope.binom_pmf_upper_envelope_even m k hm hk
  set G : ℝ := Real.sqrt (2 / (Real.pi * ((2 * m : ℕ) : ℝ))) with hG
  set E : ℝ := Real.exp (-(((k : ℝ) - (m : ℝ))^2 / (2 * (m : ℝ)))) with hE
  have hG_nonneg : 0 ≤ G := Real.sqrt_nonneg _
  have hE_nonneg : 0 ≤ E := (Real.exp_pos _).le
  -- √(p_k) ≤ √(G·E) = √G · √E
  have h1 : Real.sqrt ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹)
      ≤ Real.sqrt (G * E) := Real.sqrt_le_sqrt henv
  rw [Real.sqrt_mul hG_nonneg] at h1
  -- √G = sqrtG (2m)
  have hGeq : Real.sqrt G = sqrtG (2 * m) := by
    rw [sqrtG, hG]
  -- √E = gc (4m) m k
  have hEeq : Real.sqrt E = GaussianLatticeSumBound.gc (4 * (m : ℝ)) (m : ℝ) (k : ℝ) := by
    rw [hE, ← Real.exp_half, GaussianLatticeSumBound.gc]
    congr 1
    field_simp
    ring
  rw [hGeq, hEeq] at h1
  exact h1

/-- **Even-`n` slack bound toward Fact 9.**
`∑_{k=0}^{2m} √(C(2m,k)·2^{-2m}) ≤ sqrtG(2m) · (2 + √(π·4m))`.

Since `sqrtG(2m) = (2/(π·2m))^{1/4}` and `√(π·4m) = √(2π·2m)`, the RHS equals
`√2 · (2π·2m)^{1/4} + 2·(2/(π·2m))^{1/4}` (see the file docstring).  This is the
honest, sorry-free bound; it exceeds the tight `(2π·2m)^{1/4}` by the factor `√2`
on the leading term plus a vanishing additive `2·(2/(π·2m))^{1/4}`. -/
theorem sqrt_binom_sum_even_le (m : ℕ) (hm : 1 ≤ m) :
    (∑ k ∈ Finset.range (2 * m + 1),
      Real.sqrt ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹))
      ≤ sqrtG (2 * m) * (2 + Real.sqrt (Real.pi * (4 * (m : ℝ)))) := by
  have hm' : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm
  have hsqrtG_nonneg : 0 ≤ sqrtG (2 * m) := Real.sqrt_nonneg _
  -- termwise bound
  have hterm : ∀ k ∈ Finset.range (2 * m + 1),
      Real.sqrt ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹)
        ≤ sqrtG (2 * m) * GaussianLatticeSumBound.gc (4 * (m : ℝ)) (m : ℝ) (k : ℝ) := by
    intro k hk
    rw [Finset.mem_range] at hk
    exact sqrt_pmf_le_envelope m k hm (by omega)
  have hsum_le : (∑ k ∈ Finset.range (2 * m + 1),
        Real.sqrt ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹))
      ≤ ∑ k ∈ Finset.range (2 * m + 1),
          sqrtG (2 * m) * GaussianLatticeSumBound.gc (4 * (m : ℝ)) (m : ℝ) (k : ℝ) :=
    Finset.sum_le_sum hterm
  -- pull out the constant sqrtG
  rw [← Finset.mul_sum] at hsum_le
  -- gaussian lattice sum: ∑ gc(4m)(m)(k) ≤ 2 + √(π·4m), with peak c=m < n=2m, scale 4m.
  have hgls := GaussianLatticeSumBound.gc_lattice_sum_le
    (4 * (m : ℝ)) (by positivity) (m : ℝ) (2 * m) (by omega)
    (by positivity) (by
      have : (m : ℝ) < 2 * (m : ℝ) := by linarith
      calc (m : ℝ) < 2 * (m : ℝ) := this
        _ = ((2 * m : ℕ) : ℝ) := by push_cast; ring)
  -- assemble
  calc (∑ k ∈ Finset.range (2 * m + 1),
          Real.sqrt ((Nat.choose (2 * m) k : ℝ) * (2 ^ (2 * m) : ℝ)⁻¹))
      ≤ sqrtG (2 * m) * (∑ k ∈ Finset.range (2 * m + 1),
            GaussianLatticeSumBound.gc (4 * (m : ℝ)) (m : ℝ) (k : ℝ)) := hsum_le
    _ ≤ sqrtG (2 * m) * (2 + Real.sqrt (Real.pi * (4 * (m : ℝ)))) :=
        mul_le_mul_of_nonneg_left hgls hsqrtG_nonneg

end Workspace.ProofLemmas.SqrtBinomialGaussianSum
