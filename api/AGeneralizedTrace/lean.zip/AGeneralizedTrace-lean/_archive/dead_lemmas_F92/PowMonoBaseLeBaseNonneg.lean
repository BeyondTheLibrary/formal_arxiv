import Mathlib

/-- For all real `a, b` with `0 ≤ a` and `a ≤ b`, and every natural `m`, `a^m ≤ b^m`. -/
theorem PowMonoBaseLeBaseNonneg :
    ∀ (a b : ℝ), 0 ≤ a → a ≤ b → ∀ (m : ℕ), a ^ m ≤ b ^ m := by
  intro a b ha hab m
  exact pow_le_pow_left₀ ha hab m
