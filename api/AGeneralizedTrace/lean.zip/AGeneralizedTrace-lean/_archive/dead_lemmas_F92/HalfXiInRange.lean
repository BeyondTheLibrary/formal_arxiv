import Mathlib

open Real

/-- For every real `ξ` with `1/3 ≤ |ξ|` and `|ξ| ≤ π`, we have
`1/6 ≤ |ξ/2|` and `|ξ/2| ≤ π/2`, hence `-π/2 ≤ ξ/2 ≤ π/2`. -/
theorem HalfXiInRange :
    ∀ (ξ : ℝ), (1 : ℝ) / 3 ≤ |ξ| → |ξ| ≤ Real.pi →
      (1 : ℝ) / 6 ≤ |ξ / 2| ∧ |ξ / 2| ≤ Real.pi / 2 ∧
        -(Real.pi / 2) ≤ ξ / 2 ∧ ξ / 2 ≤ Real.pi / 2 := by
  intro ξ h1 h2
  have habs : |ξ / 2| = |ξ| / 2 := by
    rw [abs_div]
    simp [abs_of_pos (by norm_num : (0 : ℝ) < 2)]
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [habs]; linarith
  · rw [habs]; linarith
  · have := abs_le.mp (by rw [habs]; linarith [h2] : |ξ / 2| ≤ Real.pi / 2)
    linarith [this.1]
  · have := abs_le.mp (by rw [habs]; linarith [h2] : |ξ / 2| ≤ Real.pi / 2)
    linarith [this.2]
