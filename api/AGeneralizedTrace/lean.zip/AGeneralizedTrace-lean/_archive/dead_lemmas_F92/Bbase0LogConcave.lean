import Mathlib
import Workspace.ProofLemmas.GlinWeightedMGF

open scoped Real
open GlinWeightedMGF GenvConvergence

set_option maxHeartbeats 4000000

/-!
# Multiplicative log-concavity of the compact-support base `Bbase0 n`

This file proves the *base atom* for the faithful fix of
`BinomialPmfFourierLogConcave`: the paper's exact base fact (deletion.tex:357)
that `cos(ξ/2)` is log-concave on `[-π,π]`, hence `cos(ξ/2)^n = Bbase0 n`
is log-concave, stated in multiplicative form on all of ℝ.

`Bbase0 n x = if |x| ≤ π then Bbase n x else 0`, and on `[-π,π]`,
`Bbase n x = cos(x/2)^n` (`Bbase_eq_cos_pow`).

The single analytic ingredient is `Real.cos` being concave on `[-π/2,π/2]`
(`strictConcaveOn_cos_Icc`), combined with the two-term weighted AM-GM
inequality (`Real.geom_mean_le_arith_mean2_weighted`).  Concretely, for
`x,y ∈ [-π,π]` and `0 ≤ t ≤ 1`, writing `m := t*x + (1-t)*y`:

  cos(x/2)^t · cos(y/2)^(1-t)
      ≤ t·cos(x/2) + (1-t)·cos(y/2)        (weighted AM-GM)
      ≤ cos(t·(x/2) + (1-t)·(y/2)) = cos(m/2)   (concavity of cos)

Raising to the `n`-th power (monotone on nonnegatives) gives log-concavity of
`cos(·/2)^n`, i.e. of `Bbase0 n`.
-/

namespace Bbase0LogConcave

/-- The pointwise log-concavity of `g(ξ) := cos(ξ/2)` on `[-π,π]`, in the
multiplicative (geometric-mean) form. -/
theorem cosHalf_logConcave
    (x y t : ℝ) (ht0 : 0 ≤ t) (ht1 : t ≤ 1)
    (hx : |x| ≤ Real.pi) (hy : |y| ≤ Real.pi) :
    Real.cos (x / 2) ^ t * Real.cos (y / 2) ^ (1 - t)
      ≤ Real.cos ((t * x + (1 - t) * y) / 2) := by
  -- nonnegativity of the cosines on the half-interval
  have hcos_nn : ∀ z : ℝ, |z| ≤ Real.pi → 0 ≤ Real.cos (z / 2) := by
    intro z hz
    have habs2 : |z / 2| ≤ Real.pi / 2 := by
      rw [abs_div]; simp; linarith [hz]
    rw [abs_le] at habs2
    exact Real.cos_nonneg_of_neg_pi_div_two_le_of_le (by linarith [habs2.1]) habs2.2
  have hcx : 0 ≤ Real.cos (x / 2) := hcos_nn x hx
  have hcy : 0 ≤ Real.cos (y / 2) := hcos_nn y hy
  -- weighted AM-GM:  cos(x/2)^t · cos(y/2)^(1-t) ≤ t·cos(x/2) + (1-t)·cos(y/2)
  have hamgm :
      Real.cos (x / 2) ^ t * Real.cos (y / 2) ^ (1 - t)
        ≤ t * Real.cos (x / 2) + (1 - t) * Real.cos (y / 2) :=
    Real.geom_mean_le_arith_mean2_weighted ht0 (by linarith) hcx hcy (by ring)
  -- concavity of cos on [-π/2, π/2]:  the convex combination of cos values is
  -- below cos of the convex combination of arguments.
  have hconc := (strictConcaveOn_cos_Icc).concaveOn
  have hmx : (x / 2) ∈ Set.Icc (-(Real.pi / 2)) (Real.pi / 2) := by
    rw [abs_le] at hx; constructor <;> [linarith [hx.1]; linarith [hx.2]]
  have hmy : (y / 2) ∈ Set.Icc (-(Real.pi / 2)) (Real.pi / 2) := by
    rw [abs_le] at hy; constructor <;> [linarith [hy.1]; linarith [hy.2]]
  have hcc :=
    hconc.2 hmx hmy ht0 (by linarith : (0:ℝ) ≤ 1 - t) (by ring : t + (1 - t) = 1)
  -- rewrite the smul/affine combo into the cos((t*x+(1-t)*y)/2) shape
  have hcomb : t • (x / 2) + (1 - t) • (y / 2) = (t * x + (1 - t) * y) / 2 := by
    simp only [smul_eq_mul]; ring
  have hcc' :
      t * Real.cos (x / 2) + (1 - t) * Real.cos (y / 2)
        ≤ Real.cos ((t * x + (1 - t) * y) / 2) := by
    rw [hcomb] at hcc
    simpa only [smul_eq_mul] using hcc
  exact le_trans hamgm hcc'

/-- `Bbase0 n` is multiplicatively log-concave on all of ℝ, for `n ≥ 1`:
  `Bbase0 n x ^ t · Bbase0 n y ^ (1-t) ≤ Bbase0 n (t·x + (1-t)·y)`. -/
theorem Bbase0_logConcave (n : ℕ) (hn : 1 ≤ n)
    (x y t : ℝ) (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    Bbase0 n x ^ t * Bbase0 n y ^ (1 - t)
      ≤ Bbase0 n (t * x + (1 - t) * y) := by
  -- handle the degenerate endpoints t = 0 and t = 1 directly
  rcases eq_or_lt_of_le ht0 with ht0' | ht0'
  · -- t = 0:  LHS = Bbase0 n y, RHS = Bbase0 n (0*x + 1*y) = Bbase0 n y
    subst ht0'
    simp only [Real.rpow_zero, one_mul, sub_zero, Real.rpow_one, zero_mul, zero_add, one_mul]
    exact le_refl _
  rcases eq_or_lt_of_le ht1 with ht1' | ht1'
  · -- t = 1:  LHS = Bbase0 n x, RHS = Bbase0 n (1*x + 0*y) = Bbase0 n x
    subst ht1'
    simp only [Real.rpow_one, sub_self, Real.rpow_zero, mul_one, one_mul, sub_self, zero_mul,
      add_zero]
    exact le_refl _
  -- now 0 < t < 1
  set m := t * x + (1 - t) * y with hm
  -- CASE split on whether x and y are in [-π,π]
  by_cases hx : |x| ≤ Real.pi
  · by_cases hy : |y| ≤ Real.pi
    · -- both in range: m is in range (convexity of [-π,π]); use cos-pow form
      have hm_range : |m| ≤ Real.pi := by
        rw [abs_le] at hx hy ⊢
        rw [hm]
        constructor
        · nlinarith [hx.1, hy.1, ht0, (by linarith : (0:ℝ) ≤ 1 - t)]
        · nlinarith [hx.2, hy.2, ht0, (by linarith : (0:ℝ) ≤ 1 - t)]
      -- unfold Bbase0 to cos-pow on the three points
      have hBx : Bbase0 n x = Real.cos (x / 2) ^ n := by
        unfold Bbase0; rw [if_pos hx, Bbase_eq_cos_pow n hn x hx]
      have hBy : Bbase0 n y = Real.cos (y / 2) ^ n := by
        unfold Bbase0; rw [if_pos hy, Bbase_eq_cos_pow n hn y hy]
      have hBm : Bbase0 n m = Real.cos (m / 2) ^ n := by
        unfold Bbase0; rw [if_pos hm_range, Bbase_eq_cos_pow n hn m hm_range]
      rw [hBx, hBy, hBm]
      -- cos values are nonneg on the range
      have hcos_nn : ∀ z : ℝ, |z| ≤ Real.pi → 0 ≤ Real.cos (z / 2) := by
        intro z hz
        have habs2 : |z / 2| ≤ Real.pi / 2 := by
          rw [abs_div]; simp; linarith [hz]
        rw [abs_le] at habs2
        exact Real.cos_nonneg_of_neg_pi_div_two_le_of_le (by linarith [habs2.1]) habs2.2
      have hcx : 0 ≤ Real.cos (x / 2) := hcos_nn x hx
      have hcy : 0 ≤ Real.cos (y / 2) := hcos_nn y hy
      have hcm : 0 ≤ Real.cos (m / 2) := hcos_nn m hm_range
      -- base log-concavity of cos(·/2)
      have hbase := cosHalf_logConcave x y t ht0 ht1 hx hy
      rw [← hm] at hbase
      -- Goal: (cos x/2 ^ n) ^ t * (cos y/2 ^ n) ^ (1-t) ≤ cos (m/2) ^ n.
      -- Convert all the nat-powers to rpow and group exponents.
      rw [← Real.rpow_natCast (Real.cos (x / 2)) n, ← Real.rpow_natCast (Real.cos (y / 2)) n,
        ← Real.rpow_natCast (Real.cos (m / 2)) n,
        ← Real.rpow_mul hcx, ← Real.rpow_mul hcy]
      -- now LHS exponents are (n*t) and (n*(1-t)); rewrite to (t*n), ((1-t)*n)
      rw [mul_comm (n : ℝ) t, mul_comm (n : ℝ) (1 - t),
        Real.rpow_mul hcx t, Real.rpow_mul hcy (1 - t),
        ← Real.mul_rpow (Real.rpow_nonneg hcx t) (Real.rpow_nonneg hcy (1 - t))]
      -- goal: (cos x/2 ^ t * cos y/2 ^ (1-t)) ^ (n:ℝ) ≤ cos (m/2) ^ (n:ℝ)
      apply Real.rpow_le_rpow (by positivity) hbase (by positivity)
    · -- y ∉ [-π,π]:  Bbase0 n y = 0, exponent (1-t) > 0, so factor = 0
      have hBy0 : Bbase0 n y = 0 := Bbase0_supp n y (not_le.mp hy)
      rw [hBy0, Real.zero_rpow (by linarith : (1 - t) ≠ 0), mul_zero]
      exact Bbase0_nonneg n m
  · -- x ∉ [-π,π]:  Bbase0 n x = 0, exponent t > 0, so factor = 0
    have hBx0 : Bbase0 n x = 0 := Bbase0_supp n x (not_le.mp hx)
    rw [hBx0, Real.zero_rpow (by linarith : t ≠ 0), zero_mul]
    exact Bbase0_nonneg n m

end Bbase0LogConcave
