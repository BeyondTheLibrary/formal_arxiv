import Mathlib

/-- For every real `ξ` with `1/2 ≤ |ξ|` and `|ξ| ≤ π`, `1 - cos ξ ≥ 1/18`. -/
theorem OneMinusCosLowerBound :
    ∀ (ξ : ℝ), 1 / 2 ≤ |ξ| → |ξ| ≤ Real.pi → 1 - Real.cos ξ ≥ 1 / 18 := by
  intro ξ hlow hhigh
  -- Reduce to the nonnegative variable y = |ξ| using cos_abs.
  rw [show Real.cos ξ = Real.cos |ξ| from (Real.cos_abs ξ).symm]
  set y := |ξ|
  have hy_pos : 0 < y := by linarith [abs_nonneg ξ]
  -- Use the half-angle identity 1 - cos y = 2 sin²(y/2).
  have h_cos_eq : Real.cos y = 1 - 2 * Real.sin (y/2) ^ 2 := by
    conv_lhs => rw [show y = 2 * (y/2) by ring]
    exact Real.cos_two_mul_eq_one_sub (y/2)
  rw [h_cos_eq]
  -- Now y/2 ∈ [1/4, π/2]; sin is monotone on [0, π/2].
  have hy2_pos : 0 < y/2 := by linarith
  have hy2_lb : 1/4 ≤ y/2 := by linarith
  have hy2_ub : y/2 ≤ Real.pi/2 := by linarith
  have hsin_mono : Real.sin (1/4) ≤ Real.sin (y/2) := by
    apply Real.sin_le_sin_of_le_of_le_pi_div_two
    · linarith
    · exact hy2_ub
    · linarith
  -- sin(1/4) ≥ 1/4 - (1/4)^3/4 by Real.sin_gt_sub_cube.
  have hsin_14_lb : Real.sin (1/4) ≥ 1/4 - (1/4)^3/4 := by
    have h := Real.sin_gt_sub_cube (x := 1/4) (by norm_num) (by norm_num)
    linarith
  have hsin_lb_strong : Real.sin (y/2) ≥ 1/4 - (1/4)^3/4 := by linarith
  have hsin_lb_pos : (0:ℝ) ≤ 1/4 - (1/4)^3/4 := by norm_num
  have hsin_sq_lb : Real.sin (y/2) ^ 2 ≥ (1/4 - (1/4)^3/4)^2 := by
    nlinarith [hsin_lb_strong, hsin_lb_pos]
  -- (1/4 - 1/256)² ≈ 0.0610 > 1/36, so 2 · sin²(y/2) ≥ 1/18.
  nlinarith [hsin_sq_lb]
