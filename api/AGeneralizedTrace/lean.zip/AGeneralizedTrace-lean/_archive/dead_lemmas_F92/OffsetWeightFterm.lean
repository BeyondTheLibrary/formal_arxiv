import Mathlib
import Workspace.Types.StirlingAxioms
import Workspace.Types.PartialDeletionProcess
import Workspace.Types.AlternatingSumExpression

/-!
# offsetWeight vs. Fterm's first binomial factor (central coordinate)

This file relates the partial-deletion offset distribution `offsetWeight n r`
(the *sampling* distribution `bin(n/2, 1/2, r + n/4)`, paper arXiv:2412.00674v1
line 232/295) to the first binomial factor of `Fterm`, namely
`binPMFInt n (1/2) (r + n/2) = bin(n, 1/2, r + n/2)` (the factor written in the
paper's Eq. r-func-lemma, line 300).

These are GENUINELY DIFFERENT functions of `r`: the offset is *sampled* as
`Bin(n/2,1/2) - n/4`, but the paper's displayed alternating-sum term replaces the
sampling weight by `bin(n,1/2,r+n/2)`. The two agree only up to an `O(1)`
multiplicative factor — exactly the slack the paper absorbs and that
`paper_lemma_6` carries as its factor-4 slack.

The decisive (worst) case of the comparison is the central coordinate `r = 0`,
where the offset distribution attains its maximum.  This file proves that
central-coordinate bound *sorry-free*, with the tight provable constant
`4 / √π ≈ 2.2568`, using the two proven Stirling theorems
`central_binomial_pmf_upper_bound` and `central_binomial_pmf_lower_bound`.

At `r = 0`:
* `offsetWeight n 0 = C(n/2, n/4)·2^(-n/2) = bin(n/2,1/2,n/4)`
  `≤ √(2/(π·(n/2))) = 2/√(πn)`            (upper bound, central coord of `n/2`),
* `bin(n,1/2,n/2) = C(n,n/2)·2^(-n) ≥ 1/(2√n)`  (lower bound, central coord),

so `offsetWeight n 0 ≤ (2/√(πn)) = (4/√π)·(1/(2√n)) ≤ (4/√π)·bin(n,1/2,n/2)`.
-/

namespace Workspace.ProofLemmas.OffsetWeightFterm

open Workspace.Types.StirlingAxioms
open Workspace.Types.PartialDeletionProcess
open Workspace.Types.AlternatingSumExpression

/-- `offsetWeight n 0` as a real number equals `C(n/2, n/4) · (1/2)^(n/2)`. -/
lemma offsetWeight_zero_toReal (n : ℕ) :
    (offsetWeight n 0).toReal
      = (Nat.choose (n / 2) (n / 4) : ℝ) * (1 / 2 : ℝ) ^ (n / 2) := by
  unfold offsetWeight
  have hcond : (0 : ℤ) ≤ (0 : ℤ) + (n / 4 : ℕ) ∧ (0 : ℤ) + (n / 4 : ℕ) ≤ (n / 2 : ℕ) := by
    have hle : n / 4 ≤ n / 2 := Nat.div_le_div_left (by norm_num) (by norm_num)
    refine ⟨by positivity, ?_⟩
    have : ((n / 4 : ℕ) : ℤ) ≤ ((n / 2 : ℕ) : ℤ) := by exact_mod_cast hle
    simpa using this
  rw [dif_pos hcond]
  have htoNat : ((0 : ℤ) + (n / 4 : ℕ)).toNat = n / 4 := by
    rw [zero_add, Int.toNat_natCast]
  rw [htoNat, ENNReal.toReal_mul, ENNReal.toReal_natCast]
  congr 1
  rw [ENNReal.toReal_pow, ENNReal.toReal_ofReal (by norm_num : (0:ℝ) ≤ 1 / 2)]

/-- `bin(n,1/2,n/2)` (the central value of `Fterm`'s first factor) equals
`C(n, n/2) · (1/2)^n`. -/
lemma binPMFInt_central (n : ℕ) :
    binPMFInt n (1 / 2) ((n : ℤ) / 2)
      = (Nat.choose n (n / 2) : ℝ) * (1 / 2 : ℝ) ^ n := by
  unfold binPMFInt
  have hcond : (0 : ℤ) ≤ (n : ℤ) / 2 ∧ (n : ℤ) / 2 ≤ (n : ℤ) := by
    refine ⟨by positivity, by omega⟩
  rw [if_pos hcond]
  have htoNat : ((n : ℤ) / 2).toNat = n / 2 := by
    omega
  rw [htoNat]
  unfold binPMF
  rw [if_pos (Nat.div_le_self n 2)]
  have h2 : (1 : ℝ) - 1 / 2 = 1 / 2 := by norm_num
  rw [h2, mul_assoc, ← pow_add]
  congr 2
  omega

/-- **Central-coordinate ratio bound.**

For `n ≥ 4` with `4 ∣ n`, the partial-deletion offset weight at `r = 0`
(its maximum) is bounded by `Fterm`'s first binomial factor at `r = 0`, with
the tight provable constant `4 / √π`:

`offsetWeight n 0 ≤ (4 / √π) · bin(n, 1/2, n/2)`.

This is the worst (largest-ratio) case of the relation
`offsetWeight n r ≤ C · binPMFInt n (1/2) (r + n/2)`; the constant `4/√π < 4`
is absorbable into `paper_lemma_6`'s factor-4 slack. -/
theorem offsetWeight_le_central_factor (n : ℕ) (hn : 4 ≤ n) (h4 : 4 ∣ n) :
    (offsetWeight n 0).toReal
      ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) ((n : ℤ) / 2) := by
  rw [offsetWeight_zero_toReal, binPMFInt_central]
  have hnpos : 1 ≤ n := by omega
  have hhpos : 1 ≤ n / 2 := by omega
  -- n/4 = (n/2)/2, the central coordinate of n/2
  have hquart : n / 4 = (n / 2) / 2 := by omega
  -- LHS = C(n/2, (n/2)/2)·2^{-(n/2)}
  have hLHS : (Nat.choose (n / 2) (n / 4) : ℝ) * (1 / 2 : ℝ) ^ (n / 2)
      = (Nat.choose (n / 2) ((n / 2) / 2) : ℝ) * (2 ^ (n / 2) : ℝ)⁻¹ := by
    rw [hquart, one_div, inv_pow]
  -- RHS factor = C(n, n/2)·2^{-n}
  have hRHS : (Nat.choose n (n / 2) : ℝ) * (1 / 2 : ℝ) ^ n
      = (Nat.choose n (n / 2) : ℝ) * (2 ^ n : ℝ)⁻¹ := by
    rw [one_div, inv_pow]
  rw [hLHS, hRHS]
  -- Stirling bounds
  have hUB := central_binomial_pmf_upper_bound hhpos ((n / 2) / 2)
  have hLB : (Nat.choose n (n / 2) : ℝ) * (2 ^ n : ℝ)⁻¹ ≥ 1 / (2 * Real.sqrt n) :=
    central_binomial_pmf_lower_bound hnpos
  -- positivity facts
  have hpi_pos : 0 < Real.pi := Real.pi_pos
  have hsqpi_pos : 0 < Real.sqrt Real.pi := Real.sqrt_pos.mpr hpi_pos
  have hnR_pos : (0:ℝ) < (n:ℝ) := by exact_mod_cast hnpos
  have hsqn_pos : 0 < Real.sqrt n := Real.sqrt_pos.mpr hnR_pos
  have hhR : ((n / 2 : ℕ) : ℝ) = (n : ℝ) / 2 := by
    have hmul : 2 * (n / 2) = n := by omega
    have h2 : ((2 * (n / 2) : ℕ) : ℝ) = (n : ℝ) := by exact_mod_cast hmul
    push_cast at h2
    linarith
  -- constant rewrite: √(2/(π·↑(n/2))) = 2/(√π·√n)
  have hconst : Real.sqrt (2 / (Real.pi * ((n / 2 : ℕ) : ℝ))) = 2 / (Real.sqrt Real.pi * Real.sqrt n) := by
    have harg : (2 : ℝ) / (Real.pi * ((n / 2 : ℕ) : ℝ)) = (2 / (Real.sqrt Real.pi * Real.sqrt n))^2 := by
      rw [hhR, div_pow, mul_pow, Real.sq_sqrt hpi_pos.le, Real.sq_sqrt hnR_pos.le]
      field_simp
    rw [harg, Real.sqrt_sq (by positivity)]
  -- key constant inequality: √(2/(π·↑(n/2))) ≤ (4/√π)·(1/(2√n))
  have hkey : Real.sqrt (2 / (Real.pi * ((n / 2 : ℕ) : ℝ))) ≤ (4 / Real.sqrt Real.pi) * (1 / (2 * Real.sqrt n)) := by
    rw [hconst]
    apply le_of_eq
    field_simp
    norm_num
  -- chain everything
  calc (Nat.choose (n / 2) ((n / 2) / 2) : ℝ) * (2 ^ (n / 2) : ℝ)⁻¹
      ≤ Real.sqrt (2 / (Real.pi * ((n / 2 : ℕ) : ℝ))) := hUB
    _ ≤ (4 / Real.sqrt Real.pi) * (1 / (2 * Real.sqrt n)) := hkey
    _ ≤ (4 / Real.sqrt Real.pi) * ((Nat.choose n (n / 2) : ℝ) * (2 ^ n : ℝ)⁻¹) := by
        apply mul_le_mul_of_nonneg_left hLB
        positivity

end Workspace.ProofLemmas.OffsetWeightFterm
