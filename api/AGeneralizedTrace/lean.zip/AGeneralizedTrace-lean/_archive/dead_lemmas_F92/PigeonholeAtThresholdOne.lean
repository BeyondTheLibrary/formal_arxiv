import Mathlib

set_option maxHeartbeats 800000

open Classical

theorem PigeonholeAtThresholdOne :
    ∀ (η : ℝ), 1 ≤ |η| → |η| ≤ Real.pi →
      ∀ (ξ₂ ξ₃ : ℝ), |ξ₂| < 1/3 → |ξ₃| < 1/3 →
        1/3 ≤ |η - ξ₂ - ξ₃| := by
  intro η hη_lb _ ξ₂ ξ₃ hξ₂ hξ₃
  -- |η - ξ₂ - ξ₃| ≥ |η| - |ξ₂ + ξ₃| ≥ |η| - (|ξ₂| + |ξ₃|) > 1 - 2/3 = 1/3.
  have h1 : |ξ₂ + ξ₃| ≤ |ξ₂| + |ξ₃| := abs_add_le ξ₂ ξ₃
  have h2 : |ξ₂| + |ξ₃| < 1/3 + 1/3 := add_lt_add hξ₂ hξ₃
  have h3 : |ξ₂ + ξ₃| < 2/3 := by linarith
  -- Now |η - (ξ₂ + ξ₃)| ≥ |η| - |ξ₂ + ξ₃|.
  have h4 : |η| - |ξ₂ + ξ₃| ≤ |η - (ξ₂ + ξ₃)| := abs_sub_abs_le_abs_sub η (ξ₂ + ξ₃)
  have h5 : η - ξ₂ - ξ₃ = η - (ξ₂ + ξ₃) := by ring
  rw [h5]
  linarith
