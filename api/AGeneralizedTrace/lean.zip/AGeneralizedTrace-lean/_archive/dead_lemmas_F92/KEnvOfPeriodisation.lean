import Mathlib
import Workspace.ProofLemmas.KFoldConvolutionTheorem
import Workspace.ProofLemmas.CircConvInfra
import Workspace.ProofLemmas.KModEnvBound
import Workspace.ProofLemmas.KModEnvSingleDominated
import Workspace.PriorWork.CircularConvolutionAsPeriodisation

open scoped Real Complex

set_option maxHeartbeats 4000000

/-!
# Periodisation bound for the k-fold circular self-convolution envelope (Lemma 7, G4(b))

This file links the k-fold *circular* self-convolution envelope
`kEnvOf e k` (defined in `KModEnvSingleDominated`) to the *periodised* k-fold
*linear* self-convolution envelope:

  `kEnvOf e k ξ ≤ ∑'_{s ∈ ℤ} Hlin k (ξ + 2π·s)`

where `Hlin` is the k-fold linear self-convolution of the common per-factor
envelope `e` (the "linear `h`-builder"), `Hlin 1 = e`,
`Hlin (B+1) ξ = ∫ η, Hlin B η · e (ξ - η)`.

The base function `e` is assumed non-negative, integrable, and supported on
`[-π, π]` (these are exactly the hypotheses of the paper's "unwrapping"
periodisation step, see `CircularConvolutionAsPeriodisation`).

## Status (2026-06-13): general `k ≥ 1` case CLOSED.

The high-level route is to instantiate the prior-work axiom
`CircularConvolutionAsPeriodisation` with `Hcirc := kEnvOf e` and `Hlin` a linear
k-fold self-convolution builder. The axiom previously quantified its two
recurrence premises over ALL `B : ℕ` (including `B = 0`), which was
*unsatisfiable* for the `kEnvOf` recurrence — at `B = 0` it forced
`Hcirc 1 = circConvR (Hcirc 0) e`, requiring `Hcirc 0` to be a circular Dirac.
That defect has been fixed: the axiom's recurrences now carry a `1 ≤ B` guard, so
they only constrain `B ≥ 1`, exactly matching `kEnvOf`'s recurrence which links
level `B ≥ 1` to `B + 1` (`kEnvOf e (k+2) = circConvR (kEnvOf e (k+1)) e`, i.e.
`B = k+1 ≥ 1`).

This file lands, sorry-free:

1. Summability helpers (`periodised_support_finite`, `periodised_summable_one`)
   for compactly supported non-negative `e`.
2. `kEnvOfPeriodisation_one` : the `k = 1` base case bound.
3. `kEnvOfPeriodisation` : the **general `k ≥ 1`** bound
     `kEnvOf e k ξ ≤ ∑'_s Hlin k (ξ + 2π s)`
   for any linear builder `Hlin` (with `Hlin 1 = e` and the `B ≥ 1` linear
   recurrence), proved by instantiating the fixed axiom. This closes G4(b).
-/

namespace KEnvOfPeriodisation

open KFoldConvolutionTheorem
open CircConvInfra
open KModEnvBound
open KModEnvSingleDominated

/-- For a fixed `ξ`, the integer shifts `s` for which `e (ξ + 2π s) ≠ 0`
are confined to a bounded interval when `e` is supported on `[-π, π]`, hence
finitely many. -/
theorem periodised_support_finite (e : ℝ → ℝ)
    (he_supp : ∀ x, |x| > Real.pi → e x = 0) (ξ : ℝ) :
    (Function.support (fun s : ℤ => e (ξ + 2 * Real.pi * (s : ℝ)))).Finite := by
  have hπ : 0 < Real.pi := Real.pi_pos
  -- support ⊆ { s | |ξ + 2π s| ≤ π } ⊆ a bounded integer interval
  apply Set.Finite.subset
    (Set.finite_Icc (⌈(-Real.pi - ξ) / (2 * Real.pi)⌉) (⌊(Real.pi - ξ) / (2 * Real.pi)⌋))
  intro s hs
  simp only [Function.mem_support, ne_eq] at hs
  -- e(ξ+2πs) ≠ 0 ⇒ |ξ+2πs| ≤ π
  have hle : |ξ + 2 * Real.pi * (s : ℝ)| ≤ Real.pi := by
    by_contra hgt
    rw [not_le] at hgt
    exact hs (he_supp _ hgt)
  rw [abs_le] at hle
  obtain ⟨hlo, hhi⟩ := hle
  -- -π ≤ ξ + 2π s ≤ π  ⟹  (-π-ξ)/(2π) ≤ s ≤ (π-ξ)/(2π)
  have h2π : (0 : ℝ) < 2 * Real.pi := by linarith
  rw [Set.mem_Icc]
  constructor
  · -- ⌈(-π-ξ)/(2π)⌉ ≤ s
    rw [Int.ceil_le]
    rw [div_le_iff₀ h2π]
    nlinarith [hlo]
  · -- s ≤ ⌊(π-ξ)/(2π)⌋
    rw [Int.le_floor]
    rw [le_div_iff₀ h2π]
    nlinarith [hhi]

/-- The periodised series `s ↦ Hlin 1 (ξ + 2π s) = e (ξ + 2π s)` is summable. -/
theorem periodised_summable_one (e : ℝ → ℝ)
    (he_supp : ∀ x, |x| > Real.pi → e x = 0) (ξ : ℝ) :
    Summable (fun s : ℤ => e (ξ + 2 * Real.pi * (s : ℝ))) :=
  summable_of_hasFiniteSupport (periodised_support_finite e he_supp ξ)

/-- **Periodisation bound, base case `k = 1` (Lemma 7, G4(b)).**

For a non-negative `e` supported on `[-π, π]`, with `Hlin` the linear k-fold
self-convolution builder (`Hlin 1 = e`), the `k = 1` circular envelope is
bounded by its own periodisation:

  `kEnvOf e 1 ξ ≤ ∑'_s Hlin 1 (ξ + 2π s)`. -/
theorem kEnvOfPeriodisation_one (e : ℝ → ℝ)
    (he_nn : ∀ x, 0 ≤ e x) (he_supp : ∀ x, |x| > Real.pi → e x = 0)
    (Hlin : ℕ → ℝ → ℝ) (hHlin_one : Hlin 1 = e)
    (ξ : ℝ) :
    kEnvOf e 1 ξ ≤ ∑' s : ℤ, Hlin 1 (ξ + 2 * Real.pi * (s : ℝ)) := by
  rw [hHlin_one, kEnvOf_one]
  -- goal: e ξ ≤ ∑' s, e (ξ + 2π s)
  have hsumm : Summable (fun s : ℤ => e (ξ + 2 * Real.pi * (s : ℝ))) :=
    periodised_summable_one e he_supp ξ
  -- the s = 0 term equals e ξ
  have h0 : e (ξ + 2 * Real.pi * ((0 : ℤ) : ℝ)) = e ξ := by
    norm_num
  calc e ξ = e (ξ + 2 * Real.pi * ((0 : ℤ) : ℝ)) := h0.symm
    _ ≤ ∑' s : ℤ, e (ξ + 2 * Real.pi * (s : ℝ)) := by
        apply hsumm.le_tsum (0 : ℤ)
        intro j _
        exact he_nn _

/-- **Periodisation bound, general `k ≥ 1` (Lemma 7, G4(b)).**

For a non-negative, integrable `e` supported on `[-π, π]`, and any linear k-fold
self-convolution builder `Hlin` (`Hlin 1 = e`, with the `B ≥ 1` linear recurrence
`Hlin (B+1) ξ = ∫ η, Hlin B η · e (ξ - η)`), the `k`-fold *circular* envelope is
bounded by its own *linear* periodisation:

  `kEnvOf e k ξ ≤ ∑'_s Hlin k (ξ + 2π s)`   for every `k ≥ 1`, `|ξ| ≤ π`.

Proved by instantiating the (guard-fixed) prior-work axiom
`CircularConvolutionAsPeriodisation` with `Hcirc := kEnvOf e`. The `kEnvOf`
recurrence `kEnvOf e (k+2) = circConvR (kEnvOf e (k+1)) e` discharges the axiom's
`1 ≤ B` circular-recurrence premise (`B = k+1`), and `kEnvOf_one` discharges the
base. -/
theorem kEnvOfPeriodisation (e : ℝ → ℝ)
    (he_nn : ∀ x, 0 ≤ e x) (he_int : MeasureTheory.Integrable e)
    (he_supp : ∀ x, |x| > Real.pi → e x = 0)
    (Hlin : ℕ → ℝ → ℝ) (hHlin_one : Hlin 1 = e)
    (hHlin_rec : ∀ B : ℕ, 1 ≤ B → ∀ ξ : ℝ,
        Hlin (B + 1) ξ = ∫ η, Hlin B η * e (ξ - η))
    (k : ℕ) (hk : 1 ≤ k) (ξ : ℝ) (hξ : |ξ| ≤ Real.pi) :
    kEnvOf e k ξ ≤ ∑' s : ℤ, Hlin k (ξ + 2 * Real.pi * (s : ℝ)) := by
  -- Circular recurrence premise for `Hcirc := kEnvOf e`, guarded by `1 ≤ B`.
  have hcirc_rec : ∀ B : ℕ, 1 ≤ B → ∀ η : ℝ,
      kEnvOf e (B + 1) η
        = (1 / (2 * Real.pi)) *
            ∫ ζ in (-Real.pi)..Real.pi, kEnvOf e B ζ * e (η - ζ) := by
    intro B hB η
    -- B ≥ 1, so B = k' + 1 for some k'.
    obtain ⟨k', rfl⟩ : ∃ k', B = k' + 1 := ⟨B - 1, by omega⟩
    -- k' + 1 + 1 = k' + 2 ; rewrite via kEnvOf_succ_succ and unfold circConvR.
    rw [show k' + 1 + 1 = k' + 2 from rfl, kEnvOf_succ_succ]
    show CircConvInfra.circConvR (kEnvOf e (k' + 1)) e η = _
    rw [CircConvInfra.circConvR]
  -- Base case for circular builder.
  have hcirc_base : kEnvOf e 1 = e := kEnvOf_one e
  -- Instantiate the (guard-fixed) prior-work axiom.
  exact CircularConvolutionAsPeriodisation e he_nn he_int he_supp
    (kEnvOf e) Hlin hcirc_base hcirc_rec hHlin_one hHlin_rec k hk ξ hξ

end KEnvOfPeriodisation
