import Mathlib
import Workspace.ProofLemmas.HalfXiInRange

open Real

/-- For every real `ξ` with `1/3 ≤ |ξ|` and `|ξ| ≤ π`, `0 ≤ cos (ξ/2)`,
and consequently `|cos (ξ/2)| = cos (ξ/2)`. -/
theorem CosHalfNonnegOnInterval :
    ∀ (ξ : ℝ), (1 : ℝ) / 3 ≤ |ξ| → |ξ| ≤ Real.pi →
      0 ≤ Real.cos (ξ / 2) ∧ |Real.cos (ξ / 2)| = Real.cos (ξ / 2) := by
  intro ξ h1 h2
  obtain ⟨_, _, hlow, hhigh⟩ := HalfXiInRange ξ h1 h2
  have hcos_nn : 0 ≤ Real.cos (ξ / 2) :=
    Real.cos_nonneg_of_neg_pi_div_two_le_of_le hlow hhigh
  refine ⟨hcos_nn, ?_⟩
  exact abs_of_nonneg hcos_nn
