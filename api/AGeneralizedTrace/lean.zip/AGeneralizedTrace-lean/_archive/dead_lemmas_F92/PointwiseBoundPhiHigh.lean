import Mathlib
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.SublemmaFourierThree
import Workspace.ProofLemmas.SublemmaFourierThreeBcThird
import Workspace.ProofLemmas.PigeonholeAtThresholdOne

set_option maxHeartbeats 32000000

open Real

namespace Workspace.ProofLemmas

theorem PointwiseBoundPhiHigh :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
    ∀ (δ : ℝ), 0 < δ → δ ≤ 1 / 2 →
    ∀ (zMinus zPlus : ℕ),
    ∀ (Y₁ Y₂ Y₃ : ℝ → ℝ),
      -- Non-negativity of the bounding functions
      (∀ x, 0 ≤ Y₁ x) →
      (∀ x, 0 ≤ Y₂ x) →
      (∀ x, 0 ≤ Y₃ x) →
      -- Trivial uniform bounds
      (∀ x, Y₁ x ≤ 1) →
      (∀ x, Y₂ x ≤ 1 / (1 - δ)) →
      (∀ x, Y₃ x ≤ 1 / (1 - δ)) →
      -- Decay bounds at threshold 1/3.
      -- Y₁'s decay is required for ALL x with `1/3 ≤ |x|` (no upper bound)
      -- to accommodate `η - ξ₂ - ξ₃` lying outside `[-π, π]` in Case C.
      -- This corresponds to `|T̂₁|` being 2π-periodic (extended naturally).
      (∀ x, (1 / 3 : ℝ) ≤ |x| → Y₁ x ≤ Real.exp (-(n : ℝ) / 150)) →
      (∀ ξ, |ξ| ≤ Real.pi → (1 / 3 : ℝ) ≤ |ξ| →
          Y₂ ξ ≤ Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ)) →
      (∀ ξ, |ξ| ≤ Real.pi → (1 / 3 : ℝ) ≤ |ξ| →
          Y₃ ξ ≤ Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)) →
      let M : ℝ :=
        max (max (Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ))
                 (Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)))
            (Real.exp (-((n : ℝ) / 150)))
      ∀ (η : ℝ), |η| ≤ Real.pi → 1 ≤ |η| →
      ∀ (ξ₂ ξ₃ : ℝ), |ξ₂| ≤ Real.pi → |ξ₃| ≤ Real.pi →
        Y₁ (η - ξ₂ - ξ₃) * Y₂ ξ₂ * Y₃ ξ₃ ≤ M / (1 - δ) ^ 2 := by
  intro n hn hmod δ hδ_pos hδ_le zMinus zPlus
  intro Y₁ Y₂ Y₃ hY₁_nn hY₂_nn hY₃_nn
  intro hY₁_triv hY₂_triv hY₃_triv
  intro hY₁_decay hY₂_decay hY₃_decay
  intro M η hη_pi hη_lb ξ₂ ξ₃ hξ₂_pi hξ₃_pi
  -- δ ≤ 1, so 1 - δ ≥ 0; and 1 - δ ≥ 1/2 > 0
  have hδ_le_one : δ ≤ 1 := by linarith
  have h_1mδ_pos : 0 < 1 - δ := by linarith
  have h_1mδ_nn : 0 ≤ 1 - δ := h_1mδ_pos.le
  have h_1mδ_le_1 : 1 - δ ≤ 1 := by linarith
  have h_1mδ_sq_pos : 0 < (1 - δ) ^ 2 := by positivity
  have h_1mδ_sq_nn : 0 ≤ (1 - δ) ^ 2 := h_1mδ_sq_pos.le
  -- Some shorthand for the three components of the max
  set EM : ℝ := Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ) with hEM_def
  set EP : ℝ := Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ) with hEP_def
  set EN : ℝ := Real.exp (-((n : ℝ) / 150)) with hEN_def
  have hM_def : M = max (max EM EP) EN := rfl
  -- Each component of the max is positive
  have hEM_pos : 0 < EM := div_pos (Real.exp_pos _) h_1mδ_pos
  have hEP_pos : 0 < EP := div_pos (Real.exp_pos _) h_1mδ_pos
  have hEN_pos : 0 < EN := Real.exp_pos _
  have hEM_le_M : EM ≤ M := by
    rw [hM_def]; exact le_max_of_le_left (le_max_left _ _)
  have hEP_le_M : EP ≤ M := by
    rw [hM_def]; exact le_max_of_le_left (le_max_right _ _)
  have hEN_le_M : EN ≤ M := by
    rw [hM_def]; exact le_max_right _ _
  have hM_pos : 0 < M := lt_of_lt_of_le hEM_pos hEM_le_M
  have hM_nn : 0 ≤ M := hM_pos.le
  -- Helper arithmetic: if 0 ≤ E ≤ M then E/(1-δ) ≤ M/(1-δ)².
  -- Proof: cross-multiply, get E*(1-δ) ≤ M.
  -- Since E ≤ M and (1-δ) ≤ 1, E*(1-δ) ≤ E ≤ M. ✓
  have helper : ∀ E : ℝ, 0 ≤ E → E ≤ M → E / (1 - δ) ≤ M / (1 - δ) ^ 2 := by
    intro E hE_nn hE_le
    rw [div_le_div_iff₀ h_1mδ_pos h_1mδ_sq_pos]
    -- Goal: E * (1 - δ)² ≤ M * (1 - δ)
    -- Since 1-δ ≤ 1 and E ≥ 0: E * (1-δ)² ≤ E * (1-δ) ≤ E ≤ M.
    -- And we want E * (1-δ)² ≤ M * (1-δ).
    have h1 : E * (1 - δ) ^ 2 ≤ E * (1 - δ) := by
      have : (1 - δ) * (1 - δ) ≤ 1 * (1 - δ) :=
        mul_le_mul_of_nonneg_right h_1mδ_le_1 h_1mδ_nn
      nlinarith [hE_nn, this]
    have h2 : E * (1 - δ) ≤ M * (1 - δ) :=
      mul_le_mul_of_nonneg_right hE_le h_1mδ_nn
    linarith
  -- Common bounds
  have h_Y₂_triv : Y₂ ξ₂ ≤ 1 / (1 - δ) := hY₂_triv ξ₂
  have h_Y₃_triv : Y₃ ξ₃ ≤ 1 / (1 - δ) := hY₃_triv ξ₃
  have h_Y₁_triv : Y₁ (η - ξ₂ - ξ₃) ≤ 1 := hY₁_triv _
  have h_Y₁nn : 0 ≤ Y₁ (η - ξ₂ - ξ₃) := hY₁_nn _
  have h_Y₂nn : 0 ≤ Y₂ ξ₂ := hY₂_nn _
  have h_Y₃nn : 0 ≤ Y₃ ξ₃ := hY₃_nn _
  -- Case analysis
  by_cases hξ₂_third : (1 / 3 : ℝ) ≤ |ξ₂|
  · -- Case A: |ξ₂| ≥ 1/3.
    have h_Y₂ : Y₂ ξ₂ ≤ EM := hY₂_decay ξ₂ hξ₂_pi hξ₂_third
    -- Y₁ * Y₂ * Y₃ ≤ 1 * EM * (1/(1-δ)) = EM/(1-δ)
    have step1 : Y₁ (η - ξ₂ - ξ₃) * Y₂ ξ₂ ≤ 1 * EM := by
      apply mul_le_mul h_Y₁_triv h_Y₂ h_Y₂nn (by norm_num)
    have h_1EM_nn : 0 ≤ 1 * EM := by positivity
    have step2 : Y₁ (η - ξ₂ - ξ₃) * Y₂ ξ₂ * Y₃ ξ₃ ≤ 1 * EM * (1 / (1 - δ)) := by
      apply mul_le_mul step1 h_Y₃_triv h_Y₃nn h_1EM_nn
    have h_eq : 1 * EM * (1 / (1 - δ)) = EM / (1 - δ) := by ring
    rw [h_eq] at step2
    exact le_trans step2 (helper EM hEM_pos.le hEM_le_M)
  · push_neg at hξ₂_third
    by_cases hξ₃_third : (1 / 3 : ℝ) ≤ |ξ₃|
    · -- Case B: |ξ₂| < 1/3, |ξ₃| ≥ 1/3.
      have h_Y₃ : Y₃ ξ₃ ≤ EP := hY₃_decay ξ₃ hξ₃_pi hξ₃_third
      -- Y₁ * Y₂ * Y₃ ≤ 1 * (1/(1-δ)) * EP = EP/(1-δ)
      have step1 : Y₁ (η - ξ₂ - ξ₃) * Y₂ ξ₂ ≤ 1 * (1 / (1 - δ)) := by
        apply mul_le_mul h_Y₁_triv h_Y₂_triv h_Y₂nn (by norm_num)
      have h_step1_nn : 0 ≤ 1 * (1 / (1 - δ)) := by positivity
      have step2 : Y₁ (η - ξ₂ - ξ₃) * Y₂ ξ₂ * Y₃ ξ₃ ≤ 1 * (1 / (1 - δ)) * EP := by
        apply mul_le_mul step1 h_Y₃ h_Y₃nn h_step1_nn
      have h_eq : 1 * (1 / (1 - δ)) * EP = EP / (1 - δ) := by ring
      rw [h_eq] at step2
      exact le_trans step2 (helper EP hEP_pos.le hEP_le_M)
    · -- Case C: |ξ₂| < 1/3 AND |ξ₃| < 1/3.
      push_neg at hξ₃_third
      have h_pigeon : (1 / 3 : ℝ) ≤ |η - ξ₂ - ξ₃| :=
        PigeonholeAtThresholdOne η hη_lb hη_pi ξ₂ ξ₃ hξ₂_third hξ₃_third
      -- The decay hypothesis on Y₁ gives Y₁(η - ξ₂ - ξ₃) ≤ exp(-(n:ℝ)/150).
      -- But EN = exp(-((n:ℝ)/150)), and -(n:ℝ)/150 = -((n:ℝ)/150). They're equal.
      have h_neg_eq : (-(n : ℝ) / 150 : ℝ) = -((n : ℝ) / 150) := by ring
      have h_Y₁_raw : Y₁ (η - ξ₂ - ξ₃) ≤ Real.exp (-(n : ℝ) / 150) :=
        hY₁_decay _ h_pigeon
      have h_Y₁ : Y₁ (η - ξ₂ - ξ₃) ≤ EN := by
        rw [hEN_def]
        rw [show (-((n : ℝ) / 150)) = (-(n : ℝ) / 150) from by ring]
        exact h_Y₁_raw
      -- Y₁ * Y₂ * Y₃ ≤ EN * (1/(1-δ)) * (1/(1-δ))
      have step1 : Y₁ (η - ξ₂ - ξ₃) * Y₂ ξ₂ ≤ EN * (1 / (1 - δ)) := by
        apply mul_le_mul h_Y₁ h_Y₂_triv h_Y₂nn hEN_pos.le
      have h_step1_nn : 0 ≤ EN * (1 / (1 - δ)) := by positivity
      have step2 : Y₁ (η - ξ₂ - ξ₃) * Y₂ ξ₂ * Y₃ ξ₃
          ≤ EN * (1 / (1 - δ)) * (1 / (1 - δ)) := by
        apply mul_le_mul step1 h_Y₃_triv h_Y₃nn h_step1_nn
      -- EN * (1/(1-δ)) * (1/(1-δ)) = EN/(1-δ)²
      have h_1mδ_ne : (1 - δ) ≠ 0 := ne_of_gt h_1mδ_pos
      have h_eq : EN * (1 / (1 - δ)) * (1 / (1 - δ)) = EN / (1 - δ) ^ 2 := by
        rw [show (1 - δ) ^ 2 = (1 - δ) * (1 - δ) from by ring]
        field_simp
      rw [h_eq] at step2
      have h_div_le : EN / (1 - δ) ^ 2 ≤ M / (1 - δ) ^ 2 :=
        div_le_div_of_nonneg_right hEN_le_M h_1mδ_sq_nn
      exact le_trans step2 h_div_le

end Workspace.ProofLemmas
