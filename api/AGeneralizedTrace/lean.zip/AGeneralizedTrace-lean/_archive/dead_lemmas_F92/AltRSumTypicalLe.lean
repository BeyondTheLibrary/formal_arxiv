-- Paper Lemma 8 (Rivkin–Valiant–Valiant 2024, arXiv:2412.00674v1, §3.1,
-- deletion.tex lines 364-382), specialized to the TYPICAL-z range.
--
-- For typical z (`z ≥ n/16`, real threshold), the per-summand
-- discrete-Fourier-convolution bound on `|altRSum|` (proved in
-- `AltRSumFourierBoundProved` for nonempty ℓ and `AltRSumFourierBoundEmpty` for
-- ℓ = ∅) collapses: the `max{...}` factor is ≤ e^{-√n}/(1-δ) because in the
-- typical-z range
--   * δ·zMinus/20 ≥ (320/√n)·(n/16)/20 = √n  ⇒  e^{-δ·zMinus/20} ≤ e^{-√n}
--   * δ·zPlus/20  ≥ √n  (same)               ⇒  e^{-δ·zPlus/20}  ≤ e^{-√n}
--   * n/150 ≥ √n for n ≥ 22500                ⇒  e^{-n/150}       ≤ e^{-√n}
-- and 1/(1-δ) ≥ 1.  Combining with the two proved per-summand bounds yields
--   |altRSum| ≤ Btyp(n,δ) · e^{-√n}
-- where
--   Btyp(n,δ) = (n+1)(2π-2)(2π)²/(1-δ)³ + 4(2π)²/(1-δ)².
--
-- NOTE ON THE TYPICAL-z HYPOTHESIS.  The paper's "typical z" range is the real
-- threshold z ≥ n/16.  The exact (`max ≤ e^{-√n}/(1-δ)`, no spurious constant)
-- collapse needs the REAL bound `(n:ℝ)/16 ≤ z`, since
--   δ·z/20 ≥ (320/√n)·z/20 = (16/√n)·z ≥ (16/√n)·(n/16) = n/√n = √n
-- holds with equality at z = n/16.  Using the Lean `Nat`-floor `Finset.Ico (n/16) …`
-- instead would lose up to `n%16 ≤ 15`, giving only `δ·z/20 ≥ √n - 16/√n` and
-- forcing an `e^{16/√n}` factor (cf. `HeavyTypicalBound`, which carries `e ≤ 3`),
-- which would NOT close the clean `Btyp` above.  We therefore take the faithful
-- real threshold `(n:ℝ)/16 ≤ z` plus the typical upper bound `z ≤ n/2` (needed to
-- apply the proved per-summand bounds).
import Mathlib
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.AltRSumFourierBoundProved
import Workspace.PriorWork.AltRSumFourierBoundEmpty

set_option maxHeartbeats 4000000

namespace Workspace.ProofLemmas.AltRSumTypicalLe

open scoped BigOperators
open Workspace.Types.AlternatingSumExpression

/-- **Paper Lemma 8, typical-z specialization.**
For `n ≥ 10^12` with `n ≡ 1 (mod 8)`, `δ` with `320/√n ≤ δ ≤ 1/2`,
`c' := 1/(4 e² √(2π))`, `α := c'·√n`, every `ℓ ⊆ Icc 1 (n/2)` with `sameParity ℓ`,
and TYPICAL `z` (real threshold `n/16 ≤ zMinus, zPlus` and `zMinus, zPlus ≤ n/2`):

  |altRSum n δ α zMinus zPlus ℓ| ≤ Btyp(n,δ) · e^{-√n},

with `Btyp(n,δ) = (n+1)(2π-2)(2π)²/(1-δ)³ + 4(2π)²/(1-δ)²`. -/
theorem altRSum_typical_le
    (n : ℕ) (hn : (10 : ℕ) ^ 12 ≤ n) (hn8 : n % 8 = 1)
    (δ : ℝ) (hδlb : 320 / Real.sqrt n ≤ δ) (hδub : δ ≤ 1 / 2)
    (zMinus zPlus : ℕ)
    (hzm_lo : (n : ℝ) / 16 ≤ (zMinus : ℝ)) (hzm_hi : zMinus < n / 2 + 1)
    (hzp_lo : (n : ℝ) / 16 ≤ (zPlus : ℝ)) (hzp_hi : zPlus < n / 2 + 1)
    (ℓ : Finset ℕ)
    (hℓsub : ℓ ⊆ Finset.Icc 1 (n / 2))
    (hℓpar : sameParity ℓ) :
    let α : ℝ := (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n
    |altRSum n δ α zMinus zPlus ℓ|
      ≤ (((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
          + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2)
        * Real.exp (-Real.sqrt (n : ℝ)) := by
  intro α
  -- Basic facts about n, δ, π.
  have hn1 : 1 ≤ n := le_trans (by norm_num) hn
  have hnR_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn1
  have hsqrt_pos : 0 < Real.sqrt n := Real.sqrt_pos.mpr hnR_pos
  have hsqrt_nn : 0 ≤ Real.sqrt n := hsqrt_pos.le
  have h320_pos : (0 : ℝ) < 320 / Real.sqrt (n : ℝ) := by positivity
  have hδ_pos : 0 < δ := lt_of_lt_of_le h320_pos hδlb
  have hδ_nn : 0 ≤ δ := hδ_pos.le
  have hδ1 : δ < 1 := by linarith
  have hD : (0 : ℝ) < 1 - δ := by linarith
  have hD1 : 1 - δ ≤ 1 := by linarith
  have hDge : (1 : ℝ) / 2 ≤ 1 - δ := by linarith
  have hexp_pos : 0 < Real.exp (-Real.sqrt (n : ℝ)) := Real.exp_pos _
  have hexp_nn : 0 ≤ Real.exp (-Real.sqrt (n : ℝ)) := hexp_pos.le
  -- √n ≥ 10^6, hence ≥ 150.
  have hn_ge : (10 : ℝ) ^ 12 ≤ (n : ℝ) := by exact_mod_cast hn
  have hsqrt_ge : (10 : ℝ) ^ 6 ≤ Real.sqrt (n : ℝ) := by
    have h1 : ((10 : ℝ) ^ 6) ^ 2 = (10 : ℝ) ^ 12 := by norm_num
    have h2 : ((10 : ℝ) ^ 6) ^ 2 ≤ (n : ℝ) := by rw [h1]; exact hn_ge
    calc (10 : ℝ) ^ 6 = Real.sqrt (((10 : ℝ) ^ 6) ^ 2) := by
          rw [Real.sqrt_sq (by positivity)]
      _ ≤ Real.sqrt (n : ℝ) := Real.sqrt_le_sqrt h2
  have hzm_lt : zMinus < n / 2 + 1 := hzm_hi
  have hzp_lt : zPlus < n / 2 + 1 := hzp_hi
  -- n / √n = √n.
  have hn_div_sqrt : (n : ℝ) / Real.sqrt (n : ℝ) = Real.sqrt (n : ℝ) := by
    rw [div_eq_iff (ne_of_gt hsqrt_pos)]
    exact (Real.mul_self_sqrt hnR_pos.le).symm
  -- ===== KEY: δ·zMinus/20 ≥ √n, δ·zPlus/20 ≥ √n (real n/16 threshold, exact). =====
  have h_δzM_ge : Real.sqrt (n : ℝ) ≤ δ * (zMinus : ℝ) / 20 := by
    have h1 : 320 / Real.sqrt (n : ℝ) * ((n : ℝ) / 16) ≤ δ * (zMinus : ℝ) := by
      apply mul_le_mul hδlb hzm_lo (by positivity) hδ_pos.le
    have h2 : 320 / Real.sqrt (n : ℝ) * ((n : ℝ) / 16)
        = 20 * ((n : ℝ) / Real.sqrt (n : ℝ)) := by field_simp; ring
    rw [h2, hn_div_sqrt] at h1
    linarith
  have h_δzP_ge : Real.sqrt (n : ℝ) ≤ δ * (zPlus : ℝ) / 20 := by
    have h1 : 320 / Real.sqrt (n : ℝ) * ((n : ℝ) / 16) ≤ δ * (zPlus : ℝ) := by
      apply mul_le_mul hδlb hzp_lo (by positivity) hδ_pos.le
    have h2 : 320 / Real.sqrt (n : ℝ) * ((n : ℝ) / 16)
        = 20 * ((n : ℝ) / Real.sqrt (n : ℝ)) := by field_simp; ring
    rw [h2, hn_div_sqrt] at h1
    linarith
  -- n/150 ≥ √n.
  have h_n150_ge : Real.sqrt (n : ℝ) ≤ (n : ℝ) / 150 := by
    have h_sqrt_ge_150 : (150 : ℝ) ≤ Real.sqrt (n : ℝ) := by
      have : (150 : ℝ) ≤ (10 : ℝ) ^ 6 := by norm_num
      linarith
    have h1 : 150 * Real.sqrt (n : ℝ) ≤ Real.sqrt (n : ℝ) * Real.sqrt (n : ℝ) := by
      nlinarith [h_sqrt_ge_150, hsqrt_pos]
    rw [Real.mul_self_sqrt hnR_pos.le] at h1
    linarith
  -- exp inequalities for each term in the max.
  have h_exp_zM : Real.exp (-(δ * (zMinus : ℝ) / 20)) ≤ Real.exp (-Real.sqrt (n : ℝ)) :=
    Real.exp_le_exp.mpr (by linarith)
  have h_exp_zP : Real.exp (-(δ * (zPlus : ℝ) / 20)) ≤ Real.exp (-Real.sqrt (n : ℝ)) :=
    Real.exp_le_exp.mpr (by linarith)
  have h_exp_n150 : Real.exp (-((n : ℝ) / 150)) ≤ Real.exp (-Real.sqrt (n : ℝ)) :=
    Real.exp_le_exp.mpr (by linarith)
  -- ===== Each term in the max is ≤ e^{-√n}/(1-δ). =====
  have hinv_ge : (1 : ℝ) ≤ 1 / (1 - δ) := by
    rw [le_div_iff₀ hD]; linarith
  have hfrac_zM : Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ)
      ≤ Real.exp (-Real.sqrt (n : ℝ)) / (1 - δ) :=
    div_le_div_of_nonneg_right h_exp_zM hD.le
  have hfrac_zP : Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)
      ≤ Real.exp (-Real.sqrt (n : ℝ)) / (1 - δ) :=
    div_le_div_of_nonneg_right h_exp_zP hD.le
  -- e^{-n/150} ≤ e^{-√n} ≤ e^{-√n}/(1-δ) (since 1/(1-δ) ≥ 1).
  have hfrac_n150 : Real.exp (-((n : ℝ) / 150)) ≤ Real.exp (-Real.sqrt (n : ℝ)) / (1 - δ) := by
    have h1 : Real.exp (-Real.sqrt (n : ℝ)) = Real.exp (-Real.sqrt (n : ℝ)) * 1 := by ring
    calc Real.exp (-((n : ℝ) / 150))
        ≤ Real.exp (-Real.sqrt (n : ℝ)) := h_exp_n150
      _ = Real.exp (-Real.sqrt (n : ℝ)) * 1 := h1
      _ ≤ Real.exp (-Real.sqrt (n : ℝ)) * (1 / (1 - δ)) := by
            apply mul_le_mul_of_nonneg_left hinv_ge hexp_nn
      _ = Real.exp (-Real.sqrt (n : ℝ)) / (1 - δ) := by rw [mul_one_div]
  -- The max collapses to ≤ e^{-√n}/(1-δ).
  have hmax_le : max (max (Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ))
                          (Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)))
                     (Real.exp (-((n : ℝ) / 150)))
                 ≤ Real.exp (-Real.sqrt (n : ℝ)) / (1 - δ) :=
    max_le (max_le hfrac_zM hfrac_zP) hfrac_n150
  have hmax_nn : 0 ≤ max (max (Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ))
                              (Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)))
                         (Real.exp (-((n : ℝ) / 150))) := by
    apply le_max_of_le_right; positivity
  -- Prefactor of the max in the proved bound is nonneg.
  have hpre_nn : 0 ≤ ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 := by
    apply div_nonneg
    · apply mul_nonneg (mul_nonneg (by positivity) (by linarith [Real.pi_gt_three])) (by positivity)
    · positivity
  -- ===== Apply the matching proved per-summand bound (nonempty vs empty ℓ). =====
  -- Both bounds have RHS = Bexp + BFou where
  --   Bexp = (n+1)(2π-2)(2π)²/(1-δ)² · max(...)
  --   BFou = 4(2π)²/(1-δ)² · e^{-√n}.
  set MAX := max (max (Real.exp (-(δ * (zMinus : ℝ) / 20)) / (1 - δ))
                      (Real.exp (-(δ * (zPlus : ℝ) / 20)) / (1 - δ)))
                 (Real.exp (-((n : ℝ) / 150))) with hMAX
  have h_proved : |altRSum n δ α zMinus zPlus ℓ|
      ≤ ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * MAX
        + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * Real.exp (-Real.sqrt (n : ℝ)) := by
    by_cases hne : ℓ.Nonempty
    · -- k ≥ 1 case.
      have := Workspace.ProofLemmas.AltRSumFourierBoundProved.AltRSumFourierBoundProved
        n hn hn8 δ hδ_pos hδub zMinus zPlus hzm_lt hzp_lt ℓ hℓsub hℓpar hne
      simp only at this
      -- `this` has the same RHS shape; α matches definitionally.
      exact this
    · -- k = 0 / empty ℓ case.
      rw [Finset.not_nonempty_iff_eq_empty] at hne
      subst hne
      have := AltRSumFourierBoundEmpty n hn hn8 δ hδ_pos hδub zMinus zPlus hzm_lt hzp_lt
      simp only at this
      -- `AltRSumFourierBoundEmpty` uses `Real.sqrt n`; identical to `Real.sqrt (n:ℝ)`.
      exact this
  -- ===== Collapse the max and rearrange to Btyp · e^{-√n}. =====
  -- Bexp ≤ (n+1)(2π-2)(2π)²/(1-δ)² · e^{-√n}/(1-δ) = (n+1)(2π-2)(2π)²/(1-δ)³ · e^{-√n}.
  have hBexp_le : ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * MAX
      ≤ ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
          * Real.exp (-Real.sqrt (n : ℝ)) := by
    have hstep : ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * MAX
        ≤ ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2
            * (Real.exp (-Real.sqrt (n : ℝ)) / (1 - δ)) := by
      rw [hMAX] at hmax_le ⊢
      exact mul_le_mul_of_nonneg_left hmax_le hpre_nn
    -- rewrite (.../(1-δ)²)·(e/(1-δ)) = (.../(1-δ)³)·e
    have heq : ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2
            * (Real.exp (-Real.sqrt (n : ℝ)) / (1 - δ))
          = ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
            * Real.exp (-Real.sqrt (n : ℝ)) := by
      field_simp
    rw [heq] at hstep
    exact hstep
  -- Assemble.
  calc |altRSum n δ α zMinus zPlus ℓ|
      ≤ ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * MAX
        + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * Real.exp (-Real.sqrt (n : ℝ)) := h_proved
    _ ≤ ((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
            * Real.exp (-Real.sqrt (n : ℝ))
        + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2 * Real.exp (-Real.sqrt (n : ℝ)) := by
          linarith [hBexp_le]
    _ = (((n : ℝ) + 1) * (2 * Real.pi - 2) * (2 * Real.pi) ^ 2 / (1 - δ) ^ 3
          + 4 * (2 * Real.pi) ^ 2 / (1 - δ) ^ 2)
        * Real.exp (-Real.sqrt (n : ℝ)) := by ring

end Workspace.ProofLemmas.AltRSumTypicalLe
