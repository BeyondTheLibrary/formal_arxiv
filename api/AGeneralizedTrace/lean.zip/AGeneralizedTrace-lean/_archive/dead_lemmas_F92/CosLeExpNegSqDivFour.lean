import Mathlib
import Workspace.ProofLemmas.CosQuadraticUpperBound
import Workspace.ProofLemmas.AddOneLeExpNegOnUnitInterval

open Real

/-- For every real number `t` with `0 ≤ t ≤ π/2`, `cos t ≤ exp (-t^2/4)`. -/
theorem CosLeExpNegSqDivFour :
    ∀ (t : ℝ), 0 ≤ t → t ≤ Real.pi / 2 → Real.cos t ≤ Real.exp (-(t ^ 2 / 4)) := by
  intro t ht0 htpi
  -- Step 1: cos t ≤ 1 - t^2/4
  have h1 : Real.cos t ≤ 1 - t ^ 2 / 4 := CosQuadraticUpperBound t ht0 htpi
  -- Step 2: Need 1 - t^2/4 ≤ exp(-t^2/4)
  -- Apply AddOneLeExpNegOnUnitInterval with x = t^2/4
  -- Need 0 ≤ t^2/4 and t^2/4 ≤ 1
  have hx_nn : 0 ≤ t ^ 2 / 4 := by positivity
  have ht_le_2 : t ≤ 2 := by
    have hpi_lt_4 : Real.pi < 4 := by
      have := Real.pi_lt_d2
      linarith
    linarith
  have hx_le_1 : t ^ 2 / 4 ≤ 1 := by
    have ht_sq_le_4 : t ^ 2 ≤ 4 := by
      have h := mul_self_le_mul_self ht0 ht_le_2
      nlinarith [sq_nonneg t]
    linarith
  have h2 : 1 - t ^ 2 / 4 ≤ Real.exp (-(t ^ 2 / 4)) :=
    AddOneLeExpNegOnUnitInterval (t ^ 2 / 4) hx_nn hx_le_1
  linarith
