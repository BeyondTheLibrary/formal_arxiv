import Mathlib
import Workspace.ProofLemmas.CosLeExpNegSqDivFour
import Workspace.ProofLemmas.HalfXiInRange
import Workspace.ProofLemmas.CosHalfNonnegOnInterval
import Workspace.ProofLemmas.PowExpDecay
import Workspace.ProofLemmas.NHalfLowerBound
import Workspace.ProofLemmas.AddOneLeExpNegOnUnitInterval
import Workspace.ProofLemmas.PowMonoBaseLeBaseNonneg

open Real

set_option maxHeartbeats 0

/-- For every natural number `n` with `n ≥ 10^12` and `n % 8 = 1`, and every real
`ξ` with `|ξ| ≤ π` and `1/3 ≤ |ξ|`,
`|cos (ξ/2)| ^ ((n - 1) / 2) ≤ exp (-(n : ℝ) / 150)`,
where `(n - 1) / 2` is natural-number truncated division. -/
theorem ExpExponentReconciliation :
    ∀ (n : ℕ), n ≥ 10 ^ 12 → n % 8 = 1 →
      ∀ (ξ : ℝ), |ξ| ≤ Real.pi → (1 : ℝ) / 3 ≤ |ξ| →
        |Real.cos (ξ / 2)| ^ ((n - 1) / 2) ≤ Real.exp (-(n : ℝ) / 150) := by
  intro n hn _hnmod ξ hξ_pi hξ_third
  -- Basic bounds from n
  have hn_real : (n : ℝ) ≥ (10 : ℝ) ^ 12 := by exact_mod_cast hn
  have h10_12 : ((10 : ℝ)) ^ 12 ≥ 100 := by norm_num
  have hn_100 : (n : ℝ) ≥ 100 := by linarith
  have hn_pos : (0 : ℝ) < (n : ℝ) := by linarith
  -- m := (n - 1) / 2 in ℕ; we need (m : ℝ) ≥ n/2 - 1
  have hn1 : 1 ≤ n := by
    have h10 : (10 : ℕ) ^ 12 ≥ 1 := Nat.one_le_iff_ne_zero.mpr (by positivity)
    omega
  have hkey : 2 * ((n - 1) / 2 : ℕ) ≥ n - 2 := by
    have hmod : (n - 1) % 2 ≤ 1 := by
      have := Nat.mod_lt (n - 1) (by norm_num : (0 : ℕ) < 2)
      omega
    have heq := Nat.div_add_mod (n - 1) 2
    omega
  have hsub_cast : ((n - 2 : ℕ) : ℝ) = (n : ℝ) - 2 := by
    have hge : 2 ≤ n := by
      have : (n : ℝ) ≥ 100 := hn_100
      have : (n : ℕ) ≥ 100 := by exact_mod_cast this
      omega
    have hcc := Nat.sub_add_cancel hge
    have hcast : ((n - 2 + 2 : ℕ) : ℝ) = ((n : ℕ) : ℝ) := by exact_mod_cast hcc
    push_cast at hcast
    linarith
  have hm_lb : (((n - 1) / 2 : ℕ) : ℝ) ≥ (n : ℝ) / 2 - 1 := by
    have h1 : ((2 * ((n - 1) / 2 : ℕ) : ℕ) : ℝ) ≥ ((n - 2 : ℕ) : ℝ) := by exact_mod_cast hkey
    push_cast at h1
    linarith
  -- Get HalfXi info: 1/6 ≤ |ξ/2|, |ξ/2| ≤ π/2, -π/2 ≤ ξ/2 ≤ π/2
  obtain ⟨h_xihalf_lb, h_xihalf_ub, h_xihalf_neg, h_xihalf_pos⟩ :=
    HalfXiInRange ξ hξ_third hξ_pi
  -- 0 ≤ cos(ξ/2) and |cos(ξ/2)| = cos(ξ/2)
  obtain ⟨h_cos_nn, h_abs_cos⟩ := CosHalfNonnegOnInterval ξ hξ_third hξ_pi
  rw [h_abs_cos]
  -- Set m = (n-1)/2 (the natural number)
  set m : ℕ := (n - 1) / 2 with hm_def
  -- m_real = (m : ℝ) ≥ n/2 - 1
  have hm_real_lb : (m : ℝ) ≥ (n : ℝ) / 2 - 1 := hm_lb
  have hm_nn : (0 : ℝ) ≤ (m : ℝ) := by
    have : (n : ℝ) / 2 - 1 ≥ 0 := by linarith
    linarith
  -- Sign-reduce cos(ξ/2): we WLOG assume ξ ≥ 0, then ξ/2 ≥ 0 ≥ -π/2.
  -- Strategy: replace ξ with |ξ| via cos_neg and abs_of_*.
  -- Actually since cos is even, cos(ξ/2) = cos(|ξ|/2). Let t = |ξ|/2.
  -- Then 0 ≤ t (from |ξ| ≥ 0), and t ≤ π/2 (from |ξ| ≤ π).
  -- Furthermore 1/6 ≤ t (from |ξ| ≥ 1/3).
  set t : ℝ := |ξ| / 2 with ht_def
  have ht_nn : 0 ≤ t := by
    have := abs_nonneg ξ
    simp [ht_def]; linarith
  have ht_le_piHalf : t ≤ Real.pi / 2 := by
    simp [ht_def]; linarith
  have ht_lb : (1 : ℝ) / 6 ≤ t := by
    simp [ht_def]; linarith
  have ht_ub : t ≤ Real.pi / 2 := ht_le_piHalf
  -- cos(ξ/2) = cos(t): use cos is even
  have hcos_eq : Real.cos (ξ / 2) = Real.cos t := by
    by_cases hξ_pos : 0 ≤ ξ
    · simp [ht_def, abs_of_nonneg hξ_pos]
    · push_neg at hξ_pos
      have habs : |ξ| = -ξ := abs_of_neg hξ_pos
      rw [show t = |ξ| / 2 from rfl, habs]
      rw [show -ξ / 2 = -(ξ / 2) from by ring]
      rw [Real.cos_neg]
  rw [hcos_eq]
  -- Now case-split on t (which equals |ξ|/2):
  -- Case 1: t ≥ 1/4 (i.e., |ξ| ≥ 1/2). Use CosLeExpNegSqDivFour.
  -- Case 2: t < 1/4 (i.e., |ξ| < 1/2, but ≥ 1/3). Use Real.cos_bound.
  by_cases ht_quarter : (1 : ℝ) / 4 ≤ t
  · -- Case 1: t ≥ 1/4, so t² ≥ 1/16
    -- cos t ≤ exp(-t²/4)
    have hcos_bnd : Real.cos t ≤ Real.exp (-(t ^ 2 / 4)) :=
      CosLeExpNegSqDivFour t ht_nn ht_ub
    -- t² ≥ 1/16
    have ht_sq : t ^ 2 ≥ 1 / 16 := by
      have : t * t ≥ (1/4) * (1/4) := by
        have h1 : (1/4 : ℝ) ≤ t := ht_quarter
        have h2 : (0 : ℝ) ≤ 1/4 := by norm_num
        nlinarith
      have heq : t ^ 2 = t * t := by ring
      rw [heq]; linarith
    -- cos t ≥ 0
    have hcos_t_nn : 0 ≤ Real.cos t := by
      rw [← hcos_eq]; exact h_cos_nn
    -- (cos t)^m ≤ (exp(-t²/4))^m
    have hpow1 : (Real.cos t) ^ m ≤ (Real.exp (-(t ^ 2 / 4))) ^ m :=
      PowMonoBaseLeBaseNonneg _ _ hcos_t_nn hcos_bnd m
    -- (exp(-c))^m = exp(-c * m)
    have hpow2 : (Real.exp (-(t ^ 2 / 4))) ^ m = Real.exp (-(t ^ 2 / 4) * (m : ℝ)) :=
      PowExpDecay (t ^ 2 / 4) m
    rw [hpow2] at hpow1
    -- Goal: cos(t)^m ≤ exp(-n/150). We have cos(t)^m ≤ exp(-t²/4 * m).
    -- Need: -t²/4 * m ≤ -n/150, i.e., t²/4 * m ≥ n/150
    have hexp_decay : (t ^ 2 / 4) * (m : ℝ) ≥ (n : ℝ) / 150 := by
      have h_tsq_4 : t ^ 2 / 4 ≥ 1/64 := by linarith
      have hprod : t ^ 2 / 4 * (m : ℝ) ≥ (1/64 : ℝ) * ((n : ℝ)/2 - 1) := by
        nlinarith
      have hbound : (1/64 : ℝ) * ((n : ℝ)/2 - 1) ≥ (n : ℝ)/150 := by
        nlinarith
      linarith
    have hexp_le : Real.exp (-(t ^ 2 / 4) * (m : ℝ)) ≤ Real.exp (-(n : ℝ) / 150) := by
      apply Real.exp_le_exp.mpr
      have : -(t ^ 2 / 4) * (m : ℝ) = -((t ^ 2 / 4) * (m : ℝ)) := by ring
      rw [this]
      linarith
    linarith
  · -- Case 2: t < 1/4 (so |ξ| < 1/2). Then t ∈ [1/6, 1/4), so |t| ≤ 1.
    push_neg at ht_quarter
    have ht_le_quarter : t ≤ 1/4 := le_of_lt ht_quarter
    have ht_le_one : |t| ≤ 1 := by
      rw [abs_of_nonneg ht_nn]
      linarith
    -- Use Real.cos_bound: |cos t - (1 - t²/2)| ≤ |t|⁴ * 5/96
    have hbound := Real.cos_bound ht_le_one
    -- cos t ≤ 1 - t²/2 + t⁴ * 5/96
    have habs_t : |t| = t := abs_of_nonneg ht_nn
    have habs_t_sq : |t|^2 = t^2 := by rw [sq_abs]
    have habs_t_quad : |t|^4 = t^4 := by
      have : |t|^4 = (|t|^2)^2 := by ring
      rw [this, habs_t_sq]; ring
    have hcos_upper : Real.cos t ≤ 1 - t^2/2 + t^4 * (5/96) := by
      have := abs_le.mp hbound
      rw [habs_t_quad] at this
      linarith [this.2]
    -- Now: t⁴ = (t²)² ≤ t² * (1/16) since t² ≤ 1/16 (because t ≤ 1/4)
    have ht_sq_le : t^2 ≤ 1/16 := by
      have h1 : t * t ≤ (1/4) * (1/4) := by
        have h1a : t ≤ 1/4 := ht_le_quarter
        have h1b : 0 ≤ t := ht_nn
        nlinarith
      have heq : t^2 = t * t := by ring
      rw [heq]; linarith
    have ht_sq_nn : 0 ≤ t^2 := sq_nonneg t
    have ht_quad_le : t^4 ≤ t^2 * (1/16) := by
      have heq : t^4 = t^2 * t^2 := by ring
      rw [heq]
      nlinarith
    -- cos t ≤ 1 - t²/2 + t² * (1/16) * (5/96) = 1 - t² * (763/1536)
    have hcos_tighter : Real.cos t ≤ 1 - t^2 * (763 / 1536) := by
      have h1 : t^4 * (5/96) ≤ t^2 * (5/1536) := by
        have hh : t^2 * (1/16) * (5/96) = t^2 * (5/1536) := by ring
        nlinarith
      have h2 : 1 - t^2 / 2 + t^4 * (5/96) ≤ 1 - t^2 * (763/1536) := by
        have heq : (1 : ℝ) - t^2/2 + t^2 * (5/1536) = 1 - t^2 * (763/1536) := by ring
        linarith
      linarith
    -- Now use 1 - x ≤ exp(-x) where x = t² * 763/1536
    set y : ℝ := t^2 * (763/1536) with hy_def
    have hy_nn : 0 ≤ y := by positivity
    have hy_le_one : y ≤ 1 := by
      have hy_ub : t^2 * (763/1536) ≤ (1/16) * (763/1536) := by nlinarith
      have : (1/16 : ℝ) * (763/1536) ≤ 1 := by norm_num
      linarith
    have hone_sub_y : 1 - y ≤ Real.exp (-y) := AddOneLeExpNegOnUnitInterval y hy_nn hy_le_one
    -- cos t ≤ 1 - y ≤ exp(-y)
    have hcos_exp_bnd : Real.cos t ≤ Real.exp (-y) := by linarith
    -- cos t ≥ 0 (already have)
    have hcos_t_nn : 0 ≤ Real.cos t := by
      rw [← hcos_eq]; exact h_cos_nn
    -- (cos t)^m ≤ (exp(-y))^m = exp(-y * m)
    have hpow1 : (Real.cos t) ^ m ≤ (Real.exp (-y)) ^ m :=
      PowMonoBaseLeBaseNonneg _ _ hcos_t_nn hcos_exp_bnd m
    have hpow2 : (Real.exp (-y)) ^ m = Real.exp (-y * (m : ℝ)) :=
      PowExpDecay y m
    rw [hpow2] at hpow1
    -- Need: y * m ≥ n/150, i.e., t² * 763/1536 * m ≥ n/150
    -- t² ≥ 1/36 (from t ≥ 1/6)
    have ht_sq_ge : t^2 ≥ 1/36 := by
      have h1 : (1/6 : ℝ) ≤ t := ht_lb
      have h2 : t * t ≥ (1/6) * (1/6) := by
        nlinarith
      have heq : t^2 = t * t := by ring
      rw [heq]; linarith
    -- y * m ≥ n/150
    have hy_m_lb : y * (m : ℝ) ≥ (n : ℝ)/150 := by
      -- y = t² * 763/1536 ≥ (1/36) * 763/1536
      have hy_lb : y ≥ (1/36) * (763/1536) := by
        have : (763 : ℝ) / 1536 > 0 := by norm_num
        nlinarith
      -- y * m ≥ (1/36) * (763/1536) * (n/2 - 1)
      have hprod : y * (m : ℝ) ≥ ((1/36) * (763/1536)) * ((n : ℝ)/2 - 1) := by
        nlinarith
      -- (1/36) * (763/1536) * (n/2 - 1) ≥ n/150
      have hbound : ((1/36 : ℝ)) * (763/1536) * ((n : ℝ)/2 - 1) ≥ (n : ℝ)/150 := by
        nlinarith
      linarith
    have hexp_le : Real.exp (-y * (m : ℝ)) ≤ Real.exp (-(n : ℝ) / 150) := by
      apply Real.exp_le_exp.mpr
      have : -y * (m : ℝ) = -(y * (m : ℝ)) := by ring
      rw [this]
      linarith
    linarith
