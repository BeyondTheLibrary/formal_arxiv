-- Cited from: this is NOT external prior work. It is the paper's OWN log-concavity
-- step in the proof of Lemma 7 (arXiv:2412.00674v1, lines 357-359): "the
-- Prékopa-Leindler inequality says that convolutions of log-concave functions are
-- log-concave; thus since cos(ξ/2) is log-concave in the domain [-π,π], we have that
-- h is the sum of log-concave functions, each symmetric about 0. Thus h is
-- decreasing away from 0." The ONLY genuine prior-work input is Prékopa-Leindler
-- (kept separately as the axiom `PrekopaLogConcave_convolution`); everything else
-- here is the paper's own argument and should ultimately be PROVED from that axiom.
-- Paper label: Lemma 7 Prékopa log-concavity / "h decreasing away from 0"
-- NL statement: Let n ≥ 1, α > 0, and let H : ℝ → ℝ be non-negative, integrable,
-- supported on [-π, π], with α · ∫H < 1 (the t=0 instance of the paper's
-- geometric-convergence condition α·g(t)<1, where g(0)=∫H; equivalently α·‖H‖₁<1
-- since H ≥ 0 — this is what makes the L¹ geometric series for Φ converge). Let
-- Hconv be the iterated linear self-convolution of H (Hconv 1 = H,
-- Hconv (b+1) = Hconv b * H). Define Φ(η) := Σ_{b≥1} α^b · Hconv b (η). Then Φ is
-- non-negative, integrable, and log-concave; and if H is even then Φ is even and
-- monotone non-increasing on [0,∞) ("decreasing away from 0").
import Mathlib

/--
**Lemma 7 Prékopa log-concavity step: the geometric series of binomial-modulus
self-convolutions is log-concave, even, and decreasing away from 0.**

Let `n ≥ 1`, let `H : ℝ → ℝ` be the support-restricted binomial Fourier-modulus
on `[-π, π]` (non-negative, integrable, supported on `[-π, π]`), and let `α > 0`
with `α · ∫H < 1`. Let `Hconv : ℕ → ℝ → ℝ` be the sequence of `b`-fold linear
self-convolutions of `H` (so `Hconv 1 = H` and
`Hconv (b+1) η = ∫ y, Hconv b y · H (η - y)`). Define
  `Φ(η) := ∑_{b ≥ 1} α^b · Hconv b (η)`.
Then `Φ` is non-negative, integrable, and log-concave on `ℝ`; and (assuming `H`
is even) `Φ` is even and monotone non-increasing on `[0, ∞)`.

This is exactly the paper's own argument (arXiv:2412.00674v1, lines 357-359):
by Prékopa-Leindler (`PrekopaLogConcave_convolution`) each `Hconv b` is
log-concave; a log-concave even function is symmetric-unimodal (mode at 0); the
sum of symmetric-unimodal functions is symmetric and non-increasing away from 0;
and the L¹ geometric series converges because `α · ∫H < 1`.

CONVERGENCE HYPOTHESIS (faithfulness, 2026-06-13): `α · ∫H < 1` is the **t = 0
instance** of the paper's geometric-convergence condition `α · g(t) < 1`
(line: "Provided α g(t)<1, this geometric series sums"), where
`g(t) = ∫ H(ξ) e^{tξ} dξ` so `g(0) = ∫H`. Since `H ≥ 0` this equals `α·‖H‖₁<1`.
It is the exact condition needed for `Φ` to be a well-defined L¹ function, and it
is what the sole consumer (`SublemmaFourierKway`) establishes (there
`α·∫H = 1/(2e²) < 1`). It is NOT an invented stand-in for `α ≤ √n/(4e²√(2π))`;
the latter is the *separate* quantitative MGF calibration the consumer derives on
its own, not a hypothesis of this lemma.

NOTE (faithfulness, 2026-06-13): the provenance has been corrected — this is the
paper's OWN Lemma-7 step, not external prior work. It SHOULD be proved from
`PrekopaLogConcave_convolution` (the genuine prior-work axiom): each `Hconv b`
log-concave by induction, log-concave+even ⇒ unimodal-at-0, sum of unimodal ⇒
non-increasing away from 0. That derivation (the log-concave⇒unimodal real-analysis
lemma plus the tsum-of-monotone step) is multi-lemma infrastructure not yet in the
workspace, so the statement is retained as an `axiom` with this corrected, faithful
form. Do NOT revert the provenance/convergence-doc to the prior "prior-work /
α·‖H‖₁<1 invented condition" framing.
-/
axiom BinomialPmfFourierLogConcave :
    ∀ (n : ℕ), 1 ≤ n →
      ∀ (α : ℝ), 0 < α →
        ∀ (H : ℝ → ℝ),
          (∀ x, 0 ≤ H x) →
          MeasureTheory.Integrable H →
          (∀ x, |x| > Real.pi → H x = 0) →
          -- Geometric-series convergence condition: α · ‖H‖₁ < 1.
          α * (∫ x, H x) < 1 →
          ∀ (Hconv : ℕ → ℝ → ℝ),
            (Hconv 1 = H) →
            -- The recurrence is for b ≥ 1: Hconv (b+1) is the linear convolution of
            -- Hconv b with H. (For b = 0 this would force Hconv 0 to be a Dirac
            -- delta, which is not a function; so we start the recurrence at b ≥ 1.)
            (∀ b : ℕ, 1 ≤ b → ∀ η : ℝ,
                Hconv (b + 1) η = ∫ y, Hconv b y * H (η - y)) →
            -- Each iterated convolution is non-negative and integrable.
            (∀ b : ℕ, 1 ≤ b → ∀ η, 0 ≤ Hconv b η) →
            (∀ b : ℕ, 1 ≤ b → MeasureTheory.Integrable (Hconv b)) →
            ∀ (Φ : ℝ → ℝ),
              (∀ η, Φ η = ∑' b : ℕ, α ^ (b + 1) * Hconv (b + 1) η) →
              -- Conclusion (non-negativity, integrability, log-concavity, evenness
              -- assuming H is even).
              (∀ η, 0 ≤ Φ η) ∧
              MeasureTheory.Integrable Φ ∧
              (∀ x y t, 0 ≤ t → t ≤ 1 →
                Φ x ^ t * Φ y ^ (1 - t) ≤ Φ (t * x + (1 - t) * y)) ∧
              -- Antitone on [0, ∞) (assuming H is even — the standard log-concave
              -- + even ⇒ unimodal-at-0 argument).
              ((∀ x, H (-x) = H x) →
                (∀ x, Φ (-x) = Φ x) ∧
                (∀ x y, 0 ≤ x → x ≤ y → Φ y ≤ Φ x))
