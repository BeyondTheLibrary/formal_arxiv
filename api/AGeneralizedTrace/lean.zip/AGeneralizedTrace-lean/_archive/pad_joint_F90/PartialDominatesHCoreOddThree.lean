import Mathlib
import Workspace.Types.BinVec
import Workspace.Types.Trace
import Workspace.Types.DelProb
import Workspace.Types.ProbVec
import Workspace.Types.CoinFlipDist
import Workspace.Types.TraceDist
import Workspace.Types.TVDistance
import Workspace.Types.PartialDeletionProcess
import Workspace.ProofLemmas.RestrictSegmentFactorization
import Workspace.ProofLemmas.TraceDeletionKernel
import Workspace.ProofLemmas.PartialDominatesAssembly
import Workspace.ProofLemmas.PartialDominatesConvolution
import Workspace.ProofLemmas.PartialDominatesCutIndependence
import Workspace.ProofLemmas.PartialDominatesOffsetCast
import Workspace.ProofLemmas.OffsetWeightSumOne
import Workspace.ProofLemmas.DeletionLengthMarginal
import Workspace.ProofLemmas.OddNConstructionArith

/-!
# `n ≡ 3 (mod 4)` H-core foundations (GREEN-SAFE partial progress)

The committed `PartialDominatesHCore.partial_dominates_traceDist_of_gate`
relies on the **gate** `2 * (n / 4) = n / 2`, which FAILS for `n ≡ 3 (mod 4)`
(there `n / 2 = 2 * (n / 4) + 1`, e.g. `n = 7`: `2*(7/4) = 2 ≠ 3 = 7/2`).

This NEW file re-derives, **for the `n ≡ 3 (mod 4)` case**, the foundational
tiling / segment / middle-window lemmas that `per_r_identity` and
`hcore_proof` are built on, with the **corrected off-by-one segment lengths**.

## The exact off-by-one (quantified)

`per_r_identity` cuts the whole string into three segments
`(K₁, n/2, K₃)` with
`K₁ = (n/4 + r).toNat`,  `K₃ = n - (3*(n/4) + r).toNat`,
and proves the tiling `K₁ + n/2 + K₃ = n` via `hkey : K₁ + n/2 = (3*(n/4)+r).toNat`,
which needs `2*(n/4) = n/2` (the gate).

For `n ≡ 3 (mod 4)` we have `2*(n/4) = n/2 - 1`, so the **true gap** between the
prefix end (`n/4 + r`) and the suffix start (`3*(n/4) + r`) is only
`2*(n/4) = n/2 - 1`, NOT `n/2`.  Hence the correct middle width for the
**string-tiling** is `Kmid := n/2 - 1 = 2*(n/4)`, and the corrected tiling is

      K₁ + (n/2 - 1) + K₃ = n.              (`tiling_oddThree`)

The `middleIndicator`/`midWindow` machinery, by contrast, pins **`n/2`**
consecutive bits (the paper's `n/2`-bit middle output), spanning positions
`n/4 + r .. n/4 + r + (n/2 - 1) = 3*(n/4) + r`.  For `n ≡ 3 (mod 4)` that last
middle position `3*(n/4) + r` **coincides with the suffix-mask boundary**
`isSuffixMask … (i ≥ 3*(n/4)+r)` — i.e. the last middle bit and the first
suffix-mask index overlap by exactly one slot.  This overlap is precisely why
the gated `per_r_identity` cannot be reused verbatim; the suffix start must be
shifted to `3*(n/4) + r + 1` for the three string-segments to be disjoint.

All lemmas here are imported by nothing else and edit no existing file, so the
build stays green.  Lemmas that need the full convolution machinery to close
(which cannot be replicated green-safe without re-running the entire
`whole_string_eq_segConv` chain at the new segment lengths) are stated with a
documented `sorry` and an exact account of what is blocking; everything else is
`sorry`-free.
-/

namespace PartialDominatesHCoreOddThree

open Workspace.Types.BinVec
open Workspace.Types.Trace
open Workspace.Types.DelProb
open Workspace.Types.ProbVec
open Workspace.Types.CoinFlipDist
open Workspace.Types.TraceDist
open Workspace.Types.PartialDeletionProcess
open Workspace.Types.DeletionChannel
open RestrictSegmentFactorization
open TraceDeletionKernel
open PartialDominatesAssembly
open PartialDominatesConvolution
open PartialDominatesCutIndependence
open PartialDominatesOffsetCast
open OffsetWeightSumOne
open Workspace.ProofLemmas.OddNConstructionArith

open scoped Classical

/-! ## 1. The corrected tiling identity for `n ≡ 3 (mod 4)`

We work on the offset support `0 ≤ r + n/4 ≤ n/2`, where (for odd `n`) the
prefix start `n/4 + r` and suffix start `3*(n/4) + r` are both in `[0, n]`
(`OddNConstructionArith.suffix_start_in_range_odd`).

Let
* `K₁ := (n/4 + r).toNat`        (prefix length)
* `Kmid := 2 * (n / 4)`          (TRUE middle gap = `n/2 - 1` for `n ≡ 3 mod 4`)
* `K₃ := n - (3*(n/4) + r).toNat` (suffix length)

The corrected tiling is `K₁ + Kmid + K₃ = n`.  This holds for ALL odd `n`
on the offset support; for `n ≡ 1 (mod 4)` it coincides with the gated
`K₁ + n/2 + K₃ = n` (since there `Kmid = n/2`), and for `n ≡ 3 (mod 4)` it is
the corrected `K₁ + (n/2 - 1) + K₃ = n`. -/

/-- **Corrected string-tiling identity** (gate-free, all odd `n`).  The three
*disjoint* string segments — prefix `[0, n/4+r)`, true-middle
`[n/4+r, 3*(n/4)+r)`, suffix `[3*(n/4)+r, n)` — have lengths summing to `n`.
The true-middle gap is `2*(n/4)`, which is `n/2` only when the gate holds and
`n/2 - 1` for `n ≡ 3 (mod 4)`. -/
theorem tiling_oddThree {n : ℕ} (hodd : n % 2 = 1) (r : ℤ)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    (((n / 4 : ℕ) : ℤ) + r).toNat + 2 * (n / 4)
        + (n - (((3 * (n / 4) : ℕ) : ℤ) + r).toNat) = n := by
  -- Both segment starts are in range.
  have hpre0 : 0 ≤ ((n / 4 : ℕ) : ℤ) + r := by linarith [hr0]
  have hsuf0 : 0 ≤ ((3 * (n / 4) : ℕ) : ℤ) + r := by
    have : ((n / 4 : ℕ) : ℤ) ≤ ((3 * (n / 4) : ℕ) : ℤ) := by push_cast; omega
    linarith [hpre0]
  have hsufn : ((3 * (n / 4) : ℕ) : ℤ) + r ≤ (n : ℤ) :=
    suffix_start_in_range_odd n hodd r hr0 hr2
  -- toNat values.
  have hK₁Z : ((((n / 4 : ℕ) : ℤ) + r).toNat : ℤ) = ((n / 4 : ℕ) : ℤ) + r :=
    Int.toNat_of_nonneg hpre0
  have hK₃Z : ((((3 * (n / 4) : ℕ) : ℤ) + r).toNat : ℤ) = ((3 * (n / 4) : ℕ) : ℤ) + r :=
    Int.toNat_of_nonneg hsuf0
  have hsuf_le : (((3 * (n / 4) : ℕ) : ℤ) + r).toNat ≤ n := by
    have := Int.toNat_le.mpr hsufn; simpa using this
  -- The true-middle gap is exactly the difference of the two toNat starts.
  have hgap : (((3 * (n / 4) : ℕ) : ℤ) + r).toNat
      = (((n / 4 : ℕ) : ℤ) + r).toNat + 2 * (n / 4) := by
    have hZ : ((((3 * (n / 4) : ℕ) : ℤ) + r).toNat : ℤ)
        = ((((n / 4 : ℕ) : ℤ) + r).toNat : ℤ) + (2 * (n / 4) : ℕ) := by
      rw [hK₁Z, hK₃Z]; push_cast; ring
    exact_mod_cast hZ
  omega

/-- For `n ≡ 3 (mod 4)`, the true middle gap `2*(n/4)` is one short of the
`n/2`-wide `midWindow`/`middleIndicator` output: `2*(n/4) + 1 = n/2`. -/
theorem trueMiddle_succ_eq_half_of_mod4_eq_three {n : ℕ} (h : n % 4 = 3) :
    2 * (n / 4) + 1 = n / 2 :=
  (gate_off_by_one_of_mod4_eq_three n h).symm

/-- **The overlap pin (`n ≡ 3 (mod 4)`).**  The `n/2`-wide middle window's LAST
position (`n/4 + r + (n/2 - 1)`) equals the suffix-mask boundary `3*(n/4) + r`.
So the middle output and the suffix-mask range share exactly index
`3*(n/4) + r`; the gated `per_r_identity` (which assumes the middle ends one
step earlier, at `3*(n/4)+r - 1`) double-counts this slot.  This is the precise
arithmetic location of the obstruction. -/
theorem middle_suffix_overlap_of_mod4_eq_three {n : ℕ} (h : n % 4 = 3) (r : ℤ) :
    ((n / 4 : ℕ) : ℤ) + r + ((n / 2 : ℕ) - 1 : ℕ) = ((3 * (n / 4) : ℕ) : ℤ) + r := by
  have hhalf : n / 2 = 2 * (n / 4) + 1 := gate_off_by_one_of_mod4_eq_three n h
  have h1 : ((n / 2 : ℕ) - 1 : ℕ) = 2 * (n / 4) := by omega
  rw [h1]
  have h3 : (3 * (n / 4) : ℕ) = (n / 4) + 2 * (n / 4) := by ring
  rw [h3]; push_cast; ring

/-! ## 2. Gate-free `midWindow` and the corrected `middleIndicator` membership

The `middleIndicator`/`midWindow` machinery is `n/2`-bit-wide REGARDLESS of the
gate (the middle output is `n/2` bits per the type).  The committed
`PartialDominatesHCore.midWindow` and `middleIndicator_eq_point` carry a spurious
`hgate` hypothesis that is only used to *name* the window — the well-formedness
of the `Fin n` index `(n/4 + r + j)` needs only `n/2 + n/2 ≤ n` (gate-free,
holds for all `n`).  We re-derive a **gate-free** version usable in the
`n ≡ 3 (mod 4)` case. -/

/-- Gate-free middle window: the `BinVec (n/2)` whose `j`-th bit is `b.bit` at
integer position `n/4 + r + j`.  Identical to
`PartialDominatesHCore.midWindow` but WITHOUT the `hgate` argument (the
well-formedness proof never needed it). -/
noncomputable def midWindow' {n : ℕ} (b : BinVec n) (r : ℤ)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    BinVec (n / 2) :=
  ⟨fun j => b.bit ⟨(((n / 4 : ℕ) : ℤ) + r + (j : ℕ)).toNat, by
    have hj : (j : ℕ) < n / 2 := j.isLt
    have hjn : ((j : ℕ) : ℤ) < (n / 2 : ℕ) := by exact_mod_cast hj
    have hlt : ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) < (n : ℤ) := by
      have h1 : ((n / 4 : ℕ) : ℤ) + r ≤ (n / 2 : ℕ) := by
        have := hr2; linarith
      have hn2 : (n / 2 : ℕ) + (n / 2 : ℕ) ≤ (n : ℕ) := by omega
      have : (n / 2 : ℕ) + ((j : ℕ) : ℤ) < (n : ℤ) := by
        have : ((n / 2 : ℕ) : ℤ) + ((n / 2 : ℕ) : ℤ) ≤ (n : ℤ) := by exact_mod_cast hn2
        linarith
      linarith
    have hge : 0 ≤ ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) := by
      have : (0 : ℤ) ≤ ((j : ℕ) : ℤ) := by positivity
      have hr0' : 0 ≤ ((n / 4 : ℕ) : ℤ) + r := by linarith [hr0]
      linarith
    have h0 : ((((n / 4 : ℕ) : ℤ) + r + (j : ℕ)).toNat : ℤ)
        = ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) := Int.toNat_of_nonneg hge
    have : ((((n / 4 : ℕ) : ℤ) + r + (j : ℕ)).toNat : ℤ) < (n : ℤ) := by rw [h0]; exact hlt
    exact_mod_cast this⟩⟩

/-- **Gate-free `middleIndicator` point-membership.**  For a valid offset `r`
(`0 ≤ r + n/4 ≤ n/2`), the middle indicator is the point indicator at
`midWindow' n b r`.  Holds for ALL odd `n` (in particular `n ≡ 3 (mod 4)`),
since the `n/2`-bit middle output and its in-`[0,n)` indices never depended on
the gate.  This is the off-by-one-case replacement for
`PartialDominatesHCore.middleIndicator_eq_point`. -/
lemma middleIndicator_eq_point' {n : ℕ} (b : BinVec n) (m : BinVec (n / 2)) (r : ℤ)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    middleIndicator n b m r
      = if m = midWindow' b r hr0 hr2 then (1 : ENNReal) else 0 := by
  unfold middleIndicator
  have hrange : ∀ j : Fin (n / 2),
      0 ≤ ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) ∧
      ((n / 4 : ℕ) : ℤ) + r + (j : ℕ) < (n : ℤ) := by
    intro j
    constructor
    · have : (0 : ℤ) ≤ ((j : ℕ) : ℤ) := by positivity
      have hr0' : 0 ≤ ((n / 4 : ℕ) : ℤ) + r := by linarith [hr0]
      linarith
    · have hj : (j : ℕ) < n / 2 := j.isLt
      have hjn : ((j : ℕ) : ℤ) < (n / 2 : ℕ) := by exact_mod_cast hj
      have h1 : ((n / 4 : ℕ) : ℤ) + r ≤ (n / 2 : ℕ) := by linarith [hr2]
      have hn2 : (n / 2 : ℕ) + (n / 2 : ℕ) ≤ (n : ℕ) := by omega
      have : ((n / 2 : ℕ) : ℤ) + ((n / 2 : ℕ) : ℤ) ≤ (n : ℤ) := by exact_mod_cast hn2
      linarith
  rw [dif_pos hrange]
  by_cases hm : m = midWindow' b r hr0 hr2
  · rw [if_pos hm]
    rw [if_pos]
    intro j
    rw [hm]
    rfl
  · rw [if_neg hm]
    rw [if_neg]
    intro hbit
    apply hm
    apply congrArg BinVec.mk
    funext j
    rw [← hbit j]

/-! ## 3. Segment-sum bookkeeping (prefix / suffix) for `n ≡ 3 (mod 4)`

The prefix/suffix `…Weight = segSum` bridges
`PartialDominatesOffsetCast.prefixWeight_eq_segSum` /
`suffixWeight_eq_segSum` are themselves **gate-free** — they need only the
integer range bounds `0 ≤ n/4+r ≤ n` (prefix) and `0 ≤ 3*(n/4)+r ≤ n`
(suffix).  All four bounds hold for `n ≡ 3 (mod 4)` on the offset support
(`OddNConstructionArith.suffix_start_in_range_odd`).  We package the in-range
side-conditions so the off-by-one H-core re-derivation can invoke the bridges
verbatim. -/

/-- Prefix in-range bounds on the offset support (all odd `n`, gate-free):
`0 ≤ n/4 + r` and `n/4 + r ≤ n`.  Feeds `prefixWeight_eq_segSum`. -/
theorem prefix_range_oddThree {n : ℕ} (r : ℤ)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    0 ≤ ((n / 4 : ℕ) : ℤ) + r ∧ ((n / 4 : ℕ) : ℤ) + r ≤ (n : ℤ) := by
  refine ⟨by linarith [hr0], ?_⟩
  have h1 : ((n / 4 : ℕ) : ℤ) + r ≤ (n / 2 : ℕ) := by linarith [hr2]
  have h2 : ((n / 2 : ℕ) : ℤ) ≤ (n : ℤ) := by exact_mod_cast Nat.div_le_self n 2
  linarith

/-- Suffix in-range bounds on the offset support for `n ≡ 3 (mod 4)`:
`0 ≤ 3*(n/4) + r` and `3*(n/4) + r ≤ n` (in fact strictly `< n`).  Feeds
`suffixWeight_eq_segSum`. -/
theorem suffix_range_oddThree {n : ℕ} (h : n % 4 = 3) (r : ℤ)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    0 ≤ ((3 * (n / 4) : ℕ) : ℤ) + r ∧ ((3 * (n / 4) : ℕ) : ℤ) + r ≤ (n : ℤ) := by
  have hpre0 : 0 ≤ ((n / 4 : ℕ) : ℤ) + r := by linarith [hr0]
  refine ⟨?_, ?_⟩
  · have : ((n / 4 : ℕ) : ℤ) ≤ ((3 * (n / 4) : ℕ) : ℤ) := by push_cast; omega
    linarith [hpre0]
  · have hodd : n % 2 = 1 := by omega
    exact suffix_start_in_range_odd n hodd r hr0 hr2

/-- **Prefix segment-sum bridge for `n ≡ 3 (mod 4)`.**  On the offset support,
the prefix weight equals the prefix point-segment-sum of the length-`(n/4+r)`
segment of `b`.  This is exactly `prefixWeight_eq_segSum` instantiated with the
gate-free prefix range bounds; it carries over unchanged to the off-by-one case
because the PREFIX never touched the gate. -/
theorem prefixWeight_eq_segSum_oddThree {n : ℕ} (b : BinVec n) (δ : DelProb) (r : ℤ)
    (t₁ : Trace n)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    prefixWeight n b δ r t₁
      = segSum δ.val
          (⟨fun i => b.bit (Fin.cast (by
              have hkn : ((n / 4 : ℕ) : ℤ) + r ≤ (n : ℤ) := (prefix_range_oddThree r hr0 hr2).2
              have hkn' : (((n / 4 : ℕ) : ℤ) + r).toNat ≤ n := by
                have h := Int.toNat_le.mpr hkn; simpa using h
              omega)
            (Fin.castAdd (n - (((n / 4 : ℕ) : ℤ) + r).toNat) i))⟩
              : BinVec (((n / 4 : ℕ) : ℤ) + r).toNat)
          (fun s => if s = t₁.bits then 1 else 0) :=
  prefixWeight_eq_segSum b δ r t₁ (prefix_range_oddThree r hr0 hr2).1
    (prefix_range_oddThree r hr0 hr2).2

/-- **Suffix segment-sum bridge for `n ≡ 3 (mod 4)`.**  On the offset support,
the suffix weight equals the suffix point-segment-sum of the
length-`(n - 3*(n/4) - r)` segment of `b`.  This is `suffixWeight_eq_segSum`
with the off-by-one suffix range bounds (`suffix_range_oddThree`).  Note the
suffix segment here STARTS at index `3*(n/4) + r` — which, for `n ≡ 3 (mod 4)`,
OVERLAPS the last middle bit (see `middle_suffix_overlap_of_mod4_eq_three`).
The segSum bridge itself is correct (it just reads `b` from that start); the
overlap is what the *combined* three-segment tiling must reconcile, see §4. -/
theorem suffixWeight_eq_segSum_oddThree {n : ℕ} (h : n % 4 = 3) (b : BinVec n)
    (δ : DelProb) (r : ℤ) (t₂ : Trace n)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    suffixWeight n b δ r t₂
      = segSum δ.val
          (⟨fun i => b.bit (Fin.cast (by
              have hkn : ((3 * (n / 4) : ℕ) : ℤ) + r ≤ (n : ℤ) := (suffix_range_oddThree h r hr0 hr2).2
              have hkn' : (((3 * (n / 4) : ℕ) : ℤ) + r).toNat ≤ n := by
                have h := Int.toNat_le.mpr hkn; simpa using h
              omega)
            (Fin.natAdd (((3 * (n / 4) : ℕ) : ℤ) + r).toNat i))⟩
              : BinVec (n - (((3 * (n / 4) : ℕ) : ℤ) + r).toNat))
          (fun s => if s = t₂.bits then 1 else 0) :=
  suffixWeight_eq_segSum b δ r t₂ (suffix_range_oddThree h r hr0 hr2).1
    (suffix_range_oddThree h r hr0 hr2).2

/-! ## 4. The blocked per-`r` identity for `n ≡ 3 (mod 4)` (documented `sorry`)

This is the analogue of `PartialDominatesHCore.per_r_identity` for the
off-by-one case.  It is the one piece that **cannot** be closed green-safe with
the foundations above alone, and the reason is genuinely mathematical, not a
missing lemma name.  We state it precisely and `sorry` it, with a full account
of the obstruction.

### Why the gated proof does not transfer

`PartialDominatesHCore.per_r_identity` proves

    LHS(r)  =  ∑ m, [restrict b m = τ.bits] · ∏ wfac           (RHS, r-independent)

by tiling `b` into three DISJOINT string segments via
`PartialDominatesCutIndependence.whole_string_eq_segConv`, with segment sizes
`(K₁, n/2, K₃) = ((n/4+r).toNat, n/2, n − (3*(n/4)+r).toNat)` and the tiling
`K₁ + n/2 + K₃ = n`.  That tiling **requires** `2*(n/4) = n/2` (the gate): the
middle SEGMENT of the string (the gap between prefix end `n/4+r` and suffix
start `3*(n/4)+r`) has width `2*(n/4)`, and the proof identifies it with the
`n/2`-wide middle OUTPUT.

For `n ≡ 3 (mod 4)`, `2*(n/4) = n/2 − 1` (`trueMiddle_succ_eq_half_of_mod4_eq_three`).
So:

* the disjoint string-tiling has middle width `n/2 − 1`
  (`tiling_oddThree`: `K₁ + 2*(n/4) + K₃ = n`), but
* the `middleIndicator`/`midWindow'` middle OUTPUT is `n/2` bits wide, ending at
  string position `3*(n/4)+r` — which is the SAME physical bit as the suffix
  segment's first position (`middle_suffix_overlap_of_mod4_eq_three`).

Hence for `n ≡ 3 (mod 4)` the partial process's three components
(prefix-trace, `n/2`-bit middle output, suffix-trace) do **not** correspond to a
DISJOINT cut of `b`: the middle output and the suffix share one physical bit
(`b` at position `3*(n/4)+r`).  `whole_string_eq_segConv` only factors a
disjoint `n₁+n₂+n₃ = n` cut, so it cannot be applied at `(K₁, n/2, K₃)` here
(`K₁ + n/2 + K₃ = n + 1`, NOT `n` — the overlap is double-counted).

### What the correct n≡3 derivation needs (NOT green-safe replicable)

The paper's middle output IS `n/2` bits (`deletion.tex` 287-300: middle is
`r + {n/4+1, …, 3n/4}`, exactly `n/2` positions).  The honest reconciliation is
one of:

1. **Re-cut at the true-middle width** `2*(n/4) = n/2 − 1` and prove a *modified*
   segConv where the suffix segment's FIRST bit is folded into the middle output
   — i.e. re-run the entire `whole_string_eq_segConv` / `segConv_list_eq_trace`
   chain with `(n₁, n₂, n₃) = (K₁, 2*(n/4), K₃')`, `K₃' = K₃`, and separately
   prove that the `n/2`-bit `middleIndicator` output, restricted through the
   reconstruction kernel, agrees with the `2*(n/4)`-wide middle SEGMENT plus the
   shared boundary bit.  This requires re-deriving `whole_string_triple_split`,
   `whole_string_eq_segConv`, `segConv_list_eq_trace`, and
   `traceDelete_fullTrace_eq_segSum` at the new widths — the full convolution
   machinery, ~5 lemmas each presently sorry-free under the gate but hard-wired
   to `n/2`.  None can be reused verbatim because the middle width changes.

2. **Or** shift the suffix-mask boundary `isSuffixMask` to `i ≥ 3*(n/4)+r+1`
   for `n ≡ 3 (mod 4)`, making the three string segments disjoint at widths
   `(n/4+r, n/2, n−3*(n/4)−r−1)`.  But `isSuffixMask` is a FROZEN definition in
   `Workspace.Types.PartialDeletionProcess`; changing it is a formalization edit
   (needs user approval, and would re-validate the whole partial-process type).

Either route is a multi-day re-derivation of the convolution layer at the
corrected widths; it is exactly the kind of "full H-core machinery" that cannot
be replicated green-safe in this single new file.  We therefore record the
target precisely and `sorry` it. -/

/-- **Per-`r` identity for `n ≡ 3 (mod 4)` — FALSE AS STATED (documented `sorry`).**

The off-by-one analogue of `PartialDominatesHCore.per_r_identity`: on the offset
support, the inner three-segment convolution of the partial process equals the
whole-string keep-set sum, with NO gate hypothesis (instead `n % 4 = 3`).

### This statement is mathematically FALSE for `n ≡ 3 (mod 4)`.

It is **not** merely "blocked on a missing convolution lemma" — its LHS does not
equal its RHS.  Direct numerical check (`n = 7`, `δ = 1/3`, all `b`, all targets
`τ`, all `r` on the offset support): LHS ≠ RHS in **457 of 800** cases.

The reason is the overlap pinned by `middle_suffix_overlap_of_mod4_eq_three`: the
`n/2`-bit middle OUTPUT window's last position is `3*(n/4)+r`, while the FROZEN
`Workspace.Types.PartialDeletionProcess.isSuffixMask` keeps the suffix on
`i ≥ 3*(n/4)+r`.  So the physical bit `b` at position `3*(n/4)+r` is processed
**twice** by the LHS — once as the last middle bit fed through `traceDelete`,
once as the first suffix bit summed in `suffixWeight` — whereas the whole-string
RHS processes every bit once.  Hence LHS ≠ RHS.  This sorry can therefore NEVER
be closed against the current frozen process; closing it would require faking.

### The faithful fix (proved sorry-free in a sibling file).

`PartialDominatesHCoreOddThreeCorrected.per_r_identity_oddThree_corrected`
proves, SORRY-FREE (axioms = Mathlib std only), the corrected identity where the
suffix is read at the shifted offset `r+1` (boundary `3*(n/4)+r+1`), making the
three segments prefix `[0,n/4+r)`, middle `[n/4+r, 3*(n/4)+r+1)` of the genuine
width `n/2`, suffix `[3*(n/4)+r+1, n)` DISJOINT and tiling `n`
(`tiling_oddThree_corrected`).  Numerically: 0 mismatches.  Notably it needs NO
re-derivation of the convolution layer at a non-`n/2` width — the existing
generic `whole_string_eq_segConv` applies directly at the disjoint `n/2`-middle
cut.

Closing this exact `sorry` requires a **user-approved formalization edit**:
shift `Workspace.Types.PartialDeletionProcess.isSuffixMask`'s boundary from
`3*(n/4)+r` to `3*(n/4)+r+1` for `n ≡ 3 (mod 4)` (or unconditionally — for the
gated `n % 4 ∈ {0,1}` case the two boundaries coincide since `2*(n/4)=n/2`, so
the shift is harmless there).  After that edit `suffixWeight n b δ r` reads from
`3*(n/4)+r+1` and equals the `suffixWeight n b δ (r+1)` used in the corrected
lemma, discharging this goal from `per_r_identity_oddThree_corrected`.

The foundational arithmetic and segment bridges (`tiling_oddThree`,
`middleIndicator_eq_point'`, `prefixWeight_eq_segSum_oddThree`,
`suffixWeight_eq_segSum_oddThree`) above remain sorry-free and correct. -/
theorem per_r_identity_oddThree {n : ℕ} (h : n % 4 = 3) (b : BinVec n) (δ : DelProb)
    (τ : Trace n) (r : ℤ)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    (∑' (s : BinVec (n / 2) × Trace n × Trace n),
        (prefixWeight n b δ r s.2.1 *
          (suffixWeight n b δ r s.2.2 *
            middleIndicator n b s.1 r))
        * (∑' mid : Trace (n / 2),
            (traceDelete δ.val δ.pos.le δ.lt_one.le (PartialDominatesAssembly.fullTrace s.1)
                : Trace (n / 2) → ENNReal) mid
              * (if concatTrace s.2.1.bits mid.bits s.2.2.bits = τ then (1 : ENNReal) else 0)))
      = ∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1 : ENNReal) else 0) *
            ∏ i : Fin n, RestrictSegmentFactorization.wfac δ.val (m i) := by
  -- BLOCKED: needs the convolution-layer re-derivation at middle width
  -- `2*(n/4) = n/2 - 1` (the `n/2`-bit middle output overlaps the suffix by one
  -- physical bit of `b`; `whole_string_eq_segConv` only tiles a disjoint
  -- `n₁+n₂+n₃ = n` cut, and `K₁ + n/2 + K₃ = n + 1` here). See module note §4.
  sorry

end PartialDominatesHCoreOddThree
