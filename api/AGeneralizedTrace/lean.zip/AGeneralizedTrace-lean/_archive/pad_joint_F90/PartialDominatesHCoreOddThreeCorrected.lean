import Mathlib
import Workspace.Types.BinVec
import Workspace.Types.Trace
import Workspace.Types.DelProb
import Workspace.Types.ProbVec
import Workspace.Types.CoinFlipDist
import Workspace.Types.TraceDist
import Workspace.Types.TVDistance
import Workspace.Types.PartialDeletionProcess
import Workspace.ProofLemmas.RestrictSegmentFactorization
import Workspace.ProofLemmas.TraceDeletionKernel
import Workspace.ProofLemmas.PartialDominatesAssembly
import Workspace.ProofLemmas.PartialDominatesConvolution
import Workspace.ProofLemmas.PartialDominatesCutIndependence
import Workspace.ProofLemmas.PartialDominatesOffsetCast
import Workspace.ProofLemmas.OffsetWeightSumOne
import Workspace.ProofLemmas.DeletionLengthMarginal
import Workspace.ProofLemmas.OddNConstructionArith
import Workspace.ProofLemmas.PartialDominatesHCore
import Workspace.ProofLemmas.PartialDominatesHCoreOddThree

/-!
# `n ≡ 3 (mod 4)` per-`r` identity: the CORRECTED (disjoint-cut) version

## Background: `per_r_identity_oddThree` is FALSE as stated

`PartialDominatesHCoreOddThree.per_r_identity_oddThree` is **mathematically
false** for `n ≡ 3 (mod 4)`, not merely "blocked on a missing convolution
lemma". A direct numerical check (`n = 7`, `δ = 1/3`, all `b`, all `τ`, all
`r` on the offset support) shows its LHS disagrees with its RHS in 457 of 800
cases.

The reason is exactly the overlap pinned by
`PartialDominatesHCoreOddThree.middle_suffix_overlap_of_mod4_eq_three`: the
`n/2`-bit middle OUTPUT window spans positions `[n/4+r, 3*(n/4)+r]`
(its last bit is at position `3*(n/4)+r`), while the FROZEN
`Workspace.Types.PartialDeletionProcess.isSuffixMask` keeps the suffix on
`i ≥ 3*(n/4)+r` — so the physical bit `b` at position `3*(n/4)+r` is processed
**twice** by the LHS (once as the last middle bit fed through `traceDelete`,
once as the first suffix bit fed through `suffixWeight`). The whole-string
keep-set sum on the RHS processes every bit exactly once, so LHS ≠ RHS.

## The corrected identity (this file, sorry-free)

The honest fix routes the boundary bit to exactly ONE segment. Numerically
(`n = 7`, all the same sweeps) the identity becomes TRUE in 0 of 600 cases
*the moment the suffix start is shifted by one* to `3*(n/4)+r+1`, making the
three segments
* prefix  `[0, n/4+r)`,           width `K₁ = (n/4+r).toNat`,
* middle  `[n/4+r, 3*(n/4)+r+1)`, width `n/2`         (the genuine `n/2` output),
* suffix  `[3*(n/4)+r+1, n)`,     width `K₃' = n − (3*(n/4)+r+1).toNat`,
disjoint with `K₁ + n/2 + K₃' = n`
(`tiling_oddThree_corrected`, all `n ≡ 3 (mod 4)` on the offset support).

Crucially, with this shift the middle width is the genuine `n/2`, so the
EXISTING generic convolution layer
`PartialDominatesCutIndependence.whole_string_eq_segConv` /
`PartialDominatesHCore.segConv_list_eq_trace` apply at the cut
`(K₁, n/2, K₃')` with NO re-derivation at a different middle width.

We therefore introduce a LOCAL shifted suffix weight `suffixWeight'`
(boundary `3*(n/4)+r+1` instead of `3*(n/4)+r`) and prove the corrected per-`r`
identity `per_r_identity_oddThree_corrected` **sorry-free**, mirroring
`PartialDominatesHCore.per_r_identity` at the disjoint cut.

This is the exact target a future, user-approved formalization edit (shifting
`isSuffixMask`'s boundary to `3*(n/4)+r+1` for `n ≡ 3 (mod 4)`) would consume:
once `Workspace.Types.PartialDeletionProcess.suffixWeight` reads from
`3*(n/4)+r+1`, `suffixWeight = suffixWeight'` definitionally and the corrected
identity discharges the genuine `per_r_identity` for the off-by-one case.

This file imports only built modules and edits no existing file; the build
stays green.
-/

namespace PartialDominatesHCoreOddThreeCorrected

open Workspace.Types.BinVec
open Workspace.Types.Trace
open Workspace.Types.DelProb
open Workspace.Types.ProbVec
open Workspace.Types.CoinFlipDist
open Workspace.Types.TraceDist
open Workspace.Types.PartialDeletionProcess
open Workspace.Types.DeletionChannel
open RestrictSegmentFactorization
open TraceDeletionKernel
open PartialDominatesAssembly
open PartialDominatesConvolution
open PartialDominatesCutIndependence
open PartialDominatesOffsetCast
open OffsetWeightSumOne
open Workspace.ProofLemmas.OddNConstructionArith
open PartialDominatesHCore
open PartialDominatesHCoreOddThree

open scoped Classical

/-! ## 1. Corrected disjoint tiling at the genuine `n/2` middle width -/

/-- **Corrected disjoint tiling** for `n ≡ 3 (mod 4)`: with the suffix start
shifted to `3*(n/4)+r+1`, the three segments
`(K₁, n/2, K₃') = ((n/4+r).toNat, n/2, n − (3*(n/4)+r+1).toNat)` are disjoint
and tile `n`.  Here the middle width is the GENUINE `n/2` output width, so the
existing `whole_string_eq_segConv` applies directly. -/
theorem tiling_oddThree_corrected {n : ℕ} (h : n % 4 = 3) (r : ℤ)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    (((n / 4 : ℕ) : ℤ) + r).toNat + n / 2
        + (n - (((3 * (n / 4) : ℕ) : ℤ) + r + 1).toNat) = n := by
  have hodd : n % 2 = 1 := by omega
  have hpre0 : 0 ≤ ((n / 4 : ℕ) : ℤ) + r := by linarith [hr0]
  -- suffix start (shifted) is in range [0, n].
  have hsuf0 : 0 ≤ ((3 * (n / 4) : ℕ) : ℤ) + r + 1 := by
    have : ((n / 4 : ℕ) : ℤ) ≤ ((3 * (n / 4) : ℕ) : ℤ) := by push_cast; omega
    linarith [hpre0]
  have hsufn : ((3 * (n / 4) : ℕ) : ℤ) + r + 1 ≤ (n : ℤ) := by
    -- 3*(n/4)+r+1 = (n/4+r) + (2*(n/4)+1) = (n/4+r) + n/2 ≤ n/2 + n/2 ≤ n  (n%4=3 ⇒ 2*(n/4)+1=n/2)
    have hhalf : n / 2 = 2 * (n / 4) + 1 := gate_off_by_one_of_mod4_eq_three n h
    have he : ((3 * (n / 4) : ℕ) : ℤ) + r + 1
        = (((n / 4 : ℕ) : ℤ) + r) + ((n / 2 : ℕ) : ℤ) := by
      have hgZ : ((n / 2 : ℕ) : ℤ) = (2 * (n / 4) : ℕ) + 1 := by exact_mod_cast hhalf
      rw [hgZ]; push_cast; ring
    rw [he]
    have h1 : ((n / 4 : ℕ) : ℤ) + r ≤ (n / 2 : ℕ) := by linarith [hr2]
    have hn2 : (n / 2 : ℕ) + (n / 2 : ℕ) ≤ (n : ℕ) := by omega
    have : ((n / 2 : ℕ) : ℤ) + ((n / 2 : ℕ) : ℤ) ≤ (n : ℤ) := by exact_mod_cast hn2
    linarith
  have hK₁Z : ((((n / 4 : ℕ) : ℤ) + r).toNat : ℤ) = ((n / 4 : ℕ) : ℤ) + r :=
    Int.toNat_of_nonneg hpre0
  have hK₃Z : ((((3 * (n / 4) : ℕ) : ℤ) + r + 1).toNat : ℤ) = ((3 * (n / 4) : ℕ) : ℤ) + r + 1 :=
    Int.toNat_of_nonneg hsuf0
  have hsuf_le : (((3 * (n / 4) : ℕ) : ℤ) + r + 1).toNat ≤ n := by
    have := Int.toNat_le.mpr hsufn; simpa using this
  -- K₁ + n/2 = (3*(n/4)+r+1).toNat
  have hhalf : n / 2 = 2 * (n / 4) + 1 := gate_off_by_one_of_mod4_eq_three n h
  have hkey : (((n / 4 : ℕ) : ℤ) + r).toNat + n / 2
      = (((3 * (n / 4) : ℕ) : ℤ) + r + 1).toNat := by
    have hZ : ((((n / 4 : ℕ) : ℤ) + r).toNat : ℤ) + (n / 2 : ℕ)
        = ((((3 * (n / 4) : ℕ) : ℤ) + r + 1).toNat : ℤ) := by
      rw [hK₁Z, hK₃Z]
      have hgZ : ((n / 2 : ℕ) : ℤ) = (2 * (n / 4) : ℕ) + 1 := by exact_mod_cast hhalf
      rw [hgZ]; push_cast; ring
    exact_mod_cast hZ
  omega

/-! ## 2. The corrected per-`r` identity (sorry-free)

The shifted suffix is just the FROZEN `suffixWeight` evaluated at offset `r+1`:
`isSuffixMask n (r+1) μ` keeps the suffix on `i ≥ 3*(n/4)+(r+1) = 3*(n/4)+r+1`,
exactly the disjoint boundary.  So no new definition is needed — the corrected
LHS uses `suffixWeight n b δ (r+1)`.

The proof mirrors `PartialDominatesHCore.per_r_identity` at the disjoint cut
`(K₁, n/2, K₃')`, `K₁ = (n/4+r).toNat`, `K₃' = n − (3*(n/4)+r+1).toNat`, using
`tiling_oddThree_corrected` for the cut and the existing generic
`whole_string_eq_segConv` / `segConv_list_eq_trace` (middle width is the genuine
`n/2`).  Numerically verified (`n = 7`, all `b`, `τ`, `r`): 0 mismatches. -/

/-- **Corrected per-`r` identity for `n ≡ 3 (mod 4)` (SORRY-FREE).**

On the offset support, with the suffix read at the shifted offset `r+1` (so the
three string segments prefix `[0,n/4+r)`, middle `[n/4+r, 3*(n/4)+r+1)` of width
`n/2`, suffix `[3*(n/4)+r+1, n)` are DISJOINT and tile `n`), the inner
three-segment convolution of the partial process equals the whole-string
keep-set sum — independent of `r`.

This is the faithful, off-by-one-corrected analogue of
`PartialDominatesHCore.per_r_identity`; it replaces the FALSE
`PartialDominatesHCoreOddThree.per_r_identity_oddThree` (whose LHS double-counts
the boundary bit `b` at position `3*(n/4)+r`).  A future formalization edit that
shifts `Workspace.Types.PartialDeletionProcess.isSuffixMask`'s boundary to
`3*(n/4)+r+1` for `n ≡ 3 (mod 4)` makes `suffixWeight n b δ r = suffixWeight'`
read here, discharging the genuine off-by-one per-`r` identity from this lemma. -/
theorem per_r_identity_oddThree_corrected {n : ℕ} (h : n % 4 = 3) (b : BinVec n)
    (δ : DelProb) (τ : Trace n) (r : ℤ)
    (hr0 : 0 ≤ r + (n / 4 : ℕ)) (hr2 : r + (n / 4 : ℕ) ≤ (n / 2 : ℕ)) :
    (∑' (s : BinVec (n / 2) × Trace n × Trace n),
        (prefixWeight n b δ r s.2.1 *
          (suffixWeight n b δ (r + 1) s.2.2 *
            middleIndicator n b s.1 r))
        * (∑' mid : Trace (n / 2),
            (traceDelete δ.val δ.pos.le δ.lt_one.le (PartialDominatesAssembly.fullTrace s.1)
                : Trace (n / 2) → ENNReal) mid
              * (if concatTrace s.2.1.bits mid.bits s.2.2.bits = τ then (1 : ENNReal) else 0)))
      = ∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1 : ENNReal) else 0) *
            ∏ i : Fin n, RestrictSegmentFactorization.wfac δ.val (m i) := by
  have hodd : n % 2 = 1 := by omega
  -- Cut sizes (shifted suffix).
  set K₁ : ℕ := (((n / 4 : ℕ) : ℤ) + r).toNat with hK₁
  -- Use the `3*(n/4) + (r+1)` parenthesization so it matches `suffixWeight_eq_segSum (r+1)`.
  set K₃ : ℕ := n - (((3 * (n / 4) : ℕ) : ℤ) + (r + 1)).toNat with hK₃
  -- Prefix bounds.
  have hpre0 : 0 ≤ ((n / 4 : ℕ) : ℤ) + r := by linarith [hr0]
  have hpren : ((n / 4 : ℕ) : ℤ) + r ≤ (n : ℤ) := by
    have h1 : ((n / 4 : ℕ) : ℤ) + r ≤ (n / 2 : ℕ) := by linarith [hr2]
    have h2 : ((n / 2 : ℕ) : ℤ) ≤ (n : ℤ) := by exact_mod_cast Nat.div_le_self n 2
    linarith
  -- Shifted-suffix bounds (offset r+1): the suffixWeight_eq_segSum hypotheses use
  -- the integer point `3*(n/4) + (r+1)` = `3*(n/4) + r + 1`.
  have hsuf0' : 0 ≤ ((3 * (n / 4) : ℕ) : ℤ) + (r + 1) := by
    have : ((n / 4 : ℕ) : ℤ) ≤ ((3 * (n / 4) : ℕ) : ℤ) := by push_cast; omega
    have : (0 : ℤ) ≤ ((3 * (n / 4) : ℕ) : ℤ) + r := by linarith [hpre0]
    linarith
  have hsufn' : ((3 * (n / 4) : ℕ) : ℤ) + (r + 1) ≤ (n : ℤ) := by
    have hhalf : n / 2 = 2 * (n / 4) + 1 := gate_off_by_one_of_mod4_eq_three n h
    have he : ((3 * (n / 4) : ℕ) : ℤ) + (r + 1)
        = (((n / 4 : ℕ) : ℤ) + r) + ((n / 2 : ℕ) : ℤ) := by
      have hgZ : ((n / 2 : ℕ) : ℤ) = (2 * (n / 4) : ℕ) + 1 := by exact_mod_cast hhalf
      rw [hgZ]; push_cast; ring
    rw [he]
    have h1 : ((n / 4 : ℕ) : ℤ) + r ≤ (n / 2 : ℕ) := by linarith [hr2]
    have hn2 : (n / 2 : ℕ) + (n / 2 : ℕ) ≤ (n : ℕ) := by omega
    have : ((n / 2 : ℕ) : ℤ) + ((n / 2 : ℕ) : ℤ) ≤ (n : ℤ) := by exact_mod_cast hn2
    linarith
  -- The (3*(n/4) + (r+1)) and (3*(n/4) + r + 1) integers coincide.
  have hshift : ((3 * (n / 4) : ℕ) : ℤ) + (r + 1) = ((3 * (n / 4) : ℕ) : ℤ) + r + 1 := by ring
  -- The disjoint three-cut sum (using the genuine n/2 middle width).
  have hsum3 : K₁ + n / 2 + K₃ = n := by
    have ht := tiling_oddThree_corrected h r hr0 hr2
    -- bridge the two parenthesizations of the suffix start.
    have hpar : (((3 * (n / 4) : ℕ) : ℤ) + r + 1).toNat
        = (((3 * (n / 4) : ℕ) : ℤ) + (r + 1)).toNat := by
      congr 1; ring
    rw [hpar] at ht
    simpa [hK₁, hK₃] using ht
  -- The cast vector `b'` over `BinVec (K₁ + n/2 + K₃)`.
  set b' : BinVec (K₁ + n / 2 + K₃) := ⟨fun i => b.bit (Fin.cast hsum3 i)⟩ with hb'
  -- The three segConv segments of `b'`.
  set c₁ : BinVec K₁ := ⟨fun i => b'.bit (Fin.castAdd K₃ (Fin.castAdd (n / 2) i))⟩ with hc₁
  set c₂ : BinVec (n / 2) := ⟨fun i => b'.bit (Fin.castAdd K₃ (Fin.natAdd K₁ i))⟩ with hc₂
  set c₃ : BinVec K₃ := ⟨fun i => b'.bit (Fin.natAdd (K₁ + n / 2) i)⟩ with hc₃
  -- RHS chain: whole-string sum (b) = whole-string sum (b') = segConv(b') = segConv-trace.
  have hRHS :
      (∑ m : Fin n → Bool,
          (if restrict b m = τ.bits then (1 : ENNReal) else 0) *
            ∏ i : Fin n, RestrictSegmentFactorization.wfac δ.val (m i))
        = ∑' s : Trace n × Trace n × Trace (n / 2),
            segSum δ.val c₁ (fun t => if t = s.1.bits then 1 else 0)
              * (segSum δ.val c₂ (fun t => if t = s.2.2.bits then 1 else 0)
                * (segSum δ.val c₃ (fun t => if t = s.2.1.bits then 1 else 0)
                  * (if s.1.bits ++ s.2.2.bits ++ s.2.1.bits = τ.bits then (1 : ENNReal) else 0))) := by
    rw [← wholeStringSum_cast hsum3 b δ.val τ.bits]
    rw [PartialDominatesCutIndependence.whole_string_eq_segConv δ.val b' τ.bits]
    rw [segConv_list_eq_trace δ.val c₁ c₂ c₃ τ.bits (by omega) (le_refl _) (by omega)]
  -- The pinned middle window (gate-free, the genuine n/2 output).
  set Mid : BinVec (n / 2) := midWindow' b r hr0 hr2 with hMid
  rw [hRHS]
  rw [ENNReal.tsum_prod']
  rw [tsum_eq_single Mid ?_]
  · -- The `M = Mid` term.
    have hK₁Z : (K₁ : ℤ) = ((n / 4 : ℕ) : ℤ) + r := Int.toNat_of_nonneg hpre0
    -- Prefix bridge (gate-free).
    have hpreSeg : ∀ t₁ : Trace n, prefixWeight n b δ r t₁
        = segSum δ.val c₁ (fun t => if t = t₁.bits then 1 else 0) := by
      intro t₁
      rw [prefixWeight_eq_segSum b δ r t₁ hpre0 hpren]
      apply segSum_congr_bit
      intro i
      simp only [hc₁, hb']
      congr 1
    -- Suffix bridge at the SHIFTED offset r+1.
    have hsufSeg : ∀ t₂ : Trace n, suffixWeight n b δ (r + 1) t₂
        = segSum δ.val c₃ (fun t => if t = t₂.bits then 1 else 0) := by
      intro t₂
      rw [suffixWeight_eq_segSum b δ (r + 1) t₂ hsuf0' hsufn']
      apply segSum_congr_bit
      intro i
      simp only [hc₃, hb']
      congr 1
      apply Fin.ext
      simp only [Fin.val_cast, Fin.val_natAdd]
      -- (3*(n/4) + (r+1)).toNat = K₁ + n/2  (start of suffix segment)
      have hstartZ : ((((3 * (n / 4) : ℕ) : ℤ) + (r + 1)).toNat : ℤ)
          = ((3 * (n / 4) : ℕ) : ℤ) + (r + 1) := Int.toNat_of_nonneg hsuf0'
      have hkey : (((3 * (n / 4) : ℕ) : ℤ) + (r + 1)).toNat = K₁ + n / 2 := by
        have hhalf : n / 2 = 2 * (n / 4) + 1 := gate_off_by_one_of_mod4_eq_three n h
        have hZ : ((((3 * (n / 4) : ℕ) : ℤ) + (r + 1)).toNat : ℤ) = (K₁ : ℤ) + (n / 2 : ℕ) := by
          rw [hstartZ, hK₁Z]
          have hgZ : ((n / 2 : ℕ) : ℤ) = (2 * (n / 4) : ℕ) + 1 := by exact_mod_cast hhalf
          rw [hgZ]; push_cast; ring
        exact_mod_cast hZ
      omega
    -- Middle bridge (gate-free pin).
    have hmidSeg : ∀ mid : Trace (n / 2),
        (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace Mid) : Trace (n / 2) → ENNReal) mid
          = segSum δ.val c₂ (fun t => if t = mid.bits then 1 else 0) := by
      intro mid
      rw [PartialDominatesCutIndependence.traceDelete_fullTrace_eq_segSum Mid δ mid]
      apply segSum_congr_bit
      intro i
      simp only [hMid, hc₂, hb', midWindow']
      congr 1
      apply Fin.ext
      simp only [Fin.val_cast, Fin.val_castAdd, Fin.val_natAdd]
      -- middle window index n/4+r+i  =  K₁ + i  (with K₁ = (n/4+r).toNat)
      have hiZ : ((((n / 4 : ℕ) : ℤ) + r + (i : ℕ)).toNat : ℤ)
          = ((n / 4 : ℕ) : ℤ) + r + (i : ℕ) := by
        rw [Int.toNat_of_nonneg]
        have : (0 : ℤ) ≤ ((i : ℕ) : ℤ) := by positivity
        linarith [hpre0]
      have : (((n / 4 : ℕ) : ℤ) + r + (i : ℕ)).toNat = K₁ + (i : ℕ) := by
        have hZ : ((((n / 4 : ℕ) : ℤ) + r + (i : ℕ)).toNat : ℤ) = (K₁ : ℤ) + (i : ℕ) := by
          rw [hiZ, hK₁Z]
        exact_mod_cast hZ
      omega
    -- Per-(t₁,t₂) rewrite of the LHS summand into the convolution form.
    have hperLHS : ∀ s : Trace n × Trace n,
        prefixWeight n b δ r (Mid, s).2.1 *
            (suffixWeight n b δ (r + 1) (Mid, s).2.2 * middleIndicator n b (Mid, s).1 r) *
          ∑' mid : Trace (n / 2),
            (traceDelete δ.val δ.pos.le δ.lt_one.le (fullTrace (Mid, s).1) : Trace (n / 2) → ENNReal) mid
              * (if concatTrace (Mid, s).2.1.bits mid.bits (Mid, s).2.2.bits = τ then (1 : ENNReal) else 0)
        = ∑' mid : Trace (n / 2),
            segSum δ.val c₁ (fun t => if t = s.1.bits then 1 else 0)
              * (segSum δ.val c₃ (fun t => if t = s.2.bits then 1 else 0)
                * (segSum δ.val c₂ (fun t => if t = mid.bits then 1 else 0)
                  * (if s.1.bits ++ mid.bits ++ s.2.bits = τ.bits then (1 : ENNReal) else 0))) := by
      rintro ⟨t₁, t₂⟩
      simp only
      rw [middleIndicator_eq_point' b Mid r hr0 hr2, hMid, if_pos rfl, mul_one]
      rw [hpreSeg t₁, hsufSeg t₂, ← ENNReal.tsum_mul_left]
      apply tsum_congr; intro mid
      rw [hmidSeg mid]
      by_cases hz1 : segSum δ.val c₁ (fun t => if t = t₁.bits then (1:ENNReal) else 0) = 0
      · rw [hz1]; ring
      by_cases hz3 : segSum δ.val c₃ (fun t => if t = t₂.bits then (1:ENNReal) else 0) = 0
      · rw [hz3]; ring
      have hl1 : t₁.bits.length ≤ K₁ := segSum_point_ne_zero_length δ.val c₁ t₁.bits hz1
      have hl3 : t₂.bits.length ≤ K₃ := segSum_point_ne_zero_length δ.val c₃ t₂.bits hz3
      have hmidlen : mid.bits.length ≤ n / 2 := mid.length_le
      have hfit : (t₁.bits ++ mid.bits ++ t₂.bits).length ≤ n := by
        rw [List.length_append, List.length_append]; omega
      have hind : (if concatTrace t₁.bits mid.bits t₂.bits = τ then (1:ENNReal) else 0)
          = (if t₁.bits ++ mid.bits ++ t₂.bits = τ.bits then (1:ENNReal) else 0) := by
        by_cases hb2 : t₁.bits ++ mid.bits ++ t₂.bits = τ.bits
        · rw [if_pos hb2, if_pos ((concatTrace_eq_target_iff _ _ _ _ hfit).mpr hb2)]
        · rw [if_neg hb2, if_neg (fun hc => hb2 ((concatTrace_eq_target_iff _ _ _ _ hfit).mp hc))]
      rw [hind]; ring
    rw [tsum_congr hperLHS]
    have hRHS2 :
        (∑' s : Trace n × Trace n × Trace (n / 2),
            (segSum δ.val c₁ fun t => if t = s.1.bits then (1:ENNReal) else 0) *
              ((segSum δ.val c₂ fun t => if t = s.2.2.bits then 1 else 0) *
                ((segSum δ.val c₃ fun t => if t = s.2.1.bits then 1 else 0) *
                  (if s.1.bits ++ s.2.2.bits ++ s.2.1.bits = τ.bits then 1 else 0))))
          = ∑' (p : Trace n × Trace n) (mid : Trace (n / 2)),
              (segSum δ.val c₁ fun t => if t = p.1.bits then (1:ENNReal) else 0) *
                ((segSum δ.val c₃ fun t => if t = p.2.bits then 1 else 0) *
                  ((segSum δ.val c₂ fun t => if t = mid.bits then 1 else 0) *
                    (if p.1.bits ++ mid.bits ++ p.2.bits = τ.bits then 1 else 0))) := by
      rw [← (Equiv.prodAssoc (Trace n) (Trace n) (Trace (n / 2))).tsum_eq]
      rw [ENNReal.tsum_prod']
      apply tsum_congr; rintro ⟨t₁, t₂⟩
      apply tsum_congr; intro mid
      simp only [Equiv.prodAssoc_apply]
      ac_rfl
    rw [hRHS2]
  · -- Off-diagonal `M ≠ Mid`.
    intro M hM
    apply ENNReal.tsum_eq_zero.mpr
    rintro ⟨t₁, t₂⟩
    rw [middleIndicator_eq_point' b M r hr0 hr2, if_neg hM]
    simp

end PartialDominatesHCoreOddThreeCorrected
