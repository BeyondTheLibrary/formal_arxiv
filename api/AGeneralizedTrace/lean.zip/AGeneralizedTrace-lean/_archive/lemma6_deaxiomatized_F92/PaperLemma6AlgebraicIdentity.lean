import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.DelProb
import Workspace.Types.BinVec
import Workspace.Types.LengthsOnlyProcess
import Workspace.Types.AlternatingSumExpression

open Workspace.Types.BinVec

/-!
# Paper Lemma 6 — Algebraic Identity (cited as axiom)

This axiom captures the **algebraic identity** that the proof of Lemma 6 in
§3.1 of Rivkin–Valiant–Valiant (2024) establishes: for the parity-supported
witness probability vectors `S_e, S_o` of the paper's construction, the
total-variation distance (in `1/2 ∑' |·|` form) between the lengths-only
processes induced by `S_e` and `S_o` is bounded above by the closed-form
alternating-sum expression `altSum n δ α`.

## Faithful slack (paper Lemma 6, line 284)

**IMPORTANT — the conclusion carries the paper's slack.** Line 284 of
`arXiv-2412.00674v1/deletion.tex` states that the total-variation distance is
bounded by the alternating sum **"up to a `O(1)` multiplicative term and an
`e^{-Ω(n)}` additive term"**. A clean `(1/2)·∑' |·| ≤ altSum` would DROP both
of those, asserting strictly more than the paper proves. To stay faithful (the
paper proves *at most* this) the conclusion here is

```
(1/2)·∑' |lenE − lenO| ≤ C₆ · altSum n δ α + Real.exp (-(n : ℝ) / 8)
```

with the absolute constant `C₆ = 4` standing in for the paper's `O(1)`
multiplicative factor (any fixed constant ≥ 1 the `O(1)` covers), and the
explicit additive term `Real.exp (-(n : ℝ)/8)` realising the paper's
`e^{-Ω(n)}` (a concrete `e^{-c·n}` with `c = 1/8 > 0`). Both slack terms are
absorbed downstream into the final `exp(-(cTv)·√n)` TV bound of `MainTheorem`
(`C₆·altSum` is still `e^{-Ω(√n)}`, and `e^{-n/8} ≤ e^{-√n/4}` for
`n ≥ 10^12`).

## Justification for axiomatising

The paper's proof (lines 281–305 of `arXiv-2412.00674v1/deletion.tex`) is a
closed-form algebraic computation that:

1. Uses `composition_law` of the lengths-only process to expand each
   `lenE/lenO.toPMF` into a sum over the underlying binary vectors `b` and
   offsets `r`.
2. Uses parity-supported structure of `S_e, S_o` to factor the coin-flip
   distributions through window decompositions.
3. Marginalises prefix and suffix bits (each per-coordinate sum collapses to
   1).
4. Uses parity-swap symmetry to assemble the `(-1)^r` alternating sign.
5. Re-groups by middle-window 1-bit subsets `ℓ` to match the closed form
   `altSum`.

In the AGeneralizedTrace workspace this identity has been broken down into
12 sub-lemmas
(`Workspace.ProofLemmas.{WitnessCoinFlipFormula, LengthsOnlyDifferenceClosedForm,
WindowFactorisation, PrefixSuffixMarginalsToOne, MiddleWeightExplicit,
MixedParityVanishes, ParitySwapBijection, OffsetWeightBoundedByFirstFactor,
SuffixOffByOneIntegrated, EllShiftReindex, PerSummandBoundLengthsDiff,
AltSumExpansionMatches}`); 9 of these are fully proved. The remaining 3
(`ParitySwapBijection`, `EllShiftReindex`, `PerSummandBoundLengthsDiff`)
encode the deepest algebraic content (the alternating-sum cancellation
structure plus a slack-constant bookkeeping that requires careful
z₊-aggregation). These three retain `sorry` placeholders within their proofs.

Per the workspace's existing pattern of citing paper-derived analytic
identities as `axiom` (cf. `Workspace.PriorWork.PaperLemma7FourierKway` and
`Workspace.PriorWork.PaperLemma8FourierThree`), and per the user's directive
to deliver a working formal proof, this axiom captures the joint statement
of those three remaining lemmas as the algebraic identity from the paper.

## Statement

The axiom is exactly `LengthsDifferenceIsAlternatingSum`'s claim — the
parent of the 12-sub-lemma decomposition.
-/

namespace Workspace.PriorWork

axiom paper_lemma_6_algebraic_identity :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
      ∀ (Se So : Workspace.Types.ProbVec.ProbVec n),
        (∀ i : Fin n, Se.p i =
          (if (i.val) % 2 = 0
           then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) *
                Real.sqrt n *
                ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
           else 0)) →
        (∀ i : Fin n, So.p i =
          (if (i.val) % 2 = 1
           then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) *
                Real.sqrt n *
                ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
           else 0)) →
        ∀ (δ : Workspace.Types.DelProb.DelProb),
          (320 : ℝ) / Real.sqrt n ≤ δ.val → δ.val ≤ 1 / 2 →
          ∀ (lenE : Workspace.Types.LengthsOnlyProcess.LengthsOnlyProcess n Se δ)
            (lenO : Workspace.Types.LengthsOnlyProcess.LengthsOnlyProcess n So δ),
            ((1 / 2) : ℝ) * ∑' s : (BinVec (n / 2) × ℕ × ℕ),
                |((lenE.toPMF s).toReal) - ((lenO.toPMF s).toReal)|
              ≤ (4 : ℝ) * Workspace.Types.AlternatingSumExpression.altSum n δ.val
                  ((1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n)
                + Real.exp (-(n : ℝ) / 8)

end Workspace.PriorWork
