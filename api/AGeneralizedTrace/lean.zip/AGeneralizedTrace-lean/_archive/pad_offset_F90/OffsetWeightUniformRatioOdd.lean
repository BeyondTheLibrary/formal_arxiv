import Mathlib
import Workspace.Types.StirlingAxioms
import Workspace.Types.PartialDeletionProcess
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.OffsetWeightFterm

/-!
# Uniform-in-`r` ratio bound for ODD `n` (`n % 8 = 1`)

This file proves, uniformly over the offset window `r ∈ [-n/4, n/4]` for odd `n`
with `n % 8 = 1` and `n ≥ 10^12`, the ratio bound

  `offsetWeight n r ≤ (4 / √π) · binPMFInt n (1/2) (r + n/2)`.

This mirrors `OffsetWeightUniformRatio` (which assumes `4 ∣ n`), but here `n = 4q+1`
is odd, so `n/2 = 2q`, `n/4 = q`, and the denominator central coefficient is the
*odd* central binomial `C(4q+1, 2q)`.

Structure:
* **Ratio monotonicity** (`cross_mono`): writing `q := n/4`, the ratio
  `R(r) := offsetWeight(r) / bin(n,1/2,r+n/2)` is (after cancelling `r`-independent
  `2`-powers) proportional to `g(k) := C(2q,k) / C(4q+1, q+k)` with `k = q + r`.
  Its one-step ratio is `≤ 1` for `k ≥ q` and `≥ 1` for `k ≤ q-1`, with
  `g(q-1) = g(q)`, so `g` is maximised at `k = q` (equivalently `r = 0`).
* **Central bound** (`r = 0`): `offsetWeight(0) ≤ √(2/(π·(n/2)))` (Stirling upper);
  for the denominator we use a *tight* central lower bound
  `C(4q+1,2q)·2^{-(4q+1)} = centralBinom(2q+1)·4^{-(2q+1)} ≥ (2√π/e²)/√(2q+1)`
  (re-derived here from Mathlib's `Stirling`, since the loose public bound
  `1/(2√n)` is just barely too weak to give the exact constant `4/√π` for odd `n`).
  The elementary inequality `(2√π/e²)/√(2q+1) ≥ 1/(4√q)` then closes the constant
  at exactly `4/√π`.

All results are sorry-free. The achieved uniform constant is `4/√π ≈ 2.2568 < 4`.
-/

namespace Workspace.ProofLemmas.OffsetWeightUniformRatioOdd

open Workspace.Types.StirlingAxioms
open Workspace.Types.PartialDeletionProcess
open Workspace.Types.AlternatingSumExpression
open Stirling

set_option maxHeartbeats 1600000

/-! ## Re-derived tight central lower bound (from Mathlib `Stirling`) -/

/-- `n! = stirlingSeq n · (√(2n) · (n/e)^n)`. -/
private theorem factStirling (n : ℕ) (hn : 1 ≤ n) :
    (Nat.factorial n : ℝ) = stirlingSeq n * (Real.sqrt (2 * n) * ((n : ℝ) / Real.exp 1) ^ n) := by
  have hpos : (0 : ℝ) < Real.sqrt (2 * n) * ((n : ℝ) / Real.exp 1) ^ n := by
    apply mul_pos
    · apply Real.sqrt_pos.mpr; positivity
    · positivity
  rw [stirlingSeq]
  field_simp

/-- `stirlingSeq k ≤ e/√2` for `k ≥ 1`. -/
private theorem stirlingSeqLe (k : ℕ) (hk : 1 ≤ k) : stirlingSeq k ≤ Real.exp 1 / Real.sqrt 2 := by
  have hanti := Stirling.stirlingSeq'_antitone
  have hk' : k = (k - 1) + 1 := by omega
  have hle : stirlingSeq k ≤ stirlingSeq (Nat.succ 0) := by
    have := hanti (Nat.zero_le (k - 1))
    simp only [Function.comp] at this
    rw [hk']
    simpa using this
  have hs1 : stirlingSeq (Nat.succ 0) = Real.exp 1 / Real.sqrt 2 := by
    rw [stirlingSeq]; simp [Nat.factorial]; field_simp
  rw [hs1] at hle; exact hle

/-- Tight core Stirling lower bound: `centralBinom k ≥ (2√π/e²) · 4^k / √k` for `k ≥ 1`. -/
private theorem coreLower (k : ℕ) (hk : 1 ≤ k) :
    (Nat.centralBinom k : ℝ) ≥ (2 * Real.sqrt Real.pi / (Real.exp 1)^2) * (4:ℝ)^k / Real.sqrt k := by
  set c : ℝ := (Nat.centralBinom k : ℝ) with hc
  set D : ℝ := ((k:ℝ) / Real.exp 1) ^ k with hD
  set Sk : ℝ := stirlingSeq k with hSk
  set S2k : ℝ := stirlingSeq (2*k) with hS2k
  have hkR : (0:ℝ) < (k:ℝ) := by exact_mod_cast hk
  have hDpos : 0 < D := by rw [hD]; positivity
  have hfk : (Nat.factorial k : ℝ) = Sk * (Real.sqrt (2 * k) * D) := factStirling k hk
  have hf2k : (Nat.factorial (2*k) : ℝ) = S2k * (Real.sqrt (2 * ((2*k:ℕ):ℝ)) * (((2*k:ℕ):ℝ) / Real.exp 1) ^ (2*k)) :=
    factStirling (2*k) (by omega)
  have hpow : (((2*k:ℕ):ℝ) / Real.exp 1) ^ (2*k) = (4:ℝ)^k * D^2 := by
    rw [hD]
    rw [show ((2*k:ℕ):ℝ) = 2 * (k:ℝ) by push_cast; ring]
    rw [mul_div_assoc, mul_pow]
    rw [show ((2:ℝ)^(2*k)) = 4^k by rw [pow_mul]; norm_num]
    rw [show (2*k) = k*2 by ring, pow_mul]
  have hsq4 : Real.sqrt (2 * ((2*k:ℕ):ℝ)) = 2 * Real.sqrt k := by
    rw [show (2 * ((2*k:ℕ):ℝ) : ℝ) = (2:ℝ)^2 * k by push_cast; ring, Real.sqrt_mul (by positivity), Real.sqrt_sq (by norm_num)]
  have hsq2 : Real.sqrt (2 * (k:ℝ)) ^ 2 = 2 * k := by
    rw [Real.sq_sqrt (by positivity)]
  have hcid : c * ((Nat.factorial k : ℝ))^2 = (Nat.factorial (2*k) : ℝ) := by
    have h := Nat.choose_mul_factorial_mul_factorial (Nat.le_mul_of_pos_left k (by norm_num : 0 < 2))
    rw [hc, Nat.centralBinom_eq_two_mul_choose]
    have h2 : 2 * k - k = k := by omega
    rw [h2] at h
    have := congrArg (Nat.cast : ℕ → ℝ) h
    push_cast at this; nlinarith [this]
  have hSkpos : 0 < Sk := by rw [hSk]; exact Stirling.stirlingSeq'_pos (k-1) |>.trans_eq (by congr 1; omega)
  have hS2kpos : 0 < S2k := by rw [hS2k]; exact Stirling.stirlingSeq'_pos (2*k-1) |>.trans_eq (by congr 1; omega)
  have hsqkpos : 0 < Real.sqrt k := Real.sqrt_pos.mpr hkR
  have hsqk_sq : Real.sqrt k ^ 2 = k := Real.sq_sqrt hkR.le
  have hkey : c * Sk^2 * Real.sqrt k = S2k * (4:ℝ)^k := by
    have e1 : c * (Sk * (Real.sqrt (2 * k) * D))^2
        = S2k * (2 * Real.sqrt k * ((4:ℝ)^k * D^2)) := by
      rw [← hfk]
      rw [hcid, hf2k, hsq4, hpow]
    have hD2 : 0 < D^2 := by positivity
    have e2 : (Sk * (Real.sqrt (2 * k) * D))^2 = Sk^2 * (2 * k) * D^2 := by
      have : Real.sqrt (2 * (k:ℝ))^2 = 2 * k := hsq2
      ring_nf
      ring_nf at this
      nlinarith [this]
    rw [e2] at e1
    have hcancel : c * Sk^2 * (2*k) = S2k * (2 * Real.sqrt k * (4:ℝ)^k) := by
      have hD2ne : D^2 ≠ 0 := ne_of_gt hD2
      field_simp at e1 ⊢
      nlinarith [e1, hD2]
    have hk_eq : (k:ℝ) = Real.sqrt k * Real.sqrt k := by nlinarith [hsqk_sq]
    have hfac : (c * Sk^2 * Real.sqrt k - S2k * (4:ℝ)^k) * (2 * Real.sqrt k) = 0 := by
      have expand : (c * Sk^2 * Real.sqrt k - S2k * (4:ℝ)^k) * (2 * Real.sqrt k)
          = c * Sk^2 * (2 * (Real.sqrt k * Real.sqrt k)) - S2k * (2 * Real.sqrt k * (4:ℝ)^k) := by ring
      rw [expand, ← hk_eq]; linarith [hcancel]
    have hne : (2 * Real.sqrt k) ≠ 0 := by positivity
    have hz : c * Sk^2 * Real.sqrt k - S2k * (4:ℝ)^k = 0 :=
      (mul_eq_zero.mp hfac).resolve_right hne
    linarith [hz]
  have hS2k_lb : Real.sqrt Real.pi ≤ S2k := by
    rw [hS2k]; exact Stirling.sqrt_pi_le_stirlingSeq (by omega)
  have hSk_ub : Sk ≤ Real.exp 1 / Real.sqrt 2 := by rw [hSk]; exact stirlingSeqLe k hk
  have hSk2_ub : Sk^2 ≤ (Real.exp 1)^2 / 2 := by
    have h1 : Sk^2 ≤ (Real.exp 1 / Real.sqrt 2)^2 := by
      apply sq_le_sq'
      · linarith [hSkpos]
      · exact hSk_ub
    have h2 : (Real.exp 1 / Real.sqrt 2)^2 = (Real.exp 1)^2 / 2 := by
      rw [div_pow, Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 2)]
    linarith [h1, h2.le, h2.ge]
  have hSk2pos : 0 < Sk^2 := by positivity
  have hpidpos : 0 < Real.sqrt Real.pi := Real.sqrt_pos.mpr Real.pi_pos
  have h4pos : (0:ℝ) < (4:ℝ)^k := by positivity
  have hSrel : (2 * Real.sqrt Real.pi / (Real.exp 1)^2) * Sk^2 ≤ S2k := by
    have hmul : (2 * Real.sqrt Real.pi / (Real.exp 1)^2) * Sk^2
        ≤ (2 * Real.sqrt Real.pi / (Real.exp 1)^2) * ((Real.exp 1)^2 / 2) := by
      apply mul_le_mul_of_nonneg_left hSk2_ub
      positivity
    have heq : (2 * Real.sqrt Real.pi / (Real.exp 1)^2) * ((Real.exp 1)^2 / 2) = Real.sqrt Real.pi := by
      field_simp
    rw [heq] at hmul; linarith [hS2k_lb]
  rw [ge_iff_le, div_le_iff₀ hsqkpos]
  have hcsqk : c * Real.sqrt k = S2k * (4:ℝ)^k / Sk^2 := by
    rw [eq_div_iff (ne_of_gt hSk2pos)]; nlinarith [hkey]
  rw [hcsqk, le_div_iff₀ hSk2pos]
  have hfin : (2 * Real.sqrt Real.pi / (Real.exp 1)^2) * (4:ℝ)^k * Sk^2
      = ((2 * Real.sqrt Real.pi / (Real.exp 1)^2) * Sk^2) * (4:ℝ)^k := by ring
  rw [hfin]
  exact mul_le_mul_of_nonneg_right hSrel h4pos.le

/-! ## Cross-monotonicity for `g(k) = C(2q,k)/C(4q+1, q+k)` -/

/-- Positivity of a binomial coefficient cast to `ℝ`, for `k ≤ n`. -/
private lemma choose_pos_real (n k : ℕ) (h : k ≤ n) : (0 : ℝ) < (Nat.choose n k : ℝ) := by
  have : 0 < Nat.choose n k := Nat.choose_pos h
  exact_mod_cast this

/-- **Right-side one-step monotonicity.** For `q ≤ k` and `k < 2q`:
`C(2q,k+1)·C(4q+1,q+k) ≤ C(2q,k)·C(4q+1,q+k+1)`. -/
private lemma cross_step_right (q k : ℕ) (hq : 1 ≤ q) (hk : q ≤ k) (hk2 : k < 2 * q) :
    (Nat.choose (2 * q) (k + 1) : ℝ) * (Nat.choose (4 * q + 1) (q + k) : ℝ)
      ≤ (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q + 1) (q + k + 1) : ℝ) := by
  have hqk4 : q + k < 4 * q + 1 := by omega
  have hnum := binom_ratio_succ (2 * q) k hk2
  have hden := binom_ratio_succ (4 * q + 1) (q + k) hqk4
  rw [hnum, hden]
  have hCk : (0 : ℝ) < (Nat.choose (2 * q) k : ℝ) := choose_pos_real _ _ (by omega)
  have hDk : (0 : ℝ) < (Nat.choose (4 * q + 1) (q + k) : ℝ) := choose_pos_real _ _ (by omega)
  have hsub2 : ((2 * q - k : ℕ) : ℝ) = (2 * q : ℝ) - (k : ℝ) := by
    have : k ≤ 2 * q := by omega
    push_cast [Nat.cast_sub this]; ring
  have hsub4 : ((4 * q + 1 - (q + k) : ℕ) : ℝ) = (3 * q + 1 : ℝ) - (k : ℝ) := by
    have : q + k ≤ 4 * q + 1 := by omega
    push_cast [Nat.cast_sub this]; ring
  rw [hsub2, hsub4]
  have hk1 : (0 : ℝ) < (k : ℝ) + 1 := by positivity
  have hqk1 : (0 : ℝ) < (q : ℝ) + (k : ℝ) + 1 := by positivity
  push_cast
  have hqR : (1 : ℝ) ≤ (q : ℝ) := by exact_mod_cast hq
  have hkR : (q : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have hAD : (0 : ℝ) ≤ (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q + 1) (q + k) : ℝ) :=
    mul_nonneg hCk.le hDk.le
  -- (2q-k)(q+k+1) ≤ (3q+1-k)(k+1)
  have hpoly : ((2 * q : ℝ) - (k : ℝ)) * ((q : ℝ) + (k : ℝ) + 1)
      ≤ ((3 * q + 1 : ℝ) - (k : ℝ)) * ((k : ℝ) + 1) := by nlinarith [hqR, hkR]
  rw [div_mul_eq_mul_div, mul_div_assoc' (Nat.choose (2 * q) k : ℝ),
      div_le_div_iff₀ hk1 hqk1]
  nlinarith [mul_le_mul_of_nonneg_left hpoly hAD, hCk, hDk, hk1, hqk1]

/-- **Left-side one-step monotonicity.** For `k < q`:
`C(2q,k)·C(4q+1,q+k+1) ≤ C(2q,k+1)·C(4q+1,q+k)`. -/
private lemma cross_step_left (q k : ℕ) (hq : 1 ≤ q) (hk : k < q) :
    (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q + 1) (q + k + 1) : ℝ)
      ≤ (Nat.choose (2 * q) (k + 1) : ℝ) * (Nat.choose (4 * q + 1) (q + k) : ℝ) := by
  have hk2q : k < 2 * q := by omega
  have hqk4 : q + k < 4 * q + 1 := by omega
  have hnum := binom_ratio_succ (2 * q) k hk2q
  have hden := binom_ratio_succ (4 * q + 1) (q + k) hqk4
  rw [hnum, hden]
  have hCk : (0 : ℝ) < (Nat.choose (2 * q) k : ℝ) := choose_pos_real _ _ (by omega)
  have hDk : (0 : ℝ) < (Nat.choose (4 * q + 1) (q + k) : ℝ) := choose_pos_real _ _ (by omega)
  have hsub2 : ((2 * q - k : ℕ) : ℝ) = (2 * q : ℝ) - (k : ℝ) := by
    have : k ≤ 2 * q := by omega
    push_cast [Nat.cast_sub this]; ring
  have hsub4 : ((4 * q + 1 - (q + k) : ℕ) : ℝ) = (3 * q + 1 : ℝ) - (k : ℝ) := by
    have : q + k ≤ 4 * q + 1 := by omega
    push_cast [Nat.cast_sub this]; ring
  rw [hsub2, hsub4]
  have hk1 : (0 : ℝ) < (k : ℝ) + 1 := by positivity
  have hqk1 : (0 : ℝ) < (q : ℝ) + (k : ℝ) + 1 := by positivity
  push_cast
  have hqR : (1 : ℝ) ≤ (q : ℝ) := by exact_mod_cast hq
  have hkR : (k : ℝ) + 1 ≤ (q : ℝ) := by
    have : k + 1 ≤ q := hk
    exact_mod_cast this
  have hAD : (0 : ℝ) ≤ (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q + 1) (q + k) : ℝ) :=
    mul_nonneg hCk.le hDk.le
  -- (3q+1-k)(k+1) ≤ (2q-k)(q+k+1)  for k+1 ≤ q
  have hpoly : ((3 * q + 1 : ℝ) - (k : ℝ)) * ((k : ℝ) + 1)
      ≤ ((2 * q : ℝ) - (k : ℝ)) * ((q : ℝ) + (k : ℝ) + 1) := by nlinarith [hqR, hkR]
  rw [div_mul_eq_mul_div, mul_div_assoc' (Nat.choose (2 * q) k : ℝ),
      div_le_div_iff₀ hqk1 hk1]
  nlinarith [mul_le_mul_of_nonneg_left hpoly hAD, hCk, hDk, hk1, hqk1]

/-- **Right-side global monotonicity.** For `q ≤ k ≤ 2q`:
`C(2q,k)·C(4q+1,2q) ≤ C(2q,q)·C(4q+1,q+k)`. -/
private lemma cross_mono_right (q : ℕ) (hq : 1 ≤ q) :
    ∀ k, q ≤ k → k ≤ 2 * q →
      (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
        ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + k) : ℝ) := by
  intro k hk hk2
  obtain ⟨d, rfl⟩ : ∃ d, k = q + d := ⟨k - q, by omega⟩
  clear hk
  induction d with
  | zero =>
    simp only [Nat.add_zero]
    rw [show q + q = 2 * q by ring]
  | succ d ih =>
    have hk2' : q + d ≤ 2 * q := by omega
    have hkd2 : q + d < 2 * q := by omega
    have hstep := cross_step_right q (q + d) hq (by omega) hkd2
    have ihd := ih hk2'
    have hDpos : (0 : ℝ) < (Nat.choose (4 * q + 1) (q + (q + d)) : ℝ) :=
      choose_pos_real _ _ (by omega)
    have hD2pos : (0 : ℝ) < (Nat.choose (4 * q + 1) (2 * q) : ℝ) :=
      choose_pos_real _ _ (by omega)
    have hDp1pos : (0 : ℝ) < (Nat.choose (4 * q + 1) (q + (q + d) + 1) : ℝ) :=
      choose_pos_real _ _ (by omega)
    have hA : (Nat.choose (2 * q) (q + d + 1) : ℝ) * (Nat.choose (4 * q + 1) (q + (q + d)) : ℝ)
        * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
        ≤ (Nat.choose (2 * q) (q + d) : ℝ) * (Nat.choose (4 * q + 1) (q + (q + d) + 1) : ℝ)
        * (Nat.choose (4 * q + 1) (2 * q) : ℝ) :=
      mul_le_mul_of_nonneg_right hstep hD2pos.le
    have hB : (Nat.choose (2 * q) (q + d) : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
        * (Nat.choose (4 * q + 1) (q + (q + d) + 1) : ℝ)
        ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + (q + d)) : ℝ)
        * (Nat.choose (4 * q + 1) (q + (q + d) + 1) : ℝ) :=
      mul_le_mul_of_nonneg_right ihd hDp1pos.le
    have key : (Nat.choose (2 * q) (q + d + 1) : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
        * (Nat.choose (4 * q + 1) (q + (q + d)) : ℝ)
        ≤ ((Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + (q + d) + 1) : ℝ))
        * (Nat.choose (4 * q + 1) (q + (q + d)) : ℝ) := by
      nlinarith [hA, hB]
    have hgoal : (Nat.choose (2 * q) (q + d + 1) : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
        ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + (q + d) + 1) : ℝ) :=
      le_of_mul_le_mul_right key hDpos
    rw [show q + (q + d) + 1 = q + (q + d + 1) by omega] at hgoal
    exact hgoal

/-- **Left-side global monotonicity.** For `k ≤ q`:
`C(2q,k)·C(4q+1,2q) ≤ C(2q,q)·C(4q+1,q+k)`. -/
private lemma cross_mono_left (q : ℕ) (hq : 1 ≤ q) :
    ∀ k, k ≤ q →
      (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
        ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + k) : ℝ) := by
  suffices h : ∀ j, (Nat.choose (2 * q) (q - j) : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
      ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + (q - j)) : ℝ) by
    intro k hk
    have := h (q - k)
    rw [show q - (q - k) = k by omega] at this
    exact this
  intro j
  induction j with
  | zero =>
    simp only [Nat.sub_zero]
    rw [show q + q = 2 * q by ring]
  | succ j ih =>
    by_cases hjq : j + 1 ≤ q
    · set k0 := q - (j + 1) with hk0
      have hk0q : k0 < q := by omega
      have hstep := cross_step_left q k0 hq hk0q
      have hk01 : k0 + 1 = q - j := by omega
      have hqk01 : q + k0 + 1 = q + (q - j) := by omega
      rw [hk01] at hstep
      rw [hqk01] at hstep
      have hD2 : (0 : ℝ) < (Nat.choose (4 * q + 1) (2 * q) : ℝ) := choose_pos_real _ _ (by omega)
      have hDqj : (0 : ℝ) < (Nat.choose (4 * q + 1) (q + (q - j)) : ℝ) :=
        choose_pos_real _ _ (by omega)
      have hDk0 : (0 : ℝ) < (Nat.choose (4 * q + 1) (q + k0) : ℝ) := choose_pos_real _ _ (by omega)
      have hA : (Nat.choose (2 * q) k0 : ℝ) * (Nat.choose (4 * q + 1) (q + (q - j)) : ℝ)
          * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
          ≤ (Nat.choose (2 * q) (q - j) : ℝ) * (Nat.choose (4 * q + 1) (q + k0) : ℝ)
          * (Nat.choose (4 * q + 1) (2 * q) : ℝ) :=
        mul_le_mul_of_nonneg_right hstep hD2.le
      have hB : (Nat.choose (2 * q) (q - j) : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
          * (Nat.choose (4 * q + 1) (q + k0) : ℝ)
          ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + (q - j)) : ℝ)
          * (Nat.choose (4 * q + 1) (q + k0) : ℝ) :=
        mul_le_mul_of_nonneg_right ih hDk0.le
      have key : (Nat.choose (2 * q) k0 : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
          * (Nat.choose (4 * q + 1) (q + (q - j)) : ℝ)
          ≤ ((Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + k0) : ℝ))
          * (Nat.choose (4 * q + 1) (q + (q - j)) : ℝ) := by
        nlinarith [hA, hB]
      have hgoal : (Nat.choose (2 * q) k0 : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
          ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + k0) : ℝ) :=
        le_of_mul_le_mul_right key hDqj
      exact hgoal
    · rw [show q - (j + 1) = q - j by omega]
      exact ih

/-- **Cross-multiplied global monotonicity.** For `0 ≤ k ≤ 2q` (with `q ≥ 1`):
`C(2q,k)·C(4q+1,2q) ≤ C(2q,q)·C(4q+1,q+k)`. -/
private lemma cross_mono (q k : ℕ) (hq : 1 ≤ q) (hk : k ≤ 2 * q) :
    (Nat.choose (2 * q) k : ℝ) * (Nat.choose (4 * q + 1) (2 * q) : ℝ)
      ≤ (Nat.choose (2 * q) q : ℝ) * (Nat.choose (4 * q + 1) (q + k) : ℝ) := by
  rcases Nat.lt_or_ge k q with h | h
  · exact cross_mono_left q hq k (le_of_lt h)
  · exact cross_mono_right q hq k h hk

/-! ## Integer-division facts for `n = 4q+1` -/

/-- For `n % 4 = 1` write `n = 4q+1`: then `n/4 = q`, `n/2 = 2q`,
`(↑n)/2 = ↑(n/2)`, `(↑n)/4 = ↑(n/4)`. -/
private lemma divfacts_odd (n : ℕ) (hmod : n % 4 = 1) :
    ∃ q, n = 4 * q + 1 ∧ n / 4 = q ∧ n / 2 = 2 * q
      ∧ ((n : ℤ) / 2 = ((n / 2 : ℕ) : ℤ)) ∧ ((n : ℤ) / 4 = ((n / 4 : ℕ) : ℤ)) := by
  refine ⟨n / 4, ?_, rfl, ?_, ?_, ?_⟩
  · omega
  · omega
  · push_cast; omega
  · push_cast; omega

/-! ## Window real-value forms (odd `n`) -/

/-- Real-valued form of `offsetWeight n r` on the window `|r| ≤ n/4` (odd `n`):
`= C(n/2, (r + n/4).toNat) · (1/2)^(n/2)`. -/
private lemma offsetWeight_toReal_window (n : ℕ) (r : ℤ) (hmod : n % 4 = 1)
    (hlo : -((n / 4 : ℕ) : ℤ) ≤ r) (hhi : r ≤ ((n / 4 : ℕ) : ℤ)) :
    (offsetWeight n r).toReal
      = (Nat.choose (n / 2) ((r + ((n / 4 : ℕ) : ℤ)).toNat) : ℝ) * (1 / 2 : ℝ) ^ (n / 2) := by
  obtain ⟨q, hn, hq4, hq2, _, _⟩ := divfacts_odd n hmod
  unfold offsetWeight
  have hkge : (0 : ℤ) ≤ r + ((n / 4 : ℕ) : ℤ) := by omega
  have hkle : r + ((n / 4 : ℕ) : ℤ) ≤ ((n / 2 : ℕ) : ℤ) := by
    rw [show ((n / 2 : ℕ) : ℤ) = 2 * ((n / 4 : ℕ) : ℤ) by rw [hq2, hq4]; push_cast; ring]
    omega
  rw [dif_pos ⟨hkge, hkle⟩, ENNReal.toReal_mul, ENNReal.toReal_natCast]
  congr 1
  rw [ENNReal.toReal_pow, ENNReal.toReal_ofReal (by norm_num : (0:ℝ) ≤ 1 / 2)]

/-- Real-valued form of `binPMFInt n (1/2) (r + n/2)` on the window `|r| ≤ n/4`
(odd `n`): `= C(n, (r + n/2).toNat) · (1/2)^n`, where `n/2` is `(↑n)/2`. -/
private lemma binPMFInt_window (n : ℕ) (r : ℤ) (hmod : n % 4 = 1)
    (hlo : -((n / 4 : ℕ) : ℤ) ≤ r) (hhi : r ≤ ((n / 4 : ℕ) : ℤ)) :
    binPMFInt n (1 / 2) (r + (n / 2 : ℤ))
      = (Nat.choose n ((r + (n / 2 : ℤ)).toNat) : ℝ) * (1 / 2 : ℝ) ^ n := by
  obtain ⟨q, hn, hq4, hq2, hq2', _⟩ := divfacts_odd n hmod
  unfold binPMFInt
  have hq2c : (n : ℤ) / 2 = 2 * ((n / 4 : ℕ) : ℤ) := by rw [hq2', hq2, hq4]; push_cast; ring
  have hkge : (0 : ℤ) ≤ r + (n : ℤ) / 2 := by rw [hq2c]; omega
  have hkle : r + (n : ℤ) / 2 ≤ (n : ℤ) := by
    rw [hq2c, show (n : ℤ) = 4 * ((n / 4 : ℕ) : ℤ) + 1 by rw [hq4]; push_cast [hn]; ring]
    omega
  rw [if_pos ⟨hkge, hkle⟩]
  unfold binPMF
  have htoNat_le : (r + (n : ℤ) / 2).toNat ≤ n := by
    have : (r + (n : ℤ) / 2).toNat ≤ ((n : ℤ)).toNat := by
      apply Int.toNat_le_toNat; omega
    simpa using this
  rw [if_pos htoNat_le]
  have h2 : (1 : ℝ) - 1 / 2 = 1 / 2 := by norm_num
  rw [h2, mul_assoc, ← pow_add]
  congr 2
  omega

/-! ## Tight odd central lower bound -/

/-- For `n = 4q+1`, the denominator central coefficient satisfies
`C(4q+1, 2q) · 2^{-(4q+1)} ≥ 1 / (4√q)`, using the tight Stirling lower bound.
This is the slack needed to reach the exact constant `4/√π` for odd `n`. -/
private lemma odd_central_lower (q : ℕ) (hq : 1 ≤ q) :
    (1 : ℝ) / (4 * Real.sqrt q)
      ≤ (Nat.choose (4 * q + 1) (2 * q) : ℝ) * (2 ^ (4 * q + 1) : ℝ)⁻¹ := by
  -- bridge: 2·C(4q+1,2q) = centralBinom(2q+1)
  have hbridge : 2 * Nat.choose (4*q+1) (2*q) = Nat.centralBinom (2*q+1) := by
    rw [Nat.centralBinom_eq_two_mul_choose]
    have hsymm : Nat.choose (4*q+1) (2*q+1) = Nat.choose (4*q+1) (2*q) := by
      rw [← Nat.choose_symm (by omega : 2*q+1 ≤ 4*q+1)]; congr 1; omega
    have hpascal := Nat.choose_succ_succ (4*q+1) (2*q)
    show 2 * (4*q+1).choose (2*q) = (2*(2*q+1)).choose (2*q+1)
    rw [show 2*(2*q+1) = (4*q+1)+1 by ring, hpascal, hsymm]; ring
  have hbinR : (Nat.choose (4*q+1) (2*q) : ℝ) = (Nat.centralBinom (2*q+1) : ℝ) / 2 := by
    have := congrArg (Nat.cast : ℕ → ℝ) hbridge
    push_cast at this; linarith [this]
  rw [hbinR]
  -- 2^{-(4q+1)} : (centralBinom(2q+1)/2)·2^{-(4q+1)} = centralBinom(2q+1)·4^{-(2q+1)}
  have hpow2 : ((2:ℝ)^(4*q+1)) = 2 * (4:ℝ)^(2*q) := by
    rw [show 4*q+1 = 2*(2*q)+1 by ring, pow_succ, pow_mul]; ring_nf
  rw [hpow2]
  have hlhs_eq : (Nat.centralBinom (2*q+1) : ℝ) / 2 * (2 * (4:ℝ)^(2*q))⁻¹
      = (Nat.centralBinom (2*q+1) : ℝ) * ((4:ℝ)^(2*q+1))⁻¹ := by
    rw [pow_succ]; field_simp; ring
  rw [hlhs_eq]
  -- core lower at k = 2q+1
  have hcore := coreLower (2*q+1) (by omega)
  have hk1 : 1 ≤ 2*q+1 := by omega
  rw [show ((2*q+1:ℕ):ℝ) = 2*(q:ℝ)+1 by push_cast; ring] at hcore
  have h4pos : (0:ℝ) < (4:ℝ)^(2*q+1) := by positivity
  have hsq2q1pos : 0 < Real.sqrt (2*(q:ℝ)+1) := Real.sqrt_pos.mpr (by positivity)
  -- step1: centralBinom(2q+1)·4^{-(2q+1)} ≥ (2√π/e²)/√(2q+1)
  have step1 : (Nat.centralBinom (2*q+1) : ℝ) * ((4:ℝ)^(2*q+1))⁻¹
      ≥ (2 * Real.sqrt Real.pi / (Real.exp 1)^2) / Real.sqrt (2*(q:ℝ)+1) := by
    rw [ge_iff_le, div_le_iff₀ hsq2q1pos] at hcore ⊢
    rw [mul_assoc, mul_comm ((4:ℝ)^(2*q+1))⁻¹ (Real.sqrt (2*(q:ℝ)+1)), ← mul_assoc]
    rw [le_mul_inv_iff₀ h4pos]
    linarith [hcore]
  -- step2: (2√π/e²)/√(2q+1) ≥ 1/(4√q)
  have step2 : (2 * Real.sqrt Real.pi / (Real.exp 1)^2) / Real.sqrt (2*(q:ℝ)+1)
      ≥ 1 / (4 * Real.sqrt q) := by
    rw [ge_iff_le]
    have hqR : (1:ℝ) ≤ (q:ℝ) := by exact_mod_cast hq
    have hsqqpos : 0 < Real.sqrt q := Real.sqrt_pos.mpr (by positivity)
    rw [div_le_div_iff₀ (by positivity) hsq2q1pos, one_mul]
    -- need √(2q+1) ≤ (4√q)·(2√π/e²) = 8√q·√π/e²
    -- square both sides: 2q+1 ≤ 64 q π / e⁴ ; suffices 64π/e⁴ ≥ 2 + 1/q with q≥1
    have hπlb : (3.14 : ℝ) ≤ Real.pi := by linarith [Real.pi_gt_d2]
    have heub : Real.exp 1 ≤ (2.7182818286 : ℝ) := Real.exp_one_lt_d9.le
    have hepos : (0:ℝ) < Real.exp 1 := Real.exp_pos 1
    have he4 : (Real.exp 1)^4 ≤ (2.7182818286:ℝ)^4 := by gcongr
    have he4pos : (0:ℝ) < (Real.exp 1)^4 := by positivity
    have hπpos : (0:ℝ) < Real.pi := Real.pi_pos
    -- Show √(2q+1) ≤ 8√q·√π/e² by squaring
    rw [show (2 * Real.sqrt Real.pi / (Real.exp 1)^2 * (4 * Real.sqrt q))
          = (8 * Real.sqrt Real.pi / (Real.exp 1)^2) * Real.sqrt q by ring]
    apply Real.sqrt_le_iff.mpr
    refine ⟨by positivity, ?_⟩
    have hsq : ((8 * Real.sqrt Real.pi / (Real.exp 1)^2) * Real.sqrt q)^2
        = (64 * (Real.sqrt Real.pi)^2 / (Real.exp 1)^4) * (Real.sqrt q)^2 := by
      rw [mul_pow, div_pow, mul_pow]; ring_nf
    rw [hsq, Real.sq_sqrt hπpos.le, Real.sq_sqrt (by positivity : (0:ℝ) ≤ (q:ℝ))]
    -- goal: 2q+1 ≤ 64·π/e⁴ · q
    rw [div_mul_eq_mul_div, le_div_iff₀ he4pos]
    -- (2q+1)·e⁴ ≤ 64·π·q ; use e⁴ ≤ 2.7182818286⁴ and π ≥ 3.141592653, q ≥ 1
    nlinarith [hπlb, he4, hqR, sq_nonneg (Real.sqrt Real.pi)]
  exact le_trans step2 step1

/-! ## Central-coordinate ratio bound (odd `n`) -/

/-- For `n = 4q+1` with `q ≥ 1`, the offset weight at `r = 0` (its maximum) is
bounded by `Fterm`'s first factor at `r = 0`, with the exact constant `4/√π`:
`offsetWeight n 0 ≤ (4/√π) · binPMFInt n (1/2) (n/2)`. -/
private lemma offsetWeight_le_central_factor_odd (n : ℕ) (hmod : n % 4 = 1) (hn : 5 ≤ n) :
    (offsetWeight n 0).toReal
      ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) ((n : ℤ) / 2) := by
  obtain ⟨q, hnq, hq4, hq2, _, _⟩ := divfacts_odd n hmod
  rw [OffsetWeightFterm.offsetWeight_zero_toReal, OffsetWeightFterm.binPMFInt_central]
  have hq1 : 1 ≤ q := by omega
  -- LHS = C(2q, q)·2^{-2q}  (since n/2 = 2q, n/4 = q)
  have hLHS : (Nat.choose (n / 2) (n / 4) : ℝ) * (1 / 2 : ℝ) ^ (n / 2)
      = (Nat.choose (2*q) q : ℝ) * (2 ^ (2*q) : ℝ)⁻¹ := by
    rw [hq2, hq4, one_div, inv_pow]
  -- RHS factor = C(4q+1, 2q)·2^{-(4q+1)}
  have hRHS : (Nat.choose n (n / 2) : ℝ) * (1 / 2 : ℝ) ^ n
      = (Nat.choose (4*q+1) (2*q) : ℝ) * (2 ^ (4*q+1) : ℝ)⁻¹ := by
    rw [hq2, hnq, one_div, inv_pow]
  rw [hLHS, hRHS]
  -- Stirling upper bound on the numerator (central coord of 2q)
  have hUB := central_binomial_pmf_upper_bound (n := 2*q) (by omega) q
  -- tight lower bound on denominator
  have hLB := odd_central_lower q hq1
  -- positivity
  have hpi_pos : 0 < Real.pi := Real.pi_pos
  have hsqpi_pos : 0 < Real.sqrt Real.pi := Real.sqrt_pos.mpr hpi_pos
  have hqR_pos : (0:ℝ) < (q:ℝ) := by exact_mod_cast hq1
  have hsqq_pos : 0 < Real.sqrt q := Real.sqrt_pos.mpr hqR_pos
  -- constant rewrite: √(2/(π·2q)) = 1/(√π·√q)
  have hconst : Real.sqrt (2 / (Real.pi * ((2*q:ℕ):ℝ))) = 1 / (Real.sqrt Real.pi * Real.sqrt q) := by
    have harg : (2 : ℝ) / (Real.pi * ((2*q:ℕ):ℝ)) = (1 / (Real.sqrt Real.pi * Real.sqrt q))^2 := by
      rw [div_pow, mul_pow, Real.sq_sqrt hpi_pos.le, Real.sq_sqrt hqR_pos.le]
      push_cast; field_simp
    rw [harg, Real.sqrt_sq (by positivity)]
  -- key constant inequality: √(2/(π·2q)) ≤ (4/√π)·(1/(4√q))
  have hkey : Real.sqrt (2 / (Real.pi * ((2*q:ℕ):ℝ))) ≤ (4 / Real.sqrt Real.pi) * (1 / (4 * Real.sqrt q)) := by
    rw [hconst]
    apply le_of_eq
    field_simp
  -- chain: LHS ≤ √(2/(π·2q)) ≤ (4/√π)·(1/(4√q)) ≤ (4/√π)·denom
  calc (Nat.choose (2*q) q : ℝ) * (2 ^ (2*q) : ℝ)⁻¹
      ≤ Real.sqrt (2 / (Real.pi * ((2*q:ℕ):ℝ))) := hUB
    _ ≤ (4 / Real.sqrt Real.pi) * (1 / (4 * Real.sqrt q)) := hkey
    _ ≤ (4 / Real.sqrt Real.pi) * ((Nat.choose (4*q+1) (2*q) : ℝ) * (2 ^ (4*q+1) : ℝ)⁻¹) := by
        apply mul_le_mul_of_nonneg_left hLB
        positivity

/-! ## Main result -/

/-- **Uniform-in-`r` ratio bound for odd `n` (`n % 8 = 1`, `n ≥ 10^12`).**

For every offset `r` in the window `-(n/4) ≤ r ≤ n/4`,

`offsetWeight n r ≤ (4 / √π) · binPMFInt n (1/2) (r + n/2)`.

The constant `C = 4/√π ≈ 2.2568 < 4` is uniform in `r`. The proof routes through
ratio monotonicity (`cross_mono`: the ratio is maximised at `r = 0`) and the
tight central-coordinate bound `offsetWeight_le_central_factor_odd`. -/
theorem offsetWeight_le_uniform_factor_odd (n : ℕ) (hn : (10^12:ℕ) ≤ n) (hmod : n % 8 = 1)
    (r : ℤ) (hlo : -((n/4:ℕ):ℤ) ≤ r) (hhi : r ≤ ((n/4:ℕ):ℤ)) :
    (Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal
      ≤ (4 / Real.sqrt Real.pi)
          * Workspace.Types.AlternatingSumExpression.binPMFInt n (1/2) (r + ((n/2:ℕ):ℤ)) := by
  have hmod4 : n % 4 = 1 := by omega
  obtain ⟨q, hnq, hq4, hq2, hq2', hq4'⟩ := divfacts_odd n hmod4
  have hq1 : 1 ≤ q := by omega
  have hnpos : 1 ≤ n := by omega
  -- normalize the denominator argument: ((n/2:ℕ):ℤ) = (↑n)/2
  have hden_arg : (r + ((n/2:ℕ):ℤ)) = (r + (n : ℤ) / 2) := by rw [hq2']
  rw [hden_arg]
  -- abbreviate numerator index k = (r + q).toNat
  set k := (r + (q : ℤ)).toNat with hk
  have hk_le : k ≤ 2 * q := by rw [hk, hq4] at *; omega
  have hk_eq : (r + ((q : ℕ) : ℤ)) = (k : ℤ) := by
    rw [hk, Int.toNat_of_nonneg (by rw [hq4] at hlo; omega)]
  -- indices
  have hidx_num : (r + ((n / 4 : ℕ) : ℤ)).toNat = k := by rw [hq4, hk]
  have hq2c : (n : ℤ) / 2 = 2 * (q : ℤ) := by rw [hq2', hq2]; push_cast; ring
  have hidx_den : (r + (n : ℤ) / 2).toNat = q + k := by
    rw [hq2c, hk]; rw [hq4] at hlo; omega
  -- numerator real form
  have hNum : (offsetWeight n r).toReal
      = (Nat.choose (2 * q) k : ℝ) * (1 / 2 : ℝ) ^ (2 * q) := by
    rw [offsetWeight_toReal_window n r hmod4 hlo hhi, hidx_num, hq2]
  -- denominator real form
  have hDen : binPMFInt n (1 / 2) (r + (n : ℤ) / 2)
      = (Nat.choose (4 * q + 1) (q + k) : ℝ) * (1 / 2 : ℝ) ^ (4 * q + 1) := by
    have hwin := binPMFInt_window n r hmod4 hlo hhi
    rw [hwin, hidx_den, hnq]
  -- central forms at r = 0
  have hNum0 : (offsetWeight n 0).toReal
      = (Nat.choose (2 * q) q : ℝ) * (1 / 2 : ℝ) ^ (2 * q) := by
    rw [OffsetWeightFterm.offsetWeight_zero_toReal, hq2, hq4]
  have hDen0 : binPMFInt n (1 / 2) ((n : ℤ) / 2)
      = (Nat.choose (4 * q + 1) (2 * q) : ℝ) * (1 / 2 : ℝ) ^ (4 * q + 1) := by
    rw [OffsetWeightFterm.binPMFInt_central, hq2, hnq]
  -- central-coordinate bound
  have hcentral := offsetWeight_le_central_factor_odd n hmod4 (by omega)
  -- cross monotonicity
  have hmono := cross_mono q k hq1 hk_le
  -- positivity facts
  have hpowpos2 : (0 : ℝ) < (1 / 2 : ℝ) ^ (2 * q) := by positivity
  have hpowpos4 : (0 : ℝ) < (1 / 2 : ℝ) ^ (4 * q + 1) := by positivity
  have hCqpos : (0 : ℝ) < (Nat.choose (2 * q) q : ℝ) := choose_pos_real _ _ (by omega)
  have hD2pos : (0 : ℝ) < (Nat.choose (4 * q + 1) (2 * q) : ℝ) := choose_pos_real _ _ (by omega)
  have hDqkpos : (0 : ℝ) < (Nat.choose (4 * q + 1) (q + k) : ℝ) := choose_pos_real _ _ (by omega)
  have hCkpos : (0 : ℝ) ≤ (Nat.choose (2 * q) k : ℝ) := (choose_pos_real _ _ hk_le).le
  have hsqpi : (0 : ℝ) < Real.sqrt Real.pi := Real.sqrt_pos.mpr Real.pi_pos
  have hconst : (0 : ℝ) < 4 / Real.sqrt Real.pi := by positivity
  have hDenpos : 0 < binPMFInt n (1 / 2) (r + (n : ℤ) / 2) := by rw [hDen]; positivity
  have hDen0pos : 0 < binPMFInt n (1 / 2) ((n : ℤ) / 2) := by rw [hDen0]; positivity
  -- Step 1: offsetWeight(r)·binPMFInt(n/2) ≤ offsetWeight(0)·binPMFInt(r+n/2)
  have hstep1 : (offsetWeight n r).toReal * binPMFInt n (1 / 2) ((n : ℤ) / 2)
      ≤ (offsetWeight n 0).toReal * binPMFInt n (1 / 2) (r + (n : ℤ) / 2) := by
    rw [hNum, hDen, hNum0, hDen0]
    have := mul_le_mul_of_nonneg_right hmono (mul_pos hpowpos2 hpowpos4).le
    nlinarith [this, hpowpos2, hpowpos4, hCkpos, hD2pos, hCqpos, hDqkpos]
  -- Step 2: offsetWeight(0)·binPMFInt(r+n/2) ≤ (4/√π)·binPMFInt(n/2)·binPMFInt(r+n/2)
  have hstep2 : (offsetWeight n 0).toReal * binPMFInt n (1 / 2) (r + (n : ℤ) / 2)
      ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) ((n : ℤ) / 2)
          * binPMFInt n (1 / 2) (r + (n : ℤ) / 2) :=
    mul_le_mul_of_nonneg_right hcentral hDenpos.le
  -- combine and cancel binPMFInt(n/2)
  have hcombined : (offsetWeight n r).toReal * binPMFInt n (1 / 2) ((n : ℤ) / 2)
      ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) (r + (n : ℤ) / 2)
          * binPMFInt n (1 / 2) ((n : ℤ) / 2) := by
    calc (offsetWeight n r).toReal * binPMFInt n (1 / 2) ((n : ℤ) / 2)
        ≤ (offsetWeight n 0).toReal * binPMFInt n (1 / 2) (r + (n : ℤ) / 2) := hstep1
      _ ≤ (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) ((n : ℤ) / 2)
            * binPMFInt n (1 / 2) (r + (n : ℤ) / 2) := hstep2
      _ = (4 / Real.sqrt Real.pi) * binPMFInt n (1 / 2) (r + (n : ℤ) / 2)
            * binPMFInt n (1 / 2) ((n : ℤ) / 2) := by ring
  exact le_of_mul_le_mul_right hcombined hDen0pos

end Workspace.ProofLemmas.OffsetWeightUniformRatioOdd
