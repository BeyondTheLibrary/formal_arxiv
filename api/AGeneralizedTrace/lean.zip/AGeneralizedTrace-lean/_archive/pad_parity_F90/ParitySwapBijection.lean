import Mathlib
import Workspace.Types.ProbVec
import Workspace.Types.DelProb
import Workspace.Types.BinVec
import Workspace.Types.LengthsOnlyProcess
import Workspace.Types.PartialDeletionProcess
import Workspace.Types.AlternatingSumExpression
import Workspace.ProofLemmas.ParitySwapReduction
import Workspace.ProofLemmas.ParitySwapCore

open Workspace.Types.BinVec

/-!
`ParitySwapBijection` — alternating-sign assembly bound at the per-summand
level, used in the original (non-axiomatic) proof attempt for
`LengthsDifferenceIsAlternatingSum`.

This lemma's proof depends on a delicate alternating-sign cancellation
across `r` and a parity-symmetry argument that the workspace's available
infrastructure does not directly support. The current
`LengthsDifferenceIsAlternatingSum` instead routes through the paper-cited
axiom `Workspace.PriorWork.paper_lemma_6_algebraic_identity`. This file is
retained as documentation of the breakdown plan; the body is `sorry` and
the lemma is not used by `MainTheorem`.
-/
theorem ParitySwapBijection :
    ∀ (n : ℕ), (10 ^ 12 : ℕ) ≤ n → n % 8 = 1 →
    ∀ (Se So : Workspace.Types.ProbVec.ProbVec n),
      (∀ i : Fin n, Se.p i =
        (if (i.val) % 2 = 0
         then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) *
              Real.sqrt n *
              ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
         else 0)) →
      (∀ i : Fin n, So.p i =
        (if (i.val) % 2 = 1
         then (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) *
              Real.sqrt n *
              ((Nat.choose n i.val : ℝ) * (2 ^ n : ℝ)⁻¹)
         else 0)) →
      ∀ (δ : Workspace.Types.DelProb.DelProb),
        (320 : ℝ) / Real.sqrt n ≤ δ.val → δ.val ≤ 1 / 2 →
        ∀ (lenE : Workspace.Types.LengthsOnlyProcess.LengthsOnlyProcess n Se δ)
          (lenO : Workspace.Types.LengthsOnlyProcess.LengthsOnlyProcess n So δ),
        ∀ (m : Workspace.Types.BinVec.BinVec (n / 2)),
          (∀ j₁ ∈ (Finset.univ : Finset (Fin (n / 2))).filter
                    (fun j => m.bit j = true),
           ∀ j₂ ∈ (Finset.univ : Finset (Fin (n / 2))).filter
                    (fun j => m.bit j = true),
            (j₁.val) % 2 = (j₂.val) % 2) →
          ∀ (zMinus zPlus : ℕ),
            let α : ℝ :=
              (1 / (4 * Real.exp 2 * Real.sqrt (2 * Real.pi))) * Real.sqrt n
            let ell : Finset (Fin (n / 2)) :=
              (Finset.univ : Finset (Fin (n / 2))).filter
                (fun j => m.bit j = true)
            |((lenE.toPMF (m, zMinus, zPlus)).toReal)
                - ((lenO.toPMF (m, zMinus, zPlus)).toReal)|
              ≤ ∑ r ∈ Finset.Icc (-((n / 4 : ℕ) : ℤ)) ((n / 4 : ℕ) : ℤ),
                  (Workspace.Types.PartialDeletionProcess.offsetWeight n r).toReal *
                  (Workspace.Types.LengthsOnlyProcess.prefixLengthWeight n δ r zMinus).toReal *
                  (Workspace.Types.LengthsOnlyProcess.suffixLengthWeight n δ r zPlus).toReal *
                  (∏ j ∈ ell,
                    α *
                      ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                        (2 ^ n : ℝ)⁻¹) /
                    (1 -
                      α *
                        ((Nat.choose n (((n / 4 : ℕ) : ℤ) + r + (j.val : ℤ)).toNat : ℝ) *
                          (2 ^ n : ℝ)⁻¹))) := by
  intro n hn hmod Se So hSe hSo δ hδ_lb hδ_ub lenE lenO m hparity zMinus zPlus
  simp only
  apply ParitySwapReduction n hn hmod Se So hSe hSo δ hδ_lb hδ_ub lenE lenO m zMinus zPlus
  intro Ce Co r hr
  exact ParitySwapCore n hn hmod Se So hSe hSo m hparity Ce Co r hr
