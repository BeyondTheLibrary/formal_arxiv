import Mathlib

open scoped BigOperators

namespace Workspace.Types.LqNorm

/-- The `L_q` norm of a vector `x : Fin d → ℝ`, defined directly via
`Real.rpow`:
`lqNorm q x = (∑ j, |x j| ^ q) ^ (1/q)`.

We avoid `PiLp` / `EuclideanSpace` so the formula textually matches the
paper. The dimension `d` is implicit; the function is total in `q : ℝ`,
but the meaningful basic properties (non-negativity, scaling by a real)
are stated with `1 ≤ q` as required. -/
noncomputable def lqNorm (q : ℝ) {d : ℕ} (x : Fin d → ℝ) : ℝ :=
  (∑ j, |x j| ^ q) ^ ((1 : ℝ) / q)

/-- The inner sum `∑ j, |x j| ^ q` is non-negative. -/
lemma sum_abs_rpow_nonneg (q : ℝ) {d : ℕ} (x : Fin d → ℝ) :
    0 ≤ ∑ j, |x j| ^ q :=
  Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)

/-- `lqNorm q x` is non-negative for any real `q` (since the inner sum
is non-negative and `Real.rpow` of a non-negative base is non-negative). -/
lemma lqNorm_nonneg' (q : ℝ) {d : ℕ} (x : Fin d → ℝ) :
    0 ≤ lqNorm q x :=
  Real.rpow_nonneg (sum_abs_rpow_nonneg q x) _

/-- Spec-named non-negativity (with the `1 ≤ q` hypothesis). -/
lemma lqNorm_nonneg {q : ℝ} (_hq : 1 ≤ q) {d : ℕ} (x : Fin d → ℝ) :
    0 ≤ lqNorm q x :=
  lqNorm_nonneg' q x

/-- The L_q norm of the zero vector is 0. We use `Real.zero_rpow` and
the fact that `∑ j, |0|^q = 0`. -/
lemma lqNorm_zero {q : ℝ} (hq : 1 ≤ q) {d : ℕ} :
    lqNorm q (fun _ : Fin d => (0 : ℝ)) = 0 := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_ne : (1 : ℝ) / q ≠ 0 := by
    rw [one_div]; exact inv_ne_zero hq_ne
  unfold lqNorm
  have hsum : (∑ _j : Fin d, |(0 : ℝ)| ^ q) = 0 := by
    refine Finset.sum_eq_zero ?_
    intro j _
    rw [abs_zero, Real.zero_rpow hq_ne]
  rw [hsum, Real.zero_rpow h_inv_ne]

/-- The L_1 norm is the sum of absolute values. -/
lemma lqNorm_one_eq_sum_abs {d : ℕ} (x : Fin d → ℝ) :
    lqNorm 1 x = ∑ j, |x j| := by
  unfold lqNorm
  simp [Real.rpow_one]

/-- Scaling by a real `c`: `lqNorm q (c • x) = |c| * lqNorm q x`. -/
lemma lqNorm_smul {q : ℝ} (hq : 1 ≤ q) {d : ℕ} (c : ℝ) (x : Fin d → ℝ) :
    lqNorm q (fun j => c * x j) = |c| * lqNorm q x := by
  unfold lqNorm
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  -- Step 1: |c * x j| ^ q = |c|^q * |x j|^q, then factor the sum
  have h1 : (∑ j, |c * x j| ^ q) = |c| ^ q * ∑ j, |x j| ^ q := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl ?_
    intro j _
    rw [abs_mul, Real.mul_rpow (abs_nonneg _) (abs_nonneg _)]
  rw [h1]
  -- Step 2: distribute the outer rpow over the product
  have hcq_nn : 0 ≤ |c| ^ q := Real.rpow_nonneg (abs_nonneg _) q
  have hsum_nn : 0 ≤ ∑ j, |x j| ^ q := sum_abs_rpow_nonneg q x
  rw [Real.mul_rpow hcq_nn hsum_nn]
  -- Step 3: (|c|^q)^(1/q) = |c|, since q * (1/q) = 1 and |c| ≥ 0.
  have habs_nn : (0 : ℝ) ≤ |c| := abs_nonneg _
  have h2 : (|c| ^ q) ^ ((1 : ℝ) / q) = |c| := by
    rw [← Real.rpow_mul habs_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  rw [h2]

/-- (Optional, sanity) `lqNorm q` on a 1-dimensional vector is `|x 0|`. -/
lemma lqNorm_dim_one {q : ℝ} (hq : 1 ≤ q) (x : Fin 1 → ℝ) :
    lqNorm q x = |x 0| := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  unfold lqNorm
  rw [Fin.sum_univ_one]
  rw [← Real.rpow_mul (abs_nonneg _), mul_one_div, div_self hq_ne, Real.rpow_one]

/-- (Optional, sanity) `lqNorm q` on a 0-dimensional vector is `0`. -/
lemma lqNorm_dim_zero {q : ℝ} (hq : 1 ≤ q) (x : Fin 0 → ℝ) :
    lqNorm q x = 0 := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_ne : (1 : ℝ) / q ≠ 0 := by
    rw [one_div]; exact inv_ne_zero hq_ne
  unfold lqNorm
  have : (∑ j : Fin 0, |x j| ^ q) = 0 := by
    rw [Fin.sum_univ_zero]
  rw [this, Real.zero_rpow h_inv_ne]

end Workspace.Types.LqNorm

/-!
# Coordinate-wise median predicate

This file defines the predicate `IsCoordinateMedian` saying that a vector
`m : Fin d → ℝ` is a coordinate-wise median of an instance
`P : Fin n → Fin d → ℝ`, in the sense that for every coordinate `j`,
both `#{i : P i j < m j}` and `#{i : P i j > m j}` are at most `n / 2`
(natural-number integer division).

The existence theorem `exists_coordinateMedian` shows that every instance
admits a coordinate-wise median; we construct one by sorting each
coordinate and taking the `n / 2`-th order statistic.
-/

namespace Workspace.Types.CoordinateMedian

open Finset

/-- A vector `m : Fin d → ℝ` is a *coordinate-wise median* of the instance
`P : Fin n → Fin d → ℝ` if for every coordinate `j`, both the number of
indices `i` with `P i j < m j` and the number of indices with
`P i j > m j` are at most `n / 2` (natural-number integer division).

When `n` is even, this gives `n / 2` on each side; when `n` is odd, this
gives `⌊n/2⌋ = (n - 1) / 2` on each side. The predicate models arbitrary
tie-breaking: many `m` will satisfy it for typical instances. -/
def IsCoordinateMedian {n d : ℕ} (m : Fin d → ℝ) (P : Fin n → Fin d → ℝ) : Prop :=
  ∀ j : Fin d,
    (Finset.univ.filter (fun i : Fin n => P i j < m j)).card ≤ n / 2 ∧
    (Finset.univ.filter (fun i : Fin n => P i j > m j)).card ≤ n / 2

/-- Helper lemma: for a monotone function `g : Fin n → ℝ`, choosing the
`n / 2`-th order statistic gives both upper bounds. -/
private lemma monotone_median_bounds {n : ℕ} (g : Fin n → ℝ) (hg : Monotone g)
    (hn : 0 < n) :
    let k : Fin n := ⟨n / 2, Nat.div_lt_of_lt_mul (by
      have : n ≤ n * 2 := Nat.le_mul_of_pos_right _ (by decide)
      omega)⟩
    (Finset.univ.filter (fun i : Fin n => g i < g k)).card ≤ n / 2 ∧
    (Finset.univ.filter (fun i : Fin n => g i > g k)).card ≤ n / 2 := by
  intro k
  refine ⟨?_, ?_⟩
  · -- {i : g i < g k} ⊆ {i : i.val < n/2}
    have hsub : (Finset.univ.filter (fun i : Fin n => g i < g k)) ⊆
        (Finset.univ.filter (fun i : Fin n => i.val < n / 2)) := by
      intro i hi
      simp only [mem_filter, mem_univ, true_and] at hi ⊢
      by_contra hi'
      have hi'' : n / 2 ≤ i.val := Nat.le_of_not_lt hi'
      -- i.val ≥ n/2 = k.val, so by monotone g i ≥ g k, contradicting g i < g k
      have : k ≤ i := by
        change k.val ≤ i.val
        exact hi''
      have := hg this
      linarith
    refine le_trans (card_le_card hsub) ?_
    -- card of {i : i.val < n/2} is exactly min(n, n/2) = n/2 (since n/2 ≤ n)
    have : (Finset.univ.filter (fun i : Fin n => i.val < n / 2)).card = n / 2 := by
      rw [show (Finset.univ.filter (fun i : Fin n => i.val < n / 2)) =
        (Finset.range (n / 2)).attachFin (fun m hm => by
          simp at hm
          exact lt_of_lt_of_le hm (Nat.div_le_self n 2)) from ?_]
      · simp
      · ext i
        simp [Finset.mem_attachFin]
    omega
  · -- {i : g i > g k} ⊆ {i : i.val > n/2}, which has cardinality n - n/2 - 1 ≤ n/2
    have hsub : (Finset.univ.filter (fun i : Fin n => g i > g k)) ⊆
        (Finset.univ.filter (fun i : Fin n => i.val > n / 2)) := by
      intro i hi
      simp only [mem_filter, mem_univ, true_and] at hi ⊢
      by_contra hi'
      have hi'' : i.val ≤ n / 2 := Nat.le_of_not_lt hi'
      have : i ≤ k := by
        change i.val ≤ k.val
        exact hi''
      have := hg this
      linarith
    refine le_trans (card_le_card hsub) ?_
    -- card of {i : i.val > n/2} = n - (n/2 + 1)
    have hle : (Finset.univ.filter (fun i : Fin n => i.val ≤ n / 2)).card = n / 2 + 1 := by
      rw [show (Finset.univ.filter (fun i : Fin n => i.val ≤ n / 2)) =
        (Finset.range (n / 2 + 1)).attachFin (fun m hm => by
          simp at hm
          omega) from ?_]
      · simp
      · ext i
        simp [Finset.mem_attachFin]
    have hsum :
        (Finset.univ.filter (fun i : Fin n => i.val > n / 2)).card +
        (Finset.univ.filter (fun i : Fin n => i.val ≤ n / 2)).card = n := by
      rw [← card_union_of_disjoint, show
        (Finset.univ.filter (fun i : Fin n => i.val > n / 2)) ∪
        (Finset.univ.filter (fun i : Fin n => i.val ≤ n / 2)) = Finset.univ from ?_]
      · simp
      · ext i; simp; omega
      · rw [disjoint_filter]
        intros; omega
    omega

/-- Every instance `P : Fin n → Fin d → ℝ` admits a coordinate-wise
median. We construct one by sorting each coordinate independently and
taking the `n / 2`-th order statistic. -/
theorem exists_coordinateMedian (n d : ℕ) (P : Fin n → Fin d → ℝ) :
    ∃ m, IsCoordinateMedian m P := by
  classical
  by_cases hn : n = 0
  · -- vacuous: all filters over Fin 0 have cardinality 0
    refine ⟨fun _ => 0, ?_⟩
    intro j
    subst hn
    refine ⟨?_, ?_⟩ <;> simp
  -- n ≥ 1
  have hn' : 0 < n := Nat.pos_of_ne_zero hn
  -- For each coordinate j, define m j as the n/2-th value of the sorted j-th column.
  refine ⟨fun j => P (Tuple.sort (fun i => P i j) ⟨n / 2,
    Nat.div_lt_of_lt_mul (by
      have hh : n ≤ n * 2 := Nat.le_mul_of_pos_right _ (by decide)
      omega)⟩) j, ?_⟩
  intro j
  -- Let f i = P i j; let σ = Tuple.sort f. Then g := f ∘ σ is monotone.
  set f : Fin n → ℝ := fun i => P i j with hf
  set σ : Equiv.Perm (Fin n) := Tuple.sort f with hσ
  set g : Fin n → ℝ := f ∘ σ with hg_def
  have hg_mono : Monotone g := Tuple.monotone_sort f
  set k : Fin n := ⟨n / 2, Nat.div_lt_of_lt_mul (by
    have hh : n ≤ n * 2 := Nat.le_mul_of_pos_right _ (by decide)
    omega)⟩ with hk_def
  -- The chosen median is f (σ k) = g k
  have hm_eq : (fun j' => P (Tuple.sort (fun i => P i j') ⟨n / 2,
      Nat.div_lt_of_lt_mul (by
        have hh : n ≤ n * 2 := Nat.le_mul_of_pos_right _ (by decide)
        omega)⟩) j') j = g k := by
    simp [hg_def, hf, hσ, hk_def]
  rw [hm_eq]
  -- Bounds for g via monotone_median_bounds
  obtain ⟨hlt, hgt⟩ := monotone_median_bounds g hg_mono hn'
  -- Translate cardinality of {i : f i < g k} to {i : g i < g k} via the bijection σ
  refine ⟨?_, ?_⟩
  · -- card {i : P i j < g k} ≤ n / 2
    have heq : (Finset.univ.filter (fun i : Fin n => P i j < g k)).card =
        (Finset.univ.filter (fun i : Fin n => g i < g k)).card := by
      apply Finset.card_bij (fun i _ => σ.symm i)
      · intro i hi
        simp only [mem_filter, mem_univ, true_and] at hi ⊢
        show f (σ (σ.symm i)) < g k
        rw [σ.apply_symm_apply]
        exact hi
      · intros a _ b _ hab
        exact σ.symm.injective hab
      · intro i hi
        simp only [mem_filter, mem_univ, true_and] at hi
        refine ⟨σ i, ?_, ?_⟩
        · simp only [mem_filter, mem_univ, true_and]
          show f (σ i) < g k
          exact hi
        · simp
    rw [heq]
    exact hlt
  · -- card {i : P i j > g k} ≤ n / 2
    have heq : (Finset.univ.filter (fun i : Fin n => P i j > g k)).card =
        (Finset.univ.filter (fun i : Fin n => g i > g k)).card := by
      apply Finset.card_bij (fun i _ => σ.symm i)
      · intro i hi
        simp only [mem_filter, mem_univ, true_and] at hi ⊢
        show f (σ (σ.symm i)) > g k
        rw [σ.apply_symm_apply]
        exact hi
      · intros a _ b _ hab
        exact σ.symm.injective hab
      · intro i hi
        simp only [mem_filter, mem_univ, true_and] at hi
        refine ⟨σ i, ?_, ?_⟩
        · simp only [mem_filter, mem_univ, true_and]
          show f (σ i) > g k
          exact hi
        · simp
    rw [heq]
    exact hgt

/-- When `d = 0`, every vector `m : Fin 0 → ℝ` is a coordinate-wise median of
every placement `P : Fin n → Fin 0 → ℝ`. The predicate's universal quantifier
over `Fin 0` is vacuous. -/
theorem isCoordinateMedian_dim_zero {n : ℕ} (m : Fin 0 → ℝ) (P : Fin n → Fin 0 → ℝ) :
    IsCoordinateMedian m P := by
  intro j
  exact j.elim0

/-- When `n = 1`, `IsCoordinateMedian m P` is equivalent to `m = P 0`: with a
single placement, the median predicate forces `m` to coincide with that
placement on every coordinate. -/
theorem isCoordinateMedian_unique_singleton {d : ℕ} (m : Fin d → ℝ) (P : Fin 1 → Fin d → ℝ) :
    IsCoordinateMedian m P ↔ m = P 0 := by
  classical
  constructor
  · intro h
    funext j
    obtain ⟨hlt, hgt⟩ := h j
    -- 1 / 2 = 0, so both filtered sets must be empty.
    have hlt0 : (Finset.univ.filter (fun i : Fin 1 => P i j < m j)).card = 0 := by
      have : (1 : ℕ) / 2 = 0 := rfl
      omega
    have hgt0 : (Finset.univ.filter (fun i : Fin 1 => P i j > m j)).card = 0 := by
      have : (1 : ℕ) / 2 = 0 := rfl
      omega
    have hlt_empty : ¬ (P 0 j < m j) := by
      intro hcontr
      have : (0 : Fin 1) ∈ Finset.univ.filter (fun i : Fin 1 => P i j < m j) := by
        simp [hcontr]
      have : 0 < (Finset.univ.filter (fun i : Fin 1 => P i j < m j)).card :=
        Finset.card_pos.mpr ⟨0, this⟩
      omega
    have hgt_empty : ¬ (P 0 j > m j) := by
      intro hcontr
      have : (0 : Fin 1) ∈ Finset.univ.filter (fun i : Fin 1 => P i j > m j) := by
        simp [hcontr]
      have : 0 < (Finset.univ.filter (fun i : Fin 1 => P i j > m j)).card :=
        Finset.card_pos.mpr ⟨0, this⟩
      omega
    -- Trichotomy on ℝ: not <, not >, so equal. Statement is `m j = P 0 j`.
    have : P 0 j = m j := le_antisymm (not_lt.mp hgt_empty) (not_lt.mp hlt_empty)
    exact this.symm
  · intro hm
    intro j
    -- Under `m = P 0`, `m j = P 0 j`, so neither strict inequality can hold for
    -- the only index `0 : Fin 1`.
    have hmj : m j = P 0 j := by rw [hm]
    have hlt_empty :
        (Finset.univ.filter (fun i : Fin 1 => P i j < m j)) = ∅ := by
      ext i
      simp only [mem_filter, mem_univ, true_and, Finset.notMem_empty, iff_false]
      have hi0 : i = 0 := Subsingleton.elim _ _
      rw [hi0, hmj]
      exact lt_irrefl _
    have hgt_empty :
        (Finset.univ.filter (fun i : Fin 1 => P i j > m j)) = ∅ := by
      ext i
      simp only [mem_filter, mem_univ, true_and, Finset.notMem_empty, iff_false]
      have hi0 : i = 0 := Subsingleton.elim _ _
      rw [hi0, hmj]
      exact lt_irrefl _
    refine ⟨?_, ?_⟩
    · rw [hlt_empty]; simp
    · rw [hgt_empty]; simp

end Workspace.Types.CoordinateMedian

open scoped BigOperators
open Workspace.Types.LqNorm

namespace Workspace.Types.SocialCost

/-- The social cost of placing a facility at `f : Fin d → ℝ` for `n`
agents whose preferred locations are the rows of `P : Fin n → Fin d → ℝ`,
measured under the `L_q` norm:
`socialCost q P f = ∑_{i=1}^n lqNorm q (p_i − f)`,
where `(p_i − f) j = P i j − f j`. -/
noncomputable def socialCost (q : ℝ) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) : ℝ :=
  ∑ i, lqNorm q (fun j => P i j - f j)

/-- The optimal social cost is the infimum over all facility locations. -/
noncomputable def optSocialCost (q : ℝ) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) : ℝ :=
  ⨅ f, socialCost q P f

/-- The social cost is non-negative whenever `1 ≤ q`. -/
lemma socialCost_nonneg {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) :
    0 ≤ socialCost q P f := by
  unfold socialCost
  exact Finset.sum_nonneg (fun i _ => lqNorm_nonneg hq _)

/-- With zero agents the social cost is `0` for every facility location
and every `q`. -/
lemma socialCost_empty_agents :
    ∀ (q : ℝ), ∀ (d : ℕ) (P : Fin 0 → Fin d → ℝ) (f : Fin d → ℝ),
      socialCost q P f = 0 := by
  intro q d P f
  unfold socialCost
  exact Fin.sum_univ_zero _

/-- The set of social costs (over all facility locations) is bounded below
by `0` whenever `1 ≤ q`. -/
lemma socialCost_bddBelow {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) :
    BddBelow (Set.range (socialCost q P)) := by
  refine ⟨0, ?_⟩
  rintro x ⟨f, rfl⟩
  exact socialCost_nonneg hq P f

/-- The optimal social cost is a lower bound for the social cost at every
facility location (under `1 ≤ q`, which gives `BddBelow`). -/
lemma optSocialCost_le_socialCost {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) :
    optSocialCost q P ≤ socialCost q P f := by
  unfold optSocialCost
  exact ciInf_le (socialCost_bddBelow hq P) f

/-- The optimal social cost is non-negative under `1 ≤ q`. -/
lemma optSocialCost_nonneg {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) :
    0 ≤ optSocialCost q P := by
  unfold optSocialCost
  exact le_ciInf (fun f => socialCost_nonneg hq P f)

end Workspace.Types.SocialCost

namespace Workspace.ProofLemmas.FqSignAt0Pos

noncomputable def F_q (q a : ℝ) : ℝ :=
  2 * (1 - 1/q) * a + (1/q) * a ^ ((1 - q) / q) - 2 + 1/q

end Workspace.ProofLemmas.FqSignAt0Pos

open Workspace.ProofLemmas.FqSignAt0Pos

theorem FqSignAt0Pos (q : ℝ) (hq : 1 < q) :
    Filter.Tendsto (fun a => F_q q a) (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop := by
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_inv_pos : (0 : ℝ) < 1 / q := by positivity
  have hexp_neg : (1 - q) / q < 0 := by
    apply div_neg_of_neg_of_pos
    · linarith
    · exact hq_pos
  -- a^((1-q)/q) → +∞ as a → 0+
  have h_rpow : Filter.Tendsto (fun a : ℝ => a ^ ((1 - q) / q))
      (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    tendsto_rpow_neg_nhdsGT_zero hexp_neg
  -- (1/q) * a^((1-q)/q) → +∞
  have h_rpow_scaled : Filter.Tendsto (fun a : ℝ => (1/q) * a ^ ((1 - q) / q))
      (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    h_rpow.const_mul_atTop' hq_inv_pos
  -- The remaining terms tend to a finite limit
  -- 2*(1 - 1/q)*a + (-2 + 1/q) → -2 + 1/q as a → 0
  have h_nhds_zero : Filter.Tendsto (fun a : ℝ => a) (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
    exact (continuous_id.tendsto 0).mono_left nhdsWithin_le_nhds
  have h_lin : Filter.Tendsto (fun a : ℝ => 2 * (1 - 1/q) * a)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds (2 * (1 - 1/q) * 0)) :=
    h_nhds_zero.const_mul _
  have h_lin0 : Filter.Tendsto (fun a : ℝ => 2 * (1 - 1/q) * a)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
    have : 2 * (1 - 1/q) * (0 : ℝ) = 0 := by ring
    rw [this] at h_lin
    exact h_lin
  have h_other : Filter.Tendsto (fun a : ℝ => 2 * (1 - 1/q) * a + (-2 + 1/q))
      (nhdsWithin 0 (Set.Ioi 0)) (nhds (0 + (-2 + 1/q))) :=
    h_lin0.add tendsto_const_nhds
  -- Now combine: ((1/q) * a^((1-q)/q)) + (2*(1-1/q)*a + (-2 + 1/q)) → +∞
  have h_sum : Filter.Tendsto
      (fun a : ℝ => (1/q) * a ^ ((1 - q) / q) + (2 * (1 - 1/q) * a + (-2 + 1/q)))
      (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    h_rpow_scaled.atTop_add h_other
  -- Show F_q q a equals our sum
  have heq : (fun a : ℝ => F_q q a) =
      fun a : ℝ => (1/q) * a ^ ((1 - q) / q) + (2 * (1 - 1/q) * a + (-2 + 1/q)) := by
    funext a
    simp only [F_q]
    ring
  rw [heq]
  exact h_sum

open Workspace.ProofLemmas.FqSignAt0Pos

theorem FqStrictConvex (q : ℝ) (hq : 1 < q) :
    StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) := by
  set p : ℝ := (1 - q) / q with hp_def
  have hq_pos : 0 < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_inv_pos : 0 < 1 / q := by positivity
  have hp_neg : p < 0 := by
    have h1 : 1 - q < 0 := by linarith
    exact div_neg_of_neg_of_pos h1 hq_pos
  have hp_minus_one_neg : p - 1 < 0 := by linarith
  have hpp1_pos : 0 < p * (p - 1) := mul_pos_of_neg_of_neg hp_neg hp_minus_one_neg
  -- Define helper: linear coefficient.
  set c1 : ℝ := 2 * (1 - 1 / q) with hc1_def
  set c2 : ℝ := 1 / q with hc2_def
  set c3 : ℝ := -2 + 1 / q with hc3_def
  -- Rewrite F_q q a = c1 * a + c2 * a^p + c3 (for any a).
  have hFq_eq : ∀ a : ℝ, F_q q a = c1 * a + c2 * a ^ p + c3 := by
    intro a
    simp [F_q, c1, c2, c3, p]
    ring
  -- Continuity on Ioi 0.
  have hCont : ContinuousOn (fun a => F_q q a) (Set.Ioi (0 : ℝ)) := by
    refine ContinuousOn.congr ?_ (fun a _ => hFq_eq a)
    refine ((continuousOn_const.mul continuousOn_id).add ?_).add continuousOn_const
    refine continuousOn_const.mul ?_
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    exact (Real.continuousAt_rpow_const a p (Or.inl ha_ne)).continuousWithinAt
  -- First derivative on Ioi 0: F_q' a = c1 + c2 * p * a^(p-1).
  have hFq_deriv : ∀ a ∈ Set.Ioi (0 : ℝ),
      HasDerivAt (fun a => F_q q a) (c1 + c2 * (p * a ^ (p - 1))) a := by
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    have hd_lin : HasDerivAt (fun y : ℝ => c1 * y) c1 a := by
      simpa using (hasDerivAt_id a).const_mul c1
    have hd_rpow : HasDerivAt (fun y : ℝ => y ^ p) (p * a ^ (p - 1)) a :=
      Real.hasDerivAt_rpow_const (Or.inl ha_ne)
    have hd_smul : HasDerivAt (fun y : ℝ => c2 * y ^ p) (c2 * (p * a ^ (p - 1))) a :=
      hd_rpow.const_mul c2
    have hd_sum : HasDerivAt (fun y : ℝ => c1 * y + c2 * y ^ p)
        (c1 + c2 * (p * a ^ (p - 1))) a := hd_lin.add hd_smul
    have hd_const : HasDerivAt (fun y : ℝ => c1 * y + c2 * y ^ p + c3)
        (c1 + c2 * (p * a ^ (p - 1))) a := hd_sum.add_const c3
    -- congr to F_q
    have hcongr : (fun y : ℝ => F_q q y) = (fun y => c1 * y + c2 * y ^ p + c3) := by
      funext y
      exact hFq_eq y
    rw [hcongr]
    exact hd_const
  -- Now apply strictConvexOn_of_deriv2_pos.
  apply strictConvexOn_of_deriv2_pos (convex_Ioi 0) hCont
  intro a ha
  rw [interior_Ioi] at ha
  have ha_pos : 0 < a := ha
  have ha_ne : a ≠ 0 := ne_of_gt ha_pos
  -- Show deriv (deriv F_q) a > 0.
  -- Step 1: deriv F_q is eventually equal to a ↦ c1 + c2 * (p * a^(p-1)) on Ioi 0.
  have hIoi_open : IsOpen (Set.Ioi (0 : ℝ)) := isOpen_Ioi
  have hnhds : Set.Ioi (0 : ℝ) ∈ nhds a := hIoi_open.mem_nhds ha_pos
  -- deriv F_q =ᶠ[𝓝 a] fun y => c1 + c2 * (p * y^(p-1))
  have hderiv_eq : deriv (fun a => F_q q a)
      =ᶠ[nhds a] (fun y => c1 + c2 * (p * y ^ (p - 1))) := by
    filter_upwards [hnhds] with y hy
    exact (hFq_deriv y hy).deriv
  -- Therefore deriv (deriv F_q) a = deriv (fun y => c1 + c2 * (p * y^(p-1))) a
  have hd2_eq : deriv (deriv (fun a => F_q q a)) a =
      deriv (fun y => c1 + c2 * (p * y ^ (p - 1))) a :=
    hderiv_eq.deriv_eq
  show 0 < deriv^[2] (fun a => F_q q a) a
  simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
  rw [hd2_eq]
  -- Now compute deriv (fun y => c1 + c2 * (p * y^(p-1))) a.
  have hd_inner : HasDerivAt (fun y : ℝ => y ^ (p - 1))
      ((p - 1) * a ^ (p - 1 - 1)) a :=
    Real.hasDerivAt_rpow_const (Or.inl ha_ne)
  have hd_mul1 : HasDerivAt (fun y : ℝ => p * y ^ (p - 1))
      (p * ((p - 1) * a ^ (p - 1 - 1))) a := hd_inner.const_mul p
  have hd_mul2 : HasDerivAt (fun y : ℝ => c2 * (p * y ^ (p - 1)))
      (c2 * (p * ((p - 1) * a ^ (p - 1 - 1)))) a := hd_mul1.const_mul c2
  have hd_total : HasDerivAt (fun y : ℝ => c1 + c2 * (p * y ^ (p - 1)))
      (c2 * (p * ((p - 1) * a ^ (p - 1 - 1)))) a := hd_mul2.const_add c1
  rw [hd_total.deriv]
  -- c2 * (p * ((p-1) * a^(p-2))) > 0
  have ha_rpow_pos : 0 < a ^ (p - 1 - 1) := Real.rpow_pos_of_pos ha_pos _
  have : 0 < c2 * (p * ((p - 1) * a ^ (p - 1 - 1))) := by
    apply mul_pos hq_inv_pos
    rw [show p * ((p - 1) * a ^ (p - 1 - 1)) = (p * (p - 1)) * a ^ (p - 1 - 1) by ring]
    exact mul_pos hpp1_pos ha_rpow_pos
  exact this

open Workspace.ProofLemmas.FqSignAt0Pos

theorem FqDerivMonotone (q : ℝ) (hq : 1 < q) :
    StrictMonoOn (deriv (fun a => F_q q a)) (Set.Ioi (0 : ℝ)) ∧
      Filter.Tendsto (deriv (fun a => F_q q a)) (nhdsWithin 0 (Set.Ioi 0)) Filter.atBot ∧
      Filter.Tendsto (deriv (fun a => F_q q a)) Filter.atTop (nhds (2 * (1 - 1/q))) := by
  set p : ℝ := (1 - q) / q with hp_def
  have hq_pos : 0 < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_inv_pos : 0 < 1 / q := by positivity
  have hp_neg : p < 0 := by
    have h1 : 1 - q < 0 := by linarith
    exact div_neg_of_neg_of_pos h1 hq_pos
  have hp_minus_one_neg : p - 1 < 0 := by linarith
  set c1 : ℝ := 2 * (1 - 1 / q) with hc1_def
  set c2 : ℝ := 1 / q with hc2_def
  set c3 : ℝ := -2 + 1 / q with hc3_def
  -- Rewrite F_q q a = c1 * a + c2 * a^p + c3.
  have hFq_eq : ∀ a : ℝ, F_q q a = c1 * a + c2 * a ^ p + c3 := by
    intro a
    simp [F_q, c1, c2, c3, p]
    ring
  -- Pointwise derivative on Ioi 0.
  have hFq_deriv : ∀ a ∈ Set.Ioi (0 : ℝ),
      HasDerivAt (fun a => F_q q a) (c1 + c2 * (p * a ^ (p - 1))) a := by
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    have hd_lin : HasDerivAt (fun y : ℝ => c1 * y) c1 a := by
      simpa using (hasDerivAt_id a).const_mul c1
    have hd_rpow : HasDerivAt (fun y : ℝ => y ^ p) (p * a ^ (p - 1)) a :=
      Real.hasDerivAt_rpow_const (Or.inl ha_ne)
    have hd_smul : HasDerivAt (fun y : ℝ => c2 * y ^ p) (c2 * (p * a ^ (p - 1))) a :=
      hd_rpow.const_mul c2
    have hd_sum : HasDerivAt (fun y : ℝ => c1 * y + c2 * y ^ p)
        (c1 + c2 * (p * a ^ (p - 1))) a := hd_lin.add hd_smul
    have hd_const : HasDerivAt (fun y : ℝ => c1 * y + c2 * y ^ p + c3)
        (c1 + c2 * (p * a ^ (p - 1))) a := hd_sum.add_const c3
    have hcongr : (fun y : ℝ => F_q q y) = (fun y => c1 * y + c2 * y ^ p + c3) := by
      funext y
      exact hFq_eq y
    rw [hcongr]
    exact hd_const
  -- DifferentiableAt for each a ∈ Ioi 0.
  have hDiff : ∀ a ∈ Set.Ioi (0 : ℝ), DifferentiableAt ℝ (fun a => F_q q a) a := by
    intro a ha
    exact (hFq_deriv a ha).differentiableAt
  -- The derivative formula: deriv F_q a = c1 + c2 * (p * a^(p-1)) for a ∈ Ioi 0.
  have hDerivEq : ∀ a ∈ Set.Ioi (0 : ℝ),
      deriv (fun a => F_q q a) a = c1 + c2 * (p * a ^ (p - 1)) := by
    intro a ha
    exact (hFq_deriv a ha).deriv
  refine ⟨?_, ?_, ?_⟩
  · -- StrictMonoOn (deriv F_q) (Ioi 0): use FqStrictConvex.
    have hConv : StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) :=
      FqStrictConvex q hq
    exact hConv.strictMonoOn_deriv hDiff
  · -- Tendsto deriv F_q at 0+ to atBot.
    -- deriv F_q =ᶠ[nhdsWithin 0 (Ioi 0)] (fun a => c1 + (c2 * p) * a^(p-1))
    have hK_neg : c2 * p < 0 := by
      have : c2 > 0 := hq_inv_pos
      exact mul_neg_of_pos_of_neg this hp_neg
    -- Eventually equal on nhdsWithin 0 (Ioi 0).
    have hEv : (fun a => deriv (fun a => F_q q a) a) =ᶠ[nhdsWithin (0:ℝ) (Set.Ioi 0)]
        (fun a => c1 + (c2 * p) * a ^ (p - 1)) := by
      filter_upwards [self_mem_nhdsWithin] with a ha
      have ha_pos : (0:ℝ) < a := ha
      rw [hDerivEq a ha_pos]
      ring
    -- (fun a => a^(p-1)) tends to atTop on nhdsWithin 0 (Ioi 0).
    have hTendsRpow : Filter.Tendsto (fun a : ℝ => a ^ (p - 1))
        (nhdsWithin (0:ℝ) (Set.Ioi 0)) Filter.atTop :=
      tendsto_rpow_neg_nhdsGT_zero hp_minus_one_neg
    -- (fun a => a^(p-1) * (c2 * p)) tends to atBot.
    have hTendsMul : Filter.Tendsto (fun a : ℝ => a ^ (p - 1) * (c2 * p))
        (nhdsWithin (0:ℝ) (Set.Ioi 0)) Filter.atBot :=
      hTendsRpow.atTop_mul_const_of_neg hK_neg
    -- Convert (fun a => a^(p-1) * (c2 * p)) ↦ (fun a => (c2 * p) * a^(p-1)).
    have hTendsMul' : Filter.Tendsto (fun a : ℝ => (c2 * p) * a ^ (p - 1))
        (nhdsWithin (0:ℝ) (Set.Ioi 0)) Filter.atBot := by
      convert hTendsMul using 1
      funext a
      ring
    -- Add c1 on the left → atBot.
    have hTendsAdd : Filter.Tendsto (fun a : ℝ => c1 + (c2 * p) * a ^ (p - 1))
        (nhdsWithin (0:ℝ) (Set.Ioi 0)) Filter.atBot :=
      Filter.tendsto_atBot_add_const_left _ c1 hTendsMul'
    -- Use EventuallyEq.
    exact hTendsAdd.congr' hEv.symm
  · -- Tendsto deriv F_q at atTop to nhds (2 * (1 - 1/q)) = nhds c1.
    have hEv : (fun a => deriv (fun a => F_q q a) a) =ᶠ[(Filter.atTop : Filter ℝ)]
        (fun a => c1 + (c2 * p) * a ^ (p - 1)) := by
      filter_upwards [Filter.eventually_gt_atTop (0:ℝ)] with a ha_pos
      rw [hDerivEq a ha_pos]
      ring
    -- (fun a => a^(p-1)) → 0 at atTop.
    have hTendsRpow : Filter.Tendsto (fun a : ℝ => a ^ (p - 1))
        Filter.atTop (nhds 0) := by
      have : Filter.Tendsto (fun a : ℝ => a ^ (-(1 - p))) Filter.atTop (nhds 0) :=
        tendsto_rpow_neg_atTop (by linarith)
      convert this using 1
      funext a
      congr 1
      ring
    -- (c2 * p) * a^(p-1) → 0.
    have hTendsConstMul : Filter.Tendsto (fun a : ℝ => (c2 * p) * a ^ (p - 1))
        Filter.atTop (nhds ((c2 * p) * 0)) :=
      hTendsRpow.const_mul (c2 * p)
    have hTendsConstMul0 : Filter.Tendsto (fun a : ℝ => (c2 * p) * a ^ (p - 1))
        Filter.atTop (nhds 0) := by
      simpa using hTendsConstMul
    -- c1 + (c2 * p) * a^(p-1) → c1 + 0 = c1.
    have hTendsAdd : Filter.Tendsto (fun a : ℝ => c1 + (c2 * p) * a ^ (p - 1))
        Filter.atTop (nhds (c1 + 0)) :=
      hTendsConstMul0.const_add c1
    have hTendsAdd' : Filter.Tendsto (fun a : ℝ => c1 + (c2 * p) * a ^ (p - 1))
        Filter.atTop (nhds c1) := by simpa using hTendsAdd
    -- The goal target is `nhds (2 * (1 - 1/q))` = `nhds c1` (set substituted).
    exact hTendsAdd'.congr' hEv.symm

open Workspace.ProofLemmas.FqSignAt0Pos
open Classical

namespace Workspace.ProofLemmas.FqHasUniqueInteriorZero

/-- The defining property: a is in the open interval (0, 1) and F_q q a = 0. -/
private def IsAStar (q a : ℝ) : Prop := 0 < a ∧ a < 1 ∧ F_q q a = 0

/-- The unique interior zero of F_q in (0, 1), defined for q > 1 by Classical.choose
    of the existence statement. For q ≤ 1, defined as 0 by default (irrelevant). -/
noncomputable def a_star (q : ℝ) : ℝ :=
  if h : ∃ a, IsAStar q a then Classical.choose h else 0

end Workspace.ProofLemmas.FqHasUniqueInteriorZero

open Workspace.ProofLemmas.FqHasUniqueInteriorZero

theorem FqHasUniqueInteriorZero (q : ℝ) (hq : 1 < q) :
    (∃! a : ℝ, IsAStar q a) ∧ IsAStar q (a_star q) := by
  classical
  -- Basic facts.
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_pow_pos : (0 : ℝ) < q^2 := by positivity
  set p : ℝ := (1 - q) / q with hp_def
  have hp_neg : p < 0 := by
    apply div_neg_of_neg_of_pos
    · linarith
    · exact hq_pos
  -- F_q(1) = 0 by direct algebra.
  have hFq_one : F_q q 1 = 0 := by
    simp only [F_q, Real.one_rpow]
    field_simp
    ring
  -- Strict convexity.
  have hStrictConv : StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) :=
    FqStrictConvex q hq
  -- Continuity of F_q on Ioi 0.
  have hCont : ContinuousOn (fun a => F_q q a) (Set.Ioi (0 : ℝ)) := by
    have heq : ∀ a : ℝ, F_q q a =
        (2 * (1 - 1/q)) * a + (1/q) * a ^ p + (-2 + 1/q) := by
      intro a
      simp only [F_q, p]
      ring
    refine ContinuousOn.congr ?_ (fun a _ => heq a)
    refine ((continuousOn_const.mul continuousOn_id).add ?_).add continuousOn_const
    refine continuousOn_const.mul ?_
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    exact (Real.continuousAt_rpow_const a p (Or.inl ha_ne)).continuousWithinAt
  -- HasDerivAt for F_q at any positive point.
  have hFq_deriv : ∀ a : ℝ, 0 < a →
      HasDerivAt (fun a => F_q q a) (2 * (1 - 1/q) + (1/q) * (p * a ^ (p - 1))) a := by
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    have hd_lin : HasDerivAt (fun y : ℝ => (2 * (1 - 1/q)) * y) (2 * (1 - 1/q)) a := by
      simpa using (hasDerivAt_id a).const_mul (2 * (1 - 1/q))
    have hd_rpow : HasDerivAt (fun y : ℝ => y ^ p) (p * a ^ (p - 1)) a :=
      Real.hasDerivAt_rpow_const (Or.inl ha_ne)
    have hd_smul : HasDerivAt (fun y : ℝ => (1/q) * y ^ p) ((1/q) * (p * a ^ (p - 1))) a :=
      hd_rpow.const_mul (1/q)
    have hd_sum : HasDerivAt
        (fun y : ℝ => (2 * (1 - 1/q)) * y + (1/q) * y ^ p)
        (2 * (1 - 1/q) + (1/q) * (p * a ^ (p - 1))) a := hd_lin.add hd_smul
    have hd_total : HasDerivAt
        (fun y : ℝ => (2 * (1 - 1/q)) * y + (1/q) * y ^ p + (-2 + 1/q))
        (2 * (1 - 1/q) + (1/q) * (p * a ^ (p - 1))) a := hd_sum.add_const (-2 + 1/q)
    have hcongr : (fun y : ℝ => F_q q y) =
        (fun y => (2 * (1 - 1/q)) * y + (1/q) * y ^ p + (-2 + 1/q)) := by
      funext y; simp only [F_q, p]; ring
    rw [hcongr]; exact hd_total
  -- Compute the derivative value at 1.
  set L : ℝ := 2 * (1 - 1/q) + (1/q) * (p * (1 : ℝ) ^ (p - 1)) with hL_def
  have hL_eq : L = (2*q - 1) * (q - 1) / q^2 := by
    simp only [hL_def, p, Real.one_rpow, mul_one]
    field_simp
    ring
  have hL_pos : 0 < L := by
    rw [hL_eq]
    apply div_pos
    · apply mul_pos
      · linarith
      · linarith
    · exact hq_pow_pos
  have hFq_deriv_one : HasDerivAt (fun a => F_q q a) L 1 := hFq_deriv 1 zero_lt_one
  -- Step 1: Find a < 1 (close to 1, in (0,1)) with F_q a < 0.
  -- Use the slope characterization of HasDerivAt at 1.
  have htendsto_slope : Filter.Tendsto
      (fun t : ℝ => t⁻¹ * (F_q q (1 + t) - F_q q 1))
      (nhdsWithin (0:ℝ) {0}ᶜ) (nhds L) := by
    have h := hFq_deriv_one
    rw [hasDerivAt_iff_tendsto_slope_zero] at h
    simpa [smul_eq_mul] using h
  have htendsto_slope' : Filter.Tendsto
      (fun t : ℝ => t⁻¹ * F_q q (1 + t))
      (nhdsWithin (0:ℝ) {0}ᶜ) (nhds L) := by
    have heq : (fun t : ℝ => t⁻¹ * (F_q q (1 + t) - F_q q 1)) =
        (fun t => t⁻¹ * F_q q (1 + t)) := by
      funext t; rw [hFq_one]; ring
    rw [heq] at htendsto_slope
    exact htendsto_slope
  -- Restrict to nhdsWithin 0 (Iio 0).
  have hsub : nhdsWithin (0:ℝ) (Set.Iio 0) ≤ nhdsWithin (0:ℝ) {0}ᶜ :=
    nhdsWithin_mono _ (fun x hx => ne_of_lt hx)
  have htendsto_left : Filter.Tendsto
      (fun t : ℝ => t⁻¹ * F_q q (1 + t))
      (nhdsWithin (0:ℝ) (Set.Iio 0)) (nhds L) :=
    htendsto_slope'.mono_left hsub
  -- Eventually the slope > L/2 > 0.
  have hL_half : 0 < L/2 := by linarith
  have hL_half_lt : L/2 < L := by linarith
  have h_evt_slope : ∀ᶠ t in nhdsWithin (0:ℝ) (Set.Iio 0),
      L/2 < t⁻¹ * F_q q (1 + t) :=
    htendsto_left.eventually (eventually_gt_nhds hL_half_lt)
  -- Eventually -1/2 < t (so 1 + t > 1/2 > 0).
  have h_evt_t_gt : ∀ᶠ t in nhdsWithin (0:ℝ) (Set.Iio 0), -(1/2 : ℝ) < t := by
    have hneg : (-(1/2:ℝ)) < 0 := by norm_num
    have hev := (eventually_gt_nhds hneg : ∀ᶠ x in nhds (0:ℝ), -(1/2:ℝ) < x)
    exact hev.filter_mono nhdsWithin_le_nhds
  -- Membership: in nhdsWithin 0 (Iio 0), every t satisfies t < 0.
  have h_evt_t_lt : ∀ᶠ t in nhdsWithin (0:ℝ) (Set.Iio 0), t < 0 := by
    rw [Filter.eventually_iff]
    exact self_mem_nhdsWithin
  -- NeBot for the filter.
  haveI hNeBot : (nhdsWithin (0:ℝ) (Set.Iio 0)).NeBot := nhdsLT_neBot 0
  -- Combine the three eventuallys, then extract a witness.
  obtain ⟨t, ht_slope, ht_lt, ht_gt⟩ : ∃ t,
      (L/2 < t⁻¹ * F_q q (1 + t)) ∧ (t < 0) ∧ (-(1/2 : ℝ) < t) := by
    have h_combined : ∀ᶠ t in nhdsWithin (0:ℝ) (Set.Iio 0),
        (L/2 < t⁻¹ * F_q q (1 + t)) ∧ (t < 0) ∧ (-(1/2 : ℝ) < t) :=
      h_evt_slope.and (h_evt_t_lt.and h_evt_t_gt)
    exact h_combined.exists
  -- Now construct a := 1 + t.
  have ha_pos : 0 < 1 + t := by linarith
  have ha_lt_one : 1 + t < 1 := by linarith
  -- F_q q (1 + t) < 0 from the slope info.
  have h_slope_pos : 0 < t⁻¹ * F_q q (1 + t) := lt_trans hL_half ht_slope
  have ht_inv_neg : t⁻¹ < 0 := inv_lt_zero.mpr ht_lt
  have hFq_neg : F_q q (1 + t) < 0 := by
    by_contra h
    push_neg at h
    have : t⁻¹ * F_q q (1 + t) ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (le_of_lt ht_inv_neg) h
    linarith
  set a₁ : ℝ := 1 + t with ha₁_def
  -- Step 2: Find s ∈ (0, a₁) with F_q s > 0.
  -- From FqSignAt0Pos: F_q tends to +∞ at 0+.
  have hTopAtZero : Filter.Tendsto (fun a => F_q q a) (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    FqSignAt0Pos q hq
  -- ∃ s ∈ (0, a₁), F_q s > 0.
  have h_evt_top : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), 1 < F_q q a :=
    hTopAtZero.eventually (Filter.eventually_gt_atTop 1)
  have h_evt_lt_a : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), a < a₁ := by
    have hev : ∀ᶠ x in nhds (0:ℝ), x < a₁ := eventually_lt_nhds ha_pos
    exact hev.filter_mono nhdsWithin_le_nhds
  have h_evt_a_pos : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), 0 < a := by
    rw [Filter.eventually_iff]
    exact self_mem_nhdsWithin
  haveI hNeBotR : (nhdsWithin (0:ℝ) (Set.Ioi 0)).NeBot := nhdsGT_neBot 0
  obtain ⟨s, hs_top, hs_lt, hs_pos⟩ : ∃ s,
      (1 < F_q q s) ∧ (s < a₁) ∧ (0 < s) := by
    have h := h_evt_top.and (h_evt_lt_a.and h_evt_a_pos)
    exact h.exists
  -- Step 3: Apply IVT to get a zero of F_q in (s, a₁).
  -- Use `intermediate_value_Ioo'`: a ≤ b, ContinuousOn f [a, b], Ioo (f b) (f a) ⊆ f '' Ioo a b.
  -- We have f(s) > 0 > f(a₁), so 0 ∈ Ioo (f a₁) (f s). Need ContinuousOn on [s, a₁].
  have hCont_on_Icc : ContinuousOn (fun a => F_q q a) (Set.Icc s a₁) := by
    apply hCont.mono
    intro x hx
    exact lt_of_lt_of_le hs_pos hx.1
  have hsub_lt : s ≤ a₁ := le_of_lt hs_lt
  have hzero_in : (0:ℝ) ∈ Set.Ioo (F_q q a₁) (F_q q s) := by
    refine ⟨hFq_neg, ?_⟩
    linarith
  have h_image : Set.Ioo (F_q q a₁) (F_q q s) ⊆ (fun a => F_q q a) '' Set.Ioo s a₁ :=
    intermediate_value_Ioo' hsub_lt hCont_on_Icc
  obtain ⟨c, hc_mem, hc_val⟩ := h_image hzero_in
  have hc_pos : 0 < c := lt_trans hs_pos hc_mem.1
  have hc_lt : c < 1 := lt_trans hc_mem.2 ha_lt_one
  -- So `c` is in (0, 1) with F_q q c = 0. Hence IsAStar q c.
  have hIsAStar_c : IsAStar q c := ⟨hc_pos, hc_lt, hc_val⟩
  -- Step 4: Uniqueness: at most one a satisfies IsAStar q a.
  have h_unique : ∀ a b : ℝ, IsAStar q a → IsAStar q b → a = b := by
    intro a b ha hb
    by_contra hne
    rcases lt_or_gt_of_ne hne with hab | hab
    · -- a < b < 1, all zeros.
      have ha_pos := ha.1
      have ha_lt := ha.2.1
      have ha_zero := ha.2.2
      have hb_pos := hb.1
      have hb_lt := hb.2.1
      have hb_zero := hb.2.2
      have ha_in_Ioi : a ∈ Set.Ioi (0:ℝ) := ha_pos
      have hone_in_Ioi : (1:ℝ) ∈ Set.Ioi (0:ℝ) := Set.mem_Ioi.mpr zero_lt_one
      have h_a_ne_one : a ≠ 1 := ne_of_lt (lt_trans hab hb_lt)
      have hb_in_seg : b ∈ openSegment ℝ a 1 := by
        rw [openSegment_eq_Ioo (lt_trans hab hb_lt)]
        exact ⟨hab, hb_lt⟩
      have h_lt_max : F_q q b < max (F_q q a) (F_q q 1) :=
        hStrictConv.lt_on_openSegment ha_in_Ioi hone_in_Ioi h_a_ne_one hb_in_seg
      rw [ha_zero, hFq_one, max_self] at h_lt_max
      linarith
    · -- b < a < 1, all zeros.
      have ha_pos := ha.1
      have ha_lt := ha.2.1
      have ha_zero := ha.2.2
      have hb_pos := hb.1
      have hb_lt := hb.2.1
      have hb_zero := hb.2.2
      have hb_in_Ioi : b ∈ Set.Ioi (0:ℝ) := hb_pos
      have hone_in_Ioi : (1:ℝ) ∈ Set.Ioi (0:ℝ) := Set.mem_Ioi.mpr zero_lt_one
      have h_b_ne_one : b ≠ 1 := ne_of_lt (lt_trans hab ha_lt)
      have ha_in_seg : a ∈ openSegment ℝ b 1 := by
        rw [openSegment_eq_Ioo (lt_trans hab ha_lt)]
        exact ⟨hab, ha_lt⟩
      have h_lt_max : F_q q a < max (F_q q b) (F_q q 1) :=
        hStrictConv.lt_on_openSegment hb_in_Ioi hone_in_Ioi h_b_ne_one ha_in_seg
      rw [hb_zero, hFq_one, max_self] at h_lt_max
      linarith
  -- Step 5: Build ∃! a, IsAStar q a from existence + uniqueness.
  have h_exists_unique : ∃! a, IsAStar q a := by
    refine ⟨c, hIsAStar_c, ?_⟩
    intro y hy
    exact h_unique y c hy hIsAStar_c
  refine ⟨h_exists_unique, ?_⟩
  -- Step 6: IsAStar q (a_star q).
  have h_exists : ∃ a, IsAStar q a := h_exists_unique.exists
  unfold a_star
  rw [dif_pos h_exists]
  exact Classical.choose_spec h_exists

open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.FqSignAt0Pos

theorem AStarLessThanOneHalf (q : ℝ) (hq : 1 < q) :
    0 < a_star q ∧ a_star q < 1/2 := by
  -- Get IsAStar info from FqHasUniqueInteriorZero
  obtain ⟨_, hIs⟩ := FqHasUniqueInteriorZero q hq
  obtain ⟨ha_pos, ha_lt_one, hFa⟩ := hIs
  refine ⟨ha_pos, ?_⟩
  -- Basic positivity facts
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
  have hqp1_pos : (0 : ℝ) < q + 1 := by linarith
  -- F_q q 1 = 0
  have hF_one : F_q q 1 = 0 := by
    simp only [F_q, Real.one_rpow]
    field_simp
    ring
  -- log 2 < 1
  have hlog2_lt_one : Real.log 2 < 1 := by
    have h := Real.log_lt_sub_one_of_pos (by norm_num : (0 : ℝ) < 2) (by norm_num : (2 : ℝ) ≠ 1)
    linarith
  -- 0 < log 2
  have hlog2_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  -- 2 * (q - 1) / (q + 1) < log q
  have hlogq_lower : 2 * (q - 1) / (q + 1) < Real.log q := by
    have h := Real.lt_log_one_add_of_pos (x := q - 1) hqm1_pos
    have h1 : (q - 1 : ℝ) + 2 = q + 1 := by ring
    have h2 : (1 : ℝ) + (q - 1) = q := by ring
    rw [h1, h2] at h
    exact h
  -- Key inequality: log 2 * (q - 1) < q * log q
  have h_key : Real.log 2 * (q - 1) < q * Real.log q := by
    have h_step1 : Real.log 2 * (q - 1) ≤ q * (2 * (q - 1) / (q + 1)) := by
      have h_aux : Real.log 2 * (q + 1) ≤ 2 * q := by
        have hq_ge_one : (1 : ℝ) ≤ q := le_of_lt hq
        nlinarith [hlog2_lt_one, hq_ge_one, hlog2_pos]
      have h_lhs : Real.log 2 * (q - 1) * (q + 1) ≤ 2 * q * (q - 1) := by
        nlinarith [hqm1_pos, h_aux]
      have h_rhs_eq : q * (2 * (q - 1) / (q + 1)) = (2 * q * (q - 1)) / (q + 1) := by
        field_simp
      rw [h_rhs_eq, le_div_iff₀ hqp1_pos]
      linarith
    have h_step2 : q * (2 * (q - 1) / (q + 1)) < q * Real.log q := by
      exact mul_lt_mul_of_pos_left hlogq_lower hq_pos
    linarith
  -- F_q q (1/2) < 0
  have hF_half : F_q q (1/2) < 0 := by
    have h_half_rpow : ((1:ℝ)/2) ^ ((1 - q) / q) = Real.exp (((q - 1) / q) * Real.log 2) := by
      rw [show ((1:ℝ)/2) = (2:ℝ)⁻¹ by norm_num]
      rw [Real.inv_rpow (by norm_num : (0:ℝ) ≤ 2)]
      rw [show ((2 : ℝ)^((1 - q) / q))⁻¹ = (2 : ℝ)^(-(((1 - q) / q))) by
        rw [← Real.rpow_neg (by norm_num : (0:ℝ) ≤ 2)]]
      rw [show -((1 - q) / q) = (q - 1) / q by ring]
      rw [Real.rpow_def_of_pos (by norm_num : (0:ℝ) < 2)]
      ring_nf
    -- Derive: (1/2)^((1-q)/q) < q
    have h_rpow_lt_q : ((1:ℝ)/2) ^ ((1 - q) / q) < q := by
      rw [h_half_rpow]
      have hexp_lt : ((q - 1) / q) * Real.log 2 < Real.log q := by
        rw [div_mul_eq_mul_div]
        rw [div_lt_iff₀ hq_pos]
        linarith [h_key]
      calc Real.exp (((q - 1) / q) * Real.log 2)
          < Real.exp (Real.log q) := Real.exp_lt_exp.mpr hexp_lt
        _ = q := Real.exp_log hq_pos
    -- Now F_q(1/2) = -1 + (1/q) * (1/2)^((1-q)/q) < -1 + (1/q) * q = 0
    have h_inv_pos : 0 < (1 : ℝ) / q := by positivity
    have h_mul : (1/q) * ((1:ℝ)/2) ^ ((1 - q) / q) < (1/q) * q := by
      exact mul_lt_mul_of_pos_left h_rpow_lt_q h_inv_pos
    have h_inv_q : (1/q) * q = 1 := by field_simp
    rw [h_inv_q] at h_mul
    have hFq_half_eq : F_q q (1/2) = -1 + (1/q) * ((1:ℝ)/2) ^ ((1 - q) / q) := by
      simp only [F_q]
      field_simp
      ring
    rw [hFq_half_eq]
    linarith
  -- Apply secant_strict_mono via FqStrictConvex
  by_contra h_neg
  push_neg at h_neg
  -- h_neg : 1/2 ≤ a_star q
  have hSC := FqStrictConvex q hq
  rcases eq_or_lt_of_le h_neg with heq | hlt
  · -- 1/2 = a_star q
    rw [← heq] at hFa
    linarith
  · -- 1/2 < a_star q
    have h_half_in : (1 : ℝ)/2 ∈ Set.Ioi (0 : ℝ) := by
      simp only [Set.mem_Ioi]; norm_num
    have h_one_in : (1 : ℝ) ∈ Set.Ioi (0 : ℝ) := by
      simp only [Set.mem_Ioi]; norm_num
    have h_astar_in : a_star q ∈ Set.Ioi (0 : ℝ) := ha_pos
    have hxa : (1 : ℝ)/2 ≠ 1 := by norm_num
    have hya : a_star q ≠ 1 := ne_of_lt ha_lt_one
    -- secant_strict_mono : a ∈ s → x ∈ s → y ∈ s → x ≠ a → y ≠ a → x < y →
    --   (f x - f a) / (x - a) < (f y - f a) / (y - a)
    have hSecant := hSC.secant_strict_mono h_one_in h_half_in h_astar_in hxa hya hlt
    rw [hFa, hF_one] at hSecant
    -- hSecant : (F_q q (1/2) - 0) / (1/2 - 1) < (0 - 0) / (a_star q - 1)
    -- Simplify: F_q q (1/2) / (1/2 - 1) < 0
    have h_rhs_zero : (0 - (0 : ℝ)) / (a_star q - 1) = 0 := by
      simp
    have h_lhs_simp : (F_q q (1/2) - 0) / ((1:ℝ)/2 - 1) = F_q q (1/2) / ((1:ℝ)/2 - 1) := by
      ring
    rw [h_rhs_zero, h_lhs_simp] at hSecant
    -- hSecant : F_q q (1/2) / (1/2 - 1) < 0
    have hdenom_neg : ((1:ℝ)/2 - 1) < 0 := by norm_num
    -- F_q q (1/2) / (negative) < 0 means F_q q (1/2) > 0, contradicting hF_half
    have hF_pos : 0 < F_q q (1/2) := by
      rcases div_neg_iff.mp hSecant with ⟨hp, hn⟩ | ⟨hn, hp⟩
      · linarith
      · linarith
    linarith

open Workspace.ProofLemmas.FqSignAt0Pos
open Workspace.ProofLemmas.FqHasUniqueInteriorZero

namespace Workspace.ProofLemmas.DeltaStarDef

noncomputable def delta_star (q : ℝ) : ℝ :=
  ((a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q)) /
  (1 - (a_star q)) ^ ((1 : ℝ) / q)

/-- Auxiliary: for `r ∈ (0, 1]` and `x ∈ [0, 1/2]`,
    `(1-x)^r ≤ x^r + 1 - 2x`. -/
private lemma aux_chord_inequality (r : ℝ) (hr_pos : 0 < r) (hr_le : r ≤ 1)
    (x : ℝ) (hx_nn : 0 ≤ x) (hx_le : x ≤ 1/2) :
    (1 - x) ^ r ≤ x ^ r + 1 - 2 * x := by
  rcases eq_or_lt_of_le hr_le with hr_eq | hr_lt
  · -- r = 1
    rw [hr_eq]
    rw [Real.rpow_one, Real.rpow_one]
    linarith
  · -- r < 1
    rcases eq_or_lt_of_le hx_nn with hx_zero | hx_pos
    · -- x = 0
      rw [← hx_zero]
      simp [Real.zero_rpow (ne_of_gt hr_pos)]
    · rcases eq_or_lt_of_le hx_le with hx_eq_half | hx_lt_half
      · -- x = 1/2
        rw [hx_eq_half]
        have : (1 - (1/2 : ℝ)) = 1/2 := by norm_num
        rw [this]
        linarith
      · -- 0 < x < 1/2
        set H : ℝ → ℝ := fun x => (1 - x) ^ r - x ^ r - 1 + 2 * x with hH_def
        suffices hH_le : H x ≤ 0 by
          have : H x = (1 - x) ^ r - x ^ r - 1 + 2 * x := rfl
          linarith
        have hH0 : H 0 = 0 := by
          simp [hH_def, Real.zero_rpow (ne_of_gt hr_pos), Real.one_rpow]
        have hH_half : H (1/2 : ℝ) = 0 := by
          show (1 - (1/2 : ℝ)) ^ r - ((1/2 : ℝ)) ^ r - 1 + 2 * (1/2 : ℝ) = 0
          have h12 : (1 - (1/2 : ℝ)) = 1/2 := by norm_num
          rw [h12]
          ring
        -- Continuity of H on [0, 1/2].
        have hCont : ContinuousOn H (Set.Icc (0 : ℝ) (1/2)) := by
          have h1 : ContinuousOn (fun x : ℝ => (1 - x) ^ r) (Set.Icc (0 : ℝ) (1/2)) := by
            intro x hx
            have hx_le : x ≤ 1/2 := hx.2
            have h1x_pos : 0 < 1 - x := by linarith
            have h_inner : ContinuousAt (fun x : ℝ => 1 - x) x :=
              (continuous_const.sub continuous_id).continuousAt
            have h_outer : ContinuousAt (fun y : ℝ => y ^ r) (1 - x) :=
              Real.continuousAt_rpow_const (1 - x) r (Or.inl (ne_of_gt h1x_pos))
            exact (h_outer.comp h_inner).continuousWithinAt
          have h2 : ContinuousOn (fun x : ℝ => x ^ r) (Set.Icc (0 : ℝ) (1/2)) := by
            intro x hx
            have : ContinuousAt (fun x : ℝ => x ^ r) x :=
              Real.continuousAt_rpow_const x r (Or.inr (le_of_lt hr_pos))
            exact this.continuousWithinAt
          have h3 : ContinuousOn (fun x : ℝ => (1 - x) ^ r - x ^ r) (Set.Icc (0 : ℝ) (1/2)) :=
            h1.sub h2
          have h4 : ContinuousOn (fun x : ℝ => (1 - x) ^ r - x ^ r - 1) (Set.Icc (0 : ℝ) (1/2)) :=
            h3.sub continuousOn_const
          have h5 : ContinuousOn H (Set.Icc (0 : ℝ) (1/2)) := by
            simp only [hH_def]
            exact h4.add (continuousOn_const.mul continuousOn_id)
          exact h5
        have hConv_Icc : Convex ℝ (Set.Icc (0 : ℝ) (1/2)) := convex_Icc 0 (1/2)
        have h_int : interior (Set.Icc (0 : ℝ) (1/2)) = Set.Ioo 0 (1/2) := interior_Icc
        -- First derivative formula on (0, 1/2).
        have hH_deriv : ∀ y ∈ Set.Ioo (0 : ℝ) (1/2),
            HasDerivAt H (-r * (1 - y) ^ (r - 1) - r * y ^ (r - 1) + 2) y := by
          intro y hy
          have hy_pos : 0 < y := hy.1
          have hy_ne : y ≠ 0 := ne_of_gt hy_pos
          have h1y_pos : 0 < 1 - y := by linarith [hy.2]
          have h1y_ne : 1 - y ≠ 0 := ne_of_gt h1y_pos
          have hd_inner_neg : HasDerivAt (fun y : ℝ => 1 - y) (-1 : ℝ) y := by
            simpa using (hasDerivAt_id y).const_sub 1
          have hd_rpow_y : HasDerivAt (fun y : ℝ => y ^ r) (r * y ^ (r - 1)) y :=
            Real.hasDerivAt_rpow_const (Or.inl hy_ne)
          have hd_rpow_one_minus :
              HasDerivAt (fun y : ℝ => (1 - y) ^ r)
                ((r * (1 - y) ^ (r - 1)) * (-1)) y := by
            have hd := Real.hasDerivAt_rpow_const (p := r) (x := 1 - y) (Or.inl h1y_ne)
            exact hd.comp y hd_inner_neg
          have hd_sub :
              HasDerivAt (fun y : ℝ => (1 - y) ^ r - y ^ r)
                ((r * (1 - y) ^ (r - 1)) * (-1) - r * y ^ (r - 1)) y :=
            hd_rpow_one_minus.sub hd_rpow_y
          have hd_sub_const :
              HasDerivAt (fun y : ℝ => (1 - y) ^ r - y ^ r - 1)
                ((r * (1 - y) ^ (r - 1)) * (-1) - r * y ^ (r - 1)) y :=
            hd_sub.sub_const 1
          have hd_lin : HasDerivAt (fun y : ℝ => 2 * y) (2 : ℝ) y := by
            simpa using (hasDerivAt_id y).const_mul 2
          have hd_total :
              HasDerivAt H
                ((r * (1 - y) ^ (r - 1)) * (-1) - r * y ^ (r - 1) + 2) y := by
            simp only [hH_def]
            exact hd_sub_const.add hd_lin
          have heq :
              (r * (1 - y) ^ (r - 1)) * (-1) - r * y ^ (r - 1) + 2 =
                -r * (1 - y) ^ (r - 1) - r * y ^ (r - 1) + 2 := by ring
          rw [heq] at hd_total
          exact hd_total
        -- Second derivative formula.
        have hH_deriv2 : ∀ y ∈ Set.Ioo (0 : ℝ) (1/2),
            HasDerivAt
              (fun y : ℝ => -r * (1 - y) ^ (r - 1) - r * y ^ (r - 1) + 2)
              (r * (r - 1) * (1 - y) ^ (r - 2) - r * (r - 1) * y ^ (r - 2)) y := by
          intro y hy
          have hy_pos : 0 < y := hy.1
          have hy_ne : y ≠ 0 := ne_of_gt hy_pos
          have h1y_pos : 0 < 1 - y := by linarith [hy.2]
          have h1y_ne : 1 - y ≠ 0 := ne_of_gt h1y_pos
          have hd_inner_neg : HasDerivAt (fun y : ℝ => 1 - y) (-1 : ℝ) y := by
            simpa using (hasDerivAt_id y).const_sub 1
          have hd_rpow_inner :
              HasDerivAt (fun y : ℝ => y ^ (r - 1)) ((r - 1) * y ^ (r - 1 - 1)) y :=
            Real.hasDerivAt_rpow_const (Or.inl hy_ne)
          have hd_rpow_one_minus_inner :
              HasDerivAt (fun y : ℝ => (1 - y) ^ (r - 1))
                (((r - 1) * (1 - y) ^ (r - 1 - 1)) * (-1)) y := by
            have hd := Real.hasDerivAt_rpow_const (p := r - 1) (x := 1 - y) (Or.inl h1y_ne)
            exact hd.comp y hd_inner_neg
          have hd_part1 :
              HasDerivAt (fun y : ℝ => -r * (1 - y) ^ (r - 1))
                (-r * (((r - 1) * (1 - y) ^ (r - 1 - 1)) * (-1))) y :=
            hd_rpow_one_minus_inner.const_mul (-r)
          have hd_part2 :
              HasDerivAt (fun y : ℝ => r * y ^ (r - 1))
                (r * ((r - 1) * y ^ (r - 1 - 1))) y :=
            hd_rpow_inner.const_mul r
          have hd_sub :
              HasDerivAt
                (fun y : ℝ => -r * (1 - y) ^ (r - 1) - r * y ^ (r - 1))
                (-r * (((r - 1) * (1 - y) ^ (r - 1 - 1)) * (-1)) -
                  r * ((r - 1) * y ^ (r - 1 - 1))) y :=
            hd_part1.sub hd_part2
          have hd_total := hd_sub.add_const (2 : ℝ)
          have heq :
              -r * (((r - 1) * (1 - y) ^ (r - 1 - 1)) * (-1)) -
                  r * ((r - 1) * y ^ (r - 1 - 1)) =
                r * (r - 1) * (1 - y) ^ (r - 2) - r * (r - 1) * y ^ (r - 2) := by
            have h1 : r - 1 - 1 = r - 2 := by ring
            rw [h1]
            ring
          rw [heq] at hd_total
          exact hd_total
        -- Convexity via second derivative ≥ 0.
        have hConv_H : ConvexOn ℝ (Set.Icc (0 : ℝ) (1/2)) H := by
          apply convexOn_of_deriv2_nonneg hConv_Icc hCont
          · rw [h_int]
            intro y hy
            exact (hH_deriv y hy).differentiableAt.differentiableWithinAt
          · rw [h_int]
            intro y hy
            have hopen : IsOpen (Set.Ioo (0 : ℝ) (1/2)) := isOpen_Ioo
            have hnhds : Set.Ioo (0 : ℝ) (1/2) ∈ nhds y := hopen.mem_nhds hy
            have hloc :
                deriv H =ᶠ[nhds y]
                  fun z => -r * (1 - z) ^ (r - 1) - r * z ^ (r - 1) + 2 := by
              filter_upwards [hnhds] with z hz
              exact (hH_deriv z hz).deriv
            have hd2 :
                DifferentiableAt ℝ
                  (fun z : ℝ => -r * (1 - z) ^ (r - 1) - r * z ^ (r - 1) + 2) y :=
              (hH_deriv2 y hy).differentiableAt
            have hd_local : DifferentiableAt ℝ (deriv H) y :=
              hd2.congr_of_eventuallyEq hloc
            exact hd_local.differentiableWithinAt
          · rw [h_int]
            intro y hy
            simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
            have hopen : IsOpen (Set.Ioo (0 : ℝ) (1/2)) := isOpen_Ioo
            have hnhds : Set.Ioo (0 : ℝ) (1/2) ∈ nhds y := hopen.mem_nhds hy
            have hloc :
                deriv H =ᶠ[nhds y]
                  fun z => -r * (1 - z) ^ (r - 1) - r * z ^ (r - 1) + 2 := by
              filter_upwards [hnhds] with z hz
              exact (hH_deriv z hz).deriv
            have hd2_eq : deriv (deriv H) y =
                deriv (fun z => -r * (1 - z) ^ (r - 1) - r * z ^ (r - 1) + 2) y :=
              hloc.deriv_eq
            rw [hd2_eq, (hH_deriv2 y hy).deriv]
            -- Show: 0 ≤ r * (r - 1) * (1 - y) ^ (r - 2) - r * (r - 1) * y ^ (r - 2)
            have hy_pos : 0 < y := hy.1
            have hy_lt : y < 1/2 := hy.2
            have h1y_pos : 0 < 1 - y := by linarith
            have h1y_gt_y : y < 1 - y := by linarith
            have hr_minus_one_neg : r - 1 < 0 := by linarith
            have hr_minus_two_neg : r - 2 < 0 := by linarith
            have h_rpow_lt : (1 - y) ^ (r - 2) < y ^ (r - 2) :=
              Real.rpow_lt_rpow_of_exponent_neg hy_pos h1y_gt_y hr_minus_two_neg
            have hr_rm1_neg : r * (r - 1) < 0 :=
              mul_neg_of_pos_of_neg hr_pos hr_minus_one_neg
            -- r * (r - 1) * ((1 - y)^(r-2) - y^(r-2)) ≥ 0
            -- = (negative) * (negative) ≥ 0
            have h_diff_neg : (1 - y) ^ (r - 2) - y ^ (r - 2) < 0 := by linarith
            have : 0 ≤ r * (r - 1) * ((1 - y) ^ (r - 2) - y ^ (r - 2)) := by
              have := mul_pos_of_neg_of_neg hr_rm1_neg h_diff_neg
              linarith
            linarith
        -- Apply convexity using ConvexOn.le_max_of_mem_Icc.
        have hx_in : x ∈ Set.Icc (0 : ℝ) (1/2) := ⟨le_of_lt hx_pos, le_of_lt hx_lt_half⟩
        have h0_in : (0 : ℝ) ∈ Set.Icc (0 : ℝ) (1/2) := ⟨le_refl _, by norm_num⟩
        have hhalf_in : (1/2 : ℝ) ∈ Set.Icc (0 : ℝ) (1/2) := ⟨by norm_num, le_refl _⟩
        have hbound : H x ≤ max (H 0) (H (1/2 : ℝ)) :=
          hConv_H.le_max_of_mem_Icc h0_in hhalf_in hx_in
        rw [hH0, hH_half] at hbound
        simpa using hbound

theorem DeltaStarDef (q : ℝ) (hq : 1 < q) :
    1 ≤ delta_star q ∧ 0 < (1 - a_star q) ^ ((1 : ℝ) / q) := by
  have h_astar := AStarLessThanOneHalf q hq
  obtain ⟨ha_pos, ha_lt_half⟩ := h_astar
  have ha_lt_one : a_star q < 1 := by linarith
  have h1_minus_pos : 0 < 1 - a_star q := by linarith
  have hq_pos : (0 : ℝ) < q := by linarith
  have hr_pos : (0 : ℝ) < (1 : ℝ) / q := by positivity
  have hr_le : (1 : ℝ) / q ≤ 1 := by
    rw [div_le_one hq_pos]; linarith
  have h_denom_pos : 0 < (1 - a_star q) ^ ((1 : ℝ) / q) :=
    Real.rpow_pos_of_pos h1_minus_pos _
  refine ⟨?_, h_denom_pos⟩
  unfold delta_star
  rw [le_div_iff₀ h_denom_pos]
  rw [one_mul]
  have hkey := aux_chord_inequality ((1 : ℝ) / q) hr_pos hr_le (a_star q)
    (le_of_lt ha_pos) (le_of_lt ha_lt_half)
  linarith

end Workspace.ProofLemmas.DeltaStarDef

open Workspace.ProofLemmas.DeltaStarDef

namespace Workspace.ProofLemmas.LambdaStarDef

noncomputable def lambda_star (q : ℝ) : ℝ :=
  if q = 1 then 1
  else if 1 < q then
    (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q))
  else 1

theorem LambdaStarDef :
    (∀ q : ℝ, 1 ≤ q → 0 < lambda_star q ∧ lambda_star q ≤ 1) ∧ lambda_star 1 = 1 := by
  refine ⟨?_, ?_⟩
  · intro q hq
    by_cases hq1 : q = 1
    · subst hq1
      simp [lambda_star]
    · have hq' : 1 < q := lt_of_le_of_ne hq (Ne.symm hq1)
      have hq_pos : (0 : ℝ) < q := by linarith
      have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
      have hD := DeltaStarDef q hq'
      obtain ⟨hD_ge_one, _⟩ := hD
      have hD_pos : 0 < delta_star q := by linarith
      -- exponent q/(q-1) > 0
      have h_exp1_pos : 0 < q / (q - 1) := div_pos hq_pos hqm1_pos
      -- (delta_star q)^(q/(q-1)) ≥ 1 since delta_star q ≥ 1 and exponent ≥ 0
      have h_dpow_ge_one : 1 ≤ (delta_star q) ^ (q / (q - 1)) :=
        Real.one_le_rpow hD_ge_one (le_of_lt h_exp1_pos)
      -- 1 + (delta_star q)^(q/(q-1)) ≥ 2 > 0
      have h_sum_pos : 0 < 1 + (delta_star q) ^ (q / (q - 1)) := by linarith
      have h_sum_ge_one : 1 ≤ 1 + (delta_star q) ^ (q / (q - 1)) := by linarith
      -- exponent -(q-1)/q
      have h_exp2_nonpos : -((q - 1) / q) ≤ 0 := by
        have : 0 ≤ (q - 1) / q := le_of_lt (div_pos hqm1_pos hq_pos)
        linarith
      -- Now goal: 0 < lambda_star q ∧ lambda_star q ≤ 1
      have h_unfold : lambda_star q =
          (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q)) := by
        unfold lambda_star
        rw [if_neg hq1, if_pos hq']
      rw [h_unfold]
      refine ⟨Real.rpow_pos_of_pos h_sum_pos _, ?_⟩
      -- (≥ 1)^(≤ 0) ≤ 1
      have h_le : (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q)) ≤
                  (1 + (delta_star q) ^ (q / (q - 1))) ^ (0 : ℝ) := by
        apply Real.rpow_le_rpow_of_exponent_le h_sum_ge_one h_exp2_nonpos
      rw [Real.rpow_zero] at h_le
      exact h_le
  · simp [lambda_star]

end Workspace.ProofLemmas.LambdaStarDef

open Workspace.ProofLemmas.LambdaStarDef

namespace Workspace.ProofLemmas.UBDef

noncomputable def UB (q : ℝ) : ℝ :=
  if 1 ≤ q then 1 / lambda_star q else 1

theorem UBDef :
    (∀ q : ℝ, 1 ≤ q → 1 ≤ UB q) ∧ UB 1 = 1 := by
  have hLam := LambdaStarDef
  refine ⟨?_, ?_⟩
  · intro q hq
    simp only [UB, if_pos hq]
    obtain ⟨h_pos, h_le⟩ := hLam.1 q hq
    rw [le_div_iff₀ h_pos]
    linarith
  · simp only [UB, if_pos (le_refl (1 : ℝ))]
    rw [hLam.2]
    norm_num

end Workspace.ProofLemmas.UBDef

open Workspace.ProofLemmas.FqSignAt0Pos
open Filter Topology

theorem FqAtCOverQ_tendsto (c : ℝ) (hc : 0 < c) :
    Filter.Tendsto (fun q : ℝ => F_q q (c/q)) Filter.atTop (nhds (1/c - 2)) := by
  have hc_ne : c ≠ 0 := ne_of_gt hc
  -- 1/q → 0
  have h_inv : Tendsto (fun q : ℝ => q⁻¹) atTop (nhds 0) := tendsto_inv_atTop_zero
  have h_one_div_q : Tendsto (fun q : ℝ => 1/q) atTop (nhds 0) := by
    simpa [one_div] using h_inv
  -- c/q → 0
  have h_c_div_q : Tendsto (fun q : ℝ => c/q) atTop (nhds 0) := by
    have : (0 : ℝ) = c * 0 := by ring
    rw [this]
    have hcq : Tendsto (fun q : ℝ => c * (1/q)) atTop (nhds (c * 0)) :=
      h_one_div_q.const_mul c
    convert hcq using 1
    funext q
    ring
  -- q^(1/q) → 1 (Mathlib's tendsto_rpow_div)
  have h_q_pow : Tendsto (fun q : ℝ => q ^ (1/q)) atTop (nhds 1) := tendsto_rpow_div
  -- c^(1/q) → 1 via continuity of (fun y => c^y) at 0
  have h_c_pow : Tendsto (fun q : ℝ => c ^ (1/q)) atTop (nhds 1) := by
    have hcont : Continuous (fun y : ℝ => c ^ y) := Real.continuous_const_rpow hc_ne
    have : Tendsto (fun y : ℝ => c ^ y) (nhds 0) (nhds (c ^ (0 : ℝ))) :=
      hcont.tendsto 0
    have hcomp : Tendsto (fun q : ℝ => c ^ (1/q)) atTop (nhds (c ^ (0 : ℝ))) :=
      this.comp h_one_div_q
    simpa using hcomp
  -- (c/q)^(1/q) → 1, eventually rewriting via div_rpow
  have h_pos : ∀ᶠ q : ℝ in atTop, 0 < q := eventually_gt_atTop 0
  have h_cq_pow : Tendsto (fun q : ℝ => (c/q) ^ (1/q)) atTop (nhds 1) := by
    have h_div : Tendsto (fun q : ℝ => c ^ (1/q) / q ^ (1/q)) atTop (nhds (1/1)) :=
      h_c_pow.div h_q_pow one_ne_zero
    have heq : (fun q : ℝ => (c/q) ^ (1/q)) =ᶠ[atTop]
        (fun q : ℝ => c ^ (1/q) / q ^ (1/q)) := by
      filter_upwards [h_pos] with q hq
      have hcle : (0:ℝ) ≤ c := le_of_lt hc
      have hqle : (0:ℝ) ≤ q := le_of_lt hq
      exact Real.div_rpow hcle hqle (1/q)
    have : Tendsto (fun q : ℝ => (c/q) ^ (1/q)) atTop (nhds (1/1)) :=
      Tendsto.congr' heq.symm h_div
    simpa using this
  -- (1/q) * (c/q)^((1-q)/q) → 1/c, using rewrite via Real.rpow_sub
  -- (c/q)^((1-q)/q) = (c/q)^(1/q - 1) = (c/q)^(1/q) / (c/q)
  -- So (1/q) * (c/q)^((1-q)/q) = (1/q) * (c/q)^(1/q) / (c/q) = (c/q)^(1/q) / c
  have h_main_term : Tendsto (fun q : ℝ => (1/q) * (c/q) ^ ((1-q)/q)) atTop (nhds (1/c)) := by
    have h_target : Tendsto (fun q : ℝ => (c/q) ^ (1/q) / c) atTop (nhds (1/c)) := by
      have : Tendsto (fun q : ℝ => (c/q) ^ (1/q) / c) atTop (nhds (1/c)) := by
        have h := h_cq_pow.div_const c
        simpa using h
      exact this
    -- show eventually equal
    have h_pos_c : ∀ᶠ q : ℝ in atTop, c < q := eventually_gt_atTop c
    have heq : (fun q : ℝ => (1/q) * (c/q) ^ ((1-q)/q)) =ᶠ[atTop]
        (fun q : ℝ => (c/q) ^ (1/q) / c) := by
      filter_upwards [h_pos, h_pos_c] with q hq hcq_lt
      have hq_pos : 0 < q := hq
      have hcq_pos : 0 < c/q := div_pos hc hq_pos
      have hexp : (1 - q) / q = 1/q - 1 := by
        field_simp
      rw [hexp]
      rw [Real.rpow_sub hcq_pos]
      rw [Real.rpow_one]
      -- Now goal: (1/q) * ((c/q)^(1/q) / (c/q)) = (c/q)^(1/q) / c
      field_simp
    exact Tendsto.congr' heq.symm h_target
  -- 2 * (1 - 1/q) * (c/q) → 0
  have h_lin : Tendsto (fun q : ℝ => 2 * (1 - 1/q) * (c/q)) atTop (nhds 0) := by
    have h1 : Tendsto (fun q : ℝ => 1 - 1/q) atTop (nhds (1 - 0)) :=
      tendsto_const_nhds.sub h_one_div_q
    have h1' : Tendsto (fun q : ℝ => 1 - 1/q) atTop (nhds 1) := by simpa using h1
    have h2 : Tendsto (fun q : ℝ => 2 * (1 - 1/q)) atTop (nhds (2 * 1)) :=
      h1'.const_mul 2
    have h2' : Tendsto (fun q : ℝ => 2 * (1 - 1/q)) atTop (nhds 2) := by simpa using h2
    have h3 : Tendsto (fun q : ℝ => 2 * (1 - 1/q) * (c/q)) atTop (nhds (2 * 0)) :=
      h2'.mul h_c_div_q
    simpa using h3
  -- 1/q → 0 already
  -- Constant -2
  -- Combine: 2*(1-1/q)*(c/q) + (1/q) * (c/q)^((1-q)/q) - 2 + 1/q
  have h_sum : Tendsto (fun q : ℝ =>
        2 * (1 - 1/q) * (c/q) + (1/q) * (c/q) ^ ((1-q)/q) - 2 + 1/q)
      atTop (nhds (0 + (1/c) - 2 + 0)) := by
    refine ((h_lin.add h_main_term).sub_const 2).add h_one_div_q
  have h_sum' : Tendsto (fun q : ℝ =>
        2 * (1 - 1/q) * (c/q) + (1/q) * (c/q) ^ ((1-q)/q) - 2 + 1/q)
      atTop (nhds (1/c - 2)) := by
    have : (0 : ℝ) + (1/c) - 2 + 0 = 1/c - 2 := by ring
    rw [this] at h_sum
    exact h_sum
  -- Now identify F_q q (c/q) with the sum
  have heq : (fun q : ℝ => F_q q (c/q)) =
      (fun q : ℝ => 2 * (1 - 1/q) * (c/q) + (1/q) * (c/q) ^ ((1-q)/q) - 2 + 1/q) := by
    funext q
    simp only [F_q]
  rw [heq]
  exact h_sum'

open Workspace.ProofLemmas.FqSignAt0Pos

theorem FqAtCOverQ_eventually_pos (c : ℝ) (hc_pos : 0 < c) (hc_lt : c < 1/2) :
    ∀ᶠ q in Filter.atTop, 0 < F_q q (c/q) := by
  have h_tendsto : Filter.Tendsto (fun q : ℝ => F_q q (c/q)) Filter.atTop
      (nhds (1/c - 2)) := FqAtCOverQ_tendsto c hc_pos
  -- Show 1/c - 2 > 0 since c < 1/2
  have h_lim_pos : (0 : ℝ) < 1/c - 2 := by
    have hinv : (2 : ℝ) < 1/c := by
      rw [lt_div_iff₀ hc_pos]
      linarith
    linarith
  exact h_tendsto.eventually_const_lt h_lim_pos

open Workspace.ProofLemmas.FqSignAt0Pos

theorem FqAtCOverQ_eventually_neg (c : ℝ) (hc : 1/2 < c) :
    ∀ᶠ q in Filter.atTop, F_q q (c/q) < 0 := by
  have hc_pos : (0 : ℝ) < c := by linarith
  have h_tendsto : Filter.Tendsto (fun q : ℝ => F_q q (c/q)) Filter.atTop
      (nhds (1/c - 2)) := FqAtCOverQ_tendsto c hc_pos
  -- Show 1/c - 2 < 0 since c > 1/2
  have h_lim_neg : 1/c - 2 < (0 : ℝ) := by
    have hinv : 1/c < (2 : ℝ) := by
      rw [div_lt_iff₀ hc_pos]
      linarith
    linarith
  exact h_tendsto.eventually_lt_const h_lim_neg

open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.FqSignAt0Pos
open Filter Topology

theorem AStarAsymptotic :
    Filter.Tendsto (fun q => q * a_star q) Filter.atTop (nhds (1/2 : ℝ)) := by
  rw [Metric.tendsto_nhds]
  intro ε hε
  -- Pick ε' = min ε (1/4) > 0; ε' ≤ ε and ε' < 1/2.
  set ε' : ℝ := min ε (1/4) with hε'_def
  have hε'_pos : 0 < ε' := lt_min hε (by norm_num)
  have hε'_le : ε' ≤ ε := min_le_left _ _
  have hε'_lt_half : ε' < 1/2 := by
    have h1 : ε' ≤ 1/4 := min_le_right _ _
    linarith
  -- Define c_lo and c_hi.
  set c_lo : ℝ := 1/2 - ε' with hc_lo_def
  set c_hi : ℝ := 1/2 + ε' with hc_hi_def
  have hc_lo_pos : 0 < c_lo := by simp only [hc_lo_def]; linarith
  have hc_lo_lt_half : c_lo < 1/2 := by simp only [hc_lo_def]; linarith
  have hc_hi_gt_half : 1/2 < c_hi := by simp only [hc_hi_def]; linarith
  have hc_lo_lt_hi : c_lo < c_hi := by simp only [hc_lo_def, hc_hi_def]; linarith
  -- Eventually F_q q (c_lo/q) > 0.
  have h_pos : ∀ᶠ q : ℝ in atTop, 0 < F_q q (c_lo/q) :=
    FqAtCOverQ_eventually_pos c_lo hc_lo_pos hc_lo_lt_half
  -- Eventually F_q q (c_hi/q) < 0.
  have h_neg : ∀ᶠ q : ℝ in atTop, F_q q (c_hi/q) < 0 :=
    FqAtCOverQ_eventually_neg c_hi hc_hi_gt_half
  -- Eventually q > 1.
  have h_q_gt_one : ∀ᶠ q : ℝ in atTop, 1 < q := eventually_gt_atTop 1
  -- Eventually q > c_hi (so c_hi/q < 1).
  have h_q_gt_c_hi : ∀ᶠ q : ℝ in atTop, c_hi < q := eventually_gt_atTop c_hi
  -- Combine all eventuallys.
  filter_upwards [h_pos, h_neg, h_q_gt_one, h_q_gt_c_hi] with q hFpos hFneg hq hq_gt_chi
  -- Basic positivity facts.
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_clo_div_pos : 0 < c_lo / q := div_pos hc_lo_pos hq_pos
  have h_chi_div_pos : 0 < c_hi / q := div_pos (by linarith : (0:ℝ) < c_hi) hq_pos
  have h_div_lt : c_lo / q < c_hi / q := by
    apply div_lt_div_of_pos_right hc_lo_lt_hi hq_pos
  have h_chi_div_lt_one : c_hi / q < 1 := by
    rw [div_lt_one hq_pos]
    exact hq_gt_chi
  -- Continuity of F_q on Ioi 0 (use FqStrictConvex's underlying argument).
  -- Easier: use the same continuity argument as in FqHasUniqueInteriorZero.
  set p : ℝ := (1 - q) / q with hp_def
  have hCont : ContinuousOn (fun a => F_q q a) (Set.Ioi (0 : ℝ)) := by
    have heq : ∀ a : ℝ, F_q q a =
        (2 * (1 - 1/q)) * a + (1/q) * a ^ p + (-2 + 1/q) := by
      intro a
      simp only [F_q, p]
      ring
    refine ContinuousOn.congr ?_ (fun a _ => heq a)
    refine ((continuousOn_const.mul continuousOn_id).add ?_).add continuousOn_const
    refine continuousOn_const.mul ?_
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    exact (Real.continuousAt_rpow_const a p (Or.inl ha_ne)).continuousWithinAt
  -- Continuity on the closed interval [c_lo/q, c_hi/q].
  have hCont_Icc : ContinuousOn (fun a => F_q q a) (Set.Icc (c_lo/q) (c_hi/q)) := by
    apply hCont.mono
    intro x hx
    exact lt_of_lt_of_le h_clo_div_pos hx.1
  -- Apply IVT: 0 ∈ Ioo (F_q q (c_hi/q)) (F_q q (c_lo/q)) ⊆ F_q '' Ioo (c_lo/q) (c_hi/q).
  have h_zero_in : (0:ℝ) ∈ Set.Ioo (F_q q (c_hi/q)) (F_q q (c_lo/q)) :=
    ⟨hFneg, hFpos⟩
  have h_image : Set.Ioo (F_q q (c_hi/q)) (F_q q (c_lo/q)) ⊆
      (fun a => F_q q a) '' Set.Ioo (c_lo/q) (c_hi/q) :=
    intermediate_value_Ioo' (le_of_lt h_div_lt) hCont_Icc
  obtain ⟨α, hα_mem, hα_val⟩ := h_image h_zero_in
  have hα_pos : 0 < α := lt_trans h_clo_div_pos hα_mem.1
  have hα_lt_one : α < 1 := lt_trans hα_mem.2 h_chi_div_lt_one
  -- α satisfies IsAStar q α (which unfolds to 0 < α ∧ α < 1 ∧ F_q q α = 0).
  -- By uniqueness, α = a_star q.
  obtain ⟨hUnique, hStar⟩ := FqHasUniqueInteriorZero q hq
  obtain ⟨hStar1, hStar2, hStar3⟩ := hStar
  have hα_eq : α = a_star q :=
    hUnique.unique
      (show 0 < α ∧ α < 1 ∧ F_q q α = 0 from ⟨hα_pos, hα_lt_one, hα_val⟩)
      (show 0 < a_star q ∧ a_star q < 1 ∧ F_q q (a_star q) = 0 from
        ⟨hStar1, hStar2, hStar3⟩)
  -- Therefore a_star q ∈ (c_lo/q, c_hi/q).
  rw [hα_eq] at hα_mem
  obtain ⟨h_a_gt, h_a_lt⟩ := hα_mem
  -- Multiply by q to get c_lo < q * a_star q < c_hi.
  have h_q_a_gt : c_lo < q * a_star q := by
    rw [div_lt_iff₀ hq_pos] at h_a_gt
    linarith
  have h_q_a_lt : q * a_star q < c_hi := by
    rw [lt_div_iff₀ hq_pos] at h_a_lt
    linarith
  -- |q * a_star q - 1/2| ≤ ε' ≤ ε.
  have h_diff_lo : -ε' < q * a_star q - 1/2 := by
    simp only [hc_lo_def] at h_q_a_gt; linarith
  have h_diff_hi : q * a_star q - 1/2 < ε' := by
    simp only [hc_hi_def] at h_q_a_lt; linarith
  have h_abs : |q * a_star q - 1/2| < ε' := by
    rw [abs_lt]
    exact ⟨h_diff_lo, h_diff_hi⟩
  -- Finish: dist (q * a_star q) (1/2) = |q * a_star q - 1/2| ≤ ε' ≤ ε.
  rw [Real.dist_eq]
  linarith

open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.FqHasUniqueInteriorZero

theorem DeltaStarAsymptotic :
    Filter.Tendsto delta_star Filter.atTop (nhds (2 : ℝ)) := by
  -- Step 0: q * a_star q → 1/2.
  have hq_astar : Filter.Tendsto (fun q : ℝ => q * a_star q) Filter.atTop (nhds ((1:ℝ)/2)) :=
    AStarAsymptotic

  -- Step 1: 1/q → 0 (and q⁻¹ → 0).
  have h_inv_q : Filter.Tendsto (fun q : ℝ => q⁻¹) Filter.atTop (nhds (0 : ℝ)) :=
    tendsto_inv_atTop_zero
  have h_one_div_q : Filter.Tendsto (fun q : ℝ => (1 : ℝ) / q) Filter.atTop (nhds (0 : ℝ)) := by
    have h1 : (fun q : ℝ => (1 : ℝ) / q) = (fun q : ℝ => q⁻¹) := by
      funext q; rw [one_div]
    rw [h1]; exact h_inv_q

  -- Step 2: a_star q → 0.
  have h_astar_zero : Filter.Tendsto (fun q : ℝ => a_star q) Filter.atTop (nhds (0 : ℝ)) := by
    have h_prod : Filter.Tendsto (fun q : ℝ => (q * a_star q) * q⁻¹) Filter.atTop
        (nhds (((1:ℝ)/2) * 0)) := hq_astar.mul h_inv_q
    have h_target : ((1:ℝ)/2) * (0 : ℝ) = 0 := by ring
    rw [h_target] at h_prod
    have h_eq : ∀ᶠ q : ℝ in Filter.atTop, (q * a_star q) * q⁻¹ = a_star q := by
      filter_upwards [Filter.eventually_gt_atTop (0 : ℝ)] with q hq
      have hq_ne : q ≠ 0 := ne_of_gt hq
      field_simp
    exact h_prod.congr' h_eq

  -- Step 3: 1 - a_star q → 1.
  have h_one_minus : Filter.Tendsto (fun q : ℝ => 1 - a_star q) Filter.atTop (nhds (1 : ℝ)) := by
    have h := Filter.Tendsto.const_sub (1:ℝ) h_astar_zero
    simpa using h

  -- Step 4: (1 - a_star q)^(1/q) → 1.
  have h_denom_aux : Filter.Tendsto (fun q : ℝ => (1 - a_star q) ^ ((1:ℝ)/q)) Filter.atTop
      (nhds ((1:ℝ) ^ (0:ℝ))) :=
    h_one_minus.rpow h_one_div_q (Or.inl one_ne_zero)
  have h_denom : Filter.Tendsto (fun q : ℝ => (1 - a_star q) ^ ((1:ℝ)/q)) Filter.atTop
      (nhds (1 : ℝ)) := by
    have h_pow : (1:ℝ) ^ (0:ℝ) = 1 := Real.rpow_zero 1
    rw [h_pow] at h_denom_aux
    exact h_denom_aux

  -- Step 5: (a_star q)^(1/q) → 1.
  have h_log_id : Real.log =o[Filter.atTop] (id : ℝ → ℝ) := Real.isLittleO_log_id_atTop
  have h_log_div : Filter.Tendsto (fun q : ℝ => Real.log q / q) Filter.atTop (nhds 0) := by
    have h := h_log_id.tendsto_div_nhds_zero
    simpa [Function.id_def] using h

  have h_evt_q_gt_one : ∀ᶠ q : ℝ in Filter.atTop, 1 < q := Filter.eventually_gt_atTop 1
  have h_qastar_gt : ∀ᶠ q : ℝ in Filter.atTop, (1:ℝ)/4 < q * a_star q := by
    have : ∀ᶠ x in nhds ((1:ℝ)/2), (1:ℝ)/4 < x := eventually_gt_nhds (by norm_num : (1:ℝ)/4 < 1/2)
    exact hq_astar.eventually this
  have h_qastar_lt : ∀ᶠ q : ℝ in Filter.atTop, q * a_star q < (1:ℝ) := by
    have : ∀ᶠ x in nhds ((1:ℝ)/2), x < (1:ℝ) := eventually_lt_nhds (by norm_num : (1:ℝ)/2 < 1)
    exact hq_astar.eventually this

  have h_evt_main : ∀ᶠ q : ℝ in Filter.atTop,
      0 < a_star q ∧ a_star q < 1/q ∧ 1/(4*q) < a_star q ∧ 1 < q := by
    filter_upwards [h_evt_q_gt_one, h_qastar_gt, h_qastar_lt] with q hq hgt hlt
    have hq_pos : 0 < q := lt_trans zero_lt_one hq
    have h_astar_lt_half := AStarLessThanOneHalf q hq
    have ha_pos : 0 < a_star q := h_astar_lt_half.1
    have ha_lt_inv_q : a_star q < 1/q := by
      rw [lt_div_iff₀ hq_pos]
      linarith [hlt]
    have ha_gt_qtr : 1/(4*q) < a_star q := by
      have h4q_pos : 0 < 4 * q := by linarith
      rw [div_lt_iff₀ h4q_pos]
      nlinarith [hgt, hq_pos, ha_pos]
    exact ⟨ha_pos, ha_lt_inv_q, ha_gt_qtr, hq⟩

  -- Show g(q) := (1/q) * log(a_star q) → 0.
  have h_log_div_g : Filter.Tendsto (fun q : ℝ => (1/q) * Real.log (a_star q)) Filter.atTop
      (nhds (0 : ℝ)) := by
    rw [Metric.tendsto_atTop]
    intro ε hε
    have h3 : 0 < ε / 3 := by linarith
    rw [Metric.tendsto_atTop] at h_log_div
    obtain ⟨N1, hN1⟩ := h_log_div (ε / 3) h3
    have h_const_div_q : Filter.Tendsto (fun q : ℝ => Real.log 4 / q) Filter.atTop (nhds (0:ℝ)) := by
      have hh : Filter.Tendsto (fun q : ℝ => Real.log 4 * q⁻¹) Filter.atTop
          (nhds (Real.log 4 * 0)) := h_inv_q.const_mul (Real.log 4)
      have ht : Real.log 4 * (0 : ℝ) = 0 := by ring
      rw [ht] at hh
      have h_eq : (fun q : ℝ => Real.log 4 * q⁻¹) = (fun q : ℝ => Real.log 4 / q) := by
        funext q; rw [div_eq_mul_inv]
      rw [h_eq] at hh
      exact hh
    rw [Metric.tendsto_atTop] at h_const_div_q
    obtain ⟨N2, hN2⟩ := h_const_div_q (ε / 3) h3
    rw [Filter.eventually_atTop] at h_evt_main
    obtain ⟨N3, hN3⟩ := h_evt_main
    refine ⟨max (max N1 N2) N3, ?_⟩
    intro q hq_ge
    have hq_ge_N1 : q ≥ N1 := le_trans (le_trans (le_max_left _ _) (le_max_left _ _)) hq_ge
    have hq_ge_N2 : q ≥ N2 := le_trans (le_trans (le_max_right _ _) (le_max_left _ _)) hq_ge
    have hq_ge_N3 : q ≥ N3 := le_trans (le_max_right _ _) hq_ge
    have h_log_div_close := hN1 q hq_ge_N1
    have h_const_close := hN2 q hq_ge_N2
    obtain ⟨ha_pos, ha_lt_inv_q, ha_gt_qtr, hq_gt_one⟩ := hN3 q hq_ge_N3
    have hq_pos : 0 < q := lt_trans zero_lt_one hq_gt_one
    have hq_inv_pos : 0 < 1/q := by positivity
    have h_log_upper : Real.log (a_star q) < -Real.log q := by
      have h_log_lt : Real.log (a_star q) < Real.log (1/q) :=
        Real.log_lt_log ha_pos ha_lt_inv_q
      have h_log_inv : Real.log (1/q) = -Real.log q := by
        rw [Real.log_div one_ne_zero (ne_of_gt hq_pos), Real.log_one]
        ring
      linarith
    have h_log_lower : Real.log (a_star q) > -(Real.log 4 + Real.log q) := by
      have h4q_pos : (0:ℝ) < 4 * q := by linarith
      have h_log_lt : Real.log (1/(4*q)) < Real.log (a_star q) :=
        Real.log_lt_log (by positivity) ha_gt_qtr
      have h_log_inv : Real.log (1/(4*q)) = -(Real.log 4 + Real.log q) := by
        rw [Real.log_div one_ne_zero (ne_of_gt h4q_pos), Real.log_one]
        rw [Real.log_mul (by norm_num : (4:ℝ) ≠ 0) (ne_of_gt hq_pos)]
        ring
      linarith
    have h_g_upper : (1/q) * Real.log (a_star q) < -Real.log q / q := by
      have h := mul_lt_mul_of_pos_left h_log_upper hq_inv_pos
      rw [show (1/q) * (-Real.log q) = -Real.log q / q by ring] at h
      exact h
    have h_g_lower : (1/q) * Real.log (a_star q) > -((Real.log 4 + Real.log q)/q) := by
      have h := mul_lt_mul_of_pos_left h_log_lower hq_inv_pos
      have heq : (1/q) * (-(Real.log 4 + Real.log q)) = -((Real.log 4 + Real.log q) / q) := by
        ring
      rw [heq] at h
      exact h
    rw [Real.dist_eq, sub_zero] at h_log_div_close
    rw [Real.dist_eq, sub_zero] at h_const_close
    rw [Real.dist_eq, sub_zero]
    -- Need |1/q * log(a_star q)| < ε.
    rw [abs_lt]
    refine ⟨?_, ?_⟩
    · -- -ε < 1/q * log(a_star q)
      -- We have 1/q * log(a_star q) > -((log 4 + log q)/q)
      -- = -(log 4 / q + log q / q)
      -- ≥ -(|log 4 / q| + |log q / q|)
      -- > -(ε/3 + ε/3) = -2ε/3 > -ε
      have h1 : -((Real.log 4 + Real.log q)/q) = -(Real.log 4 / q) - (Real.log q / q) := by
        have hq_ne : q ≠ 0 := ne_of_gt hq_pos
        field_simp
        ring
      rw [h1] at h_g_lower
      have h_abs1 : -(Real.log 4 / q) ≥ -|Real.log 4 / q| := neg_le_neg (le_abs_self _)
      have h_abs2 : -(Real.log q / q) ≥ -|Real.log q / q| := neg_le_neg (le_abs_self _)
      have h_combined : -(Real.log 4 / q) - (Real.log q / q) ≥ -|Real.log 4 / q| - |Real.log q / q| := by
        linarith
      have h_bound : -|Real.log 4 / q| - |Real.log q / q| > -(ε/3) - (ε/3) := by linarith
      have h_eps : -(ε/3) - (ε/3) ≥ -ε := by linarith
      linarith
    · -- 1/q * log(a_star q) < ε
      -- 1/q * log(a_star q) < -log q / q ≤ |log q / q| < ε/3 < ε
      have h_abs : -(Real.log q / q) ≤ |Real.log q / q| := neg_le_abs _
      have heq : -Real.log q / q = -(Real.log q / q) := by ring
      rw [heq] at h_g_upper
      linarith

  -- 6e: (a_star q)^(1/q) = exp((1/q) * log(a_star q)) eventually.
  have h_astar_pow : Filter.Tendsto (fun q : ℝ => (a_star q) ^ ((1:ℝ)/q)) Filter.atTop
      (nhds (1 : ℝ)) := by
    have h_exp_tendsto : Filter.Tendsto (fun q : ℝ => Real.exp ((1/q) * Real.log (a_star q)))
        Filter.atTop (nhds (Real.exp 0)) :=
      Real.continuous_exp.continuousAt.tendsto.comp h_log_div_g
    have h_exp_zero : Real.exp 0 = 1 := Real.exp_zero
    rw [h_exp_zero] at h_exp_tendsto
    have h_eq : ∀ᶠ q : ℝ in Filter.atTop,
        Real.exp ((1/q) * Real.log (a_star q)) = (a_star q) ^ ((1:ℝ)/q) := by
      filter_upwards [h_evt_main] with q hq_data
      obtain ⟨ha_pos, _, _, _⟩ := hq_data
      rw [Real.rpow_def_of_pos ha_pos]
      ring_nf
    exact h_exp_tendsto.congr' h_eq

  -- Step 7: Numerator → 2.
  have h_num : Filter.Tendsto (fun q : ℝ => (a_star q) ^ ((1:ℝ)/q) + 1 - 2 * (a_star q))
      Filter.atTop (nhds (2 : ℝ)) := by
    have h1 : Filter.Tendsto (fun q : ℝ => (a_star q) ^ ((1:ℝ)/q) + 1) Filter.atTop
        (nhds ((1:ℝ) + 1)) := h_astar_pow.add_const 1
    have h2 : Filter.Tendsto (fun q : ℝ => 2 * a_star q) Filter.atTop (nhds (0 : ℝ)) := by
      have h := h_astar_zero.const_mul (2 : ℝ)
      have ht : (2 : ℝ) * 0 = 0 := by ring
      rw [ht] at h
      exact h
    have h3 : Filter.Tendsto (fun q : ℝ => ((a_star q) ^ ((1:ℝ)/q) + 1) - 2 * a_star q) Filter.atTop
        (nhds ((1 + 1) - 0)) := h1.sub h2
    have ht : ((1:ℝ) + 1) - 0 = 2 := by ring
    rw [ht] at h3
    have h_fun_eq : (fun q : ℝ => ((a_star q) ^ ((1:ℝ)/q) + 1) - 2 * a_star q) =
        (fun q : ℝ => (a_star q) ^ ((1:ℝ)/q) + 1 - 2 * (a_star q)) := by
      funext q; ring
    rw [h_fun_eq] at h3
    exact h3

  -- Step 8: delta_star q → 2/1 = 2.
  have h_div_aux : Filter.Tendsto
      (fun q : ℝ => ((a_star q) ^ ((1:ℝ)/q) + 1 - 2 * (a_star q)) /
        (1 - a_star q) ^ ((1:ℝ)/q))
      Filter.atTop (nhds ((2:ℝ) / 1)) :=
    h_num.div h_denom one_ne_zero
  have h_div : Filter.Tendsto
      (fun q : ℝ => ((a_star q) ^ ((1:ℝ)/q) + 1 - 2 * (a_star q)) /
        (1 - a_star q) ^ ((1:ℝ)/q))
      Filter.atTop (nhds (2 : ℝ)) := by
    have ht : (2:ℝ) / 1 = 2 := by norm_num
    rw [ht] at h_div_aux
    exact h_div_aux

  -- delta_star q is the fraction.
  have h_eq_final : delta_star = (fun q : ℝ => ((a_star q) ^ ((1:ℝ)/q) + 1 - 2 * (a_star q)) /
        (1 - a_star q) ^ ((1:ℝ)/q)) := by
    funext q; rfl
  rw [h_eq_final]
  exact h_div

open Workspace.ProofLemmas.LambdaStarDef
open Workspace.ProofLemmas.DeltaStarDef

theorem LambdaStarAsymptotic :
    Filter.Tendsto lambda_star Filter.atTop (nhds ((1:ℝ)/3)) := by
  -- Step 1: q/(q-1) → 1 as q → ∞.
  -- We have q/(q-1) = 1 + 1/(q-1).
  have h_tendsto_id : Filter.Tendsto (fun q : ℝ => q) Filter.atTop Filter.atTop :=
    Filter.tendsto_id
  have h_tendsto_qm1_atTop : Filter.Tendsto (fun q : ℝ => q - 1) Filter.atTop Filter.atTop := by
    simpa using Filter.tendsto_atTop_add_const_right Filter.atTop (-1 : ℝ) h_tendsto_id
  have h_tendsto_inv_qm1 : Filter.Tendsto (fun q : ℝ => (q - 1)⁻¹) Filter.atTop (nhds (0 : ℝ)) :=
    Filter.Tendsto.comp tendsto_inv_atTop_zero h_tendsto_qm1_atTop
  -- q/(q-1) = 1 + 1/(q-1) for q ≠ 1
  have h_q_div_qm1 : Filter.Tendsto (fun q : ℝ => q / (q - 1)) Filter.atTop (nhds (1 : ℝ)) := by
    have : Filter.Tendsto (fun q : ℝ => 1 + (q - 1)⁻¹) Filter.atTop (nhds ((1 : ℝ) + 0)) :=
      Filter.Tendsto.const_add 1 h_tendsto_inv_qm1
    have h_eq : ∀ᶠ q : ℝ in Filter.atTop, 1 + (q - 1)⁻¹ = q / (q - 1) := by
      filter_upwards [Filter.eventually_gt_atTop (1 : ℝ)] with q hq
      have hqm1_ne : q - 1 ≠ 0 := by
        intro h
        have : q = 1 := by linarith
        linarith
      field_simp
      ring
    have h1 : Filter.Tendsto (fun q : ℝ => 1 + (q - 1)⁻¹) Filter.atTop (nhds (1 : ℝ)) := by
      simpa using this
    exact h1.congr' h_eq
  -- Step 2: (q-1)/q → 1, so -((q-1)/q) → -1.
  have h_inv_q : Filter.Tendsto (fun q : ℝ => q⁻¹) Filter.atTop (nhds (0 : ℝ)) :=
    tendsto_inv_atTop_zero
  have h_qm1_div_q : Filter.Tendsto (fun q : ℝ => (q - 1) / q) Filter.atTop (nhds (1 : ℝ)) := by
    have h0 : Filter.Tendsto (fun q : ℝ => 1 - q⁻¹) Filter.atTop (nhds ((1 : ℝ) - 0)) :=
      Filter.Tendsto.const_sub 1 h_inv_q
    have h_eq : ∀ᶠ q : ℝ in Filter.atTop, 1 - q⁻¹ = (q - 1) / q := by
      filter_upwards [Filter.eventually_gt_atTop (0 : ℝ)] with q hq
      have hq_ne : q ≠ 0 := ne_of_gt hq
      field_simp
    have h1 : Filter.Tendsto (fun q : ℝ => 1 - q⁻¹) Filter.atTop (nhds (1 : ℝ)) := by
      simpa using h0
    exact h1.congr' h_eq
  have h_neg_qm1_div_q : Filter.Tendsto (fun q : ℝ => -((q - 1) / q)) Filter.atTop (nhds (-1 : ℝ)) := by
    have := h_qm1_div_q.neg
    simpa using this
  -- Step 3: delta_star q → 2.
  have h_delta : Filter.Tendsto delta_star Filter.atTop (nhds (2 : ℝ)) := DeltaStarAsymptotic
  -- Step 4: (delta_star q)^(q/(q-1)) → 2^1 = 2.
  have h_dpow : Filter.Tendsto (fun q : ℝ => (delta_star q) ^ (q / (q - 1))) Filter.atTop
      (nhds ((2 : ℝ) ^ (1 : ℝ))) :=
    h_delta.rpow h_q_div_qm1 (Or.inl (by norm_num : (2 : ℝ) ≠ 0))
  have h_two_pow_one : (2 : ℝ) ^ (1 : ℝ) = 2 := Real.rpow_one 2
  have h_dpow' : Filter.Tendsto (fun q : ℝ => (delta_star q) ^ (q / (q - 1))) Filter.atTop
      (nhds (2 : ℝ)) := by
    rw [← h_two_pow_one]; exact h_dpow
  -- Step 5: 1 + (delta_star q)^(q/(q-1)) → 3.
  have h_sum : Filter.Tendsto (fun q : ℝ => 1 + (delta_star q) ^ (q / (q - 1))) Filter.atTop
      (nhds ((1 : ℝ) + 2)) :=
    Filter.Tendsto.const_add 1 h_dpow'
  have h_sum' : Filter.Tendsto (fun q : ℝ => 1 + (delta_star q) ^ (q / (q - 1))) Filter.atTop
      (nhds (3 : ℝ)) := by
    have : (1 : ℝ) + 2 = 3 := by norm_num
    rw [← this]; exact h_sum
  -- Step 6: (1 + ...)^(-((q-1)/q)) → 3^(-1).
  have h_full : Filter.Tendsto
      (fun q : ℝ => (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q)))
      Filter.atTop (nhds ((3 : ℝ) ^ (-1 : ℝ))) :=
    h_sum'.rpow h_neg_qm1_div_q (Or.inl (by norm_num : (3 : ℝ) ≠ 0))
  have h_three_inv : (3 : ℝ) ^ (-1 : ℝ) = 1/3 := by
    rw [Real.rpow_neg_one]
    norm_num
  have h_full' : Filter.Tendsto
      (fun q : ℝ => (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q)))
      Filter.atTop (nhds ((1 : ℝ)/3)) := by
    rw [← h_three_inv]; exact h_full
  -- Step 7: lambda_star q = (1 + ...)^(-((q-1)/q)) eventually.
  have h_eq : ∀ᶠ q : ℝ in Filter.atTop, lambda_star q =
      (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q)) := by
    filter_upwards [Filter.eventually_gt_atTop (1 : ℝ)] with q hq
    have hq_ne1 : q ≠ 1 := ne_of_gt hq
    unfold lambda_star
    rw [if_neg hq_ne1, if_pos hq]
  exact h_full'.congr' (Filter.EventuallyEq.symm h_eq)

open Workspace.ProofLemmas.UBDef
open Workspace.ProofLemmas.LambdaStarDef

theorem UBLimitThree :
    Filter.Tendsto UB Filter.atTop (nhds (3 : ℝ)) := by
  have h_lam : Filter.Tendsto lambda_star Filter.atTop (nhds ((1:ℝ)/3)) :=
    LambdaStarAsymptotic
  -- 1 / lambda_star q tends to 1 / (1/3) = 3
  have h_inv : Filter.Tendsto (fun q => 1 / lambda_star q) Filter.atTop (nhds (3 : ℝ)) := by
    have h_ne : ((1:ℝ)/3) ≠ 0 := by norm_num
    have h_div : Filter.Tendsto (fun q => 1 / lambda_star q) Filter.atTop (nhds (1 / ((1:ℝ)/3))) :=
      Filter.Tendsto.div tendsto_const_nhds h_lam h_ne
    have h_eq : (1 : ℝ) / ((1:ℝ)/3) = 3 := by norm_num
    rw [h_eq] at h_div
    exact h_div
  -- UB q = 1 / lambda_star q for q ≥ 1
  apply h_inv.congr'
  filter_upwards [Filter.eventually_ge_atTop (1 : ℝ)] with q hq
  simp only [UB, if_pos hq]

open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.FqSignAt0Pos

theorem AStarAtTwo : a_star 2 = 1 - Real.sqrt 3 / 2 := by
  -- Get existence + uniqueness of the interior zero from FqHasUniqueInteriorZero.
  have h := FqHasUniqueInteriorZero 2 one_lt_two
  obtain ⟨hUnique, hStar⟩ := h
  -- Destructure IsAStar 2 (a_star 2): 0 < a_star 2, a_star 2 < 1, F_q 2 (a_star 2) = 0
  obtain ⟨h1, h2, h3⟩ := hStar
  -- Build the algebraic facts about 1 - √3/2.
  set a : ℝ := 1 - Real.sqrt 3 / 2 with ha_def
  -- 0 ≤ √3
  have h_sqrt3_nn : 0 ≤ Real.sqrt 3 := Real.sqrt_nonneg 3
  -- √3 < 2 since 3 < 4
  have h_sqrt3_lt_two : Real.sqrt 3 < 2 := by
    have : Real.sqrt 3 < Real.sqrt 4 := by
      apply Real.sqrt_lt_sqrt
      · norm_num
      · norm_num
    rw [show (4 : ℝ) = 2 ^ 2 from by norm_num] at this
    rw [Real.sqrt_sq (by norm_num : (2 : ℝ) ≥ 0)] at this
    exact this
  -- 1 < √3
  have h_one_lt_sqrt3 : 1 < Real.sqrt 3 := by
    have : Real.sqrt 1 < Real.sqrt 3 := by
      apply Real.sqrt_lt_sqrt
      · norm_num
      · norm_num
    rwa [Real.sqrt_one] at this
  -- a > 0
  have ha_pos : 0 < a := by
    simp only [ha_def]
    linarith
  -- a < 1
  have ha_lt_one : a < 1 := by
    simp only [ha_def]
    linarith
  -- a = ((√3 - 1)/2)^2
  have h3_sq : Real.sqrt 3 * Real.sqrt 3 = 3 := Real.mul_self_sqrt (by norm_num : (3:ℝ) ≥ 0)
  have ha_eq_sq : a = ((Real.sqrt 3 - 1) / 2) ^ 2 := by
    simp only [ha_def]
    field_simp
    ring_nf
    nlinarith [h3_sq]
  -- (√3 - 1)/2 > 0
  have h_half_pos : 0 < (Real.sqrt 3 - 1) / 2 := by linarith
  -- √a = (√3 - 1)/2
  have h_sqrt_a : Real.sqrt a = (Real.sqrt 3 - 1) / 2 := by
    rw [ha_eq_sq]
    rw [Real.sqrt_sq (le_of_lt h_half_pos)]
  -- The exponent (1 - 2)/2 simplifies to -(1/2)
  have h_exp_eq : ((1 - 2) / 2 : ℝ) = -(1/2 : ℝ) := by norm_num
  -- a^(1/2) = √a
  have h_a_half : a ^ ((1:ℝ)/2) = Real.sqrt a := by
    rw [Real.sqrt_eq_rpow]
  -- a^(-1/2) = (a^(1/2))⁻¹
  have h_a_neg_half : a ^ (-(1:ℝ)/2) = (a ^ ((1:ℝ)/2))⁻¹ := by
    rw [show -(1:ℝ)/2 = -(1/2:ℝ) from by ring]
    rw [Real.rpow_neg (le_of_lt ha_pos)]
  -- Combine
  have h_a_pow : a ^ ((1 - 2) / 2 : ℝ) = (Real.sqrt a)⁻¹ := by
    rw [h_exp_eq]
    rw [show -(1/2:ℝ) = -(1:ℝ)/2 from by ring]
    rw [h_a_neg_half, h_a_half]
  -- Compute F_q 2 a = 0
  have hF_zero : F_q 2 a = 0 := by
    unfold F_q
    rw [h_a_pow, h_sqrt_a]
    have h_ne : Real.sqrt 3 - 1 ≠ 0 := ne_of_gt (by linarith)
    field_simp
    nlinarith [h3_sq, h_one_lt_sqrt3, h_sqrt3_lt_two, h_sqrt3_nn]
  -- Use uniqueness to identify a_star 2 with a.
  exact (hUnique.unique
    (show 0 < a_star 2 ∧ a_star 2 < 1 ∧ F_q 2 (a_star 2) = 0 from ⟨h1, h2, h3⟩)
    (show 0 < a ∧ a < 1 ∧ F_q 2 a = 0 from ⟨ha_pos, ha_lt_one, hF_zero⟩))

open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.FqHasUniqueInteriorZero

theorem DeltaStarSqAtTwo :
    (delta_star 2) ^ 2 = 6 * Real.sqrt 3 - 9 := by
  have hAStar : a_star 2 = 1 - Real.sqrt 3 / 2 := AStarAtTwo
  -- basic sqrt 3 facts
  have h3sq : Real.sqrt 3 * Real.sqrt 3 = 3 := Real.mul_self_sqrt (by norm_num : (3:ℝ) ≥ 0)
  have h3pos : 0 < Real.sqrt 3 := Real.sqrt_pos.mpr (by norm_num)
  have h3lt2 : Real.sqrt 3 < 2 := by
    have hh : Real.sqrt 3 < Real.sqrt 4 := Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
    have h4 : Real.sqrt 4 = 2 := by
      rw [show (4:ℝ) = 2^2 by norm_num, Real.sqrt_sq (by norm_num : (2:ℝ) ≥ 0)]
    linarith
  have h3gt1 : 1 < Real.sqrt 3 := by
    have hh : Real.sqrt 1 < Real.sqrt 3 := Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
    rw [Real.sqrt_one] at hh
    exact hh
  -- 1 - √3 / 2 > 0 and √3/2 > 0
  have h_a_pos : 0 < 1 - Real.sqrt 3 / 2 := by linarith
  have h_one_minus_a : 1 - (1 - Real.sqrt 3 / 2) = Real.sqrt 3 / 2 := by ring
  have h_one_minus_a_pos : 0 < Real.sqrt 3 / 2 := by linarith
  -- key identity: √(1 - √3/2) = (√3 - 1)/2
  have hkey : Real.sqrt (1 - Real.sqrt 3 / 2) = (Real.sqrt 3 - 1) / 2 := by
    have hnonneg : 0 ≤ (Real.sqrt 3 - 1) / 2 := by linarith
    rw [show (1 - Real.sqrt 3 / 2) = ((Real.sqrt 3 - 1) / 2)^2 by nlinarith [h3sq]]
    exact Real.sqrt_sq hnonneg
  -- unfold delta_star and substitute a_star 2
  unfold delta_star
  rw [hAStar]
  -- Convert rpow ((1:ℝ)/2) to sqrt
  rw [← Real.sqrt_eq_rpow, ← Real.sqrt_eq_rpow]
  rw [h_one_minus_a, hkey]
  -- denominator √(√3/2) is positive, with square equal to √3/2
  have hden : Real.sqrt (Real.sqrt 3 / 2) > 0 := Real.sqrt_pos.mpr h_one_minus_a_pos
  have hden_sq : (Real.sqrt (Real.sqrt 3 / 2))^2 = Real.sqrt 3 / 2 :=
    Real.sq_sqrt (le_of_lt h_one_minus_a_pos)
  field_simp
  rw [hden_sq]
  ring_nf
  nlinarith [h3sq, h3pos, sq_nonneg (Real.sqrt 3 - 1), sq_nonneg (Real.sqrt 3)]

theorem SixSqrtThreeMinusEightPos : 6 * Real.sqrt 3 - 8 > 0 := by
  nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 3), Real.sqrt_nonneg 3]

open Workspace.ProofLemmas.UBDef
open Workspace.ProofLemmas.LambdaStarDef
open Workspace.ProofLemmas.DeltaStarDef

theorem UBTwo : UB 2 = Real.sqrt (6 * Real.sqrt 3 - 8) := by
  have h1le2 : (1 : ℝ) ≤ 2 := by norm_num
  have h1lt2 : (1 : ℝ) < 2 := by norm_num
  have h2ne1 : (2 : ℝ) ≠ 1 := by norm_num
  have hpos : (0 : ℝ) < 6 * Real.sqrt 3 - 8 := SixSqrtThreeMinusEightPos
  have hd2 : (delta_star 2) ^ 2 = 6 * Real.sqrt 3 - 9 := DeltaStarSqAtTwo
  -- (delta_star 2) ^ ((2:ℝ)/(2-1)) = (delta_star 2)^2 (as real number)
  have hexp : ((2 : ℝ) / (2 - 1)) = (2 : ℕ) := by norm_num
  have h_rpow_eq : (delta_star 2) ^ ((2 : ℝ) / (2 - 1)) = (delta_star 2) ^ 2 := by
    rw [hexp, Real.rpow_natCast]
  -- 1 + (delta_star 2)^(2/(2-1)) = 6 * sqrt 3 - 8
  have h_sum : 1 + (delta_star 2) ^ ((2 : ℝ) / (2 - 1)) = 6 * Real.sqrt 3 - 8 := by
    rw [h_rpow_eq, hd2]; ring
  -- lambda_star 2 = (6*sqrt 3 - 8) ^ (-1/2)
  have h_exponent : -((2 - 1 : ℝ)/2) = -(1/2 : ℝ) := by norm_num
  have h_lambda : lambda_star 2 = (6 * Real.sqrt 3 - 8) ^ (-(1/2 : ℝ)) := by
    unfold lambda_star
    rw [if_neg h2ne1, if_pos h1lt2, h_sum, h_exponent]
  -- UB 2 = 1 / lambda_star 2
  have h_UB : UB 2 = 1 / lambda_star 2 := by
    unfold UB
    rw [if_pos h1le2]
  rw [h_UB, h_lambda]
  -- 1 / x^(-1/2) = sqrt(x)
  rw [Real.rpow_neg (le_of_lt hpos), one_div, inv_inv, ← Real.sqrt_eq_rpow]

open Finset

theorem OneDMedianMinimizesSumAbsDeviation
    {n : ℕ} (y : Fin n → ℝ) (mu : ℝ)
    (hlt : (Finset.univ.filter (fun i : Fin n => y i < mu)).card ≤ n / 2)
    (hgt : (Finset.univ.filter (fun i : Fin n => y i > mu)).card ≤ n / 2)
    (t : ℝ) :
    (∑ i, |y i - mu|) ≤ ∑ i, |y i - t| := by
  -- It suffices to show ∑ (|y i - t| - |y i - mu|) ≥ 0
  rw [← sub_nonneg]
  have hsum_eq : (∑ i, |y i - t|) - (∑ i, |y i - mu|) =
      ∑ i, (|y i - t| - |y i - mu|) := by
    rw [← Finset.sum_sub_distrib]
  rw [hsum_eq]
  -- Split into cases based on the sign of (t - mu)
  rcases le_total mu t with htmu | htmu
  · -- Case t ≥ mu
    -- For each i: pointwise lower bound
    -- If y i ≤ mu: |y i - t| - |y i - mu| = (t - y i) - (mu - y i) = t - mu ≥ 0
    -- If y i > mu: |y i - t| - |y i - mu| ≥ -(t - mu)
    --   because |y i - t| ≥ y i - t = (y i - mu) - (t - mu) = |y i - mu| - (t - mu)
    -- So pointwise: |y i - t| - |y i - mu| ≥ if y i ≤ mu then t - mu else mu - t
    set A : Finset (Fin n) := Finset.univ.filter (fun i => y i ≤ mu) with hA
    set B : Finset (Fin n) := Finset.univ.filter (fun i => mu < y i) with hB
    -- A and B are disjoint, A ∪ B = univ
    have hAB_disj : Disjoint A B := by
      rw [hA, hB]
      rw [Finset.disjoint_filter]
      intros i _ hi1 hi2
      linarith
    have hAB_union : A ∪ B = Finset.univ := by
      rw [hA, hB]
      ext i
      simp only [Finset.mem_union, Finset.mem_filter, Finset.mem_univ, true_and, iff_true]
      exact (lt_or_ge mu (y i)).symm.imp id id
    -- Define lower bound function
    have key : ∀ i : Fin n, (if y i ≤ mu then (t - mu) else (mu - t)) ≤ |y i - t| - |y i - mu| := by
      intro i
      by_cases h : y i ≤ mu
      · simp only [if_pos h]
        -- y i ≤ mu ≤ t, so |y i - t| = t - y i, |y i - mu| = mu - y i
        have h1 : |y i - t| = t - y i := by
          rw [abs_of_nonpos]; · ring
          linarith
        have h2 : |y i - mu| = mu - y i := by
          rw [abs_of_nonpos]; · ring
          linarith
        rw [h1, h2]; ring_nf; linarith
      · simp only [if_neg h]
        -- y i > mu, want: mu - t ≤ |y i - t| - |y i - mu|
        -- equivalently |y i - mu| + (mu - t) ≤ |y i - t|
        -- |y i - mu| = y i - mu (since y i > mu), so y i - mu + mu - t = y i - t ≤ |y i - t|. True.
        have hgt' : mu < y i := lt_of_not_ge h
        have h2 : |y i - mu| = y i - mu := by
          rw [abs_of_nonneg]; linarith
        rw [h2]
        have h3 : y i - t ≤ |y i - t| := le_abs_self _
        linarith
    -- Now sum the lower bound
    have hsum_lower : (∑ i, (if y i ≤ mu then (t - mu) else (mu - t))) ≤
        ∑ i, (|y i - t| - |y i - mu|) := Finset.sum_le_sum (fun i _ => key i)
    refine le_trans ?_ hsum_lower
    -- Compute ∑ (if y i ≤ mu then t-mu else mu-t)
    -- = (t - mu) * #A + (mu - t) * #B  where A = {y i ≤ mu}, B = {y i > mu}
    have hsum_split : (∑ i, (if y i ≤ mu then (t - mu) else (mu - t))) =
        A.card • (t - mu) + B.card • (mu - t) := by
      rw [← hAB_union, Finset.sum_union hAB_disj]
      have hA_eval : (∑ i ∈ A, (if y i ≤ mu then (t - mu) else (mu - t))) =
          A.card • (t - mu) := by
        rw [Finset.sum_congr rfl]
        · rw [Finset.sum_const]
        · intro i hi
          have : y i ≤ mu := by rw [hA, Finset.mem_filter] at hi; exact hi.2
          simp [this]
      have hB_eval : (∑ i ∈ B, (if y i ≤ mu then (t - mu) else (mu - t))) =
          B.card • (mu - t) := by
        rw [Finset.sum_congr rfl]
        · rw [Finset.sum_const]
        · intro i hi
          have : mu < y i := by rw [hB, Finset.mem_filter] at hi; exact hi.2
          have : ¬ y i ≤ mu := not_le.mpr this
          simp [this]
      rw [hA_eval, hB_eval]
    rw [hsum_split]
    -- A.card • (t - mu) + B.card • (mu - t) = (A.card - B.card) * (t - mu)
    -- We have B.card ≤ n/2 (from hgt) and A.card + B.card = n
    -- So A.card - B.card = n - 2 * B.card ≥ n - 2*(n/2) ≥ 0
    -- And t - mu ≥ 0
    simp only [nsmul_eq_mul]
    have hcard : A.card + B.card = n := by
      have : (A ∪ B).card = A.card + B.card := Finset.card_union_of_disjoint hAB_disj
      rw [hAB_union] at this
      simp at this
      linarith
    have hB_le : B.card ≤ n / 2 := by
      rw [hB]; exact hgt
    have hA_ge : (n : ℝ) - 2 * (B.card : ℝ) ≥ 0 := by
      have h2 : 2 * (n / 2) ≤ n := by omega
      have h3 : 2 * B.card ≤ n := le_trans (by linarith) h2
      have hcast : 2 * (B.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast h3
      linarith
    -- Goal: 0 ≤ A.card * (t - mu) + B.card * (mu - t)
    have : (A.card : ℝ) * (t - mu) + (B.card : ℝ) * (mu - t) =
        ((A.card : ℝ) - (B.card : ℝ)) * (t - mu) := by ring
    rw [this]
    have hAB_diff : (A.card : ℝ) - (B.card : ℝ) ≥ 0 := by
      have : ((A.card + B.card : ℕ) : ℝ) = (n : ℝ) := by exact_mod_cast hcard
      push_cast at this
      have hAcard_eq : (A.card : ℝ) = (n : ℝ) - (B.card : ℝ) := by linarith
      rw [hAcard_eq]; linarith
    have ht_pos : t - mu ≥ 0 := by linarith
    exact mul_nonneg hAB_diff ht_pos
  · -- Case t < mu (symmetric)
    set A : Finset (Fin n) := Finset.univ.filter (fun i => y i < mu) with hA
    set B : Finset (Fin n) := Finset.univ.filter (fun i => mu ≤ y i) with hB
    have hAB_disj : Disjoint A B := by
      rw [hA, hB]
      rw [Finset.disjoint_filter]
      intros i _ hi1 hi2
      linarith
    have hAB_union : A ∪ B = Finset.univ := by
      rw [hA, hB]
      ext i
      simp only [Finset.mem_union, Finset.mem_filter, Finset.mem_univ, true_and, iff_true]
      exact lt_or_ge (y i) mu
    -- For t < mu:
    -- If y i ≥ mu: y i ≥ mu > t, so |y i - t| = y i - t, |y i - mu| = y i - mu
    --   diff = (y i - t) - (y i - mu) = mu - t > 0
    -- If y i < mu: want mu - t ≤ |y i - t| - |y i - mu|? No, want: t - mu ≤ ...
    --   Actually we want (mu - t) - bound. We use: |y i - t| ≥ -(y i - t) = t - y i
    --     |y i - mu| = mu - y i
    --     diff = |y i - t| - (mu - y i) ≥ (t - y i) - (mu - y i) = t - mu
    -- So pointwise: |y i - t| - |y i - mu| ≥ if y i < mu then t - mu else mu - t
    have key : ∀ i : Fin n, (if y i < mu then (t - mu) else (mu - t)) ≤ |y i - t| - |y i - mu| := by
      intro i
      by_cases h : y i < mu
      · simp only [if_pos h]
        -- y i < mu, |y i - mu| = mu - y i
        have h2 : |y i - mu| = mu - y i := by
          rw [abs_of_nonpos]; · ring
          linarith
        rw [h2]
        -- want t - mu ≤ |y i - t| - (mu - y i)
        -- i.e., |y i - t| ≥ t - mu + mu - y i = t - y i
        have h3 : -(y i - t) ≤ |y i - t| := neg_le_abs _
        linarith
      · simp only [if_neg h]
        -- y i ≥ mu, and t < mu, so y i ≥ mu > t
        have hge : mu ≤ y i := not_lt.mp h
        have h1 : |y i - t| = y i - t := by
          rw [abs_of_nonneg]; linarith
        have h2 : |y i - mu| = y i - mu := by
          rw [abs_of_nonneg]; linarith
        rw [h1, h2]; ring_nf; linarith
    have hsum_lower : (∑ i, (if y i < mu then (t - mu) else (mu - t))) ≤
        ∑ i, (|y i - t| - |y i - mu|) := Finset.sum_le_sum (fun i _ => key i)
    refine le_trans ?_ hsum_lower
    have hsum_split : (∑ i, (if y i < mu then (t - mu) else (mu - t))) =
        A.card • (t - mu) + B.card • (mu - t) := by
      rw [← hAB_union, Finset.sum_union hAB_disj]
      have hA_eval : (∑ i ∈ A, (if y i < mu then (t - mu) else (mu - t))) =
          A.card • (t - mu) := by
        rw [Finset.sum_congr rfl]
        · rw [Finset.sum_const]
        · intro i hi
          have : y i < mu := by rw [hA, Finset.mem_filter] at hi; exact hi.2
          simp [this]
      have hB_eval : (∑ i ∈ B, (if y i < mu then (t - mu) else (mu - t))) =
          B.card • (mu - t) := by
        rw [Finset.sum_congr rfl]
        · rw [Finset.sum_const]
        · intro i hi
          have : mu ≤ y i := by rw [hB, Finset.mem_filter] at hi; exact hi.2
          have : ¬ y i < mu := not_lt.mpr this
          simp [this]
      rw [hA_eval, hB_eval]
    rw [hsum_split]
    simp only [nsmul_eq_mul]
    have hcard : A.card + B.card = n := by
      have : (A ∪ B).card = A.card + B.card := Finset.card_union_of_disjoint hAB_disj
      rw [hAB_union] at this
      simp at this
      linarith
    have hA_le : A.card ≤ n / 2 := by
      rw [hA]; exact hlt
    have : (A.card : ℝ) * (t - mu) + (B.card : ℝ) * (mu - t) =
        ((B.card : ℝ) - (A.card : ℝ)) * (mu - t) := by ring
    rw [this]
    have hBA_diff : (B.card : ℝ) - (A.card : ℝ) ≥ 0 := by
      have hBcard_eq : (B.card : ℝ) = (n : ℝ) - (A.card : ℝ) := by
        have : ((A.card + B.card : ℕ) : ℝ) = (n : ℝ) := by exact_mod_cast hcard
        push_cast at this; linarith
      have h2 : 2 * (n / 2) ≤ n := by omega
      have hAtimes : 2 * A.card ≤ n := le_trans (by linarith) h2
      have hcast : 2 * (A.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast hAtimes
      rw [hBcard_eq]; linarith
    have hmu_t_pos : mu - t ≥ 0 := by linarith
    exact mul_nonneg hBA_diff hmu_t_pos

open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost
open Workspace.ProofLemmas.UBDef

theorem MainTheoremApproxBoundQEqOne
    {n d : ℕ} (hd : 1 ≤ d) (P : Fin n → Fin d → ℝ)
    (m : Fin d → ℝ) (hm : IsCoordinateMedian m P) :
    socialCost 1 P m ≤ UB 1 * optSocialCost 1 P := by
  -- Step 1: UB 1 = 1, so RHS becomes optSocialCost 1 P
  have hUB1 : UB 1 = 1 := UBDef.2
  rw [hUB1, one_mul]
  -- Step 2: optSocialCost 1 P = ⨅ f, socialCost 1 P f. Show socialCost 1 P m ≤ socialCost 1 P f for every f.
  unfold optSocialCost
  refine le_ciInf (fun f => ?_)
  -- Step 3: Goal: socialCost 1 P m ≤ socialCost 1 P f
  -- socialCost 1 P g = ∑ i, lqNorm 1 (P i - g) = ∑ i, ∑ j, |P i j - g j|
  unfold socialCost
  -- Rewrite each lqNorm 1 to a sum of abs values
  have hrw_m : ∀ i : Fin n, lqNorm 1 (fun j => P i j - m j) =
      ∑ j, |P i j - m j| := fun i => lqNorm_one_eq_sum_abs _
  have hrw_f : ∀ i : Fin n, lqNorm 1 (fun j => P i j - f j) =
      ∑ j, |P i j - f j| := fun i => lqNorm_one_eq_sum_abs _
  rw [Finset.sum_congr rfl (fun i _ => hrw_m i),
      Finset.sum_congr rfl (fun i _ => hrw_f i)]
  -- Now goal: ∑ i, ∑ j, |P i j - m j| ≤ ∑ i, ∑ j, |P i j - f j|
  -- Swap order of summation on both sides
  rw [Finset.sum_comm (s := Finset.univ) (t := Finset.univ)
        (f := fun i j => |P i j - m j|),
      Finset.sum_comm (s := Finset.univ) (t := Finset.univ)
        (f := fun i j => |P i j - f j|)]
  -- Goal: ∑ j, ∑ i, |P i j - m j| ≤ ∑ j, ∑ i, |P i j - f j|
  -- Apply OneDMedianMinimizesSumAbsDeviation per coordinate j.
  apply Finset.sum_le_sum
  intro j _
  obtain ⟨hlt, hgt⟩ := hm j
  exact OneDMedianMinimizesSumAbsDeviation
    (fun i => P i j) (m j) hlt hgt (f j)

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormZeroIffEqZero
    (q : ℝ) (hq : 1 ≤ q) {d : ℕ} (hd : 1 ≤ d) (x : Fin d → ℝ) :
    lqNorm q x = 0 ↔ x = 0 := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_ne : (1 : ℝ) / q ≠ 0 := by
    rw [one_div]; exact inv_ne_zero hq_ne
  have hsum_nn : 0 ≤ ∑ j, |x j| ^ q := sum_abs_rpow_nonneg q x
  unfold lqNorm
  rw [Real.rpow_eq_zero hsum_nn h_inv_ne]
  constructor
  · intro hsum
    have hzero : ∀ j ∈ Finset.univ, |x j| ^ q = 0 := by
      rw [Finset.sum_eq_zero_iff_of_nonneg
        (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)] at hsum
      exact hsum
    funext j
    have hj : |x j| ^ q = 0 := hzero j (Finset.mem_univ j)
    have habs : |x j| = 0 := by
      have := (Real.rpow_eq_zero (abs_nonneg _) hq_ne).mp hj
      exact this
    have : x j = 0 := abs_eq_zero.mp habs
    simpa using this
  · intro hx
    subst hx
    apply Finset.sum_eq_zero
    intro j _
    simp [Real.zero_rpow hq_ne]

open Workspace.Types.CoordinateMedian

theorem MedianOfConstant {n d : ℕ} (hn : 1 ≤ n) (c : Fin d → ℝ) (m : Fin d → ℝ)
    (h : IsCoordinateMedian m (fun (_ : Fin n) (j : Fin d) => c j)) :
    m = c := by
  funext j
  obtain ⟨hlt, hgt⟩ := h j
  by_contra hne
  rcases lt_or_gt_of_ne hne with hmlt | hmgt
  · -- m j < c j: for every i, c j > m j, so the `>` filter equals univ.
    have hfilter :
        (Finset.univ.filter (fun _ : Fin n => c j > m j)) = Finset.univ := by
      apply Finset.filter_eq_self.mpr
      intro i _
      exact hmlt
    have hcard : (Finset.univ.filter (fun _ : Fin n => c j > m j)).card = n := by
      rw [hfilter]
      simp
    rw [hcard] at hgt
    omega
  · -- m j > c j: for every i, c j < m j, so the `<` filter equals univ.
    have hfilter :
        (Finset.univ.filter (fun _ : Fin n => c j < m j)) = Finset.univ := by
      apply Finset.filter_eq_self.mpr
      intro i _
      exact hmgt
    have hcard : (Finset.univ.filter (fun _ : Fin n => c j < m j)).card = n := by
      rw [hfilter]
      simp
    rw [hcard] at hlt
    omega

open Workspace.Types.LqNorm

theorem LqNormSubReverseTriangle {q : ℝ} (hq : 1 ≤ q) {d : ℕ} (x y : Fin d → ℝ) :
    lqNorm q x - lqNorm q y ≤ lqNorm q (fun j => x j - y j) := by
  -- Apply the Minkowski inequality `Real.Lp_add_le` to f = x - y, g = y.
  -- That gives: lqNorm q ((x-y)+y) ≤ lqNorm q (x-y) + lqNorm q y, i.e.
  --            lqNorm q x ≤ lqNorm q (x-y) + lqNorm q y.
  have hMink := Real.Lp_add_le (Finset.univ : Finset (Fin d))
    (fun j => x j - y j) (fun j => y j) hq
  -- Rewrite `(x j - y j) + y j` as `x j` inside the LHS sum.
  have hxeq : (∑ j, |(x j - y j) + y j| ^ q) = (∑ j, |x j| ^ q) := by
    refine Finset.sum_congr rfl ?_
    intro j _
    have : (x j - y j) + y j = x j := by ring
    rw [this]
  rw [hxeq] at hMink
  -- Now hMink : (∑ j, |x j|^q)^(1/q) ≤ (∑ j, |x j - y j|^q)^(1/q) + (∑ j, |y j|^q)^(1/q)
  -- These are exactly lqNorm q x, lqNorm q (fun j => x j - y j), and lqNorm q y.
  unfold lqNorm
  linarith

open scoped BigOperators
open Workspace.Types.SocialCost
open Workspace.Types.LqNorm

namespace SocialCostMinExistsProof

-- Auxiliary lemma: lqNorm bounds individual coordinates.
private lemma _scme_lqNorm_ge_abs_coord {q : ℝ} (hq : 1 ≤ q) {d : ℕ}
    (x : Fin d → ℝ) (j : Fin d) :
    |x j| ≤ lqNorm q x := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_pos : 0 < (1 : ℝ) / q := by positivity
  -- |x j|^q ≤ ∑ k, |x k|^q
  have h_pos : ∀ k, 0 ≤ |x k| ^ q := fun k => Real.rpow_nonneg (abs_nonneg _) q
  have h_le : |x j| ^ q ≤ ∑ k, |x k| ^ q := by
    have := Finset.single_le_sum (f := fun k => |x k| ^ q)
      (s := Finset.univ) (a := j)
      (fun k _ => h_pos k) (Finset.mem_univ j)
    exact this
  -- Take rpow (1/q) of both sides
  have h_lhs_nn : 0 ≤ |x j| ^ q := h_pos j
  have h_rhs_nn : 0 ≤ ∑ k, |x k| ^ q := sum_abs_rpow_nonneg q x
  have h2 : (|x j| ^ q) ^ ((1 : ℝ) / q) ≤ (∑ k, |x k| ^ q) ^ ((1 : ℝ) / q) :=
    Real.rpow_le_rpow h_lhs_nn h_le (le_of_lt h_inv_pos)
  -- Simplify (|x j|^q)^(1/q) = |x j|
  have habs_nn : (0 : ℝ) ≤ |x j| := abs_nonneg _
  have h3 : (|x j| ^ q) ^ ((1 : ℝ) / q) = |x j| := by
    rw [← Real.rpow_mul habs_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  rw [h3] at h2
  exact h2

-- Continuity of lqNorm
private lemma lqNorm_continuous {q : ℝ} (hq : 1 ≤ q) {d : ℕ} :
    Continuous (fun x : Fin d → ℝ => lqNorm q x) := by
  unfold lqNorm
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have h_inv_nn : 0 ≤ (1 : ℝ) / q := by positivity
  have hq_nn : 0 ≤ q := le_of_lt hq_pos
  -- continuous fun x => ∑ j, |x j|^q
  have h_inner : Continuous (fun x : Fin d → ℝ => ∑ j, |x j| ^ q) := by
    apply continuous_finset_sum
    intro j _
    exact (Real.continuous_rpow_const hq_nn).comp ((continuous_apply j).abs)
  -- continuous fun y => y^(1/q) on [0, ∞), well, on all reals when 1/q ≥ 0
  exact (Real.continuous_rpow_const h_inv_nn).comp h_inner

-- Continuity of socialCost
private lemma socialCost_continuous {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) :
    Continuous (fun f : Fin d → ℝ => socialCost q P f) := by
  unfold socialCost
  apply continuous_finset_sum
  intro i _
  -- f ↦ lqNorm q (fun j => P i j - f j) = lqNorm q ∘ (P i - f)
  have h_arg : Continuous (fun f : Fin d → ℝ => fun j => P i j - f j) := by
    apply continuous_pi
    intro j
    exact continuous_const.sub (continuous_apply j)
  exact (lqNorm_continuous hq).comp h_arg

end SocialCostMinExistsProof

open SocialCostMinExistsProof

theorem SocialCostMinExists
    (q : ℝ) (hq : 1 ≤ q) {n d : ℕ} (hd : 1 ≤ d) (P : Fin n → Fin d → ℝ) :
    ∃ f : Fin d → ℝ, socialCost q P f = optSocialCost q P := by
  classical
  -- Case n = 0: socialCost is identically 0
  by_cases hn : n = 0
  · subst hn
    refine ⟨fun _ => 0, ?_⟩
    have h0 : socialCost q P (fun _ => 0) = 0 := socialCost_empty_agents q d P _
    rw [h0]
    -- optSocialCost = ⨅ f, socialCost q P f = ⨅ f, 0 = 0
    unfold optSocialCost
    have hconst : ∀ f : Fin d → ℝ, socialCost q P f = 0 :=
      fun f => socialCost_empty_agents q d P f
    simp only [hconst]
    exact (ciInf_const (α := ℝ)).symm
  -- Case n ≥ 1
  · have hn_pos : 0 < n := Nat.pos_of_ne_zero hn
    -- Use that socialCost is continuous and coercive: bounded sublevel set.
    have hcont : Continuous (fun f : Fin d → ℝ => socialCost q P f) :=
      socialCost_continuous hq P
    -- Pick base point f₀ = 0
    set K : ℝ := socialCost q P (fun _ => 0) with hK_def
    -- We show {f | socialCost q P f ≤ K} is bounded.
    -- For any f in this set: lqNorm q (P 0 - f) ≤ K (since other terms ≥ 0),
    -- and |f j - P 0 j| ≤ lqNorm q (P 0 - f), so |f j| ≤ K + |P 0 j|.
    have hbdd : Bornology.IsBounded {f : Fin d → ℝ | socialCost q P f ≤ K} := by
      -- Define R := K + max j |P 0 j|. Use pi_norm_le_iff_of_nonneg.
      -- Use Metric.isBounded_iff_subset_closedBall to wrap up.
      -- Define a uniform bound
      have hPmax : ∀ f : Fin d → ℝ, socialCost q P f ≤ K →
          ∀ j : Fin d, |f j| ≤ K + |P ⟨0, hn_pos⟩ j| := by
        intro f hfK j
        -- socialCost q P f ≥ lqNorm q (fun k => P 0 k - f k)
        have h_term_nn : ∀ i, 0 ≤ lqNorm q (fun k => P i k - f k) := fun i =>
          lqNorm_nonneg hq _
        have h_le : lqNorm q (fun k => P ⟨0, hn_pos⟩ k - f k) ≤ socialCost q P f := by
          unfold socialCost
          exact Finset.single_le_sum (f := fun i => lqNorm q (fun k => P i k - f k))
            (s := Finset.univ) (a := ⟨0, hn_pos⟩)
            (fun i _ => h_term_nn i) (Finset.mem_univ _)
        have h1 : lqNorm q (fun k => P ⟨0, hn_pos⟩ k - f k) ≤ K := le_trans h_le hfK
        -- |P 0 j - f j| ≤ lqNorm q (fun k => P 0 k - f k)
        have h2 : |P ⟨0, hn_pos⟩ j - f j| ≤ lqNorm q (fun k => P ⟨0, hn_pos⟩ k - f k) := by
          have := _scme_lqNorm_ge_abs_coord hq (fun k => P ⟨0, hn_pos⟩ k - f k) j
          simpa using this
        have h3 : |P ⟨0, hn_pos⟩ j - f j| ≤ K := le_trans h2 h1
        -- |f j| ≤ |P 0 j - f j| + |P 0 j|, by reverse triangle inequality
        have h4 : |f j| ≤ |P ⟨0, hn_pos⟩ j - f j| + |P ⟨0, hn_pos⟩ j| := by
          have key : |f j - P ⟨0, hn_pos⟩ j| ≤
              |P ⟨0, hn_pos⟩ j - f j| := by
            rw [abs_sub_comm]
          have triangle : |f j| ≤ |f j - P ⟨0, hn_pos⟩ j| + |P ⟨0, hn_pos⟩ j| := by
            have := abs_sub_abs_le_abs_sub (f j) (P ⟨0, hn_pos⟩ j)
            -- |f j| - |P 0 j| ≤ |f j - P 0 j|, so |f j| ≤ |f j - P 0 j| + |P 0 j|
            linarith [abs_nonneg (P ⟨0, hn_pos⟩ j)]
          linarith
        linarith
      -- Now show boundedness using closedBall
      rw [Metric.isBounded_iff_subset_closedBall (0 : Fin d → ℝ)]
      -- Choose R = K + ∑ j, |P 0 j| (a single uniform bound for all coordinates)
      -- Actually, use R = K + max_j |P 0 j|. But sup of finite set is a Real.
      -- For simplicity, use M := ∑ j, |P 0 j|.
      set M : ℝ := ∑ j, |P ⟨0, hn_pos⟩ j| with hM_def
      refine ⟨K + M, ?_⟩
      intro f hf
      simp only [Set.mem_setOf_eq] at hf
      rw [Metric.mem_closedBall, dist_zero_right]
      -- ‖f‖ ≤ K + M; use pi_norm_le_iff_of_nonneg
      have hKnn : 0 ≤ K := socialCost_nonneg hq P _
      have hMnn : 0 ≤ M := Finset.sum_nonneg (fun j _ => abs_nonneg _)
      rw [pi_norm_le_iff_of_nonneg (by linarith : (0 : ℝ) ≤ K + M)]
      intro j
      have hj := hPmax f hf j
      -- |f j| ≤ K + |P 0 j| ≤ K + M
      have hPj : |P ⟨0, hn_pos⟩ j| ≤ M := by
        exact Finset.single_le_sum (f := fun k => |P ⟨0, hn_pos⟩ k|)
          (s := Finset.univ) (a := j)
          (fun k _ => abs_nonneg _) (Finset.mem_univ _)
      simp only [Real.norm_eq_abs]
      linarith
    -- Apply Continuous.exists_forall_le_of_isBounded
    obtain ⟨f₀, hf₀⟩ := hcont.exists_forall_le_of_isBounded (fun _ => 0) hbdd
    refine ⟨f₀, ?_⟩
    -- Show socialCost q P f₀ = optSocialCost q P
    unfold optSocialCost
    apply le_antisymm
    · -- socialCost q P f₀ ≤ ⨅ f, socialCost q P f
      apply le_ciInf
      intro f
      exact hf₀ f
    · -- ⨅ f, socialCost q P f ≤ socialCost q P f₀
      exact ciInf_le (socialCost_bddBelow hq P) f₀

open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost
open Workspace.ProofLemmas.UBDef

theorem MainTheoremTrivialCases
    (q : ℝ) (hq : 1 ≤ q) {n d : ℕ} (hd : 1 ≤ d)
    (P : Fin n → Fin d → ℝ) (m : Fin d → ℝ)
    (hm : IsCoordinateMedian m P)
    (htrivial : n = 0 ∨ optSocialCost q P = 0) :
    socialCost q P m ≤ UB q * optSocialCost q P := by
  -- Split on n = 0 vs n ≥ 1
  by_cases hn : n = 0
  · -- Case n = 0: socialCost = 0 for all f, optSocialCost = 0
    subst hn
    have hsc : socialCost q P m = 0 := socialCost_empty_agents q d P m
    have hopt : optSocialCost q P = 0 := by
      unfold optSocialCost
      have hconst : ∀ f : Fin d → ℝ, socialCost q P f = 0 :=
        fun f => socialCost_empty_agents q d P f
      simp only [hconst]
      exact ciInf_const
    rw [hsc, hopt, mul_zero]
  · -- Case n ≥ 1: by hypothesis, optSocialCost q P = 0
    have hopt : optSocialCost q P = 0 := by
      rcases htrivial with hn0 | hopt0
      · exact absurd hn0 hn
      · exact hopt0
    have hn_pos : 0 < n := Nat.pos_of_ne_zero hn
    have hn_ge_one : 1 ≤ n := hn_pos
    -- Get a minimizer f*
    obtain ⟨fstar, hfstar⟩ := SocialCostMinExists q hq hd P
    have hsc_fstar : socialCost q P fstar = 0 := by
      rw [hfstar, hopt]
    -- Each summand is 0
    have hterm_zero : ∀ i : Fin n, lqNorm q (fun j => P i j - fstar j) = 0 := by
      have hsum : ∑ i, lqNorm q (fun j => P i j - fstar j) = 0 := by
        unfold socialCost at hsc_fstar
        exact hsc_fstar
      have hnn : ∀ i ∈ Finset.univ, 0 ≤ lqNorm q (fun j => P i j - fstar j) :=
        fun i _ => lqNorm_nonneg hq _
      intro i
      have := (Finset.sum_eq_zero_iff_of_nonneg hnn).mp hsum i (Finset.mem_univ i)
      exact this
    -- So P i j = fstar j for all i, j
    have hP_eq : ∀ i : Fin n, (fun j => P i j) = fstar := by
      intro i
      have hzero : (fun j => P i j - fstar j) = 0 := by
        exact (LqNormZeroIffEqZero q hq hd _).mp (hterm_zero i)
      funext j
      have : P i j - fstar j = 0 := by
        have := congr_fun hzero j
        simpa using this
      linarith
    -- Hence P is the constant placement = fstar
    have hP_const : P = (fun (_ : Fin n) (j : Fin d) => fstar j) := by
      funext i j
      have := hP_eq i
      exact congr_fun this j
    -- m = fstar by MedianOfConstant
    have hm_eq : m = fstar := by
      have hm' : IsCoordinateMedian m (fun (_ : Fin n) (j : Fin d) => fstar j) := by
        rw [← hP_const]; exact hm
      exact MedianOfConstant hn_ge_one fstar m hm'
    -- Conclude socialCost q P m = 0
    have hsc_m : socialCost q P m = 0 := by
      rw [hm_eq]; exact hsc_fstar
    rw [hsc_m, hopt, mul_zero]

open Workspace.Types.SocialCost
open Workspace.Types.LqNorm

theorem SocialCostTranslationInvariance (q : ℝ) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) (t f : Fin d → ℝ) :
    socialCost q (fun (i : Fin n) (j : Fin d) => P i j - t j) (fun j => f j - t j)
      = socialCost q P f := by
  unfold socialCost
  refine Finset.sum_congr rfl (fun i _ => ?_)
  congr 1
  funext j
  ring

open Workspace.Types.SocialCost

theorem OptSocialCostTranslationInvariance
    (q : ℝ) {n d : ℕ} (P : Fin n → Fin d → ℝ) (t : Fin d → ℝ) :
    optSocialCost q (fun (i : Fin n) (j : Fin d) => P i j - t j) =
      optSocialCost q P := by
  unfold optSocialCost
  -- Apply the bijection f ↦ f - t on the domain.
  -- Function.Surjective.iInf_congr gives ⨅ x, F x = ⨅ y, G y when
  -- there's a surjection h with G (h x) = F x.
  -- We want ⨅ f, socialCost q P f = ⨅ f, socialCost q (P-t) f.
  symm
  refine Function.Surjective.iInf_congr (fun (f : Fin d → ℝ) => fun j => f j - t j) ?_ ?_
  · -- Surjective
    intro g
    refine ⟨fun j => g j + t j, ?_⟩
    funext j
    ring
  · -- pointwise equality
    intro f
    exact SocialCostTranslationInvariance q P t f

open Workspace.Types.CoordinateMedian

theorem MedianTranslationInvariance {n d : ℕ} (P : Fin n → Fin d → ℝ) (m t : Fin d → ℝ) :
    IsCoordinateMedian m P ↔
    IsCoordinateMedian (fun j => m j - t j) (fun (i : Fin n) (j : Fin d) => P i j - t j) := by
  unfold IsCoordinateMedian
  refine forall_congr' (fun j => ?_)
  have hlt_set : (Finset.univ.filter (fun i : Fin n => P i j < m j)) =
      (Finset.univ.filter (fun i : Fin n => P i j - t j < m j - t j)) := by
    apply Finset.filter_congr
    intros i _
    exact (sub_lt_sub_iff_right (t j)).symm
  have hgt_set : (Finset.univ.filter (fun i : Fin n => P i j > m j)) =
      (Finset.univ.filter (fun i : Fin n => P i j - t j > m j - t j)) := by
    apply Finset.filter_congr
    intros i _
    exact (sub_lt_sub_iff_right (t j)).symm
  rw [hlt_set, hgt_set]

open Workspace.Types.CoordinateMedian

theorem MedianCoordinateReflection {n d : ℕ} (P : Fin n → Fin d → ℝ)
    (eps : Fin d → ℝ) (heps : ∀ j, eps j = 1 ∨ eps j = -1)
    (h : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ)) P) :
    IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
      (fun (i : Fin n) (j : Fin d) => eps j * P i j) := by
  intro j
  rcases heps j with h1 | h1
  · -- eps j = 1: predicate is unchanged.
    have heq : ∀ i, eps j * P i j = P i j := fun i => by rw [h1]; ring
    have h_lt : (Finset.univ.filter (fun i : Fin n => eps j * P i j < 0)) =
                (Finset.univ.filter (fun i : Fin n => P i j < 0)) := by
      ext i
      simp [heq i]
    have h_gt : (Finset.univ.filter (fun i : Fin n => eps j * P i j > 0)) =
                (Finset.univ.filter (fun i : Fin n => P i j > 0)) := by
      ext i
      simp [heq i]
    rw [h_lt, h_gt]
    exact h j
  · -- eps j = -1: filters swap.
    have heq : ∀ i, eps j * P i j = -(P i j) := fun i => by rw [h1]; ring
    have h_lt : (Finset.univ.filter (fun i : Fin n => eps j * P i j < 0)) =
                (Finset.univ.filter (fun i : Fin n => P i j > 0)) := by
      ext i
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, heq i]
      constructor <;> intro hh <;> linarith
    have h_gt : (Finset.univ.filter (fun i : Fin n => eps j * P i j > 0)) =
                (Finset.univ.filter (fun i : Fin n => P i j < 0)) := by
      ext i
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, heq i]
      constructor <;> intro hh <;> linarith
    obtain ⟨hlt, hgt⟩ := h j
    rw [h_lt, h_gt]
    exact ⟨hgt, hlt⟩

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost
open Workspace.ProofLemmas.UBDef

namespace TranslationScaleNormalizeProof3

/-- Reflecting a vector by signs preserves its lqNorm. -/
private lemma lqNorm_coord_reflection {q : ℝ} {d : ℕ}
    (eps : Fin d → ℝ) (heps : ∀ j, eps j = 1 ∨ eps j = -1) (x : Fin d → ℝ) :
    lqNorm q (fun j => eps j * x j) = lqNorm q x := by
  unfold lqNorm
  congr 1
  refine Finset.sum_congr rfl (fun j _ => ?_)
  show |eps j * x j| ^ q = |x j| ^ q
  rw [abs_mul]
  rcases heps j with h1 | h1
  · rw [h1]; simp
  · rw [h1]; simp

/-- Sign-flip on coordinates preserves SC. -/
private lemma socialCost_coord_reflection (q : ℝ) {n d : ℕ}
    (eps : Fin d → ℝ) (heps : ∀ j, eps j = 1 ∨ eps j = -1)
    (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) :
    socialCost q (fun (i : Fin n) (j : Fin d) => eps j * P i j)
      (fun j => eps j * f j) = socialCost q P f := by
  unfold socialCost
  refine Finset.sum_congr rfl (fun i _ => ?_)
  have heq : (fun j => eps j * P i j - eps j * f j)
              = (fun j => eps j * (P i j - f j)) := by
    funext j; ring
  rw [heq]
  exact lqNorm_coord_reflection eps heps _

/-- Scaling: socialCost q (αP) (αf) = α · socialCost q P f for α ≥ 0. -/
private lemma socialCost_scale {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (α : ℝ) (hα : 0 ≤ α) (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) :
    socialCost q (fun i j => α * P i j) (fun j => α * f j)
      = α * socialCost q P f := by
  unfold socialCost
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  have heq : (fun j => α * P i j - α * f j) = (fun j => α * (P i j - f j)) := by
    funext j; ring
  rw [heq, lqNorm_smul hq α, abs_of_nonneg hα]

/-- Median predicate is invariant under positive scaling. -/
private lemma median_scale {n d : ℕ} (P : Fin n → Fin d → ℝ) (m : Fin d → ℝ)
    (α : ℝ) (hα : 0 < α) :
    IsCoordinateMedian m P ↔
    IsCoordinateMedian (fun j => α * m j) (fun (i : Fin n) (j : Fin d) => α * P i j) := by
  unfold IsCoordinateMedian
  refine forall_congr' (fun j => ?_)
  have hlt : (Finset.univ.filter (fun i : Fin n => P i j < m j)) =
      (Finset.univ.filter (fun i : Fin n => α * P i j < α * m j)) := by
    apply Finset.filter_congr; intros i _
    constructor
    · intro h; exact mul_lt_mul_of_pos_left h hα
    · intro h; exact lt_of_mul_lt_mul_left h hα.le
  have hgt : (Finset.univ.filter (fun i : Fin n => P i j > m j)) =
      (Finset.univ.filter (fun i : Fin n => α * P i j > α * m j)) := by
    apply Finset.filter_congr; intros i _
    constructor
    · intro h; exact mul_lt_mul_of_pos_left h hα
    · intro h; exact lt_of_mul_lt_mul_left h hα.le
  rw [hlt, hgt]

end TranslationScaleNormalizeProof3

open TranslationScaleNormalizeProof3

theorem TranslationScaleNormalize
    (h_norm : ∀ q : ℝ, 1 < q → ∀ {n d : ℕ}, 0 < n → Even n → 1 ≤ d →
      ∀ (P_norm : Fin n → Fin d → ℝ),
      IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ)) P_norm →
      ∀ (f : Fin d → ℝ), (∀ j, 0 ≤ f j) → lqNorm q f = 1 →
      socialCost q P_norm (fun (_ : Fin d) => (0 : ℝ)) ≤ UB q * socialCost q P_norm f) :
    ∀ q : ℝ, 1 < q → ∀ {n d : ℕ}, 0 < n → Even n → 1 ≤ d →
      ∀ (P : Fin n → Fin d → ℝ),
      ∀ (m : Fin d → ℝ), IsCoordinateMedian m P →
      0 < optSocialCost q P →
      socialCost q P m ≤ UB q * optSocialCost q P := by
  intro q hq n d hn hn_even hd P m hm hopt
  have hq_le : 1 ≤ q := le_of_lt hq
  -- Get the optimal facility f*
  obtain ⟨fstar, hfstar⟩ := SocialCostMinExists q hq_le hd P
  have hsc_fstar : socialCost q P fstar = optSocialCost q P := hfstar
  set OPT : ℝ := optSocialCost q P with hOPT_def
  have hOPT_pos : 0 < OPT := hopt
  have hOPT_nn : 0 ≤ OPT := le_of_lt hOPT_pos
  -- v = fstar - m: optimum after translating m to 0.
  set v : Fin d → ℝ := fun j => fstar j - m j with hv_def
  -- ε_j = 1 if v_j ≥ 0, else -1.
  classical
  set eps : Fin d → ℝ := fun j => if 0 ≤ v j then 1 else -1 with heps_def
  have heps_pm : ∀ j, eps j = 1 ∨ eps j = -1 := by
    intro j
    rw [heps_def]
    by_cases h : 0 ≤ v j
    · simp [h]
    · simp [h]
  have heps_v_nonneg : ∀ j, 0 ≤ eps j * v j := by
    intro j
    rw [heps_def]
    by_cases h : 0 ≤ v j
    · simp [h]
    · simp [h]
      have : v j < 0 := lt_of_not_ge h
      linarith
  -- P_tr_refl i j = eps j * (P i j - m j); v_refl j = eps j * v j ≥ 0.
  set P_tr_refl : Fin n → Fin d → ℝ := fun i j => eps j * (P i j - m j) with hP_tr_def
  set v_refl : Fin d → ℝ := fun j => eps j * v j with hv_refl_def
  have hv_refl_nn : ∀ j, 0 ≤ v_refl j := heps_v_nonneg
  -- Median 0 of (P i j - m j).
  have hmed_tr : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
      (fun (i : Fin n) (j : Fin d) => P i j - m j) := by
    have h1 := (MedianTranslationInvariance P m m).mp hm
    have heq : (fun j => m j - m j) = (fun (_ : Fin d) => (0 : ℝ)) := by
      funext j; ring
    rw [heq] at h1
    exact h1
  -- Median 0 of P_tr_refl.
  have hmed_tr_refl : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ)) P_tr_refl := by
    have := MedianCoordinateReflection (fun i j => P i j - m j) eps heps_pm hmed_tr
    exact this
  -- SC(P_tr_refl, v_refl) = OPT.
  have hsc_tr_refl : socialCost q P_tr_refl v_refl = OPT := by
    have h1 : socialCost q (fun (i : Fin n) (j : Fin d) => P i j - m j) v
              = socialCost q P fstar := by
      have := SocialCostTranslationInvariance q P m fstar
      convert this using 2
    have h2 : socialCost q P_tr_refl v_refl =
              socialCost q (fun i j => P i j - m j) v := by
      rw [hP_tr_def, hv_refl_def]
      exact socialCost_coord_reflection q eps heps_pm _ _
    rw [h2, h1, hsc_fstar]
  -- SC(P_tr_refl, 0) = SC(P, m).
  have hsc_tr_refl_0 : socialCost q P_tr_refl (fun (_ : Fin d) => (0 : ℝ))
      = socialCost q P m := by
    have h1 : socialCost q P_tr_refl (fun (_ : Fin d) => (0 : ℝ))
              = socialCost q (fun (i : Fin n) (j : Fin d) => P i j - m j)
                  (fun (_ : Fin d) => (0 : ℝ)) := by
      rw [hP_tr_def]
      have heq : (fun (_ : Fin d) => (0 : ℝ)) = (fun (j : Fin d) => eps j * 0) := by
        funext j; ring
      conv_lhs => rw [heq]
      exact socialCost_coord_reflection q eps heps_pm _ _
    have h2 : socialCost q (fun (i : Fin n) (j : Fin d) => P i j - m j)
                (fun (_ : Fin d) => (0 : ℝ)) = socialCost q P m := by
      have := SocialCostTranslationInvariance q P m m
      have heq : (fun j => m j - m j) = (fun (_ : Fin d) => (0 : ℝ)) := by
        funext j; ring
      rw [heq] at this
      exact this
    rw [h1, h2]
  -- Now we case-split on whether v_refl is the zero vector
  -- (equivalently, whether lqNorm q v_refl = 0).
  set u : ℝ := lqNorm q v_refl with hu_def
  have hu_nn : 0 ≤ u := lqNorm_nonneg hq_le _
  by_cases hu_zero : u = 0
  · -- Degenerate: v_refl = 0, so fstar = m, so OPT = SC(P, m).
    have hv_refl_eq_zero : v_refl = (fun _ => 0) := by
      have := (LqNormZeroIffEqZero q hq_le hd v_refl).mp hu_zero
      ext j
      have := congr_fun this j
      simpa using this
    -- v_refl j = eps j * v j = 0 and eps j ≠ 0, so v j = 0.
    have hv_zero : ∀ j, v j = 0 := by
      intro j
      have hvr : eps j * v j = 0 := by
        have := congr_fun hv_refl_eq_zero j
        simpa [hv_refl_def] using this
      rcases heps_pm j with h1 | h1
      · rw [h1] at hvr; linarith
      · rw [h1] at hvr; linarith
    -- So fstar = m
    have hfstar_eq_m : fstar = m := by
      funext j
      have := hv_zero j
      simp [hv_def] at this
      linarith
    -- SC(P, m) = OPT
    have hSC_eq_OPT : socialCost q P m = OPT := by
      rw [← hfstar_eq_m]
      exact hsc_fstar
    rw [hSC_eq_OPT]
    -- Goal: OPT ≤ UB q * OPT
    have hUB_ge_one : 1 ≤ UB q := UBDef.1 q hq_le
    nlinarith [hOPT_pos]
  · -- Generic: u > 0. Scale by σ = 1/u.
    have hu_pos : 0 < u := lt_of_le_of_ne hu_nn (Ne.symm hu_zero)
    set σ : ℝ := 1 / u with hσ_def
    have hσ_pos : 0 < σ := by rw [hσ_def]; positivity
    have hσ_nn : 0 ≤ σ := le_of_lt hσ_pos
    set P_norm : Fin n → Fin d → ℝ := fun i j => σ * P_tr_refl i j with hP_norm_def
    set f_norm : Fin d → ℝ := fun j => σ * v_refl j with hf_norm_def
    -- Median 0 of P_norm.
    have hmed_norm : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ)) P_norm := by
      have h := (median_scale P_tr_refl (fun (_ : Fin d) => (0 : ℝ)) σ hσ_pos).mp hmed_tr_refl
      have heq : (fun j => σ * (0 : ℝ)) = (fun (_ : Fin d) => (0 : ℝ)) := by
        funext j; ring
      rw [heq] at h
      exact h
    -- f_norm ≥ 0.
    have hf_norm_nn : ∀ j, 0 ≤ f_norm j := by
      intro j
      rw [hf_norm_def]
      exact mul_nonneg hσ_nn (hv_refl_nn j)
    -- lqNorm q f_norm = 1.
    have hf_norm_unit : lqNorm q f_norm = 1 := by
      rw [hf_norm_def]
      rw [lqNorm_smul hq_le σ v_refl]
      rw [abs_of_nonneg hσ_nn]
      rw [hσ_def, ← hu_def]
      field_simp
    -- SC(P_norm, f_norm) = σ * OPT.
    have hsc_norm : socialCost q P_norm f_norm = σ * OPT := by
      rw [hP_norm_def, hf_norm_def]
      rw [socialCost_scale hq_le σ hσ_nn P_tr_refl v_refl]
      rw [hsc_tr_refl]
    -- SC(P_norm, 0) = σ * SC(P, m).
    have hsc_norm_0 : socialCost q P_norm (fun (_ : Fin d) => (0 : ℝ))
        = σ * socialCost q P m := by
      rw [hP_norm_def]
      have heq : (fun (_ : Fin d) => (0 : ℝ)) = (fun j => σ * 0) := by
        funext j; ring
      conv_lhs => rw [heq]
      rw [socialCost_scale hq_le σ hσ_nn P_tr_refl _]
      rw [hsc_tr_refl_0]
    -- Apply h_norm.
    have happ : socialCost q P_norm (fun (_ : Fin d) => (0 : ℝ))
                ≤ UB q * socialCost q P_norm f_norm :=
      h_norm q hq hn hn_even hd P_norm hmed_norm f_norm hf_norm_nn hf_norm_unit
    -- Substitute and clear σ.
    rw [hsc_norm_0, hsc_norm] at happ
    -- happ: σ * SC(P, m) ≤ UB q * (σ * OPT)
    -- Multiply by 1/σ = u (since σ > 0).
    have happ' : σ * socialCost q P m ≤ σ * (UB q * OPT) := by linarith
    exact le_of_mul_le_mul_left happ' hσ_pos

open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost
open Workspace.ProofLemmas.UBDef

open scoped BigOperators

/-- Auxiliary: when `n = 0`, the social cost is `0` for every `f`. -/
private lemma socialCost_zero_agents {q : ℝ} (d : ℕ)
    (P : Fin 0 → Fin d → ℝ) (f : Fin d → ℝ) :
    socialCost q P f = 0 := by
  unfold socialCost
  exact Fin.sum_univ_zero _

private lemma optSocialCost_zero_agents {q : ℝ} (hq : 1 ≤ q) (d : ℕ)
    (P : Fin 0 → Fin d → ℝ) :
    optSocialCost q P = 0 := by
  apply le_antisymm
  · have := optSocialCost_le_socialCost hq P (fun _ => 0)
    rw [socialCost_zero_agents] at this
    exact this
  · exact optSocialCost_nonneg hq P

theorem ReductionToEvenN
    (h_even : ∀ q : ℝ, 1 ≤ q → ∀ {n d : ℕ}, 0 < n → Even n → 1 ≤ d →
      ∀ (P : Fin n → Fin d → ℝ),
      ∀ (m : Fin d → ℝ), IsCoordinateMedian m P →
        socialCost q P m ≤ UB q * optSocialCost q P) :
    ∀ q : ℝ, 1 ≤ q → ∀ {n d : ℕ}, 1 ≤ d →
      ∀ (P : Fin n → Fin d → ℝ),
      ∀ (m : Fin d → ℝ), IsCoordinateMedian m P →
        socialCost q P m ≤ UB q * optSocialCost q P := by
  intro q hq n d hd P m hm
  -- Case n = 0: both sides are 0
  by_cases hn0 : n = 0
  · subst hn0
    have h1 : socialCost q P m = 0 := socialCost_zero_agents d P m
    have h2 : optSocialCost q P = 0 := optSocialCost_zero_agents hq d P
    rw [h1, h2, mul_zero]
  -- n ≥ 1: reduce to case 2*n via duplication
  have hn_pos : 0 < n := Nat.pos_of_ne_zero hn0
  -- Build P' : Fin (n + n) → Fin d → ℝ via duplication using Sum equiv
  let e : Fin n ⊕ Fin n ≃ Fin (n + n) := finSumFinEquiv
  let P' : Fin (n + n) → Fin d → ℝ := fun i => Sum.elim P P (e.symm i)
  -- Show 2n is even and positive
  have hn2_pos : 0 < n + n := by omega
  have hn2_even : Even (n + n) := ⟨n, rfl⟩
  -- Key fact: socialCost q P' f = 2 * socialCost q P f for any f
  have h_sc : ∀ f : Fin d → ℝ, socialCost q P' f = 2 * socialCost q P f := by
    intro f
    unfold socialCost
    -- Define F : Fin n → ℝ as the per-agent norm, so the sum-type sum is Sum.elim F F.
    set F : Fin n → ℝ := fun i => lqNorm q (fun j => P i j - f j) with hF
    -- Use the equiv to rewrite the sum over Fin (n+n) as a sum over Fin n ⊕ Fin n.
    have h1 : (∑ i : Fin (n + n), lqNorm q (fun j => P' i j - f j))
        = ∑ i : Fin n ⊕ Fin n, lqNorm q (fun j => Sum.elim P P i j - f j) := by
      rw [← Equiv.sum_comp e (fun i : Fin (n + n) =>
            lqNorm q (fun j => P' i j - f j))]
      apply Finset.sum_congr rfl
      intro i _
      simp [P', Equiv.symm_apply_apply]
    rw [h1]
    -- Now the summand equals Sum.elim F F i for i : Fin n ⊕ Fin n.
    have h2 : ∀ i : Fin n ⊕ Fin n,
        lqNorm q (fun j => Sum.elim P P i j - f j) = Sum.elim F F i := by
      intro i
      cases i with
      | inl a => simp [F, Sum.elim_inl]
      | inr a => simp [F, Sum.elim_inr]
    rw [Finset.sum_congr rfl (fun i _ => h2 i)]
    rw [Fintype.sum_sumElim]
    ring
  -- Show m is a coordinate-wise median of P'
  have hm' : IsCoordinateMedian m P' := by
    intro j
    obtain ⟨hlt, hgt⟩ := hm j
    -- Cardinality lemma: filter on P' equals 2 * filter on P (for any predicate via P).
    -- Use the bijection e.symm to translate to a filter over Fin n ⊕ Fin n.
    have card_eq : ∀ (R : ℝ → ℝ → Prop) [DecidablePred (fun i : Fin (n + n) => R (P' i j) (m j))]
        [DecidablePred (fun i : Fin n => R (P i j) (m j))],
        (Finset.univ.filter (fun i : Fin (n + n) => R (P' i j) (m j))).card =
        2 * (Finset.univ.filter (fun i : Fin n => R (P i j) (m j))).card := by
      intro R _ _
      classical
      -- Express cardinalities as sums of 0/1 indicators, then use Fintype.sum_sumElim.
      have h1 : (Finset.univ.filter (fun i : Fin (n + n) => R (P' i j) (m j))).card =
          ∑ i : Fin (n + n), (if R (P' i j) (m j) then (1 : ℕ) else 0) := by
        rw [Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const, smul_eq_mul,
            mul_one]
      have h2 : (Finset.univ.filter (fun i : Fin n => R (P i j) (m j))).card =
          ∑ i : Fin n, (if R (P i j) (m j) then (1 : ℕ) else 0) := by
        rw [Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const, smul_eq_mul,
            mul_one]
      rw [h1, h2]
      -- Use Equiv.sum_comp e to push through the sum-type equiv.
      rw [← Equiv.sum_comp e (fun i : Fin (n + n) =>
            (if R (P' i j) (m j) then (1 : ℕ) else 0))]
      -- Now the summand is `if R (P' (e i) j) (m j) then 1 else 0`. Convert via Sum.elim P P i.
      have hF : ∀ i : Fin n ⊕ Fin n,
          (if R (P' (e i) j) (m j) then (1 : ℕ) else 0) =
          Sum.elim
            (fun a : Fin n => if R (P a j) (m j) then (1 : ℕ) else 0)
            (fun a : Fin n => if R (P a j) (m j) then (1 : ℕ) else 0) i := by
        intro i
        cases i with
        | inl a =>
          show (if R (P' (e (Sum.inl a)) j) (m j) then (1 : ℕ) else 0) = _
          have hrw : P' (e (Sum.inl a)) = P a := by
            show Sum.elim P P (e.symm (e (Sum.inl a))) = P a
            rw [e.symm_apply_apply]
            rfl
          simp [hrw]
        | inr a =>
          show (if R (P' (e (Sum.inr a)) j) (m j) then (1 : ℕ) else 0) = _
          have hrw : P' (e (Sum.inr a)) = P a := by
            show Sum.elim P P (e.symm (e (Sum.inr a))) = P a
            rw [e.symm_apply_apply]
            rfl
          simp [hrw]
      rw [Finset.sum_congr rfl (fun i _ => hF i)]
      rw [Fintype.sum_sumElim]
      ring
    classical
    have hlt_card := card_eq (· < ·)
    have hgt_card := card_eq (· > ·)
    have hn2_div : (n + n) / 2 = n := by omega
    refine ⟨?_, ?_⟩
    · rw [hlt_card, hn2_div]
      have hn2 : n / 2 + n / 2 ≤ n := by omega
      omega
    · rw [hgt_card, hn2_div]
      have hn2 : n / 2 + n / 2 ≤ n := by omega
      omega
  -- Apply h_even
  have h_main := h_even q hq hn2_pos hn2_even hd P' m hm'
  -- Now use h_sc to convert
  have h_lhs : socialCost q P' m = 2 * socialCost q P m := h_sc m
  -- Need: optSocialCost q P' ≤ 2 * optSocialCost q P
  have h_opt : optSocialCost q P' ≤ 2 * optSocialCost q P := by
    -- For all f: optSocialCost q P' ≤ socialCost q P' f = 2 * socialCost q P f
    -- So optSocialCost q P' / 2 ≤ socialCost q P f for all f
    -- Hence optSocialCost q P' / 2 ≤ ⨅ f, socialCost q P f = optSocialCost q P
    have hhalf : optSocialCost q P' / 2 ≤ optSocialCost q P := by
      apply le_ciInf
      intro f
      have hle := optSocialCost_le_socialCost hq P' f
      rw [h_sc f] at hle
      linarith
    linarith
  -- UB q ≥ 1 ≥ 0
  have hUB_nn : 0 ≤ UB q := by
    have h1 := UBDef.1 q hq
    linarith
  -- Combine
  rw [h_lhs] at h_main
  have h_chain : 2 * socialCost q P m ≤ UB q * (2 * optSocialCost q P) := by
    calc 2 * socialCost q P m
        ≤ UB q * optSocialCost q P' := h_main
      _ ≤ UB q * (2 * optSocialCost q P) :=
          mul_le_mul_of_nonneg_left h_opt hUB_nn
  -- Cancel 2
  have h2pos : (0 : ℝ) < 2 := by norm_num
  have hresult : socialCost q P m ≤ UB q * optSocialCost q P := by
    have h2 : UB q * (2 * optSocialCost q P) = 2 * (UB q * optSocialCost q P) := by ring
    rw [h2] at h_chain
    linarith
  exact hresult

namespace Workspace.ProofLemmas.LambdaDeltaIdentity

open Real

noncomputable def delta_of_lambda (q lambda : ℝ) : ℝ :=
  (lambda ^ (-(q / (q - 1))) - 1) ^ ((q - 1) / q)

end Workspace.ProofLemmas.LambdaDeltaIdentity

open Workspace.ProofLemmas.LambdaDeltaIdentity

theorem LambdaDeltaIdentity
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam_pos : 0 < lambda) (hlam_le : lambda ≤ 1) :
    lambda * delta_of_lambda q lambda
      = (1 - lambda ^ (q / (q - 1))) ^ ((q - 1) / q) := by
  unfold delta_of_lambda
  -- Set up positivity facts
  set r : ℝ := q / (q - 1) with hr_def
  have hq_sub_pos : 0 < q - 1 := by linarith
  have hq_sub_ne : q - 1 ≠ 0 := ne_of_gt hq_sub_pos
  have hq_pos : 0 < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hr_pos : 0 < r := by
    simp [hr_def]; exact div_pos hq_pos hq_sub_pos
  have hr_ne : r ≠ 0 := ne_of_gt hr_pos
  have hlam_nn : (0 : ℝ) ≤ lambda := le_of_lt hlam_pos
  have hlam_ne : lambda ≠ 0 := ne_of_gt hlam_pos
  -- lambda^r > 0
  have hlam_r_pos : 0 < lambda ^ r := Real.rpow_pos_of_pos hlam_pos _
  have hlam_r_nn : 0 ≤ lambda ^ r := le_of_lt hlam_r_pos
  have hlam_r_ne : lambda ^ r ≠ 0 := ne_of_gt hlam_r_pos
  -- Rewrite lambda^(-r) - 1 = (1 - lambda^r) / lambda^r
  have h_neg : lambda ^ (-r) = (lambda ^ r)⁻¹ := Real.rpow_neg hlam_nn r
  -- Compute 1 - lambda^r ≥ 0 since lambda ≤ 1 and r > 0
  have h_lam_r_le_one : lambda ^ r ≤ 1 := by
    have : lambda ^ r ≤ lambda ^ (0 : ℝ) := by
      apply Real.rpow_le_rpow_of_exponent_ge hlam_pos hlam_le
      linarith
    simpa using this
  have h_one_sub_nn : 0 ≤ 1 - lambda ^ r := by linarith
  -- Substitute lambda^(-r) = (lambda^r)⁻¹
  rw [h_neg]
  -- Now: lambda * ((lambda^r)⁻¹ - 1)^((q-1)/q) = (1 - lambda^r)^((q-1)/q)
  have h_step1 : (lambda ^ r)⁻¹ - 1 = (1 - lambda ^ r) / (lambda ^ r) := by
    field_simp
  rw [h_step1]
  -- Goal: lambda * ((1 - lambda^r) / lambda^r)^((q-1)/q) = (1 - lambda^r)^((q-1)/q)
  rw [Real.div_rpow h_one_sub_nn hlam_r_nn]
  -- Goal: lambda * ((1 - lambda^r)^((q-1)/q) / (lambda^r)^((q-1)/q)) = ...
  -- We want to show (lambda^r)^((q-1)/q) = lambda
  have h_inner : (lambda ^ r) ^ ((q - 1) / q) = lambda := by
    rw [← Real.rpow_mul hlam_nn]
    have h_prod : r * ((q - 1) / q) = 1 := by
      simp [hr_def]
      field_simp
    rw [h_prod, Real.rpow_one]
  rw [h_inner]
  -- Goal: lambda * ((1 - lambda^r)^((q-1)/q) / lambda) = (1 - lambda^r)^((q-1)/q)
  field_simp

open Workspace.Types.CoordinateMedian
open Finset

theorem MedianConstraintFromCWMedian
    {n d : ℕ} (hn_even : Even n) (P : Fin n → Fin d → ℝ)
    (hP : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ)) P) :
    ∃ sigma : Fin n → Fin d → ℝ,
      (∀ i j, sigma i j = 1 ∨ sigma i j = -1) ∧
      (∀ i j, P i j > 0 → sigma i j = 1) ∧
      (∀ i j, P i j < 0 → sigma i j = -1) ∧
      (∀ j, ∑ i, sigma i j = 0) := by
  classical
  -- Per-coordinate sets
  let posSet : Fin d → Finset (Fin n) :=
    fun j => Finset.univ.filter (fun i => P i j > 0)
  let negSet : Fin d → Finset (Fin n) :=
    fun j => Finset.univ.filter (fun i => P i j < 0)
  let zeroSet : Fin d → Finset (Fin n) :=
    fun j => Finset.univ.filter (fun i => P i j = 0)
  have hpos_mem : ∀ {i j}, i ∈ posSet j ↔ P i j > 0 := by
    intro i j
    simp [posSet]
  have hneg_mem : ∀ {i j}, i ∈ negSet j ↔ P i j < 0 := by
    intro i j
    simp [negSet]
  have hzero_mem : ∀ {i j}, i ∈ zeroSet j ↔ P i j = 0 := by
    intro i j
    simp [zeroSet]
  -- Cardinality bounds from hP
  have hpos_le : ∀ j, (posSet j).card ≤ n / 2 := fun j => (hP j).2
  have hneg_le : ∀ j, (negSet j).card ≤ n / 2 := fun j => (hP j).1
  -- Disjointness
  have hpos_neg_disj : ∀ j, Disjoint (posSet j) (negSet j) := by
    intro j; rw [Finset.disjoint_filter]
    intros i _ hpi hni; linarith
  have hpos_zero_disj : ∀ j, Disjoint (posSet j) (zeroSet j) := by
    intro j; rw [Finset.disjoint_filter]
    intros i _ hpi hzi; linarith
  have hneg_zero_disj : ∀ j, Disjoint (negSet j) (zeroSet j) := by
    intro j; rw [Finset.disjoint_filter]
    intros i _ hni hzi; linarith
  -- The three sets partition univ.
  have hunion : ∀ j,
      (posSet j) ∪ (negSet j) ∪ (zeroSet j) = (Finset.univ : Finset (Fin n)) := by
    intro j
    apply Finset.eq_univ_of_forall
    intro i
    rcases lt_trichotomy (P i j) 0 with h | h | h
    · -- i ∈ negSet j
      apply Finset.mem_union.mpr
      left
      apply Finset.mem_union.mpr
      right
      exact hneg_mem.mpr h
    · -- i ∈ zeroSet j
      apply Finset.mem_union.mpr
      right
      exact hzero_mem.mpr h
    · -- i ∈ posSet j
      apply Finset.mem_union.mpr
      left
      apply Finset.mem_union.mpr
      left
      exact hpos_mem.mpr h
  -- Cardinality sum: |posSet| + |negSet| + |zeroSet| = n
  have hcard_sum : ∀ j, (posSet j).card + (negSet j).card + (zeroSet j).card = n := by
    intro j
    have hd1 : Disjoint (posSet j ∪ negSet j) (zeroSet j) := by
      rw [Finset.disjoint_union_left]
      exact ⟨hpos_zero_disj j, hneg_zero_disj j⟩
    have h1 : ((posSet j ∪ negSet j) ∪ zeroSet j).card =
        (posSet j ∪ negSet j).card + (zeroSet j).card :=
      Finset.card_union_of_disjoint hd1
    have h2 : (posSet j ∪ negSet j).card = (posSet j).card + (negSet j).card :=
      Finset.card_union_of_disjoint (hpos_neg_disj j)
    have h3 : ((posSet j ∪ negSet j) ∪ zeroSet j).card = n := by
      rw [hunion j]; simp
    omega
  -- We need to choose a subset T j ⊆ zeroSet j with |T j| = n/2 - |posSet j|.
  have hu_le : ∀ j, n / 2 - (posSet j).card ≤ (zeroSet j).card := by
    intro j
    have hsum := hcard_sum j
    have hneg := hneg_le j
    omega
  have hexT : ∀ j, ∃ T : Finset (Fin n), T ⊆ zeroSet j ∧
      T.card = n / 2 - (posSet j).card := by
    intro j
    exact Finset.exists_subset_card_eq (hu_le j)
  let T : Fin d → Finset (Fin n) := fun j => (hexT j).choose
  have hT_sub : ∀ j, T j ⊆ zeroSet j := fun j => (hexT j).choose_spec.1
  have hT_card : ∀ j, (T j).card = n / 2 - (posSet j).card :=
    fun j => (hexT j).choose_spec.2
  -- Define the signature.
  refine ⟨fun i j => if P i j > 0 then (1 : ℝ)
                     else if P i j < 0 then (-1 : ℝ)
                     else if i ∈ T j then (1 : ℝ) else (-1 : ℝ), ?_, ?_, ?_, ?_⟩
  · -- sigma values are ±1
    intro i j
    by_cases h1 : P i j > 0
    · left; simp [h1]
    · by_cases h2 : P i j < 0
      · right; simp [h1, h2]
      · by_cases h3 : i ∈ T j
        · left; simp [h1, h2, h3]
        · right; simp [h1, h2, h3]
  · intro i j hij; simp [hij]
  · intro i j hij
    have h1 : ¬ P i j > 0 := by linarith
    simp [h1, hij]
  · -- Sum equals zero per coordinate
    intro j
    have hsigma_pos : ∀ i ∈ posSet j,
        (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1 else if i ∈ T j then 1 else -1) = 1 := by
      intros i hi
      have h := hpos_mem.mp hi
      simp [h]
    have hsigma_neg : ∀ i ∈ negSet j,
        (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1 else if i ∈ T j then 1 else -1) = -1 := by
      intros i hi
      have h := hneg_mem.mp hi
      have h1 : ¬ P i j > 0 := by linarith
      simp [h1, h]
    have hsigma_zero_in : ∀ i ∈ T j,
        (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1 else if i ∈ T j then 1 else -1) = 1 := by
      intros i hT
      have hi : i ∈ zeroSet j := hT_sub j hT
      have h := hzero_mem.mp hi
      have h1 : ¬ P i j > 0 := by linarith
      have h2 : ¬ P i j < 0 := by linarith
      simp [h1, h2, hT]
    have hsigma_zero_out : ∀ i ∈ zeroSet j \ T j,
        (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1 else if i ∈ T j then 1 else -1) = -1 := by
      intros i hi
      have hi1 : i ∈ zeroSet j := (Finset.mem_sdiff.mp hi).1
      have hi2 : i ∉ T j := (Finset.mem_sdiff.mp hi).2
      have h := hzero_mem.mp hi1
      have h1 : ¬ P i j > 0 := by linarith
      have h2 : ¬ P i j < 0 := by linarith
      simp [h1, h2, hi2]
    -- Express sum over univ as sum over the partition.
    have hpart : (Finset.univ : Finset (Fin n)) = (posSet j ∪ negSet j) ∪ zeroSet j :=
      (hunion j).symm
    have hd1 : Disjoint (posSet j ∪ negSet j) (zeroSet j) := by
      rw [Finset.disjoint_union_left]
      exact ⟨hpos_zero_disj j, hneg_zero_disj j⟩
    rw [hpart, Finset.sum_union hd1, Finset.sum_union (hpos_neg_disj j)]
    rw [Finset.sum_congr rfl hsigma_pos]
    rw [Finset.sum_congr rfl hsigma_neg]
    have hd2 : Disjoint (T j) (zeroSet j \ T j) := Finset.disjoint_sdiff
    have hzs_eq : zeroSet j = T j ∪ (zeroSet j \ T j) := by
      rw [Finset.union_sdiff_of_subset (hT_sub j)]
    rw [hzs_eq, Finset.sum_union hd2]
    rw [Finset.sum_congr rfl hsigma_zero_in]
    rw [Finset.sum_congr rfl hsigma_zero_out]
    rw [Finset.sum_const, Finset.sum_const, Finset.sum_const, Finset.sum_const]
    -- Goal: |posSet| • 1 + |negSet| • (-1) + (|T j| • 1 + |zeroSet \ T j| • (-1)) = 0
    simp only [smul_eq_mul, mul_one, mul_neg_one, nsmul_eq_mul]
    -- Now arithmetic identity in ℝ
    have hT_le_zs : (T j).card ≤ (zeroSet j).card := Finset.card_le_card (hT_sub j)
    have hsdiff_card : (zeroSet j \ T j).card = (zeroSet j).card - (T j).card :=
      Finset.card_sdiff_of_subset (hT_sub j)
    obtain ⟨k, hk⟩ := hn_even
    have hn2 : n / 2 = k := by omega
    have hcard_sum_j := hcard_sum j
    have hT_card_j := hT_card j
    have hpos_le_j := hpos_le j
    -- Cast everything carefully
    have hT_real : ((T j).card : ℝ) = ((n / 2 : ℕ) : ℝ) - ((posSet j).card : ℝ) := by
      rw [hT_card_j]
      push_cast [Nat.cast_sub hpos_le_j]
      ring
    have hzs_real : ((zeroSet j).card : ℝ) =
        (n : ℝ) - ((posSet j).card : ℝ) - ((negSet j).card : ℝ) := by
      have : ((posSet j).card : ℝ) + ((negSet j).card : ℝ) + ((zeroSet j).card : ℝ) = (n : ℝ) := by
        exact_mod_cast hcard_sum_j
      linarith
    have hsdiff_real : ((zeroSet j \ T j).card : ℝ) =
        ((zeroSet j).card : ℝ) - ((T j).card : ℝ) := by
      have h1 : ((zeroSet j \ T j).card : ℝ) = (((zeroSet j).card - (T j).card : ℕ) : ℝ) := by
        rw [hsdiff_card]
      rw [h1, Nat.cast_sub hT_le_zs]
    have h2n : (n : ℝ) = 2 * ((n / 2 : ℕ) : ℝ) := by
      have hh : (n : ℕ) = 2 * (n / 2) := by omega
      exact_mod_cast hh
    rw [hsdiff_real, hT_real, hzs_real]
    linarith

open scoped BigOperators
open Workspace.Types.LqNorm

namespace Workspace.ProofLemmas.ConstrainedMinExists

/-- The objective summand: `g_lambda q lambda f p = lqNorm q (p - f) - lambda * lqNorm q p`. -/
noncomputable def g_lambda (q : ℝ) (lambda : ℝ) {d : ℕ}
    (f : Fin d → ℝ) (p : Fin d → ℝ) : ℝ :=
  lqNorm q (fun j => p j - f j) - lambda * lqNorm q p

end Workspace.ProofLemmas.ConstrainedMinExists

open Workspace.ProofLemmas.ConstrainedMinExists

namespace ConstrainedMinExistsProof

-- Auxiliary lemma: lqNorm bounds individual coordinates.
private lemma lqNorm_ge_abs_coord {q : ℝ} (hq : 1 ≤ q) {d : ℕ}
    (x : Fin d → ℝ) (j : Fin d) :
    |x j| ≤ lqNorm q x := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_pos : 0 < (1 : ℝ) / q := by positivity
  have h_pos : ∀ k, 0 ≤ |x k| ^ q := fun k => Real.rpow_nonneg (abs_nonneg _) q
  have h_le : |x j| ^ q ≤ ∑ k, |x k| ^ q := by
    have := Finset.single_le_sum (f := fun k => |x k| ^ q)
      (s := Finset.univ) (a := j)
      (fun k _ => h_pos k) (Finset.mem_univ j)
    exact this
  have h_lhs_nn : 0 ≤ |x j| ^ q := h_pos j
  have h_rhs_nn : 0 ≤ ∑ k, |x k| ^ q := sum_abs_rpow_nonneg q x
  have h2 : (|x j| ^ q) ^ ((1 : ℝ) / q) ≤ (∑ k, |x k| ^ q) ^ ((1 : ℝ) / q) :=
    Real.rpow_le_rpow h_lhs_nn h_le (le_of_lt h_inv_pos)
  have habs_nn : (0 : ℝ) ≤ |x j| := abs_nonneg _
  have h3 : (|x j| ^ q) ^ ((1 : ℝ) / q) = |x j| := by
    rw [← Real.rpow_mul habs_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  rw [h3] at h2
  exact h2

-- Continuity of lqNorm
private lemma lqNorm_continuous {q : ℝ} (hq : 1 ≤ q) {d : ℕ} :
    Continuous (fun x : Fin d → ℝ => lqNorm q x) := by
  unfold lqNorm
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have h_inv_nn : 0 ≤ (1 : ℝ) / q := by positivity
  have hq_nn : 0 ≤ q := le_of_lt hq_pos
  have h_inner : Continuous (fun x : Fin d → ℝ => ∑ j, |x j| ^ q) := by
    apply continuous_finset_sum
    intro j _
    exact (Real.continuous_rpow_const hq_nn).comp ((continuous_apply j).abs)
  exact (Real.continuous_rpow_const h_inv_nn).comp h_inner

-- Continuity of g_lambda in p
private lemma g_lambda_continuous {q : ℝ} (hq : 1 ≤ q) (lambda : ℝ) {d : ℕ}
    (f : Fin d → ℝ) :
    Continuous (fun p : Fin d → ℝ => g_lambda q lambda f p) := by
  unfold g_lambda
  have h_arg : Continuous (fun p : Fin d → ℝ => fun j => p j - f j) := by
    apply continuous_pi
    intro j
    exact (continuous_apply j).sub continuous_const
  have h1 : Continuous (fun p : Fin d → ℝ => lqNorm q (fun j => p j - f j)) :=
    (lqNorm_continuous hq).comp h_arg
  have h2 : Continuous (fun p : Fin d → ℝ => lqNorm q p) := lqNorm_continuous hq
  exact h1.sub (continuous_const.mul h2)

-- Sum of g_lambda is continuous
private lemma sum_g_lambda_continuous {q : ℝ} (hq : 1 ≤ q) (lambda : ℝ) {n d : ℕ}
    (f : Fin d → ℝ) :
    Continuous (fun p : Fin n → Fin d → ℝ => ∑ i, g_lambda q lambda f (p i)) := by
  apply continuous_finset_sum
  intro i _
  exact (g_lambda_continuous hq lambda f).comp (continuous_apply i)

-- Coercive lower bound: g_lambda q lambda f p ≥ (1 - lambda) * lqNorm q p - 1
private lemma g_lambda_lower_bound {q : ℝ} (hq : 1 ≤ q) {lambda : ℝ}
    {d : ℕ} (f : Fin d → ℝ) (hf_norm : lqNorm q f = 1) (p : Fin d → ℝ) :
    (1 - lambda) * lqNorm q p - 1 ≤ g_lambda q lambda f p := by
  unfold g_lambda
  have h := LqNormSubReverseTriangle hq p f
  rw [hf_norm] at h
  linarith

end ConstrainedMinExistsProof

open ConstrainedMinExistsProof

theorem ConstrainedMinExists
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {n d : ℕ} (hd : 1 ≤ d)
    (f : Fin d → ℝ) (hf_norm : lqNorm q f = 1) (hf_nn : ∀ j, 0 ≤ f j)
    (sigma_assign : Fin n → Fin d → ℝ)
    (hsigma_pm : ∀ i j, sigma_assign i j = 1 ∨ sigma_assign i j = -1)
    (hsigma_zero : ∀ j, ∑ i, sigma_assign i j = 0) :
    ∃ p_star : Fin n → Fin d → ℝ,
      (∀ i j, (sigma_assign i j = 1 → 0 ≤ p_star i j) ∧
              (sigma_assign i j = -1 → p_star i j ≤ 0)) ∧
      (∀ p : Fin n → Fin d → ℝ,
        (∀ i j, (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                (sigma_assign i j = -1 → p i j ≤ 0)) →
        (∑ i, g_lambda q lambda f (p_star i)) ≤ (∑ i, g_lambda q lambda f (p i))) := by
  classical
  have hq_le : 1 ≤ q := le_of_lt hq
  -- Define the constraint set
  set S : Set (Fin n → Fin d → ℝ) :=
    {p | ∀ i j, (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                (sigma_assign i j = -1 → p i j ≤ 0)} with hS_def
  -- Define the objective
  set G : (Fin n → Fin d → ℝ) → ℝ :=
    fun p => ∑ i, g_lambda q lambda f (p i) with hG_def
  -- G is continuous
  have hG_cont : Continuous G := sum_g_lambda_continuous hq_le lambda f
  -- 0 ∈ S
  have h0_mem : (fun _ _ => (0 : ℝ)) ∈ S := by
    intro i j
    refine ⟨fun _ => le_refl 0, fun _ => le_refl 0⟩
  -- S is closed
  have hS_closed : IsClosed S := by
    have : S = ⋂ (i : Fin n) (j : Fin d),
        {p : Fin n → Fin d → ℝ | (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                                  (sigma_assign i j = -1 → p i j ≤ 0)} := by
      ext p
      simp only [Set.mem_iInter, Set.mem_setOf_eq, hS_def]
    rw [this]
    apply isClosed_iInter
    intro i
    apply isClosed_iInter
    intro j
    have h_eq : {p : Fin n → Fin d → ℝ | (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                                  (sigma_assign i j = -1 → p i j ≤ 0)} =
        {p | sigma_assign i j = 1 → 0 ≤ p i j} ∩
        {p | sigma_assign i j = -1 → p i j ≤ 0} := by
      ext p; simp [Set.mem_inter_iff, Set.mem_setOf_eq]
    rw [h_eq]
    apply IsClosed.inter
    · rcases hsigma_pm i j with h1 | h1
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = 1 → 0 ≤ p i j}
            = {p : Fin n → Fin d → ℝ | 0 ≤ p i j} := by
          ext p; simp [h1]
        rw [heq]
        have h_cont : Continuous (fun p : Fin n → Fin d → ℝ => p i j) :=
          (continuous_apply j).comp (continuous_apply i)
        exact isClosed_le continuous_const h_cont
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = 1 → 0 ≤ p i j}
            = Set.univ := by
          ext p
          simp only [Set.mem_setOf_eq, Set.mem_univ, iff_true]
          intro hcontr
          rw [h1] at hcontr
          linarith
        rw [heq]; exact isClosed_univ
    · rcases hsigma_pm i j with h1 | h1
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = -1 → p i j ≤ 0}
            = Set.univ := by
          ext p
          simp only [Set.mem_setOf_eq, Set.mem_univ, iff_true]
          intro hcontr
          rw [h1] at hcontr
          linarith
        rw [heq]; exact isClosed_univ
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = -1 → p i j ≤ 0}
            = {p : Fin n → Fin d → ℝ | p i j ≤ 0} := by
          ext p; simp [h1]
        rw [heq]
        have h_cont : Continuous (fun p : Fin n → Fin d → ℝ => p i j) :=
          (continuous_apply j).comp (continuous_apply i)
        exact isClosed_le h_cont continuous_const
  -- Set K := G 0
  set K : ℝ := G (fun _ _ => 0) with hK_def
  -- Define T := S ∩ {p | G p ≤ K}
  set T : Set (Fin n → Fin d → ℝ) := S ∩ {p | G p ≤ K} with hT_def
  -- T is closed
  have hT_closed : IsClosed T := hS_closed.inter (isClosed_le hG_cont continuous_const)
  -- T is bounded
  have hT_bdd : Bornology.IsBounded T := by
    have h_one_lam_pos : 0 < 1 - lambda := by linarith
    have h_one_lam_nn : 0 ≤ 1 - lambda := le_of_lt h_one_lam_pos
    set R : ℝ := (K + n) / (1 - lambda) with hR_def
    have h_pj_bound : ∀ p ∈ T, ∀ i j, |p i j| ≤ R := by
      intro p hp i j
      obtain ⟨hpS, hpK⟩ := hp
      simp only [Set.mem_setOf_eq] at hpK
      have h_each : ∀ i', (1 - lambda) * lqNorm q (p i') - 1 ≤ g_lambda q lambda f (p i') :=
        fun i' => g_lambda_lower_bound hq_le f hf_norm (p i')
      have h_sum : (1 - lambda) * (∑ i', lqNorm q (p i')) - n ≤ ∑ i', g_lambda q lambda f (p i') := by
        have h1 : (∑ i' : Fin n, ((1 - lambda) * lqNorm q (p i') - 1)) ≤
                   ∑ i', g_lambda q lambda f (p i') := by
          apply Finset.sum_le_sum
          intro i' _
          exact h_each i'
        have h2 : (∑ i' : Fin n, ((1 - lambda) * lqNorm q (p i') - 1)) =
                  (1 - lambda) * (∑ i', lqNorm q (p i')) - n := by
          rw [Finset.sum_sub_distrib]
          rw [← Finset.mul_sum]
          simp
        linarith [h1, h2.symm.le, h2.le]
      have h_sum2 : (1 - lambda) * (∑ i', lqNorm q (p i')) ≤ K + n := by
        have : ∑ i', g_lambda q lambda f (p i') = G p := rfl
        linarith
      have h_nn : ∀ i', 0 ≤ lqNorm q (p i') := fun i' => lqNorm_nonneg hq_le _
      have h_single_le_sum : lqNorm q (p i) ≤ ∑ i', lqNorm q (p i') := by
        exact Finset.single_le_sum (f := fun i' => lqNorm q (p i'))
          (s := Finset.univ) (a := i)
          (fun i' _ => h_nn i') (Finset.mem_univ _)
      have h_pi_bound : (1 - lambda) * lqNorm q (p i) ≤ K + n := by
        calc (1 - lambda) * lqNorm q (p i) ≤ (1 - lambda) * (∑ i', lqNorm q (p i')) := by
              exact mul_le_mul_of_nonneg_left h_single_le_sum h_one_lam_nn
          _ ≤ K + n := h_sum2
      have h_lqnorm_le_R : lqNorm q (p i) ≤ R := by
        rw [hR_def]
        rw [le_div_iff₀ h_one_lam_pos]
        linarith [mul_comm (1 - lambda) (lqNorm q (p i))]
      have h_abs_le : |p i j| ≤ lqNorm q (p i) := lqNorm_ge_abs_coord hq_le (p i) j
      linarith
    rw [Metric.isBounded_iff_subset_closedBall (0 : Fin n → Fin d → ℝ)]
    refine ⟨R, ?_⟩
    intro p hp
    rw [Metric.mem_closedBall, dist_zero_right]
    have hR_nn : 0 ≤ R := by
      rw [hR_def]
      apply div_nonneg
      · have h_g0 : ∀ i : Fin n, g_lambda q lambda f ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i) = 1 := by
          intro i
          unfold g_lambda
          have h_pi : ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i) = (fun (_ : Fin d) => (0 : ℝ)) := rfl
          rw [h_pi]
          have h_eq : (fun j : Fin d => ((fun (_ : Fin d) => (0 : ℝ)) j) - f j) = (fun j => -f j) := by
            funext j; simp
          rw [h_eq]
          have h_neg : lqNorm q (fun j : Fin d => -f j) = lqNorm q f := by
            have h1 := lqNorm_smul hq_le (-1 : ℝ) f
            have h2 : (fun j : Fin d => (-1 : ℝ) * f j) = (fun j => -f j) := by
              funext j; ring
            rw [h2] at h1
            simp at h1
            exact h1
          rw [h_neg, hf_norm]
          have h_zero : lqNorm q (fun (_ : Fin d) => (0 : ℝ)) = 0 := lqNorm_zero hq_le
          rw [h_zero]
          ring
        have hK_val : K = n := by
          show G (fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) = n
          show (∑ i : Fin n, g_lambda q lambda f ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i)) = n
          rw [Finset.sum_congr rfl (fun i _ => h_g0 i)]
          simp
        rw [hK_val]
        have hn_nn : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
        linarith
      · exact h_one_lam_nn
    rw [pi_norm_le_iff_of_nonneg hR_nn]
    intro i
    rw [pi_norm_le_iff_of_nonneg hR_nn]
    intro j
    simp only [Real.norm_eq_abs]
    exact h_pj_bound p hp i j
  -- T is compact
  have hT_compact : IsCompact T :=
    Metric.isCompact_iff_isClosed_bounded.mpr ⟨hT_closed, hT_bdd⟩
  -- T is nonempty
  have hT_nonempty : T.Nonempty := by
    refine ⟨fun _ _ => 0, h0_mem, ?_⟩
    simp only [Set.mem_setOf_eq]
    rfl
  -- G is continuous on T
  have hG_cont_on : ContinuousOn G T := hG_cont.continuousOn
  -- Apply IsCompact.exists_isMinOn
  obtain ⟨p_star, hp_star_T, hp_star_min⟩ :=
    hT_compact.exists_isMinOn hT_nonempty hG_cont_on
  refine ⟨p_star, hp_star_T.1, ?_⟩
  intro p hp
  by_cases hpK : G p ≤ K
  · have hpT : p ∈ T := ⟨hp, hpK⟩
    exact hp_star_min hpT
  · push_neg at hpK
    have hp_star_K : G p_star ≤ K := hp_star_T.2
    linarith

open Workspace.Types.LqNorm
open scoped BigOperators

/-- Strict-monotonicity primitive for `lqNorm`: if `tildep` agrees with
`p` off a single coordinate `j_0` and `|tildep j_0 - f j_0| < |p j_0 - f j_0|`,
then `lqNorm q (tildep - f) < lqNorm q (p - f)`. -/
theorem LqNormStrictDecrease_OfSingleCoordinateCloser
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (p tildep f : Fin d → ℝ) (j0 : Fin d)
    (h_eq_off : ∀ k : Fin d, k ≠ j0 → tildep k = p k)
    (h_strict : |tildep j0 - f j0| < |p j0 - f j0|) :
    lqNorm q (fun k => tildep k - f k) < lqNorm q (fun k => p k - f k) := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hinv_pos : 0 < (1 : ℝ) / q := by
    rw [one_div]; exact inv_pos.mpr hq_pos
  -- Step 1: reduce to comparing the inner sums via strict monotonicity of x ↦ x^(1/q)
  unfold lqNorm
  -- Set up the two sums
  set S₁ : ℝ := ∑ j, |tildep j - f j| ^ q with hS₁
  set S₂ : ℝ := ∑ j, |p j - f j| ^ q with hS₂
  have hS₁_nn : 0 ≤ S₁ :=
    Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)
  have hS₂_nn : 0 ≤ S₂ :=
    Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)
  -- Step 2: show S₁ < S₂
  have h_sum_lt : S₁ < S₂ := by
    -- Apply Finset.sum_lt_sum: every term is ≤, and at j0 it is strictly <
    refine Finset.sum_lt_sum (fun k _ => ?_) ⟨j0, Finset.mem_univ j0, ?_⟩
    · -- term-wise ≤
      by_cases hk : k = j0
      · -- at j0, use strict inequality (which is in particular ≤)
        subst hk
        have h_abs_nn₁ : 0 ≤ |tildep k - f k| := abs_nonneg _
        have h_abs_lt : |tildep k - f k| < |p k - f k| := h_strict
        exact le_of_lt (Real.rpow_lt_rpow h_abs_nn₁ h_abs_lt hq_pos)
      · -- off j0: equality
        have hk_eq : tildep k = p k := h_eq_off k hk
        rw [hk_eq]
    · -- strict at j0
      have h_abs_nn₁ : 0 ≤ |tildep j0 - f j0| := abs_nonneg _
      exact Real.rpow_lt_rpow h_abs_nn₁ h_strict hq_pos
  -- Step 3: apply (·)^(1/q) which is strictly monotonic on [0,∞)
  exact Real.rpow_lt_rpow hS₁_nn h_sum_lt hinv_pos

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormStrictIncrease_OfSingleCoordinateLarger
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (p tildep : Fin d → ℝ) (j0 : Fin d)
    (h_eq_off : ∀ k : Fin d, k ≠ j0 → tildep k = p k)
    (h_strict : |p j0| < |tildep j0|) :
    lqNorm q p < lqNorm q tildep := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hinv_pos : 0 < (1 : ℝ) / q := by
    rw [one_div]; exact inv_pos.mpr hq_pos
  -- Step 1: reduce to comparing the inner sums via strict monotonicity of x ↦ x^(1/q)
  unfold lqNorm
  -- Set up the two sums
  set S₁ : ℝ := ∑ j, |p j| ^ q with hS₁
  set S₂ : ℝ := ∑ j, |tildep j| ^ q with hS₂
  have hS₁_nn : 0 ≤ S₁ :=
    Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)
  have hS₂_nn : 0 ≤ S₂ :=
    Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)
  -- Step 2: show S₁ < S₂
  have h_sum_lt : S₁ < S₂ := by
    -- Apply Finset.sum_lt_sum: every term is ≤, and at j0 it is strictly <
    refine Finset.sum_lt_sum (fun k _ => ?_) ⟨j0, Finset.mem_univ j0, ?_⟩
    · -- term-wise ≤
      by_cases hk : k = j0
      · -- at j0, use strict inequality (which is in particular ≤)
        subst hk
        have h_abs_nn : 0 ≤ |p k| := abs_nonneg _
        exact le_of_lt (Real.rpow_lt_rpow h_abs_nn h_strict hq_pos)
      · -- off j0: equality
        have hk_eq : tildep k = p k := h_eq_off k hk
        rw [hk_eq]
    · -- strict at j0
      have h_abs_nn : 0 ≤ |p j0| := abs_nonneg _
      exact Real.rpow_lt_rpow h_abs_nn h_strict hq_pos
  -- Step 3: apply (·)^(1/q) which is strictly monotonic on [0,∞)
  exact Real.rpow_lt_rpow hS₁_nn h_sum_lt hinv_pos

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem Claim1_RuleOutInterior
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (j : Fin d) (hsig : sigma j = 1) :
    p_star j = 0 ∨ f j ≤ p_star j := by
  -- Proof by contradiction: suppose 0 < p_star j and p_star j < f j.
  by_contra hcon
  push_neg at hcon
  obtain ⟨hpj_ne, hpj_lt_fj⟩ := hcon
  -- From hp_in and σ_j = 1, p_star j ≥ 0; combined with ≠ 0 gives 0 < p_star j.
  have hpj_nn : 0 ≤ p_star j := (hp_in j).1 hsig
  have hpj_pos : 0 < p_star j := lt_of_le_of_ne hpj_nn (Ne.symm hpj_ne)
  -- Get the local-min radius ε > 0.
  obtain ⟨ε, hε_pos, hε_loc⟩ := hp_loc
  -- Define δ := min(ε/2, (f j - p_star j)/2) > 0.
  have hgap_pos : 0 < f j - p_star j := sub_pos.mpr hpj_lt_fj
  set δ : ℝ := min (ε / 2) ((f j - p_star j) / 2) with hδ_def
  have hδ_pos : 0 < δ := lt_min (by linarith) (by linarith)
  have hδ_le_eps_half : δ ≤ ε / 2 := min_le_left _ _
  have hδ_le_gap_half : δ ≤ (f j - p_star j) / 2 := min_le_right _ _
  -- Define t := p_star j + δ.
  set t : ℝ := p_star j + δ with ht_def
  have ht_gt_pj : p_star j < t := by rw [ht_def]; linarith
  have ht_lt_fj : t < f j := by
    rw [ht_def]
    have : (f j - p_star j) / 2 < f j - p_star j := by linarith
    linarith
  have ht_pos : 0 < t := lt_trans hpj_pos ht_gt_pj
  have ht_nn : 0 ≤ t := le_of_lt ht_pos
  -- Define the perturbation tildep := update p_star j t.
  set tildep : Fin d → ℝ := Function.update p_star j t with htildep_def
  -- tildep j = t.
  have htildep_at_j : tildep j = t := by
    simp [htildep_def, Function.update_self]
  -- For k ≠ j, tildep k = p_star k.
  have htildep_off_j : ∀ k : Fin d, k ≠ j → tildep k = p_star k := by
    intro k hk
    simp [htildep_def, Function.update_of_ne hk]
  -- tildep is in the orthant.
  have htildep_in : ∀ k, (sigma k = 1 → 0 ≤ tildep k) ∧ (sigma k = -1 → tildep k ≤ 0) := by
    intro k
    by_cases hk : k = j
    · subst hk
      refine ⟨fun _ => ?_, fun hsig_neg => ?_⟩
      · rw [htildep_at_j]; exact ht_nn
      · -- σ k = 1, but hypothesis says σ k = -1. Contradiction.
        exfalso
        rw [hsig] at hsig_neg
        linarith
    · rw [htildep_off_j k hk]
      exact hp_in k
  -- |tildep k - p_star k| < ε for all k.
  have htildep_close : ∀ k, |tildep k - p_star k| < ε := by
    intro k
    by_cases hk : k = j
    · subst hk
      rw [htildep_at_j, ht_def]
      have : p_star k + δ - p_star k = δ := by ring
      rw [this]
      rw [abs_of_pos hδ_pos]
      linarith
    · rw [htildep_off_j k hk]
      have : p_star k - p_star k = 0 := by ring
      rw [this, abs_zero]
      exact hε_pos
  -- By local-min: g(p_star) ≤ g(tildep).
  have hg_le : g_lambda q lambda f p_star ≤ g_lambda q lambda f tildep :=
    hε_loc tildep htildep_in htildep_close
  -- Now derive a strict inequality the other way.
  -- Step (a): lqNorm q (tildep - f) < lqNorm q (p_star - f).
  -- Need |tildep j - f j| < |p_star j - f j|.
  -- |tildep j - f j| = |t - f j| = f j - t (since t < f j).
  -- |p_star j - f j| = f j - p_star j (since p_star j < f j).
  -- And f j - t < f j - p_star j since p_star j < t.
  have h_abs_strict_decrease : |tildep j - f j| < |p_star j - f j| := by
    rw [htildep_at_j]
    have h1 : t - f j < 0 := sub_neg.mpr ht_lt_fj
    have h2 : p_star j - f j < 0 := sub_neg.mpr hpj_lt_fj
    rw [abs_of_neg h1, abs_of_neg h2]
    linarith
  have h_eq_off_decrease : ∀ k : Fin d, k ≠ j → tildep k = p_star k := htildep_off_j
  have hnorm_decrease :
      lqNorm q (fun k => tildep k - f k) < lqNorm q (fun k => p_star k - f k) :=
    LqNormStrictDecrease_OfSingleCoordinateCloser hq hd p_star tildep f j h_eq_off_decrease h_abs_strict_decrease
  -- Step (b): lqNorm q p_star < lqNorm q tildep.
  -- |p_star j| = p_star j, |tildep j| = t, p_star j < t.
  have h_abs_strict_increase : |p_star j| < |tildep j| := by
    rw [htildep_at_j]
    rw [abs_of_pos hpj_pos, abs_of_pos ht_pos]
    exact ht_gt_pj
  have h_eq_off_increase : ∀ k : Fin d, k ≠ j → tildep k = p_star k := htildep_off_j
  have hnorm_increase : lqNorm q p_star < lqNorm q tildep :=
    LqNormStrictIncrease_OfSingleCoordinateLarger hq hd p_star tildep j h_eq_off_increase h_abs_strict_increase
  -- Combine: g_lambda q lambda f tildep < g_lambda q lambda f p_star.
  have hg_strict_lt : g_lambda q lambda f tildep < g_lambda q lambda f p_star := by
    unfold g_lambda
    -- LHS = lqNorm q (tildep - f) - lambda * lqNorm q tildep
    -- RHS = lqNorm q (p_star - f) - lambda * lqNorm q p_star
    -- LHS < RHS ↔ lqNorm q (tildep - f) - lqNorm q (p_star - f) < lambda * (lqNorm q tildep - lqNorm q p_star)
    -- We have: lqNorm q (tildep - f) < lqNorm q (p_star - f) (so LHS_decrease < 0)
    -- and: lambda * (lqNorm q tildep - lqNorm q p_star) > 0 (so RHS positive).
    have h1 : lqNorm q (fun k => tildep k - f k) - lqNorm q (fun k => p_star k - f k) < 0 := by
      linarith
    have h2 : 0 < lambda * (lqNorm q tildep - lqNorm q p_star) := by
      apply mul_pos hlam0
      linarith
    linarith
  -- Contradiction.
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormPartialDerivative_PosBranch
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d)
    (hx_pos : 0 < x j) (hlq_pos : 0 < lqNorm q x) :
    HasDerivAt (fun t : ℝ => lqNorm q (Function.update x j t))
      ((x j) ^ (q - 1) / (lqNorm q x) ^ (q - 1)) (x j) := by
  -- Setup basic facts about q
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_xj_ne : (x j) ≠ 0 := ne_of_gt hx_pos
  have h_lqq_pos : 0 < lqNorm q x := hlq_pos
  have h_lqq_ne : lqNorm q x ≠ 0 := ne_of_gt h_lqq_pos
  have h_lqq_nonneg : 0 ≤ lqNorm q x := le_of_lt h_lqq_pos
  -- Define the constant part C = ∑_{k≠j} |x k|^q
  set C : ℝ := ∑ k ∈ Finset.univ.erase j, |x k| ^ q with hC_def
  -- The total sum equals C + (x j)^q (using |x j| = x j since x j > 0)
  have h_total_sum : (∑ k, |x k| ^ q) = C + (x j) ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h1 : (∑ k, |x k| ^ q) = ∑ k ∈ Finset.univ.erase j, |x k| ^ q + |x j| ^ q := by
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d)) (fun k => |x k| ^ q) hj_mem]
    rw [h1, abs_of_pos hx_pos]
  -- (lqNorm q x)^q = total_sum: ((∑|x|^q)^(1/q))^q = ∑|x|^q
  have h_lqNorm_q_eq : (lqNorm q x) ^ q = ∑ k, |x k| ^ q := by
    unfold lqNorm
    rw [← Real.rpow_mul (sum_abs_rpow_nonneg q x), one_div_mul_cancel hq_ne, Real.rpow_one]
  -- Show: in a nbhd of x j, the function equals (C + t^q)^(1/q)
  have h_pos_nhd : ∀ᶠ t in nhds (x j), (0 : ℝ) < t :=
    eventually_gt_nhds hx_pos
  have h_eq_local : ∀ᶠ t in nhds (x j),
      lqNorm q (Function.update x j t) = (C + t ^ q) ^ ((1 : ℝ) / q) := by
    filter_upwards [h_pos_nhd] with t ht_pos
    unfold lqNorm
    congr 1
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
          (fun k => |Function.update x j t k| ^ q) hj_mem]
    rw [Function.update_self, abs_of_pos ht_pos]
    congr 1
    apply Finset.sum_congr rfl
    intro k hk
    have hkj : k ≠ j := Finset.ne_of_mem_erase hk
    rw [Function.update_of_ne hkj]
  -- Compute derivative of t ↦ C + t^q at t = x j
  have h_t_pow_q : HasDerivAt (fun t : ℝ => t ^ q) (q * (x j) ^ (q - 1)) (x j) :=
    Real.hasDerivAt_rpow_const (Or.inl h_xj_ne)
  have h_C_add : HasDerivAt (fun t : ℝ => C + t ^ q) (q * (x j) ^ (q - 1)) (x j) := by
    have := h_t_pow_q.const_add C
    convert this using 1
  -- (C + (x j)^q) = (lqNorm q x)^q > 0
  have h_inner_eq : C + (x j) ^ q = (lqNorm q x) ^ q := by
    rw [← h_total_sum, ← h_lqNorm_q_eq]
  have h_inner_pos : 0 < C + (x j) ^ q := by
    rw [h_inner_eq]
    exact Real.rpow_pos_of_pos h_lqq_pos q
  have h_inner_ne : C + (x j) ^ q ≠ 0 := ne_of_gt h_inner_pos
  -- Use HasDerivAt.rpow_const for the outer composition
  have h_outer : HasDerivAt (fun t : ℝ => (C + t ^ q) ^ ((1 : ℝ) / q))
      (q * (x j) ^ (q - 1) * ((1 : ℝ) / q) * (C + (x j) ^ q) ^ ((1 : ℝ) / q - 1)) (x j) :=
    h_C_add.rpow_const (Or.inl h_inner_ne)
  -- Transfer via eventuallyEq
  have h_eq_local' : (fun t : ℝ => lqNorm q (Function.update x j t)) =ᶠ[nhds (x j)]
      (fun t : ℝ => (C + t ^ q) ^ ((1 : ℝ) / q)) := by
    filter_upwards [h_eq_local] with t ht
    exact ht
  rw [Filter.EventuallyEq.hasDerivAt_iff h_eq_local']
  -- Algebraic manipulation: show the two derivative values are equal
  convert h_outer using 1
  -- Goal: (x j)^(q-1) / (lqNorm q x)^(q-1) = q * (x j)^(q-1) * (1/q) * (C + (x j)^q)^(1/q - 1)
  rw [h_inner_eq]
  -- Now: (x j)^(q-1) / (lqNorm q x)^(q-1) = q * (x j)^(q-1) * (1/q) * ((lqNorm q x)^q)^(1/q - 1)
  -- Step 1: simplify q * (...) * (1/q) = (...)
  have h_q_simp : q * (x j) ^ (q - 1) * ((1 : ℝ) / q) = (x j) ^ (q - 1) := by
    field_simp
  rw [h_q_simp]
  -- Step 2: ((lqNorm q x)^q)^(1/q - 1) = (lqNorm q x)^(q*(1/q - 1)) = (lqNorm q x)^(1 - q)
  have h_pow_simp : ((lqNorm q x) ^ q) ^ ((1 : ℝ) / q - 1) = (lqNorm q x) ^ (1 - q) := by
    rw [← Real.rpow_mul h_lqq_nonneg]
    congr 1
    field_simp
  rw [h_pow_simp]
  -- Step 3: (lqNorm q x)^(1 - q) = ((lqNorm q x)^(q-1))⁻¹
  have h_neg : (lqNorm q x) ^ (1 - q) = ((lqNorm q x) ^ (q - 1))⁻¹ := by
    have : (1 - q) = -(q - 1) := by ring
    rw [this, Real.rpow_neg h_lqq_nonneg]
  rw [h_neg]
  -- Goal: (x j)^(q-1) / (lqNorm q x)^(q-1) = (x j)^(q-1) * ((lqNorm q x)^(q-1))⁻¹
  rw [div_eq_mul_inv]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem InteriorFOC_Pos
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (hp_pos : 0 < lqNorm q p_star)
    (j : Fin d) (hsig : sigma j = 1) (hpf : f j < p_star j) :
    (p_star j - f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
      = lambda * ((p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) := by
  -- Strategy: restrict g_lambda to the line through p_star in direction e_j and
  -- apply IsLocalMin.hasDerivAt_eq_zero.
  -- Setup
  have hpj_pos : 0 < p_star j := lt_of_le_of_lt (hf_nn j) hpf
  have hpfj_pos : 0 < p_star j - f j := sub_pos.mpr hpf
  -- Define y := p_star - f and y' := p_star (so we can apply LqNormPartialDerivative_PosBranch)
  set y : Fin d → ℝ := fun k => p_star k - f k with hy_def
  have hyj_pos : 0 < y j := hpfj_pos
  have hy_lq_pos : 0 < lqNorm q y := hpf_pos
  -- KEY ALGEBRAIC IDENTITY:
  -- (fun k => Function.update p_star j t k - f k) = Function.update y j (t - f j)
  have h_update_sub : ∀ t : ℝ,
      (fun k => Function.update p_star j t k - f k) = Function.update y j (t - f j) := by
    intro t
    funext k
    by_cases hk : k = j
    · subst hk
      rw [Function.update_self, Function.update_self]
    · rw [Function.update_of_ne hk, Function.update_of_ne hk]
  -- Derivative of t ↦ lqNorm q (Function.update y j (t - f j)) at t = p_star j
  -- Step 1: t ↦ t - f j has derivative 1 at t = p_star j, with value (p_star j - f j) = y j
  have h_lin : HasDerivAt (fun t : ℝ => t - f j) 1 (p_star j) := by
    have := (hasDerivAt_id (p_star j)).sub_const (f j)
    convert this
  -- Step 2: t ↦ lqNorm q (Function.update y j t) has derivative
  -- (y j)^(q-1) / (lqNorm q y)^(q-1) at t = y j = p_star j - f j
  have h_lq1 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update y j t))
      ((y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (y j) :=
    LqNormPartialDerivative_PosBranch hq hd y j hyj_pos hy_lq_pos
  -- Compose: t ↦ lqNorm q (Function.update y j (t - f j))
  -- has derivative ((y j)^(q-1)/(lqNorm q y)^(q-1)) * 1 at t = p_star j
  -- (since t - f j evaluated at p_star j gives p_star j - f j = y j)
  have h_yj_eq : y j = p_star j - f j := by simp [hy_def]
  have h_comp1 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update y j (t - f j)))
      ((y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (p_star j) := by
    have h_at : (p_star j) - f j = y j := h_yj_eq.symm
    have := HasDerivAt.comp (p_star j) (h_at ▸ h_lq1) h_lin
    -- this : HasDerivAt ((fun t => lqNorm q (Function.update y j t)) ∘ (fun t => t - f j))
    --   ((y j)^(q-1)/(lqNorm q y)^(q-1) * 1) (p_star j)
    have h_simp : (y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1) * 1 =
                  (y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1) := by ring
    rw [← h_simp]
    exact this
  -- Now rewrite the result in terms of p_star - f
  have h_deriv1 : HasDerivAt (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
      ((y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (p_star j) := by
    have h_eq : (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
              = (fun t : ℝ => lqNorm q (Function.update y j (t - f j))) := by
      funext t
      rw [h_update_sub t]
    rw [h_eq]
    exact h_comp1
  -- Derivative of t ↦ lqNorm q (Function.update p_star j t) at t = p_star j
  have h_deriv2 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update p_star j t))
      ((p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) (p_star j) :=
    LqNormPartialDerivative_PosBranch hq hd p_star j hpj_pos hp_pos
  -- Combine: derivative of φ(t) = g_lambda q lambda f (Function.update p_star j t)
  -- equals (deriv1) - lambda * (deriv2)
  set D1 : ℝ := (y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1) with hD1_def
  set D2 : ℝ := (p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1) with hD2_def
  have h_phi_deriv : HasDerivAt
      (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t))
      (D1 - lambda * D2) (p_star j) := by
    unfold g_lambda
    exact h_deriv1.sub (h_deriv2.const_mul lambda)
  -- Now show: φ has a local min at p_star j
  obtain ⟨ε, hε_pos, hε_min⟩ := hp_loc
  -- Pick δ = min(ε, p_star j)
  have h_local_min :
      IsLocalMin (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) := by
    -- We need: ∀ᶠ t in nhds (p_star j), φ (p_star j) ≤ φ t
    rw [IsLocalMin, IsMinFilter]
    -- Want: ∀ᶠ t in nhds (p_star j), g_lambda q lambda f p_star ≤ g_lambda q lambda f (Function.update p_star j t)
    -- Note: Function.update p_star j (p_star j) = p_star.
    have h_eventually_close : ∀ᶠ t in nhds (p_star j), |t - p_star j| < ε := by
      filter_upwards [eventually_abs_sub_lt (p_star j) hε_pos] with t ht
      exact ht
    -- Also need t in (p_star j - p_star j, ∞) i.e. t > 0 for j coordinate
    have h_eventually_pos : ∀ᶠ t in nhds (p_star j), 0 < t := eventually_gt_nhds hpj_pos
    filter_upwards [h_eventually_close, h_eventually_pos] with t ht_close ht_pos
    -- Apply hε_min to p := Function.update p_star j t
    -- After update_self, Function.update p_star j (p_star j) = p_star
    show g_lambda q lambda f (Function.update p_star j (p_star j)) ≤
         g_lambda q lambda f (Function.update p_star j t)
    rw [Function.update_eq_self]
    apply hε_min (Function.update p_star j t)
    · -- Orthant condition
      intro k
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        refine ⟨fun _ => le_of_lt ht_pos, fun hcontr => ?_⟩
        rw [hsig] at hcontr; linarith
      · rw [Function.update_of_ne hk]
        exact hp_in k
    · -- Distance condition: |p k - p_star k| < ε for all k
      intro k
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        exact ht_close
      · rw [Function.update_of_ne hk]
        simp only [sub_self, abs_zero]
        exact hε_pos
  -- Apply IsLocalMin.hasDerivAt_eq_zero
  have h_zero : D1 - lambda * D2 = 0 := h_local_min.hasDerivAt_eq_zero h_phi_deriv
  -- Rewrite to obtain the goal
  -- Goal: D1 = lambda * D2
  have hD1_eq_D2 : D1 = lambda * D2 := by linarith
  -- Now translate back to the goal statement
  show (p_star j - f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
      = lambda * ((p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1))
  have h_y_lq : lqNorm q y = lqNorm q (fun k => p_star k - f k) := rfl
  rw [← h_yj_eq, ← h_y_lq]
  exact hD1_eq_D2

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormPartialDerivative_NegBranch
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d)
    (hx_neg : x j < 0) (hlq_pos : 0 < lqNorm q x) :
    HasDerivAt (fun t : ℝ => lqNorm q (Function.update x j t))
      (-(-(x j)) ^ (q - 1) / (lqNorm q x) ^ (q - 1)) (x j) := by
  -- Setup basic facts about q
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_xj_ne : (x j) ≠ 0 := ne_of_lt hx_neg
  have h_neg_xj_pos : 0 < -(x j) := neg_pos.mpr hx_neg
  have h_neg_xj_ne : -(x j) ≠ 0 := ne_of_gt h_neg_xj_pos
  have h_lqq_pos : 0 < lqNorm q x := hlq_pos
  have h_lqq_ne : lqNorm q x ≠ 0 := ne_of_gt h_lqq_pos
  have h_lqq_nonneg : 0 ≤ lqNorm q x := le_of_lt h_lqq_pos
  -- Define the constant part C = ∑_{k≠j} |x k|^q
  set C : ℝ := ∑ k ∈ Finset.univ.erase j, |x k| ^ q with hC_def
  -- The total sum equals C + (-(x j))^q (using |x j| = -(x j) since x j < 0)
  have h_total_sum : (∑ k, |x k| ^ q) = C + (-(x j)) ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h1 : (∑ k, |x k| ^ q) = ∑ k ∈ Finset.univ.erase j, |x k| ^ q + |x j| ^ q := by
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d)) (fun k => |x k| ^ q) hj_mem]
    rw [h1, abs_of_neg hx_neg]
  -- (lqNorm q x)^q = total_sum: ((∑|x|^q)^(1/q))^q = ∑|x|^q
  have h_lqNorm_q_eq : (lqNorm q x) ^ q = ∑ k, |x k| ^ q := by
    unfold lqNorm
    rw [← Real.rpow_mul (sum_abs_rpow_nonneg q x), one_div_mul_cancel hq_ne, Real.rpow_one]
  -- Show: in a nbhd of x j, the function equals (C + (-t)^q)^(1/q)
  have h_neg_nhd : ∀ᶠ t in nhds (x j), t < (0 : ℝ) :=
    eventually_lt_nhds hx_neg
  have h_eq_local : ∀ᶠ t in nhds (x j),
      lqNorm q (Function.update x j t) = (C + (-t) ^ q) ^ ((1 : ℝ) / q) := by
    filter_upwards [h_neg_nhd] with t ht_neg
    unfold lqNorm
    congr 1
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
          (fun k => |Function.update x j t k| ^ q) hj_mem]
    rw [Function.update_self, abs_of_neg ht_neg]
    congr 1
    apply Finset.sum_congr rfl
    intro k hk
    have hkj : k ≠ j := Finset.ne_of_mem_erase hk
    rw [Function.update_of_ne hkj]
  -- Compute derivative of t ↦ -t at t = x j
  have h_neg_t : HasDerivAt (fun t : ℝ => -t) (-1 : ℝ) (x j) := by
    simpa using (hasDerivAt_id (x j)).neg
  -- Compute derivative of s ↦ s^q at s = -(x j)
  have h_t_pow_q_outer : HasDerivAt (fun s : ℝ => s ^ q) (q * (-(x j)) ^ (q - 1)) (-(x j)) :=
    Real.hasDerivAt_rpow_const (Or.inl h_neg_xj_ne)
  -- Chain: derivative of t ↦ (-t)^q at t = x j is q * (-(x j))^(q-1) * (-1)
  have h_neg_t_pow_q : HasDerivAt (fun t : ℝ => (-t) ^ q)
      (q * (-(x j)) ^ (q - 1) * (-1)) (x j) :=
    h_t_pow_q_outer.comp (x j) h_neg_t
  -- Add constant C
  have h_C_add : HasDerivAt (fun t : ℝ => C + (-t) ^ q)
      (q * (-(x j)) ^ (q - 1) * (-1)) (x j) := by
    have := h_neg_t_pow_q.const_add C
    convert this using 1
  -- (C + (-(x j))^q) = (lqNorm q x)^q > 0
  have h_inner_eq : C + (-(x j)) ^ q = (lqNorm q x) ^ q := by
    rw [← h_total_sum, ← h_lqNorm_q_eq]
  have h_inner_pos : 0 < C + (-(x j)) ^ q := by
    rw [h_inner_eq]
    exact Real.rpow_pos_of_pos h_lqq_pos q
  have h_inner_ne : C + (-(x j)) ^ q ≠ 0 := ne_of_gt h_inner_pos
  -- Use HasDerivAt.rpow_const for the outer composition
  have h_outer : HasDerivAt (fun t : ℝ => (C + (-t) ^ q) ^ ((1 : ℝ) / q))
      (q * (-(x j)) ^ (q - 1) * (-1) * ((1 : ℝ) / q) *
        (C + (-(x j)) ^ q) ^ ((1 : ℝ) / q - 1)) (x j) :=
    h_C_add.rpow_const (Or.inl h_inner_ne)
  -- Transfer via eventuallyEq
  have h_eq_local' : (fun t : ℝ => lqNorm q (Function.update x j t)) =ᶠ[nhds (x j)]
      (fun t : ℝ => (C + (-t) ^ q) ^ ((1 : ℝ) / q)) := by
    filter_upwards [h_eq_local] with t ht
    exact ht
  rw [Filter.EventuallyEq.hasDerivAt_iff h_eq_local']
  -- Algebraic manipulation
  convert h_outer using 1
  -- Goal: -(-(x j))^(q-1) / (lqNorm q x)^(q-1) =
  --       q * (-(x j))^(q-1) * (-1) * (1/q) * (C + (-(x j))^q)^(1/q - 1)
  rw [h_inner_eq]
  -- Step 1: simplify q * (-(x j))^(q-1) * (-1) * (1/q) = -(-(x j))^(q-1)
  have h_q_simp : q * (-(x j)) ^ (q - 1) * (-1) * ((1 : ℝ) / q) = -(-(x j)) ^ (q - 1) := by
    field_simp
  rw [h_q_simp]
  -- Step 2: ((lqNorm q x)^q)^(1/q - 1) = (lqNorm q x)^(1 - q)
  have h_pow_simp : ((lqNorm q x) ^ q) ^ ((1 : ℝ) / q - 1) = (lqNorm q x) ^ (1 - q) := by
    rw [← Real.rpow_mul h_lqq_nonneg]
    congr 1
    field_simp
  rw [h_pow_simp]
  -- Step 3: (lqNorm q x)^(1 - q) = ((lqNorm q x)^(q-1))⁻¹
  have h_neg : (lqNorm q x) ^ (1 - q) = ((lqNorm q x) ^ (q - 1))⁻¹ := by
    have : (1 - q) = -(q - 1) := by ring
    rw [this, Real.rpow_neg h_lqq_nonneg]
  rw [h_neg]
  -- Goal: -(-(x j))^(q-1) / (lqNorm q x)^(q-1) = -(-(x j))^(q-1) * ((lqNorm q x)^(q-1))⁻¹
  rw [div_eq_mul_inv]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

/-- **Interior first-order condition — negative branch.**

Under the same hypotheses as `Claim1_RuleOutInterior`, suppose furthermore
`lqNorm q (p_star - f) > 0` and `lqNorm q p_star > 0`. Then for every
index `j` with `σ j = -1` and `p_star j < 0`, the first-order condition
holds:
`(f j - p_star j)^(q-1) / (lqNorm q (p_star - f))^(q-1)
  = λ · (-(p_star j))^(q-1) / (lqNorm q p_star)^(q-1)`.

Paper reference: Block 2, Steps 2.3.1–2.3.4 (KKT negative branch);
mirror of `InteriorFOC_Pos` with sign flips. -/
theorem InteriorFOC_Neg
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (hp_pos : 0 < lqNorm q p_star)
    (j : Fin d) (hsig : sigma j = -1) (hpneg : p_star j < 0) :
    (f j - p_star j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
      = lambda * ((-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) := by
  -- Mirror of InteriorFOC_Pos with sign flips.
  -- Setup
  have hpj_neg : p_star j < 0 := hpneg
  have hfj_nn : 0 ≤ f j := hf_nn j
  -- y j = p_star j - f j < 0 since p_star j < 0 and f j ≥ 0
  have hyj_neg : p_star j - f j < 0 := by linarith
  have hfj_sub_pos : 0 < f j - p_star j := by linarith
  -- Define y := p_star - f
  set y : Fin d → ℝ := fun k => p_star k - f k with hy_def
  have hyj_neg' : y j < 0 := hyj_neg
  have hy_lq_pos : 0 < lqNorm q y := hpf_pos
  -- KEY ALGEBRAIC IDENTITY:
  -- (fun k => Function.update p_star j t k - f k) = Function.update y j (t - f j)
  have h_update_sub : ∀ t : ℝ,
      (fun k => Function.update p_star j t k - f k) = Function.update y j (t - f j) := by
    intro t
    funext k
    by_cases hk : k = j
    · subst hk
      rw [Function.update_self, Function.update_self]
    · rw [Function.update_of_ne hk, Function.update_of_ne hk]
  -- Derivative of t ↦ lqNorm q (Function.update y j (t - f j)) at t = p_star j
  -- Step 1: t ↦ t - f j has derivative 1 at t = p_star j, with value (p_star j - f j) = y j
  have h_lin : HasDerivAt (fun t : ℝ => t - f j) 1 (p_star j) := by
    have := (hasDerivAt_id (p_star j)).sub_const (f j)
    convert this
  -- Step 2: t ↦ lqNorm q (Function.update y j t) has derivative
  -- -(-(y j))^(q-1) / (lqNorm q y)^(q-1) at t = y j
  have h_lq1 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update y j t))
      (-(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (y j) :=
    LqNormPartialDerivative_NegBranch hq hd y j hyj_neg' hy_lq_pos
  -- Compose: t ↦ lqNorm q (Function.update y j (t - f j))
  -- has derivative the same value at t = p_star j (since 1 * x = x)
  have h_yj_eq : y j = p_star j - f j := by simp [hy_def]
  have h_comp1 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update y j (t - f j)))
      (-(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (p_star j) := by
    have h_at : (p_star j) - f j = y j := h_yj_eq.symm
    have := HasDerivAt.comp (p_star j) (h_at ▸ h_lq1) h_lin
    have h_simp : -(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1) * 1 =
                  -(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1) := by ring
    rw [← h_simp]
    exact this
  -- Now rewrite the result in terms of p_star - f
  have h_deriv1 : HasDerivAt (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
      (-(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (p_star j) := by
    have h_eq : (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
              = (fun t : ℝ => lqNorm q (Function.update y j (t - f j))) := by
      funext t
      rw [h_update_sub t]
    rw [h_eq]
    exact h_comp1
  -- Derivative of t ↦ lqNorm q (Function.update p_star j t) at t = p_star j
  have h_deriv2 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update p_star j t))
      (-(-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) (p_star j) :=
    LqNormPartialDerivative_NegBranch hq hd p_star j hpneg hp_pos
  -- Combine: derivative of φ(t) = g_lambda q lambda f (Function.update p_star j t)
  -- equals (deriv1) - lambda * (deriv2)
  set D1 : ℝ := -(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1) with hD1_def
  set D2 : ℝ := -(-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1) with hD2_def
  have h_phi_deriv : HasDerivAt
      (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t))
      (D1 - lambda * D2) (p_star j) := by
    unfold g_lambda
    exact h_deriv1.sub (h_deriv2.const_mul lambda)
  -- Now show: φ has a local min at p_star j
  obtain ⟨ε, hε_pos, hε_min⟩ := hp_loc
  have h_local_min :
      IsLocalMin (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) := by
    rw [IsLocalMin, IsMinFilter]
    have h_eventually_close : ∀ᶠ t in nhds (p_star j), |t - p_star j| < ε := by
      filter_upwards [eventually_abs_sub_lt (p_star j) hε_pos] with t ht
      exact ht
    -- We need t < 0 in a neighborhood of p_star j (since p_star j < 0)
    have h_eventually_neg : ∀ᶠ t in nhds (p_star j), t < 0 := eventually_lt_nhds hpneg
    filter_upwards [h_eventually_close, h_eventually_neg] with t ht_close ht_neg
    show g_lambda q lambda f (Function.update p_star j (p_star j)) ≤
         g_lambda q lambda f (Function.update p_star j t)
    rw [Function.update_eq_self]
    apply hε_min (Function.update p_star j t)
    · -- Orthant condition
      intro k
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        refine ⟨fun hcontr => ?_, fun _ => le_of_lt ht_neg⟩
        rw [hsig] at hcontr; linarith
      · rw [Function.update_of_ne hk]
        exact hp_in k
    · -- Distance condition: |p k - p_star k| < ε for all k
      intro k
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        exact ht_close
      · rw [Function.update_of_ne hk]
        simp only [sub_self, abs_zero]
        exact hε_pos
  -- Apply IsLocalMin.hasDerivAt_eq_zero
  have h_zero : D1 - lambda * D2 = 0 := h_local_min.hasDerivAt_eq_zero h_phi_deriv
  -- D1 = lambda * D2
  have hD1_eq_D2 : D1 = lambda * D2 := by linarith
  -- Now translate back to the goal statement
  -- D1 = -(-(y j))^(q-1) / (lqNorm q y)^(q-1)
  -- We have y j = p_star j - f j, so -(y j) = f j - p_star j
  -- Goal: (f j - p_star j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
  --     = lambda * ((-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1))
  -- Note D1 = -((f j - p_star j))^(q-1) / (lqNorm q y)^(q-1)
  --      D2 = -(-(p_star j))^(q-1) / (lqNorm q p_star)^(q-1)
  -- So D1 = lambda * D2 means:
  --   -(f j - p_star j)^(q-1) / D₁norm = lambda * -(-(p_star j))^(q-1) / D₂norm
  -- Multiply both sides by -1:
  --   (f j - p_star j)^(q-1) / D₁norm = lambda * (-(p_star j))^(q-1) / D₂norm
  show (f j - p_star j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
      = lambda * ((-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1))
  have h_y_lq : lqNorm q y = lqNorm q (fun k => p_star k - f k) := rfl
  have h_neg_yj : -(y j) = f j - p_star j := by show -(p_star j - f j) = f j - p_star j; ring
  -- Rewrite D1 using -(y j) = f j - p_star j
  have hD1_rewrite : D1 = -((f j - p_star j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)) := by
    show -(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1) = _
    rw [h_neg_yj, h_y_lq]
    ring
  -- Rewrite D2
  have hD2_rewrite : D2 = -((-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) := by
    show -(-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1) = _
    ring
  rw [hD1_rewrite, hD2_rewrite] at hD1_eq_D2
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormBoundaryUpwardExpansion
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d) (delta : ℝ)
    (hd_nn : 0 ≤ delta) (hxj_zero : x j = 0) :
    lqNorm q (Function.update x j delta)
      = ((lqNorm q x) ^ q + delta ^ q) ^ ((1 : ℝ) / q) := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hsum_nn : (0 : ℝ) ≤ ∑ k, |x k| ^ q := sum_abs_rpow_nonneg q x
  -- Step 1: Compute (lqNorm q x)^q = ∑ k, |x k|^q
  have h_pow_lqNorm : (lqNorm q x) ^ q = ∑ k, |x k| ^ q := by
    show ((∑ k, |x k| ^ q) ^ ((1 : ℝ) / q)) ^ q = ∑ k, |x k| ^ q
    rw [← Real.rpow_mul hsum_nn, one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one]
  -- Step 2: Split the sum over Function.update using Finset.sum_update_of_mem
  have h_update_sum :
      (∑ k, |Function.update x j delta k| ^ q) = delta ^ q + ∑ k ∈ Finset.univ \ {j}, |x k| ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h_eq : (fun k => |Function.update x j delta k| ^ q) =
                Function.update (fun k => |x k| ^ q) j (|delta| ^ q) := by
      funext k
      by_cases hk : k = j
      · subst hk
        simp [Function.update_self]
      · rw [Function.update_of_ne hk, Function.update_of_ne hk]
    rw [show (∑ k, |Function.update x j delta k| ^ q) =
            ∑ k, Function.update (fun k => |x k| ^ q) j (|delta| ^ q) k from by rw [h_eq]]
    rw [Finset.sum_update_of_mem hj_mem]
    rw [abs_of_nonneg hd_nn]
  -- Step 3: ∑ k, |x k|^q = ∑ k ∈ univ \ {j}, |x k|^q (since |x j|^q = 0)
  have h_x_sum : (∑ k, |x k| ^ q) = ∑ k ∈ Finset.univ \ {j}, |x k| ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    rw [← Finset.sum_erase_add _ _ hj_mem]
    rw [hxj_zero, abs_zero, Real.zero_rpow hq_ne, add_zero]
    congr 1
    ext k
    simp [Finset.mem_erase, Finset.mem_sdiff, Finset.mem_singleton, and_comm]
  -- Step 4: combine
  have h_main_sum :
      (∑ k, |Function.update x j delta k| ^ q) = (∑ k, |x k| ^ q) + delta ^ q := by
    rw [h_update_sum, h_x_sum, add_comm]
  -- Step 5: Use h_main_sum and h_pow_lqNorm to rewrite the goal
  show ((∑ k, |Function.update x j delta k| ^ q) ^ ((1 : ℝ) / q))
        = ((lqNorm q x) ^ q + delta ^ q) ^ ((1 : ℝ) / q)
  rw [h_main_sum, h_pow_lqNorm]

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormBoundaryRightDeriv
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d)
    (hx_nn : 0 ≤ x j) (hlq_pos : 0 < lqNorm q x) :
    HasDerivWithinAt (fun t : ℝ => lqNorm q (Function.update x j t))
      ((x j) ^ (q - 1) / (lqNorm q x) ^ (q - 1)) (Set.Ici (x j)) (x j) := by
  -- Useful basic facts about q.
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_one_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hq1_pos : 0 < q - 1 := sub_pos.mpr hq
  have hq1_nonneg : (0 : ℝ) ≤ q - 1 := le_of_lt hq1_pos
  have hq1_ne : q - 1 ≠ 0 := ne_of_gt hq1_pos
  have hlq_nn : 0 ≤ lqNorm q x := le_of_lt hlq_pos
  have hlq_ne : lqNorm q x ≠ 0 := ne_of_gt hlq_pos
  -- Split on x j > 0 vs x j = 0.
  rcases lt_or_eq_of_le hx_nn with hxj_pos | hxj_zero_eq
  · -- Case x j > 0: use LqNormPartialDerivative_PosBranch.
    have h := LqNormPartialDerivative_PosBranch hq hd x j hxj_pos hlq_pos
    exact h.hasDerivWithinAt
  · -- Case 0 = x j (so x j = 0).
    have hxj0 : x j = 0 := hxj_zero_eq.symm
    -- The target derivative is 0:
    have htarget : (x j) ^ (q - 1) / (lqNorm q x) ^ (q - 1) = 0 := by
      rw [hxj0, Real.zero_rpow hq1_ne, zero_div]
    rw [htarget, hxj0]
    -- We want HasDerivWithinAt (fun t => lqNorm q (update x j t)) 0 (Set.Ici 0) 0.
    -- Define g(t) := ((lqNorm q x)^q + t^q)^(1/q). By LqNormBoundaryUpwardExpansion,
    -- on Ici 0 we have lqNorm q (update x j t) = g(t).
    set L : ℝ := lqNorm q x with hL_def
    -- L^q > 0, so the inner sum L^q + t^q > 0 for t ≥ 0.
    have hLq_pos : 0 < L ^ q := Real.rpow_pos_of_pos hlq_pos q
    have hLq_ne : L ^ q ≠ 0 := ne_of_gt hLq_pos
    -- Step A: HasDerivAt (fun t => L^q + t^q) (q * 0^(q-1)) 0.
    have h_pow_q : HasDerivAt (fun t : ℝ => t ^ q) (q * (0 : ℝ) ^ (q - 1)) 0 :=
      Real.hasDerivAt_rpow_const (Or.inr hq_one_le)
    have h_inner : HasDerivAt (fun t : ℝ => L ^ q + t ^ q) (q * (0 : ℝ) ^ (q - 1)) 0 := by
      have := h_pow_q.const_add (L ^ q)
      simpa using this
    -- Step B: simplify (q * 0^(q-1)) = 0
    have h_inner_deriv_zero : q * (0 : ℝ) ^ (q - 1) = 0 := by
      rw [Real.zero_rpow hq1_ne, mul_zero]
    rw [h_inner_deriv_zero] at h_inner
    -- Step C: Apply rpow_const at p = 1/q with f(0) = L^q ≠ 0.
    have h_outer : HasDerivAt (fun t : ℝ => (L ^ q + t ^ q) ^ ((1 : ℝ) / q))
        (0 * (1 / q) * (L ^ q + (0 : ℝ) ^ q) ^ ((1 : ℝ) / q - 1)) 0 := by
      have hbase : (fun t : ℝ => L ^ q + t ^ q) 0 ≠ 0 := by
        show L ^ q + (0 : ℝ) ^ q ≠ 0
        rw [Real.zero_rpow hq_ne, add_zero]
        exact hLq_ne
      exact h_inner.rpow_const (Or.inl hbase)
    -- Step D: simplify the derivative value to 0.
    have h_outer_deriv_zero :
        (0 : ℝ) * (1 / q) * (L ^ q + (0 : ℝ) ^ q) ^ ((1 : ℝ) / q - 1) = 0 := by
      ring
    rw [h_outer_deriv_zero] at h_outer
    -- Step E: Lift to HasDerivWithinAt on Ici 0.
    have h_outer_within : HasDerivWithinAt
        (fun t : ℝ => (L ^ q + t ^ q) ^ ((1 : ℝ) / q))
        0 (Set.Ici (0 : ℝ)) 0 := h_outer.hasDerivWithinAt
    -- Step F: Show eventually-equal in nhdsWithin 0 (Ici 0):
    -- For t ≥ 0, lqNorm q (update x j t) = (L^q + t^q)^(1/q).
    have h_eq_on : ∀ t ∈ Set.Ici (0 : ℝ),
        lqNorm q (Function.update x j t) = (L ^ q + t ^ q) ^ ((1 : ℝ) / q) := by
      intro t ht
      have ht_nn : 0 ≤ t := ht
      exact LqNormBoundaryUpwardExpansion hq hd x j t ht_nn hxj0
    -- Use HasDerivWithinAt.congr to switch from g to lqNorm.
    -- HasDerivWithinAt.congr : HasDerivWithinAt f f' s x → (∀ x ∈ s, f₁ x = f x) → f₁ x = f x → HasDerivWithinAt f₁ s x
    refine h_outer_within.congr ?_ ?_
    · intros t ht
      exact h_eq_on t ht
    · -- f₁ 0 = f 0 where f₁ = lqNorm composition, f = (L^q + t^q)^(1/q)
      exact h_eq_on 0 Set.self_mem_Ici

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem RightBoundary_ForcesC0
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (hp_pos : 0 < lqNorm q p_star)
    (j : Fin d) (hsig : sigma j = 1) (hpf_eq : p_star j = f j) (hfj_pos : 0 < f j) :
    lqNorm q (fun k => p_star k - f k) = 0 := by
  -- The proof strategy: we derive False from the hypotheses.
  -- We compute the right-derivative of t ↦ g_lambda q lambda f (Function.update p_star j t)
  -- on Ici (p_star j) at t = p_star j. It is strictly negative, contradicting
  -- the local-min hypothesis.
  exfalso
  -- Useful basic facts.
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq1_pos : 0 < q - 1 := sub_pos.mpr hq
  have hq1_ne : q - 1 ≠ 0 := ne_of_gt hq1_pos
  have hpj_pos : 0 < p_star j := by rw [hpf_eq]; exact hfj_pos
  have hpj_nn : 0 ≤ p_star j := le_of_lt hpj_pos
  -- Notation: pmf = p_star - f.
  set pmf : Fin d → ℝ := fun k => p_star k - f k with hpmf_def
  have hpmf_j_zero : pmf j = 0 := by
    simp [hpmf_def, hpf_eq]
  have hpmf_pos : 0 < lqNorm q pmf := hpf_pos
  have hpmf_nn : 0 ≤ lqNorm q pmf := le_of_lt hpmf_pos
  have hpmf_ne : lqNorm q pmf ≠ 0 := ne_of_gt hpmf_pos
  -- ============================================================
  -- Step 1: Compute right derivative of (t ↦ lqNorm q (update p_star j t - f))
  -- at t = p_star j on Ici (p_star j). Equals 0.
  -- ============================================================
  -- Use LqNormBoundaryRightDeriv on pmf at index j.
  -- That gives derivative on Ici (pmf j) = Ici 0 of t ↦ lqNorm q (update pmf j t).
  have hH : HasDerivWithinAt
      (fun s : ℝ => lqNorm q (Function.update pmf j s))
      ((pmf j) ^ (q - 1) / (lqNorm q pmf) ^ (q - 1))
      (Set.Ici (pmf j)) (pmf j) :=
    LqNormBoundaryRightDeriv hq hd pmf j (le_of_eq hpmf_j_zero.symm) hpmf_pos
  -- The derivative simplifies to 0 since pmf j = 0.
  have hH_zero : HasDerivWithinAt
      (fun s : ℝ => lqNorm q (Function.update pmf j s))
      0 (Set.Ici (0 : ℝ)) 0 := by
    have hcoef : (pmf j) ^ (q - 1) / (lqNorm q pmf) ^ (q - 1) = 0 := by
      rw [hpmf_j_zero, Real.zero_rpow hq1_ne, zero_div]
    rw [hcoef] at hH
    rw [hpmf_j_zero] at hH
    exact hH
  -- Now translate from `s` to `t = s + p_star j`, i.e. `s = t - p_star j`.
  -- The function `t ↦ lqNorm q (update p_star j t - f)` equals
  -- `t ↦ lqNorm q (update pmf j (t - p_star j))` pointwise.
  have h_update_eq : ∀ t : ℝ,
      (fun k => Function.update p_star j t k - f k) = Function.update pmf j (t - p_star j) := by
    intro t
    funext k
    by_cases hk : k = j
    · subst hk
      simp [Function.update_self, hpmf_def, hpf_eq]
    · simp [Function.update_of_ne hk, hpmf_def]
  -- Compose with the affine map `t ↦ t - p_star j` to obtain HasDerivWithinAt on Ici (p_star j).
  have h_inner : HasDerivAt (fun t : ℝ => t - p_star j) 1 (p_star j) := by
    have := (hasDerivAt_id (p_star j)).sub_const (p_star j)
    simpa using this
  -- MapsTo: t ∈ Ici (p_star j) → t - p_star j ∈ Ici 0
  have h_maps : Set.MapsTo (fun t : ℝ => t - p_star j) (Set.Ici (p_star j)) (Set.Ici (0 : ℝ)) := by
    intro t ht
    simp only [Set.mem_Ici] at ht ⊢
    linarith
  have h_inner_within : HasDerivWithinAt (fun t : ℝ => t - p_star j) 1
      (Set.Ici (p_star j)) (p_star j) := h_inner.hasDerivWithinAt
  have h_comp_at_zero : (fun t : ℝ => t - p_star j) (p_star j) = 0 := by ring
  have hG_pre : HasDerivWithinAt
      (fun t : ℝ => lqNorm q (Function.update pmf j (t - p_star j)))
      (1 * 0) (Set.Ici (p_star j)) (p_star j) := by
    have hH_at : HasDerivWithinAt
        (fun s : ℝ => lqNorm q (Function.update pmf j s))
        0 (Set.Ici (0 : ℝ)) ((fun t : ℝ => t - p_star j) (p_star j)) := by
      rw [h_comp_at_zero]
      exact hH_zero
    have := HasDerivWithinAt.scomp (x := p_star j)
      (g₁ := fun s : ℝ => lqNorm q (Function.update pmf j s))
      (h := fun t : ℝ => t - p_star j)
      (g₁' := (0 : ℝ)) (h' := (1 : ℝ))
      (t' := Set.Ici (0 : ℝ)) (s := Set.Ici (p_star j))
      hH_at h_inner_within h_maps
    -- this : HasDerivWithinAt (g₁ ∘ h) (h' • g₁') s x
    -- which is: HasDerivWithinAt (fun t => lqNorm q (update pmf j (t - p_star j))) (1 • 0) (Ici (p_star j)) (p_star j)
    convert this using 1
  have hG : HasDerivWithinAt
      (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
      0 (Set.Ici (p_star j)) (p_star j) := by
    have h_eq_fun : (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
        = fun t : ℝ => lqNorm q (Function.update pmf j (t - p_star j)) := by
      funext t
      rw [h_update_eq t]
    rw [h_eq_fun]
    have : (1 : ℝ) * 0 = 0 := by ring
    rw [← this]
    exact hG_pre
  -- ============================================================
  -- Step 2: Compute derivative of (t ↦ lqNorm q (update p_star j t)) at t = p_star j.
  -- Equals (p_star j)^(q-1) / (lqNorm q p_star)^(q-1) > 0.
  -- ============================================================
  have hP : HasDerivAt
      (fun t : ℝ => lqNorm q (Function.update p_star j t))
      ((p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1))
      (p_star j) :=
    LqNormPartialDerivative_PosBranch hq hd p_star j hpj_pos hp_pos
  set deriv_p : ℝ := (p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1) with hdp_def
  have hdp_pos : 0 < deriv_p := by
    rw [hdp_def]
    apply div_pos
    · exact Real.rpow_pos_of_pos hpj_pos _
    · exact Real.rpow_pos_of_pos hp_pos _
  -- Lift hP to HasDerivWithinAt on Ici (p_star j).
  have hP_within : HasDerivWithinAt
      (fun t : ℝ => lqNorm q (Function.update p_star j t))
      deriv_p (Set.Ici (p_star j)) (p_star j) := hP.hasDerivWithinAt
  -- ============================================================
  -- Step 3: Compute right derivative of g_lambda(update p_star j t) at p_star j.
  -- ============================================================
  -- g_lambda q lambda f p = lqNorm q (p - f) - lambda * lqNorm q p
  -- Right deriv = (deriv of first) - lambda * (deriv of second) = 0 - lambda * deriv_p
  -- = -lambda * deriv_p < 0.
  have hP_within_smul : HasDerivWithinAt
      (fun t : ℝ => lambda * lqNorm q (Function.update p_star j t))
      (lambda * deriv_p) (Set.Ici (p_star j)) (p_star j) :=
    hP_within.const_mul lambda
  have hG_total : HasDerivWithinAt
      (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t))
      (0 - lambda * deriv_p) (Set.Ici (p_star j)) (p_star j) := by
    -- g_lambda q lambda f (update p_star j t) = lqNorm q (update p_star j t - f) - lambda * lqNorm q (update p_star j t)
    have h_eq : (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t))
        = fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k)
                      - lambda * lqNorm q (Function.update p_star j t) := by
      funext t
      simp [g_lambda]
    rw [h_eq]
    exact hG.sub hP_within_smul
  -- The derivative is strictly negative.
  set D : ℝ := 0 - lambda * deriv_p with hD_def
  have hD_neg : D < 0 := by
    rw [hD_def, zero_sub]
    apply neg_neg_iff_pos.mpr
    exact mul_pos hlam0 hdp_pos
  -- ============================================================
  -- Step 4: Use HasDerivWithinAt.liminf_right_slope_le to find a point z > p_star j
  -- arbitrarily close, with slope < 0.
  -- ============================================================
  have h_freq : ∃ᶠ z in (nhdsWithin (p_star j) (Set.Ioi (p_star j))),
      slope (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) z < 0 :=
    hG_total.liminf_right_slope_le hD_neg
  -- ============================================================
  -- Step 5: Pull a specific z out of the frequently filter.
  -- The local-min radius gives ε > 0.
  -- ============================================================
  obtain ⟨ε, hε_pos, hε_loc⟩ := hp_loc
  -- We want z ∈ (p_star j, p_star j + ε), with slope < 0.
  -- Build a neighborhood: (p_star j, p_star j + ε) is a punctured-right neighborhood.
  have h_nbhd : Set.Ioo (p_star j) (p_star j + ε) ∈ (nhdsWithin (p_star j) (Set.Ioi (p_star j))) := by
    rw [mem_nhdsWithin]
    refine ⟨Set.Iio (p_star j + ε), isOpen_Iio, ?_, ?_⟩
    · show p_star j < p_star j + ε
      linarith
    · intro x hx
      simp only [Set.mem_inter_iff, Set.mem_Iio, Set.mem_Ioi, Set.mem_Ioo] at hx ⊢
      exact ⟨hx.2, hx.1⟩
  -- Combine the frequently-witness with the neighborhood.
  have h_freq_strong : ∃ᶠ z in (nhdsWithin (p_star j) (Set.Ioi (p_star j))),
      z ∈ Set.Ioo (p_star j) (p_star j + ε) ∧
      slope (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) z < 0 :=
    (Filter.eventually_of_mem h_nbhd (fun _ h => h)).and_frequently h_freq
  -- Extract one such z.
  obtain ⟨z, ⟨hz_lo, hz_hi⟩, h_slope⟩ := h_freq_strong.exists
  have hz_gt : p_star j < z := hz_lo
  have hz_close : z < p_star j + ε := hz_hi
  -- ============================================================
  -- Step 6: Show update_p_star_j_z is in the orthant and within ε.
  -- ============================================================
  set tildep : Fin d → ℝ := Function.update p_star j z with htildep_def
  have htildep_at_j : tildep j = z := by simp [htildep_def, Function.update_self]
  have htildep_off_j : ∀ k : Fin d, k ≠ j → tildep k = p_star k := by
    intro k hk
    simp [htildep_def, Function.update_of_ne hk]
  have hz_pos : 0 < z := lt_trans hpj_pos hz_gt
  have hz_nn : 0 ≤ z := le_of_lt hz_pos
  -- tildep is in the orthant.
  have htildep_in : ∀ k, (sigma k = 1 → 0 ≤ tildep k) ∧ (sigma k = -1 → tildep k ≤ 0) := by
    intro k
    by_cases hk : k = j
    · subst hk
      refine ⟨fun _ => ?_, fun hsig_neg => ?_⟩
      · rw [htildep_at_j]; exact hz_nn
      · exfalso; rw [hsig] at hsig_neg; linarith
    · rw [htildep_off_j k hk]
      exact hp_in k
  -- |tildep k - p_star k| < ε for all k.
  have htildep_close : ∀ k, |tildep k - p_star k| < ε := by
    intro k
    by_cases hk : k = j
    · subst hk
      rw [htildep_at_j]
      have hzk_pos : 0 < z - p_star k := by linarith
      rw [abs_of_pos hzk_pos]
      linarith
    · rw [htildep_off_j k hk]
      have : p_star k - p_star k = 0 := by ring
      rw [this, abs_zero]
      exact hε_pos
  -- ============================================================
  -- Step 7: From local-min hypothesis: g_lambda(p_star) ≤ g_lambda(tildep).
  -- ============================================================
  have hg_le : g_lambda q lambda f p_star ≤ g_lambda q lambda f tildep :=
    hε_loc tildep htildep_in htildep_close
  -- Note: tildep = update p_star j z, and at j: p_star = update p_star j (p_star j).
  -- So slope (fun t => g_lambda(update p_star j t)) (p_star j) z =
  --        (g_lambda(update p_star j z) - g_lambda(update p_star j (p_star j))) / (z - p_star j)
  --      = (g_lambda(tildep) - g_lambda(p_star)) / (z - p_star j) ≥ 0
  -- This contradicts slope < 0.
  have h_update_pstar : Function.update p_star j (p_star j) = p_star := by
    funext k
    by_cases hk : k = j
    · subst hk; simp [Function.update_self]
    · simp [Function.update_of_ne hk]
  have h_slope_eq :
      slope (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) z
        = (z - p_star j)⁻¹ * (g_lambda q lambda f tildep - g_lambda q lambda f p_star) := by
    unfold slope
    simp only [vsub_eq_sub, smul_eq_mul]
    rw [h_update_pstar]
  rw [h_slope_eq] at h_slope
  have hz_diff_pos : 0 < z - p_star j := by linarith
  have hz_inv_pos : 0 < (z - p_star j)⁻¹ := inv_pos.mpr hz_diff_pos
  have h_sub_nn : 0 ≤ g_lambda q lambda f tildep - g_lambda q lambda f p_star := by linarith
  have h_prod_nn : 0 ≤ (z - p_star j)⁻¹ * (g_lambda q lambda f tildep - g_lambda q lambda f p_star) :=
    mul_nonneg (le_of_lt hz_inv_pos) h_sub_nn
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormPartialDerivative_PosBranch_LimitAtZero
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x f : Fin d → ℝ) (j : Fin d)
    (hxj_zero : x j = 0) (hfj_pos : 0 < f j) (hf_nn : ∀ k, 0 ≤ f k)
    (hlq_pos : 0 < lqNorm q (fun k => x k - f k)) :
    HasDerivWithinAt
      (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k))
      (-(f j) ^ (q - 1) / (lqNorm q (fun k => x k - f k)) ^ (q - 1))
      (Set.Ici (0 : ℝ)) 0 := by
  -- Setup basic facts
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hfj_ne : f j ≠ 0 := ne_of_gt hfj_pos
  have h_lqq_ne : lqNorm q (fun k => x k - f k) ≠ 0 := ne_of_gt hlq_pos
  have h_lqq_nonneg : 0 ≤ lqNorm q (fun k => x k - f k) := le_of_lt hlq_pos
  -- Define the constant part A = ∑_{k≠j} |x k - f k|^q
  set A : ℝ := ∑ k ∈ Finset.univ.erase j, |x k - f k| ^ q with hA_def
  -- The total sum equals A + (f j)^q (using x j = 0 and f j > 0, so |x j - f j| = |-f j| = f j)
  have h_total_sum : (∑ k, |x k - f k| ^ q) = A + (f j) ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h1 : (∑ k, |x k - f k| ^ q) = ∑ k ∈ Finset.univ.erase j, |x k - f k| ^ q
                + |x j - f j| ^ q := by
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
            (fun k => |x k - f k| ^ q) hj_mem]
    rw [h1, hxj_zero, zero_sub, abs_neg, abs_of_pos hfj_pos]
  -- (lqNorm q (x - f))^q = A + (f j)^q
  have h_lqNorm_q_eq : (lqNorm q (fun k => x k - f k)) ^ q = ∑ k, |x k - f k| ^ q := by
    unfold lqNorm
    rw [← Real.rpow_mul (sum_abs_rpow_nonneg q _), one_div_mul_cancel hq_ne, Real.rpow_one]
  have h_inner_eq : A + (f j) ^ q = (lqNorm q (fun k => x k - f k)) ^ q := by
    rw [← h_total_sum, ← h_lqNorm_q_eq]
  have h_inner_pos : 0 < A + (f j) ^ q := by
    rw [h_inner_eq]
    exact Real.rpow_pos_of_pos hlq_pos q
  have h_inner_ne : A + (f j) ^ q ≠ 0 := ne_of_gt h_inner_pos
  -- Local equality on a nhdsWithin (Set.Ici 0) 0:
  -- for t ∈ [0, f j), the lqNorm equals (A + (f j - t)^q)^(1/q)
  have h_eq_local :
      (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k)) =ᶠ[nhdsWithin 0 (Set.Ici (0 : ℝ))]
      (fun t : ℝ => (A + (f j - t) ^ q) ^ ((1 : ℝ) / q)) := by
    -- We use the characterization: ∀ᶠ in nhdsWithin a s ↔ ∀ᶠ in nhds a, x ∈ s → p x.
    rw [Filter.eventuallyEq_iff_exists_mem]
    refine ⟨Set.Iio (f j), ?_, ?_⟩
    · -- Set.Iio (f j) ∈ nhdsWithin 0 (Set.Ici 0): just need it to be in nhds 0.
      apply mem_nhdsWithin_of_mem_nhds
      exact Iio_mem_nhds hfj_pos
    · -- For t ∈ Iio (f j), the equality holds.
      intro t ht_lt
      have ht_lt' : t < f j := ht_lt
      show lqNorm q (fun k => Function.update x j t k - f k)
        = (A + (f j - t) ^ q) ^ ((1 : ℝ) / q)
      unfold lqNorm
      congr 1
      have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
            (fun k => |Function.update x j t k - f k| ^ q) hj_mem]
      rw [Function.update_self]
      -- Now |t - f j|^q = (f j - t)^q since t - f j < 0
      have h_neg : t - f j < 0 := by linarith
      have h_abs : |t - f j| = f j - t := by
        rw [abs_of_neg h_neg]; ring
      rw [h_abs]
      -- Sum over k ≠ j is unchanged because Function.update at k ≠ j equals x k.
      have h_sum_eq : (∑ k ∈ Finset.univ.erase j,
            |Function.update x j t k - f k| ^ q) = A := by
        apply Finset.sum_congr rfl
        intro k hk
        have hkj : k ≠ j := Finset.ne_of_mem_erase hk
        rw [Function.update_of_ne hkj]
      rw [h_sum_eq]
  -- Compute derivative at 0 of t ↦ A + (f j - t)^q within Set.Ici 0
  -- Step 1: HasDerivAt of t ↦ f j - t at 0 with derivative -1
  have h_sub : HasDerivAt (fun t : ℝ => f j - t) (-1) 0 := by
    have h1 : HasDerivAt (fun t : ℝ => t) 1 0 := hasDerivAt_id 0
    exact h1.const_sub (f j)
  -- Step 2: HasDerivAt of t ↦ (f j - t)^q at 0
  -- Apply rpow_const: HasDerivAt.rpow_const requires h_sub.x ≠ 0 ∨ 1 ≤ q. Since f j ≠ 0 (h_sub at 0 is f j - 0 = f j).
  have h_sub_at_zero : (fun t : ℝ => f j - t) 0 = f j := by simp
  have h_pow : HasDerivAt (fun t : ℝ => (f j - t) ^ q)
      (-1 * q * (f j) ^ (q - 1)) 0 := by
    have h_ne0 : (fun t : ℝ => f j - t) 0 ≠ 0 := by simp [hfj_ne]
    have h := HasDerivAt.rpow_const (p := q) h_sub (Or.inl h_ne0)
    -- h : HasDerivAt (fun y => (f j - y)^q) (-1 * q * (f j - 0)^(q-1)) 0
    have h_simp : (f j - (0 : ℝ)) = f j := by ring
    rw [h_simp] at h
    exact h
  -- Step 3: HasDerivAt of t ↦ A + (f j - t)^q at 0
  have h_A_add : HasDerivAt (fun t : ℝ => A + (f j - t) ^ q)
      (-1 * q * (f j) ^ (q - 1)) 0 := by
    have := h_pow.const_add A
    simpa using this
  -- Step 4: HasDerivAt of t ↦ (A + (f j - t)^q)^(1/q) at 0
  have h_outer : HasDerivAt (fun t : ℝ => (A + (f j - t) ^ q) ^ ((1 : ℝ) / q))
      (-1 * q * (f j) ^ (q - 1) * ((1 : ℝ) / q) *
        (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q - 1)) 0 := by
    have h_at_zero : (fun t : ℝ => A + (f j - t) ^ q) 0 = A + (f j) ^ q := by
      simp
    have h_ne : (fun t : ℝ => A + (f j - t) ^ q) 0 ≠ 0 := by
      rw [h_at_zero]; exact h_inner_ne
    have h := HasDerivAt.rpow_const (p := (1 : ℝ) / q) h_A_add (Or.inl h_ne)
    convert h using 1
  -- Convert HasDerivAt to HasDerivWithinAt
  have h_outer_within : HasDerivWithinAt (fun t : ℝ => (A + (f j - t) ^ q) ^ ((1 : ℝ) / q))
      (-1 * q * (f j) ^ (q - 1) * ((1 : ℝ) / q) *
        (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q - 1)) (Set.Ici (0 : ℝ)) 0 :=
    h_outer.hasDerivWithinAt
  -- Use HasDerivWithinAt.congr_of_eventuallyEq:
  -- HasDerivWithinAt f f' s x → f₁ =ᶠ[nhdsWithin x s] f → f₁ x = f x → HasDerivWithinAt f₁ f' s x
  -- We have HasDerivWithinAt of rpow_form (=: f), and h_eq_local says lqNorm_form =ᶠ rpow_form.
  -- So passing h_eq_local makes lqNorm_form play the role of f₁, and we get HasDerivWithinAt lqNorm_form.
  have h_pointwise : (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k)) 0
      = (fun t : ℝ => (A + (f j - t) ^ q) ^ ((1 : ℝ) / q)) 0 := by
    -- At t = 0, Function.update x j 0 = x (since x j = 0).
    have h_upd : Function.update x j (0 : ℝ) = x := by
      ext k
      by_cases hk : k = j
      · subst hk; rw [Function.update_self, hxj_zero]
      · rw [Function.update_of_ne hk]
    show lqNorm q (fun k => Function.update x j 0 k - f k)
        = (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q)
    rw [show (fun k => Function.update x j 0 k - f k) = (fun k => x k - f k) by
          ext k; rw [h_upd]]
    -- now lqNorm q (x - f) = (A + (f j)^q)^(1/q)
    show lqNorm q (fun k => x k - f k) = (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q)
    have : (A + (f j - 0) ^ q) = (lqNorm q (fun k => x k - f k)) ^ q := by
      have : f j - 0 = f j := by ring
      rw [this, h_inner_eq]
    rw [this]
    -- Goal: lqNorm q (x - f) = ((lqNorm q (x - f))^q)^(1/q)
    rw [← Real.rpow_mul h_lqq_nonneg, mul_one_div, div_self hq_ne, Real.rpow_one]
  have h_target : HasDerivWithinAt (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k))
      (-1 * q * (f j) ^ (q - 1) * ((1 : ℝ) / q) *
        (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q - 1)) (Set.Ici (0 : ℝ)) 0 :=
    h_outer_within.congr_of_eventuallyEq h_eq_local h_pointwise
  -- Now show the derivative value matches the goal:
  -- -1 * q * (f j)^(q-1) * (1/q) * (A + (f j)^q)^(1/q - 1) = -(f j)^(q-1) / (lqNorm q (x - f))^(q-1)
  convert h_target using 1
  -- Goal: -(f j)^(q-1) / (lqNorm q (x - f))^(q-1)
  --     = -1 * q * (f j)^(q-1) * (1/q) * (A + (f j - 0)^q)^(1/q - 1)
  have h_fj0 : f j - 0 = f j := by ring
  rw [h_fj0]
  rw [h_inner_eq]
  -- Now: ... = -1 * q * (f j)^(q-1) * (1/q) * ((lqNorm q (x - f))^q)^(1/q - 1)
  -- Simplify: q * (1/q) = 1, so: -1 * (f j)^(q-1) * ((lqNorm q (x - f))^q)^(1/q - 1)
  have h_q_simp : (-1 : ℝ) * q * (f j) ^ (q - 1) * ((1 : ℝ) / q)
      = -((f j) ^ (q - 1)) := by
    field_simp
  -- Reorganize the RHS
  have h_pow_simp : ((lqNorm q (fun k => x k - f k)) ^ q) ^ ((1 : ℝ) / q - 1)
      = (lqNorm q (fun k => x k - f k)) ^ (1 - q) := by
    rw [← Real.rpow_mul h_lqq_nonneg]
    congr 1
    field_simp
  have h_neg_pow : (lqNorm q (fun k => x k - f k)) ^ (1 - q)
      = ((lqNorm q (fun k => x k - f k)) ^ (q - 1))⁻¹ := by
    have heq : (1 - q) = -(q - 1) := by ring
    rw [heq, Real.rpow_neg h_lqq_nonneg]
  -- Algebraic manipulation
  rw [show (-1 : ℝ) * q * (f j) ^ (q - 1) * ((1 : ℝ) / q) *
        ((lqNorm q (fun k => x k - f k)) ^ q) ^ ((1 : ℝ) / q - 1)
       = ((-1 : ℝ) * q * (f j) ^ (q - 1) * ((1 : ℝ) / q)) *
         ((lqNorm q (fun k => x k - f k)) ^ q) ^ ((1 : ℝ) / q - 1) by ring]
  rw [h_q_simp, h_pow_simp, h_neg_pow]
  -- Goal: -(f j)^(q-1) / (lqNorm q (x - f))^(q-1) = -((f j)^(q-1)) * ((lqNorm q (x - f))^(q-1))⁻¹
  rw [div_eq_mul_inv, neg_mul]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

/-- **Left boundary forces `f j = 0` (positive branch).**

Under the same hypotheses as `Claim1_RuleOutInterior`, with the
additional assumption that `lqNorm q (p_star - f) > 0`, every index `j`
with `σ j = +1` and `p_star j = 0` satisfies `f j = 0`.

Paper reference: Block 3, Step 3.6 (companion to `RightBoundary_ForcesC0`)
of Gravin & Jia, *Approximation guarantees of Median Mechanism in ℝ^d*,
arXiv:2502.08578v2. -/
theorem LeftBoundary_ForcesFjZero
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (j : Fin d) (hsig : sigma j = 1) (hpz : p_star j = 0) :
    f j = 0 := by
  classical
  -- Basic facts about q.
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq1_pos : 0 < q - 1 := sub_pos.mpr hq
  have hq1_nn : (0 : ℝ) ≤ q - 1 := le_of_lt hq1_pos
  -- f j is non-negative.
  have hfj_nn : 0 ≤ f j := hf_nn j
  -- Try to derive a contradiction from f j > 0.
  by_contra hfj_ne
  have hfj_pos : 0 < f j := lt_of_le_of_ne hfj_nn (Ne.symm hfj_ne)
  -- Extract the local-min ε from hp_loc.
  obtain ⟨ε, hε_pos, hε_loc⟩ := hp_loc
  -- Set up the abbreviation L = lqNorm q (p_star - f).
  set L : ℝ := lqNorm q (fun k => p_star k - f k) with hL_def
  have hL_pos : 0 < L := hpf_pos
  have hL_nn : 0 ≤ L := le_of_lt hL_pos
  have hL_ne : L ≠ 0 := ne_of_gt hL_pos
  -- The first-term derivative.
  have h_deriv_first :
      HasDerivWithinAt
        (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
        (-(f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1))
        (Set.Ici (0 : ℝ)) 0 :=
    LqNormPartialDerivative_PosBranch_LimitAtZero hq hd p_star f j hpz hfj_pos hf_nn hpf_pos
  -- Define D₁ as that derivative; show D₁ < 0.
  set D₁ : ℝ := -(f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1) with hD₁_def
  have hLpow_pos : 0 < L ^ (q - 1) := Real.rpow_pos_of_pos hL_pos _
  have hfjpow_pos : 0 < (f j) ^ (q - 1) := Real.rpow_pos_of_pos hfj_pos _
  have hD₁_neg : D₁ < 0 := by
    rw [hD₁_def]
    show -(f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1) < 0
    rw [show -(f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
          = -((f j) ^ (q - 1) / L ^ (q - 1)) by rw [hL_def]; ring]
    have hpos : 0 < (f j) ^ (q - 1) / L ^ (q - 1) := div_pos hfjpow_pos hLpow_pos
    linarith
  -- Use HasDerivWithinAt.liminf_right_slope_le with r = D₁/2 > D₁ to find a small z>0
  -- for which the slope is < D₁/2.
  -- First, set the function name explicitly.
  set F : ℝ → ℝ := fun t => lqNorm q (fun k => Function.update p_star j t k - f k) with hF_def
  have h_deriv_first' :
      HasDerivWithinAt F D₁ (Set.Ici (0 : ℝ)) 0 := h_deriv_first
  -- D₁/2 is strictly between D₁ and 0.
  have hD₁_half_lt_zero : D₁ / 2 < 0 := by linarith
  have hD₁_lt_half : D₁ < D₁ / 2 := by linarith
  -- Frequently in 𝓝[>] 0, slope F 0 z < D₁/2.
  have h_freq : ∃ᶠ z in nhdsWithin 0 (Set.Ioi (0 : ℝ)), slope F 0 z < D₁ / 2 :=
    h_deriv_first'.liminf_right_slope_le hD₁_lt_half
  -- We also need z to lie in the open interval where the local-min and t<ε hold:
  -- specifically z ∈ (0, ε) suffices.
  have h_in_nhds : Set.Ioo (0 : ℝ) ε ∈ nhdsWithin (0 : ℝ) (Set.Ioi 0) := by
    rw [mem_nhdsWithin]
    refine ⟨Set.Iio ε, isOpen_Iio, hε_pos, ?_⟩
    intro x hx
    refine ⟨hx.2, hx.1⟩
  -- Combine the frequently and the eventually-membership of (0, ε) to extract a witness.
  have h_witness : ∃ z ∈ Set.Ioo (0 : ℝ) ε, slope F 0 z < D₁ / 2 := by
    -- Filter.Frequently.exists from h_freq filtered by the eventually predicate.
    have := h_freq.and_eventually (Filter.Eventually.of_forall (p := fun z => True) (fun _ => trivial))
    have h_freq' : ∃ᶠ z in nhdsWithin 0 (Set.Ioi (0 : ℝ)),
        z ∈ Set.Ioo (0 : ℝ) ε ∧ slope F 0 z < D₁ / 2 := by
      have hev : ∀ᶠ z in nhdsWithin 0 (Set.Ioi (0 : ℝ)), z ∈ Set.Ioo (0 : ℝ) ε := h_in_nhds
      exact h_freq.and_eventually hev |>.mp (Filter.Eventually.of_forall (fun z hz => ⟨hz.2, hz.1⟩))
    rcases h_freq'.exists with ⟨z, hz⟩
    exact ⟨z, hz.1, hz.2⟩
  -- Unpack the witness.
  obtain ⟨z, hz_mem, hz_slope⟩ := h_witness
  obtain ⟨hz_pos, hz_lt_ε⟩ := hz_mem
  -- The slope is (F z - F 0) / z.
  have h_slope_eq : slope F 0 z = (F z - F 0) / z := by
    rw [slope_def_field]
    rw [sub_zero]
  rw [h_slope_eq] at hz_slope
  have hz_ne : z ≠ 0 := ne_of_gt hz_pos
  -- From slope < D₁/2 and z > 0: F z - F 0 < (D₁/2) * z.
  have h_F_diff_lt : F z - F 0 < (D₁ / 2) * z := by
    have := (div_lt_iff₀ hz_pos).mp hz_slope
    linarith
  -- Now compute: F 0 = lqNorm q (p_star - f) = L; F z = lqNorm q (update p_star j z - f).
  have hF0 : F 0 = L := by
    show lqNorm q (fun k => Function.update p_star j 0 k - f k) = L
    have h_upd : Function.update p_star j (0 : ℝ) = p_star := by
      ext k
      by_cases hk : k = j
      · subst hk; rw [Function.update_self, hpz]
      · rw [Function.update_of_ne hk]
    rw [show (fun k => Function.update p_star j 0 k - f k) = (fun k => p_star k - f k) by
          ext k; rw [h_upd]]
  -- Now we control the second term: lqNorm q (update p_star j z) ≥ lqNorm q p_star.
  -- Apply LqNormBoundaryUpwardExpansion with x := p_star, j, delta := z.
  have hz_nn : 0 ≤ z := le_of_lt hz_pos
  have h_expand : lqNorm q (Function.update p_star j z)
      = ((lqNorm q p_star) ^ q + z ^ q) ^ ((1 : ℝ) / q) :=
    LqNormBoundaryUpwardExpansion hq hd p_star j z hz_nn hpz
  -- Show lqNorm q (update p_star j z) ≥ lqNorm q p_star.
  have h_lq_pstar_nn : 0 ≤ lqNorm q p_star := lqNorm_nonneg' q p_star
  have h_lq_mono : lqNorm q p_star ≤ lqNorm q (Function.update p_star j z) := by
    rw [h_expand]
    have h_zq_nn : 0 ≤ z ^ q := Real.rpow_nonneg hz_nn q
    have h_lqq_nn : 0 ≤ (lqNorm q p_star) ^ q := Real.rpow_nonneg h_lq_pstar_nn q
    have h_le : (lqNorm q p_star) ^ q ≤ (lqNorm q p_star) ^ q + z ^ q := by linarith
    have h_inv_nn : (0 : ℝ) ≤ (1 : ℝ) / q := by positivity
    have h1 : ((lqNorm q p_star) ^ q) ^ ((1 : ℝ) / q)
        ≤ ((lqNorm q p_star) ^ q + z ^ q) ^ ((1 : ℝ) / q) :=
      Real.rpow_le_rpow h_lqq_nn h_le h_inv_nn
    have h2 : ((lqNorm q p_star) ^ q) ^ ((1 : ℝ) / q) = lqNorm q p_star := by
      rw [← Real.rpow_mul h_lq_pstar_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
    linarith [h2]
  -- Now use the local minimum: g_lambda p_star ≤ g_lambda (update p_star j z).
  -- Build the constraint hypothesis for hε_loc.
  have h_orth : ∀ k, (sigma k = 1 → 0 ≤ Function.update p_star j z k) ∧
                     (sigma k = -1 → Function.update p_star j z k ≤ 0) := by
    intro k
    refine ⟨?_, ?_⟩
    · intro hsk
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        exact hz_nn
      · rw [Function.update_of_ne hk]
        exact (hp_in k).1 hsk
    · intro hsk
      by_cases hk : k = j
      · subst hk
        -- sigma j = -1 contradicts hsig : sigma j = 1
        rw [hsig] at hsk; linarith
      · rw [Function.update_of_ne hk]
        exact (hp_in k).2 hsk
  -- ε-closeness condition.
  have h_close : ∀ k, |Function.update p_star j z k - p_star k| < ε := by
    intro k
    by_cases hk : k = j
    · subst hk
      rw [Function.update_self, hpz, sub_zero, abs_of_pos hz_pos]
      exact hz_lt_ε
    · rw [Function.update_of_ne hk, sub_self, abs_zero]
      exact hε_pos
  -- Apply the local-min property.
  have h_g_le := hε_loc (Function.update p_star j z) h_orth h_close
  -- Now we want to derive a contradiction.
  -- g_lambda f p_star = L - λ * lqNorm q p_star
  -- g_lambda f (update p_star j z) = F z - λ * lqNorm q (update p_star j z)
  -- h_g_le: L - λ*A ≤ F z - λ*B, where A = lqNorm q p_star, B = lqNorm q (update p_star j z).
  -- h_lq_mono: A ≤ B → -λ*B ≤ -λ*A → ... So we have F z ≥ L + λ*(B - A) ≥ L.
  -- But h_F_diff_lt: F z < L + (D₁/2) * z, with (D₁/2)*z < 0, so F z < L. Contradiction.
  have h_lambda_ineq : -lambda * lqNorm q (Function.update p_star j z) ≤
      -lambda * lqNorm q p_star := by
    have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
    have := mul_le_mul_of_nonneg_left h_lq_mono hlam_nn
    linarith
  -- Unfold g_lambda.
  have h_g_unfold : g_lambda q lambda f p_star ≤ g_lambda q lambda f (Function.update p_star j z) :=
    h_g_le
  -- Recall g_lambda q lambda f p = lqNorm q (p - f) - lambda * lqNorm q p
  have h_g_p_star : g_lambda q lambda f p_star = L - lambda * lqNorm q p_star := by
    show lqNorm q (fun k => p_star k - f k) - lambda * lqNorm q p_star = L - lambda * lqNorm q p_star
    rfl
  have h_g_update : g_lambda q lambda f (Function.update p_star j z)
      = F z - lambda * lqNorm q (Function.update p_star j z) := by
    show lqNorm q (fun k => Function.update p_star j z k - f k) - lambda * lqNorm q (Function.update p_star j z)
        = F z - lambda * lqNorm q (Function.update p_star j z)
    rfl
  rw [h_g_p_star, h_g_update] at h_g_unfold
  -- Now: L - λ * lqNorm q p_star ≤ F z - λ * lqNorm q (Function.update p_star j z)
  -- With h_lq_mono: λ * lqNorm q p_star ≤ λ * lqNorm q (Function.update p_star j z).
  have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
  have h_lq_lam_mono : lambda * lqNorm q p_star ≤ lambda * lqNorm q (Function.update p_star j z) :=
    mul_le_mul_of_nonneg_left h_lq_mono hlam_nn
  -- From h_g_unfold and h_lq_lam_mono: L ≤ F z + (λ * lqNorm q p_star - λ * lqNorm q (update))
  -- Wait, let's just rearrange.
  -- L - λ*A ≤ F z - λ*B
  -- L ≤ F z - λ*B + λ*A = F z - λ*(B - A) ≤ F z (since B ≥ A and λ > 0)
  have h_L_le_Fz : L ≤ F z := by
    have hsub : 0 ≤ lambda * lqNorm q (Function.update p_star j z) - lambda * lqNorm q p_star := by
      linarith
    linarith
  -- But h_F_diff_lt: F z - L < (D₁/2) * z, and (D₁/2) * z < 0 (since z > 0 and D₁/2 < 0).
  have hD₁_half_z_neg : (D₁ / 2) * z < 0 := by
    exact mul_neg_of_neg_of_pos hD₁_half_lt_zero hz_pos
  have h_Fz_lt_L : F z < L := by
    have : F z - L < 0 := by
      have := h_F_diff_lt
      rw [hF0] at this
      linarith
    linarith
  -- Contradiction.
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

/-- **Sign Incompatibility lemma.**

Under the same hypotheses as `Claim1_RuleOutInterior`, with
`lqNorm q (p_star - f) > 0` and `lqNorm q p_star > 0`, the following two
conditions cannot both hold simultaneously:

* (P) there exists `j` with `σ j = +1`, `p_star j ≥ f j`, and `f j > 0`;
* (N) there exists `i` with `σ i = -1`, `p_star i < 0`, and `f i > 0`.

Paper reference: `approx.tex` lines 103–106; Block 4, Steps 4.1–4.3
(Gravin & Jia, *Approximation guarantees of Median Mechanism in ℝ^d*,
arXiv:2502.08578v2). -/
theorem SignIncompatibility
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (hp_pos : 0 < lqNorm q p_star) :
    ¬ ((∃ j : Fin d, sigma j = 1 ∧ f j ≤ p_star j ∧ 0 < f j) ∧
       (∃ i : Fin d, sigma i = -1 ∧ p_star i < 0 ∧ 0 < f i)) := by
  -- Take the assumption and break it down
  intro ⟨⟨j, hsig_j, hfj_le, hfj_pos⟩, ⟨i, hsig_i, hpi_neg, hfi_pos⟩⟩
  -- Notation
  have hq1 : 0 < q - 1 := by linarith
  have hN_pos : 0 < lqNorm q (fun k => p_star k - f k) := hpf_pos
  have hM_pos : 0 < lqNorm q p_star := hp_pos
  have hNqm1_pos : 0 < (lqNorm q (fun k => p_star k - f k)) ^ (q - 1) :=
    Real.rpow_pos_of_pos hN_pos _
  have hMqm1_pos : 0 < (lqNorm q p_star) ^ (q - 1) :=
    Real.rpow_pos_of_pos hM_pos _
  have hNqm1_ne : (lqNorm q (fun k => p_star k - f k)) ^ (q - 1) ≠ 0 := ne_of_gt hNqm1_pos
  have hMqm1_ne : (lqNorm q p_star) ^ (q - 1) ≠ 0 := ne_of_gt hMqm1_pos
  -- p_star j ≥ 0 from orthant
  have hpj_nn : 0 ≤ p_star j := (hp_in j).1 hsig_j
  -- p_star j ≥ f j > 0
  have hpj_pos : 0 < p_star j := lt_of_lt_of_le hfj_pos hfj_le
  -- Case split on whether f j = p_star j or f j < p_star j
  rcases lt_or_eq_of_le hfj_le with hfj_lt | hfj_eq
  · -- Case A: f j < p_star j (interior)
    -- Apply InteriorFOC_Pos
    have h_pos := InteriorFOC_Pos q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
      sigma hsigma_pm p_star hp_in hp_loc hpf_pos hp_pos j hsig_j hfj_lt
    -- Apply InteriorFOC_Neg
    have h_neg := InteriorFOC_Neg q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
      sigma hsigma_pm p_star hp_in hp_loc hpf_pos hp_pos i hsig_i hpi_neg
    -- Positive branch: derive (p_star j - f j)^(q-1) / p_star j^(q-1) = lambda * N^(q-1) / M^(q-1)
    have hpfj_pos : 0 < p_star j - f j := sub_pos.mpr hfj_lt
    have hpj_qm1_pos : 0 < p_star j ^ (q - 1) := Real.rpow_pos_of_pos hpj_pos _
    have hpfj_qm1_pos : 0 < (p_star j - f j) ^ (q - 1) := Real.rpow_pos_of_pos hpfj_pos _
    have hpj_qm1_ne : p_star j ^ (q - 1) ≠ 0 := ne_of_gt hpj_qm1_pos
    have hpfj_qm1_ne : (p_star j - f j) ^ (q - 1) ≠ 0 := ne_of_gt hpfj_qm1_pos
    -- Negative branch positivities
    have hmpi_pos : 0 < -p_star i := neg_pos.mpr hpi_neg
    have h_diff_pos : 0 < f i - p_star i := by linarith
    have h_diff_gt : -p_star i < f i - p_star i := by linarith
    have hmpi_qm1_pos : 0 < (-p_star i) ^ (q - 1) := Real.rpow_pos_of_pos hmpi_pos _
    have h_diff_qm1_pos : 0 < (f i - p_star i) ^ (q - 1) := Real.rpow_pos_of_pos h_diff_pos _
    have hmpi_qm1_ne : (-p_star i) ^ (q - 1) ≠ 0 := ne_of_gt hmpi_qm1_pos
    -- Step 1: rewrite h_pos and h_neg as: ratio of differences = K
    -- where K = lambda * N^(q-1) / M^(q-1)
    -- From h_pos:
    --   (p_star j - f j)^(q-1) / N^(q-1) = lambda * (p_star j^(q-1) / M^(q-1))
    -- Multiply both sides by N^(q-1) / p_star j^(q-1):
    --   (p_star j - f j)^(q-1) / p_star j^(q-1) = lambda * N^(q-1) / M^(q-1)
    set N := lqNorm q (fun k => p_star k - f k)
    set M := lqNorm q p_star
    -- Make K explicit
    set K := lambda * N ^ (q - 1) / M ^ (q - 1) with hK_def
    have hK_pos : 0 < K := by rw [hK_def]; positivity
    -- Convert h_pos to (p_star j - f j)^(q-1) / p_star j^(q-1) = K
    have h_pos_K : (p_star j - f j) ^ (q - 1) / p_star j ^ (q - 1) = K := by
      have hN_ne : N ^ (q - 1) ≠ 0 := hNqm1_ne
      have hM_ne : M ^ (q - 1) ≠ 0 := hMqm1_ne
      rw [hK_def]
      field_simp
      have h := h_pos
      field_simp at h
      linarith
    -- Inequality: (p_star j - f j)^(q-1) / p_star j^(q-1) < 1
    have h_lt_one : (p_star j - f j) ^ (q - 1) / p_star j ^ (q - 1) < 1 := by
      rw [div_lt_one hpj_qm1_pos]
      apply Real.rpow_lt_rpow (le_of_lt hpfj_pos) _ hq1
      linarith
    have hK_lt_one : K < 1 := h_pos_K ▸ h_lt_one
    -- Convert h_neg to (f i - p_star i)^(q-1) / (-p_star i)^(q-1) = K
    have h_neg_K : (f i - p_star i) ^ (q - 1) / (-p_star i) ^ (q - 1) = K := by
      have hN_ne : N ^ (q - 1) ≠ 0 := hNqm1_ne
      have hM_ne : M ^ (q - 1) ≠ 0 := hMqm1_ne
      rw [hK_def]
      field_simp
      have h := h_neg
      field_simp at h
      linarith
    have h_gt_one : 1 < (f i - p_star i) ^ (q - 1) / (-p_star i) ^ (q - 1) := by
      rw [lt_div_iff₀ hmpi_qm1_pos, one_mul]
      apply Real.rpow_lt_rpow (le_of_lt hmpi_pos) h_diff_gt hq1
    have hK_gt_one : 1 < K := h_neg_K ▸ h_gt_one
    linarith
  · -- Case B: f j = p_star j, use RightBoundary_ForcesC0
    have h_eq : p_star j = f j := hfj_eq.symm
    have h_zero := RightBoundary_ForcesC0 q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
      sigma hsigma_pm p_star hp_in hp_loc hpf_pos hp_pos j hsig_j h_eq hfj_pos
    -- h_zero : lqNorm q (fun k => p_star k - f k) = 0
    -- Contradicts hpf_pos
    rw [h_zero] at hpf_pos
    exact lt_irrefl 0 hpf_pos

open Workspace.Types.LqNorm

theorem LqNormBoundaryFirstOrderRise
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d)
    (hxj_zero : x j = 0) (hlq_pos : 0 < lqNorm q x) :
    ∃ delta0 > (0 : ℝ), ∃ C > (0 : ℝ),
      ∀ delta ∈ Set.Ioo (0 : ℝ) delta0,
        lqNorm q (Function.update x j delta)
          ≤ lqNorm q x + C * delta ^ q := by
  -- Set up the basic constants and positivity facts.
  set M : ℝ := lqNorm q x with hM_def
  have hM_pos : 0 < M := hlq_pos
  have hM_nn : 0 ≤ M := le_of_lt hM_pos
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_nn : 0 ≤ q := le_of_lt hq_pos
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hinvq_pos : 0 < 1 / q := by positivity
  have hinvq_le_one : 1 / q ≤ 1 := by
    rw [div_le_one hq_pos]; exact le_of_lt hq
  have hinvq_nn : 0 ≤ 1 / q := le_of_lt hinvq_pos
  -- M^q > 0 and M^(q-1) > 0
  have hMq_pos : 0 < M ^ q := Real.rpow_pos_of_pos hM_pos q
  have hMq_nn : 0 ≤ M ^ q := le_of_lt hMq_pos
  have hMq_ne : M ^ q ≠ 0 := ne_of_gt hMq_pos
  have hMqm1_pos : 0 < M ^ (q - 1) := Real.rpow_pos_of_pos hM_pos (q - 1)
  have hMqm1_ne : M ^ (q - 1) ≠ 0 := ne_of_gt hMqm1_pos
  -- Useful identity: (M^q)^(1/q) = M
  have hMq_invq : (M ^ q) ^ ((1 : ℝ) / q) = M := by
    rw [← Real.rpow_mul hM_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  -- Useful: M^q = M^(q-1) * M
  have hMq_split : M ^ q = M ^ (q - 1) * M := by
    have : M ^ (q - 1) * M ^ (1 : ℝ) = M ^ ((q - 1) + 1) :=
      (Real.rpow_add hM_pos _ _).symm
    rw [Real.rpow_one] at this
    rw [this]
    ring_nf
  -- Choose C = 1 / (q * M^(q-1))
  refine ⟨1, by norm_num, 1 / (q * M ^ (q - 1)), ?_, ?_⟩
  · -- C > 0
    apply div_pos zero_lt_one
    exact mul_pos hq_pos hMqm1_pos
  · -- The main inequality, for all δ ∈ (0, 1)
    intro delta hdelta
    obtain ⟨hdelta_pos, hdelta_lt⟩ := hdelta
    have hdelta_nn : 0 ≤ delta := le_of_lt hdelta_pos
    have hdq_pos : 0 < delta ^ q := Real.rpow_pos_of_pos hdelta_pos q
    have hdq_nn : 0 ≤ delta ^ q := le_of_lt hdq_pos
    -- Use UpwardExpansion to rewrite the LHS.
    have hexp : lqNorm q (Function.update x j delta)
                  = (M ^ q + delta ^ q) ^ ((1 : ℝ) / q) :=
      LqNormBoundaryUpwardExpansion hq hd x j delta hdelta_nn hxj_zero
    rw [hexp]
    -- Factor (M^q + δ^q) = M^q * (1 + δ^q / M^q)
    have hfactor : M ^ q + delta ^ q = M ^ q * (1 + delta ^ q / M ^ q) := by
      field_simp
    rw [hfactor]
    -- (M^q * (1 + δ^q/M^q))^(1/q) = (M^q)^(1/q) * (1 + δ^q/M^q)^(1/q)
    have hsdef : delta ^ q / M ^ q ≥ 0 := div_nonneg hdq_nn hMq_nn
    have h1pos : (0 : ℝ) ≤ 1 + delta ^ q / M ^ q := by linarith
    rw [Real.mul_rpow hMq_nn h1pos]
    rw [hMq_invq]
    -- Apply Bernoulli-type bound: (1 + s)^(1/q) ≤ 1 + (1/q)*s for s ≥ -1
    set s : ℝ := delta ^ q / M ^ q with hs_def
    have hs_ge : -1 ≤ s := by
      have : (0 : ℝ) ≤ s := hsdef
      linarith
    have hbern : (1 + s) ^ ((1 : ℝ) / q) ≤ 1 + (1 / q) * s :=
      rpow_one_add_le_one_add_mul_self hs_ge hinvq_nn hinvq_le_one
    have hbound : M * (1 + s) ^ ((1 : ℝ) / q) ≤ M * (1 + (1 / q) * s) :=
      mul_le_mul_of_nonneg_left hbern hM_nn
    refine le_trans hbound ?_
    -- Now show M * (1 + (1/q) * s) ≤ M + (1/(q*M^(q-1))) * δ^q
    -- Actually equality holds.
    have hgoal : M * (1 + (1 / q) * s) = M + (1 / (q * M ^ (q - 1))) * delta ^ q := by
      show M * (1 + (1 / q) * (delta ^ q / M ^ q))
            = M + (1 / (q * M ^ (q - 1))) * delta ^ q
      rw [hMq_split]
      field_simp
    linarith

open scoped BigOperators
open Workspace.Types.LqNorm

theorem PerturbAtZero_StrictDescent
    {q : ℝ} (hq : 1 < q) {lambda : ℝ} (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_norm : lqNorm q f = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (hS_pos : ∃ k, sigma k = 1)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ tildep : Fin d → ℝ,
      (∀ j, (sigma j = 1 → 0 ≤ tildep j) ∧ (sigma j = -1 → tildep j ≤ 0)) ∧
      (∀ j, |tildep j| < ε) ∧
      lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep
        < lqNorm q (fun k => -(f k)) := by
  -- Basic positivity of q
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  -- Pick k with σ k = 1
  obtain ⟨k, hsigma_k⟩ := hS_pos
  -- lqNorm q (fun k => -(f k)) = lqNorm q f = 1
  have hlq_neg_f : lqNorm q (fun k => -(f k)) = lqNorm q f := by
    unfold lqNorm
    congr 1
    apply Finset.sum_congr rfl
    intro j _
    rw [abs_neg]
  have hlq_neg_f_eq_one : lqNorm q (fun k => -(f k)) = 1 := by
    rw [hlq_neg_f, hf_norm]
  -- A helper: lqNorm q (Function.update (fun _ => 0) k δ) = δ for δ ≥ 0
  have hnorm_update_zero : ∀ delta : ℝ, 0 ≤ delta →
      lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k delta) = delta := by
    intro delta hdelta_nn
    have h_zero_k : (fun _ : Fin d => (0 : ℝ)) k = 0 := rfl
    have hexp : lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k delta)
        = ((lqNorm q (fun _ : Fin d => (0 : ℝ))) ^ q + delta ^ q) ^ ((1 : ℝ) / q) :=
      LqNormBoundaryUpwardExpansion hq hd (fun _ : Fin d => (0 : ℝ)) k delta hdelta_nn h_zero_k
    rw [hexp, lqNorm_zero hq_le]
    rw [Real.zero_rpow hq_ne, zero_add]
    rw [← Real.rpow_mul hdelta_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  -- Case split on whether f k > 0 or f k = 0
  by_cases hfk_pos : 0 < f k
  · -- ============= Case 1: f k > 0 =============
    -- Pick δ := min(ε, f k) / 2
    set δ := min ε (f k) / 2 with hδ_def
    have hδ_pos : 0 < δ := by
      apply div_pos
      · exact lt_min hε hfk_pos
      · norm_num
    have hδ_lt_ε : δ < ε := by
      have h1 : δ ≤ min ε (f k) / 1 := by
        rw [div_one]; rw [hδ_def]; linarith [min_le_left ε (f k), min_le_right ε (f k)]
      have h2 : min ε (f k) ≤ ε := min_le_left _ _
      have : min ε (f k) / 2 < min ε (f k) := by
        have : min ε (f k) > 0 := lt_min hε hfk_pos
        linarith
      linarith
    have hδ_lt_fk : δ < f k := by
      have hmin : min ε (f k) ≤ f k := min_le_right _ _
      have hpos : 0 < min ε (f k) := lt_min hε hfk_pos
      linarith
    have hδ_nn : 0 ≤ δ := le_of_lt hδ_pos
    -- Define tildep
    refine ⟨Function.update (fun _ : Fin d => (0 : ℝ)) k δ, ?_, ?_, ?_⟩
    · -- Orthant condition
      intro j
      refine ⟨?_, ?_⟩
      · intro _
        by_cases hj : j = k
        · subst hj; rw [Function.update_self]; exact hδ_nn
        · rw [Function.update_of_ne hj]
      · intro hsj
        by_cases hj : j = k
        · subst hj
          -- sigma k = 1 and sigma k = -1 simultaneously is impossible
          rw [hsigma_k] at hsj; norm_num at hsj
        · rw [Function.update_of_ne hj]
    · -- |tildep j| < ε
      intro j
      by_cases hj : j = k
      · subst hj; rw [Function.update_self]; rw [abs_of_nonneg hδ_nn]; exact hδ_lt_ε
      · rw [Function.update_of_ne hj]; rw [abs_zero]; exact hε
    · -- Strict descent
      -- lqNorm q (tildep - f) < lqNorm q (-f) using LqNormStrictDecrease_OfSingleCoordinateCloser
      have h_strict_dec :
          lqNorm q (fun j => Function.update (fun _ : Fin d => (0 : ℝ)) k δ j - f j)
            < lqNorm q (fun j => (fun _ : Fin d => (0 : ℝ)) j - f j) := by
        apply LqNormStrictDecrease_OfSingleCoordinateCloser hq hd
            (fun _ : Fin d => (0 : ℝ)) (Function.update (fun _ : Fin d => (0 : ℝ)) k δ) f k
        · intro j hj
          rw [Function.update_of_ne hj]
        · -- |tildep k - f k| < |0 - f k|
          rw [Function.update_self]
          rw [zero_sub]
          rw [abs_neg, abs_of_nonneg (hf_nn k)]
          rw [abs_of_nonpos (by linarith : δ - f k ≤ 0)]
          linarith
      -- Rewrite (fun j => 0 - f j) = (fun j => -(f j))
      have h_zero_sub : (fun j : Fin d => (fun _ : Fin d => (0 : ℝ)) j - f j) =
                        (fun j : Fin d => -(f j)) := by
        funext j; rw [zero_sub]
      rw [h_zero_sub] at h_strict_dec
      -- lqNorm q tildep ≥ 0
      have hlq_tildep_nn : 0 ≤ lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k δ) :=
        lqNorm_nonneg hq_le _
      have h_lambda_norm_nn :
          0 ≤ lambda * lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k δ) :=
        mul_nonneg (le_of_lt hlam0) hlq_tildep_nn
      linarith
  · -- ============= Case 2: f k = 0 =============
    push_neg at hfk_pos
    have hfk_eq_zero : f k = 0 := le_antisymm hfk_pos (hf_nn k)
    -- Apply LqNormBoundaryFirstOrderRise to x = -f at coordinate k
    have h_neg_f_k_zero : (fun j => -(f j)) k = 0 := by simp [hfk_eq_zero]
    have hlq_neg_f_pos : 0 < lqNorm q (fun j => -(f j)) := by
      rw [hlq_neg_f_eq_one]; norm_num
    obtain ⟨delta0, hdelta0_pos, C, hC_pos, hbound⟩ :=
      LqNormBoundaryFirstOrderRise hq hd (fun j => -(f j)) k h_neg_f_k_zero hlq_neg_f_pos
    -- Now choose δ small enough:
    --   0 < δ < δ0, δ < ε, δ < (λ / (2C))^(1/(q-1))   (so C * δ^q < λ * δ)
    -- A simple bound: pick δ ≤ (λ / (2C)) for the last condition? Actually we need
    --   C * δ^q < λ * δ ⇔ δ^(q-1) < λ/C ⇔ δ < (λ/C)^(1/(q-1)).
    -- Let `bound1 := (lambda / (2 * C))^(1/(q-1))`.
    -- Pick δ := min(delta0, ε, bound1) / 2.
    have hqm1_pos : 0 < q - 1 := by linarith
    have hqm1_inv_pos : 0 < 1 / (q - 1) := by positivity
    have h_lambda_2C_pos : 0 < lambda / (2 * C) := div_pos hlam0 (by linarith)
    set bound1 : ℝ := (lambda / (2 * C)) ^ ((1 : ℝ) / (q - 1)) with hbound1_def
    have hbound1_pos : 0 < bound1 := by
      apply Real.rpow_pos_of_pos h_lambda_2C_pos
    set δ : ℝ := min (min delta0 ε) bound1 / 2 with hδ_def
    have h_min_pos : 0 < min (min delta0 ε) bound1 := by
      exact lt_min (lt_min hdelta0_pos hε) hbound1_pos
    have hδ_pos : 0 < δ := by rw [hδ_def]; positivity
    have hδ_nn : 0 ≤ δ := le_of_lt hδ_pos
    have hδ_lt_min : δ < min (min delta0 ε) bound1 := by
      rw [hδ_def]; linarith
    have hδ_lt_delta0 : δ < delta0 :=
      lt_of_lt_of_le hδ_lt_min (le_trans (min_le_left _ _) (min_le_left _ _))
    have hδ_lt_ε : δ < ε :=
      lt_of_lt_of_le hδ_lt_min (le_trans (min_le_left _ _) (min_le_right _ _))
    have hδ_lt_bound1 : δ < bound1 :=
      lt_of_lt_of_le hδ_lt_min (min_le_right _ _)
    -- Define tildep
    refine ⟨Function.update (fun _ : Fin d => (0 : ℝ)) k δ, ?_, ?_, ?_⟩
    · -- Orthant condition
      intro j
      refine ⟨?_, ?_⟩
      · intro _
        by_cases hj : j = k
        · subst hj; rw [Function.update_self]; exact hδ_nn
        · rw [Function.update_of_ne hj]
      · intro hsj
        by_cases hj : j = k
        · subst hj
          rw [hsigma_k] at hsj; norm_num at hsj
        · rw [Function.update_of_ne hj]
    · -- |tildep j| < ε
      intro j
      by_cases hj : j = k
      · subst hj; rw [Function.update_self]; rw [abs_of_nonneg hδ_nn]; exact hδ_lt_ε
      · rw [Function.update_of_ne hj]; rw [abs_zero]; exact hε
    · -- Strict descent via boundary first-order rise
      -- (1) Show that (tildep - f) = Function.update (-f) k δ
      have h_tildep_minus_f :
          (fun j => Function.update (fun _ : Fin d => (0 : ℝ)) k δ j - f j)
            = Function.update (fun j => -(f j)) k δ := by
        funext j
        by_cases hj : j = k
        · subst hj
          rw [Function.update_self, Function.update_self, hfk_eq_zero, sub_zero]
        · rw [Function.update_of_ne hj, Function.update_of_ne hj]
          rw [zero_sub]
      rw [h_tildep_minus_f]
      -- (2) From boundary first order rise:
      have hδ_in_Ioo : δ ∈ Set.Ioo (0 : ℝ) delta0 := ⟨hδ_pos, hδ_lt_delta0⟩
      have h_rise : lqNorm q (Function.update (fun j => -(f j)) k δ)
                      ≤ lqNorm q (fun j => -(f j)) + C * δ ^ q :=
        hbound δ hδ_in_Ioo
      -- (3) lqNorm q tildep = δ
      have hnorm_tildep :
          lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k δ) = δ :=
        hnorm_update_zero δ hδ_nn
      rw [hnorm_tildep]
      -- (4) Final inequality:
      --   lqNorm q (-f) + C * δ^q - λ * δ < lqNorm q (-f)
      -- iff C * δ^q < λ * δ
      -- We have δ < bound1 = (λ/(2C))^(1/(q-1)), so δ^(q-1) < λ/(2C),
      -- so C * δ^q = C * δ^(q-1) * δ < (λ/2) * δ < λ * δ.
      -- Step (a): δ^(q-1) < λ/(2C)
      have h_delta_qm1_lt : δ ^ (q - 1) < lambda / (2 * C) := by
        -- δ < (λ/(2C))^(1/(q-1)) ⇒ δ^(q-1) < λ/(2C)
        have h_eq : (bound1) ^ (q - 1) = lambda / (2 * C) := by
          rw [hbound1_def]
          rw [← Real.rpow_mul (le_of_lt h_lambda_2C_pos)]
          rw [div_mul_cancel₀ 1 (by linarith : q - 1 ≠ 0)]
          exact Real.rpow_one _
        have h_step : δ ^ (q - 1) < bound1 ^ (q - 1) :=
          Real.rpow_lt_rpow hδ_nn hδ_lt_bound1 hqm1_pos
        rw [h_eq] at h_step
        exact h_step
      -- Step (b): C * δ^q < (λ/2) * δ
      have hCpos : 0 < C := hC_pos
      -- C * δ^q = C * δ * δ^(q-1)  (since δ^q = δ^(q-1) * δ^1 = δ^(q-1) * δ)
      have h_split : δ ^ q = δ ^ (q - 1) * δ := by
        have h1 : δ ^ ((q - 1) + 1) = δ ^ (q - 1) * δ ^ (1 : ℝ) :=
          Real.rpow_add hδ_pos _ _
        rw [Real.rpow_one] at h1
        have h_qm1_p1 : (q - 1) + 1 = q := by ring
        rw [h_qm1_p1] at h1
        exact h1
      have h_Cdelta_qm1 : C * δ ^ (q - 1) < lambda / 2 := by
        have h1 : C * δ ^ (q - 1) < C * (lambda / (2 * C)) :=
          mul_lt_mul_of_pos_left h_delta_qm1_lt hCpos
        have h_simp : C * (lambda / (2 * C)) = lambda / 2 := by
          field_simp
        linarith [h_simp]
      have h_C_delta_q_lt : C * δ ^ q < (lambda / 2) * δ := by
        rw [h_split]
        have heq : C * (δ ^ (q - 1) * δ) = (C * δ ^ (q - 1)) * δ := by ring
        rw [heq]
        exact mul_lt_mul_of_pos_right h_Cdelta_qm1 hδ_pos
      -- Step (c): conclude
      have h_lambda_2_lt : (lambda / 2) * δ < lambda * δ := by
        have hl : lambda / 2 < lambda := by linarith
        exact mul_lt_mul_of_pos_right hl hδ_pos
      have h_C_delta_q_lt' : C * δ ^ q < lambda * δ := lt_trans h_C_delta_q_lt h_lambda_2_lt
      linarith [h_rise]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem PEqZeroNotLocalMin
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (hS_pos : ∃ k, sigma k = 1) :
    ¬ ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - 0| < ε) →
          g_lambda q lambda f (fun _ : Fin d => (0 : ℝ)) ≤ g_lambda q lambda f p := by
  -- Step 1: convert the sum hypothesis to lqNorm q f = 1
  have hq_le : 1 ≤ q := le_of_lt hq
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq_le
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hf_norm : lqNorm q f = 1 := by
    unfold lqNorm
    have h_abs : (∑ j, |f j| ^ q) = (∑ j, (f j) ^ q) := by
      apply Finset.sum_congr rfl
      intro j _
      rw [abs_of_nonneg (hf_nn j)]
    rw [h_abs, hf_sum, Real.one_rpow]
  -- Step 2: assume the contradiction hypothesis
  rintro ⟨ε, hε_pos, hε_local⟩
  -- Step 3: apply PerturbAtZero_StrictDescent
  obtain ⟨tildep, h_orthant, h_close, h_strict⟩ :=
    PerturbAtZero_StrictDescent hq hlam0 hlam1 hd f hf_nn hf_norm sigma hsigma_pm hS_pos hε_pos
  -- h_strict : lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep
  --             < lqNorm q (fun k => -(f k))
  -- Step 4: apply the local minimum at tildep
  have h_dist : ∀ j, |tildep j - 0| < ε := by
    intro j
    rw [sub_zero]
    exact h_close j
  have h_local := hε_local tildep h_orthant h_dist
  -- h_local : g_lambda q lambda f 0 ≤ g_lambda q lambda f tildep
  -- Step 5: simplify g_lambda at 0
  have h_g0 : g_lambda q lambda f (fun _ : Fin d => (0 : ℝ))
              = lqNorm q (fun k : Fin d => -(f k)) := by
    unfold g_lambda
    have h_zero : lqNorm q (fun _ : Fin d => (0 : ℝ)) = 0 := lqNorm_zero hq_le
    have h_arg : (fun j : Fin d => (fun (_ : Fin d) => (0 : ℝ)) j - f j)
                  = (fun k : Fin d => -(f k)) := by
      funext j; ring
    rw [h_arg, h_zero]
    ring
  -- Step 6: g_lambda at tildep
  have h_gtilde : g_lambda q lambda f tildep
                  = lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep := rfl
  -- Step 7: derive contradiction
  rw [h_g0] at h_local
  rw [h_gtilde] at h_local
  -- h_local : lqNorm q (fun k => -(f k)) ≤ lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep
  -- h_strict : lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep < lqNorm q (fun k => -(f k))
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

namespace LocalOptimumCharacterization_CaseSNonemptyProof

/-- Helper: x^(q-1) = y^(q-1) with x, y ≥ 0 and q-1 > 0 implies x = y. -/
private lemma rpow_qm1_inj {q : ℝ} (hqm1 : 0 < q - 1) {x y : ℝ}
    (hx : 0 ≤ x) (hy : 0 ≤ y) (heq : x ^ (q - 1) = y ^ (q - 1)) : x = y := by
  have hq_inv_pos : 0 < 1 / (q - 1) := by positivity
  have h1 : (x ^ (q - 1)) ^ (1 / (q - 1)) = (y ^ (q - 1)) ^ (1 / (q - 1)) := by rw [heq]
  rw [← Real.rpow_mul hx, ← Real.rpow_mul hy] at h1
  have hmul : (q - 1) * (1 / (q - 1)) = 1 := by
    field_simp
  rw [hmul, Real.rpow_one, Real.rpow_one] at h1
  exact h1

/-- Helper: from `(p - f)^(q-1) / N1^(q-1) = lambda * p^(q-1) / N2^(q-1)`
with `p > f ≥ 0`, `N1 > 0`, `N2 > 0`, `lambda > 0`, `q > 1`, derive
`(p - f) / p = lambda^(1/(q-1)) * N1 / N2`. -/
private lemma extract_c_pos {q : ℝ} (hq : 1 < q) {p_j f_j N1 N2 lambda : ℝ}
    (hf_nn : 0 ≤ f_j) (hpf : f_j < p_j) (hN1 : 0 < N1) (hN2 : 0 < N2)
    (hlam : 0 < lambda)
    (hkkt : (p_j - f_j) ^ (q - 1) / N1 ^ (q - 1)
            = lambda * (p_j ^ (q - 1) / N2 ^ (q - 1))) :
    (p_j - f_j) / p_j = Real.rpow lambda (1 / (q - 1)) * N1 / N2 := by
  have hp_pos : 0 < p_j := lt_of_le_of_lt hf_nn hpf
  have hpf_pos : 0 < p_j - f_j := by linarith
  have hqm1_pos : 0 < q - 1 := by linarith
  have hN1_pow : 0 < N1 ^ (q - 1) := Real.rpow_pos_of_pos hN1 _
  have hN2_pow : 0 < N2 ^ (q - 1) := Real.rpow_pos_of_pos hN2 _
  have hp_pow : 0 < p_j ^ (q - 1) := Real.rpow_pos_of_pos hp_pos _
  -- Step 1: Multiply both sides by N1^(q-1)/p^(q-1).
  -- ((p-f)/p)^(q-1) = lambda * (N1/N2)^(q-1)
  have hstep1 : ((p_j - f_j) / p_j) ^ (q - 1) = lambda * (N1 / N2) ^ (q - 1) := by
    rw [Real.div_rpow (le_of_lt hpf_pos) (le_of_lt hp_pos)]
    rw [Real.div_rpow (le_of_lt hN1) (le_of_lt hN2)]
    field_simp
    field_simp at hkkt
    linarith
  -- Step 2: Take (q-1)-th roots.
  -- LHS: ((p-f)/p) ≥ 0; RHS: lambda^(1/(q-1)) * N1/N2 ≥ 0.
  have hlhs_nn : 0 ≤ (p_j - f_j) / p_j := div_nonneg (le_of_lt hpf_pos) (le_of_lt hp_pos)
  have hN1N2_nn : 0 ≤ N1 / N2 := div_nonneg (le_of_lt hN1) (le_of_lt hN2)
  have hlam_rpow_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) := Real.rpow_nonneg (le_of_lt hlam) _
  have hrhs_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) * (N1 / N2) :=
    mul_nonneg hlam_rpow_nn hN1N2_nn
  -- We'll show: (lambda^(1/(q-1)) * (N1/N2))^(q-1) = lambda * (N1/N2)^(q-1).
  have hrhs_pow : (Real.rpow lambda (1 / (q - 1)) * (N1 / N2)) ^ (q - 1)
      = lambda * (N1 / N2) ^ (q - 1) := by
    rw [Real.mul_rpow hlam_rpow_nn hN1N2_nn]
    -- (lambda^(1/(q-1)))^(q-1) = lambda
    have hlam_pow : Real.rpow lambda (1 / (q - 1)) ^ (q - 1) = lambda := by
      rw [show (Real.rpow lambda (1/(q-1))) ^ (q-1)
            = Real.rpow lambda ((1/(q-1))*(q-1))
            from (Real.rpow_mul (le_of_lt hlam) (1/(q-1)) (q-1)).symm,
          show (1 / (q-1) * (q-1) : ℝ) = 1 from by field_simp]
      exact Real.rpow_one lambda
    rw [hlam_pow]
  -- Now ((p-f)/p)^(q-1) = (lambda^(1/(q-1)) * (N1/N2))^(q-1).
  have heq2 : ((p_j - f_j) / p_j) ^ (q - 1)
      = (Real.rpow lambda (1 / (q - 1)) * (N1 / N2)) ^ (q - 1) := by
    rw [hrhs_pow]; exact hstep1
  have heq3 : (p_j - f_j) / p_j = Real.rpow lambda (1 / (q - 1)) * (N1 / N2) :=
    rpow_qm1_inj hqm1_pos hlhs_nn hrhs_nn heq2
  rw [heq3]; ring

/-- Helper: same for negative branch.
From `(f - p)^(q-1) / N1^(q-1) = lambda * (-p)^(q-1) / N2^(q-1)` with `p < 0`, `f ≥ 0`,
derive `(f - p) / (-p) = lambda^(1/(q-1)) * N1/N2`. -/
private lemma extract_c_neg {q : ℝ} (hq : 1 < q) {p_j f_j N1 N2 lambda : ℝ}
    (hf_nn : 0 ≤ f_j) (hp_neg : p_j < 0) (hN1 : 0 < N1) (hN2 : 0 < N2)
    (hlam : 0 < lambda)
    (hkkt : (f_j - p_j) ^ (q - 1) / N1 ^ (q - 1)
            = lambda * ((-p_j) ^ (q - 1) / N2 ^ (q - 1))) :
    (f_j - p_j) / (-p_j) = Real.rpow lambda (1 / (q - 1)) * N1 / N2 := by
  have hnp_pos : 0 < -p_j := by linarith
  have hfp_pos : 0 < f_j - p_j := by linarith
  have hqm1_pos : 0 < q - 1 := by linarith
  have hN1_pow : 0 < N1 ^ (q - 1) := Real.rpow_pos_of_pos hN1 _
  have hN2_pow : 0 < N2 ^ (q - 1) := Real.rpow_pos_of_pos hN2 _
  have hnp_pow : 0 < (-p_j) ^ (q - 1) := Real.rpow_pos_of_pos hnp_pos _
  have hstep1 : ((f_j - p_j) / (-p_j)) ^ (q - 1) = lambda * (N1 / N2) ^ (q - 1) := by
    rw [Real.div_rpow (le_of_lt hfp_pos) (le_of_lt hnp_pos)]
    rw [Real.div_rpow (le_of_lt hN1) (le_of_lt hN2)]
    field_simp
    field_simp at hkkt
    linarith
  have hlhs_nn : 0 ≤ (f_j - p_j) / (-p_j) := div_nonneg (le_of_lt hfp_pos) (le_of_lt hnp_pos)
  have hN1N2_nn : 0 ≤ N1 / N2 := div_nonneg (le_of_lt hN1) (le_of_lt hN2)
  have hlam_rpow_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) := Real.rpow_nonneg (le_of_lt hlam) _
  have hrhs_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) * (N1 / N2) :=
    mul_nonneg hlam_rpow_nn hN1N2_nn
  have hrhs_pow : (Real.rpow lambda (1 / (q - 1)) * (N1 / N2)) ^ (q - 1)
      = lambda * (N1 / N2) ^ (q - 1) := by
    rw [Real.mul_rpow hlam_rpow_nn hN1N2_nn]
    have hlam_pow : Real.rpow lambda (1 / (q - 1)) ^ (q - 1) = lambda := by
      rw [show (Real.rpow lambda (1/(q-1))) ^ (q-1)
            = Real.rpow lambda ((1/(q-1))*(q-1))
            from (Real.rpow_mul (le_of_lt hlam) (1/(q-1)) (q-1)).symm,
          show (1 / (q-1) * (q-1) : ℝ) = 1 from by field_simp]
      exact Real.rpow_one lambda
    rw [hlam_pow]
  have heq2 : ((f_j - p_j) / (-p_j)) ^ (q - 1)
      = (Real.rpow lambda (1 / (q - 1)) * (N1 / N2)) ^ (q - 1) := by
    rw [hrhs_pow]; exact hstep1
  have heq3 : (f_j - p_j) / (-p_j) = Real.rpow lambda (1 / (q - 1)) * (N1 / N2) :=
    rpow_qm1_inj hqm1_pos hlhs_nn hrhs_nn heq2
  rw [heq3]; ring

end LocalOptimumCharacterization_CaseSNonemptyProof

open LocalOptimumCharacterization_CaseSNonemptyProof

theorem LocalOptimumCharacterization_CaseSNonempty
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧
                  (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧
                (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (S : Finset (Fin d))
    (hS_def : S = Finset.univ.filter (fun j : Fin d => sigma_i j = 1))
    (hS_ne : S.Nonempty) :
    ∃ c : ℝ, 0 ≤ c ∧ c < 1 ∧
      (∀ j ∈ S, p_star j = f j / (1 - c)) ∧
      (∀ j ∉ S, p_star j = 0) := by
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hq_pos : (0 : ℝ) < q := lt_of_lt_of_le zero_lt_one hq_le
  have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
  have hmemS : ∀ j, j ∈ S ↔ sigma_i j = 1 := by
    intro j; rw [hS_def]; simp [Finset.mem_filter]
  have hnotmemS : ∀ j, j ∉ S ↔ sigma_i j = -1 := by
    intro j
    rw [hmemS]
    constructor
    · intro hne
      rcases hsigma_pm j with h | h
      · exact (hne h).elim
      · exact h
    · intro h heq
      rw [heq] at h; norm_num at h
  have hp_nn_S : ∀ j ∈ S, 0 ≤ p_star j := by
    intro j hj; exact (hp_in j).1 ((hmemS j).mp hj)
  have hp_np_Sc : ∀ j ∉ S, p_star j ≤ 0 := by
    intro j hj; exact (hp_in j).2 ((hnotmemS j).mp hj)
  -- p_star is not identically zero
  have hS_pos : ∃ k, sigma_i k = 1 := by
    obtain ⟨j, hj⟩ := hS_ne
    exact ⟨j, (hmemS j).mp hj⟩
  have hp_not_zero : ¬ (∀ j, p_star j = 0) := by
    intro hzero
    apply PEqZeroNotLocalMin q hq lambda hlam0 hlam1 hd f hf_nn hf_sum sigma_i hsigma_pm hS_pos
    obtain ⟨ε, hε, hloc⟩ := hp_loc
    refine ⟨ε, hε, ?_⟩
    intro p hp_orth hp_close
    have hp_close' : ∀ j, |p j - p_star j| < ε := by
      intro j; have hk := hp_close j; rw [hzero j]; simpa using hk
    have h2 : g_lambda q lambda f p_star ≤ g_lambda q lambda f p := hloc p hp_orth hp_close'
    have hpstar_eq : p_star = (fun _ : Fin d => (0 : ℝ)) := by
      funext j; exact hzero j
    rw [hpstar_eq] at h2
    exact h2
  have hps_pos : 0 < lqNorm q p_star := by
    have hps_nn : 0 ≤ lqNorm q p_star := lqNorm_nonneg hq_le p_star
    rcases lt_or_eq_of_le hps_nn with h | h
    · exact h
    · exfalso
      have heq : lqNorm q p_star = 0 := h.symm
      have hzero : p_star = 0 := (LqNormZeroIffEqZero q hq_le hd p_star).mp heq
      apply hp_not_zero
      intro j; have := congrFun hzero j; simpa using this
  -- Case split on lqNorm q (p - f) = 0.
  by_cases hpf_zero : lqNorm q (fun k => p_star k - f k) = 0
  · -- Case A: p_star = f.
    have hpf_eq : (fun k => p_star k - f k) = 0 :=
      (LqNormZeroIffEqZero q hq_le hd _).mp hpf_zero
    have hpf_ptw : ∀ j, p_star j = f j := by
      intro j
      have := congrFun hpf_eq j
      simp at this
      linarith
    refine ⟨0, le_refl 0, by norm_num, ?_, ?_⟩
    · intro j _hj
      rw [hpf_ptw j]; ring
    · intro j hj
      have hpj_le : p_star j ≤ 0 := hp_np_Sc j hj
      have hpj_eq : p_star j = f j := hpf_ptw j
      have hfj_nn : 0 ≤ f j := hf_nn j
      linarith
  · -- Case B: lqNorm q (p_star - f) > 0.
    have hpf_pos : 0 < lqNorm q (fun k => p_star k - f k) := by
      have hnn : 0 ≤ lqNorm q (fun k => p_star k - f k) := lqNorm_nonneg hq_le _
      rcases lt_or_eq_of_le hnn with h | h
      · exact h
      · exfalso; exact hpf_zero h.symm
    set c : ℝ :=
        Real.rpow lambda (1 / (q - 1)) *
          lqNorm q (fun k => p_star k - f k) / lqNorm q p_star with hc_def
    have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
    have hrpow_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) := Real.rpow_nonneg hlam_nn _
    have hc_nn : 0 ≤ c := by
      have h1 : 0 ≤ Real.rpow lambda (1 / (q - 1)) *
          lqNorm q (fun k => p_star k - f k) :=
        mul_nonneg hrpow_nn (le_of_lt hpf_pos)
      exact div_nonneg h1 (le_of_lt hps_pos)
    -- Key claim: at any j ∈ Fin d with σ_j = +1, p_star j > f j, we have
    -- (p_star j - f j) / p_star j = c.
    have hc_eq_pos : ∀ (j : Fin d), sigma_i j = 1 → f j < p_star j →
        (p_star j - f j) / p_star j = c := by
      intro j hsig hpf
      have hkkt := InteriorFOC_Pos q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
        sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos hps_pos j hsig hpf
      have := extract_c_pos hq (hf_nn j) hpf hpf_pos hps_pos hlam0 hkkt
      rw [this, hc_def]
    -- Similarly for negative branch.
    have hc_eq_neg : ∀ (j : Fin d), sigma_i j = -1 → p_star j < 0 →
        (f j - p_star j) / (- p_star j) = c := by
      intro j hsig hpneg
      have hkkt := InteriorFOC_Neg q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
        sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos hps_pos j hsig hpneg
      have := extract_c_neg hq (hf_nn j) hpneg hpf_pos hps_pos hlam0 hkkt
      rw [this, hc_def]
    -- Step 5.1.2: For every j ∈ S, (1 - c) p_star j = f j.
    have hS_eq_aux : ∀ j ∈ S, (1 - c) * p_star j = f j := by
      intro j hj
      have hsig : sigma_i j = 1 := (hmemS j).mp hj
      have hp_nn : 0 ≤ p_star j := hp_nn_S j hj
      have hclaim := Claim1_RuleOutInterior q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
        sigma_i hsigma_pm p_star hp_in hp_loc j hsig
      rcases hclaim with hpz | hpf_ge
      · have hfz : f j = 0 := LeftBoundary_ForcesFjZero q hq lambda hlam0 hlam1 hd f
          hf_nn hf_sum sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos j hsig hpz
        rw [hpz, hfz]; ring
      · rcases lt_or_eq_of_le hpf_ge with hgt | heq
        · -- p_star j > f j. Use hc_eq_pos.
          have hcj := hc_eq_pos j hsig hgt
          have hpj_pos : 0 < p_star j := lt_of_le_of_lt (hf_nn j) hgt
          -- hcj : (p_star j - f j)/p_star j = c.
          -- Want: (1-c) * p_star j = f j.
          have : p_star j - f j = c * p_star j := by
            field_simp at hcj
            linarith
          linarith
        · -- p_star j = f j. Sub-cases.
          rcases lt_or_eq_of_le (hf_nn j) with hfp | hfz
          · -- f j > 0. RightBoundary_ForcesC0 contradicts Case B.
            exfalso
            have hcontr := RightBoundary_ForcesC0 q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
              sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos hps_pos j hsig heq.symm hfp
            rw [hcontr] at hpf_pos
            exact lt_irrefl _ hpf_pos
          · -- f j = 0. Then p_star j = 0 too.
            have hfj : f j = 0 := hfz.symm
            have hpj : p_star j = 0 := by linarith
            rw [hpj, hfj]; ring
    -- Step 5.1.3: KEY — there is some j ∈ S with f j > 0 (i.e. the energy on S
    -- is positive). From this, c < 1 follows directly. We package the witness
    -- with the bound f j ≤ p_star j so it doubles as the SignIncompatibility (P)
    -- witness.
    have hPwit : ∃ j ∈ S, f j ≤ p_star j ∧ 0 < f j := by
      -- Helper: at any k ∈ S with f k > 0, we get f k ≤ p_star k.
      have hSwit_of_mem : ∀ k ∈ S, 0 < f k → f k ≤ p_star k := by
        intro k hk_S hfk_pos
        have hsig_k : sigma_i k = 1 := (hmemS k).mp hk_S
        have hcl_k := Claim1_RuleOutInterior q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
          sigma_i hsigma_pm p_star hp_in hp_loc k hsig_k
        rcases hcl_k with hpkz | hpk_ge
        · exfalso
          have hfk_zero := LeftBoundary_ForcesFjZero q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
            sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos k hsig_k hpkz
          linarith
        · exact hpk_ge
      -- It suffices to prove there is some j ∈ S with 0 < f j (positive S-energy).
      rsuffices ⟨j, hj_S, hfj_pos⟩ : ∃ j ∈ S, 0 < f j
      · exact ⟨j, hj_S, hSwit_of_mem j hj_S hfj_pos, hfj_pos⟩
      -- ===================================================================
      -- POSITIVE S-ENERGY  (∃ j ∈ S, 0 < f j).
      --
      -- With the paper's normalization `hf_pos : ∀ j, 0 < f j` (approx.tex
      -- line 9, every optimal facility coordinate is strictly positive), the
      -- degenerate configuration E_S = ∑_{j∈S} f_j^q = 0 cannot occur: S is
      -- nonempty, so pick any witness j ∈ S and `hf_pos j` gives 0 < f j.
      -- ===================================================================
      obtain ⟨j, hj_S⟩ := hS_ne
      exact ⟨j, hj_S, hf_pos j⟩
    -- From hPwit, derive c < 1 and the SignIncompatibility (P) witness.
    obtain ⟨jw, hjw_S, hfjw_le, hfjw_pos⟩ := hPwit
    have hsig_jw : sigma_i jw = 1 := (hmemS jw).mp hjw_S
    have hpjw_pos : 0 < p_star jw := lt_of_lt_of_le hfjw_pos hfjw_le
    -- c < 1: from (1 - c) * p_star jw = f jw > 0 and p_star jw > 0.
    have hc_lt_one : c < 1 := by
      have hq_eq := hS_eq_aux jw hjw_S
      by_contra hge
      push_neg at hge  -- 1 ≤ c
      have h1mc : 1 - c ≤ 0 := by linarith
      have : (1 - c) * p_star jw ≤ 0 :=
        mul_nonpos_of_nonpos_of_nonneg h1mc (le_of_lt hpjw_pos)
      rw [hq_eq] at this
      linarith
    -- (P) witness for SignIncompatibility.
    have hP : ∃ j : Fin d, sigma_i j = 1 ∧ f j ≤ p_star j ∧ 0 < f j :=
      ⟨jw, hsig_jw, hfjw_le, hfjw_pos⟩
    -- Step 5.1.5: For every i ∉ S, p_star i = 0.
    have h_pSc_zero : ∀ i, i ∉ S → p_star i = 0 := by
      intro i hi
      have hsig_i : sigma_i i = -1 := (hnotmemS i).mp hi
      have hpi_np : p_star i ≤ 0 := hp_np_Sc i hi
      rcases lt_or_eq_of_le hpi_np with hpi_neg | hpi_zero
      · exfalso
        rcases lt_or_eq_of_le (hf_nn i) with hfi_pos | hfi_zero
        · -- f i > 0, p_star i < 0: SignIncompatibility with the (P) witness.
          have hsi := SignIncompatibility q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
            sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos hps_pos
          apply hsi
          exact ⟨hP, ⟨i, hsig_i, hpi_neg, hfi_pos⟩⟩
        · -- f i = 0, p_star i < 0: negative FOC gives c = 1, contradicting c < 1.
          have hci := hc_eq_neg i hsig_i hpi_neg
          have hfi_eq : f i = 0 := hfi_zero.symm
          rw [hfi_eq, zero_sub] at hci
          have hnpi_ne : -p_star i ≠ 0 := by linarith
          have hci_eq_one : c = 1 := by
            rw [← hci, neg_div_neg_eq, div_self (by linarith : p_star i ≠ 0)]
          linarith
      · exact hpi_zero
    -- Step 5.1.6 + 5.1.7: assemble.
    refine ⟨c, hc_nn, hc_lt_one, ?_, h_pSc_zero⟩
    intro j hj
    have hj_eq := hS_eq_aux j hj
    have h1mc_pos : 0 < 1 - c := by linarith
    have h1mc_ne : (1 - c) ≠ 0 := ne_of_gt h1mc_pos
    field_simp
    linarith

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem LocalOptimumCharacterization_CaseSEmpty
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧
                  (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧
                (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (S : Finset (Fin d))
    (hS_def : S = Finset.univ.filter (fun j : Fin d => sigma_i j = 1))
    (hS_eq : S = ∅) :
    ∃ T : Finset (Fin d), ∃ c' : ℝ, 1 < c' ∧
      (∀ j ∈ T, -(p_star j) = f j / (c' - 1)) ∧
      (∀ j ∉ T, p_star j = 0) ∧
      (∀ j, p_star j ≤ 0) := by
  classical
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_le : 1 ≤ q := le_of_lt hq
  have hq1_pos : 0 < q - 1 := by linarith
  have hq1_ne : (q - 1) ≠ 0 := ne_of_gt hq1_pos
  -- Step 5.2.1: every σ_j = -1, hence p_star j ≤ 0 for all j
  have hsig_neg : ∀ j, sigma_i j = -1 := by
    intro j
    rcases hsigma_pm j with h1 | hm
    · -- σ_j = 1 ⇒ j ∈ S, but S = ∅
      exfalso
      have hj_in : j ∈ S := by
        rw [hS_def]
        simp [Finset.mem_filter, h1]
      rw [hS_eq] at hj_in
      exact (Finset.notMem_empty j) hj_in
    · exact hm
  have hpstar_le : ∀ j, p_star j ≤ 0 := fun j => (hp_in j).2 (hsig_neg j)
  -- Step 5.2.2: define T
  set T : Finset (Fin d) := Finset.univ.filter (fun j : Fin d => p_star j < 0) with hT_def
  have hT_mem : ∀ j, j ∈ T ↔ p_star j < 0 := by
    intro j
    rw [hT_def, Finset.mem_filter]
    simp
  -- Step 5.2.3: case on whether T is empty.  T may legitimately be empty
  -- (the all-zero point is a genuine local min when every σ = −1); in that
  -- case the conclusion holds vacuously with c' = 2.
  rcases Finset.eq_empty_or_nonempty T with hT_empty | hT_ne
  · -- T = ∅ ⇒ ∀ j, p_star j = 0.  Witnesses: T (= ∅), c' = 2.
    have hpstar_zero : ∀ j, p_star j = 0 := by
      intro j
      have hnotmem : j ∉ T := by
        rw [hT_empty]; exact Finset.notMem_empty j
      have hnot_lt : ¬ p_star j < 0 := by
        intro h_lt
        exact hnotmem ((hT_mem j).mpr h_lt)
      have h_ge : 0 ≤ p_star j := not_lt.mp hnot_lt
      linarith [hpstar_le j]
    refine ⟨T, 2, by norm_num, ?_, ?_, hpstar_le⟩
    · intro j hjT
      rw [hT_empty] at hjT
      exact absurd hjT (Finset.notMem_empty j)
    · intro j _
      exact hpstar_zero j
  -- Step 5.2.4: define c' (T nonempty branch)
  -- First we need lqNorm q p_star > 0 and lqNorm q (p_star - f) > 0
  -- Pick j₀ ∈ T
  obtain ⟨j₀, hj₀_T⟩ := hT_ne
  have hj₀_neg : p_star j₀ < 0 := (hT_mem j₀).mp hj₀_T
  -- lqNorm q p_star > 0 because |p_star j₀| > 0
  have hp_norm_pos : 0 < lqNorm q p_star := by
    -- Use that |p_star j₀|^q > 0 ≤ ∑ j, |p_star j|^q, so the sum is positive
    have h_abs_pos : 0 < |p_star j₀| := abs_pos.mpr (ne_of_lt hj₀_neg)
    have h_each_nn : ∀ j, 0 ≤ |p_star j| ^ q :=
      fun j => Real.rpow_nonneg (abs_nonneg _) q
    have h_j₀_pow_pos : 0 < |p_star j₀| ^ q := Real.rpow_pos_of_pos h_abs_pos q
    have h_sum_pos : 0 < ∑ j, |p_star j| ^ q := by
      have h_le := Finset.single_le_sum (f := fun j => |p_star j| ^ q)
        (s := Finset.univ) (a := j₀)
        (fun k _ => h_each_nn k) (Finset.mem_univ j₀)
      linarith
    unfold lqNorm
    exact Real.rpow_pos_of_pos h_sum_pos _
  have hp_norm_ne : lqNorm q p_star ≠ 0 := ne_of_gt hp_norm_pos
  -- lqNorm q (p_star - f) > 0 because |p_star j₀ - f j₀| > 0
  have hpf_norm_pos : 0 < lqNorm q (fun k => p_star k - f k) := by
    -- p_star j₀ < 0 ≤ f j₀, so p_star j₀ - f j₀ < 0
    have h_sub_neg : p_star j₀ - f j₀ < 0 := by
      have := hf_nn j₀
      linarith
    have h_sub_ne : p_star j₀ - f j₀ ≠ 0 := ne_of_lt h_sub_neg
    have h_abs_pos : 0 < |p_star j₀ - f j₀| := abs_pos.mpr h_sub_ne
    have h_each_nn : ∀ j, 0 ≤ |p_star j - f j| ^ q :=
      fun j => Real.rpow_nonneg (abs_nonneg _) q
    have h_j₀_pow_pos : 0 < |p_star j₀ - f j₀| ^ q := Real.rpow_pos_of_pos h_abs_pos q
    have h_sum_pos : 0 < ∑ j, |p_star j - f j| ^ q := by
      have h_le := Finset.single_le_sum (f := fun j => |p_star j - f j| ^ q)
        (s := Finset.univ) (a := j₀)
        (fun k _ => h_each_nn k) (Finset.mem_univ j₀)
      linarith
    unfold lqNorm
    exact Real.rpow_pos_of_pos h_sum_pos _
  have hpf_norm_ne : lqNorm q (fun k => p_star k - f k) ≠ 0 := ne_of_gt hpf_norm_pos
  -- Define c'
  set c' : ℝ := Real.rpow lambda (1 / (q - 1)) * lqNorm q (fun k => p_star k - f k) / lqNorm q p_star with hc'_def
  have hlam_pow_pos : 0 < Real.rpow lambda (1 / (q - 1)) := Real.rpow_pos_of_pos hlam0 _
  have hc'_pos : 0 < c' := by
    rw [hc'_def]
    exact div_pos (mul_pos hlam_pow_pos hpf_norm_pos) hp_norm_pos
  -- Step 5.2.5: equation (⋆_-) on T (using InteriorFOC_Neg)
  -- For j ∈ T, derive (f j - p_star j) / (-(p_star j)) = c'
  have hFOC_eq : ∀ j ∈ T, (f j - p_star j) / (-(p_star j)) = c' := by
    intro j hjT
    have hp_j_neg : p_star j < 0 := (hT_mem j).mp hjT
    have hsig_j : sigma_i j = -1 := hsig_neg j
    -- Apply InteriorFOC_Neg
    have hFOC := InteriorFOC_Neg q hq lambda hlam0 hlam1 hd f hf_nn hf_sum sigma_i hsigma_pm
        p_star hp_in hp_loc hpf_norm_pos hp_norm_pos j hsig_j hp_j_neg
    -- hFOC : (f j - p_star j)^(q-1) / N1^(q-1) = lambda * ((-(p_star j))^(q-1) / N2^(q-1))
    -- where N1 = lqNorm q (fun k => p_star k - f k), N2 = lqNorm q p_star
    set N1 : ℝ := lqNorm q (fun k => p_star k - f k) with hN1
    set N2 : ℝ := lqNorm q p_star with hN2
    have hA_pos : 0 < f j - p_star j := by
      have := hf_nn j
      linarith
    have hB_pos : 0 < -(p_star j) := by linarith
    have hN1_pos : 0 < N1 := hpf_norm_pos
    have hN2_pos : 0 < N2 := hp_norm_pos
    have hA_q1_pos : 0 < (f j - p_star j) ^ (q - 1) := Real.rpow_pos_of_pos hA_pos _
    have hB_q1_pos : 0 < (-(p_star j)) ^ (q - 1) := Real.rpow_pos_of_pos hB_pos _
    have hN1_q1_pos : 0 < N1 ^ (q - 1) := Real.rpow_pos_of_pos hN1_pos _
    have hN2_q1_pos : 0 < N2 ^ (q - 1) := Real.rpow_pos_of_pos hN2_pos _
    -- Manipulate hFOC: cross-multiply
    -- A^(q-1) / N1^(q-1) = lambda * (B^(q-1) / N2^(q-1))
    -- A^(q-1) * N2^(q-1) = lambda * B^(q-1) * N1^(q-1)
    -- (A/B)^(q-1) = lambda * (N1/N2)^(q-1)
    -- = (lambda^(1/(q-1)))^(q-1) * (N1/N2)^(q-1)
    -- = (lambda^(1/(q-1)) * N1/N2)^(q-1) = (c')^(q-1)
    have h_eq1 : ((f j - p_star j) / (-(p_star j))) ^ (q - 1) = c' ^ (q - 1) := by
      -- Step 1: (f j - p_star j) / (-(p_star j)) ^(q-1) = ((f j - p_star j)^(q-1)) / ((-(p_star j))^(q-1))
      have hA_nn : 0 ≤ f j - p_star j := le_of_lt hA_pos
      have hB_nn : 0 ≤ -(p_star j) := le_of_lt hB_pos
      have hN1_nn : 0 ≤ N1 := le_of_lt hN1_pos
      have hN2_nn : 0 ≤ N2 := le_of_lt hN2_pos
      have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
      have hlam_pow_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) := le_of_lt hlam_pow_pos
      -- (A/B)^(q-1) = A^(q-1) / B^(q-1)
      rw [Real.div_rpow hA_nn hB_nn]
      -- c'^(q-1) = (lambda^(1/(q-1)) * N1 / N2)^(q-1) = (lambda^(1/(q-1)))^(q-1) * (N1/N2)^(q-1)
      --   = lambda * (N1/N2)^(q-1) = lambda * N1^(q-1) / N2^(q-1)
      have hc'_eq : c' ^ (q - 1)
          = lambda * (N1 ^ (q - 1) / N2 ^ (q - 1)) := by
        rw [hc'_def]
        rw [show Real.rpow lambda (1 / (q - 1)) * N1 / N2
            = (Real.rpow lambda (1 / (q - 1)) * N1) * (N2)⁻¹ by ring]
        -- ((λ^{1/(q-1)} * N1) * N2⁻¹)^(q-1) = (λ^{1/(q-1)})^(q-1) * N1^(q-1) * (N2⁻¹)^(q-1)
        --   = λ * N1^(q-1) * N2^(-1*(q-1)) -- wait, easier to use Real.div_rpow & Real.mul_rpow
        rw [show Real.rpow lambda (1 / (q - 1)) * N1 * N2⁻¹
            = (Real.rpow lambda (1 / (q - 1)) * N1) / N2 by ring]
        rw [Real.div_rpow (mul_nonneg hlam_pow_nn hN1_nn) hN2_nn]
        rw [Real.mul_rpow hlam_pow_nn hN1_nn]
        -- (λ^{1/(q-1)})^(q-1) = λ
        have h_pow : (Real.rpow lambda (1 / (q - 1))) ^ (q - 1) = lambda := by
          show (lambda ^ (1 / (q - 1) : ℝ)) ^ (q - 1 : ℝ) = lambda
          rw [← Real.rpow_mul hlam_nn]
          rw [show (1/(q-1) : ℝ) * (q-1) = 1 from by field_simp]
          exact Real.rpow_one _
        rw [h_pow]
        ring
      rw [hc'_eq]
      -- Now we have A^(q-1) / B^(q-1) = lambda * (N1^(q-1) / N2^(q-1))
      -- From hFOC : A^(q-1) / N1^(q-1) = lambda * (B^(q-1) / N2^(q-1))
      -- Need: A^(q-1) / B^(q-1) = lambda * N1^(q-1) / N2^(q-1)
      -- From hFOC: A^(q-1) * N2^(q-1) = lambda * B^(q-1) * N1^(q-1) (cross multiply)
      -- Divide both sides by B^(q-1) * N2^(q-1): A^(q-1)/B^(q-1) = lambda * N1^(q-1) / N2^(q-1)
      have hN1_q1_ne : N1 ^ (q - 1) ≠ 0 := ne_of_gt hN1_q1_pos
      have hN2_q1_ne : N2 ^ (q - 1) ≠ 0 := ne_of_gt hN2_q1_pos
      have hB_q1_ne : (-(p_star j)) ^ (q - 1) ≠ 0 := ne_of_gt hB_q1_pos
      field_simp at hFOC
      field_simp
      linarith
    -- Now A/B and c' are both positive; their (q-1)-th powers are equal
    have hAB_pos : 0 < (f j - p_star j) / (-(p_star j)) := div_pos hA_pos hB_pos
    have hAB_nn : 0 ≤ (f j - p_star j) / (-(p_star j)) := le_of_lt hAB_pos
    have hc'_nn : 0 ≤ c' := le_of_lt hc'_pos
    exact (Real.rpow_left_inj hAB_nn hc'_nn hq1_ne).mp h_eq1
  -- Step 5.2.6: c' > 1, derived directly from the witness j₀ ∈ T.
  -- FOC at j₀ gives (f j₀ - p_star j₀) / (-(p_star j₀)) = c'; since f j₀ > 0
  -- (by hf_pos) the numerator exceeds the denominator, forcing c' > 1.
  have hFOC_j0 : (f j₀ - p_star j₀) / (-(p_star j₀)) = c' := hFOC_eq j₀ hj₀_T
  have hB_j0_pos : 0 < -(p_star j₀) := by linarith
  have hc'_gt1 : 1 < c' := by
    rw [← hFOC_j0]
    rw [lt_div_iff₀ hB_j0_pos]
    linarith [hf_pos j₀]
  -- Step 5.2.7: closed form -p_star j = f j / (c' - 1) for j ∈ T
  have hc'1_pos : 0 < c' - 1 := by linarith
  have hc'1_ne : c' - 1 ≠ 0 := ne_of_gt hc'1_pos
  have heqT : ∀ j ∈ T, -(p_star j) = f j / (c' - 1) := by
    intro j hjT
    have hp_j_neg : p_star j < 0 := (hT_mem j).mp hjT
    have hB_j_pos : 0 < -(p_star j) := by linarith
    have hB_j_ne : -(p_star j) ≠ 0 := ne_of_gt hB_j_pos
    have h_eq := hFOC_eq j hjT
    -- (f j - p_star j) / (-(p_star j)) = c'
    -- ⇒ f j - p_star j = c' * (-(p_star j))
    have h1 : f j - p_star j = c' * (-(p_star j)) := by
      have := (div_eq_iff hB_j_ne).mp h_eq
      linarith
    -- f j = c' * (-(p_star j)) + p_star j = (c' - 1) * (-(p_star j))
    have h2 : f j = (c' - 1) * (-(p_star j)) := by linarith
    -- Hence -(p_star j) = f j / (c' - 1)
    rw [h2]
    field_simp
  -- Step 5.2.8: For j ∉ T, p_star j = 0
  have heqTc : ∀ j ∉ T, p_star j = 0 := by
    intro j hjnotT
    have hnot_lt : ¬ p_star j < 0 := by
      intro h_lt
      exact hjnotT ((hT_mem j).mpr h_lt)
    have h_ge : 0 ≤ p_star j := not_lt.mp hnot_lt
    exact le_antisymm (hpstar_le j) h_ge
  -- Assemble
  exact ⟨T, c', hc'_gt1, heqT, heqTc, hpstar_le⟩

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

namespace LocalOptimumCharacterizationProof

open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem case_S_nonempty
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧
                  (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧
                (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (S : Finset (Fin d))
    (hS_def : S = Finset.univ.filter (fun j : Fin d => sigma_i j = 1))
    (hS_ne : S.Nonempty) :
    ∃ c : ℝ, 0 ≤ c ∧ c < 1 ∧
      (∀ j ∈ S, p_star j = f j / (1 - c)) ∧
      (∀ j ∉ S, p_star j = 0) :=
  LocalOptimumCharacterization_CaseSNonempty q hq lambda hlam0 hlam1 hd f hf_nn hf_pos hf_sum
    sigma_i hsigma_pm p_star hp_in hp_loc S hS_def hS_ne

theorem case_S_empty
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧
                  (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧
                (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (S : Finset (Fin d))
    (hS_def : S = Finset.univ.filter (fun j : Fin d => sigma_i j = 1))
    (hS_eq : S = ∅) :
    ∃ T : Finset (Fin d), ∃ c' : ℝ, 1 < c' ∧
      (∀ j ∈ T, -(p_star j) = f j / (c' - 1)) ∧
      (∀ j ∉ T, p_star j = 0) ∧
      (∀ j, p_star j ≤ 0) :=
  LocalOptimumCharacterization_CaseSEmpty q hq lambda hlam0 hlam1 hd f hf_nn hf_pos hf_sum
    sigma_i hsigma_pm p_star hp_in hp_loc S hS_def hS_eq

end LocalOptimumCharacterizationProof

open LocalOptimumCharacterizationProof

open Classical in
theorem LocalOptimumCharacterization
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧ (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧ (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p) :
    let S := Finset.univ.filter (fun j : Fin d => sigma_i j = 1)
    ( S.Nonempty ∧ ∃ c : ℝ, 0 ≤ c ∧ c < 1 ∧
        (∀ j ∈ S, p_star j = f j / (1 - c)) ∧
        (∀ j ∉ S, p_star j = 0) )
    ∨
    ( S = ∅ ∧ ∃ T : Finset (Fin d), ∃ c' : ℝ, 1 < c' ∧
        (∀ j ∈ T, -(p_star j) = f j / (c' - 1)) ∧
        (∀ j ∉ T, p_star j = 0) ∧
        (∀ j, p_star j ≤ 0) ) := by
  -- Set up the abbreviation `S := {j : σ_j = +1}` introduced by the `let`
  -- in the goal.
  intro S
  -- The proof distinguishes the two cases of paper Lemma 2:
  --   case (i):  S ≠ ∅, with closed form p_j = f_j/(1-c) on S;
  --   case (ii): S = ∅, with closed form -p_j = f_j/(c'-1) on T.
  by_cases hS : S.Nonempty
  · -- **Case (i): S ≠ ∅.** Apply step (a) to get c.
    left
    refine ⟨hS, ?_⟩
    exact case_S_nonempty q hq lambda hlam0 hlam1 hd f hf_nn hf_pos hf_sum
            sigma_i hsigma_pm p_star hp_in hp_loc S rfl hS
  · -- **Case (ii): S = ∅.** Apply step (b) to get T, c'.
    right
    have hS_eq : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hS
    refine ⟨hS_eq, ?_⟩
    exact case_S_empty q hq lambda hlam0 hlam1 hd f hf_nn hf_pos hf_sum
            sigma_i hsigma_pm p_star hp_in hp_loc S rfl hS_eq

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists
open Workspace.ProofLemmas.LambdaDeltaIdentity

namespace LocalMinEmptyS_Aux2

/-- Helper: For w ≥ 0, q > 1, lambda ∈ (0,1), with K = (1 - lambda^(q/(q-1)))^((q-1)/q),
    we have `(w^q + 1)^(1/q) ≥ K + lambda * w`. Proven via 2-component Hölder. -/
lemma key_holder_one_dim
    {q : ℝ} (hq : 1 < q) {lambda : ℝ} (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {w : ℝ} (hw : 0 ≤ w) :
    (1 - lambda ^ (q / (q - 1))) ^ ((q - 1) / q) + lambda * w
      ≤ (w ^ q + 1) ^ ((1 : ℝ) / q) := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_sub_pos : 0 < q - 1 := by linarith
  have hq_sub_ne : q - 1 ≠ 0 := ne_of_gt hq_sub_pos
  set p : ℝ := q / (q - 1) with hp_def
  have hp_pos : 0 < p := by simp [hp_def]; exact div_pos hq_pos hq_sub_pos
  have hp_ne : p ≠ 0 := ne_of_gt hp_pos
  have hp_gt1 : 1 < p := by
    rw [hp_def]
    rw [lt_div_iff₀ hq_sub_pos]
    linarith
  have hpinv_q : p⁻¹ + q⁻¹ = 1 := by
    rw [hp_def]
    field_simp
    ring
  have h_hc : Real.HolderConjugate p q := by
    rw [Real.holderConjugate_iff]
    exact ⟨hp_gt1, hpinv_q⟩
  -- lambda^p = lambda^(q/(q-1))
  set lp : ℝ := lambda ^ p with hlp_def
  have hlam_nn : (0 : ℝ) ≤ lambda := le_of_lt hlam0
  have hlp_pos : 0 < lp := Real.rpow_pos_of_pos hlam0 _
  have hlp_nn : 0 ≤ lp := le_of_lt hlp_pos
  -- lambda^p ≤ 1
  have hlp_le_one : lp ≤ 1 := by
    rw [hlp_def]
    have h1 : lambda ^ p ≤ lambda ^ (0 : ℝ) := by
      apply Real.rpow_le_rpow_of_exponent_ge hlam0 (le_of_lt hlam1)
      linarith
    simpa using h1
  have h_one_sub_lp_nn : 0 ≤ 1 - lp := by linarith
  -- K = (1 - lp)^((q-1)/q)
  set K : ℝ := (1 - lp) ^ ((q - 1) / q) with hK_def
  have hK_nn : 0 ≤ K := Real.rpow_nonneg h_one_sub_lp_nn _
  let fH : Fin 2 → ℝ := fun i => if i = 0 then lambda else K
  let gH : Fin 2 → ℝ := fun i => if i = 0 then w else 1
  have hfH_nn : ∀ i ∈ (Finset.univ : Finset (Fin 2)), 0 ≤ fH i := by
    intro i _
    fin_cases i
    · simp [fH]; exact hlam_nn
    · simp [fH]; exact hK_nn
  have hgH_nn : ∀ i ∈ (Finset.univ : Finset (Fin 2)), 0 ≤ gH i := by
    intro i _
    fin_cases i
    · simp [gH]; exact hw
    · simp [gH]
  have hHolder := Real.inner_le_Lp_mul_Lq_of_nonneg
    (Finset.univ : Finset (Fin 2)) h_hc hfH_nn hgH_nn
  -- Compute the sums explicitly
  have hsum_fg : ∑ i, fH i * gH i = lambda * w + K * 1 := by
    rw [Fin.sum_univ_two]
    simp [fH, gH]
  have hsum_f : ∑ i, fH i ^ p = lambda ^ p + K ^ p := by
    rw [Fin.sum_univ_two]
    simp [fH]
  have hsum_g : ∑ i, gH i ^ q = w ^ q + 1 ^ q := by
    rw [Fin.sum_univ_two]
    simp [gH]
  rw [hsum_fg, hsum_f, hsum_g] at hHolder
  -- Show lambda^p + K^p = 1.
  have hKp : K ^ p = 1 - lp := by
    rw [hK_def]
    rw [← Real.rpow_mul h_one_sub_lp_nn]
    have hprod : ((q - 1) / q) * p = 1 := by
      rw [hp_def]; field_simp
    rw [hprod, Real.rpow_one]
  have hsum_one : lambda ^ p + K ^ p = 1 := by
    rw [hKp, ← hlp_def]; ring
  rw [hsum_one] at hHolder
  have h_one_pinv : (1 : ℝ) ^ (1 / p) = 1 := Real.one_rpow _
  rw [h_one_pinv, one_mul] at hHolder
  have h_one_q : (1 : ℝ) ^ q = 1 := Real.one_rpow _
  rw [h_one_q] at hHolder
  rw [mul_one] at hHolder
  linarith [hHolder]

/-- Helper: For u ≥ v ≥ 0 and q ≥ 1, `u^q ≥ (u-v)^q + v^q`. -/
lemma sub_rpow_le {q : ℝ} (hq : 1 ≤ q) {u v : ℝ} (hv : 0 ≤ v) (huv : v ≤ u) :
    (u - v) ^ q + v ^ q ≤ u ^ q := by
  have h_uvnn : 0 ≤ u - v := by linarith
  have h := Real.add_rpow_le_rpow_add h_uvnn hv hq
  have heq : (u - v) + v = u := by ring
  rw [heq] at h
  exact h

end LocalMinEmptyS_Aux2

open LocalMinEmptyS_Aux2

theorem LocalMinEmptyS
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (T : Finset (Fin d)) (hT_ne : T.Nonempty)
    (c' : ℝ) (hc' : 1 < c')
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j ∈ T, -(p_star j) = f j / (c' - 1))
    (hp_out : ∀ j ∉ T, p_star j = 0)
    (hp_nonpos : ∀ j, p_star j ≤ 0) :
    (1 - lambda ^ (q / (q - 1))) ^ ((q - 1) / q) ≤ g_lambda q lambda f p_star := by
  classical
  have hq_le : 1 ≤ q := le_of_lt hq
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_inv_pos : 0 < 1 / q := by positivity
  have hq_inv_nn : 0 ≤ 1 / q := le_of_lt hq_inv_pos
  have hc'_sub_pos : 0 < c' - 1 := by linarith
  have hc'_sub_ne : c' - 1 ≠ 0 := ne_of_gt hc'_sub_pos
  have hc'_pos : 0 < c' := by linarith
  -- Set c = c'/(c'-1) > 1.
  set c : ℝ := c' / (c' - 1) with hc_def
  have hc_pos : 0 < c := div_pos hc'_pos hc'_sub_pos
  have hc_gt1 : 1 < c := by
    rw [hc_def, lt_div_iff₀ hc'_sub_pos]; linarith
  have hc_nn : 0 ≤ c := le_of_lt hc_pos
  have hc_sub1 : c - 1 = 1 / (c' - 1) := by
    rw [hc_def]; field_simp; ring
  -- |p_star j| for j ∈ T equals f j / (c'-1).
  have habs_in : ∀ j ∈ T, |p_star j| = f j / (c' - 1) := by
    intro j hj
    have h1 : -(p_star j) = f j / (c' - 1) := hp_in j hj
    have h2 : p_star j = -(f j / (c' - 1)) := by linarith
    rw [h2, abs_neg]
    have h3 : 0 ≤ f j / (c' - 1) := div_nonneg (hf_nn j) (le_of_lt hc'_sub_pos)
    rw [abs_of_nonneg h3]
  have habs_out : ∀ j ∉ T, |p_star j| = 0 := by
    intro j hj
    rw [hp_out j hj, abs_zero]
  -- |p_star j - f j| for j ∈ T equals f j * c'/(c'-1) = c * f j.
  -- For j ∉ T equals f j.
  have hsub_in : ∀ j ∈ T, |p_star j - f j| = c * f j := by
    intro j hj
    have h1 : -(p_star j) = f j / (c' - 1) := hp_in j hj
    have h2 : p_star j = -(f j / (c' - 1)) := by linarith
    rw [h2]
    have h3 : -(f j / (c' - 1)) - f j = -(f j * (c'/(c'-1))) := by
      field_simp
      ring
    rw [h3, abs_neg]
    have h4 : 0 ≤ f j * c := mul_nonneg (hf_nn j) hc_nn
    have heq : f j * (c'/(c'-1)) = f j * c := by rw [hc_def]
    rw [heq]
    rw [abs_of_nonneg h4]
    ring
  have hsub_out : ∀ j ∉ T, |p_star j - f j| = f j := by
    intro j hj
    rw [hp_out j hj, zero_sub, abs_neg]
    rw [abs_of_nonneg (hf_nn j)]
  -- Define S_T = ∑ j ∈ T, f_j ^ q
  set S_T : ℝ := ∑ j ∈ T, (f j) ^ q with hST_def
  have hST_nn : 0 ≤ S_T := by
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) q
  -- 1 - S_T = ∑ j ∉ T (over univ \ T), f_j ^ q
  have hST_le_one : S_T ≤ 1 := by
    rw [← hf_sum]
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · exact T.subset_univ
    · intro j _ _
      exact Real.rpow_nonneg (hf_nn j) q
  -- Compute lqNorm q p_star ^ q = (c-1)^q * S_T
  have h_pstar_norm_pow : (∑ j, |p_star j| ^ q) = (c - 1) ^ q * S_T := by
    rw [hST_def]
    rw [← Finset.sum_compl_add_sum T (fun j => |p_star j| ^ q)]
    have h_left : ∑ j ∈ Tᶜ, |p_star j| ^ q = 0 := by
      apply Finset.sum_eq_zero
      intro j hj
      have hjT : j ∉ T := Finset.mem_compl.mp hj
      rw [habs_out j hjT]
      exact Real.zero_rpow hq_ne
    rw [h_left, zero_add]
    have h_right : ∑ j ∈ T, |p_star j| ^ q = ∑ j ∈ T, ((c - 1) ^ q) * (f j) ^ q := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [habs_in j hj]
      have h1 : f j / (c' - 1) = (1 / (c' - 1)) * f j := by ring
      rw [h1]
      have h2 : 1 / (c' - 1) = c - 1 := by rw [hc_sub1]
      rw [h2]
      have h_cm1 : 0 ≤ c - 1 := by linarith
      have h_fj : 0 ≤ f j := hf_nn j
      rw [Real.mul_rpow h_cm1 h_fj]
    rw [h_right, ← Finset.mul_sum]
  -- Compute lqNorm q (p_star - f) ^ q = c^q * S_T + (1 - S_T)
  have h_psf_norm_pow : (∑ j, |p_star j - f j| ^ q) = c ^ q * S_T + (1 - S_T) := by
    rw [← Finset.sum_compl_add_sum T (fun j => |p_star j - f j| ^ q)]
    have h_left : ∑ j ∈ Tᶜ, |p_star j - f j| ^ q = 1 - S_T := by
      have heq : ∑ j ∈ Tᶜ, |p_star j - f j| ^ q = ∑ j ∈ Tᶜ, (f j) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        have hjT : j ∉ T := Finset.mem_compl.mp hj
        rw [hsub_out j hjT]
      rw [heq]
      have hsum_split : ∑ j ∈ T, (f j) ^ q + ∑ j ∈ Tᶜ, (f j) ^ q = 1 := by
        rw [add_comm]
        rw [Finset.sum_compl_add_sum T (fun j => (f j) ^ q)]
        exact hf_sum
      linarith [hsum_split, hST_def]
    rw [h_left]
    have h_right : ∑ j ∈ T, |p_star j - f j| ^ q = c ^ q * S_T := by
      have heq : ∑ j ∈ T, |p_star j - f j| ^ q = ∑ j ∈ T, c ^ q * (f j) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        rw [hsub_in j hj]
        rw [Real.mul_rpow hc_nn (hf_nn j)]
      rw [heq, ← Finset.mul_sum]
    rw [h_right]
    ring
  -- Now compute lqNorm q p_star and lqNorm q (p_star - f) using these.
  -- Define u = c * S_T^(1/q), v = S_T^(1/q).
  set v : ℝ := S_T ^ ((1 : ℝ) / q) with hv_def
  have hv_nn : 0 ≤ v := Real.rpow_nonneg hST_nn _
  -- v^q = S_T
  have hv_q : v ^ q = S_T := by
    rw [hv_def, ← Real.rpow_mul hST_nn]
    rw [one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one]
  -- v ≤ 1 since S_T ≤ 1 and (·)^(1/q) is monotone on [0, ∞)
  have hv_le_one : v ≤ 1 := by
    rw [hv_def]
    have h1 : S_T ^ ((1 : ℝ) / q) ≤ (1 : ℝ) ^ ((1 : ℝ) / q) :=
      Real.rpow_le_rpow hST_nn hST_le_one hq_inv_nn
    rw [Real.one_rpow] at h1
    exact h1
  set u : ℝ := c * v with hu_def
  have hu_nn : 0 ≤ u := mul_nonneg hc_nn hv_nn
  have hu_ge_v : v ≤ u := by
    rw [hu_def]
    nlinarith [hv_nn, hc_gt1]
  -- u^q = c^q * v^q = c^q * S_T
  have hu_q : u ^ q = c ^ q * S_T := by
    rw [hu_def, Real.mul_rpow hc_nn hv_nn, hv_q]
  -- lqNorm q (p_star - f) ^ q = u^q + 1 - v^q = u^q + (1 - v^q)
  have h_psf_pow_eq : (∑ j, |p_star j - f j| ^ q) = u ^ q + (1 - v ^ q) := by
    rw [h_psf_norm_pow, hu_q, hv_q]
  -- Bound: u^q ≥ (u-v)^q + v^q  (so u^q + 1 - v^q ≥ (u-v)^q + 1).
  have h_uv_bound : (u - v) ^ q + 1 ≤ u ^ q + (1 - v ^ q) := by
    have h := sub_rpow_le hq_le hv_nn hu_ge_v
    -- h: (u - v)^q + v^q ≤ u^q
    linarith
  -- (∑ j, |p_star j - f j|^q)^(1/q) ≥ ((u-v)^q + 1)^(1/q)
  have h_psf_norm_ge : ((u - v) ^ q + 1) ^ ((1 : ℝ) / q)
                        ≤ (∑ j, |p_star j - f j| ^ q) ^ ((1 : ℝ) / q) := by
    rw [h_psf_pow_eq]
    have h_lhs_nn : 0 ≤ (u - v) ^ q + 1 := by
      have hl1 : 0 ≤ (u - v) ^ q :=
        Real.rpow_nonneg (by linarith) q
      linarith
    exact Real.rpow_le_rpow h_lhs_nn h_uv_bound hq_inv_nn
  -- (∑ j, |p_star j|^q)^(1/q) = (c-1) * S_T^(1/q) = u - v
  have hc_sub1_nn : 0 ≤ c - 1 := by linarith
  have h_pstar_norm_eq : (∑ j, |p_star j| ^ q) ^ ((1 : ℝ) / q) = u - v := by
    rw [h_pstar_norm_pow]
    have hcm1_q_nn : 0 ≤ (c - 1) ^ q := Real.rpow_nonneg hc_sub1_nn _
    rw [Real.mul_rpow hcm1_q_nn hST_nn]
    have h_cm1_qq : ((c - 1) ^ q) ^ ((1 : ℝ) / q) = c - 1 := by
      rw [← Real.rpow_mul hc_sub1_nn]
      rw [mul_one_div, div_self hq_ne, Real.rpow_one]
    rw [h_cm1_qq]
    -- Goal: (c - 1) * S_T ^ (1/q) = u - v
    -- u - v = c * v - v = (c - 1) * v = (c - 1) * S_T^(1/q)
    rw [hu_def, hv_def]
    ring
  -- Now use the key Hölder inequality on w = u - v.
  have h_w_nn : 0 ≤ u - v := by linarith
  have h_key := key_holder_one_dim hq hlam0 hlam1 h_w_nn
  -- h_key: K + lambda * (u - v) ≤ ((u - v)^q + 1)^(1/q)
  -- Combine: K ≤ ((u-v)^q + 1)^(1/q) - lambda*(u-v) ≤ lqNorm q (p_star - f) - lambda*lqNorm q p_star
  -- = g_lambda.
  unfold g_lambda lqNorm
  rw [h_pstar_norm_eq]
  linarith [h_key, h_psf_norm_ge]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists
open Workspace.ProofLemmas.LambdaDeltaIdentity

theorem GLambdaLowerBound_h
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (h_local :
      let S := Finset.univ.filter (fun j : Fin d => sigma_i j = 1)
      ( S.Nonempty ∧ ∃ c : ℝ, 0 ≤ c ∧ c < 1 ∧
          (∀ j ∈ S, p_star j = f j / (1 - c)) ∧
          (∀ j ∉ S, p_star j = 0) )
      ∨
      ( S = ∅ ∧ ∃ T : Finset (Fin d), ∃ c' : ℝ, 1 < c' ∧
          (∀ j ∈ T, -(p_star j) = f j / (c' - 1)) ∧
          (∀ j ∉ T, p_star j = 0) ∧
          (∀ j, p_star j ≤ 0) )) :
    let S := Finset.univ.filter (fun j : Fin d => sigma_i j = 1)
    let x := ∑ j ∈ S, (f j) ^ q
    lambda *
      (delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q) - x ^ ((1 : ℝ) / q))
      ≤ g_lambda q lambda f p_star := by
  classical
  intro S
  intro x
  -- Set up basic positivity / arithmetic facts
  have hq_pos : 0 < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_sub_pos : 0 < q - 1 := by linarith
  have hq_sub_ne : q - 1 ≠ 0 := ne_of_gt hq_sub_pos
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have h_inv_q_pos : 0 < (1 : ℝ) / q := by positivity
  have h_inv_q_nn : 0 ≤ (1 : ℝ) / q := le_of_lt h_inv_q_pos
  have hlam_nn : (0 : ℝ) ≤ lambda := le_of_lt hlam0
  have hlam_le : lambda ≤ 1 := le_of_lt hlam1
  -- r := q / (q - 1)
  set r : ℝ := q / (q - 1) with hr_def
  have hr_pos : 0 < r := div_pos hq_pos hq_sub_pos
  have hr_ne : r ≠ 0 := ne_of_gt hr_pos
  have hlam_r_pos : 0 < lambda ^ r := Real.rpow_pos_of_pos hlam0 _
  have hlam_r_nn : 0 ≤ lambda ^ r := le_of_lt hlam_r_pos
  -- 1 - lambda^r > 0
  have h_lam_r_lt_one : lambda ^ r < 1 := by
    have h1 : lambda ^ r < (1 : ℝ) ^ r :=
      Real.rpow_lt_rpow hlam_nn hlam1 hr_pos
    simpa using h1
  have h_one_sub_pos : 0 < 1 - lambda ^ r := by linarith
  have h_one_sub_nn : 0 ≤ 1 - lambda ^ r := le_of_lt h_one_sub_pos
  -- lambda * delta = (1 - lambda^r)^((q-1)/q)
  have h_lam_delta : lambda * delta_of_lambda q lambda
        = (1 - lambda ^ r) ^ ((q - 1) / q) := by
    have := LambdaDeltaIdentity q hq lambda hlam0 hlam_le
    simpa [hr_def] using this
  -- f j ≥ 0, so |f j| = f j
  have hf_abs : ∀ j, |f j| = f j := fun j => abs_of_nonneg (hf_nn j)
  -- 1 - x = sum over complement of S
  have h_one_sub_x : (1 : ℝ) - x = ∑ j ∈ Sᶜ, (f j) ^ q := by
    have h_split := Finset.sum_compl_add_sum (s := S) (f := fun j => (f j) ^ q)
    have : (∑ j ∈ Sᶜ, (f j) ^ q) + (∑ j ∈ S, (f j) ^ q) = ∑ j, (f j) ^ q := by
      simpa using h_split
    rw [hf_sum] at this
    linarith
  -- x ≥ 0, 1 - x ≥ 0
  have hx_nn : 0 ≤ x := by
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) q
  have h_one_sub_x_nn : 0 ≤ 1 - x := by
    rw [h_one_sub_x]
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) q
  -- Now do the case split
  rcases h_local with ⟨hS_ne, c, hc0, hc1, hp_in, hp_out⟩ | ⟨hS_emp, hcase2⟩
  · -- Case (i): S nonempty
    have h1c_pos : 0 < 1 - c := by linarith
    have h1c_ne : 1 - c ≠ 0 := ne_of_gt h1c_pos
    have h1c_nn : 0 ≤ 1 - c := le_of_lt h1c_pos
    have hc_nn : 0 ≤ c := hc0
    have h_c_over : 0 ≤ c / (1 - c) := div_nonneg hc_nn h1c_nn
    -- For j ∈ S: |p_star j|^q = f j^q / (1-c)^q
    have h_ps_in : ∀ j ∈ S, |p_star j| ^ q = (f j) ^ q / (1 - c) ^ q := by
      intro j hj
      have h_eq : p_star j = f j / (1 - c) := hp_in j hj
      have h_nn : 0 ≤ p_star j := by
        rw [h_eq]; exact div_nonneg (hf_nn j) h1c_nn
      rw [abs_of_nonneg h_nn, h_eq]
      rw [Real.div_rpow (hf_nn j) h1c_nn]
    -- For j ∈ S: |p_star j - f j|^q = (c/(1-c))^q * f j^q
    have h_ps_diff_in : ∀ j ∈ S, |p_star j - f j| ^ q
        = (c / (1 - c)) ^ q * (f j) ^ q := by
      intro j hj
      have h_eq : p_star j = f j / (1 - c) := hp_in j hj
      have h_diff : p_star j - f j = f j * (c / (1 - c)) := by
        rw [h_eq]; field_simp; ring
      have h_diff_nn : 0 ≤ p_star j - f j := by
        rw [h_diff]; exact mul_nonneg (hf_nn j) h_c_over
      rw [abs_of_nonneg h_diff_nn, h_diff]
      rw [Real.mul_rpow (hf_nn j) h_c_over]
      ring
    -- For j ∉ S: |p_star j|^q = 0
    have h_ps_out : ∀ j ∉ S, |p_star j| ^ q = 0 := by
      intro j hj
      rw [hp_out j hj, abs_zero, Real.zero_rpow hq_ne]
    -- For j ∉ S: |p_star j - f j|^q = f j^q
    have h_ps_diff_out : ∀ j ∉ S, |p_star j - f j| ^ q = (f j) ^ q := by
      intro j hj
      rw [hp_out j hj, zero_sub, abs_neg, hf_abs j]
    -- Compute sum |p_star|^q
    have h_sum_ps : (∑ j, |p_star j| ^ q) = x / (1 - c) ^ q := by
      have hsplit := Finset.sum_compl_add_sum (s := S) (f := fun j => |p_star j| ^ q)
      have hSc : (∑ j ∈ Sᶜ, |p_star j| ^ q) = 0 := by
        apply Finset.sum_eq_zero
        intro j hj
        have hj' : j ∉ S := by
          intro hjS
          exact (Finset.mem_compl.mp hj) hjS
        exact h_ps_out j hj'
      have hSi : (∑ j ∈ S, |p_star j| ^ q) = ∑ j ∈ S, (f j) ^ q / (1 - c) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        exact h_ps_in j hj
      have h_total : (∑ j, |p_star j| ^ q) = ∑ j ∈ S, (f j) ^ q / (1 - c) ^ q := by
        calc (∑ j, |p_star j| ^ q)
            = (∑ j ∈ Sᶜ, |p_star j| ^ q) + (∑ j ∈ S, |p_star j| ^ q) := hsplit.symm
          _ = 0 + (∑ j ∈ S, |p_star j| ^ q) := by rw [hSc]
          _ = ∑ j ∈ S, |p_star j| ^ q := by rw [zero_add]
          _ = ∑ j ∈ S, (f j) ^ q / (1 - c) ^ q := hSi
      rw [h_total]
      rw [show x = ∑ j ∈ S, (f j) ^ q from rfl]
      rw [← Finset.sum_div]
    -- Compute sum |p_star - f|^q
    have h_sum_ps_diff : (∑ j, |p_star j - f j| ^ q)
        = (c / (1 - c)) ^ q * x + (1 - x) := by
      have hsplit := Finset.sum_compl_add_sum (s := S) (f := fun j => |p_star j - f j| ^ q)
      have hSc : (∑ j ∈ Sᶜ, |p_star j - f j| ^ q) = ∑ j ∈ Sᶜ, (f j) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        have hj' : j ∉ S := by
          intro hjS
          exact (Finset.mem_compl.mp hj) hjS
        exact h_ps_diff_out j hj'
      have hSi : (∑ j ∈ S, |p_star j - f j| ^ q)
          = ∑ j ∈ S, (c / (1 - c)) ^ q * (f j) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        exact h_ps_diff_in j hj
      have h_total : (∑ j, |p_star j - f j| ^ q)
          = (∑ j ∈ Sᶜ, (f j) ^ q) + (c / (1 - c)) ^ q * x := by
        calc (∑ j, |p_star j - f j| ^ q)
            = (∑ j ∈ Sᶜ, |p_star j - f j| ^ q) + (∑ j ∈ S, |p_star j - f j| ^ q) :=
              hsplit.symm
          _ = (∑ j ∈ Sᶜ, (f j) ^ q) + (∑ j ∈ S, (c / (1 - c)) ^ q * (f j) ^ q) := by
              rw [hSc, hSi]
          _ = (∑ j ∈ Sᶜ, (f j) ^ q) + (c / (1 - c)) ^ q * (∑ j ∈ S, (f j) ^ q) := by
              rw [Finset.mul_sum]
          _ = (∑ j ∈ Sᶜ, (f j) ^ q) + (c / (1 - c)) ^ q * x := rfl
      rw [h_total]
      rw [show (∑ j ∈ Sᶜ, (f j) ^ q) = 1 - x from h_one_sub_x.symm]
      ring
    -- Compute lqNorm q p_star = x^(1/q) / (1-c)
    have h_norm_ps : lqNorm q p_star = x ^ ((1 : ℝ) / q) / (1 - c) := by
      unfold lqNorm
      rw [h_sum_ps]
      rw [Real.div_rpow hx_nn (Real.rpow_nonneg h1c_nn q)]
      have h_pow : ((1 - c) ^ q) ^ ((1 : ℝ) / q) = 1 - c := by
        rw [← Real.rpow_mul h1c_nn]
        rw [mul_one_div, div_self hq_ne, Real.rpow_one]
      rw [h_pow]
    -- Compute lqNorm q (p_star - f) = ((c/(1-c))^q * x + (1-x))^(1/q)
    have h_norm_psf : lqNorm q (fun j => p_star j - f j)
        = ((c / (1 - c)) ^ q * x + (1 - x)) ^ ((1 : ℝ) / q) := by
      unfold lqNorm
      rw [h_sum_ps_diff]
    -- g_lambda q lambda f p_star
    have h_g : g_lambda q lambda f p_star
        = ((c / (1 - c)) ^ q * x + (1 - x)) ^ ((1 : ℝ) / q)
            - lambda * (x ^ ((1 : ℝ) / q) / (1 - c)) := by
      unfold g_lambda
      rw [h_norm_ps, h_norm_psf]
    -- Apply two-term Hölder
    -- HolderConjugate q r where r = q/(q-1)
    have hr_q_conj : (q : ℝ).HolderConjugate r := by
      rw [Real.holderConjugate_iff]
      refine ⟨hq, ?_⟩
      rw [hr_def]
      field_simp
      ring
    -- Define vectors A and B
    -- A 0 = (c/(1-c)) * x^(1/q),  A 1 = (1-x)^(1/q)
    -- B 0 = lambda,                B 1 = (1 - lambda^r)^((q-1)/q)
    -- ∑ A*B ≤ (∑|A|^q)^(1/q) * (∑|B|^r)^(1/r)
    have h_x_inv_q_nn : 0 ≤ x ^ ((1 : ℝ) / q) := Real.rpow_nonneg hx_nn _
    have h_one_x_inv_q_nn : 0 ≤ (1 - x) ^ ((1 : ℝ) / q) :=
      Real.rpow_nonneg h_one_sub_x_nn _
    have h_lamr_pow_nn : 0 ≤ (1 - lambda ^ r) ^ ((q - 1) / q) :=
      Real.rpow_nonneg h_one_sub_nn _
    let A : Fin 2 → ℝ := fun i => if i = 0 then (c / (1 - c)) * x ^ ((1 : ℝ) / q)
                                  else (1 - x) ^ ((1 : ℝ) / q)
    let B : Fin 2 → ℝ := fun i => if i = 0 then lambda
                                  else (1 - lambda ^ r) ^ ((q - 1) / q)
    have hA0 : A 0 = (c / (1 - c)) * x ^ ((1 : ℝ) / q) := by simp [A]
    have hA1 : A 1 = (1 - x) ^ ((1 : ℝ) / q) := by simp [A]
    have hB0 : B 0 = lambda := by simp [B]
    have hB1 : B 1 = (1 - lambda ^ r) ^ ((q - 1) / q) := by simp [B]
    -- ∑ A*B
    have h_sum_AB : (∑ i, A i * B i)
        = (c / (1 - c)) * x ^ ((1 : ℝ) / q) * lambda
            + (1 - x) ^ ((1 : ℝ) / q) * (1 - lambda ^ r) ^ ((q - 1) / q) := by
      rw [Fin.sum_univ_two, hA0, hA1, hB0, hB1]
    -- ∑ |A i|^q
    have h_A0_nn : 0 ≤ A 0 := by
      rw [hA0]; exact mul_nonneg h_c_over h_x_inv_q_nn
    have h_A1_nn : 0 ≤ A 1 := by
      rw [hA1]; exact h_one_x_inv_q_nn
    have h_B0_nn : 0 ≤ B 0 := by rw [hB0]; exact hlam_nn
    have h_B1_nn : 0 ≤ B 1 := by rw [hB1]; exact h_lamr_pow_nn
    have h_pow_xinvq : (x ^ ((1 : ℝ) / q)) ^ q = x := by
      rw [← Real.rpow_mul hx_nn, one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one]
    have h_pow_oneminusx : ((1 - x) ^ ((1 : ℝ) / q)) ^ q = 1 - x := by
      rw [← Real.rpow_mul h_one_sub_x_nn, one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one]
    have h_sum_Aq : (∑ i, |A i| ^ q) = (c / (1 - c)) ^ q * x + (1 - x) := by
      rw [Fin.sum_univ_two]
      rw [hA0, hA1]
      rw [abs_of_nonneg (mul_nonneg h_c_over h_x_inv_q_nn)]
      rw [abs_of_nonneg h_one_x_inv_q_nn]
      rw [Real.mul_rpow h_c_over h_x_inv_q_nn]
      rw [h_pow_xinvq, h_pow_oneminusx]
    -- ∑ |B i|^r
    have h_pow_lamr : ((1 - lambda ^ r) ^ ((q - 1) / q)) ^ r = 1 - lambda ^ r := by
      rw [← Real.rpow_mul h_one_sub_nn]
      have h_prod : (q - 1) / q * r = 1 := by
        rw [hr_def]; field_simp
      rw [h_prod, Real.rpow_one]
    have h_sum_Br : (∑ i, |B i| ^ r) = 1 := by
      rw [Fin.sum_univ_two]
      rw [hB0, hB1]
      rw [abs_of_nonneg hlam_nn]
      rw [abs_of_nonneg h_lamr_pow_nn]
      rw [h_pow_lamr]
      linarith
    -- Apply Hölder
    have h_holder := Real.inner_le_Lp_mul_Lq Finset.univ A B hr_q_conj
    rw [h_sum_AB, h_sum_Aq, h_sum_Br] at h_holder
    have h_one_rpow : (1 : ℝ) ^ ((1 : ℝ) / r) = 1 := Real.one_rpow _
    rw [h_one_rpow, mul_one] at h_holder
    -- h_holder: (c/(1-c))*x^(1/q)*lambda + (1-x)^(1/q)*(1-lambda^r)^((q-1)/q)
    --           ≤ ((c/(1-c))^q * x + (1-x))^(1/q)
    rw [h_g]
    -- Goal: lambda * (delta * (1-x)^(1/q) - x^(1/q))
    --      ≤ ((c/(1-c))^q * x + (1-x))^(1/q) - lambda * (x^(1/q)/(1-c))
    -- Step: rewrite LHS using h_lam_delta
    have h_LHS : lambda * (delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q)
          - x ^ ((1 : ℝ) / q))
        = (1 - lambda ^ r) ^ ((q - 1) / q) * (1 - x) ^ ((1 : ℝ) / q)
            - lambda * x ^ ((1 : ℝ) / q) := by
      have h1 : lambda * delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q)
            = (1 - lambda ^ r) ^ ((q - 1) / q) * (1 - x) ^ ((1 : ℝ) / q) := by
        rw [h_lam_delta]
      have h2 : lambda * (delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q)
            - x ^ ((1 : ℝ) / q))
          = lambda * delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q)
              - lambda * x ^ ((1 : ℝ) / q) := by ring
      rw [h2, h1]
    rw [h_LHS]
    -- Now need to show:
    -- (1-lambda^r)^((q-1)/q) * (1-x)^(1/q) - lambda * x^(1/q)
    -- ≤ ((c/(1-c))^q*x + (1-x))^(1/q) - lambda * (x^(1/q)/(1-c))
    -- Equivalently: lambda*(x^(1/q)/(1-c)) - lambda * x^(1/q)
    --            ≤ ((c/(1-c))^q*x + (1-x))^(1/q) - (1-lambda^r)^((q-1)/q)*(1-x)^(1/q)
    -- And: lambda*(x^(1/q)/(1-c)) - lambda*x^(1/q) = lambda * x^(1/q) * c/(1-c)
    --                                              = (c/(1-c)) * x^(1/q) * lambda
    -- So we need ((c/(1-c)) * x^(1/q) * lambda) + (1-lambda^r)^((q-1)/q) * (1-x)^(1/q)
    --           ≤ ((c/(1-c))^q*x + (1-x))^(1/q)
    -- which is h_holder (with the second term reordered).
    have h_eq_form : lambda * (x ^ ((1 : ℝ) / q) / (1 - c)) - lambda * x ^ ((1 : ℝ) / q)
        = (c / (1 - c)) * x ^ ((1 : ℝ) / q) * lambda := by
      have : x ^ ((1 : ℝ) / q) / (1 - c) - x ^ ((1 : ℝ) / q)
          = (c / (1 - c)) * x ^ ((1 : ℝ) / q) := by
        field_simp; ring
      have hmul : lambda * (x ^ ((1 : ℝ) / q) / (1 - c) - x ^ ((1 : ℝ) / q))
          = lambda * ((c / (1 - c)) * x ^ ((1 : ℝ) / q)) := by
        rw [this]
      have hl : lambda * (x ^ ((1 : ℝ) / q) / (1 - c) - x ^ ((1 : ℝ) / q))
          = lambda * (x ^ ((1 : ℝ) / q) / (1 - c)) - lambda * x ^ ((1 : ℝ) / q) := by ring
      have hr : lambda * ((c / (1 - c)) * x ^ ((1 : ℝ) / q))
          = (c / (1 - c)) * x ^ ((1 : ℝ) / q) * lambda := by ring
      linarith [hmul, hl, hr]
    linarith [h_holder, h_eq_form]
  · -- Case (ii): S = ∅
    -- x = 0 in this case
    have hx_zero : x = 0 := by
      show (∑ j ∈ S, (f j) ^ q) = 0
      have : S = ∅ := hS_emp
      rw [this, Finset.sum_empty]
    obtain ⟨T, c', hc'_lt, hp_in, hp_out, hp_nonpos⟩ := hcase2
    rw [hx_zero]
    have h_one_sub_zero : (1 : ℝ) - 0 = 1 := by ring
    rw [h_one_sub_zero]
    have h_one_pow : (1 : ℝ) ^ ((1 : ℝ) / q) = 1 := Real.one_rpow _
    have h_zero_pow : (0 : ℝ) ^ ((1 : ℝ) / q) = 0 :=
      Real.zero_rpow (ne_of_gt h_inv_q_pos)
    rw [h_one_pow, h_zero_pow]
    have h_calc : lambda * (delta_of_lambda q lambda * 1 - 0)
        = lambda * delta_of_lambda q lambda := by ring
    rw [h_calc, h_lam_delta]
    rcases Finset.eq_empty_or_nonempty T with hT_emp | hT_ne
    · -- T = ∅ : every p_star j = 0, so g_lambda = 1 and the bound is ≤ 1
      have hp0 : ∀ j, p_star j = 0 := by
        intro j
        exact hp_out j (hT_emp ▸ Finset.notMem_empty j)
      -- g_lambda q lambda f p_star = 1
      have h_g_one : g_lambda q lambda f p_star = 1 := by
        unfold g_lambda
        have h_norm_ps : lqNorm q p_star = 0 := by
          unfold lqNorm
          have : (∑ j, |p_star j| ^ q) = 0 := by
            apply Finset.sum_eq_zero
            intro j _
            rw [hp0 j, abs_zero, Real.zero_rpow hq_ne]
          rw [this, Real.zero_rpow (ne_of_gt h_inv_q_pos)]
        have h_norm_psf : lqNorm q (fun j => p_star j - f j) = 1 := by
          unfold lqNorm
          have hsum : (∑ j, |p_star j - f j| ^ q) = 1 := by
            have : (∑ j, |p_star j - f j| ^ q) = ∑ j, (f j) ^ q := by
              apply Finset.sum_congr rfl
              intro j _
              rw [hp0 j, zero_sub, abs_neg, hf_abs j]
            rw [this, hf_sum]
          rw [hsum, Real.one_rpow]
        rw [h_norm_ps, h_norm_psf]
        ring
      rw [h_g_one]
      -- Goal: (1 - lambda^r)^((q-1)/q) ≤ 1
      apply Real.rpow_le_one h_one_sub_nn (by linarith [hlam_r_nn]) (by positivity)
    · -- T nonempty : existing LocalMinEmptyS path
      have h_min := LocalMinEmptyS q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
          T hT_ne c' hc'_lt p_star hp_in hp_out hp_nonpos
      exact h_min

open Classical

theorem MedianConstraintToSumX
    {n d : ℕ} (hn_even : Even n) (q : ℝ)
    (f : Fin d → ℝ) (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin n → Fin d → ℝ)
    (hsigma_pm : ∀ i j, sigma i j = 1 ∨ sigma i j = -1)
    (hsigma_zero : ∀ j, ∑ i, sigma i j = 0) :
    (∑ i, ∑ j ∈ Finset.univ.filter (fun j => sigma i j = 1), (f j) ^ q) = (n : ℝ) / 2 := by
  classical
  -- Key combinatorial lemma: for each j, the number of i with sigma i j = 1 is n/2.
  have card_eq : ∀ j : Fin d,
      ((Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1)).card * 2 = n := by
    intro j
    -- Split the universe by sigma i j
    set Spos := (Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1) with hSpos
    set Sneg := (Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = -1) with hSneg
    -- Spos ∪ Sneg = univ and disjoint
    have hdisj : Disjoint Spos Sneg := by
      rw [Finset.disjoint_filter]
      intro i _ h1 h2
      rw [h1] at h2
      norm_num at h2
    have hunion : Spos ∪ Sneg = Finset.univ := by
      apply Finset.eq_univ_of_forall
      intro i
      rcases hsigma_pm i j with h | h
      · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _, h⟩)
      · exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _, h⟩)
    -- Cardinalities sum to n
    have hcard_sum : Spos.card + Sneg.card = n := by
      have h1 : (Spos ∪ Sneg).card = Spos.card + Sneg.card :=
        Finset.card_union_of_disjoint hdisj
      rw [hunion] at h1
      simp at h1
      linarith
    -- Sum of sigma over univ
    have hsum := hsigma_zero j
    -- Split sum over Spos ∪ Sneg
    have hsum_split : ∑ i, sigma i j = ∑ i ∈ Spos, sigma i j + ∑ i ∈ Sneg, sigma i j := by
      rw [← Finset.sum_union hdisj, hunion]
    -- On Spos, sigma i j = 1; on Sneg, sigma i j = -1.
    have hsum_pos : ∑ i ∈ Spos, sigma i j = (Spos.card : ℝ) := by
      rw [Finset.sum_congr rfl (fun i hi => by
        have := (Finset.mem_filter.mp hi).2
        exact this)]
      simp
    have hsum_neg : ∑ i ∈ Sneg, sigma i j = -(Sneg.card : ℝ) := by
      rw [Finset.sum_congr rfl (fun i hi => by
        have := (Finset.mem_filter.mp hi).2
        exact this)]
      simp
    rw [hsum_split, hsum_pos, hsum_neg] at hsum
    -- Now: Spos.card - Sneg.card = 0 and Spos.card + Sneg.card = n.
    have hcard_eq : (Spos.card : ℝ) = (Sneg.card : ℝ) := by linarith
    have hcard_eq_nat : Spos.card = Sneg.card := by exact_mod_cast hcard_eq
    rw [hcard_eq_nat] at hcard_sum
    omega
  -- Now use this to compute the sum.
  have step1 :
      (∑ i, ∑ j ∈ (Finset.univ : Finset (Fin d)).filter (fun j => sigma i j = 1), (f j) ^ q) =
      ∑ i, ∑ j, (if sigma i j = 1 then (f j) ^ q else 0) := by
    refine Finset.sum_congr rfl (fun i _ => ?_)
    rw [Finset.sum_filter]
  rw [step1]
  rw [Finset.sum_comm]
  -- Now: ∑ j, ∑ i, (if sigma i j = 1 then (f j) ^ q else 0) = (n : ℝ) / 2
  have step2 : ∀ j : Fin d,
      (∑ i, (if sigma i j = 1 then (f j) ^ q else 0)) =
      (((Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1)).card : ℝ) * (f j) ^ q := by
    intro j
    rw [← Finset.sum_filter]
    rw [Finset.sum_const]
    ring
  simp_rw [step2]
  -- Now: ∑ j, (filter card : ℝ) * (f j)^q = n / 2
  have step3 : ∀ j : Fin d,
      (((Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1)).card : ℝ) =
      (n : ℝ) / 2 := by
    intro j
    have := card_eq j
    have hnpos : (2 : ℝ) ≠ 0 := by norm_num
    field_simp
    have : (((Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1)).card * 2 : ℕ) = n := this
    have hcast : (((Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1)).card : ℝ) * 2 = (n : ℝ) := by
      exact_mod_cast this
    linarith
  simp_rw [step3]
  -- Now: ∑ j, (n/2) * (f j)^q = n/2
  rw [← Finset.mul_sum]
  rw [hf_sum]
  ring

namespace Workspace.ProofLemmas.HSecondDerivative

noncomputable def h_q (q lambda delta x : ℝ) : ℝ :=
  lambda * (delta * (1 - x) ^ ((1 : ℝ) / q) - x ^ ((1 : ℝ) / q))

end Workspace.ProofLemmas.HSecondDerivative

open Workspace.ProofLemmas.HSecondDerivative in
theorem HSecondDerivative
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) (x : ℝ) (hx0 : 0 < x) (hx1 : x < 1) :
    iteratedDeriv 2 (fun x => h_q q lambda delta x) x =
      (lambda * (q - 1) / q^2) *
        (x ^ ((1 - 2*q) / q) - delta * (1 - x) ^ ((1 - 2*q) / q)) := by
  -- q ≠ 0
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  -- First derivative formula at any point y with 0 < y < 1
  have firstDeriv : ∀ y, 0 < y → y < 1 →
      HasDerivAt (fun z => h_q q lambda delta z)
        (lambda * (-(delta * ((1/q) * (1 - y) ^ ((1:ℝ)/q - 1))) - (1/q) * y ^ ((1:ℝ)/q - 1))) y := by
    intro y hy0 hy1
    have hy_ne : y ≠ 0 := ne_of_gt hy0
    have h1my_ne : (1 - y) ≠ 0 := by linarith
    -- HasDerivAt for y ↦ y^(1/q)
    have h_y_pow : HasDerivAt (fun z : ℝ => z ^ ((1:ℝ)/q)) ((1/q) * y ^ ((1:ℝ)/q - 1)) y := by
      have h := (hasDerivAt_id y).rpow_const (p := (1:ℝ)/q) (Or.inl hy_ne)
      simpa using h
    -- HasDerivAt for y ↦ (1 - y)^(1/q)
    have h_oneminus_y : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) y := by
      simpa using (hasDerivAt_id y).const_sub 1
    have h_1my_pow : HasDerivAt (fun z : ℝ => (1 - z) ^ ((1:ℝ)/q))
        (-1 * (1/q) * (1 - y) ^ ((1:ℝ)/q - 1)) y := by
      have h := h_oneminus_y.rpow_const (p := (1:ℝ)/q) (Or.inl h1my_ne)
      convert h using 1
    -- HasDerivAt for delta * (1 - y)^(1/q)
    have h_d_1my_pow : HasDerivAt (fun z : ℝ => delta * (1 - z) ^ ((1:ℝ)/q))
        (delta * (-1 * (1/q) * (1 - y) ^ ((1:ℝ)/q - 1))) y :=
      h_1my_pow.const_mul delta
    -- HasDerivAt for (delta * (1 - y)^(1/q) - y^(1/q))
    have h_diff : HasDerivAt (fun z : ℝ => delta * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q))
        (delta * (-1 * (1/q) * (1 - y) ^ ((1:ℝ)/q - 1)) - (1/q) * y ^ ((1:ℝ)/q - 1)) y :=
      h_d_1my_pow.sub h_y_pow
    -- Multiply by lambda
    have h_full : HasDerivAt (fun z : ℝ => lambda * (delta * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q)))
        (lambda * (delta * (-1 * (1/q) * (1 - y) ^ ((1:ℝ)/q - 1)) - (1/q) * y ^ ((1:ℝ)/q - 1))) y :=
      h_diff.const_mul lambda
    have h_eq : (fun z => h_q q lambda delta z) =
        (fun z : ℝ => lambda * (delta * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q))) := by
      funext z; rfl
    rw [h_eq]
    convert h_full using 1
    ring
  -- The first derivative function (in a neighborhood of x):
  let f' : ℝ → ℝ := fun y =>
    lambda * (-(delta * ((1/q) * (1 - y) ^ ((1:ℝ)/q - 1))) - (1/q) * y ^ ((1:ℝ)/q - 1))
  -- Equivalent simpler form for differentiation
  let g' : ℝ → ℝ := fun y =>
    -(lambda * (1/q)) * (delta * (1 - y) ^ ((1:ℝ)/q - 1) + y ^ ((1:ℝ)/q - 1))
  have hf'_eq_g' : f' = g' := by
    funext y; simp only [f', g']; ring
  -- deriv equals f' on a neighborhood of x (in fact, on (0,1))
  have hderiv_on_nbhd : ∀ᶠ y in nhds x, deriv (fun z => h_q q lambda delta z) y = f' y := by
    have h_open : IsOpen (Set.Ioo (0:ℝ) 1) := isOpen_Ioo
    have hx_mem : x ∈ Set.Ioo (0:ℝ) 1 := ⟨hx0, hx1⟩
    filter_upwards [h_open.mem_nhds hx_mem] with y hy
    exact (firstDeriv y hy.1 hy.2).deriv
  -- Now compute the derivative of f' at x using HasDerivAt
  -- Use the fact that f' = g' to do differentiation on g'
  have hx_ne : x ≠ 0 := ne_of_gt hx0
  have h1mx_ne : (1 - x) ≠ 0 := by linarith
  -- HasDerivAt for y ↦ y^((1/q) - 1)
  have h_y_pow' : HasDerivAt (fun z : ℝ => z ^ ((1:ℝ)/q - 1))
      (((1:ℝ)/q - 1) * x ^ ((1:ℝ)/q - 1 - 1)) x := by
    have h := (hasDerivAt_id x).rpow_const (p := (1:ℝ)/q - 1) (Or.inl hx_ne)
    simpa using h
  -- HasDerivAt for y ↦ (1 - y)^((1/q) - 1)
  have h_oneminus_x : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) x := by
    simpa using (hasDerivAt_id x).const_sub 1
  have h_1mx_pow' : HasDerivAt (fun z : ℝ => (1 - z) ^ ((1:ℝ)/q - 1))
      (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1:ℝ)/q - 1 - 1)) x := by
    have h := h_oneminus_x.rpow_const (p := (1:ℝ)/q - 1) (Or.inl h1mx_ne)
    convert h using 1
  -- delta * (1 - y) ^ ((1/q) - 1)
  have h_d_1mx_pow' : HasDerivAt (fun z : ℝ => delta * (1 - z) ^ ((1:ℝ)/q - 1))
      (delta * (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1:ℝ)/q - 1 - 1))) x :=
    h_1mx_pow'.const_mul delta
  -- Sum: delta * (1 - y) ^ ((1/q) - 1) + y ^ ((1/q) - 1)
  have h_sum : HasDerivAt
      (fun z : ℝ => delta * (1 - z) ^ ((1:ℝ)/q - 1) + z ^ ((1:ℝ)/q - 1))
      (delta * (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1:ℝ)/q - 1 - 1))
        + ((1:ℝ)/q - 1) * x ^ ((1:ℝ)/q - 1 - 1)) x :=
    h_d_1mx_pow'.add h_y_pow'
  -- Multiply by -(lambda/q)
  have h_g' : HasDerivAt g'
      (-(lambda * (1/q)) *
        (delta * (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1:ℝ)/q - 1 - 1))
          + ((1:ℝ)/q - 1) * x ^ ((1:ℝ)/q - 1 - 1))) x :=
    h_sum.const_mul _
  -- Iterated deriv
  rw [show (2 : ℕ) = 1 + 1 from rfl, iteratedDeriv_succ, iteratedDeriv_one]
  -- Goal: deriv (deriv (fun x => h_q q lambda delta x)) x = ...
  -- Replace deriv of inner function via EventuallyEq
  rw [Filter.EventuallyEq.deriv_eq hderiv_on_nbhd]
  rw [hf'_eq_g']
  rw [h_g'.deriv]
  -- Now we need to show the algebraic identity
  -- Simplify the exponents: (1/q) - 1 = (1 - q)/q  and  (1/q) - 1 - 1 = (1 - 2q)/q
  have hexp1 : (1:ℝ)/q - 1 - 1 = (1 - 2*q) / q := by
    field_simp
    ring
  have hexp2 : (1:ℝ)/q - 1 = (1 - q) / q := by
    field_simp
  -- Substitute exponents
  rw [hexp1]
  -- coefficient simplification
  -- LHS = -(lambda * (1/q)) * (delta * (-1 * ((1/q) - 1) * (1-x)^((1-2q)/q)) + ((1/q) - 1) * x^((1-2q)/q))
  -- We want: (lambda * (q - 1) / q^2) * (x^((1-2q)/q) - delta * (1-x)^((1-2q)/q))
  have hcoef : -(lambda * (1/q)) * ((1:ℝ)/q - 1) = lambda * (q - 1) / q^2 := by
    field_simp
    ring
  -- Rewrite goal
  have lhs_simp :
      -(lambda * (1/q)) *
        (delta * (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1 - 2*q)/q))
          + ((1:ℝ)/q - 1) * x ^ ((1 - 2*q)/q))
      = (-(lambda * (1/q)) * ((1:ℝ)/q - 1)) *
        (x ^ ((1 - 2*q)/q) - delta * (1 - x) ^ ((1 - 2*q)/q)) := by
    ring
  rw [lhs_simp, hcoef]

open Workspace.ProofLemmas.DeltaStarDef

namespace Workspace.ProofLemmas.ZeqInHalfRange

noncomputable def z_func (q : ℝ) : ℝ :=
  (delta_star q) ^ (-(q / (2*q - 1))) /
    ((delta_star q) ^ (-(q / (2*q - 1))) + 1)

theorem ZeqInHalfRange (q : ℝ) (hq : 1 < q) :
    0 < z_func q ∧ z_func q ≤ 1/2 := by
  -- Use DeltaStarDef to get 1 ≤ delta_star q
  have hD : 1 ≤ delta_star q := (Workspace.ProofLemmas.DeltaStarDef.DeltaStarDef q hq).1
  have hDpos : 0 < delta_star q := lt_of_lt_of_le one_pos hD
  -- p = -(q/(2q-1)) is the exponent. Since q > 1, 2q - 1 > 1 > 0, q/(2q-1) > 0, so p < 0.
  set p : ℝ := -(q / (2*q - 1)) with hp_def
  have h2q1 : 0 < 2*q - 1 := by linarith
  have hqpos : 0 < q := lt_trans zero_lt_one hq
  have hp_neg : p < 0 := by
    rw [hp_def, neg_lt, neg_zero]
    exact div_pos hqpos h2q1
  have hp_nonpos : p ≤ 0 := le_of_lt hp_neg
  -- D^p > 0
  have hDp_pos : 0 < (delta_star q) ^ p := Real.rpow_pos_of_pos hDpos p
  -- D^p ≤ 1 since D ≥ 1 and p ≤ 0
  have hDp_le_one : (delta_star q) ^ p ≤ 1 :=
    Real.rpow_le_one_of_one_le_of_nonpos hD hp_nonpos
  -- denominator > 0
  have hDenom_pos : 0 < (delta_star q) ^ p + 1 := by linarith
  refine ⟨?_, ?_⟩
  · -- 0 < z_func q
    unfold z_func
    show 0 < (delta_star q) ^ p / ((delta_star q) ^ p + 1)
    exact div_pos hDp_pos hDenom_pos
  · -- z_func q ≤ 1/2
    unfold z_func
    show (delta_star q) ^ p / ((delta_star q) ^ p + 1) ≤ 1/2
    rw [div_le_div_iff₀ hDenom_pos (by norm_num : (0:ℝ) < 2)]
    -- Goal: D^p * 2 ≤ 1 * (D^p + 1)
    linarith

end Workspace.ProofLemmas.ZeqInHalfRange

open Workspace.ProofLemmas.FqSignAt0Pos
open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.ZeqInHalfRange

set_option maxHeartbeats 4000000

theorem UStarMinAttained (q : ℝ) (hq : 1 < q) :
    let u_star (a : ℝ) : ℝ :=
      delta_star q * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a
    (0 ≤ a_star q ∧ a_star q ≤ z_func q) ∧
      u_star (a_star q) = 0 ∧
      (∀ a, 0 ≤ a → a ≤ z_func q → 0 ≤ u_star a) := by
  -- Basic facts.
  have hAStar := AStarLessThanOneHalf q hq
  obtain ⟨hAS_pos, hAS_lt_half⟩ := hAStar
  have hAS_lt_one : a_star q < 1 := by linarith
  have hAS_one_minus_pos : 0 < 1 - a_star q := by linarith
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_inv_pos : (0 : ℝ) < 1 / q := by positivity
  have hq_inv_le_one : (1 : ℝ) / q ≤ 1 := by
    rw [div_le_one hq_pos]; linarith
  have h2qm1_pos : (0 : ℝ) < 2 * q - 1 := by linarith
  have h2qm1_ne : (2 * q - 1) ≠ 0 := ne_of_gt h2qm1_pos
  have hDS := DeltaStarDef q hq
  obtain ⟨hDS_ge_one, hDenom_pos⟩ := hDS
  have hDS_pos : 0 < delta_star q := lt_of_lt_of_le one_pos hDS_ge_one
  have hZ := ZeqInHalfRange q hq
  obtain ⟨hZ_pos, hZ_le_half⟩ := hZ
  have hZ_lt_one : z_func q < 1 := by linarith
  -- Key identity: delta_star definition.
  have h_delta_eq : delta_star q =
      ((a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q)) /
      (1 - (a_star q)) ^ ((1 : ℝ) / q) := rfl
  have hU_at_AStar :
      delta_star q * (1 - a_star q) ^ ((1 : ℝ) / q) =
      (a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q) := by
    rw [h_delta_eq]
    field_simp
  -- Now define u_star via let-intro.
  intro u_star
  show (0 ≤ a_star q ∧ a_star q ≤ z_func q) ∧
      u_star (a_star q) = 0 ∧
      (∀ a, 0 ≤ a → a ≤ z_func q → 0 ≤ u_star a)
  have hu_def : ∀ a, u_star a =
      delta_star q * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a := by
    intro a; rfl
  -- Part 2: u_star(a_star q) = 0.
  have hUStar_AStar_eq_zero : u_star (a_star q) = 0 := by
    rw [hu_def]
    linarith [hU_at_AStar]

  -- F_q(a_star q) = 0.
  have hFqAstar : F_q q (a_star q) = 0 := by
    have h := (FqHasUniqueInteriorZero q hq).2
    exact h.2.2

  -- Set up exponents.
  set p1 : ℝ := (1 - q) / q with hp1_def
  have hp1_neg : p1 < 0 := by
    rw [hp1_def]
    apply div_neg_of_neg_of_pos _ hq_pos
    linarith
  set p2 : ℝ := (1 - 2*q) / q with hp2_def
  have hp2_neg : p2 < 0 := by
    rw [hp2_def]
    apply div_neg_of_neg_of_pos _ hq_pos
    linarith
  have hp1_one_over_q : p1 = (1:ℝ)/q - 1 := by
    rw [hp1_def]; field_simp
  have hp2_eq_p1m1 : p2 = p1 - 1 := by
    rw [hp2_def, hp1_def]
    field_simp
    ring

  -- (a_star q)^p1 = 2q - 1 - 2(q-1) a_star.
  have hAStar_p1_eq : (a_star q) ^ p1 = 2*q - 1 - 2*(q-1)*(a_star q) := by
    have hFq_def : F_q q (a_star q) =
        2 * (1 - 1/q) * (a_star q) + (1/q) * (a_star q) ^ ((1 - q) / q) - 2 + 1/q := rfl
    rw [hFq_def] at hFqAstar
    have hkey : (1/q) * (a_star q) ^ ((1 - q) / q) =
        2 - 1/q - 2*(1 - 1/q)*(a_star q) := by linarith
    have h_mul_q : q * ((1/q) * (a_star q) ^ ((1 - q) / q)) =
        q * (2 - 1/q - 2*(1 - 1/q)*(a_star q)) := by
      rw [hkey]
    have hq_inv_eq : q * (1/q) = 1 := by field_simp
    have h_lhs : q * ((1/q) * (a_star q) ^ ((1 - q) / q)) = (a_star q) ^ ((1 - q) / q) := by
      rw [← mul_assoc, hq_inv_eq, one_mul]
    have h_rhs : q * (2 - 1/q - 2*(1 - 1/q)*(a_star q)) =
        2*q - 1 - 2*(q-1)*(a_star q) := by
      field_simp
    rw [h_lhs] at h_mul_q
    rw [h_mul_q, h_rhs]

  -- (a*)^(1/q) = (2q-1)*a* - 2(q-1)*a*^2.
  have hAStar_one_over_q : (a_star q) ^ ((1 : ℝ) / q) =
      (2*q - 1) * (a_star q) - 2*(q-1) * (a_star q)^2 := by
    have hid : (a_star q) ^ p1 * (a_star q) = (a_star q) ^ ((1 : ℝ) / q) := by
      have hsum : p1 + 1 = (1 : ℝ) / q := by
        rw [hp1_def]; field_simp; ring
      have hadd := Real.rpow_add hAS_pos p1 1
      rw [Real.rpow_one] at hadd
      rw [← hadd, hsum]
    rw [← hid, hAStar_p1_eq]
    ring

  -- (8b): delta_star * (1-a*)^p1 + (a*)^p1 = 2q.
  have h8b : delta_star q * (1 - a_star q) ^ p1 + (a_star q) ^ p1 = 2 * q := by
    have hid_1ma : (1 - a_star q) ^ p1 * (1 - a_star q) = (1 - a_star q) ^ ((1 : ℝ) / q) := by
      have hsum : p1 + 1 = (1 : ℝ) / q := by
        rw [hp1_def]; field_simp; ring
      have hadd := Real.rpow_add hAS_one_minus_pos p1 1
      rw [Real.rpow_one] at hadd
      rw [← hadd, hsum]
    have h1ma_ne : (1 - a_star q) ≠ 0 := ne_of_gt hAS_one_minus_pos
    have hpow_p1_pos : 0 < (1 - a_star q) ^ p1 := Real.rpow_pos_of_pos hAS_one_minus_pos p1
    have step1 : delta_star q * (1 - a_star q) ^ p1 * (1 - a_star q) =
        (a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q) := by
      rw [mul_assoc, hid_1ma, hU_at_AStar]
    have step2 : delta_star q * (1 - a_star q) ^ p1 =
        ((a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q)) / (1 - a_star q) := by
      rw [eq_div_iff h1ma_ne]
      exact step1
    rw [step2, hAStar_one_over_q, hAStar_p1_eq]
    field_simp
    ring

  -- ψ(x) = x^p2 - delta_star * (1-x)^p2.
  set psi : ℝ → ℝ := fun x => x ^ p2 - delta_star q * (1 - x) ^ p2 with hpsi_def

  -- ψ strictly antitone on (0, 1).
  have hpsi_anti : StrictAntiOn psi (Set.Ioo (0:ℝ) 1) := by
    intro x hx y hy hxy
    have hx_pos : 0 < x := hx.1
    have hy_pos : 0 < y := hy.1
    have h1my_pos : 0 < 1 - y := by linarith [hy.2]
    have hxp2 : y ^ p2 < x ^ p2 :=
      Real.rpow_lt_rpow_of_exponent_neg hx_pos hxy hp2_neg
    have h1mxy : 1 - y < 1 - x := by linarith
    have h1m_p2 : (1 - x) ^ p2 < (1 - y) ^ p2 :=
      Real.rpow_lt_rpow_of_exponent_neg h1my_pos h1mxy hp2_neg
    have hd_mul : delta_star q * (1 - x) ^ p2 < delta_star q * (1 - y) ^ p2 :=
      mul_lt_mul_of_pos_left h1m_p2 hDS_pos
    show psi y < psi x
    rw [hpsi_def]
    show y ^ p2 - delta_star q * (1 - y) ^ p2 < x ^ p2 - delta_star q * (1 - x) ^ p2
    linarith

  -- ψ(z_func) = 0.
  have hpsi_zfunc : psi (z_func q) = 0 := by
    set D : ℝ := (delta_star q) ^ (-(q / (2*q - 1))) with hD_def
    have hD_pos : 0 < D := Real.rpow_pos_of_pos hDS_pos _
    have hDenom_pos2 : 0 < D + 1 := by linarith
    have hDenom_ne : D + 1 ≠ 0 := ne_of_gt hDenom_pos2
    have hz_form : z_func q = D / (D + 1) := rfl
    have hone_minus_z : 1 - z_func q = 1 / (D + 1) := by
      rw [hz_form, eq_div_iff hDenom_ne]
      field_simp
      ring
    have hone_minus_z_pos : 0 < 1 - z_func q := by
      rw [hone_minus_z]; positivity
    have hp_p2 : -(q / (2*q - 1)) * p2 = 1 := by
      rw [hp2_def]
      have hne : (2*q - 1) * q ≠ 0 := mul_ne_zero h2qm1_ne hq_ne
      have hstep : -(q / (2*q - 1)) * ((1 - 2*q) / q) =
             (-q * (1 - 2*q)) / ((2*q - 1) * q) := by
        rw [neg_mul, div_mul_div_comm]
        congr 1
        ring
      rw [hstep, div_eq_iff hne]
      ring
    have h_z_p2 : (z_func q) ^ p2 = D ^ p2 / (D + 1) ^ p2 := by
      rw [hz_form]
      exact Real.div_rpow (le_of_lt hD_pos) (le_of_lt hDenom_pos2) p2
    have h_1mz_p2 : (1 - z_func q) ^ p2 = 1 / (D + 1) ^ p2 := by
      rw [hone_minus_z]
      rw [Real.div_rpow (by norm_num) (le_of_lt hDenom_pos2), Real.one_rpow]
    have hD_p2 : D ^ p2 = delta_star q := by
      rw [hD_def]
      rw [← Real.rpow_mul (le_of_lt hDS_pos), hp_p2, Real.rpow_one]
    show (z_func q) ^ p2 - delta_star q * (1 - z_func q) ^ p2 = 0
    rw [h_z_p2, h_1mz_p2, hD_p2]
    have hDpow_ne : (D + 1) ^ p2 ≠ 0 :=
      ne_of_gt (Real.rpow_pos_of_pos hDenom_pos2 p2)
    field_simp
    ring

  -- ψ(a_star) > 0.
  have hAStar_p2 : (a_star q) ^ p2 = (a_star q) ^ p1 / (a_star q) := by
    rw [hp2_eq_p1m1]
    rw [show p1 - 1 = p1 + (-1) by ring]
    rw [Real.rpow_add hAS_pos]
    rw [Real.rpow_neg_one]
    rw [div_eq_mul_inv]
  have h1mAStar_p2 : (1 - a_star q) ^ p2 = (1 - a_star q) ^ p1 / (1 - a_star q) := by
    rw [hp2_eq_p1m1]
    rw [show p1 - 1 = p1 + (-1) by ring]
    rw [Real.rpow_add hAS_one_minus_pos]
    rw [Real.rpow_neg_one]
    rw [div_eq_mul_inv]
  have hprod_pos : 0 < (a_star q) * (1 - a_star q) := mul_pos hAS_pos hAS_one_minus_pos
  have hpsi_AStar_eq :
      psi (a_star q) =
      (2*q - 1) * (1 - 2 * (a_star q)) / ((a_star q) * (1 - a_star q)) := by
    show (a_star q) ^ p2 - delta_star q * (1 - a_star q) ^ p2 =
        (2*q - 1) * (1 - 2 * (a_star q)) / ((a_star q) * (1 - a_star q))
    rw [hAStar_p2, h1mAStar_p2]
    rw [mul_div_assoc']
    have h8b' : delta_star q * (1 - a_star q) ^ p1 = 2 * q - (a_star q) ^ p1 := by
      linarith [h8b]
    rw [h8b']
    rw [hAStar_p1_eq]
    field_simp
    ring
  have hpsi_AStar_pos : 0 < psi (a_star q) := by
    rw [hpsi_AStar_eq]
    apply div_pos
    · apply mul_pos
      · linarith
      · linarith
    · exact hprod_pos

  -- Hence a_star q < z_func q.
  have hAStar_lt_zfunc : a_star q < z_func q := by
    by_contra h
    push_neg at h
    rcases eq_or_lt_of_le h with heq | hlt
    · rw [← heq] at hpsi_AStar_pos
      rw [hpsi_zfunc] at hpsi_AStar_pos
      linarith
    · have hzfunc_in : z_func q ∈ Set.Ioo (0:ℝ) 1 := ⟨hZ_pos, hZ_lt_one⟩
      have hAStar_in : a_star q ∈ Set.Ioo (0:ℝ) 1 := ⟨hAS_pos, hAS_lt_one⟩
      have := hpsi_anti hzfunc_in hAStar_in hlt
      rw [hpsi_zfunc] at this
      linarith

  have hAStar_le_zfunc : a_star q ≤ z_func q := le_of_lt hAStar_lt_zfunc

  refine ⟨⟨le_of_lt hAS_pos, hAStar_le_zfunc⟩, hUStar_AStar_eq_zero, ?_⟩

  -- Part 3: ∀ a ∈ [0, z_func q], 0 ≤ u_star a.

  intro a ha_nn ha_le_z

  -- Define u : ℝ → ℝ explicitly.
  set u : ℝ → ℝ := fun a =>
    delta_star q * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a with hu_eq

  have hu_eq_ustar : ∀ x, u x = u_star x := by
    intro x
    show delta_star q * (1 - x) ^ ((1 : ℝ) / q) - x ^ ((1 : ℝ) / q) - 1 + 2 * x = u_star x
    rw [hu_def]

  -- ContinuousOn u on [0, z_func q].
  have h_cont : ContinuousOn u (Set.Icc (0:ℝ) (z_func q)) := by
    intro x hx
    have hx_le_z : x ≤ z_func q := hx.2
    have hx_lt_one : x < 1 := lt_of_le_of_lt hx_le_z hZ_lt_one
    have h1mx_pos : 0 < 1 - x := by linarith
    have hx_nn : 0 ≤ x := hx.1
    have h_inner : ContinuousAt (fun y : ℝ => 1 - y) x :=
      (continuous_const.sub continuous_id).continuousAt
    have h_outer : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/q)) (1 - x) :=
      Real.continuousAt_rpow_const (1 - x) ((1:ℝ)/q) (Or.inl (ne_of_gt h1mx_pos))
    have h_1mx_pow : ContinuousAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/q)) x :=
      h_outer.comp h_inner
    have h_d_1mx_pow : ContinuousAt (fun y : ℝ => delta_star q * (1 - y) ^ ((1:ℝ)/q)) x :=
      h_1mx_pow.const_mul (delta_star q)
    have h_x_pow : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/q)) x :=
      Real.continuousAt_rpow_const x ((1:ℝ)/q) (Or.inr (le_of_lt hq_inv_pos))
    have h_diff : ContinuousAt
        (fun y : ℝ => delta_star q * (1 - y) ^ ((1:ℝ)/q) - y ^ ((1:ℝ)/q)) x :=
      h_d_1mx_pow.sub h_x_pow
    have h_diff_const : ContinuousAt
        (fun y : ℝ => delta_star q * (1 - y) ^ ((1:ℝ)/q) - y ^ ((1:ℝ)/q) - 1) x :=
      h_diff.sub continuousAt_const
    have h_lin : ContinuousAt (fun y : ℝ => 2 * y) x :=
      (continuous_const.mul continuous_id).continuousAt
    have h_total : ContinuousAt u x := by
      simp only [hu_eq]
      exact h_diff_const.add h_lin
    exact h_total.continuousWithinAt

  -- Derivative of u on (0, 1).
  have h_deriv : ∀ y, 0 < y → y < 1 →
      HasDerivAt u (-(delta_star q) / q * (1 - y) ^ p1 - (1/q) * y ^ p1 + 2) y := by
    intro y hy hy1
    have hy_ne : y ≠ 0 := ne_of_gt hy
    have h1my_pos : 0 < 1 - y := by linarith
    have h1my_ne : 1 - y ≠ 0 := ne_of_gt h1my_pos
    have hd_y_pow : HasDerivAt (fun z : ℝ => z ^ ((1:ℝ)/q)) ((1/q) * y ^ p1) y := by
      have h := Real.hasDerivAt_rpow_const (p := (1:ℝ)/q) (x := y) (Or.inl hy_ne)
      have heq : ((1:ℝ)/q) - 1 = p1 := by
        rw [hp1_def]; field_simp
      rw [heq] at h
      exact h
    have hd_inner : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) y := by
      simpa using (hasDerivAt_id y).const_sub 1
    have hd_1my_pow : HasDerivAt (fun z : ℝ => (1 - z) ^ ((1:ℝ)/q))
        ((1/q) * (1 - y) ^ p1 * (-1)) y := by
      have h := Real.hasDerivAt_rpow_const (p := (1:ℝ)/q) (x := 1 - y) (Or.inl h1my_ne)
      have heq : ((1:ℝ)/q) - 1 = p1 := by
        rw [hp1_def]; field_simp
      rw [heq] at h
      exact h.comp y hd_inner
    have hd_d_1my : HasDerivAt (fun z : ℝ => delta_star q * (1 - z) ^ ((1:ℝ)/q))
        (delta_star q * ((1/q) * (1 - y) ^ p1 * (-1))) y :=
      hd_1my_pow.const_mul (delta_star q)
    have hd_diff : HasDerivAt
        (fun z : ℝ => delta_star q * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q))
        (delta_star q * ((1/q) * (1 - y) ^ p1 * (-1)) - (1/q) * y ^ p1) y :=
      hd_d_1my.sub hd_y_pow
    have hd_diff_const : HasDerivAt
        (fun z : ℝ => delta_star q * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q) - 1)
        (delta_star q * ((1/q) * (1 - y) ^ p1 * (-1)) - (1/q) * y ^ p1) y :=
      hd_diff.sub_const 1
    have hd_lin : HasDerivAt (fun z : ℝ => 2 * z) (2 : ℝ) y := by
      simpa using (hasDerivAt_id y).const_mul 2
    have hd_total :
        HasDerivAt u
          (delta_star q * ((1/q) * (1 - y) ^ p1 * (-1)) - (1/q) * y ^ p1 + 2) y := by
      simp only [hu_eq]
      exact hd_diff_const.add hd_lin
    have heq_d :
        delta_star q * ((1/q) * (1 - y) ^ p1 * (-1)) - (1/q) * y ^ p1 + 2 =
        -(delta_star q) / q * (1 - y) ^ p1 - (1/q) * y ^ p1 + 2 := by
      field_simp
    rw [heq_d] at hd_total
    exact hd_total

  -- u'(a_star q) = 0.
  have h_uPrime_AStar :
      -(delta_star q) / q * (1 - a_star q) ^ p1 - (1/q) * (a_star q) ^ p1 + 2 = 0 := by
    have h := h8b
    have heq : -(delta_star q) / q * (1 - a_star q) ^ p1 - (1/q) * (a_star q) ^ p1 + 2 =
        -(1/q) * (delta_star q * (1 - a_star q) ^ p1 + (a_star q) ^ p1) + 2 := by
      field_simp
      ring
    rw [heq, h]
    field_simp
    ring

  have h_uPrime_AStar_zero : HasDerivAt u 0 (a_star q) := by
    have h := h_deriv (a_star q) hAS_pos hAS_lt_one
    rw [h_uPrime_AStar] at h
    exact h

  -- Second derivative of u on (0, 1).
  have h_deriv2 : ∀ y, 0 < y → y < 1 →
      HasDerivAt (fun y => -(delta_star q) / q * (1 - y) ^ p1 - (1/q) * y ^ p1 + 2)
        ((p1/q) * (delta_star q * (1 - y) ^ p2 - y ^ p2)) y := by
    intro y hy hy1
    have hy_ne : y ≠ 0 := ne_of_gt hy
    have h1my_pos : 0 < 1 - y := by linarith
    have h1my_ne : 1 - y ≠ 0 := ne_of_gt h1my_pos
    have hd_y_p1 : HasDerivAt (fun z : ℝ => z ^ p1) (p1 * y ^ p2) y := by
      have h := Real.hasDerivAt_rpow_const (p := p1) (x := y) (Or.inl hy_ne)
      have heq : p1 - 1 = p2 := by rw [hp1_def, hp2_def]; field_simp; ring
      rw [heq] at h
      exact h
    have hd_inner : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) y := by
      simpa using (hasDerivAt_id y).const_sub 1
    have hd_1my_p1 : HasDerivAt (fun z : ℝ => (1 - z) ^ p1) (p1 * (1 - y) ^ p2 * (-1)) y := by
      have h := Real.hasDerivAt_rpow_const (p := p1) (x := 1 - y) (Or.inl h1my_ne)
      have heq : p1 - 1 = p2 := by rw [hp1_def, hp2_def]; field_simp; ring
      rw [heq] at h
      exact h.comp y hd_inner
    have hd_part1 : HasDerivAt (fun z : ℝ => -(delta_star q) / q * (1 - z) ^ p1)
        (-(delta_star q) / q * (p1 * (1 - y) ^ p2 * (-1))) y :=
      hd_1my_p1.const_mul (-(delta_star q) / q)
    have hd_part2 : HasDerivAt (fun z : ℝ => (1/q) * z ^ p1) ((1/q) * (p1 * y ^ p2)) y :=
      hd_y_p1.const_mul (1/q)
    have hd_sub : HasDerivAt
        (fun z : ℝ => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1)
        (-(delta_star q) / q * (p1 * (1 - y) ^ p2 * (-1)) - (1/q) * (p1 * y ^ p2)) y :=
      hd_part1.sub hd_part2
    have hd_total := hd_sub.add_const (2 : ℝ)
    have heq_simp :
        -(delta_star q) / q * (p1 * (1 - y) ^ p2 * (-1)) - (1/q) * (p1 * y ^ p2) =
        (p1/q) * (delta_star q * (1 - y) ^ p2 - y ^ p2) := by
      field_simp
    rw [heq_simp] at hd_total
    exact hd_total

  -- u'' ≥ 0 on (0, z_func q).
  have h_uSecond_nn : ∀ y, 0 < y → y < z_func q →
      0 ≤ (p1/q) * (delta_star q * (1 - y) ^ p2 - y ^ p2) := by
    intro y hy_pos hy_lt_z
    have hy_lt_one : y < 1 := lt_trans hy_lt_z hZ_lt_one
    have hpsi_y_pos : 0 < y ^ p2 - delta_star q * (1 - y) ^ p2 := by
      have hy_in : y ∈ Set.Ioo (0:ℝ) 1 := ⟨hy_pos, hy_lt_one⟩
      have hz_in : z_func q ∈ Set.Ioo (0:ℝ) 1 := ⟨hZ_pos, hZ_lt_one⟩
      have h_anti := hpsi_anti hy_in hz_in hy_lt_z
      -- h_anti : psi (z_func q) < psi y, i.e. fun-eval form
      have hpsi_y_val : psi y = y ^ p2 - delta_star q * (1 - y) ^ p2 := rfl
      have hpsi_z_val : psi (z_func q) =
          (z_func q) ^ p2 - delta_star q * (1 - z_func q) ^ p2 := rfl
      have h_anti' : psi (z_func q) < psi y := h_anti
      rw [hpsi_zfunc, hpsi_y_val] at h_anti'
      exact h_anti'
    have hp1_q_neg : p1 / q < 0 := div_neg_of_neg_of_pos hp1_neg hq_pos
    have hbracket_neg : delta_star q * (1 - y) ^ p2 - y ^ p2 < 0 := by linarith
    have h_pos : 0 < (p1/q) * (delta_star q * (1 - y) ^ p2 - y ^ p2) :=
      mul_pos_of_neg_of_neg hp1_q_neg hbracket_neg
    linarith

  -- ConvexOn u on [0, z_func q].
  have hConvexIcc : Convex ℝ (Set.Icc (0:ℝ) (z_func q)) := convex_Icc 0 (z_func q)
  have h_int : interior (Set.Icc (0:ℝ) (z_func q)) = Set.Ioo 0 (z_func q) := interior_Icc
  have hConv_u : ConvexOn ℝ (Set.Icc (0:ℝ) (z_func q)) u := by
    apply convexOn_of_deriv2_nonneg hConvexIcc h_cont
    · rw [h_int]
      intro y hy
      have hy_pos : 0 < y := hy.1
      have hy_lt_z : y < z_func q := hy.2
      have hy_lt_one : y < 1 := lt_trans hy_lt_z hZ_lt_one
      exact (h_deriv y hy_pos hy_lt_one).differentiableAt.differentiableWithinAt
    · rw [h_int]
      intro y hy
      have hy_pos : 0 < y := hy.1
      have hy_lt_z : y < z_func q := hy.2
      have hy_lt_one : y < 1 := lt_trans hy_lt_z hZ_lt_one
      have hopen : IsOpen (Set.Ioo (0:ℝ) (z_func q)) := isOpen_Ioo
      have hnhds : Set.Ioo (0:ℝ) (z_func q) ∈ nhds y := hopen.mem_nhds hy
      have hloc : deriv u =ᶠ[nhds y]
          fun z => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1 + 2 := by
        filter_upwards [hnhds] with z hz
        exact (h_deriv z hz.1 (lt_trans hz.2 hZ_lt_one)).deriv
      have hd2 : DifferentiableAt ℝ
          (fun z : ℝ => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1 + 2) y :=
        (h_deriv2 y hy_pos hy_lt_one).differentiableAt
      have hd_local : DifferentiableAt ℝ (deriv u) y :=
        hd2.congr_of_eventuallyEq hloc
      exact hd_local.differentiableWithinAt
    · rw [h_int]
      intro y hy
      simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
      have hy_pos : 0 < y := hy.1
      have hy_lt_z : y < z_func q := hy.2
      have hy_lt_one : y < 1 := lt_trans hy_lt_z hZ_lt_one
      have hopen : IsOpen (Set.Ioo (0:ℝ) (z_func q)) := isOpen_Ioo
      have hnhds : Set.Ioo (0:ℝ) (z_func q) ∈ nhds y := hopen.mem_nhds hy
      have hloc : deriv u =ᶠ[nhds y]
          fun z => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1 + 2 := by
        filter_upwards [hnhds] with z hz
        exact (h_deriv z hz.1 (lt_trans hz.2 hZ_lt_one)).deriv
      have hd2_eq : deriv (deriv u) y =
          deriv (fun z => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1 + 2) y :=
        hloc.deriv_eq
      rw [hd2_eq, (h_deriv2 y hy_pos hy_lt_one).deriv]
      exact h_uSecond_nn y hy_pos hy_lt_z

  -- a_star q is in interior of [0, z_func q].
  have hAS_in_Ioo : a_star q ∈ Set.Ioo (0:ℝ) (z_func q) := ⟨hAS_pos, hAStar_lt_zfunc⟩
  have hAS_in_int : a_star q ∈ interior (Set.Icc (0:ℝ) (z_func q)) := by
    rw [h_int]; exact hAS_in_Ioo

  -- derivWithin u (Ioi a_star q) (a_star q) = 0.
  have h_derivWithin : derivWithin u (Set.Ioi (a_star q)) (a_star q) = 0 := by
    have h := h_uPrime_AStar_zero.hasDerivWithinAt
        (s := Set.Ioi (a_star q))
    exact h.derivWithin (uniqueDiffWithinAt_Ioi (a_star q))

  -- Apply ConvexOn.isMinOn_of_rightDeriv_eq_zero.
  have h_isMinOn : IsMinOn u (Set.Icc (0:ℝ) (z_func q)) (a_star q) :=
    hConv_u.isMinOn_of_rightDeriv_eq_zero hAS_in_int h_derivWithin

  -- Apply at a.
  have ha_in_Icc : a ∈ Set.Icc (0:ℝ) (z_func q) := ⟨ha_nn, ha_le_z⟩
  have h_min_raw := h_isMinOn ha_in_Icc
  -- h_min_raw : u (a_star q) ≤ u a (in setOf form)
  have h_min : u (a_star q) ≤ u a := h_min_raw
  have hu_AStar_zero : u (a_star q) = 0 := by
    rw [hu_eq_ustar]; exact hUStar_AStar_eq_zero
  rw [hu_AStar_zero] at h_min
  -- h_min : 0 ≤ u a.
  have hua_eq : u a = u_star a := hu_eq_ustar a
  linarith

open Workspace.ProofLemmas.HSecondDerivative
open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.LambdaStarDef
open Workspace.ProofLemmas.LambdaDeltaIdentity
open Workspace.ProofLemmas.ZeqInHalfRange

set_option maxHeartbeats 4000000

namespace Workspace.ProofLemmas.RelaxedCoreDual

/-- Bridge identity `delta_of_lambda q (lambda_star q) = delta_star q` (pure rpow algebra
from the definitions; self-contained so this file does not need to import the
duplication/limit assembly). -/
theorem deltaOfLambda_lambdaStar_eq (q : ℝ) (hq : 1 < q) :
    delta_of_lambda q (lambda_star q) = delta_star q := by
  have hq1 : q ≠ 1 := ne_of_gt hq
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hqm1_pos : 0 < q - 1 := by linarith
  have hqm1_ne : q - 1 ≠ 0 := ne_of_gt hqm1_pos
  have hDS_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
  have hDS_pos : 0 < delta_star q := lt_of_lt_of_le one_pos hDS_ge_one
  have hDS_nn : 0 ≤ delta_star q := le_of_lt hDS_pos
  set r : ℝ := q / (q - 1) with hr_def
  have hr_pos : 0 < r := div_pos hq_pos hqm1_pos
  set e : ℝ := (q - 1) / q with he_def
  have he_pos : 0 < e := div_pos hqm1_pos hq_pos
  have hDSr_pos : 0 < (delta_star q) ^ r := Real.rpow_pos_of_pos hDS_pos r
  have hDSr_nn : 0 ≤ (delta_star q) ^ r := le_of_lt hDSr_pos
  set B : ℝ := 1 + (delta_star q) ^ r with hB_def
  have hB_pos : 0 < B := by rw [hB_def]; linarith
  have hB_nn : 0 ≤ B := le_of_lt hB_pos
  have hlam_unfold : lambda_star q = B ^ (-e) := by
    unfold lambda_star
    rw [if_neg hq1, if_pos hq]
  have her : e * r = 1 := by rw [he_def, hr_def]; field_simp
  have h_pow_pow : (B ^ (-e)) ^ (-r) = B := by
    rw [← Real.rpow_mul hB_nn]
    have : (-e) * (-r) = 1 := by rw [neg_mul_neg, her]
    rw [this, Real.rpow_one]
  unfold delta_of_lambda
  rw [hlam_unfold]
  rw [← hr_def, ← he_def, h_pow_pow]
  have hB_sub : B - 1 = (delta_star q) ^ r := by rw [hB_def]; ring
  rw [hB_sub, ← Real.rpow_mul hDS_nn, mul_comm r e, her, Real.rpow_one]

/-- The supporting-line / dual potential `u(a) = δ*·(1-a)^{1/q} - a^{1/q} - 1 + 2a`. -/
noncomputable def u_dual (q a : ℝ) : ℝ :=
  delta_star q * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a

/-- On `[0, z_func q]`, `u(a) ≥ 0` is exactly `UStarMinAttained`. -/
theorem u_dual_nonneg_left (q : ℝ) (hq : 1 < q) (a : ℝ) (ha0 : 0 ≤ a)
    (ha_le_z : a ≤ z_func q) : 0 ≤ u_dual q a := by
  have hU := UStarMinAttained q hq
  exact hU.2.2 a ha0 ha_le_z

/-- `u(1) = 0`. -/
theorem u_dual_at_one (q : ℝ) (hq : 1 < q) : u_dual q 1 = 0 := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : (1 : ℝ) / q ≠ 0 := by positivity
  show delta_star q * (1 - 1) ^ ((1 : ℝ) / q) - (1 : ℝ) ^ ((1 : ℝ) / q) - 1 + 2 * 1 = 0
  rw [show (1 : ℝ) - 1 = 0 by ring, Real.zero_rpow hq_ne, Real.one_rpow]
  ring

/-- KEY LEMMA: `u(a) ≥ 0` for all `a ∈ [0,1]` at `q > 1`. -/
theorem u_dual_nonneg (q : ℝ) (hq : 1 < q) (a : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1) :
    0 ≤ u_dual q a := by
  -- Basic facts
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hDS_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
  have hDS_pos : 0 < delta_star q := lt_of_lt_of_le one_pos hDS_ge_one
  have hZ := ZeqInHalfRange q hq
  obtain ⟨hZ_pos, hZ_le_half⟩ := hZ
  have hZ_lt_one : z_func q < 1 := by linarith
  -- Split at z_func q.
  rcases le_or_gt a (z_func q) with ha_le_z | ha_gt_z
  · exact u_dual_nonneg_left q hq a ha0 ha_le_z
  -- Now z_func q < a ≤ 1.  Use concavity on [z_func q, 1].
  -- Exponents.
  set p1 : ℝ := (1 - q) / q with hp1_def
  have hp1_neg : p1 < 0 := by
    rw [hp1_def]; apply div_neg_of_neg_of_pos _ hq_pos; linarith
  set p2 : ℝ := (1 - 2*q) / q with hp2_def
  have hp2_neg : p2 < 0 := by
    rw [hp2_def]; apply div_neg_of_neg_of_pos _ hq_pos; linarith
  -- ψ(x) = x^p2 - δ* (1-x)^p2, strictly antitone on (0,1); ψ(z_func q) = 0.
  set psi : ℝ → ℝ := fun x => x ^ p2 - delta_star q * (1 - x) ^ p2 with hpsi_def
  have hpsi_anti : StrictAntiOn psi (Set.Ioo (0:ℝ) 1) := by
    intro xx hxx yy hyy hxy
    have hx_pos : 0 < xx := hxx.1
    have hy_pos : 0 < yy := hyy.1
    have h1my_pos : 0 < 1 - yy := by linarith [hyy.2]
    have hxp2 : yy ^ p2 < xx ^ p2 :=
      Real.rpow_lt_rpow_of_neg hx_pos hxy hp2_neg
    have h1mxy : 1 - yy < 1 - xx := by linarith
    have h1m_p2 : (1 - xx) ^ p2 < (1 - yy) ^ p2 :=
      Real.rpow_lt_rpow_of_neg h1my_pos h1mxy hp2_neg
    have hd_mul : delta_star q * (1 - xx) ^ p2 < delta_star q * (1 - yy) ^ p2 :=
      mul_lt_mul_of_pos_left h1m_p2 hDS_pos
    show yy ^ p2 - delta_star q * (1 - yy) ^ p2 < xx ^ p2 - delta_star q * (1 - xx) ^ p2
    linarith
  -- ψ(z_func q) = 0  (replicated from UStarMinAttained.hpsi_zfunc).
  have h2qm1_pos : (0 : ℝ) < 2 * q - 1 := by linarith
  have h2qm1_ne : (2 * q - 1) ≠ 0 := ne_of_gt h2qm1_pos
  have hpsi_zfunc : psi (z_func q) = 0 := by
    set D : ℝ := (delta_star q) ^ (-(q / (2*q - 1))) with hD_def
    have hD_pos : 0 < D := Real.rpow_pos_of_pos hDS_pos _
    have hDenom_pos : 0 < D + 1 := by linarith
    have hDenom_ne : D + 1 ≠ 0 := ne_of_gt hDenom_pos
    have hz_form : z_func q = D / (D + 1) := rfl
    have hone_minus_z : 1 - z_func q = 1 / (D + 1) := by
      rw [hz_form, eq_div_iff hDenom_ne]; field_simp; ring
    have hp_p2 : -(q / (2*q - 1)) * p2 = 1 := by
      rw [hp2_def]
      have hne : (2*q - 1) * q ≠ 0 := mul_ne_zero h2qm1_ne hq_ne
      have hstep : -(q / (2*q - 1)) * ((1 - 2*q) / q) =
             (-q * (1 - 2*q)) / ((2*q - 1) * q) := by
        rw [neg_mul, div_mul_div_comm]; ring
      rw [hstep, div_eq_iff hne]; ring
    have h_z_p2 : (z_func q) ^ p2 = D ^ p2 / (D + 1) ^ p2 := by
      rw [hz_form]; exact Real.div_rpow (le_of_lt hD_pos) (le_of_lt hDenom_pos) p2
    have h_1mz_p2 : (1 - z_func q) ^ p2 = 1 / (D + 1) ^ p2 := by
      rw [hone_minus_z, Real.div_rpow (by norm_num) (le_of_lt hDenom_pos), Real.one_rpow]
    have hD_p2 : D ^ p2 = delta_star q := by
      rw [hD_def, ← Real.rpow_mul (le_of_lt hDS_pos), hp_p2, Real.rpow_one]
    show (z_func q) ^ p2 - delta_star q * (1 - z_func q) ^ p2 = 0
    rw [h_z_p2, h_1mz_p2, hD_p2]
    have hDpow_ne : (D + 1) ^ p2 ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hDenom_pos p2)
    field_simp; ring
  -- Define u as a function for derivative work.
  set u : ℝ → ℝ := fun a => u_dual q a with hu_eq
  have hu_def : ∀ a, u a =
      delta_star q * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a := by
    intro a; rfl
  -- First derivative of u on (0,1).
  have h_deriv : ∀ y, 0 < y → y < 1 →
      HasDerivAt u (-(delta_star q) / q * (1 - y) ^ p1 - (1/q) * y ^ p1 + 2) y := by
    intro y hy hy1
    have hy_ne : y ≠ 0 := ne_of_gt hy
    have h1my_pos : 0 < 1 - y := by linarith
    have h1my_ne : 1 - y ≠ 0 := ne_of_gt h1my_pos
    have hd_y_pow : HasDerivAt (fun z : ℝ => z ^ ((1:ℝ)/q)) ((1/q) * y ^ p1) y := by
      have h := Real.hasDerivAt_rpow_const (p := (1:ℝ)/q) (x := y) (Or.inl hy_ne)
      have heq : ((1:ℝ)/q) - 1 = p1 := by rw [hp1_def]; field_simp
      rw [heq] at h; exact h
    have hd_inner : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) y := by
      simpa using (hasDerivAt_id y).const_sub 1
    have hd_1my_pow : HasDerivAt (fun z : ℝ => (1 - z) ^ ((1:ℝ)/q))
        ((1/q) * (1 - y) ^ p1 * (-1)) y := by
      have h := Real.hasDerivAt_rpow_const (p := (1:ℝ)/q) (x := 1 - y) (Or.inl h1my_ne)
      have heq : ((1:ℝ)/q) - 1 = p1 := by rw [hp1_def]; field_simp
      rw [heq] at h; exact h.comp y hd_inner
    have hd_d_1my : HasDerivAt (fun z : ℝ => delta_star q * (1 - z) ^ ((1:ℝ)/q))
        (delta_star q * ((1/q) * (1 - y) ^ p1 * (-1))) y :=
      hd_1my_pow.const_mul (delta_star q)
    have hd_diff : HasDerivAt
        (fun z : ℝ => delta_star q * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q))
        (delta_star q * ((1/q) * (1 - y) ^ p1 * (-1)) - (1/q) * y ^ p1) y :=
      hd_d_1my.sub hd_y_pow
    have hd_diff_const : HasDerivAt
        (fun z : ℝ => delta_star q * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q) - 1)
        (delta_star q * ((1/q) * (1 - y) ^ p1 * (-1)) - (1/q) * y ^ p1) y :=
      hd_diff.sub_const 1
    have hd_lin : HasDerivAt (fun z : ℝ => 2 * z) (2 : ℝ) y := by
      simpa using (hasDerivAt_id y).const_mul 2
    have hd_total :
        HasDerivAt u
          (delta_star q * ((1/q) * (1 - y) ^ p1 * (-1)) - (1/q) * y ^ p1 + 2) y := by
      simp only [hu_eq]
      exact hd_diff_const.add hd_lin
    have heq_d :
        delta_star q * ((1/q) * (1 - y) ^ p1 * (-1)) - (1/q) * y ^ p1 + 2 =
        -(delta_star q) / q * (1 - y) ^ p1 - (1/q) * y ^ p1 + 2 := by field_simp
    rw [heq_d] at hd_total; exact hd_total
  -- Second derivative of u on (0,1).
  have h_deriv2 : ∀ y, 0 < y → y < 1 →
      HasDerivAt (fun y => -(delta_star q) / q * (1 - y) ^ p1 - (1/q) * y ^ p1 + 2)
        ((p1/q) * (delta_star q * (1 - y) ^ p2 - y ^ p2)) y := by
    intro y hy hy1
    have hy_ne : y ≠ 0 := ne_of_gt hy
    have h1my_pos : 0 < 1 - y := by linarith
    have h1my_ne : 1 - y ≠ 0 := ne_of_gt h1my_pos
    have hd_y_p1 : HasDerivAt (fun z : ℝ => z ^ p1) (p1 * y ^ p2) y := by
      have h := Real.hasDerivAt_rpow_const (p := p1) (x := y) (Or.inl hy_ne)
      have heq : p1 - 1 = p2 := by rw [hp1_def, hp2_def]; field_simp; ring
      rw [heq] at h; exact h
    have hd_inner : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) y := by
      simpa using (hasDerivAt_id y).const_sub 1
    have hd_1my_p1 : HasDerivAt (fun z : ℝ => (1 - z) ^ p1) (p1 * (1 - y) ^ p2 * (-1)) y := by
      have h := Real.hasDerivAt_rpow_const (p := p1) (x := 1 - y) (Or.inl h1my_ne)
      have heq : p1 - 1 = p2 := by rw [hp1_def, hp2_def]; field_simp; ring
      rw [heq] at h; exact h.comp y hd_inner
    have hd_part1 : HasDerivAt (fun z : ℝ => -(delta_star q) / q * (1 - z) ^ p1)
        (-(delta_star q) / q * (p1 * (1 - y) ^ p2 * (-1))) y :=
      hd_1my_p1.const_mul (-(delta_star q) / q)
    have hd_part2 : HasDerivAt (fun z : ℝ => (1/q) * z ^ p1) ((1/q) * (p1 * y ^ p2)) y :=
      hd_y_p1.const_mul (1/q)
    have hd_sub : HasDerivAt
        (fun z : ℝ => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1)
        (-(delta_star q) / q * (p1 * (1 - y) ^ p2 * (-1)) - (1/q) * (p1 * y ^ p2)) y :=
      hd_part1.sub hd_part2
    have hd_total := hd_sub.add_const (2 : ℝ)
    have heq_simp :
        -(delta_star q) / q * (p1 * (1 - y) ^ p2 * (-1)) - (1/q) * (p1 * y ^ p2) =
        (p1/q) * (delta_star q * (1 - y) ^ p2 - y ^ p2) := by field_simp
    rw [heq_simp] at hd_total; exact hd_total
  -- u'' ≤ 0 on (z_func q, 1).
  have h_uSecond_np : ∀ y, z_func q < y → y < 1 →
      (p1/q) * (delta_star q * (1 - y) ^ p2 - y ^ p2) ≤ 0 := by
    intro y hy_gt_z hy_lt_one
    have hy_pos : 0 < y := lt_trans hZ_pos hy_gt_z
    -- ψ(y) < ψ(z_func q) = 0  (ψ antitone, y > z)
    have hpsi_y_neg : y ^ p2 - delta_star q * (1 - y) ^ p2 < 0 := by
      have hy_in : y ∈ Set.Ioo (0:ℝ) 1 := ⟨hy_pos, hy_lt_one⟩
      have hz_in : z_func q ∈ Set.Ioo (0:ℝ) 1 := ⟨hZ_pos, hZ_lt_one⟩
      have h_anti := hpsi_anti hz_in hy_in hy_gt_z
      have hpsi_y_val : psi y = y ^ p2 - delta_star q * (1 - y) ^ p2 := rfl
      rw [hpsi_zfunc, hpsi_y_val] at h_anti
      exact h_anti
    have hp1_q_neg : p1 / q < 0 := div_neg_of_neg_of_pos hp1_neg hq_pos
    have hbracket_pos : 0 < delta_star q * (1 - y) ^ p2 - y ^ p2 := by linarith
    have h_neg : (p1/q) * (delta_star q * (1 - y) ^ p2 - y ^ p2) < 0 :=
      mul_neg_of_neg_of_pos hp1_q_neg hbracket_pos
    linarith
  -- Continuity of u on [z_func q, 1].
  have hq_inv_pos : (0 : ℝ) < 1 / q := by positivity
  have h_cont : ContinuousOn u (Set.Icc (z_func q) 1) := by
    intro xx hx
    have hx_ge_z : z_func q ≤ xx := hx.1
    have hx_le_one : xx ≤ 1 := hx.2
    have hx_pos : 0 < xx := lt_of_lt_of_le hZ_pos hx_ge_z
    have h_inner : ContinuousAt (fun y : ℝ => 1 - y) xx :=
      (continuous_const.sub continuous_id).continuousAt
    have h_outer : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/q)) (1 - xx) := by
      rcases eq_or_lt_of_le hx_le_one with hxone | hxlt
      · -- xx = 1, 1 - xx = 0; use exponent positivity branch
        rw [hxone] at *
        simpa using Real.continuousAt_rpow_const (0:ℝ) ((1:ℝ)/q) (Or.inr (le_of_lt hq_inv_pos))
      · have h1mx_pos : 0 < 1 - xx := by linarith
        exact Real.continuousAt_rpow_const (1 - xx) ((1:ℝ)/q) (Or.inl (ne_of_gt h1mx_pos))
    have h_1mx_pow : ContinuousAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/q)) xx :=
      h_outer.comp h_inner
    have h_d_1mx_pow : ContinuousAt (fun y : ℝ => delta_star q * (1 - y) ^ ((1:ℝ)/q)) xx :=
      h_1mx_pow.const_mul (delta_star q)
    have h_x_pow : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/q)) xx :=
      Real.continuousAt_rpow_const xx ((1:ℝ)/q) (Or.inr (le_of_lt hq_inv_pos))
    have h_diff : ContinuousAt
        (fun y : ℝ => delta_star q * (1 - y) ^ ((1:ℝ)/q) - y ^ ((1:ℝ)/q)) xx :=
      h_d_1mx_pow.sub h_x_pow
    have h_diff_const : ContinuousAt
        (fun y : ℝ => delta_star q * (1 - y) ^ ((1:ℝ)/q) - y ^ ((1:ℝ)/q) - 1) xx :=
      h_diff.sub continuousAt_const
    have h_lin : ContinuousAt (fun y : ℝ => 2 * y) xx :=
      (continuous_const.mul continuous_id).continuousAt
    have h_total : ContinuousAt u xx := by
      simp only [hu_eq]; exact h_diff_const.add h_lin
    exact h_total.continuousWithinAt
  -- ConcaveOn u on [z_func q, 1].
  have hConvexIcc : Convex ℝ (Set.Icc (z_func q) 1) := convex_Icc (z_func q) 1
  have h_int : interior (Set.Icc (z_func q) 1) = Set.Ioo (z_func q) 1 := interior_Icc
  have hConc_u : ConcaveOn ℝ (Set.Icc (z_func q) 1) u := by
    apply concaveOn_of_deriv2_nonpos hConvexIcc h_cont
    · rw [h_int]
      intro y hy
      have hy_pos : 0 < y := lt_trans hZ_pos hy.1
      exact (h_deriv y hy_pos hy.2).differentiableAt.differentiableWithinAt
    · rw [h_int]
      intro y hy
      have hy_pos : 0 < y := lt_trans hZ_pos hy.1
      have hopen : IsOpen (Set.Ioo (z_func q) 1) := isOpen_Ioo
      have hnhds : Set.Ioo (z_func q) 1 ∈ nhds y := hopen.mem_nhds hy
      have hloc : deriv u =ᶠ[nhds y]
          fun z => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1 + 2 := by
        filter_upwards [hnhds] with z hz
        exact (h_deriv z (lt_trans hZ_pos hz.1) hz.2).deriv
      have hd2 : DifferentiableAt ℝ
          (fun z : ℝ => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1 + 2) y :=
        (h_deriv2 y hy_pos hy.2).differentiableAt
      have hd_local : DifferentiableAt ℝ (deriv u) y :=
        hd2.congr_of_eventuallyEq hloc
      exact hd_local.differentiableWithinAt
    · rw [h_int]
      intro y hy
      simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
      have hy_pos : 0 < y := lt_trans hZ_pos hy.1
      have hopen : IsOpen (Set.Ioo (z_func q) 1) := isOpen_Ioo
      have hnhds : Set.Ioo (z_func q) 1 ∈ nhds y := hopen.mem_nhds hy
      have hloc : deriv u =ᶠ[nhds y]
          fun z => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1 + 2 := by
        filter_upwards [hnhds] with z hz
        exact (h_deriv z (lt_trans hZ_pos hz.1) hz.2).deriv
      have hd2_eq : deriv (deriv u) y =
          deriv (fun z => -(delta_star q) / q * (1 - z) ^ p1 - (1/q) * z ^ p1 + 2) y :=
        hloc.deriv_eq
      rw [hd2_eq, (h_deriv2 y hy_pos hy.2).deriv]
      exact h_uSecond_np y hy.1 hy.2
  -- Apply ConcaveOn.ge_on_segment with endpoints z_func q and 1.
  have hz_mem : z_func q ∈ Set.Icc (z_func q) 1 := ⟨le_refl _, le_of_lt hZ_lt_one⟩
  have hone_mem : (1:ℝ) ∈ Set.Icc (z_func q) 1 := ⟨le_of_lt hZ_lt_one, le_refl _⟩
  have ha_mem_seg : a ∈ segment ℝ (z_func q) 1 := by
    rw [segment_eq_Icc (le_of_lt hZ_lt_one)]
    exact ⟨le_of_lt ha_gt_z, ha1⟩
  have hchord := hConc_u.ge_on_segment hz_mem hone_mem ha_mem_seg
  -- u(z_func q) ≥ 0  and  u(1) = 0, so min ≥ 0.
  have hu_z_nn : 0 ≤ u (z_func q) :=
    u_dual_nonneg_left q hq (z_func q) (le_of_lt hZ_pos) (le_refl _)
  have hu_one : u 1 = 0 := u_dual_at_one q hq
  have hmin_nn : 0 ≤ min (u (z_func q)) (u 1) := by
    rw [hu_one]; exact le_min hu_z_nn (le_refl 0)
  -- u a = u_dual q a.
  show 0 ≤ u_dual q a
  have : u a = u_dual q a := rfl
  rw [← this]
  exact le_trans hmin_nn hchord

/-- MAIN: dual-certificate proof of the relaxed core inequality. -/
theorem relaxedFeasibleSumNonneg_dual
    (q : ℝ) (hq : 1 < q)
    {n : ℕ} (hn_pos : 0 < n) (hn_even : Even n)
    (lambda : ℝ) (hlam_eq : lambda = lambda_star q)
    (delta : ℝ) (hdelta_eq : delta = delta_of_lambda q lambda)
    (x : Fin n → ℝ)
    (hx_nn : ∀ i, 0 ≤ x i) (hx_le_one : ∀ i, x i ≤ 1)
    (hx_sum : (∑ i, x i) = (n : ℝ) / 2) :
    0 ≤ (∑ i, h_q q lambda delta (x i)) := by
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hlam_pos : 0 < lambda := by rw [hlam_eq]; exact (LambdaStarDef.1 q hq_le).1
  -- Bridge: delta = delta_star q.
  have hdelta_star : delta = delta_star q := by
    rw [hdelta_eq, hlam_eq]
    exact deltaOfLambda_lambdaStar_eq q hq
  -- Pointwise lower bound: h_q q lambda delta (x i) ≥ lambda * (1 - 2 * x i).
  have h_pointwise : ∀ i, lambda * (1 - 2 * x i) ≤ h_q q lambda delta (x i) := by
    intro i
    have hu_nn : 0 ≤ u_dual q (x i) := u_dual_nonneg q hq (x i) (hx_nn i) (hx_le_one i)
    -- h_q = lambda * (u_dual q (x i) + 1 - 2 * x i)
    have h_rewrite : h_q q lambda delta (x i) = lambda * (u_dual q (x i) + 1 - 2 * (x i)) := by
      show lambda * (delta * (1 - x i) ^ ((1:ℝ)/q) - (x i) ^ ((1:ℝ)/q))
        = lambda * ((delta_star q * (1 - x i) ^ ((1:ℝ)/q) - (x i) ^ ((1:ℝ)/q) - 1 + 2 * (x i)) + 1 - 2 * (x i))
      rw [hdelta_star]; ring
    rw [h_rewrite]
    have hmul := mul_le_mul_of_nonneg_left (by linarith : (1 - 2 * x i) ≤ (u_dual q (x i) + 1 - 2 * (x i))) (le_of_lt hlam_pos)
    linarith [hmul]
  -- Sum the pointwise bound.
  have hsum_lb : (∑ i, lambda * (1 - 2 * x i)) ≤ (∑ i, h_q q lambda delta (x i)) :=
    Finset.sum_le_sum (fun i _ => h_pointwise i)
  -- ∑ lambda*(1 - 2 x i) = lambda * (n - 2 * ∑ x i) = lambda * (n - n) = 0.
  have hsum_eq : (∑ i, lambda * (1 - 2 * x i)) = 0 := by
    rw [← Finset.mul_sum]
    have hinner : (∑ i, (1 - 2 * x i)) = (n : ℝ) - 2 * (∑ i, x i) := by
      rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
          ← Finset.mul_sum]
      simp
    rw [hinner, hx_sum]
    ring
  rw [hsum_eq] at hsum_lb
  exact hsum_lb

end Workspace.ProofLemmas.RelaxedCoreDual

open Workspace.Types.LqNorm
open Workspace.Types.SocialCost
open Workspace.Types.CoordinateMedian
open Workspace.ProofLemmas.UBDef
open Workspace.ProofLemmas.LambdaStarDef
open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.LambdaDeltaIdentity
open Workspace.ProofLemmas.ConstrainedMinExists
open Workspace.ProofLemmas.HSecondDerivative
open Workspace.ProofLemmas.FqHasUniqueInteriorZero

set_option maxHeartbeats 8000000

/-- The `f > 0` (strictly positive) version of `NormalizedCoreInequality`.
This carries the paper's normalization hypothesis `hf_pos : ∀ j, 0 < f j`,
which is required by `LocalOptimumCharacterization` / `GLambdaLowerBound_h`.
The `f ≥ 0` version `NormalizedCoreInequality` is derived from this one via
the paper's ε-perturbation device (approx.tex line 9). The `∑ h_q ≥ 0` step
uses the FULLY-PROVEN dual lemma
`Workspace.ProofLemmas.RelaxedCoreDual.relaxedFeasibleSumNonneg_dual`, so this
theorem has NO `sorry` in its dependency closure. -/
theorem NormalizedCoreInequality_fpos :
    ∀ (q : ℝ), 1 < q →
      ∀ {n d : ℕ}, 0 < n → Even n → 1 ≤ d →
      ∀ (P_norm : Fin n → Fin d → ℝ),
      IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ)) P_norm →
      ∀ (f : Fin d → ℝ), (∀ j, 0 ≤ f j) → (∀ j, 0 < f j) → lqNorm q f = 1 →
      socialCost q P_norm (fun (_ : Fin d) => (0 : ℝ)) ≤ UB q * socialCost q P_norm f := by
  intro q hq n d hn_pos hn_even hd P_norm hP_med f hf_nn hf_pos hf_norm
  -- Basic setup.
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_q_pos : (0 : ℝ) < 1 / q := by positivity
  have h_inv_q_ne : (1 : ℝ) / q ≠ 0 := ne_of_gt h_inv_q_pos
  -- Define lambda := lambda_star q. By LambdaStarDef, 0 < lambda < 1 (strict since q > 1).
  set lambda : ℝ := lambda_star q with hlam_def
  have hLam := (LambdaStarDef.1 q hq_le)
  have hlam_pos : 0 < lambda := hLam.1
  have hlam_le_one : lambda ≤ 1 := hLam.2
  -- For q > 1 we have lambda < 1 strictly.
  have hlam_lt_one : lambda < 1 := by
    have hq_ne1 : q ≠ 1 := ne_of_gt hq
    have h_unfold : lambda_star q =
        (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q)) := by
      unfold lambda_star
      rw [if_neg hq_ne1, if_pos hq]
    have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
    have hD_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
    have hD_pos : 0 < delta_star q := lt_of_lt_of_le one_pos hD_ge_one
    have h_exp1_pos : 0 < q / (q - 1) := div_pos hq_pos hqm1_pos
    have h_dpow_ge_one : 1 ≤ (delta_star q) ^ (q / (q - 1)) :=
      Real.one_le_rpow hD_ge_one (le_of_lt h_exp1_pos)
    have h_sum_gt_one : 1 < 1 + (delta_star q) ^ (q / (q - 1)) := by linarith
    have h_sum_pos : 0 < 1 + (delta_star q) ^ (q / (q - 1)) := by linarith
    have h_exp2_neg : -((q - 1) / q) < 0 := by
      have hp : 0 < (q - 1) / q := div_pos hqm1_pos hq_pos
      linarith
    have h_lt : (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q)) < 1 := by
      have h := Real.rpow_lt_one_of_one_lt_of_neg h_sum_gt_one h_exp2_neg
      exact h
    show lambda < 1
    rw [hlam_def, h_unfold]
    exact h_lt
  -- UB q = 1 / lambda.
  have h_UB_eq : UB q = 1 / lambda := by
    show UB q = 1 / lambda_star q
    unfold UB
    rw [if_pos hq_le]
  -- Goal rewrite: SC(P,0) ≤ (1/lambda) * SC(P,f) ↔ lambda * SC(P,0) ≤ SC(P,f)
  rw [h_UB_eq]
  rw [show (1 : ℝ) / lambda * socialCost q P_norm f = socialCost q P_norm f / lambda by ring]
  rw [le_div_iff₀ hlam_pos]
  -- Step (c): obtain sigma : Fin n → Fin d → ℝ via MedianConstraintFromCWMedian.
  obtain ⟨sigma, hsigma_pm, hsigma_pos, hsigma_neg, hsigma_zero⟩ :=
    MedianConstraintFromCWMedian hn_even P_norm hP_med
  -- f satisfies sum f^q = 1 since lqNorm q f = 1.
  have hf_pow_sum : (∑ j, (f j) ^ q) = 1 := by
    have h1 : lqNorm q f = (∑ j, |f j| ^ q) ^ ((1 : ℝ) / q) := rfl
    rw [h1] at hf_norm
    have h_inner_nn : 0 ≤ ∑ j, |f j| ^ q := sum_abs_rpow_nonneg q f
    have hsum_eq : (∑ j, |f j| ^ q) = 1 := by
      have h2 : ((∑ j, |f j| ^ q) ^ ((1 : ℝ) / q)) ^ q = (1 : ℝ) ^ q := by rw [hf_norm]
      rw [← Real.rpow_mul h_inner_nn, one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one,
          Real.one_rpow] at h2
      exact h2
    have h_abs : ∀ j, |f j| ^ q = (f j) ^ q := by
      intro j
      rw [abs_of_nonneg (hf_nn j)]
    rw [show (∑ j, (f j) ^ q) = (∑ j, |f j| ^ q) from
      Finset.sum_congr rfl (fun j _ => (h_abs j).symm)]
    exact hsum_eq
  -- Step (d): apply ConstrainedMinExists to get p_star which minimizes
  -- ∑ g_lambda(p_i) subject to the orthant constraint.
  obtain ⟨p_star, hp_star_in, hp_star_min⟩ :=
    ConstrainedMinExists q hq lambda hlam_pos hlam_lt_one hd f hf_norm hf_nn
      sigma hsigma_pm hsigma_zero
  -- Establish that P_norm itself satisfies the orthant constraint w.r.t. sigma.
  have hP_in : ∀ i j, (sigma i j = 1 → 0 ≤ P_norm i j) ∧
                       (sigma i j = -1 → P_norm i j ≤ 0) := by
    intro i j
    refine ⟨?_, ?_⟩
    · intro hsig
      by_contra h_neg
      push_neg at h_neg
      have := hsigma_neg i j h_neg
      rw [this] at hsig
      norm_num at hsig
    · intro hsig
      by_contra h_pos
      push_neg at h_pos
      have := hsigma_pos i j h_pos
      rw [this] at hsig
      norm_num at hsig
  -- The minimization gives: ∑ g_lambda f (p_star i) ≤ ∑ g_lambda f (P_norm i).
  have h_p_star_le : (∑ i, g_lambda q lambda f (p_star i))
      ≤ (∑ i, g_lambda q lambda f (P_norm i)) := hp_star_min P_norm hP_in
  -- Define x_i := ∑_{j ∈ S_i} (f j)^q, where S_i := {j : sigma i j = 1}.
  classical
  set x : Fin n → ℝ := fun i =>
    ∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma i j = 1)), (f j) ^ q with hx_def
  -- x i ∈ [0, 1] for each i.
  have hx_nn : ∀ i, 0 ≤ x i := by
    intro i
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) q
  have hx_le_one : ∀ i, x i ≤ 1 := by
    intro i
    have h_split := Finset.sum_compl_add_sum
      (s := (Finset.univ.filter (fun j : Fin d => sigma i j = 1)))
      (f := fun j => (f j) ^ q)
    have h_compl_nn : 0 ≤ ∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma i j = 1))ᶜ, (f j) ^ q := by
      apply Finset.sum_nonneg
      intro j _
      exact Real.rpow_nonneg (hf_nn j) q
    have hf_sum_eq :
        (∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma i j = 1))ᶜ, (f j) ^ q) +
          (∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma i j = 1)), (f j) ^ q) =
        ∑ j, (f j) ^ q := h_split
    rw [hf_pow_sum] at hf_sum_eq
    show (∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma i j = 1)), (f j) ^ q) ≤ 1
    linarith
  -- ∑ x i = n / 2 by MedianConstraintToSumX.
  have hx_sum : (∑ i, x i) = (n : ℝ) / 2 :=
    MedianConstraintToSumX hn_even q f hf_nn hf_pow_sum sigma hsigma_pm hsigma_zero
  -- Define the lower bound function.
  set delta : ℝ := delta_of_lambda q lambda with hdelta_def
  -- Per-agent local-min argument: from the GLOBAL minimum hypothesis on p_star,
  -- each component p_star i is a global (and hence local) minimum of g_lambda
  -- on the per-agent orthant orthant(σ i).
  have h_per_agent_min : ∀ i (p_i : Fin d → ℝ),
      (∀ j, (sigma i j = 1 → 0 ≤ p_i j) ∧ (sigma i j = -1 → p_i j ≤ 0)) →
      g_lambda q lambda f (p_star i) ≤ g_lambda q lambda f p_i := by
    intro i p_i hp_i_in
    -- Construct p' = p_star with i-th replaced by p_i.
    let p' : Fin n → Fin d → ℝ := fun i' => if i' = i then p_i else p_star i'
    have hp'_in : ∀ i' j, (sigma i' j = 1 → 0 ≤ p' i' j) ∧
                          (sigma i' j = -1 → p' i' j ≤ 0) := by
      intro i' j
      by_cases hi' : i' = i
      · subst hi'
        show (sigma i' j = 1 → 0 ≤ (if i' = i' then p_i else p_star i') j) ∧
             (sigma i' j = -1 → (if i' = i' then p_i else p_star i') j ≤ 0)
        simp only [if_true]
        exact hp_i_in j
      · show (sigma i' j = 1 → 0 ≤ (if i' = i then p_i else p_star i') j) ∧
             (sigma i' j = -1 → (if i' = i then p_i else p_star i') j ≤ 0)
        simp only [if_neg hi']
        exact hp_star_in i' j
    have h_global := hp_star_min p' hp'_in
    -- Sums differ only at i.
    have h_at_i : p' i = p_i := by simp [p']
    have h_off_i : ∀ i' ∈ Finset.univ.erase i, p' i' = p_star i' := by
      intro i' hi'
      rw [Finset.mem_erase] at hi'
      simp [p', hi'.1]
    have h_sum_p' :
        (∑ i', g_lambda q lambda f (p' i')) =
          g_lambda q lambda f p_i + ∑ i' ∈ Finset.univ.erase i, g_lambda q lambda f (p_star i') := by
      rw [← Finset.add_sum_erase _ _ (Finset.mem_univ i)]
      congr 1
      · rw [h_at_i]
      · apply Finset.sum_congr rfl
        intro i' hi'
        rw [h_off_i i' hi']
    have h_sum_pstar :
        (∑ i', g_lambda q lambda f (p_star i')) =
          g_lambda q lambda f (p_star i) + ∑ i' ∈ Finset.univ.erase i, g_lambda q lambda f (p_star i') := by
      rw [← Finset.add_sum_erase _ _ (Finset.mem_univ i)]
    rw [h_sum_p', h_sum_pstar] at h_global
    linarith
  -- Each per-agent point is a "local minimum" with any positive ε; we use ε = 1.
  have h_local_min : ∀ i,
      ∃ ε > (0 : ℝ),
        ∀ p_i : Fin d → ℝ,
          (∀ j, (sigma i j = 1 → 0 ≤ p_i j) ∧ (sigma i j = -1 → p_i j ≤ 0)) →
          (∀ j, |p_i j - p_star i j| < ε) →
          g_lambda q lambda f (p_star i) ≤ g_lambda q lambda f p_i := by
    intro i
    refine ⟨1, by norm_num, ?_⟩
    intro p_i hp_i_in _
    exact h_per_agent_min i p_i hp_i_in
  -- Per-agent g ≥ h via LocalOptimumCharacterization + GLambdaLowerBound_h.
  have h_per_agent_g_ge_h : ∀ i,
      lambda * (delta * (1 - x i) ^ ((1 : ℝ) / q) - (x i) ^ ((1 : ℝ) / q))
        ≤ g_lambda q lambda f (p_star i) := by
    intro i
    have hp_star_i_in : ∀ j, (sigma i j = 1 → 0 ≤ p_star i j) ∧
                              (sigma i j = -1 → p_star i j ≤ 0) := hp_star_in i
    have hsigma_i_pm : ∀ j, sigma i j = 1 ∨ sigma i j = -1 := fun j => hsigma_pm i j
    have h_local := LocalOptimumCharacterization q hq lambda hlam_pos hlam_lt_one
      hd f hf_nn hf_pos hf_pow_sum (sigma i) hsigma_i_pm (p_star i)
      hp_star_i_in (h_local_min i)
    have h_glb := GLambdaLowerBound_h q hq lambda hlam_pos hlam_lt_one
      hd f hf_nn hf_pos hf_pow_sum (sigma i) hsigma_i_pm (p_star i) h_local
    show lambda * (delta * (1 - x i) ^ ((1 : ℝ) / q) - (x i) ^ ((1 : ℝ) / q))
      ≤ g_lambda q lambda f (p_star i)
    have hx_eq : x i =
        ∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma i j = 1)), (f j) ^ q := rfl
    have hdelta_eq : delta = delta_of_lambda q lambda := rfl
    rw [hx_eq, hdelta_eq]
    exact h_glb
  -- Sum the per-agent bound.
  have h_g_ge_h : (∑ i, lambda * (delta * (1 - x i) ^ ((1 : ℝ) / q) - (x i) ^ ((1 : ℝ) / q)))
      ≤ (∑ i, g_lambda q lambda f (p_star i)) := by
    apply Finset.sum_le_sum
    intro i _
    exact h_per_agent_g_ge_h i
  -- Now establish ∑ h_q(x i) ≥ 0 via the FULLY-PROVEN dual lemma.
  have h_sum_h_nn : 0 ≤ (∑ i, h_q q lambda delta (x i)) := by
    exact Workspace.ProofLemmas.RelaxedCoreDual.relaxedFeasibleSumNonneg_dual q hq hn_pos hn_even
      lambda hlam_def delta hdelta_def x hx_nn hx_le_one hx_sum
  -- Convert the LHS of h_g_ge_h to the h_q form.
  have h_lhs_eq : (∑ i, lambda * (delta * (1 - x i) ^ ((1 : ℝ) / q) - (x i) ^ ((1 : ℝ) / q)))
      = (∑ i, h_q q lambda delta (x i)) := by
    apply Finset.sum_congr rfl
    intro i _
    show lambda * (delta * (1 - x i) ^ ((1 : ℝ) / q) - (x i) ^ ((1 : ℝ) / q))
       = h_q q lambda delta (x i)
    rfl
  rw [h_lhs_eq] at h_g_ge_h
  -- Combine: 0 ≤ ∑ h_q(x i) ≤ ∑ g_lambda(p_star i) ≤ ∑ g_lambda(P_norm i).
  have h_main_chain : 0 ≤ ∑ i, g_lambda q lambda f (P_norm i) := by
    have h1 : 0 ≤ ∑ i, g_lambda q lambda f (p_star i) :=
      le_trans h_sum_h_nn h_g_ge_h
    linarith
  -- Unfold g_lambda and conclude.
  have h_sum_eq : (∑ i, g_lambda q lambda f (P_norm i))
      = socialCost q P_norm f - lambda * socialCost q P_norm (fun (_ : Fin d) => (0 : ℝ)) := by
    unfold g_lambda socialCost
    rw [Finset.sum_sub_distrib]
    rw [Finset.mul_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro i _
    have h_ext : (fun j => P_norm i j - (fun (_ : Fin d) => (0 : ℝ)) j) = fun j => P_norm i j := by
      funext j; ring
    rw [h_ext]
  rw [h_sum_eq] at h_main_chain
  linarith

theorem NormalizedCoreInequality :
    ∀ (q : ℝ), 1 < q →
      ∀ {n d : ℕ}, 0 < n → Even n → 1 ≤ d →
      ∀ (P_norm : Fin n → Fin d → ℝ),
      IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ)) P_norm →
      ∀ (f : Fin d → ℝ), (∀ j, 0 ≤ f j) → lqNorm q f = 1 →
      socialCost q P_norm (fun (_ : Fin d) => (0 : ℝ)) ≤ UB q * socialCost q P_norm f := by
  intro q hq n d hn_pos hn_even hd P_norm hP_med f hf_nn hf_norm
  -- ===================================================================
  -- ε-PERTURBATION DEVICE (approx.tex line 9): derive the f ≥ 0 statement
  -- from the f > 0 statement `NormalizedCoreInequality_fpos`. For ε > 0 we
  -- replace f by the strictly-positive normalized perturbation
  --   f_eps ε j := (f j + ε) / lqNorm q (fun k => f k + ε),
  -- apply `_fpos`, and let ε → 0⁺ along the sequence ε_k = 1/(k+1),
  -- using continuity of `g ↦ socialCost q P_norm g`.
  -- ===================================================================
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_q_nn : (0 : ℝ) ≤ 1 / q := by positivity
  -- (1) `socialCost q P_norm` is continuous in its facility-location argument.
  have h_cont_sc : Continuous (fun g : Fin d → ℝ => socialCost q P_norm g) := by
    show Continuous (fun g : Fin d → ℝ => ∑ i, lqNorm q (fun j => P_norm i j - g j))
    apply continuous_finset_sum
    intro i _
    show Continuous (fun g : Fin d → ℝ =>
      (∑ j, |P_norm i j - g j| ^ q) ^ ((1 : ℝ) / q))
    apply Continuous.rpow_const
    · apply continuous_finset_sum
      intro j _
      apply Continuous.rpow_const
      · exact (continuous_const.sub (continuous_apply j)).abs
      · intro x; right; exact le_of_lt hq_pos
    · intro x; right; exact h_inv_q_nn
  -- (2) The normalizing constant c ε = lqNorm q (f + ε), as a function of ε.
  set c : ℝ → ℝ := fun ε => lqNorm q (fun k => f k + ε) with hc_def
  -- c is continuous (in ε).
  have h_cont_c : Continuous c := by
    show Continuous (fun ε : ℝ => (∑ k, |f k + ε| ^ q) ^ ((1 : ℝ) / q))
    apply Continuous.rpow_const
    · apply continuous_finset_sum
      intro k _
      apply Continuous.rpow_const
      · exact (continuous_const.add continuous_id).abs
      · intro x; right; exact le_of_lt hq_pos
    · intro x; right; exact h_inv_q_nn
  -- c 0 = lqNorm q f = 1.
  have hc_zero : c 0 = 1 := by
    have h_eq : (fun k => f k + (0:ℝ)) = f := by funext k; ring
    show lqNorm q (fun k => f k + (0:ℝ)) = 1
    rw [h_eq]; exact hf_norm
  -- For ε > 0 : c ε > 0  (since each f k + ε > 0 and d ≥ 1).
  have hc_pos : ∀ ε : ℝ, 0 < ε → 0 < c ε := by
    intro ε hε
    show 0 < lqNorm q (fun k => f k + ε)
    have h_inner_pos : 0 < ∑ k, |f k + ε| ^ q := by
      obtain ⟨j0⟩ : Nonempty (Fin d) := Fin.pos_iff_nonempty.mp (lt_of_lt_of_le one_pos hd)
      have hpos_term : 0 < |f j0 + ε| ^ q := by
        have hfe : 0 < f j0 + ε := by have := hf_nn j0; linarith
        apply Real.rpow_pos_of_pos
        rw [abs_of_pos hfe]; exact hfe
      have h_nn : ∀ k ∈ (Finset.univ : Finset (Fin d)), 0 ≤ |f k + ε| ^ q :=
        fun k _ => Real.rpow_nonneg (abs_nonneg _) q
      calc (0:ℝ) < |f j0 + ε| ^ q := hpos_term
        _ ≤ ∑ k, |f k + ε| ^ q := Finset.single_le_sum h_nn (Finset.mem_univ j0)
    show 0 < (∑ k, |f k + ε| ^ q) ^ ((1 : ℝ) / q)
    exact Real.rpow_pos_of_pos h_inner_pos _
  -- (3) The perturbed, normalized feasible point.
  set f_eps : ℝ → (Fin d → ℝ) := fun ε j => (f j + ε) / c ε with hfeps_def
  -- For ε > 0 : f_eps ε j > 0.
  have hfeps_pos : ∀ ε : ℝ, 0 < ε → ∀ j, 0 < f_eps ε j := by
    intro ε hε j
    show 0 < (f j + ε) / c ε
    apply div_pos
    · have := hf_nn j; linarith
    · exact hc_pos ε hε
  have hfeps_nn : ∀ ε : ℝ, 0 < ε → ∀ j, 0 ≤ f_eps ε j :=
    fun ε hε j => le_of_lt (hfeps_pos ε hε j)
  -- For ε > 0 : lqNorm q (f_eps ε) = 1 (scaling by 1/c ε).
  have hfeps_norm : ∀ ε : ℝ, 0 < ε → lqNorm q (f_eps ε) = 1 := by
    intro ε hε
    have hcε_pos : 0 < c ε := hc_pos ε hε
    have hcε_ne : c ε ≠ 0 := ne_of_gt hcε_pos
    have h_smul : f_eps ε = (fun j => (1 / c ε) * (f j + ε)) := by
      funext j; show (f j + ε) / c ε = (1 / c ε) * (f j + ε); rw [one_div]; ring
    rw [h_smul]
    rw [lqNorm_smul hq_le (1 / c ε) (fun k => f k + ε)]
    have h_abs : |1 / c ε| = 1 / c ε := abs_of_pos (by positivity)
    rw [h_abs]
    show (1 / c ε) * c ε = 1
    rw [one_div, inv_mul_cancel₀ hcε_ne]
  -- (4) The sequence ε_k = 1/(k+1) → 0⁺.
  set aε : ℕ → ℝ := fun k => 1 / (k + 1) with haε_def
  have haε_pos : ∀ k, 0 < aε k := by
    intro k; show 0 < 1 / ((k : ℝ) + 1)
    apply div_pos one_pos; positivity
  have haε_tendsto : Filter.Tendsto aε Filter.atTop (nhds 0) := by
    have h : Filter.Tendsto (fun n : ℕ => 1 / ((n : ℝ) + 1)) Filter.atTop (nhds 0) :=
      tendsto_one_div_add_atTop_nhds_zero_nat
    exact h
  -- (5) c (aε k) → c 0 = 1  (continuity of c at 0).
  have hc_tendsto : Filter.Tendsto (fun k => c (aε k)) Filter.atTop (nhds 1) := by
    have h := (h_cont_c.tendsto 0).comp haε_tendsto
    rw [hc_zero] at h
    exact h
  -- (6) f_eps (aε k) → f  pointwise (in the product topology).
  have hfeps_tendsto : Filter.Tendsto (fun k => f_eps (aε k)) Filter.atTop (nhds f) := by
    rw [tendsto_pi_nhds]
    intro j
    show Filter.Tendsto (fun k => (f j + aε k) / c (aε k)) Filter.atTop (nhds (f j))
    have h_num : Filter.Tendsto (fun k => f j + aε k) Filter.atTop (nhds (f j + 0)) :=
      Filter.Tendsto.const_add (f j) haε_tendsto
    rw [add_zero] at h_num
    have h_div := Filter.Tendsto.div h_num hc_tendsto (by norm_num : (1:ℝ) ≠ 0)
    rw [div_one] at h_div
    exact h_div
  -- (7) socialCost q P_norm (f_eps (aε k)) → socialCost q P_norm f  (continuity).
  have hsc_tendsto :
      Filter.Tendsto (fun k => socialCost q P_norm (f_eps (aε k)))
        Filter.atTop (nhds (socialCost q P_norm f)) :=
    (h_cont_sc.tendsto f).comp hfeps_tendsto
  -- (8) Multiply by the constant factor UB q.
  have hub_tendsto :
      Filter.Tendsto (fun k => UB q * socialCost q P_norm (f_eps (aε k)))
        Filter.atTop (nhds (UB q * socialCost q P_norm f)) :=
    Filter.Tendsto.const_mul (UB q) hsc_tendsto
  -- (9) Each term obeys the f > 0 inequality from `_fpos`.
  have h_each : ∀ k,
      socialCost q P_norm (fun (_ : Fin d) => (0 : ℝ))
        ≤ UB q * socialCost q P_norm (f_eps (aε k)) := by
    intro k
    exact NormalizedCoreInequality_fpos q hq hn_pos hn_even hd P_norm hP_med
      (f_eps (aε k)) (hfeps_nn (aε k) (haε_pos k)) (hfeps_pos (aε k) (haε_pos k))
      (hfeps_norm (aε k) (haε_pos k))
  -- (10) Pass to the limit: the constant LHS ≤ limit of the RHS.
  exact ge_of_tendsto' hub_tendsto h_each

open Workspace.Types.LqNorm
open Workspace.Types.SocialCost
open Workspace.Types.CoordinateMedian
open Workspace.ProofLemmas.UBDef

theorem MainTheoremApproxBoundQGtOne
    (q : ℝ) (hq : 1 < q) {n d : ℕ} (hd : 1 ≤ d)
    (P : Fin n → Fin d → ℝ) (m : Fin d → ℝ)
    (hm : IsCoordinateMedian m P) :
    socialCost q P m ≤ UB q * optSocialCost q P := by
  -- Top-level structural reduction:
  --   Outer: reduce general n to even n via ReductionToEvenN.
  --   Inner: case-split on q' = 1 (use MainTheoremApproxBoundQEqOne) versus q' > 1;
  --          for q' > 1, dispatch the trivial subcase (optSocialCost = 0) via
  --          MainTheoremTrivialCases, else apply TranslationScaleNormalize, with
  --          NormalizedCoreInequality supplying the normalized-core hypothesis.
  apply ReductionToEvenN ?_ q hq.le hd P m hm
  intro q' hq' n' d' hn'_pos hn'_even hd' P' m' hm'
  rcases eq_or_lt_of_le hq' with hq1 | hq1
  · -- q' = 1
    rw [← hq1]
    exact MainTheoremApproxBoundQEqOne hd' P' m' hm'
  · -- q' > 1
    by_cases hopt0 : optSocialCost q' P' = 0
    · exact MainTheoremTrivialCases q' (le_of_lt hq1) hd' P' m' hm' (Or.inr hopt0)
    have hopt_nn : 0 ≤ optSocialCost q' P' := optSocialCost_nonneg hq' P'
    have hopt_pos : 0 < optSocialCost q' P' := lt_of_le_of_ne hopt_nn (Ne.symm hopt0)
    exact TranslationScaleNormalize NormalizedCoreInequality
      q' hq1 hn'_pos hn'_even hd' P' m' hm' hopt_pos

open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost
open Workspace.ProofLemmas.UBDef

theorem MainTheoremFinalAssembly :
    ∃ UB' : ℝ → ℝ,
      UB' 1 = 1 ∧
      Filter.Tendsto UB' Filter.atTop (nhds 3) ∧
      UB' 2 = Real.sqrt (6 * Real.sqrt 3 - 8) ∧
      ∀ (q : ℝ), 1 ≤ q →
        ∀ {n d : ℕ}, 1 ≤ d →
        ∀ (P : Fin n → Fin d → ℝ),
        ∀ (m : Fin d → ℝ), IsCoordinateMedian m P →
          socialCost q P m ≤ UB' q * optSocialCost q P := by
  refine ⟨UB, UBDef.2, UBLimitThree, UBTwo, ?_⟩
  intro q hq n d hd P m hm
  rcases eq_or_lt_of_le hq with hq1 | hq1
  · -- hq1 : 1 = q
    rw [← hq1]
    exact MainTheoremApproxBoundQEqOne hd P m hm
  · exact MainTheoremApproxBoundQGtOne q hq1 hd P m hm

open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost

namespace Workspace.MainTheorem

theorem main_theorem :
    ∃ UB : ℝ → ℝ,
      UB 1 = 1 ∧
      Filter.Tendsto UB Filter.atTop (nhds 3) ∧
      UB 2 = Real.sqrt (6 * Real.sqrt 3 - 8) ∧
      ∀ (q : ℝ), 1 ≤ q →
        ∀ {n d : ℕ}, 1 ≤ d →
        ∀ (P : Fin n → Fin d → ℝ),
        ∀ (m : Fin d → ℝ), IsCoordinateMedian m P →
          socialCost q P m ≤ UB q * optSocialCost q P
    := MainTheoremFinalAssembly

end Workspace.MainTheorem
