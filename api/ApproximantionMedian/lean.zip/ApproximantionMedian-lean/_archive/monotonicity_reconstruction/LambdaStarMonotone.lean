import Mathlib
import Workspace.ProofLemmas.LambdaStarDef
import Workspace.ProofLemmas.DeltaStarDef
import Workspace.ProofLemmas.DeltaStarContinuousOn
import Workspace.ProofLemmas.DeltaStarDifferentiable
import Workspace.ProofLemmas.AStarLessThanOneHalf
import Workspace.ProofLemmas.LambdaStarMonotoneAux
import Workspace.ProofLemmas.LambdaStarMonotoneGoalIneq

open Workspace.ProofLemmas.LambdaStarDef
open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.LambdaStarMonotoneAux
open Workspace.ProofLemmas.LambdaStarMonotoneGoalIneq

namespace Workspace.ProofLemmas.LambdaStarMonotone

/-! # Antitonicity of `lambda_star` on `[1, ∞)`

This file proves `AntitoneOn lambda_star (Set.Ici 1)`, the key analytic fact
needed for `UBMonotone` (since `UB q = 1 / lambda_star q` is monotone iff
`lambda_star` is antitone).

The structure is:
* `lambda_star q = (1 + (delta_star q) ^ (q/(q-1))) ^ (-(q-1)/q)` for `q > 1`
  (the closed form, `lambdaClosedForm`).
* On the open ray `(1, ∞)`, `lambda_star` is continuous and differentiable
  (reconstructed from `DeltaStarContinuousOn` / `DeltaStarDifferentiable`).
* `deriv lambda_star q ≤ 0` on `(1, ∞)` — the single residual analytic lemma
  `deriv_lambda_star_nonpos` (see its docstring for the precise math content and
  why it is isolated). Everything else is fully proven and wired through it.
* `antitoneOn_of_deriv_nonpos` then gives `AntitoneOn lambda_star (Set.Ioi 1)`.
* A boundary case-split (`lambda_star 1 = 1 ≥ lambda_star b`) lifts this to
  `AntitoneOn lambda_star (Set.Ici 1)`.
-/

/-- Closed form of `lambda_star` on `(1, ∞)`. -/
noncomputable def lambdaClosedForm (q : ℝ) : ℝ :=
  (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q))

/-- On `(1, ∞)`, `lambda_star` agrees with its closed form. -/
theorem lambda_star_eq_closedForm (q : ℝ) (hq : 1 < q) :
    lambda_star q = lambdaClosedForm q := by
  have hq1 : q ≠ 1 := ne_of_gt hq
  unfold lambda_star lambdaClosedForm
  rw [if_neg hq1, if_pos hq]

/-- The base `1 + (delta_star q) ^ (q/(q-1))` is `> 0` (indeed `≥ 2`) for `q > 1`. -/
theorem base_pos (q : ℝ) (hq : 1 < q) :
    0 < 1 + (delta_star q) ^ (q / (q - 1)) := by
  have hq_pos : (0 : ℝ) < q := by linarith
  have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
  have hD := DeltaStarDef q hq
  have hD_ge_one : 1 ≤ delta_star q := hD.1
  have h_exp1_pos : 0 < q / (q - 1) := div_pos hq_pos hqm1_pos
  have h_dpow_ge_one : 1 ≤ (delta_star q) ^ (q / (q - 1)) :=
    Real.one_le_rpow hD_ge_one (le_of_lt h_exp1_pos)
  linarith

/-- `lambda_star q > 0` for `q ≥ 1`. -/
theorem lambda_star_pos (q : ℝ) (hq : 1 ≤ q) : 0 < lambda_star q :=
  (LambdaStarDef.1 q hq).1

/-- `lambda_star q ≤ 1` for `q ≥ 1`. -/
theorem lambda_star_le_one (q : ℝ) (hq : 1 ≤ q) : lambda_star q ≤ 1 :=
  (LambdaStarDef.1 q hq).2

/-! ## Continuity and differentiability of the closed form -/

/-- The base `q ↦ 1 + (delta_star q) ^ (q/(q-1))` is continuous on `(1, ∞)`. -/
theorem base_continuousOn :
    ContinuousOn (fun q : ℝ => 1 + (delta_star q) ^ (q / (q - 1))) (Set.Ioi (1 : ℝ)) := by
  have hD : ContinuousOn delta_star (Set.Ioi (1 : ℝ)) := DeltaStarContinuousOn
  have hexp : ContinuousOn (fun q : ℝ => q / (q - 1)) (Set.Ioi (1 : ℝ)) := by
    apply ContinuousOn.div continuousOn_id (continuousOn_id.sub continuousOn_const)
    intro q hq
    have : 1 < q := hq
    have : q - 1 ≠ 0 := by linarith
    simpa using this
  have hbase : ContinuousOn (fun q : ℝ => (delta_star q) ^ (q / (q - 1))) (Set.Ioi (1 : ℝ)) := by
    apply ContinuousOn.rpow hD hexp
    intro q hq
    left
    have hD_ge := (DeltaStarDef q hq).1
    have : 0 < delta_star q := by linarith
    exact ne_of_gt this
  exact continuousOn_const.add hbase

/-- The exponent `q ↦ -(q-1)/q` is continuous on `(1, ∞)`. -/
theorem exp2_continuousOn :
    ContinuousOn (fun q : ℝ => -((q - 1) / q)) (Set.Ioi (1 : ℝ)) := by
  apply ContinuousOn.neg
  apply ContinuousOn.div (continuousOn_id.sub continuousOn_const) continuousOn_id
  intro q hq
  have : 1 < q := hq
  have : q ≠ 0 := by linarith
  simpa using this

/-- `lambda_star` (equivalently `lambdaClosedForm`) is continuous on `(1, ∞)`. -/
theorem lambda_star_continuousOn :
    ContinuousOn lambda_star (Set.Ioi (1 : ℝ)) := by
  have hcf : ContinuousOn lambdaClosedForm (Set.Ioi (1 : ℝ)) := by
    unfold lambdaClosedForm
    apply ContinuousOn.rpow base_continuousOn exp2_continuousOn
    intro q hq
    left
    exact ne_of_gt (base_pos q hq)
  apply hcf.congr
  intro q hq
  exact lambda_star_eq_closedForm q hq

/-- The base `q ↦ 1 + (delta_star q) ^ (q/(q-1))` is differentiable at any `q > 1`. -/
theorem base_differentiableAt (q : ℝ) (hq : 1 < q) :
    DifferentiableAt ℝ (fun q : ℝ => 1 + (delta_star q) ^ (q / (q - 1))) q := by
  have hq_ne : q ≠ 0 := by linarith
  have hqm1_ne : q - 1 ≠ 0 := by linarith
  have hD := DeltaStarDifferentiable q hq
  have hD_ge := (DeltaStarDef q hq).1
  have hD_pos : 0 < delta_star q := by linarith
  have hexp : DifferentiableAt ℝ (fun q : ℝ => q / (q - 1)) q :=
    differentiableAt_id.div (differentiableAt_id.sub (differentiableAt_const 1)) hqm1_ne
  have hbase : DifferentiableAt ℝ (fun q : ℝ => (delta_star q) ^ (q / (q - 1))) q :=
    hD.rpow hexp (ne_of_gt hD_pos)
  exact (differentiableAt_const 1).add hbase

/-- The exponent `q ↦ -(q-1)/q` is differentiable at any `q > 1`. -/
theorem exp2_differentiableAt (q : ℝ) (hq : 1 < q) :
    DifferentiableAt ℝ (fun q : ℝ => -((q - 1) / q)) q := by
  have hq_ne : q ≠ 0 := by linarith
  apply DifferentiableAt.neg
  exact (differentiableAt_id.sub (differentiableAt_const 1)).div differentiableAt_id hq_ne

/-- `lambda_star` (equivalently `lambdaClosedForm`) is differentiable at any `q > 1`. -/
theorem lambda_star_differentiableAt (q : ℝ) (hq : 1 < q) :
    DifferentiableAt ℝ lambda_star q := by
  -- `lambda_star =ᶠ lambdaClosedForm` near `q` (since `Ioi 1` is open and contains `q`).
  have hcf : DifferentiableAt ℝ lambdaClosedForm q := by
    unfold lambdaClosedForm
    have hbase := base_differentiableAt q hq
    have hexp := exp2_differentiableAt q hq
    exact hbase.rpow hexp (ne_of_gt (base_pos q hq))
  have hmem : Set.Ioi (1 : ℝ) ∈ nhds q := (isOpen_Ioi).mem_nhds hq
  have heq : lambda_star =ᶠ[nhds q] lambdaClosedForm := by
    filter_upwards [hmem] with x hx
    exact lambda_star_eq_closedForm x hx
  exact hcf.congr_of_eventuallyEq heq

theorem lambda_star_differentiableOn :
    DifferentiableOn ℝ lambda_star (Set.Ioi (1 : ℝ)) := by
  intro q hq
  exact (lambda_star_differentiableAt q hq).differentiableWithinAt

/-! ## The exponent `e(q) = (q-1)/q` is nonneg and increasing on `(1, ∞)` -/

/-- `(q-1)/q ≥ 0` for `q > 1`. -/
theorem e_nonneg (q : ℝ) (hq : 1 < q) : 0 ≤ (q - 1) / q := by
  have hq_pos : (0 : ℝ) < q := by linarith
  apply div_nonneg
  · linarith
  · linarith

/-- `(q-1)/q` is increasing: for `1 < q₁ ≤ q₂`, `(q₁-1)/q₁ ≤ (q₂-1)/q₂`. -/
theorem e_mono (q₁ q₂ : ℝ) (hq₁ : 1 < q₁) (hle : q₁ ≤ q₂) :
    (q₁ - 1) / q₁ ≤ (q₂ - 1) / q₂ := by
  have hq₁_pos : (0 : ℝ) < q₁ := by linarith
  have hq₂_pos : (0 : ℝ) < q₂ := by linarith
  -- (q-1)/q = 1 - 1/q, and 1/q is antitone.
  have h₁ : (q₁ - 1) / q₁ = 1 - 1 / q₁ := by field_simp
  have h₂ : (q₂ - 1) / q₂ = 1 - 1 / q₂ := by field_simp
  rw [h₁, h₂]
  have : 1 / q₂ ≤ 1 / q₁ := one_div_le_one_div_of_le hq₁_pos hle
  linarith

/-! ## The residual analytic lemma (single isolated `sorry`): `β` is monotone -/

/-- The base function `β(q) = (delta_star q) ^ (q/(q-1))`, so that
`lambda_star q = (1 + β q) ^ (-(q-1)/q)`. -/
noncomputable def betaFun (q : ℝ) : ℝ := (delta_star q) ^ (q / (q - 1))

/-- `β q ≥ 0` for `q > 1` (indeed `β q ≥ 1`). -/
theorem betaFun_ge_one (q : ℝ) (hq : 1 < q) : 1 ≤ betaFun q := by
  have hq_pos : (0 : ℝ) < q := by linarith
  have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
  have hD_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
  have h_exp1_pos : 0 < q / (q - 1) := div_pos hq_pos hqm1_pos
  exact Real.one_le_rpow hD_ge_one (le_of_lt h_exp1_pos)

/-!
`betaFun_monotoneOn` (proved at the end of this section) is the genuine analytic
crux of `deriv_lambda_star_nonpos`. It is reduced — by a fully-proven `rpow`
log-derivative computation — to the single residual inequality `betaFun_goalIneq`:

  `delta_star q · log (delta_star q) ≤ q·(q-1)·(deriv delta_star q)`.

The derivative infrastructure (implicit differentiation of `a_star`, partial
derivatives of `F_q`) lives in `LambdaStarMonotoneAux`. Steps 1–3 below
(`hasDerivAt_betaFun`, the closed forms of `deriv a_star`) are fully proven; the
only `sorry` is `betaFun_goalIneq`.
-/

/-- `delta_star q > 0` for `q > 1`. -/
theorem delta_star_pos (q : ℝ) (hq : 1 < q) : 0 < delta_star q := by
  have := (DeltaStarDef q hq).1; linarith

/-- The exponent `e2 q = q/(q-1)` and its derivative `-1/(q-1)^2`. -/
theorem hasDerivAt_e2 (q : ℝ) (hq : 1 < q) :
    HasDerivAt (fun q' : ℝ => q' / (q' - 1)) (-1 / (q - 1) ^ 2) q := by
  have hqm1_pos : (0:ℝ) < q - 1 := by linarith
  have hqm1_ne : q - 1 ≠ 0 := ne_of_gt hqm1_pos
  have hnum : HasDerivAt (fun q' : ℝ => q') (1 : ℝ) q := hasDerivAt_id q
  have hden : HasDerivAt (fun q' : ℝ => q' - 1) (1 : ℝ) q := by
    simpa using (hasDerivAt_id q).sub_const 1
  have hdiv := hnum.div hden hqm1_ne
  have heq : (1 * (q - 1) - q * 1) / (q - 1) ^ 2 = -1 / (q - 1) ^ 2 := by
    congr 1; ring
  rwa [heq] at hdiv

/-- The closed-form derivative of `betaFun` at `q > 1`:
`deriv betaFun q = (deriv delta_star q)·(q/(q-1))·δ^(e2-1) - (1/(q-1)^2)·δ^e2·log δ`,
where `δ = delta_star q`, `e2 = q/(q-1)`, and `deriv delta_star q = deriv delta_star q`. -/
theorem hasDerivAt_betaFun (q : ℝ) (hq : 1 < q) :
    HasDerivAt betaFun
      ((deriv delta_star q) * (q / (q - 1)) * (delta_star q) ^ (q / (q - 1) - 1)
        + (-1 / (q - 1) ^ 2) * (delta_star q) ^ (q / (q - 1)) * Real.log (delta_star q)) q := by
  have hD_pos : 0 < delta_star q := delta_star_pos q hq
  have hf : HasDerivAt delta_star (deriv delta_star q) q :=
    (DeltaStarDifferentiable q hq).hasDerivAt
  have hg : HasDerivAt (fun q' : ℝ => q' / (q' - 1)) (-1 / (q - 1) ^ 2) q :=
    hasDerivAt_e2 q hq
  have h := hf.rpow hg hD_pos
  exact h

/--
**GOAL-INEQ — fully derivative-eliminated residual (the single isolated `sorry`).**

Here `deriv delta_star q` has been replaced by its explicit closed form
`derivDeltaStarVal q` (`= (deriv N · D − N · deriv D)/D²` from the quotient rule,
with `N, D` the numerator/denominator of `delta_star` and `derivAStar q` the
implicit-differentiation closed form of `deriv a_star q`). Unfolding the defs, the
statement is a concrete inequality in `q`, `a_star q`, `Real.log (a_star q)`,
`Real.log (1 - a_star q)`, `Real.log (delta_star q)`, and `derivAStar q`
(`= -(partialQF q (a_star q))/(partialAF q (a_star q))`) — NO `deriv`/limits remain.

Known bounds available for an attack: `0 < a_star q < 1/2`
(`AStarLessThanOneHalf`), `1 ≤ delta_star q` and `0 < (1 - a_star q)^(1/q)`
(`DeltaStarDef`), `partialAF q (a_star q) < 0` (`partialAF_at_aStar_neg`), and
`F_q q (a_star q) = 0` (`FqHasUniqueInteriorZero`). Both sides are `≥ 0`. -/
theorem betaFun_goalIneq_explicit (q : ℝ) (hq : 1 < q) :
    delta_star q * Real.log (delta_star q) ≤ q * (q - 1) * (derivDeltaStarVal q) :=
  -- Reduced (in `LambdaStarMonotoneGoalIneq`) by the crude log bound
  -- `log δ ≤ δ - 1` and clearing the positive denominator `D²` to the simpler
  -- algebraic/log residual `goalIneq_residual`.
  goalIneq_explicit_of_residual q hq

/-- GOAL-INEQ in terms of the honest derivative, bridged to the explicit residual
via `deriv_deltaStar_eq` (a fully-proven closed-form identity). -/
theorem betaFun_goalIneq (q : ℝ) (hq : 1 < q) :
    delta_star q * Real.log (delta_star q) ≤ q * (q - 1) * (deriv delta_star q) := by
  rw [deriv_deltaStar_eq q hq]
  exact betaFun_goalIneq_explicit q hq

/-- `0 ≤ deriv betaFun q` for `q > 1`, reduced to `betaFun_goalIneq`. -/
theorem deriv_betaFun_nonneg (q : ℝ) (hq : 1 < q) : 0 ≤ deriv betaFun q := by
  have hq_pos : (0:ℝ) < q := by linarith
  have hqm1_pos : (0:ℝ) < q - 1 := by linarith
  have hD_pos : 0 < delta_star q := delta_star_pos q hq
  have hD_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
  have he2 : 0 < q / (q - 1) := div_pos hq_pos hqm1_pos
  -- The closed-form derivative.
  have hderiv := (hasDerivAt_betaFun q hq).deriv
  rw [hderiv]
  -- Abbreviations.
  set δ : ℝ := delta_star q with hδ_def
  set e2 : ℝ := q / (q - 1) with he2_def
  set dD : ℝ := deriv delta_star q with hdD_def
  -- δ^(e2-1) > 0 and δ^e2 = δ^(e2-1) * δ.
  have hpow_pos : 0 < δ ^ (e2 - 1) := Real.rpow_pos_of_pos hD_pos _
  have hpow_split : δ ^ e2 = δ ^ (e2 - 1) * δ := by
    have h1 : δ ^ (e2 - 1) * δ ^ (1:ℝ) = δ ^ (e2 - 1 + 1) := (Real.rpow_add hD_pos _ _).symm
    have h2 : δ ^ (1:ℝ) = δ := Real.rpow_one δ
    rw [h2] at h1
    rw [h1]
    congr 1
    ring
  -- The bracket after factoring δ^(e2-1): dD·e2 - (1/(q-1)^2)·δ·log δ.
  have hkey : dD * e2 * δ ^ (e2 - 1) + (-1 / (q - 1) ^ 2) * δ ^ e2 * Real.log δ
      = δ ^ (e2 - 1) * (dD * e2 - (1 / (q - 1) ^ 2) * (δ * Real.log δ)) := by
    rw [hpow_split]; ring
  rw [hkey]
  apply mul_nonneg (le_of_lt hpow_pos)
  -- Reduce to: dD·e2 ≥ (1/(q-1)^2)·δ·log δ, i.e. multiply by (q-1)^2 > 0.
  rw [sub_nonneg]
  -- e2 = q/(q-1); (1/(q-1)^2)·δ·log δ ≤ dD·q/(q-1) ⟺ δ·log δ ≤ q(q-1)·dD.
  have hgoal := betaFun_goalIneq q hq
  rw [← hδ_def, ← hdD_def] at hgoal
  -- Multiply hgoal (δ log δ ≤ q(q-1) dD) by 1/(q-1)^2.
  have hqm1_sq_pos : 0 < (q - 1) ^ 2 := by positivity
  have he2_eq : e2 = q / (q - 1) := he2_def
  rw [he2_eq]
  -- goal: (1/(q-1)^2)*(δ*log δ) ≤ dD * (q/(q-1)).
  -- Clear denominators by proving the multiplied-out identities.
  -- It suffices to compare after multiplying by (q-1)^2 > 0.
  rw [← sub_nonneg]
  have hfac : dD * (q / (q - 1)) - (1 / (q - 1) ^ 2) * (δ * Real.log δ)
      = (q * (q - 1) * dD - δ * Real.log δ) / (q - 1) ^ 2 := by
    rw [eq_div_iff (ne_of_gt hqm1_sq_pos)]
    field_simp
  rw [hfac]
  apply div_nonneg _ (le_of_lt hqm1_sq_pos)
  linarith [hgoal]

/-- `betaFun` is differentiable at every `q > 1`. -/
theorem betaFun_differentiableAt (q : ℝ) (hq : 1 < q) :
    DifferentiableAt ℝ betaFun q :=
  (hasDerivAt_betaFun q hq).differentiableAt

/-- `betaFun` is continuous on `(1, ∞)`. -/
theorem betaFun_continuousOn : ContinuousOn betaFun (Set.Ioi (1 : ℝ)) := by
  intro q hq
  exact (betaFun_differentiableAt q hq).continuousAt.continuousWithinAt

/-- `betaFun` is differentiable on `(1, ∞)`. -/
theorem betaFun_differentiableOn : DifferentiableOn ℝ betaFun (Set.Ioi (1 : ℝ)) := by
  intro q hq
  exact (betaFun_differentiableAt q hq).differentiableWithinAt

theorem betaFun_monotoneOn : MonotoneOn betaFun (Set.Ioi (1 : ℝ)) := by
  apply monotoneOn_of_deriv_nonneg (convex_Ioi 1) betaFun_continuousOn
  · rw [interior_Ioi]; exact betaFun_differentiableOn
  · rw [interior_Ioi]
    intro q hq
    exact deriv_betaFun_nonneg q hq

/-! ## Antitonicity (real proofs, reduced to `betaFun_monotoneOn`) -/

/-- `lambda_star` is antitone on the open ray `(1, ∞)`.

Pointwise proof from `betaFun_monotoneOn`: for `1 < q₁ ≤ q₂`, writing
`A = 1 + β q₁ ≤ B = 1 + β q₂` (both `≥ 1`) and `0 ≤ e₁ = (q₁-1)/q₁ ≤ e₂`,
`lambda_star q₂ = B^(-e₂) ≤ B^(-e₁) ≤ A^(-e₁) = lambda_star q₁`. -/
theorem lambda_star_antitoneOn_Ioi :
    AntitoneOn lambda_star (Set.Ioi (1 : ℝ)) := by
  intro q₁ hq₁mem q₂ hq₂mem hle
  have hq₁ : 1 < q₁ := hq₁mem
  have hq₂ : 1 < q₂ := hq₂mem
  -- Closed forms.
  rw [lambda_star_eq_closedForm q₁ hq₁, lambda_star_eq_closedForm q₂ hq₂]
  unfold lambdaClosedForm
  -- Abbreviations for the two bases and exponents.
  set A : ℝ := 1 + betaFun q₁ with hA_def
  set B : ℝ := 1 + betaFun q₂ with hB_def
  have hβ₁ : 1 ≤ betaFun q₁ := betaFun_ge_one q₁ hq₁
  have hβ₂ : 1 ≤ betaFun q₂ := betaFun_ge_one q₂ hq₂
  have hA_ge_one : (1 : ℝ) ≤ A := by rw [hA_def]; linarith
  have hB_ge_one : (1 : ℝ) ≤ B := by rw [hB_def]; linarith
  have hA_pos : (0 : ℝ) < A := by linarith
  -- β monotone ⇒ A ≤ B.
  have hβ_le : betaFun q₁ ≤ betaFun q₂ :=
    betaFun_monotoneOn hq₁mem hq₂mem hle
  have hAB : A ≤ B := by rw [hA_def, hB_def]; linarith
  -- Exponents.
  set e₁ : ℝ := (q₁ - 1) / q₁ with he₁_def
  set e₂ : ℝ := (q₂ - 1) / q₂ with he₂_def
  have he₁_nonneg : 0 ≤ e₁ := e_nonneg q₁ hq₁
  have he_le : e₁ ≤ e₂ := e_mono q₁ q₂ hq₁ hle
  have hne₁_nonpos : -e₁ ≤ 0 := by linarith
  have hne_le : -e₂ ≤ -e₁ := by linarith
  -- The target after unfolding the closed form: B^(-e₂) ≤ A^(-e₁).
  show B ^ (-e₂) ≤ A ^ (-e₁)
  -- Step 1: B^(-e₂) ≤ B^(-e₁) since B ≥ 1 and -e₂ ≤ -e₁.
  have step1 : B ^ (-e₂) ≤ B ^ (-e₁) :=
    Real.rpow_le_rpow_of_exponent_le hB_ge_one hne_le
  -- Step 2: B^(-e₁) ≤ A^(-e₁) since 0 < A ≤ B and -e₁ ≤ 0.
  have step2 : B ^ (-e₁) ≤ A ^ (-e₁) :=
    Real.rpow_le_rpow_of_nonpos hA_pos hAB hne₁_nonpos
  exact le_trans step1 step2

/--
`deriv lambda_star q ≤ 0` for every `q > 1`.

Now a **real proof** (no `sorry` here): `lambda_star` is antitone on the open set
`(1, ∞)` (`lambda_star_antitoneOn_Ioi`, itself reduced to the single residual
`betaFun_monotoneOn`), and an antitone function has nonpositive `derivWithin`,
which equals `deriv` on an open set.
-/
theorem deriv_lambda_star_nonpos (q : ℝ) (hq : 1 < q) : deriv lambda_star q ≤ 0 := by
  have hmem : q ∈ Set.Ioi (1 : ℝ) := hq
  rw [← derivWithin_of_isOpen isOpen_Ioi hmem]
  exact lambda_star_antitoneOn_Ioi.derivWithin_nonpos

/-- `lambda_star` is antitone on the closed ray `[1, ∞)`. -/
theorem lambda_star_antitoneOn_Ici :
    AntitoneOn lambda_star (Set.Ici (1 : ℝ)) := by
  intro a ha b hb hab
  have ha1 : 1 ≤ a := ha
  have hb1 : 1 ≤ b := hb
  rcases eq_or_lt_of_le ha1 with ha_eq | ha_gt
  · -- a = 1: lambda_star 1 = 1 ≥ lambda_star b
    rw [← ha_eq, LambdaStarDef.2]
    exact lambda_star_le_one b hb1
  · -- 1 < a ≤ b, both in Ioi 1
    have ha_mem : a ∈ Set.Ioi (1 : ℝ) := ha_gt
    have hb_mem : b ∈ Set.Ioi (1 : ℝ) := lt_of_lt_of_le ha_gt hab
    exact lambda_star_antitoneOn_Ioi ha_mem hb_mem hab

end Workspace.ProofLemmas.LambdaStarMonotone
