import Mathlib
import Workspace.ProofLemmas.FqHasUniqueInteriorZero
import Workspace.ProofLemmas.FqSignAt0Pos
import Workspace.ProofLemmas.FqStrictConvex

open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.FqSignAt0Pos

theorem PhiPartialAAtAStarNeg (q : ℝ) (hq : 1 < q) :
    2 * (1 - 1/q) + (1/q) * ((1 - q)/q) * (a_star q) ^ (((1 - q)/q) - 1) < 0 := by
  -- Pull out the basic algebraic facts about a_star q.
  obtain ⟨_h_unique, h_iA⟩ := FqHasUniqueInteriorZero q hq
  obtain ⟨ha_pos, ha_lt_one, hFa⟩ := h_iA
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  -- F_q q 1 = 0 by direct computation.
  have hF_one : F_q q 1 = 0 := by
    simp only [F_q, Real.one_rpow]
    field_simp
    ring
  -- F_q q is strictly convex on (0, ∞).
  have hSC : StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) :=
    FqStrictConvex q hq
  -- Set up the exponent p = (1 - q) / q.
  set p : ℝ := (1 - q) / q with hp_def
  -- Build HasDerivAt for F_q q at a_star q.
  have ha_ne : a_star q ≠ 0 := ne_of_gt ha_pos
  have hd_lin : HasDerivAt (fun y : ℝ => 2 * (1 - 1/q) * y) (2 * (1 - 1/q)) (a_star q) := by
    simpa using (hasDerivAt_id (a_star q)).const_mul (2 * (1 - 1/q))
  have hd_rpow : HasDerivAt (fun y : ℝ => y ^ p) (p * (a_star q) ^ (p - 1)) (a_star q) :=
    Real.hasDerivAt_rpow_const (Or.inl ha_ne)
  have hd_smul : HasDerivAt (fun y : ℝ => (1/q) * y ^ p)
      ((1/q) * (p * (a_star q) ^ (p - 1))) (a_star q) := hd_rpow.const_mul (1/q)
  have hd_sum : HasDerivAt (fun y : ℝ => 2 * (1 - 1/q) * y + (1/q) * y ^ p)
      (2 * (1 - 1/q) + (1/q) * (p * (a_star q) ^ (p - 1))) (a_star q) :=
    hd_lin.add hd_smul
  have hd_total : HasDerivAt
      (fun y : ℝ => 2 * (1 - 1/q) * y + (1/q) * y ^ p - 2 + 1/q)
      (2 * (1 - 1/q) + (1/q) * (p * (a_star q) ^ (p - 1))) (a_star q) := by
    have h1 : HasDerivAt
        (fun y : ℝ => 2 * (1 - 1/q) * y + (1/q) * y ^ p + (-2 + 1/q))
        (2 * (1 - 1/q) + (1/q) * (p * (a_star q) ^ (p - 1))) (a_star q) :=
      hd_sum.add_const _
    have heq : (fun y : ℝ => 2 * (1 - 1/q) * y + (1/q) * y ^ p + (-2 + 1/q)) =
        (fun y : ℝ => 2 * (1 - 1/q) * y + (1/q) * y ^ p - 2 + 1/q) := by
      funext y; ring
    rw [heq] at h1; exact h1
  have hcongr : (fun a => F_q q a) =
      (fun y : ℝ => 2 * (1 - 1/q) * y + (1/q) * y ^ p - 2 + 1/q) := by
    funext y; simp only [F_q, p]
  -- Set up the derivative L.
  set L : ℝ := 2 * (1 - 1/q) + (1/q) * (p * (a_star q) ^ (p - 1)) with hL_def
  have hFq_deriv_aStar : HasDerivAt (fun a => F_q q a) L (a_star q) := by
    rw [hcongr]; exact hd_total
  -- Slope from a_star q to 1 of F_q q is 0.
  have hslope : slope (fun a => F_q q a) (a_star q) 1 = 0 := by
    simp [slope, hFa, hF_one]
  -- By strict convexity, deriv at the LEFT endpoint < secant slope.
  have hL_lt_slope : L < slope (fun a => F_q q a) (a_star q) 1 :=
    hSC.lt_slope_of_hasDerivAt (Set.mem_Ioi.mpr ha_pos)
      (Set.mem_Ioi.mpr zero_lt_one) ha_lt_one hFq_deriv_aStar
  have hL_neg : L < 0 := by rw [hslope] at hL_lt_slope; exact hL_lt_slope
  -- The target equals L by associativity (after unfolding p).
  have hgoal_eq : 2 * (1 - 1/q) + (1/q) * ((1 - q)/q) * (a_star q) ^ (((1 - q)/q) - 1) = L := by
    show 2 * (1 - 1/q) + (1/q) * ((1 - q)/q) * (a_star q) ^ (((1 - q)/q) - 1) =
         2 * (1 - 1/q) + (1/q) * (p * (a_star q) ^ (p - 1))
    simp only [hp_def]
    ring
  rw [hgoal_eq]; exact hL_neg
