import Mathlib
import Workspace.ProofLemmas.FqHasUniqueInteriorZero
import Workspace.ProofLemmas.PhiHasStrictFDerivAt
import Workspace.ProofLemmas.PhiPartialAAtAStarNeg

open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.FqSignAt0Pos

theorem AStarDifferentiable : ∀ q : ℝ, 1 < q → DifferentiableAt ℝ a_star q := by
  intro q hq
  -- Pull out the basic algebraic facts about a_star q.
  obtain ⟨h_unique, h_iA⟩ := FqHasUniqueInteriorZero q hq
  obtain ⟨ha_pos, ha_lt_one, hFa⟩ := h_iA
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  -- Step 1: Strict Fréchet derivative of Φ at (q, a_star q).
  obtain ⟨Φ', hΦ_strict, hΦ_partial⟩ := PhiHasStrictFDerivAt q hq_ne (a_star q) ha_pos
  -- Step 2: L = Φ' (0, 1) = 2*(1-1/q) + (1/q)*((1-q)/q) * (a_star q)^(((1-q)/q) - 1) < 0
  have hL_neg : Φ' (0, 1) < 0 := by
    rw [hΦ_partial]
    exact PhiPartialAAtAStarNeg q hq
  set L : ℝ := Φ' (0, 1) with hL_def
  have hL_ne : L ≠ 0 := ne_of_lt hL_neg
  -- Step 3: Show that Φ'.comp (inr ℝ ℝ ℝ) is invertible.
  -- This map ℝ →L[ℝ] ℝ sends x ↦ Φ' (0, x). By linearity, it equals x ↦ x * L (= L * x).
  set g : ℝ →L[ℝ] ℝ := Φ'.comp (ContinuousLinearMap.inr ℝ ℝ ℝ) with hg_def
  have hg_apply : ∀ x : ℝ, g x = L * x := by
    intro x
    have h1 : g x = Φ' (0, x) := by
      simp [g, ContinuousLinearMap.inr]
    rw [h1]
    -- Φ'(0, x) = x • Φ'(0, 1) = x * L (by linearity)
    have h2 : ((0 : ℝ), x) = x • ((0 : ℝ), (1 : ℝ)) := by
      simp [Prod.smul_def]
    rw [h2, Φ'.map_smul]
    show x * L = L * x
    ring
  -- Now construct an inverse of g: namely h x := L⁻¹ * x.
  let e : ℝ ≃L[ℝ] ℝ :=
    { toFun := fun x => L * x
      invFun := fun y => L⁻¹ * y
      map_add' := fun x y => by ring
      map_smul' := fun c x => by simp; ring
      left_inv := fun x => by
        show L⁻¹ * (L * x) = x
        field_simp
      right_inv := fun y => by
        show L * (L⁻¹ * y) = y
        field_simp
      continuous_toFun := by continuity
      continuous_invFun := by continuity }
  have h_g_eq_e : g = (e : ℝ →L[ℝ] ℝ) := by
    apply ContinuousLinearMap.ext
    intro x
    show g x = L * x
    exact hg_apply x
  have h_g_invertible : g.IsInvertible := by
    rw [h_g_eq_e]
    exact ContinuousLinearMap.isInvertible_equiv
  -- Step 4: Apply HasStrictFDerivAt.implicitFunctionOfProdDomain.
  -- We need: HasStrictFDerivAt f f' u and (f'.comp (inr 𝕜 E₁ E₂)).IsInvertible
  -- where f : E₁ × E₂ → F, u : E₁ × E₂.
  -- In our case: f = (fun u : ℝ × ℝ => F_q u.1 u.2), f' = Φ', u = (q, a_star q).
  set Φ : ℝ × ℝ → ℝ := fun u => F_q u.1 u.2 with hΦ_def
  -- Note: hΦ_strict is exactly HasStrictFDerivAt Φ Φ' (q, a_star q).
  -- And h_g_invertible says (Φ'.comp (inr ℝ ℝ ℝ)).IsInvertible.
  set ψ : ℝ → ℝ := hΦ_strict.implicitFunctionOfProdDomain h_g_invertible with hψ_def
  -- Step 5: Get ψ properties.
  -- (a) ψ q = a_star q. We need to show: ψ q = (q, a_star q).2 = a_star q.
  -- The lemma `eventually_apply_eq_iff_implicitFunctionOfProdDomain` says
  -- ∀ᶠ v in nhds u, f v = f u ↔ ψ v.1 = v.2.
  -- Applying at v = u = (q, a_star q): f u = f u (true), so ψ u.1 = u.2, i.e. ψ q = a_star q.
  have hψ_at_q : ψ q = a_star q := by
    have h := hΦ_strict.eventually_apply_eq_iff_implicitFunctionOfProdDomain h_g_invertible
    rcases h.exists with ⟨v, hv⟩
    -- v is some witness; we want to use the iff at u = (q, a_star q) itself.
    -- Better: just use that the IFT lemma says ψ u.1 = u.2 always at u? No, only eventually.
    -- Since `eventually` gives a *neighborhood*, and the condition holds at u itself (Φ u = Φ u trivially).
    -- Use `Filter.Eventually.self_of_nhds` to extract the value at (q, a_star q):
    have h_at_u := h.self_of_nhds
    -- h_at_u : Φ (q, a_star q) = Φ (q, a_star q) ↔ ψ (q, a_star q).1 = (q, a_star q).2
    have : ψ q = a_star q := h_at_u.mp rfl
    exact this
  -- (b) ψ tends to a_star q at q (i.e. ψ is continuous at q).
  have hψ_tendsto : Filter.Tendsto ψ (nhds q) (nhds (a_star q)) := by
    have h := hΦ_strict.tendsto_implicitFunctionOfProdDomain h_g_invertible
    -- h : Filter.Tendsto ψ (nhds (q, a_star q).1) (nhds (q, a_star q).2)
    -- which is exactly Filter.Tendsto ψ (nhds q) (nhds (a_star q))
    exact h
  -- (c) ψ has strict Fréchet derivative at q.
  have hψ_hasStrictFDeriv :
      HasStrictFDerivAt ψ
        (-(Φ'.comp (ContinuousLinearMap.inr ℝ ℝ ℝ)).inverse.comp
              (Φ'.comp (ContinuousLinearMap.inl ℝ ℝ ℝ))) q := by
    have h := hΦ_strict.hasStrictFDerivAt_implicitFunctionOfProdDomain h_g_invertible
    exact h
  -- (d) ψ is differentiable at q.
  have hψ_diff : DifferentiableAt ℝ ψ q := hψ_hasStrictFDeriv.differentiableAt
  -- (e) Eventually F_q q' (ψ q') = F_q q (a_star q) = 0 near q.
  have h_eventually_F : ∀ᶠ q' in nhds q, F_q q' (ψ q') = 0 := by
    have h := hΦ_strict.eventually_apply_implicitFunctionOfProdDomain h_g_invertible
    -- h : ∀ᶠ x in nhds (q, a_star q).1, Φ (x, ψ x) = Φ (q, a_star q)
    -- where Φ u = F_q u.1 u.2.
    -- Φ (q, a_star q) = F_q q (a_star q) = 0 by hFa.
    filter_upwards [h] with q' hq'
    have h1 : Φ (q', ψ q') = Φ (q, a_star q) := hq'
    have h2 : Φ (q, a_star q) = 0 := by simpa [Φ] using hFa
    have h3 : Φ (q', ψ q') = 0 := h1.trans h2
    simpa [Φ] using h3
  -- Step 6: Eventually 0 < ψ q' and ψ q' < 1 (from continuity of ψ at q and ψ q = a_star q ∈ (0, 1)).
  have h_eventually_pos : ∀ᶠ q' in nhds q, 0 < ψ q' := by
    have h_lim : Filter.Tendsto ψ (nhds q) (nhds (a_star q)) := hψ_tendsto
    have : ∀ᶠ q' in nhds q, 0 < ψ q' :=
      h_lim.eventually (eventually_gt_nhds ha_pos)
    exact this
  have h_eventually_lt_one : ∀ᶠ q' in nhds q, ψ q' < 1 := by
    have h_lim : Filter.Tendsto ψ (nhds q) (nhds (a_star q)) := hψ_tendsto
    have : ∀ᶠ q' in nhds q, ψ q' < 1 :=
      h_lim.eventually (eventually_lt_nhds ha_lt_one)
    exact this
  -- Step 7: Eventually 1 < q' near q.
  have h_eventually_q' : ∀ᶠ q' in nhds q, 1 < q' := eventually_gt_nhds hq
  -- Step 8: Combine and identify ψ q' = a_star q' eventually.
  have h_eventually_eq : ψ =ᶠ[nhds q] a_star := by
    filter_upwards [h_eventually_F, h_eventually_pos, h_eventually_lt_one, h_eventually_q']
      with q' h_F h_pos h_lt h_q
    -- IsAStar q' (a_star q') from FqHasUniqueInteriorZero.
    obtain ⟨h_uniq, h_iA_q'⟩ := FqHasUniqueInteriorZero q' h_q
    -- IsAStar q' (ψ q') from h_pos, h_lt, h_F. Match the type of h_iA_q'.
    have h_isAStar_psi := show 0 < ψ q' ∧ ψ q' < 1 ∧ F_q q' (ψ q') = 0 from
      ⟨h_pos, h_lt, h_F⟩
    -- Uniqueness: there is a unique a, IsAStar q' a, so ψ q' = a_star q'.
    exact h_uniq.unique h_isAStar_psi h_iA_q'
  -- Step 9: Transfer differentiability.
  have h_eventually_eq_symm : a_star =ᶠ[nhds q] ψ := h_eventually_eq.symm
  exact hψ_diff.congr_of_eventuallyEq h_eventually_eq_symm
