import Mathlib
import Workspace.ProofLemmas.FqSignAt0Pos
import Workspace.ProofLemmas.FqHasUniqueInteriorZero
import Workspace.ProofLemmas.AStarLessThanOneHalf
import Workspace.ProofLemmas.DeltaStarDef
import Workspace.ProofLemmas.PhiPartialAAtAStarNeg
import Workspace.ProofLemmas.LambdaStarMonotoneAux

open Workspace.ProofLemmas.FqSignAt0Pos
open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.LambdaStarMonotoneAux

namespace Workspace.ProofLemmas.LambdaStarMonotoneGoalIneq

/-! # Reduction of `betaFun_goalIneq_explicit` to a simpler algebraic residual

The target inequality (from `LambdaStarMonotone.lean`) is

  `delta_star q * Real.log (delta_star q) ≤ q * (q - 1) * (derivDeltaStarVal q)`.

This file performs the rigorous algebraic reductions (a)–(c) requested:

* **(b) crude log bound.** `Real.log_le_sub_one_of_pos` gives
  `log (delta_star q) ≤ delta_star q - 1`, and a numerical check confirms the
  resulting (log-free) inequality is still valid (slack is positive everywhere,
  tight only as `q → 1⁺`). So it suffices to prove
  `delta_star q * (delta_star q - 1) ≤ q*(q-1)*derivDeltaStarVal q`.

* **(c) clear the denominator `D² = deltaDenVal q ^ 2 > 0`.** Writing
  `N := deltaNumVal q`, `D := deltaDenVal q` (so `delta_star q = N/D`), the bound
  `delta_star*(delta_star-1) ≤ q(q-1)·(N'D-ND')/D²` is equivalent (after
  multiplying by `D² > 0` and using `delta_star = N/D`) to the **polynomial /
  log residual**

  `N*(N - D) ≤ q*(q-1)*(derivDeltaNumVal q * D - N * derivDeltaDenVal q)`.

That residual (`goalIneq_residual`) is the single isolated `sorry`. It is
strictly simpler than the original: the LHS no longer contains `Real.log
(delta_star q)` (only a quadratic in `N, D`), and the denominator `D²` has been
cleared. The `Real.log a`, `Real.log (1-a)` terms inside `derivDeltaNumVal` /
`derivDeltaDenVal` remain (they are intrinsic to the derivative), as does the
`a^((1-q)/q)` structure inside `derivAStar`; see `aStar_rpow_sub` for the
substitution that turns that `rpow` into a polynomial in `a, q` when needed.
-/

/-- Abbreviation: `δ = delta_star q`. -/
local notation "δ" => delta_star

/-- `delta_star q = deltaNumVal q / deltaDenVal q`. -/
theorem delta_star_eq_div (q : ℝ) :
    delta_star q = deltaNumVal q / deltaDenVal q := by
  simp only [delta_star, deltaNumVal, deltaDenVal]

/-- The denominator `D = deltaDenVal q = (1 - a_star q)^(1/q)` is positive. -/
theorem deltaDen_pos (q : ℝ) (hq : 1 < q) : 0 < deltaDenVal q := by
  obtain ⟨ha_pos, ha_lt_half⟩ := AStarLessThanOneHalf q hq
  have h1a_pos : 0 < 1 - a_star q := by linarith
  exact Real.rpow_pos_of_pos h1a_pos _

/-- **Key substitution.** At `a = a_star q` (where `F_q q a = 0`), the rpow
`a^((1-q)/q)` equals the polynomial `2*q - 1 - 2*(q-1)*a`. -/
theorem aStar_rpow_sub (q : ℝ) (hq : 1 < q) :
    (a_star q) ^ ((1 - q) / q) = 2 * q - 1 - 2 * (q - 1) * (a_star q) := by
  have hq_pos : (0 : ℝ) < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  obtain ⟨_h_unique, h_iA⟩ := FqHasUniqueInteriorZero q hq
  obtain ⟨ha_pos, ha_lt_one, hFa⟩ := h_iA
  -- `F_q q a = 0`, i.e. `2*(1-1/q)*a + (1/q)*a^((1-q)/q) - 2 + 1/q = 0`.
  have hF : 2 * (1 - 1/q) * (a_star q) + (1/q) * (a_star q) ^ ((1 - q) / q) - 2 + 1/q = 0 := by
    have := hFa
    simpa only [F_q] using this
  -- Treat the rpow as an opaque real `t` and solve the linear equation for it.
  set t : ℝ := (a_star q) ^ ((1 - q) / q) with ht_def
  -- Multiply `hF` by `q` to clear the `1/q` factors.
  have hFq : q * (2 * (1 - 1/q) * (a_star q) + (1/q) * t - 2 + 1/q) = q * 0 :=
    congrArg (q * ·) hF
  have hexpand : 2 * (q - 1) * (a_star q) + t - 2 * q + 1 = 0 := by
    have hqi : q * (1/q) = 1 := by field_simp
    have : q * (2 * (1 - 1/q) * (a_star q) + (1/q) * t - 2 + 1/q)
        = 2 * (a_star q) * (q - q * (1/q)) + (q * (1/q)) * t - 2 * q + q * (1/q) := by ring
    rw [this, hqi] at hFq
    linarith [hFq]
  linarith [hexpand]

/-! ## The simplified algebraic residual

After the crude log bound and clearing `D²`, the goal reduces to the following
polynomial/log residual.  Numerically verified to hold for all `q > 1` with
positive slack (tight only as `q → 1⁺`).  This is the single isolated `sorry`. -/

/-- **Residual inequality (the single isolated `sorry`).**

`N*(N - D) ≤ q*(q-1)*(N'*D - N*D')`, where
`N = deltaNumVal q`, `D = deltaDenVal q`, `N' = derivDeltaNumVal q`,
`D' = derivDeltaDenVal q`.

This is `betaFun_goalIneq_explicit` after (b) bounding `log δ ≤ δ - 1` and
(c) clearing the positive denominator `D² = deltaDenVal q ^ 2`.  No
`Real.log (delta_star q)` and no division by `D²` remain; the LHS is the
quadratic `N*(N-D)` (with `N - D ≥ 0` since `δ ≥ 1`).  The residual logs
`Real.log (a_star q)`, `Real.log (1 - a_star q)` inside `N'`, `D'` are intrinsic
to the derivative; `aStar_rpow_sub` above eliminates the `a^((1-q)/q)` rpow
inside `derivAStar`/`partialQF` when polynomial form is wanted. -/
theorem goalIneq_residual (q : ℝ) (hq : 1 < q) :
    deltaNumVal q * (deltaNumVal q - deltaDenVal q)
      ≤ q * (q - 1) * (derivDeltaNumVal q * deltaDenVal q
          - deltaNumVal q * derivDeltaDenVal q) := by
  sorry

/-- **Reduction lemma.** `betaFun_goalIneq_explicit` follows from the residual
`goalIneq_residual` by the crude log bound `log δ ≤ δ - 1` and clearing `D²`. -/
theorem goalIneq_explicit_of_residual (q : ℝ) (hq : 1 < q) :
    delta_star q * Real.log (delta_star q) ≤ q * (q - 1) * (derivDeltaStarVal q) := by
  -- Abbreviations.
  set N : ℝ := deltaNumVal q with hN_def
  set D : ℝ := deltaDenVal q with hD_def
  set N' : ℝ := derivDeltaNumVal q with hN'_def
  set D' : ℝ := derivDeltaDenVal q with hD'_def
  -- Positivity of the denominator.
  have hD_pos : 0 < D := deltaDen_pos q hq
  have hD_ne : D ≠ 0 := ne_of_gt hD_pos
  have hD_sq_pos : 0 < D ^ 2 := by positivity
  -- δ = N / D, and δ ≥ 1, δ > 0.
  have hδ_eq : delta_star q = N / D := by rw [hN_def, hD_def]; exact delta_star_eq_div q
  have hδ_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
  have hδ_pos : 0 < delta_star q := by linarith
  -- (b) Crude log bound: log δ ≤ δ - 1.
  have hlog : Real.log (delta_star q) ≤ delta_star q - 1 :=
    Real.log_le_sub_one_of_pos hδ_pos
  -- δ * log δ ≤ δ * (δ - 1).
  have hstep1 : delta_star q * Real.log (delta_star q) ≤ delta_star q * (delta_star q - 1) := by
    apply mul_le_mul_of_nonneg_left hlog (le_of_lt hδ_pos)
  -- derivDeltaStarVal q = (N'*D - N*D') / D^2.
  have hderiv_eq : derivDeltaStarVal q = (N' * D - N * D') / D ^ 2 := by
    rw [hN'_def, hD_def, hN_def, hD'_def]
    simp only [derivDeltaStarVal]
  -- (c) The residual, then divide back by D^2.
  have hres : N * (N - D) ≤ q * (q - 1) * (N' * D - N * D') := by
    rw [hN_def, hD_def, hN'_def, hD'_def]; exact goalIneq_residual q hq
  -- δ*(δ-1) = N*(N-D)/D^2.
  have hδδ : delta_star q * (delta_star q - 1) = N * (N - D) / D ^ 2 := by
    rw [hδ_eq]
    field_simp
  -- q(q-1)*derivDeltaStarVal = q(q-1)*(N'D - N D')/D^2.
  have hrhs : q * (q - 1) * (derivDeltaStarVal q)
      = q * (q - 1) * (N' * D - N * D') / D ^ 2 := by
    rw [hderiv_eq]; ring
  -- Combine: δ*(δ-1) ≤ q(q-1)*deriv via dividing the residual by D^2.
  have hstep2 : delta_star q * (delta_star q - 1) ≤ q * (q - 1) * (derivDeltaStarVal q) := by
    rw [hδδ, hrhs]
    rw [div_le_div_iff_of_pos_right hD_sq_pos]
    exact hres
  linarith [hstep1, hstep2]
