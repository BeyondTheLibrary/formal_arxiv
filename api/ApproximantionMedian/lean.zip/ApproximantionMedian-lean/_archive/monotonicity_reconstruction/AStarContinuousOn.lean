import Mathlib
import Workspace.ProofLemmas.FqHasUniqueInteriorZero
import Workspace.ProofLemmas.FqStrictConvex
import Workspace.ProofLemmas.FqSignAt0Pos
import Workspace.ProofLemmas.AStarLessThanOneHalf

open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.FqSignAt0Pos
open Classical

/-! # Continuity of `a_star` on `(1, ∞)` -/

/-- Membership of `a_star q` in `(0,1)` and zero of `F_q` for `q > 1`. -/
private lemma a_star_props (q : ℝ) (hq : 1 < q) :
    0 < a_star q ∧ a_star q < 1 ∧ F_q q (a_star q) = 0 := by
  obtain ⟨_, hIs⟩ := FqHasUniqueInteriorZero q hq
  exact hIs

/-- Uniqueness: any zero of F_q in (0,1) equals a_star q. -/
private lemma a_star_unique (q : ℝ) (hq : 1 < q) (c : ℝ)
    (hc_pos : 0 < c) (hc_lt : c < 1) (hc_zero : F_q q c = 0) : c = a_star q := by
  obtain ⟨ha_pos, ha_lt, ha_zero⟩ := a_star_props q hq
  -- Use strict convexity to derive uniqueness from scratch.
  by_contra hne
  have hSC : StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) := FqStrictConvex q hq
  -- F_q q 1 = 0
  have hF_one : F_q q 1 = 0 := by
    simp only [F_q, Real.one_rpow]
    have hq_ne : q ≠ 0 := ne_of_gt (lt_trans zero_lt_one hq)
    field_simp
    ring
  rcases lt_or_gt_of_ne hne with hcab | hcab
  · -- c < a_star q < 1, all zeros.
    have hc_in : c ∈ Set.Ioi (0:ℝ) := hc_pos
    have hone_in : (1:ℝ) ∈ Set.Ioi (0:ℝ) := Set.mem_Ioi.mpr zero_lt_one
    have h_c_ne_one : c ≠ 1 := ne_of_lt hc_lt
    have h_aStar_in_seg : a_star q ∈ openSegment ℝ c 1 := by
      rw [openSegment_eq_Ioo (lt_trans hcab ha_lt)]
      exact ⟨hcab, ha_lt⟩
    have h_lt_max : F_q q (a_star q) < max (F_q q c) (F_q q 1) :=
      hSC.lt_on_openSegment hc_in hone_in h_c_ne_one h_aStar_in_seg
    rw [hc_zero, hF_one, max_self, ha_zero] at h_lt_max
    linarith
  · -- a_star q < c < 1, all zeros.
    have ha_in : a_star q ∈ Set.Ioi (0:ℝ) := ha_pos
    have hone_in : (1:ℝ) ∈ Set.Ioi (0:ℝ) := Set.mem_Ioi.mpr zero_lt_one
    have h_aStar_ne_one : a_star q ≠ 1 := ne_of_lt ha_lt
    have h_c_in_seg : c ∈ openSegment ℝ (a_star q) 1 := by
      rw [openSegment_eq_Ioo (lt_trans hcab hc_lt)]
      exact ⟨hcab, hc_lt⟩
    have h_lt_max : F_q q c < max (F_q q (a_star q)) (F_q q 1) :=
      hSC.lt_on_openSegment ha_in hone_in h_aStar_ne_one h_c_in_seg
    rw [ha_zero, hF_one, max_self, hc_zero] at h_lt_max
    linarith

/-- F_q is continuous on (0, ∞) (extracted to avoid relying on .continuousOn from StrictConvexOn). -/
private lemma F_q_continuous_on_Ioi (q : ℝ) (hq_pos : 0 < q) :
    ContinuousOn (fun a => F_q q a) (Set.Ioi (0 : ℝ)) := by
  set p : ℝ := (1 - q) / q with hp_def
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have heq : ∀ a : ℝ, F_q q a =
      (2 * (1 - 1/q)) * a + (1/q) * a ^ p + (-2 + 1/q) := by
    intro a
    simp only [F_q, p]
    ring
  refine ContinuousOn.congr ?_ (fun a _ => heq a)
  refine ((continuousOn_const.mul continuousOn_id).add ?_).add continuousOn_const
  refine continuousOn_const.mul ?_
  intro a ha
  have ha_ne : a ≠ 0 := ne_of_gt ha
  exact (Real.continuousAt_rpow_const a p (Or.inl ha_ne)).continuousWithinAt

/-- F_q is positive on `(0, a_star q)`. -/
private lemma F_q_pos_left (q : ℝ) (hq : 1 < q) (x : ℝ) (hx_pos : 0 < x)
    (hx_lt : x < a_star q) : 0 < F_q q x := by
  classical
  obtain ⟨ha_pos, ha_lt_one, hFa⟩ := a_star_props q hq
  by_contra h_neg
  push_neg at h_neg
  -- Find s ∈ (0, x) with F_q s > 0.
  have hTopAtZero : Filter.Tendsto (fun a => F_q q a) (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    FqSignAt0Pos q hq
  have h_evt_top : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), 1 < F_q q a :=
    hTopAtZero.eventually (Filter.eventually_gt_atTop 1)
  have h_evt_lt_x : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), a < x := by
    have hev : ∀ᶠ y in nhds (0:ℝ), y < x := eventually_lt_nhds hx_pos
    exact hev.filter_mono nhdsWithin_le_nhds
  have h_evt_a_pos : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), 0 < a := by
    rw [Filter.eventually_iff]
    exact self_mem_nhdsWithin
  haveI hNeBotR : (nhdsWithin (0:ℝ) (Set.Ioi 0)).NeBot := nhdsGT_neBot 0
  obtain ⟨s, hs_top, hs_lt_x, hs_pos⟩ : ∃ s,
      (1 < F_q q s) ∧ (s < x) ∧ (0 < s) := by
    have h := h_evt_top.and (h_evt_lt_x.and h_evt_a_pos)
    exact h.exists
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hCont : ContinuousOn (fun a => F_q q a) (Set.Ioi (0 : ℝ)) := F_q_continuous_on_Ioi q hq_pos
  have hCont_seg : ContinuousOn (fun a => F_q q a) (Set.Icc s x) := by
    apply hCont.mono
    intro y hy
    exact lt_of_lt_of_le hs_pos hy.1
  rcases lt_or_eq_of_le h_neg with hx_neg | hx_zero
  · have hzero_in : (0:ℝ) ∈ Set.Ioo (F_q q x) (F_q q s) := ⟨hx_neg, by linarith⟩
    have h_image : Set.Ioo (F_q q x) (F_q q s) ⊆ (fun a => F_q q a) '' Set.Ioo s x :=
      intermediate_value_Ioo' (le_of_lt hs_lt_x) hCont_seg
    obtain ⟨c, hc_mem, hc_val⟩ := h_image hzero_in
    have hc_pos : 0 < c := lt_trans hs_pos hc_mem.1
    have hc_lt_x : c < x := hc_mem.2
    have hc_lt_one : c < 1 := lt_trans hc_lt_x (lt_trans hx_lt ha_lt_one)
    have hc_ne : c ≠ a_star q := ne_of_lt (lt_trans hc_lt_x hx_lt)
    have h_eq : c = a_star q := a_star_unique q hq c hc_pos hc_lt_one hc_val
    exact hc_ne h_eq
  · -- F_q x = 0
    have hx_lt_one : x < 1 := lt_trans hx_lt ha_lt_one
    have h_eq : x = a_star q := a_star_unique q hq x hx_pos hx_lt_one hx_zero
    exact (ne_of_lt hx_lt) h_eq

/-- F_q is negative on `(a_star q, 1)`. -/
private lemma F_q_neg_right (q : ℝ) (hq : 1 < q) (x : ℝ) (hx_gt : a_star q < x)
    (hx_lt_one : x < 1) : F_q q x < 0 := by
  classical
  obtain ⟨ha_pos, ha_lt_one, hFa⟩ := a_star_props q hq
  have hSC : StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) := FqStrictConvex q hq
  have hF_one : F_q q 1 = 0 := by
    simp only [F_q, Real.one_rpow]
    have hq_ne : q ≠ 0 := ne_of_gt (lt_trans zero_lt_one hq)
    field_simp
    ring
  have h_astar_in : a_star q ∈ Set.Ioi (0 : ℝ) := ha_pos
  have h_one_in : (1 : ℝ) ∈ Set.Ioi (0 : ℝ) := Set.mem_Ioi.mpr zero_lt_one
  have h_ne : a_star q ≠ 1 := ne_of_lt ha_lt_one
  have hx_in_seg : x ∈ openSegment ℝ (a_star q) 1 := by
    rw [openSegment_eq_Ioo (lt_trans hx_gt hx_lt_one)]
    exact ⟨hx_gt, hx_lt_one⟩
  have h_lt_max : F_q q x < max (F_q q (a_star q)) (F_q q 1) :=
    hSC.lt_on_openSegment h_astar_in h_one_in h_ne hx_in_seg
  rw [hFa, hF_one, max_self] at h_lt_max
  exact h_lt_max

/-- F_q at fixed a > 0 is continuous in q at any q > 0. -/
private lemma F_q_continuous_in_q (a : ℝ) (ha_pos : 0 < a) (q : ℝ) (hq_pos : 0 < q) :
    ContinuousAt (fun q' => F_q q' a) q := by
  unfold F_q
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have ha_ne : a ≠ 0 := ne_of_gt ha_pos
  have h_id : ContinuousAt (fun q' : ℝ => q') q := continuousAt_id
  have h_inv : ContinuousAt (fun q' : ℝ => 1/q') q := by
    have : ContinuousAt (fun q' : ℝ => q'⁻¹) q := continuousAt_inv₀ hq_ne
    simp only [one_div]; exact this
  have h_one_minus : ContinuousAt (fun q' : ℝ => 1 - 1/q') q :=
    continuousAt_const.sub h_inv
  have h_two_mul : ContinuousAt (fun q' : ℝ => 2 * (1 - 1/q')) q :=
    continuousAt_const.mul h_one_minus
  have h_lin : ContinuousAt (fun q' : ℝ => 2 * (1 - 1/q') * a) q :=
    h_two_mul.mul continuousAt_const
  have h_num : ContinuousAt (fun q' : ℝ => 1 - q') q := continuousAt_const.sub h_id
  have h_exp : ContinuousAt (fun q' : ℝ => (1 - q')/q') q := h_num.div h_id hq_ne
  -- a^((1-q')/q'): use ContinuousAt.rpow.
  have h_rpow : ContinuousAt (fun q' : ℝ => a ^ ((1 - q') / q')) q :=
    (continuousAt_const : ContinuousAt (fun _ : ℝ => a) q).rpow h_exp (Or.inl ha_ne)
  have h_term2 : ContinuousAt (fun q' : ℝ => (1/q') * a ^ ((1 - q')/q')) q :=
    h_inv.mul h_rpow
  have h_sum1 : ContinuousAt
      (fun q' : ℝ => 2 * (1 - 1/q') * a + (1/q') * a ^ ((1 - q')/q')) q :=
    h_lin.add h_term2
  have h_sub : ContinuousAt
      (fun q' : ℝ => 2 * (1 - 1/q') * a + (1/q') * a ^ ((1 - q')/q') - 2) q :=
    h_sum1.sub continuousAt_const
  exact h_sub.add h_inv

/-- Main lemma: continuous on (1, ∞). -/
theorem AStarContinuousOn : ContinuousOn a_star (Set.Ioi (1 : ℝ)) := by
  classical
  rw [Metric.continuousOn_iff]
  intro q₀ hq₀ ε hε
  have h_pos_lt_half := AStarLessThanOneHalf q₀ hq₀
  have ha₀_pos : 0 < a_star q₀ := h_pos_lt_half.1
  have ha₀_lt_half : a_star q₀ < 1/2 := h_pos_lt_half.2
  have ha₀_lt_one : a_star q₀ < 1 := lt_trans ha₀_lt_half (by norm_num)
  set ε' : ℝ := min ε (min (a_star q₀ / 2) (1/4)) with hε'_def
  have hε'_pos : 0 < ε' := by
    refine lt_min hε (lt_min ?_ ?_)
    · exact half_pos ha₀_pos
    · norm_num
  have hε'_le : ε' ≤ ε := min_le_left _ _
  have hε'_le_half_a : ε' ≤ a_star q₀ / 2 :=
    le_trans (min_le_right _ _) (min_le_left _ _)
  have hε'_le_qtr : ε' ≤ 1/4 :=
    le_trans (min_le_right _ _) (min_le_right _ _)
  set α : ℝ := a_star q₀ - ε' with hα_def
  set β : ℝ := a_star q₀ + ε' with hβ_def
  have hα_pos : 0 < α := by simp only [hα_def]; linarith
  have hα_lt_a₀ : α < a_star q₀ := by simp only [hα_def]; linarith
  have hβ_gt_a₀ : a_star q₀ < β := by simp only [hβ_def]; linarith
  have hβ_lt_one : β < 1 := by simp only [hβ_def]; linarith
  have hβ_pos : 0 < β := by simp only [hβ_def]; linarith
  have hFα_pos : 0 < F_q q₀ α := F_q_pos_left q₀ hq₀ α hα_pos hα_lt_a₀
  have hFβ_neg : F_q q₀ β < 0 := F_q_neg_right q₀ hq₀ β hβ_gt_a₀ hβ_lt_one
  have hq₀_pos : 0 < q₀ := lt_trans zero_lt_one hq₀
  have hContα : ContinuousAt (fun q' => F_q q' α) q₀ :=
    F_q_continuous_in_q α hα_pos q₀ hq₀_pos
  have hContβ : ContinuousAt (fun q' => F_q q' β) q₀ :=
    F_q_continuous_in_q β hβ_pos q₀ hq₀_pos
  have hα_evt : ∀ᶠ q' in nhds q₀, 0 < F_q q' α :=
    hContα.eventually_const_lt hFα_pos
  have hβ_evt : ∀ᶠ q' in nhds q₀, F_q q' β < 0 :=
    hContβ.eventually_lt_const hFβ_neg
  have hq1_evt : ∀ᶠ q' in nhds q₀, 1 < q' := eventually_gt_nhds hq₀
  have h_combined : ∀ᶠ q' in nhds q₀, 0 < F_q q' α ∧ F_q q' β < 0 ∧ 1 < q' :=
    hα_evt.and (hβ_evt.and hq1_evt)
  rw [Metric.eventually_nhds_iff] at h_combined
  obtain ⟨δ, hδ_pos, hδ_prop⟩ := h_combined
  refine ⟨δ, hδ_pos, ?_⟩
  intro q hq_in hq_dist
  obtain ⟨hFq_α_pos, hFq_β_neg, hq_gt_one⟩ := hδ_prop hq_dist
  have ha_q_props := a_star_props q hq_gt_one
  obtain ⟨ha_q_pos, ha_q_lt_one, ha_q_zero⟩ := ha_q_props
  have hα_lt_β : α < β := lt_trans hα_lt_a₀ hβ_gt_a₀
  have hq_pos : 0 < q := lt_trans zero_lt_one hq_gt_one
  have hCont_q : ContinuousOn (fun a => F_q q a) (Set.Ioi (0 : ℝ)) :=
    F_q_continuous_on_Ioi q hq_pos
  have hCont_seg : ContinuousOn (fun a => F_q q a) (Set.Icc α β) := by
    apply hCont_q.mono
    intro y hy
    exact lt_of_lt_of_le hα_pos hy.1
  have h_zero_mem : (0:ℝ) ∈ Set.Ioo (F_q q β) (F_q q α) := ⟨hFq_β_neg, hFq_α_pos⟩
  have h_image : Set.Ioo (F_q q β) (F_q q α) ⊆ (fun a => F_q q a) '' Set.Ioo α β :=
    intermediate_value_Ioo' (le_of_lt hα_lt_β) hCont_seg
  obtain ⟨c, hc_mem, hc_zero⟩ := h_image h_zero_mem
  have hc_pos : 0 < c := lt_trans hα_pos hc_mem.1
  have hc_lt_one : c < 1 := lt_trans hc_mem.2 hβ_lt_one
  have h_c_eq : c = a_star q := a_star_unique q hq_gt_one c hc_pos hc_lt_one hc_zero
  rw [← h_c_eq]
  rw [Real.dist_eq]
  have h_c_in_Ioo : α < c ∧ c < β := hc_mem
  have h_diff_lt : |c - a_star q₀| < ε' := by
    rw [abs_sub_lt_iff]
    refine ⟨?_, ?_⟩
    · have : c < β := h_c_in_Ioo.2
      have : c < a_star q₀ + ε' := by simp only [hβ_def] at this; exact this
      linarith
    · have : α < c := h_c_in_Ioo.1
      have : a_star q₀ - ε' < c := by simp only [hα_def] at this; exact this
      linarith
  exact lt_of_lt_of_le h_diff_lt hε'_le
