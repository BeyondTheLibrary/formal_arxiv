import Mathlib
import Workspace.ProofLemmas.FqSignAt0Pos

open Workspace.ProofLemmas.FqSignAt0Pos

theorem PhiHasStrictFDerivAt (q : ℝ) (hq : q ≠ 0) (a : ℝ) (ha : 0 < a) :
    ∃ Φ' : (ℝ × ℝ) →L[ℝ] ℝ,
      HasStrictFDerivAt (fun u : ℝ × ℝ => F_q u.1 u.2) Φ' (q, a) ∧
      Φ' (0, 1) = 2 * (1 - 1/q) + (1/q) * ((1 - q)/q) * a ^ (((1 - q)/q) - 1) := by
  -- Strategy: Express F_q in terms of u.1⁻¹ instead of 1/u.1 so that we can use
  -- (1-u.1)/u.1 = u.1⁻¹ - 1 (which holds for u.1 ≠ 0). We work with the smooth
  -- version G(u), prove its derivative, then use congr_of_eventuallyEq.

  -- Coordinate projections
  have hfst : HasStrictFDerivAt (fun u : ℝ × ℝ => u.1)
      (ContinuousLinearMap.fst ℝ ℝ ℝ) (q, a) := hasStrictFDerivAt_fst
  have hsnd : HasStrictFDerivAt (fun u : ℝ × ℝ => u.2)
      (ContinuousLinearMap.snd ℝ ℝ ℝ) (q, a) := hasStrictFDerivAt_snd

  -- u ↦ u.1⁻¹: composition of inv with fst.
  have hinv_q : HasStrictDerivAt (fun x : ℝ => x⁻¹) (-(q^2)⁻¹) q := hasStrictDerivAt_inv hq
  have hinv_q_F : HasStrictFDerivAt (fun x : ℝ => x⁻¹)
      (ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)) q := hinv_q.hasStrictFDerivAt
  have hinv : HasStrictFDerivAt (fun u : ℝ × ℝ => (u.1)⁻¹)
      ((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
        (ContinuousLinearMap.fst ℝ ℝ ℝ)) (q, a) := hinv_q_F.comp (q, a) hfst

  -- u ↦ u.1⁻¹ - 1
  have hinv_sub : HasStrictFDerivAt (fun u : ℝ × ℝ => (u.1)⁻¹ - 1)
      ((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
        (ContinuousLinearMap.fst ℝ ℝ ℝ)) (q, a) := hinv.sub_const 1

  -- u ↦ u.2 ^ (u.1⁻¹ - 1) via HasStrictFDerivAt.rpow
  -- f = snd, g = u.1⁻¹ - 1, base = a > 0
  have ha_pos : (0 : ℝ) < (fun u : ℝ × ℝ => u.2) (q, a) := ha
  have hrpow : HasStrictFDerivAt (fun u : ℝ × ℝ => u.2 ^ ((u.1)⁻¹ - 1))
      (((q⁻¹ - 1) * a ^ ((q⁻¹ - 1) - 1)) • (ContinuousLinearMap.snd ℝ ℝ ℝ) +
        (a ^ (q⁻¹ - 1) * Real.log a) • ((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
          (ContinuousLinearMap.fst ℝ ℝ ℝ))) (q, a) :=
    hsnd.rpow hinv_sub ha_pos

  -- Piece P1: 2 * (1 - u.1⁻¹) * u.2
  -- 1 - u.1⁻¹ has derivative -hinv'
  have h_one_sub_inv : HasStrictFDerivAt (fun u : ℝ × ℝ => 1 - (u.1)⁻¹)
      (-((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
        (ContinuousLinearMap.fst ℝ ℝ ℝ))) (q, a) := hinv.const_sub 1
  have h_two_one_sub_inv : HasStrictFDerivAt (fun u : ℝ × ℝ => 2 * (1 - (u.1)⁻¹))
      ((2 : ℝ) • (-((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
        (ContinuousLinearMap.fst ℝ ℝ ℝ)))) (q, a) := h_one_sub_inv.const_mul 2
  have hP1 : HasStrictFDerivAt (fun u : ℝ × ℝ => 2 * (1 - (u.1)⁻¹) * u.2)
      ((2 * (1 - q⁻¹)) • (ContinuousLinearMap.snd ℝ ℝ ℝ) +
       a • ((2 : ℝ) • (-((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
        (ContinuousLinearMap.fst ℝ ℝ ℝ))))) (q, a) := by
    convert h_two_one_sub_inv.mul hsnd using 1

  -- Piece P2: u.1⁻¹ * u.2^(u.1⁻¹ - 1)
  have hP2 : HasStrictFDerivAt (fun u : ℝ × ℝ => (u.1)⁻¹ * u.2 ^ ((u.1)⁻¹ - 1))
      (q⁻¹ • ((((q⁻¹ - 1)) * a ^ ((q⁻¹ - 1) - 1)) • (ContinuousLinearMap.snd ℝ ℝ ℝ) +
        (a ^ (q⁻¹ - 1) * Real.log a) • ((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
          (ContinuousLinearMap.fst ℝ ℝ ℝ))) +
       (a ^ (q⁻¹ - 1)) • ((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
        (ContinuousLinearMap.fst ℝ ℝ ℝ))) (q, a) := by
    convert hinv.mul hrpow using 1

  -- Piece P3: -2 + u.1⁻¹
  have hP3 : HasStrictFDerivAt (fun u : ℝ × ℝ => -2 + (u.1)⁻¹)
      ((ContinuousLinearMap.toSpanSingleton ℝ (-(q^2)⁻¹)).comp
        (ContinuousLinearMap.fst ℝ ℝ ℝ)) (q, a) := hinv.const_add (-2 : ℝ)

  -- Sum: P1 + P2 + P3
  have hSum : HasStrictFDerivAt
      (fun u : ℝ × ℝ => 2 * (1 - (u.1)⁻¹) * u.2 + (u.1)⁻¹ * u.2 ^ ((u.1)⁻¹ - 1) +
        (-2 + (u.1)⁻¹))
      _ (q, a) := (hP1.add hP2).add hP3

  -- Show G eventually equals F_q near (q, a)
  -- F_q u.1 u.2 = 2 * (1 - 1/u.1) * u.2 + (1/u.1) * u.2^((1-u.1)/u.1) - 2 + 1/u.1
  -- G u = 2 * (1 - u.1⁻¹) * u.2 + u.1⁻¹ * u.2^(u.1⁻¹ - 1) + (-2 + u.1⁻¹)
  -- These agree when u.1 ≠ 0.
  have hF_eq_G : (fun u : ℝ × ℝ => F_q u.1 u.2) =ᶠ[nhds (q, a)]
      (fun u : ℝ × ℝ => 2 * (1 - (u.1)⁻¹) * u.2 + (u.1)⁻¹ * u.2 ^ ((u.1)⁻¹ - 1) +
        (-2 + (u.1)⁻¹)) := by
    have hopen : IsOpen { u : ℝ × ℝ | u.1 ≠ 0 } := by
      have : { u : ℝ × ℝ | u.1 ≠ 0 } = Prod.fst ⁻¹' {x : ℝ | x ≠ 0} := rfl
      rw [this]
      exact (isOpen_ne).preimage continuous_fst
    have hmem : (q, a) ∈ { u : ℝ × ℝ | u.1 ≠ 0 } := hq
    have hmem_nhds : { u : ℝ × ℝ | u.1 ≠ 0 } ∈ nhds (q, a) := hopen.mem_nhds hmem
    refine Filter.eventually_of_mem hmem_nhds ?_
    intro u hu
    simp only [Set.mem_setOf_eq] at hu
    simp only [F_q]
    have h1 : 1 / u.1 = (u.1)⁻¹ := one_div u.1
    have h2 : (1 - u.1) / u.1 = (u.1)⁻¹ - 1 := by field_simp
    rw [h1, h2]
    ring

  -- Apply hSum to (fun u => F_q u.1 u.2)
  refine ⟨_, hSum.congr_of_eventuallyEq hF_eq_G.symm, ?_⟩
  -- Compute Φ' (0, 1)
  simp only [ContinuousLinearMap.add_apply, ContinuousLinearMap.smul_apply,
             ContinuousLinearMap.coe_snd', ContinuousLinearMap.coe_fst',
             ContinuousLinearMap.coe_comp', Function.comp_apply,
             ContinuousLinearMap.toSpanSingleton_apply, ContinuousLinearMap.neg_apply,
             smul_eq_mul]
  -- (0,1).1 = 0, (0,1).2 = 1
  show _ = 2 * (1 - 1/q) + 1/q * ((1 - q)/q) * a ^ ((1 - q)/q - 1)
  have hq2 : q⁻¹ - 1 = (1 - q) / q := by field_simp
  rw [hq2]
  have h1q : (1 : ℝ) / q = q⁻¹ := one_div q
  rw [h1q]
  ring
