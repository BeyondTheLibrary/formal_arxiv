import Mathlib
import Workspace.ProofLemmas.FqSignAt0Pos
import Workspace.ProofLemmas.FqHasUniqueInteriorZero
import Workspace.ProofLemmas.PhiHasStrictFDerivAt
import Workspace.ProofLemmas.PhiPartialAAtAStarNeg
import Workspace.ProofLemmas.AStarDifferentiable
import Workspace.ProofLemmas.AStarLessThanOneHalf
import Workspace.ProofLemmas.DeltaStarDef
import Workspace.ProofLemmas.DeltaStarDifferentiable

open Workspace.ProofLemmas.FqSignAt0Pos
open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.DeltaStarDef

namespace Workspace.ProofLemmas.LambdaStarMonotoneAux

/-! # Auxiliary derivative computations for `LambdaStarMonotone`

This file builds the explicit derivative of `a_star` (implicit differentiation of
`F_q q (a_star q) = 0`) and then of `delta_star`, used by `LambdaStarMonotone` to
attack the monotonicity of `betaFun q = (delta_star q) ^ (q/(q-1))`.

Notation throughout:
* `s q := (1 - q) / q` (the exponent inside `F_q`).
* `partialQF q a := (1/q^2) * (2*a - a ^ (s q) * (1 + (Real.log a)/q) - 1)`  — `∂_q F`.
* `partialAF q a := 2 * (1 - 1/q) + (1/q) * (s q) * a ^ ((s q) - 1)`           — `∂_a F`.
-/

/-- The exponent appearing in `F_q`. -/
noncomputable def sExp (q : ℝ) : ℝ := (1 - q) / q

/-- The explicit partial derivative `∂_q F` at `(q, a)`. -/
noncomputable def partialQF (q a : ℝ) : ℝ :=
  (1 / q ^ 2) * (2 * a - a ^ (sExp q) * (1 + (Real.log a) / q) - 1)

/-- The explicit partial derivative `∂_a F` at `(q, a)`. -/
noncomputable def partialAF (q a : ℝ) : ℝ :=
  2 * (1 - 1 / q) + (1 / q) * (sExp q) * a ^ ((sExp q) - 1)

/-- `∂_q F`: derivative of `q' ↦ F_q q' a` at `q` (fixed `a > 0`). -/
theorem hasDerivAt_partialQF (q a : ℝ) (hq : q ≠ 0) (ha : 0 < a) :
    HasDerivAt (fun q' : ℝ => F_q q' a) (partialQF q a) q := by
  -- derivative of `q' ↦ 1/q'` is `-1/q^2`.
  have hinv : HasDerivAt (fun q' : ℝ => 1 / q') (-1 / q ^ 2) q := by
    have h : HasDerivAt (fun q' : ℝ => q'⁻¹) (-(q ^ 2)⁻¹) q := hasDerivAt_inv hq
    have h2 : HasDerivAt (fun q' : ℝ => 1 / q') (-(q ^ 2)⁻¹) q := by
      simpa only [one_div] using h
    have heq : -(q ^ 2)⁻¹ = -1 / q ^ 2 := by rw [neg_div, one_div]
    rwa [heq] at h2
  -- derivative of `sExp q' = (1-q')/q'` is `-1/q^2`, via the quotient rule.
  have hs : HasDerivAt (fun q' : ℝ => sExp q') (-1 / q ^ 2) q := by
    have hnum : HasDerivAt (fun q' : ℝ => 1 - q') (-1 : ℝ) q := by
      simpa using (hasDerivAt_id q).const_sub 1
    have hden : HasDerivAt (fun q' : ℝ => q') (1 : ℝ) q := hasDerivAt_id q
    have hdiv := hnum.div hden hq
    have heq : ((-1) * q - (1 - q) * 1) / q ^ 2 = -1 / q ^ 2 := by
      congr 1; ring
    have : HasDerivAt (fun q' : ℝ => (1 - q') / q') (-1 / q ^ 2) q := by
      rw [← heq]; exact hdiv
    exact this
  -- derivative of `q' ↦ a ^ (sExp q')` (constant base `a > 0`).
  have hrpow : HasDerivAt (fun q' : ℝ => a ^ (sExp q'))
      (Real.log a * (-1 / q ^ 2) * a ^ (sExp q)) q :=
    hs.const_rpow ha
  -- t2 q' = (1/q') * a ^ (sExp q')
  have ht2 : HasDerivAt (fun q' : ℝ => (1 / q') * a ^ (sExp q'))
      ((-1 / q ^ 2) * a ^ (sExp q) + (1 / q) * (Real.log a * (-1 / q ^ 2) * a ^ (sExp q))) q :=
    hinv.mul hrpow
  -- t1 q' = 2*(1 - 1/q')*a
  have hone_sub : HasDerivAt (fun q' : ℝ => 1 - 1 / q') (1 / q ^ 2) q := by
    have h := hinv.const_sub 1
    have heq : -(-1 / q ^ 2) = 1 / q ^ 2 := by ring
    rwa [heq] at h
  have ht1 : HasDerivAt (fun q' : ℝ => 2 * (1 - 1 / q') * a)
      ((2 * (1 / q ^ 2)) * a) q :=
    (hone_sub.const_mul 2).mul_const a
  -- Assemble F_q q' a = t1 + t2 - 2 + 1/q'.
  have hsum1 := ht1.add ht2
  have hsum2 := hsum1.sub_const (2 : ℝ)
  have hsum3 := hsum2.add hinv
  -- Identify the function with F_q and the derivative value with partialQF.
  have hfun : (fun q' : ℝ => 2 * (1 - 1 / q') * a + (1 / q') * a ^ (sExp q') - 2 + 1 / q')
      = (fun q' : ℝ => F_q q' a) := by
    funext q'; simp only [F_q, sExp]
  have hval : (2 * (1 / q ^ 2)) * a +
        ((-1 / q ^ 2) * a ^ (sExp q) + (1 / q) * (Real.log a * (-1 / q ^ 2) * a ^ (sExp q)))
        + (-1 / q ^ 2) = partialQF q a := by
    simp only [partialQF]
    field_simp
    ring
  rw [hval] at hsum3
  -- `hsum3` is `HasDerivAt G (partialQF q a) q` where `G` is defeq to `fun q' => F_q q' a`.
  convert hsum3 using 1

/-- `∂_a F`: derivative of `a' ↦ F_q q a'` at `a` (fixed `a > 0`). -/
theorem hasDerivAt_partialAF (q a : ℝ) (ha : 0 < a) :
    HasDerivAt (fun a' : ℝ => F_q q a') (partialAF q a) a := by
  have ha_ne : a ≠ 0 := ne_of_gt ha
  have hd_lin : HasDerivAt (fun a' : ℝ => 2 * (1 - 1 / q) * a') (2 * (1 - 1 / q)) a := by
    simpa using (hasDerivAt_id a).const_mul (2 * (1 - 1 / q))
  have hd_rpow : HasDerivAt (fun a' : ℝ => a' ^ (sExp q))
      ((sExp q) * a ^ ((sExp q) - 1)) a :=
    Real.hasDerivAt_rpow_const (Or.inl ha_ne)
  have hd_smul : HasDerivAt (fun a' : ℝ => (1 / q) * a' ^ (sExp q))
      ((1 / q) * ((sExp q) * a ^ ((sExp q) - 1))) a := hd_rpow.const_mul (1 / q)
  have hd_sum : HasDerivAt (fun a' : ℝ => 2 * (1 - 1 / q) * a' + (1 / q) * a' ^ (sExp q))
      (2 * (1 - 1 / q) + (1 / q) * ((sExp q) * a ^ ((sExp q) - 1))) a :=
    hd_lin.add hd_smul
  have hd_total : HasDerivAt
      (fun a' : ℝ => 2 * (1 - 1 / q) * a' + (1 / q) * a' ^ (sExp q) - 2 + 1 / q)
      (2 * (1 - 1 / q) + (1 / q) * ((sExp q) * a ^ ((sExp q) - 1))) a := by
    have h1 := (hd_sum.sub_const (2 : ℝ)).add_const (1 / q)
    exact h1
  have hfun : (fun a' : ℝ => 2 * (1 - 1 / q) * a' + (1 / q) * a' ^ (sExp q) - 2 + 1 / q)
      = (fun a' : ℝ => F_q q a') := by
    funext a'; simp only [F_q, sExp]
  have hval : (2 * (1 - 1 / q) + (1 / q) * ((sExp q) * a ^ ((sExp q) - 1))) = partialAF q a := by
    simp only [partialAF]; ring
  rw [hval] at hd_total
  convert hd_total using 1

/-- `partialAF q (a_star q) < 0` for `q > 1` (restatement of `PhiPartialAAtAStarNeg`). -/
theorem partialAF_at_aStar_neg (q : ℝ) (hq : 1 < q) :
    partialAF q (a_star q) < 0 := by
  have h := PhiPartialAAtAStarNeg q hq
  -- `h : 2*(1-1/q) + (1/q)*((1-q)/q)*(a_star q)^(((1-q)/q)-1) < 0`
  have heq : partialAF q (a_star q) =
      2 * (1 - 1/q) + (1/q) * ((1 - q)/q) * (a_star q) ^ (((1 - q)/q) - 1) := by
    simp only [partialAF, sExp]
  rw [heq]; exact h

/-- The closed-form derivative of `a_star` via implicit differentiation:
`a_star'(q) = -(∂_q F)/(∂_a F)` evaluated at `(q, a_star q)`. -/
noncomputable def derivAStar (q : ℝ) : ℝ :=
  - (partialQF q (a_star q)) / (partialAF q (a_star q))

/-- **Implicit differentiation.** `a_star` has derivative `derivAStar q` at `q > 1`. -/
theorem hasDerivAt_aStar (q : ℝ) (hq : 1 < q) :
    HasDerivAt a_star (derivAStar q) q := by
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  obtain ⟨ha_pos, ha_lt_half⟩ := AStarLessThanOneHalf q hq
  have ha_lt_one : a_star q < 1 := by linarith
  obtain ⟨_h_unique, h_iA⟩ := FqHasUniqueInteriorZero q hq
  obtain ⟨_, _, hFa⟩ := h_iA
  -- a_star is differentiable, name its derivative d.
  have ha_diff : DifferentiableAt ℝ a_star q := AStarDifferentiable q hq
  set d : ℝ := deriv a_star q with hd_def
  have hP_deriv : HasDerivAt a_star d q := ha_diff.hasDerivAt
  -- The joint strict Fréchet derivative Φ' at (q, a_star q).
  obtain ⟨Φ', hΦ_strict, hΦ_partial⟩ := PhiHasStrictFDerivAt q hq_ne (a_star q) ha_pos
  have hΦ_fderiv : HasFDerivAt (fun u : ℝ × ℝ => F_q u.1 u.2) Φ' (q, a_star q) :=
    hΦ_strict.hasFDerivAt
  -- (1) Φ' (0,1) = partialAF q (a_star q).
  have hΦ01 : Φ' (0, 1) = partialAF q (a_star q) := by
    rw [hΦ_partial]; simp only [partialAF, sExp]
  -- (2) Φ' (1,0) = partialQF q (a_star q), via HasDerivAt uniqueness.
  have hΦ10 : Φ' (1, 0) = partialQF q (a_star q) := by
    -- q' ↦ (q', a_star q) has derivative (1, 0).
    have hP10 : HasDerivAt (fun q' : ℝ => (q', a_star q)) ((1 : ℝ), (0 : ℝ)) q :=
      (hasDerivAt_id q).prodMk (hasDerivAt_const q (a_star q))
    have hcomp10 : HasDerivAt (fun q' : ℝ => F_q q' (a_star q)) (Φ' (1, 0)) q := by
      have h := hΦ_fderiv.comp_hasDerivAt q hP10
      exact h
    have hother := hasDerivAt_partialQF q (a_star q) hq_ne ha_pos
    exact hcomp10.unique hother
  -- The full chain rule: g(q') = F_q q' (a_star q').
  have hP1d : HasDerivAt (fun q' : ℝ => (q', a_star q')) ((1 : ℝ), d) q :=
    (hasDerivAt_id q).prodMk hP_deriv
  have hg : HasDerivAt (fun q' : ℝ => F_q q' (a_star q')) (Φ' (1, d)) q := by
    have h := hΦ_fderiv.comp_hasDerivAt q hP1d
    exact h
  -- Φ' (1, d) = Φ'(1,0) + d • Φ'(0,1) = partialQF + d * partialAF.
  have hlin : Φ' (1, d) = partialQF q (a_star q) + d * partialAF q (a_star q) := by
    have hsplit : ((1 : ℝ), d) = (1, 0) + d • ((0, 1) : ℝ × ℝ) := by
      apply Prod.ext <;> simp
    rw [hsplit, map_add, map_smul, hΦ10, hΦ01, smul_eq_mul]
  rw [hlin] at hg
  -- g =ᶠ 0 near q, so HasDerivAt g 0 q.
  have hg_zero : HasDerivAt (fun q' : ℝ => F_q q' (a_star q')) 0 q := by
    have h_event : (fun q' : ℝ => F_q q' (a_star q')) =ᶠ[nhds q] (fun _ : ℝ => (0 : ℝ)) := by
      have hmem : Set.Ioi (1 : ℝ) ∈ nhds q := (isOpen_Ioi).mem_nhds hq
      filter_upwards [hmem] with q' hq'
      obtain ⟨_, h_iA'⟩ := FqHasUniqueInteriorZero q' hq'
      exact h_iA'.2.2
    exact (hasDerivAt_const q (0 : ℝ)).congr_of_eventuallyEq h_event
  -- Uniqueness: partialQF + d * partialAF = 0.
  have heq0 : partialQF q (a_star q) + d * partialAF q (a_star q) = 0 :=
    hg.unique hg_zero
  -- Solve for d.
  have hAF_ne : partialAF q (a_star q) ≠ 0 := ne_of_lt (partialAF_at_aStar_neg q hq)
  have hd_eq : d = derivAStar q := by
    have : d * partialAF q (a_star q) = - partialQF q (a_star q) := by linarith
    rw [hd_def] at this ⊢
    simp only [derivAStar]
    field_simp
    linarith [this]
  rw [← hd_eq]
  exact hP_deriv

/-! ## Derivative of `delta_star`

`delta_star = N/D` with `N q = a^(1/q) + 1 - 2a`, `D q = (1-a)^(1/q)`, `a = a_star q`.
We build `HasDerivAt` for `N` and `D` and combine by the quotient rule. We do NOT
need a hand-written closed form for the final value: the prover that consumes this
can read off `deriv delta_star q` via `.deriv`. -/

/-- `HasDerivAt` for the numerator `N q = (a_star q)^(1/q) + 1 - 2*(a_star q)`. -/
theorem hasDerivAt_deltaNum (q : ℝ) (hq : 1 < q) :
    HasDerivAt (fun q' : ℝ => (a_star q') ^ ((1:ℝ) / q') + 1 - 2 * (a_star q'))
      ((derivAStar q * (1 / q) * (a_star q) ^ (1 / q - 1)
          + (-1 / q ^ 2) * (a_star q) ^ (1 / q) * Real.log (a_star q))
        - 2 * derivAStar q) q := by
  obtain ⟨ha_pos, ha_lt_half⟩ := AStarLessThanOneHalf q hq
  have hq_pos : (0:ℝ) < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have ha : HasDerivAt a_star (derivAStar q) q := hasDerivAt_aStar q hq
  have hinvq : HasDerivAt (fun q' : ℝ => (1:ℝ) / q') (-1 / q ^ 2) q := by
    have h : HasDerivAt (fun q' : ℝ => q'⁻¹) (-(q ^ 2)⁻¹) q := hasDerivAt_inv hq_ne
    have h2 : HasDerivAt (fun q' : ℝ => 1 / q') (-(q ^ 2)⁻¹) q := by
      simpa only [one_div] using h
    have heq : -(q ^ 2)⁻¹ = -1 / q ^ 2 := by rw [neg_div, one_div]
    rwa [heq] at h2
  -- a^(1/q) via HasDerivAt.rpow.
  have hpow : HasDerivAt (fun q' : ℝ => (a_star q') ^ ((1:ℝ) / q'))
      (derivAStar q * (1 / q) * (a_star q) ^ (1 / q - 1)
        + (-1 / q ^ 2) * (a_star q) ^ (1 / q) * Real.log (a_star q)) q :=
    ha.rpow hinvq ha_pos
  have h2a : HasDerivAt (fun q' : ℝ => 2 * (a_star q')) (2 * derivAStar q) q :=
    ha.const_mul 2
  have hsum := (hpow.add_const (1:ℝ)).sub h2a
  exact hsum

/-- `HasDerivAt` for the denominator `D q = (1 - a_star q)^(1/q)`. -/
theorem hasDerivAt_deltaDen (q : ℝ) (hq : 1 < q) :
    HasDerivAt (fun q' : ℝ => (1 - a_star q') ^ ((1:ℝ) / q'))
      ((-derivAStar q) * (1 / q) * (1 - a_star q) ^ (1 / q - 1)
        + (-1 / q ^ 2) * (1 - a_star q) ^ (1 / q) * Real.log (1 - a_star q)) q := by
  obtain ⟨ha_pos, ha_lt_half⟩ := AStarLessThanOneHalf q hq
  have hq_pos : (0:ℝ) < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h1a_pos : 0 < 1 - a_star q := by linarith
  have ha : HasDerivAt a_star (derivAStar q) q := hasDerivAt_aStar q hq
  have hbase : HasDerivAt (fun q' : ℝ => 1 - a_star q') (-derivAStar q) q := by
    simpa using (ha.const_sub 1)
  have hinvq : HasDerivAt (fun q' : ℝ => (1:ℝ) / q') (-1 / q ^ 2) q := by
    have h : HasDerivAt (fun q' : ℝ => q'⁻¹) (-(q ^ 2)⁻¹) q := hasDerivAt_inv hq_ne
    have h2 : HasDerivAt (fun q' : ℝ => 1 / q') (-(q ^ 2)⁻¹) q := by
      simpa only [one_div] using h
    have heq : -(q ^ 2)⁻¹ = -1 / q ^ 2 := by rw [neg_div, one_div]
    rwa [heq] at h2
  have hpow : HasDerivAt (fun q' : ℝ => (1 - a_star q') ^ ((1:ℝ) / q'))
      ((-derivAStar q) * (1 / q) * (1 - a_star q) ^ (1 / q - 1)
        + (-1 / q ^ 2) * (1 - a_star q) ^ (1 / q) * Real.log (1 - a_star q)) q :=
    hbase.rpow hinvq h1a_pos
  exact hpow

/-- The closed-form derivative of `delta_star` (quotient rule), as a function of
`q`, `a_star q`, and `derivAStar q`. We keep it abstract via `dN`, `dD` below. -/
noncomputable def deltaNumVal (q : ℝ) : ℝ :=
  (a_star q) ^ ((1:ℝ) / q) + 1 - 2 * (a_star q)

noncomputable def deltaDenVal (q : ℝ) : ℝ :=
  (1 - a_star q) ^ ((1:ℝ) / q)

noncomputable def derivDeltaNumVal (q : ℝ) : ℝ :=
  derivAStar q * (1 / q) * (a_star q) ^ (1 / q - 1)
    + (-1 / q ^ 2) * (a_star q) ^ (1 / q) * Real.log (a_star q) - 2 * derivAStar q

noncomputable def derivDeltaDenVal (q : ℝ) : ℝ :=
  (-derivAStar q) * (1 / q) * (1 - a_star q) ^ (1 / q - 1)
    + (-1 / q ^ 2) * (1 - a_star q) ^ (1 / q) * Real.log (1 - a_star q)

/-- The closed form of `deriv delta_star q`. -/
noncomputable def derivDeltaStarVal (q : ℝ) : ℝ :=
  (derivDeltaNumVal q * deltaDenVal q - deltaNumVal q * derivDeltaDenVal q)
    / (deltaDenVal q) ^ 2

/-- **`delta_star` has derivative `derivDeltaStarVal q` at `q > 1`** (quotient rule). -/
theorem hasDerivAt_deltaStar (q : ℝ) (hq : 1 < q) :
    HasDerivAt delta_star (derivDeltaStarVal q) q := by
  obtain ⟨ha_pos, ha_lt_half⟩ := AStarLessThanOneHalf q hq
  have h1a_pos : 0 < 1 - a_star q := by linarith
  have hDen_pos : 0 < deltaDenVal q := Real.rpow_pos_of_pos h1a_pos _
  have hDen_ne : deltaDenVal q ≠ 0 := ne_of_gt hDen_pos
  have hN := hasDerivAt_deltaNum q hq
  have hD := hasDerivAt_deltaDen q hq
  -- delta_star = N / D.
  have hdiv := hN.div hD hDen_ne
  -- Identify the function with delta_star.
  have hfun : (fun q' : ℝ => ((a_star q') ^ ((1:ℝ) / q') + 1 - 2 * (a_star q'))
      / ((1 - a_star q') ^ ((1:ℝ) / q'))) = delta_star := by
    funext q'; simp only [delta_star]
  -- Identify the derivative value.
  have hval :
      (((derivAStar q * (1 / q) * (a_star q) ^ (1 / q - 1)
            + (-1 / q ^ 2) * (a_star q) ^ (1 / q) * Real.log (a_star q)) - 2 * derivAStar q)
          * ((1 - a_star q) ^ ((1:ℝ) / q))
        - ((a_star q) ^ ((1:ℝ) / q) + 1 - 2 * (a_star q))
          * ((-derivAStar q) * (1 / q) * (1 - a_star q) ^ (1 / q - 1)
              + (-1 / q ^ 2) * (1 - a_star q) ^ (1 / q) * Real.log (1 - a_star q)))
        / ((1 - a_star q) ^ ((1:ℝ) / q)) ^ 2
      = derivDeltaStarVal q := by
    simp only [derivDeltaStarVal, derivDeltaNumVal, deltaDenVal, deltaNumVal, derivDeltaDenVal]
  rw [hval] at hdiv
  rw [← hfun]
  exact hdiv

/-- `deriv delta_star q = derivDeltaStarVal q` for `q > 1`. -/
theorem deriv_deltaStar_eq (q : ℝ) (hq : 1 < q) :
    deriv delta_star q = derivDeltaStarVal q :=
  (hasDerivAt_deltaStar q hq).deriv

end Workspace.ProofLemmas.LambdaStarMonotoneAux
