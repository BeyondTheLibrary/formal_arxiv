import Mathlib
import Workspace.ProofLemmas.DeltaStarDef
import Workspace.ProofLemmas.AStarContinuousOn
import Workspace.ProofLemmas.AStarLessThanOneHalf

open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.FqHasUniqueInteriorZero

theorem DeltaStarContinuousOn : ContinuousOn delta_star (Set.Ioi (1 : ℝ)) := by
  -- Pointwise positivity facts
  have h_astar_pos : ∀ q ∈ Set.Ioi (1 : ℝ), 0 < a_star q := fun q hq =>
    (AStarLessThanOneHalf q hq).1
  have h_astar_lt_half : ∀ q ∈ Set.Ioi (1 : ℝ), a_star q < 1/2 := fun q hq =>
    (AStarLessThanOneHalf q hq).2
  have h_one_minus_pos : ∀ q ∈ Set.Ioi (1 : ℝ), 0 < 1 - a_star q := by
    intro q hq
    have h := h_astar_lt_half q hq
    linarith
  -- Continuity of basic ingredients on Ioi 1
  have hCont_astar : ContinuousOn a_star (Set.Ioi (1 : ℝ)) := AStarContinuousOn
  have hCont_id : ContinuousOn (fun q : ℝ => q) (Set.Ioi (1 : ℝ)) := continuousOn_id
  have hCont_one : ContinuousOn (fun q : ℝ => (1 : ℝ)) (Set.Ioi (1 : ℝ)) := continuousOn_const
  -- Continuity of q ↦ 1/q on Ioi 1 (q ≠ 0 there)
  have hCont_recip : ContinuousOn (fun q : ℝ => (1 : ℝ) / q) (Set.Ioi (1 : ℝ)) := by
    apply ContinuousOn.div hCont_one hCont_id
    intro q hq
    have hq1 : 1 < q := hq
    linarith
  -- Continuity of q ↦ 1 - a_star q
  have hCont_one_minus : ContinuousOn (fun q : ℝ => 1 - a_star q) (Set.Ioi (1 : ℝ)) :=
    hCont_one.sub hCont_astar
  -- Continuity of q ↦ (a_star q) ^ (1/q)
  have hCont_num1 : ContinuousOn
      (fun q : ℝ => (a_star q) ^ ((1 : ℝ) / q)) (Set.Ioi (1 : ℝ)) := by
    apply ContinuousOn.rpow hCont_astar hCont_recip
    intro q hq
    left
    exact ne_of_gt (h_astar_pos q hq)
  -- Continuity of q ↦ 2 * a_star q
  have hCont_two_astar : ContinuousOn
      (fun q : ℝ => 2 * a_star q) (Set.Ioi (1 : ℝ)) :=
    continuousOn_const.mul hCont_astar
  -- Continuity of the numerator: (a_star q)^(1/q) + 1 - 2 * a_star q
  have hCont_num : ContinuousOn
      (fun q : ℝ => (a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q))
      (Set.Ioi (1 : ℝ)) :=
    (hCont_num1.add hCont_one).sub hCont_two_astar
  -- Continuity of the denominator: (1 - a_star q) ^ (1/q)
  have hCont_denom : ContinuousOn
      (fun q : ℝ => (1 - a_star q) ^ ((1 : ℝ) / q)) (Set.Ioi (1 : ℝ)) := by
    apply ContinuousOn.rpow hCont_one_minus hCont_recip
    intro q hq
    left
    exact ne_of_gt (h_one_minus_pos q hq)
  -- Denominator is nonzero on Ioi 1
  have h_denom_ne : ∀ q ∈ Set.Ioi (1 : ℝ),
      (1 - a_star q) ^ ((1 : ℝ) / q) ≠ 0 := by
    intro q hq
    exact ne_of_gt (Real.rpow_pos_of_pos (h_one_minus_pos q hq) _)
  -- Combine via division
  have hdiv : ContinuousOn
      (fun q : ℝ =>
        ((a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q)) /
          (1 - a_star q) ^ ((1 : ℝ) / q))
      (Set.Ioi (1 : ℝ)) := by
    have := hCont_num.div hCont_denom h_denom_ne
    exact this
  -- Match the goal: delta_star is exactly this expression
  have hcongr : ∀ q ∈ Set.Ioi (1 : ℝ),
      delta_star q =
        ((a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q)) /
          (1 - a_star q) ^ ((1 : ℝ) / q) := by
    intro q _
    rfl
  exact hdiv.congr (fun q hq => (hcongr q hq).symm)
