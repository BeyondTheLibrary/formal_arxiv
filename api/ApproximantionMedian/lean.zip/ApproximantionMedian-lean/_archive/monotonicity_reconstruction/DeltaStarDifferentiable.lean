import Mathlib
import Workspace.ProofLemmas.DeltaStarDef
import Workspace.ProofLemmas.AStarDifferentiable
import Workspace.ProofLemmas.AStarLessThanOneHalf

open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.FqHasUniqueInteriorZero

theorem DeltaStarDifferentiable : ∀ q : ℝ, 1 < q → DifferentiableAt ℝ delta_star q := by
  intro q hq
  -- Basic facts
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  obtain ⟨ha_pos, ha_lt_half⟩ := AStarLessThanOneHalf q hq
  have ha_ne : a_star q ≠ 0 := ne_of_gt ha_pos
  have ha_lt_one : a_star q < 1 := by linarith
  have h1_minus_pos : 0 < 1 - a_star q := by linarith
  have h1_minus_ne : 1 - a_star q ≠ 0 := ne_of_gt h1_minus_pos
  -- Differentiability of basic pieces
  have ha_diff : DifferentiableAt ℝ a_star q := AStarDifferentiable q hq
  have h_inv_q_diff : DifferentiableAt ℝ (fun q : ℝ => (1 : ℝ) / q) q := by
    exact (differentiableAt_const 1).div differentiableAt_id hq_ne
  -- (a_star q)^(1/q) is differentiable
  have h_num1_diff : DifferentiableAt ℝ (fun q : ℝ => (a_star q) ^ ((1 : ℝ) / q)) q := by
    exact ha_diff.rpow h_inv_q_diff ha_ne
  -- (1 - a_star q) is differentiable
  have h_one_minus_diff : DifferentiableAt ℝ (fun q : ℝ => 1 - a_star q) q :=
    (differentiableAt_const 1).sub ha_diff
  -- (1 - a_star q)^(1/q) is differentiable
  have h_denom_diff : DifferentiableAt ℝ (fun q : ℝ => (1 - a_star q) ^ ((1 : ℝ) / q)) q := by
    exact h_one_minus_diff.rpow h_inv_q_diff h1_minus_ne
  -- 2 * a_star q is differentiable
  have h_two_a_diff : DifferentiableAt ℝ (fun q : ℝ => 2 * a_star q) q :=
    (differentiableAt_const 2).mul ha_diff
  -- Numerator is differentiable
  have h_num_diff : DifferentiableAt ℝ
      (fun q : ℝ => (a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q)) q := by
    exact (h_num1_diff.add (differentiableAt_const 1)).sub h_two_a_diff
  -- Denominator nonzero
  have h_denom_ne : (1 - a_star q) ^ ((1 : ℝ) / q) ≠ 0 := by
    exact ne_of_gt (Real.rpow_pos_of_pos h1_minus_pos _)
  -- Combine
  have : DifferentiableAt ℝ
      (fun q : ℝ => ((a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q)) /
                    ((1 - (a_star q)) ^ ((1 : ℝ) / q))) q :=
    h_num_diff.div h_denom_diff h_denom_ne
  -- delta_star is exactly this function
  show DifferentiableAt ℝ delta_star q
  unfold delta_star
  exact this
