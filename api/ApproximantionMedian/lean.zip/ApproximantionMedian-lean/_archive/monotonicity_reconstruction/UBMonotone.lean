import Mathlib
import Workspace.ProofLemmas.UBDef
import Workspace.ProofLemmas.LambdaStarDef
import Workspace.ProofLemmas.LambdaStarMonotone

open Workspace.ProofLemmas.UBDef
open Workspace.ProofLemmas.LambdaStarDef
open Workspace.ProofLemmas.LambdaStarMonotone

/--
`UB` is monotone (non-decreasing) on `[1, ∞)`.

Proof structure (fully proven modulo the single isolated analytic lemma
`LambdaStarMonotone.deriv_lambda_star_nonpos`, which carries the only remaining
`sorry` in this development):

* For `q ≥ 1` we have `UB q = 1 / lambda_star q` and `lambda_star q > 0`.
* `lambda_star` is antitone on `[1, ∞)` (`lambda_star_antitoneOn_Ici`), so for
  `1 ≤ a ≤ b` we get `0 < lambda_star b ≤ lambda_star a`.
* Hence `1 / lambda_star a ≤ 1 / lambda_star b`, i.e. `UB a ≤ UB b`.
-/
theorem UBMonotone : MonotoneOn UB (Set.Ici (1 : ℝ)) := by
  intro a ha b hb hab
  have ha1 : 1 ≤ a := ha
  have hb1 : 1 ≤ b := hb
  -- Unfold `UB` on `[1, ∞)`.
  have hUBa : UB a = 1 / lambda_star a := by simp only [UB, if_pos ha1]
  have hUBb : UB b = 1 / lambda_star b := by simp only [UB, if_pos hb1]
  rw [hUBa, hUBb]
  -- Positivity and antitonicity of `lambda_star`.
  have hLb_pos : 0 < lambda_star b := lambda_star_pos b hb1
  have hLba : lambda_star b ≤ lambda_star a :=
    lambda_star_antitoneOn_Ici ha hb hab
  exact one_div_le_one_div_of_le hLb_pos hLba
