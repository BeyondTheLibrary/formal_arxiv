import Mathlib
import Workspace.ProofLemmas.HSecondDerivative
import Workspace.ProofLemmas.HConvexOnLeft_ConcaveOnRight

open Workspace.ProofLemmas.HSecondDerivative

theorem HQStrictConvexOnIoo
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) :
    let z := delta ^ (-(q / (2*q - 1))) / (delta ^ (-(q / (2*q - 1))) + 1)
    StrictConvexOn ℝ (Set.Ioo (0 : ℝ) z) (fun y => h_q q lambda delta y) := by
  intro z
  -- Get HConvex info about z and second derivative
  have hConvex := HConvexOnLeft_ConcaveOnRight q hq lambda hlam delta hdelta
  obtain ⟨⟨hz_pos, hz_le_half⟩, hsecond_pos, _⟩ := hConvex
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_inv_nonneg : (0 : ℝ) ≤ 1 / q := by positivity
  -- Continuity of h_q on all of ℝ (since 1/q > 0)
  have hCont_global : Continuous (fun y => h_q q lambda delta y) := by
    have h1 : Continuous (fun y : ℝ => y ^ ((1:ℝ) / q)) :=
      Real.continuous_rpow_const hq_inv_nonneg
    have h2 : Continuous (fun y : ℝ => (1 - y) ^ ((1:ℝ) / q)) := by
      have h_sub : Continuous (fun y : ℝ => 1 - y) := by continuity
      exact (Real.continuous_rpow_const hq_inv_nonneg).comp h_sub
    have h3 : Continuous (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ) / q)) :=
      continuous_const.mul h2
    have h4 : Continuous (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ) / q) - y ^ ((1:ℝ) / q)) :=
      h3.sub h1
    have h5 : Continuous (fun y : ℝ =>
        lambda * (delta * (1 - y) ^ ((1:ℝ) / q) - y ^ ((1:ℝ) / q))) :=
      continuous_const.mul h4
    -- h_q matches the lambda * (...) form
    have h_eq : (fun y => h_q q lambda delta y) =
        (fun y : ℝ => lambda * (delta * (1 - y) ^ ((1:ℝ) / q) - y ^ ((1:ℝ) / q))) := by
      funext y
      rfl
    rw [h_eq]
    exact h5
  have hCont : ContinuousOn (fun y => h_q q lambda delta y) (Set.Ioo (0 : ℝ) z) :=
    hCont_global.continuousOn
  -- Apply strictConvexOn_of_deriv2_pos
  apply strictConvexOn_of_deriv2_pos (convex_Ioo 0 z) hCont
  intro x hx
  rw [interior_Ioo] at hx
  obtain ⟨hx0, hxz⟩ := hx
  have h_iter_eq : (deriv^[2] (fun y => h_q q lambda delta y)) x =
      iteratedDeriv 2 (fun y => h_q q lambda delta y) x := by
    rw [iteratedDeriv_eq_iterate]
  rw [h_iter_eq]
  exact hsecond_pos x hx0 hxz
