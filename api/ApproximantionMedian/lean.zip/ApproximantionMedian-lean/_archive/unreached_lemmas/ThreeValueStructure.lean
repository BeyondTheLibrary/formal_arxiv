import Mathlib
import Workspace.ProofLemmas.HSecondDerivative
import Workspace.ProofLemmas.HConvexOnLeft_ConcaveOnRight
import Workspace.ProofLemmas.HQStrictConvexOnIoo
import Workspace.ProofLemmas.HQStrictConcaveOnIoo

open Workspace.ProofLemmas.HSecondDerivative

set_option maxHeartbeats 4000000

/-!
Attempt 6 for ThreeValueStructure (Lemma 5 of approx.tex).

Strategy: same as Attempt 5; fix the unsolved goals in the field-simp combos
and the `cover` ext.
-/

theorem ThreeValueStructure
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta)
    {n : ℕ} (hn_pos : 0 < n) (hn_even : Even n)
    (x : Fin n → ℝ)
    (hx0 : ∀ i, 0 ≤ x i) (hx1 : ∀ i, x i ≤ 1)
    (hx_sum : (∑ i, x i) = (n : ℝ) / 2)
    (hx_min : ∀ y : Fin n → ℝ, (∀ i, 0 ≤ y i) → (∀ i, y i ≤ 1) →
              (∑ i, y i) = (n : ℝ) / 2 →
              (∑ i, h_q q lambda delta (x i)) ≤ (∑ i, h_q q lambda delta (y i))) :
    let z := delta ^ (-(q / (2*q - 1))) / (delta ^ (-(q / (2*q - 1))) + 1)
    ∃ a b : ℝ, ∃ I_a I_b I_one : Finset (Fin n),
      0 ≤ a ∧ a ≤ z ∧ z ≤ b ∧ b ≤ 1 ∧
      Disjoint I_a I_b ∧ Disjoint I_a I_one ∧ Disjoint I_b I_one ∧
      (I_a ∪ I_b ∪ I_one = Finset.univ) ∧
      (∀ i ∈ I_a, x i = a) ∧ (∀ i ∈ I_b, x i = b) ∧ (∀ i ∈ I_one, x i = 1) ∧
      I_b.card ≤ 1 := by
  intro z
  classical
  have hz_props := HConvexOnLeft_ConcaveOnRight q hq lambda hlam delta hdelta
  obtain ⟨⟨hz_pos, hz_le_half⟩, hconv2, hconc2⟩ := hz_props
  have hz_lt_one : z < 1 := lt_of_le_of_lt hz_le_half (by norm_num)
  have hz_nonneg : 0 ≤ z := le_of_lt hz_pos
  have hz_le_one : z ≤ 1 := le_of_lt hz_lt_one
  -- Continuity of h_q on all of ℝ (since 1/q > 0)
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_inv_nonneg : (0 : ℝ) ≤ 1 / q := by positivity
  have hCont_global : Continuous (fun y => h_q q lambda delta y) := by
    have h1 : Continuous (fun y : ℝ => y ^ ((1:ℝ) / q)) :=
      Real.continuous_rpow_const hq_inv_nonneg
    have h2 : Continuous (fun y : ℝ => (1 - y) ^ ((1:ℝ) / q)) := by
      have h_sub : Continuous (fun y : ℝ => 1 - y) := by continuity
      exact (Real.continuous_rpow_const hq_inv_nonneg).comp h_sub
    have h3 : Continuous (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ) / q)) :=
      continuous_const.mul h2
    have h4 : Continuous (fun y : ℝ =>
        delta * (1 - y) ^ ((1:ℝ) / q) - y ^ ((1:ℝ) / q)) := h3.sub h1
    have h5 : Continuous (fun y : ℝ =>
        lambda * (delta * (1 - y) ^ ((1:ℝ) / q) - y ^ ((1:ℝ) / q))) :=
      continuous_const.mul h4
    have h_eq : (fun y => h_q q lambda delta y) =
        (fun y : ℝ => lambda * (delta * (1 - y) ^ ((1:ℝ) / q) - y ^ ((1:ℝ) / q))) := by
      funext y; rfl
    rw [h_eq]; exact h5
  -- Strict convex on closed Icc 0 z
  have hSCvx_Icc : StrictConvexOn ℝ (Set.Icc (0 : ℝ) z) (fun y => h_q q lambda delta y) := by
    apply strictConvexOn_of_deriv2_pos (convex_Icc 0 z) hCont_global.continuousOn
    intro x hx
    have hx_int : x ∈ Set.Ioo (0:ℝ) z := by
      rwa [interior_Icc] at hx
    obtain ⟨hx0', hxz⟩ := hx_int
    have h_iter_eq : (deriv^[2] (fun y => h_q q lambda delta y)) x =
        iteratedDeriv 2 (fun y => h_q q lambda delta y) x := by
      rw [iteratedDeriv_eq_iterate]
    rw [h_iter_eq]
    exact hconv2 x hx0' hxz
  -- Strict concave on closed Icc z 1
  have hSCcv_Icc : StrictConcaveOn ℝ (Set.Icc z 1) (fun y => h_q q lambda delta y) := by
    apply strictConcaveOn_of_deriv2_neg (convex_Icc z 1) hCont_global.continuousOn
    intro x hx
    have hx_int : x ∈ Set.Ioo z 1 := by
      rwa [interior_Icc] at hx
    obtain ⟨hxz, hx1'⟩ := hx_int
    have h_iter_eq : (deriv^[2] (fun y => h_q q lambda delta y)) x =
        iteratedDeriv 2 (fun y => h_q q lambda delta y) x := by
      rw [iteratedDeriv_eq_iterate]
    rw [h_iter_eq]
    exact hconc2 x hxz hx1'
  -- Helper lemma 1: convex contradiction for two distinct values both in [0, z].
  have noTwoDistinctInIcc0z : ¬ ∃ i j : Fin n, x i ≤ z ∧ x j ≤ z ∧ x i ≠ x j := by
    rintro ⟨i, j, hxi_le, hxj_le, hij_ne⟩
    have hi_ne_j : i ≠ j := fun h => by subst h; exact hij_ne rfl
    have hxi_nn : 0 ≤ x i := hx0 i
    have hxj_nn : 0 ≤ x j := hx0 j
    let y : Fin n → ℝ := fun k =>
      if k = i then (x i + x j) / 2
      else if k = j then (x i + x j) / 2
      else x k
    have hyi : y i = (x i + x j) / 2 := by simp [y]
    have hyj : y j = (x i + x j) / 2 := by simp [y, (Ne.symm hi_ne_j)]
    have hy_outside : ∀ k, k ≠ i → k ≠ j → y k = x k := by
      intro k hki hkj
      simp [y, hki, hkj]
    have hy0 : ∀ k, 0 ≤ y k := by
      intro k
      simp only [y]
      split_ifs with hki hkj
      · linarith
      · linarith
      · exact hx0 k
    have hy1 : ∀ k, y k ≤ 1 := by
      intro k
      simp only [y]
      split_ifs with hki hkj
      · have : (x i + x j) / 2 ≤ z := by linarith
        linarith
      · have : (x i + x j) / 2 ≤ z := by linarith
        linarith
      · exact hx1 k
    have hy_sum : (∑ k, y k) = (∑ k, x k) := by
      have hpair_sub : ({i, j} : Finset (Fin n)) ⊆ Finset.univ := Finset.subset_univ _
      have hsum_x_split :
          (∑ k, x k) = (∑ k ∈ ({i, j} : Finset (Fin n)), x k) +
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), x k) := by
        have := Finset.sum_sdiff (f := x) hpair_sub
        linarith
      have hsum_y_split :
          (∑ k, y k) = (∑ k ∈ ({i, j} : Finset (Fin n)), y k) +
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k) := by
        have := Finset.sum_sdiff (f := y) hpair_sub
        linarith
      have hpair_x : (∑ k ∈ ({i, j} : Finset (Fin n)), x k) = x i + x j := by
        rw [Finset.sum_pair hi_ne_j]
      have hpair_y : (∑ k ∈ ({i, j} : Finset (Fin n)), y k) = y i + y j := by
        rw [Finset.sum_pair hi_ne_j]
      have houtside_eq : ∀ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k = x k := by
        intro k hk
        simp only [Finset.mem_sdiff, Finset.mem_univ, true_and,
                   Finset.mem_insert, Finset.mem_singleton, not_or] at hk
        exact hy_outside k hk.1 hk.2
      have hsum_outside_eq :
          (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k) =
          (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), x k) :=
        Finset.sum_congr rfl houtside_eq
      have hyi_yj : y i + y j = x i + x j := by
        rw [hyi, hyj]; ring
      rw [hsum_y_split, hsum_x_split, hpair_x, hpair_y, hyi_yj, hsum_outside_eq]
    have hy_sum_half : (∑ k, y k) = (n : ℝ) / 2 := by rw [hy_sum]; exact hx_sum
    have hxi_in : x i ∈ Set.Icc (0:ℝ) z := ⟨hxi_nn, hxi_le⟩
    have hxj_in : x j ∈ Set.Icc (0:ℝ) z := ⟨hxj_nn, hxj_le⟩
    have hstrict :
        h_q q lambda delta ((x i + x j) / 2) <
          (h_q q lambda delta (x i) + h_q q lambda delta (x j)) / 2 := by
      have h_smul := (hSCvx_Icc.2) hxi_in hxj_in hij_ne
        (a := (1:ℝ)/2) (b := (1:ℝ)/2)
        (by norm_num : (0:ℝ) < 1/2) (by norm_num : (0:ℝ) < 1/2)
        (by norm_num : (1:ℝ)/2 + 1/2 = 1)
      simp only [smul_eq_mul] at h_smul
      have heq1 : (1:ℝ)/2 * x i + (1:ℝ)/2 * x j = (x i + x j) / 2 := by ring
      have heq2 : (1:ℝ)/2 * h_q q lambda delta (x i) + (1:ℝ)/2 * h_q q lambda delta (x j)
          = (h_q q lambda delta (x i) + h_q q lambda delta (x j)) / 2 := by ring
      rw [heq1, heq2] at h_smul
      exact h_smul
    have hpair_sub : ({i, j} : Finset (Fin n)) ⊆ Finset.univ := Finset.subset_univ _
    have hsum_hx_split :
        (∑ k, h_q q lambda delta (x k)) =
        (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) +
          (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) := by
      have := Finset.sum_sdiff (f := fun k => h_q q lambda delta (x k)) hpair_sub
      linarith
    have hsum_hy_split :
        (∑ k, h_q q lambda delta (y k)) =
        (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) +
          (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) := by
      have := Finset.sum_sdiff (f := fun k => h_q q lambda delta (y k)) hpair_sub
      linarith
    have hpair_hx : (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) =
        h_q q lambda delta (x i) + h_q q lambda delta (x j) := by
      rw [Finset.sum_pair hi_ne_j]
    have hpair_hy : (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) =
        h_q q lambda delta (y i) + h_q q lambda delta (y j) := by
      rw [Finset.sum_pair hi_ne_j]
    have houtside_h_eq :
        ∀ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)),
          h_q q lambda delta (y k) = h_q q lambda delta (x k) := by
      intro k hk
      simp only [Finset.mem_sdiff, Finset.mem_univ, true_and,
                 Finset.mem_insert, Finset.mem_singleton, not_or] at hk
      rw [hy_outside k hk.1 hk.2]
    have hsum_outside_h_eq :
        (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) =
        (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) :=
      Finset.sum_congr rfl houtside_h_eq
    have hyi_yj_h : h_q q lambda delta (y i) + h_q q lambda delta (y j) <
        h_q q lambda delta (x i) + h_q q lambda delta (x j) := by
      rw [hyi, hyj]
      linarith
    have hsum_lt : (∑ k, h_q q lambda delta (y k)) < (∑ k, h_q q lambda delta (x k)) := by
      rw [hsum_hy_split, hsum_hx_split, hpair_hy, hpair_hx, hsum_outside_h_eq]
      linarith
    have hmin := hx_min y hy0 hy1 hy_sum_half
    linarith
  -- Helper lemma 2: concave contradiction for two distinct indices i ≠ j with
  -- x_i ∈ (z, 1) AND x_j ∈ [z, 1] and x_j < 1 (so we have ε > 0 spread room).
  have noTwoInIozOne : ¬ ∃ i j : Fin n, i ≠ j ∧ z < x i ∧ x i < 1 ∧
      z ≤ x j ∧ x j < 1 ∧ z < x j := by
    rintro ⟨i, j, hi_ne_j, hxi_z, hxi_lt1, hxj_z_le, hxj_lt1, hxj_z⟩
    rcases le_or_gt (x i) (x j) with hxij_le | hxij_lt
    · -- x i ≤ x j. Spread: y i = x i - ε, y j = x j + ε.
      set εmin := min (x i - z) (1 - x j) with hε_def
      have hε_pos : 0 < εmin := by
        rw [hε_def]
        exact lt_min (by linarith) (by linarith)
      set ε : ℝ := εmin / 2 with hε_eq
      have hε_pos' : 0 < ε := by rw [hε_eq]; linarith
      have hε_lt_xi_minus_z : ε < x i - z := by
        rw [hε_eq, hε_def]
        have : min (x i - z) (1 - x j) ≤ x i - z := min_le_left _ _
        linarith
      have hε_lt_one_minus_xj : ε < 1 - x j := by
        rw [hε_eq, hε_def]
        have : min (x i - z) (1 - x j) ≤ 1 - x j := min_le_right _ _
        linarith
      let y : Fin n → ℝ := fun k =>
        if k = i then x i - ε
        else if k = j then x j + ε
        else x k
      have hyi_eq : y i = x i - ε := by simp [y]
      have hyj_eq : y j = x j + ε := by simp [y, hi_ne_j.symm]
      have hy_outside : ∀ k, k ≠ i → k ≠ j → y k = x k := by
        intro k hki hkj
        simp [y, hki, hkj]
      have hyi_in : y i ∈ Set.Icc z 1 := by
        rw [hyi_eq]
        constructor
        · linarith
        · linarith
      have hyj_in : y j ∈ Set.Icc z 1 := by
        rw [hyj_eq]
        constructor
        · linarith
        · linarith
      have hxi_in : x i ∈ Set.Icc z 1 := ⟨le_of_lt hxi_z, le_of_lt hxi_lt1⟩
      have hxj_in : x j ∈ Set.Icc z 1 := ⟨hxj_z_le, le_of_lt hxj_lt1⟩
      have hy0 : ∀ k, 0 ≤ y k := by
        intro k
        simp only [y]
        split_ifs with hki hkj
        · have : 0 ≤ x i - ε := by linarith
          linarith
        · have : 0 ≤ x j + ε := by linarith [hx0 j]
          linarith
        · exact hx0 k
      have hy1 : ∀ k, y k ≤ 1 := by
        intro k
        simp only [y]
        split_ifs with hki hkj
        · linarith [hx1 i]
        · linarith
        · exact hx1 k
      have hy_sum : (∑ k, y k) = (∑ k, x k) := by
        have hpair_sub : ({i, j} : Finset (Fin n)) ⊆ Finset.univ := Finset.subset_univ _
        have hsum_x_split :
            (∑ k, x k) = (∑ k ∈ ({i, j} : Finset (Fin n)), x k) +
              (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), x k) := by
          have := Finset.sum_sdiff (f := x) hpair_sub
          linarith
        have hsum_y_split :
            (∑ k, y k) = (∑ k ∈ ({i, j} : Finset (Fin n)), y k) +
              (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k) := by
          have := Finset.sum_sdiff (f := y) hpair_sub
          linarith
        have hpair_x : (∑ k ∈ ({i, j} : Finset (Fin n)), x k) = x i + x j := by
          rw [Finset.sum_pair hi_ne_j]
        have hpair_y : (∑ k ∈ ({i, j} : Finset (Fin n)), y k) = y i + y j := by
          rw [Finset.sum_pair hi_ne_j]
        have houtside_eq : ∀ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k = x k := by
          intro k hk
          simp only [Finset.mem_sdiff, Finset.mem_univ, true_and,
                     Finset.mem_insert, Finset.mem_singleton, not_or] at hk
          exact hy_outside k hk.1 hk.2
        have hsum_outside_eq :
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k) =
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), x k) :=
          Finset.sum_congr rfl houtside_eq
        have hyi_yj : y i + y j = x i + x j := by
          rw [hyi_eq, hyj_eq]; ring
        rw [hsum_y_split, hsum_x_split, hpair_x, hpair_y, hyi_yj, hsum_outside_eq]
      have hy_sum_half : (∑ k, y k) = (n : ℝ) / 2 := by rw [hy_sum]; exact hx_sum
      have hyi_lt_xi : y i < x i := by rw [hyi_eq]; linarith
      have hxj_lt_yj : x j < y j := by rw [hyj_eq]; linarith
      have hyi_lt_yj : y i < y j := by linarith
      have hyj_minus_yi_pos : 0 < y j - y i := by linarith
      have hyj_minus_yi_ne : y j - y i ≠ 0 := ne_of_gt hyj_minus_yi_pos
      set s : ℝ := (x i - y i) / (y j - y i) with hs_def
      have hs_pos : 0 < s := by
        rw [hs_def]; exact div_pos (by linarith) hyj_minus_yi_pos
      have hs_lt_one : s < 1 := by
        rw [hs_def, div_lt_one hyj_minus_yi_pos]
        linarith
      -- Define t inline as 1 - s, but use it as a fresh local term to avoid `set` issues.
      have ht_pos : 0 < (1 - s) := by linarith
      have hxi_combo : x i = (1 - s) * y i + s * y j := by
        have key : (1 - s) * y i + s * y j = y i + s * (y j - y i) := by ring
        rw [key, hs_def, div_mul_cancel₀ _ hyj_minus_yi_ne]
        linarith
      have hxj_combo : x j = s * y i + (1 - s) * y j := by
        -- y i + y j = x i + x j. So x j = (y i + y j) - x i = (x i + x j) - x i.
        -- s * y i + (1 - s) * y j = y j - s * (y j - y i) = y j - (x i - y i) = y j - x i + y i.
        have key : s * y i + (1 - s) * y j = y j - s * (y j - y i) := by ring
        rw [key, hs_def, div_mul_cancel₀ _ hyj_minus_yi_ne]
        -- Need: x j = y j - (x i - y i). I.e. x j + x i = y j + y i.
        have hsum_yij : y i + y j = x i + x j := by rw [hyi_eq, hyj_eq]; ring
        linarith
      have hyi_ne_yj : y i ≠ y j := ne_of_lt hyi_lt_yj
      -- Apply strict concavity to get strict inequalities — use strictConcaveOn.2 with explicit args.
      have hSCcv_pair := hSCcv_Icc.2
      have h_concav : (1 - s) • h_q q lambda delta (y i) + s • h_q q lambda delta (y j) <
          h_q q lambda delta ((1 - s) • y i + s • y j) :=
        hSCcv_pair hyi_in hyj_in hyi_ne_yj ht_pos hs_pos (by linarith)
      have h_concav' : s • h_q q lambda delta (y i) + (1 - s) • h_q q lambda delta (y j) <
          h_q q lambda delta (s • y i + (1 - s) • y j) :=
        hSCcv_pair hyi_in hyj_in hyi_ne_yj hs_pos ht_pos (by linarith)
      simp only [smul_eq_mul] at h_concav h_concav'
      have h1 : (1 - s) * h_q q lambda delta (y i) + s * h_q q lambda delta (y j) <
          h_q q lambda delta (x i) := by
        rw [hxi_combo]; exact h_concav
      have h2 : s * h_q q lambda delta (y i) + (1 - s) * h_q q lambda delta (y j) <
          h_q q lambda delta (x j) := by
        rw [hxj_combo]; exact h_concav'
      have hsum_added := add_lt_add h1 h2
      have hcombine_lhs :
          ((1 - s) * h_q q lambda delta (y i) + s * h_q q lambda delta (y j))
            + (s * h_q q lambda delta (y i) + (1 - s) * h_q q lambda delta (y j))
          = h_q q lambda delta (y i) + h_q q lambda delta (y j) := by ring
      rw [hcombine_lhs] at hsum_added
      have hsum_y_lt_x : h_q q lambda delta (y i) + h_q q lambda delta (y j) <
          h_q q lambda delta (x i) + h_q q lambda delta (x j) := hsum_added
      have hpair_sub : ({i, j} : Finset (Fin n)) ⊆ Finset.univ := Finset.subset_univ _
      have hsum_hx_split :
          (∑ k, h_q q lambda delta (x k)) =
          (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) +
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) := by
        have := Finset.sum_sdiff (f := fun k => h_q q lambda delta (x k)) hpair_sub
        linarith
      have hsum_hy_split :
          (∑ k, h_q q lambda delta (y k)) =
          (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) +
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) := by
        have := Finset.sum_sdiff (f := fun k => h_q q lambda delta (y k)) hpair_sub
        linarith
      have hpair_hx : (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) =
          h_q q lambda delta (x i) + h_q q lambda delta (x j) := by
        rw [Finset.sum_pair hi_ne_j]
      have hpair_hy : (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) =
          h_q q lambda delta (y i) + h_q q lambda delta (y j) := by
        rw [Finset.sum_pair hi_ne_j]
      have houtside_h_eq :
          ∀ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)),
            h_q q lambda delta (y k) = h_q q lambda delta (x k) := by
        intro k hk
        simp only [Finset.mem_sdiff, Finset.mem_univ, true_and,
                   Finset.mem_insert, Finset.mem_singleton, not_or] at hk
        rw [hy_outside k hk.1 hk.2]
      have hsum_outside_h_eq :
          (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) =
          (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) :=
        Finset.sum_congr rfl houtside_h_eq
      have hsum_lt : (∑ k, h_q q lambda delta (y k)) < (∑ k, h_q q lambda delta (x k)) := by
        rw [hsum_hy_split, hsum_hx_split, hpair_hy, hpair_hx, hsum_outside_h_eq]
        linarith
      have hmin := hx_min y hy0 hy1 hy_sum_half
      linarith
    · -- x j < x i case. Swap roles: y i = x i + ε, y j = x j - ε.
      set εmin := min (x j - z) (1 - x i) with hε_def
      have hε_pos : 0 < εmin := by
        rw [hε_def]
        exact lt_min (by linarith) (by linarith)
      set ε : ℝ := εmin / 2 with hε_eq
      have hε_pos' : 0 < ε := by rw [hε_eq]; linarith
      have hε_lt_xj_minus_z : ε < x j - z := by
        rw [hε_eq, hε_def]
        have : min (x j - z) (1 - x i) ≤ x j - z := min_le_left _ _
        linarith
      have hε_lt_one_minus_xi : ε < 1 - x i := by
        rw [hε_eq, hε_def]
        have : min (x j - z) (1 - x i) ≤ 1 - x i := min_le_right _ _
        linarith
      let y : Fin n → ℝ := fun k =>
        if k = i then x i + ε
        else if k = j then x j - ε
        else x k
      have hyi_eq : y i = x i + ε := by simp [y]
      have hyj_eq : y j = x j - ε := by simp [y, hi_ne_j.symm]
      have hy_outside : ∀ k, k ≠ i → k ≠ j → y k = x k := by
        intro k hki hkj
        simp [y, hki, hkj]
      have hyi_in : y i ∈ Set.Icc z 1 := by
        rw [hyi_eq]
        constructor
        · linarith
        · linarith
      have hyj_in : y j ∈ Set.Icc z 1 := by
        rw [hyj_eq]
        constructor
        · linarith
        · linarith
      have hxi_in : x i ∈ Set.Icc z 1 := ⟨le_of_lt hxi_z, le_of_lt hxi_lt1⟩
      have hxj_in : x j ∈ Set.Icc z 1 := ⟨hxj_z_le, le_of_lt hxj_lt1⟩
      have hy0 : ∀ k, 0 ≤ y k := by
        intro k
        simp only [y]
        split_ifs with hki hkj
        · linarith [hx0 i]
        · linarith
        · exact hx0 k
      have hy1 : ∀ k, y k ≤ 1 := by
        intro k
        simp only [y]
        split_ifs with hki hkj
        · linarith
        · linarith [hx1 j]
        · exact hx1 k
      have hy_sum : (∑ k, y k) = (∑ k, x k) := by
        have hpair_sub : ({i, j} : Finset (Fin n)) ⊆ Finset.univ := Finset.subset_univ _
        have hsum_x_split :
            (∑ k, x k) = (∑ k ∈ ({i, j} : Finset (Fin n)), x k) +
              (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), x k) := by
          have := Finset.sum_sdiff (f := x) hpair_sub
          linarith
        have hsum_y_split :
            (∑ k, y k) = (∑ k ∈ ({i, j} : Finset (Fin n)), y k) +
              (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k) := by
          have := Finset.sum_sdiff (f := y) hpair_sub
          linarith
        have hpair_x : (∑ k ∈ ({i, j} : Finset (Fin n)), x k) = x i + x j := by
          rw [Finset.sum_pair hi_ne_j]
        have hpair_y : (∑ k ∈ ({i, j} : Finset (Fin n)), y k) = y i + y j := by
          rw [Finset.sum_pair hi_ne_j]
        have houtside_eq : ∀ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k = x k := by
          intro k hk
          simp only [Finset.mem_sdiff, Finset.mem_univ, true_and,
                     Finset.mem_insert, Finset.mem_singleton, not_or] at hk
          exact hy_outside k hk.1 hk.2
        have hsum_outside_eq :
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), y k) =
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), x k) :=
          Finset.sum_congr rfl houtside_eq
        have hyi_yj : y i + y j = x i + x j := by
          rw [hyi_eq, hyj_eq]; ring
        rw [hsum_y_split, hsum_x_split, hpair_x, hpair_y, hyi_yj, hsum_outside_eq]
      have hy_sum_half : (∑ k, y k) = (n : ℝ) / 2 := by rw [hy_sum]; exact hx_sum
      have hxj_lt_xi : x j < x i := hxij_lt
      have hyj_lt_xj : y j < x j := by rw [hyj_eq]; linarith
      have hxi_lt_yi : x i < y i := by rw [hyi_eq]; linarith
      have hyj_lt_yi : y j < y i := by linarith
      have hyi_minus_yj_pos : 0 < y i - y j := by linarith
      have hyi_minus_yj_ne : y i - y j ≠ 0 := ne_of_gt hyi_minus_yj_pos
      set s : ℝ := (y i - x j) / (y i - y j) with hs_def
      have hs_pos : 0 < s := by
        rw [hs_def]; exact div_pos (by linarith) hyi_minus_yj_pos
      have hs_lt_one : s < 1 := by
        rw [hs_def, div_lt_one hyi_minus_yj_pos]
        linarith
      have ht_pos : 0 < (1 - s) := by linarith
      -- s = (y i - x j)/(y i - y j). y j < y i. We want
      --  x j = s * y j + (1 - s) * y i.
      have hxj_combo : x j = s * y j + (1 - s) * y i := by
        have key : s * y j + (1 - s) * y i = y i - s * (y i - y j) := by ring
        rw [key, hs_def, div_mul_cancel₀ _ hyi_minus_yj_ne]
        linarith
      -- x i = (1 - s) * y j + s * y i.
      have hxi_combo : x i = (1 - s) * y j + s * y i := by
        have key : (1 - s) * y j + s * y i = y j + s * (y i - y j) := by ring
        rw [key, hs_def, div_mul_cancel₀ _ hyi_minus_yj_ne]
        -- Need x i = y j + (y i - x j) = y i + y j - x j. Use sum: y i + y j = x i + x j.
        have hsum_yij : y i + y j = x i + x j := by rw [hyi_eq, hyj_eq]; ring
        linarith
      have hyj_ne_yi : y j ≠ y i := ne_of_lt hyj_lt_yi
      have hSCcv_pair := hSCcv_Icc.2
      -- Apply with arguments s, (1 - s) on (y j, y i)
      have h_concav : s • h_q q lambda delta (y j) + (1 - s) • h_q q lambda delta (y i) <
          h_q q lambda delta (s • y j + (1 - s) • y i) :=
        hSCcv_pair hyj_in hyi_in hyj_ne_yi hs_pos ht_pos (by linarith)
      have h_concav' : (1 - s) • h_q q lambda delta (y j) + s • h_q q lambda delta (y i) <
          h_q q lambda delta ((1 - s) • y j + s • y i) :=
        hSCcv_pair hyj_in hyi_in hyj_ne_yi ht_pos hs_pos (by linarith)
      simp only [smul_eq_mul] at h_concav h_concav'
      have h1 : s * h_q q lambda delta (y j) + (1 - s) * h_q q lambda delta (y i) <
          h_q q lambda delta (x j) := by
        rw [hxj_combo]; exact h_concav
      have h2 : (1 - s) * h_q q lambda delta (y j) + s * h_q q lambda delta (y i) <
          h_q q lambda delta (x i) := by
        rw [hxi_combo]; exact h_concav'
      have hsum_added := add_lt_add h1 h2
      have hcombine_lhs :
          (s * h_q q lambda delta (y j) + (1 - s) * h_q q lambda delta (y i))
            + ((1 - s) * h_q q lambda delta (y j) + s * h_q q lambda delta (y i))
          = h_q q lambda delta (y i) + h_q q lambda delta (y j) := by ring
      rw [hcombine_lhs] at hsum_added
      have hsum_y_lt_x : h_q q lambda delta (y i) + h_q q lambda delta (y j) <
          h_q q lambda delta (x i) + h_q q lambda delta (x j) := by linarith [hsum_added]
      have hpair_sub : ({i, j} : Finset (Fin n)) ⊆ Finset.univ := Finset.subset_univ _
      have hsum_hx_split :
          (∑ k, h_q q lambda delta (x k)) =
          (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) +
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) := by
        have := Finset.sum_sdiff (f := fun k => h_q q lambda delta (x k)) hpair_sub
        linarith
      have hsum_hy_split :
          (∑ k, h_q q lambda delta (y k)) =
          (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) +
            (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) := by
        have := Finset.sum_sdiff (f := fun k => h_q q lambda delta (y k)) hpair_sub
        linarith
      have hpair_hx : (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) =
          h_q q lambda delta (x i) + h_q q lambda delta (x j) := by
        rw [Finset.sum_pair hi_ne_j]
      have hpair_hy : (∑ k ∈ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) =
          h_q q lambda delta (y i) + h_q q lambda delta (y j) := by
        rw [Finset.sum_pair hi_ne_j]
      have houtside_h_eq :
          ∀ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)),
            h_q q lambda delta (y k) = h_q q lambda delta (x k) := by
        intro k hk
        simp only [Finset.mem_sdiff, Finset.mem_univ, true_and,
                   Finset.mem_insert, Finset.mem_singleton, not_or] at hk
        rw [hy_outside k hk.1 hk.2]
      have hsum_outside_h_eq :
          (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (y k)) =
          (∑ k ∈ Finset.univ \ ({i, j} : Finset (Fin n)), h_q q lambda delta (x k)) :=
        Finset.sum_congr rfl houtside_h_eq
      have hsum_lt : (∑ k, h_q q lambda delta (y k)) < (∑ k, h_q q lambda delta (x k)) := by
        rw [hsum_hy_split, hsum_hx_split, hpair_hy, hpair_hx, hsum_outside_h_eq]
        linarith
      have hmin := hx_min y hy0 hy1 hy_sum_half
      linarith
  -- Now use these two helpers to construct the partition.
  let I_one : Finset (Fin n) := Finset.univ.filter (fun i => x i = 1)
  let I_b : Finset (Fin n) := Finset.univ.filter (fun i => z < x i ∧ x i < 1)
  let I_a : Finset (Fin n) := Finset.univ.filter (fun i => x i ≤ z)
  have mem_I_one : ∀ i, i ∈ I_one ↔ x i = 1 := by intro i; simp [I_one]
  have mem_I_b : ∀ i, i ∈ I_b ↔ z < x i ∧ x i < 1 := by intro i; simp [I_b]
  have mem_I_a : ∀ i, i ∈ I_a ↔ x i ≤ z := by intro i; simp [I_a]
  have disj_ab : Disjoint I_a I_b := by
    rw [Finset.disjoint_filter]
    intro i _ hxi_le hxi_b
    linarith [hxi_b.1]
  have disj_ao : Disjoint I_a I_one := by
    rw [Finset.disjoint_filter]
    intro i _ hxi_le hxi_one
    linarith
  have disj_bo : Disjoint I_b I_one := by
    rw [Finset.disjoint_filter]
    intro i _ hxi_b hxi_one
    linarith [hxi_b.2]
  -- Coverage: every i is in I_a ∪ I_b ∪ I_one.
  have cover : I_a ∪ I_b ∪ I_one = Finset.univ := by
    apply Finset.eq_univ_of_forall
    intro i
    have h1 : x i ≤ 1 := hx1 i
    rw [Finset.mem_union, Finset.mem_union]
    rcases lt_or_ge z (x i) with hz_lt | hz_ge
    · -- z < x i. So x i ≤ z fails; check x i = 1 vs (z, 1).
      rcases lt_or_eq_of_le h1 with hlt | heq
      · left; right; rw [mem_I_b]; exact ⟨hz_lt, hlt⟩
      · right; rw [mem_I_one]; exact heq
    · left; left; rw [mem_I_a]; exact hz_ge
  have card_I_b_le_one : I_b.card ≤ 1 := by
    by_contra hcard
    push_neg at hcard
    rw [Nat.lt_iff_add_one_le, ← Nat.succ_eq_add_one] at hcard
    have : 1 < I_b.card := hcard
    rw [Finset.one_lt_card] at this
    obtain ⟨i, hi, j, hj, hij⟩ := this
    rw [mem_I_b] at hi hj
    apply noTwoInIozOne
    refine ⟨i, j, hij, hi.1, hi.2, le_of_lt hj.1, hj.2, hj.1⟩
  by_cases hIa_nonempty : I_a.Nonempty
  · obtain ⟨i_a_rep, hi_a_rep_in⟩ := hIa_nonempty
    set a := x i_a_rep with ha_def
    have ha_le_z : a ≤ z := (mem_I_a i_a_rep).mp hi_a_rep_in
    have ha_nonneg : 0 ≤ a := hx0 i_a_rep
    have all_Ia_eq_a : ∀ i ∈ I_a, x i = a := by
      intro i hi
      have hi_le : x i ≤ z := (mem_I_a i).mp hi
      have hrep_le : x i_a_rep ≤ z := (mem_I_a i_a_rep).mp hi_a_rep_in
      by_contra hne
      apply noTwoDistinctInIcc0z
      exact ⟨i, i_a_rep, hi_le, hrep_le, hne⟩
    by_cases hIb_nonempty : I_b.Nonempty
    · obtain ⟨i_b_rep, hi_b_rep_in⟩ := hIb_nonempty
      set b := x i_b_rep with hb_def
      have hb_props := (mem_I_b i_b_rep).mp hi_b_rep_in
      have hzb_le : z ≤ b := le_of_lt hb_props.1
      have hb_le_one : b ≤ 1 := le_of_lt hb_props.2
      refine ⟨a, b, I_a, I_b, I_one,
              ha_nonneg, ha_le_z, hzb_le, hb_le_one,
              disj_ab, disj_ao, disj_bo, cover,
              all_Ia_eq_a, ?_, ?_, card_I_b_le_one⟩
      · intro i hi
        have hcard_pos : 0 < I_b.card := Finset.card_pos.mpr ⟨i_b_rep, hi_b_rep_in⟩
        have hcard_eq_one : I_b.card = 1 := le_antisymm card_I_b_le_one hcard_pos
        rw [Finset.card_eq_one] at hcard_eq_one
        obtain ⟨c, hIb_eq_c⟩ := hcard_eq_one
        rw [hIb_eq_c, Finset.mem_singleton] at hi
        rw [hIb_eq_c, Finset.mem_singleton] at hi_b_rep_in
        rw [hi, ← hi_b_rep_in]
      · intro i hi
        exact (mem_I_one i).mp hi
    · -- I_b empty: pick b = z.
      refine ⟨a, z, I_a, ∅, I_one,
              ha_nonneg, ha_le_z, le_refl z, hz_le_one,
              ?_, disj_ao, ?_, ?_,
              all_Ia_eq_a, ?_, ?_, ?_⟩
      · exact Finset.disjoint_empty_right _
      · exact Finset.disjoint_empty_left _
      · rw [Finset.not_nonempty_iff_eq_empty] at hIb_nonempty
        rw [← cover, hIb_nonempty]
      · intro i hi
        exact absurd hi (Finset.notMem_empty i)
      · intro i hi
        exact (mem_I_one i).mp hi
      · simp
  · rw [Finset.not_nonempty_iff_eq_empty] at hIa_nonempty
    by_cases hIb_nonempty : I_b.Nonempty
    · obtain ⟨i_b_rep, hi_b_rep_in⟩ := hIb_nonempty
      set b := x i_b_rep with hb_def
      have hb_props := (mem_I_b i_b_rep).mp hi_b_rep_in
      have hzb_le : z ≤ b := le_of_lt hb_props.1
      have hb_le_one : b ≤ 1 := le_of_lt hb_props.2
      refine ⟨0, b, ∅, I_b, I_one,
              le_refl 0, hz_nonneg, hzb_le, hb_le_one,
              ?_, ?_, disj_bo, ?_, ?_, ?_, ?_, card_I_b_le_one⟩
      · exact Finset.disjoint_empty_left _
      · exact Finset.disjoint_empty_left _
      · rw [Finset.empty_union]
        rw [← cover, hIa_nonempty, Finset.empty_union]
      · intro i hi
        exact absurd hi (Finset.notMem_empty i)
      · intro i hi
        have hcard_pos : 0 < I_b.card := Finset.card_pos.mpr ⟨i_b_rep, hi_b_rep_in⟩
        have hcard_eq_one : I_b.card = 1 := le_antisymm card_I_b_le_one hcard_pos
        rw [Finset.card_eq_one] at hcard_eq_one
        obtain ⟨c, hIb_eq_c⟩ := hcard_eq_one
        rw [hIb_eq_c, Finset.mem_singleton] at hi
        rw [hIb_eq_c, Finset.mem_singleton] at hi_b_rep_in
        rw [hi, ← hi_b_rep_in]
      · intro i hi
        exact (mem_I_one i).mp hi
    · rw [Finset.not_nonempty_iff_eq_empty] at hIb_nonempty
      have hall_one : ∀ i, x i = 1 := by
        intro i
        have hi_in_cov : i ∈ I_a ∪ I_b ∪ I_one := cover ▸ Finset.mem_univ i
        rw [Finset.mem_union, Finset.mem_union] at hi_in_cov
        rcases hi_in_cov with (h | h) | h
        · exfalso; rw [hIa_nonempty] at h; exact Finset.notMem_empty i h
        · exfalso; rw [hIb_nonempty] at h; exact Finset.notMem_empty i h
        · exact (mem_I_one i).mp h
      exfalso
      have hsum_eq_n : (∑ i, x i) = (n : ℝ) := by
        calc (∑ i, x i) = ∑ _i : Fin n, (1 : ℝ) := by
                apply Finset.sum_congr rfl
                intros i _
                exact hall_one i
          _ = (n : ℝ) := by
                rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin]
                simp
      rw [hsum_eq_n] at hx_sum
      have hn_pos_real : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn_pos
      linarith
