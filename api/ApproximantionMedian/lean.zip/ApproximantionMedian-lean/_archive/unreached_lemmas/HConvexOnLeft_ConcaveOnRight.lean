import Mathlib
import Workspace.ProofLemmas.HSecondDerivative

open Workspace.ProofLemmas.HSecondDerivative

theorem HConvexOnLeft_ConcaveOnRight
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) :
    let z := delta ^ (-(q / (2*q - 1))) / (delta ^ (-(q / (2*q - 1))) + 1)
    (0 < z ∧ z ≤ 1/2) ∧
    (∀ x, 0 < x → x < z → iteratedDeriv 2 (fun y => h_q q lambda delta y) x > 0) ∧
    (∀ x, z < x → x < 1 → iteratedDeriv 2 (fun y => h_q q lambda delta y) x < 0) := by
  -- Setup: positivity, exponent definitions
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h2q1 : 0 < 2*q - 1 := by linarith
  have h2q1_ne : 2*q - 1 ≠ 0 := ne_of_gt h2q1
  have hdelta_pos : 0 < delta := lt_of_lt_of_le one_pos hdelta
  -- Set p := -(q / (2q - 1))
  set p : ℝ := -(q / (2*q - 1)) with hp_def
  -- D := delta ^ p, our anchor
  set D : ℝ := delta ^ p with hD_def
  have hD_pos : 0 < D := Real.rpow_pos_of_pos hdelta_pos p
  have hD_le_one : D ≤ 1 := by
    have hp_neg : p ≤ 0 := by
      rw [hp_def]
      have : 0 < q / (2*q - 1) := div_pos hq_pos h2q1
      linarith
    exact Real.rpow_le_one_of_one_le_of_nonpos hdelta hp_neg
  -- denom positive
  have hDenom_pos : 0 < D + 1 := by linarith
  have hDenom_ne : D + 1 ≠ 0 := ne_of_gt hDenom_pos
  -- z = D / (D + 1)
  intro z
  have hz_eq : z = D / (D + 1) := rfl
  -- Bounds on z
  have hz_pos : 0 < z := by
    rw [hz_eq]
    exact div_pos hD_pos hDenom_pos
  have hz_le_half : z ≤ 1/2 := by
    rw [hz_eq]
    rw [div_le_div_iff₀ hDenom_pos (by norm_num : (0:ℝ) < 2)]
    linarith
  have hz_lt_one : z < 1 := by
    have : (1:ℝ)/2 < 1 := by norm_num
    linarith
  -- 1 - z = 1 / (D + 1)
  have hone_minus_z : 1 - z = 1 / (D + 1) := by
    rw [hz_eq, eq_div_iff hDenom_ne]
    field_simp
    ring
  have hone_minus_z_pos : 0 < 1 - z := by linarith
  -- Set the exponent p2 := (1 - 2q) / q
  set p2 : ℝ := (1 - 2*q) / q with hp2_def
  have hp2_neg : p2 < 0 := by
    rw [hp2_def]
    apply div_neg_of_neg_of_pos _ hq_pos
    linarith
  -- p * p2 = 1
  have hp_mul_p2 : p * p2 = 1 := by
    rw [hp_def, hp2_def]
    field_simp
    rw [show -((1 - q * 2) / (q * 2 - 1)) = (q * 2 - 1) / (q * 2 - 1) from by ring]
    exact div_self (by linarith : (q*2 - 1 : ℝ) ≠ 0)
  -- Bracket vanishes at z: z^p2 = delta * (1 - z)^p2
  have hzpow : z ^ p2 = delta * (1 - z) ^ p2 := by
    have h1 : z ^ p2 = D ^ p2 / (D + 1) ^ p2 := by
      rw [hz_eq, Real.div_rpow (le_of_lt hD_pos) (le_of_lt hDenom_pos)]
    have h2 : (1 - z) ^ p2 = 1 / (D + 1) ^ p2 := by
      rw [hone_minus_z, Real.div_rpow (by norm_num) (le_of_lt hDenom_pos), Real.one_rpow]
    have h3 : D ^ p2 = delta := by
      rw [hD_def, ← Real.rpow_mul (le_of_lt hdelta_pos), hp_mul_p2, Real.rpow_one]
    rw [h1, h2, h3]
    have hDenom_pow_ne : (D + 1) ^ p2 ≠ 0 :=
      ne_of_gt (Real.rpow_pos_of_pos hDenom_pos p2)
    field_simp
  -- Strict anti monotonicity of x ↦ x^p2 on Ioi 0
  have hstrict_anti : StrictAntiOn (fun (x:ℝ) => x ^ p2) (Set.Ioi 0) :=
    Real.strictAntiOn_rpow_Ioi_of_exponent_neg hp2_neg
  refine ⟨⟨hz_pos, hz_le_half⟩, ?_, ?_⟩
  · -- For x with 0 < x < z: bracket > 0
    intro x hx0 hxz
    have hx_lt_one : x < 1 := by linarith
    have hone_minus_x_pos : 0 < 1 - x := by linarith
    have hone_minus_lt : 1 - z < 1 - x := by linarith
    -- Use second derivative formula
    have hsec :=
      HSecondDerivative q hq lambda hlam delta hdelta x hx0 hx_lt_one
    rw [hsec]
    have hcoef_pos : 0 < lambda * (q - 1) / q ^ 2 := by
      apply div_pos
      · exact mul_pos hlam (by linarith)
      · exact pow_pos hq_pos 2
    -- Bracket positive: x^p2 > delta * (1-x)^p2
    have hbracket_pos : 0 < x ^ p2 - delta * (1 - x) ^ p2 := by
      -- x < z, both > 0: by strict anti, z^p2 < x^p2
      have hx_pow : z ^ p2 < x ^ p2 :=
        hstrict_anti hx0 hz_pos hxz
      -- (1 - z) < (1 - x), both > 0: by strict anti, (1 - x)^p2 < (1 - z)^p2
      have h1x_pow : (1 - x) ^ p2 < (1 - z) ^ p2 :=
        hstrict_anti hone_minus_z_pos hone_minus_x_pos hone_minus_lt
      have hd1x_le : delta * (1 - x) ^ p2 < delta * (1 - z) ^ p2 :=
        mul_lt_mul_of_pos_left h1x_pow hdelta_pos
      have hzpow_sym : delta * (1 - z) ^ p2 = z ^ p2 := hzpow.symm
      linarith
    have hpos : 0 < (lambda * (q - 1) / q^2) * (x ^ p2 - delta * (1 - x) ^ p2) :=
      mul_pos hcoef_pos hbracket_pos
    show 0 < lambda * (q - 1) / q ^ 2 * (x ^ ((1 - 2*q) / q) - delta * (1 - x) ^ ((1 - 2*q) / q))
    exact hpos
  · -- For x with z < x < 1: bracket < 0
    intro x hxz hx1
    have hx_pos : 0 < x := by linarith
    have hone_minus_x_pos : 0 < 1 - x := by linarith
    have hone_minus_lt : 1 - x < 1 - z := by linarith
    have hsec :=
      HSecondDerivative q hq lambda hlam delta hdelta x hx_pos hx1
    rw [hsec]
    have hcoef_pos : 0 < lambda * (q - 1) / q ^ 2 := by
      apply div_pos
      · exact mul_pos hlam (by linarith)
      · exact pow_pos hq_pos 2
    have hbracket_neg : x ^ p2 - delta * (1 - x) ^ p2 < 0 := by
      -- z < x, both > 0: by strict anti, x^p2 < z^p2
      have hx_pow : x ^ p2 < z ^ p2 :=
        hstrict_anti hz_pos hx_pos hxz
      -- (1 - x) < (1 - z), both > 0: by strict anti, (1 - z)^p2 < (1 - x)^p2
      have h1x_pow : (1 - z) ^ p2 < (1 - x) ^ p2 :=
        hstrict_anti hone_minus_x_pos hone_minus_z_pos hone_minus_lt
      have hd1x_gt : delta * (1 - z) ^ p2 < delta * (1 - x) ^ p2 :=
        mul_lt_mul_of_pos_left h1x_pow hdelta_pos
      have hzpow_sym : delta * (1 - z) ^ p2 = z ^ p2 := hzpow.symm
      linarith
    have hneg : (lambda * (q - 1) / q^2) * (x ^ p2 - delta * (1 - x) ^ p2) < 0 :=
      mul_neg_of_pos_of_neg hcoef_pos hbracket_neg
    show lambda * (q - 1) / q ^ 2 * (x ^ ((1 - 2*q) / q) - delta * (1 - x) ^ ((1 - 2*q) / q)) < 0
    exact hneg
