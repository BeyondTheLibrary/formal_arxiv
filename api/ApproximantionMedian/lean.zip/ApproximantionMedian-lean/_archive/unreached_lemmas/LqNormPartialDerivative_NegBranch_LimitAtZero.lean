import Mathlib
import Workspace.Types.LqNorm

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormPartialDerivative_NegBranch_LimitAtZero
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x f : Fin d → ℝ) (j : Fin d)
    (hxj_zero : x j = 0) (hfj_pos : 0 < f j) (hf_nn : ∀ k, 0 ≤ f k)
    (hlq_pos : 0 < lqNorm q (fun k => x k - f k)) :
    HasDerivWithinAt
      (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k))
      (-(f j) ^ (q - 1) / (lqNorm q (fun k => x k - f k)) ^ (q - 1))
      (Set.Iic (0 : ℝ)) 0 := by
  -- Setup basic facts about q
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hfj_ne : f j ≠ 0 := ne_of_gt hfj_pos
  have hlq_ne : lqNorm q (fun k => x k - f k) ≠ 0 := ne_of_gt hlq_pos
  have hlq_nonneg : 0 ≤ lqNorm q (fun k => x k - f k) := le_of_lt hlq_pos
  -- Define the constant part C = ∑_{k≠j} |x k - f k|^q
  set C : ℝ := ∑ k ∈ Finset.univ.erase j, |x k - f k| ^ q with hC_def
  -- The total sum equals C + (f j)^q (using x j = 0 so |x j - f j| = |-f j| = f j)
  have h_total_sum : (∑ k, |x k - f k| ^ q) = C + (f j) ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h1 : (∑ k, |x k - f k| ^ q) =
        ∑ k ∈ Finset.univ.erase j, |x k - f k| ^ q + |x j - f j| ^ q := by
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
            (fun k => |x k - f k| ^ q) hj_mem]
    rw [h1]
    have h_xj_minus_fj : x j - f j = -(f j) := by rw [hxj_zero]; ring
    rw [h_xj_minus_fj, abs_neg, abs_of_pos hfj_pos]
  -- (lqNorm q (x - f))^q = total_sum
  have h_lqNorm_q_eq : (lqNorm q (fun k => x k - f k)) ^ q = ∑ k, |x k - f k| ^ q := by
    unfold lqNorm
    rw [← Real.rpow_mul (sum_abs_rpow_nonneg q (fun k => x k - f k)),
        one_div_mul_cancel hq_ne, Real.rpow_one]
  -- For t near 0: t < f j (since f j > 0). In this nbhd:
  --  Function.update x j t k - f k = t - f j when k = j else x k - f k
  --  |t - f j| = f j - t since t - f j < 0
  have h_t_lt_fj : ∀ᶠ t in nhds (0 : ℝ), t < f j :=
    eventually_lt_nhds hfj_pos
  have h_eq_local : ∀ᶠ t in nhds (0 : ℝ),
      lqNorm q (fun k => Function.update x j t k - f k) =
        (C + (f j - t) ^ q) ^ ((1 : ℝ) / q) := by
    filter_upwards [h_t_lt_fj] with t ht_lt
    have h_neg : t - f j < 0 := by linarith
    unfold lqNorm
    congr 1
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
          (fun k => |Function.update x j t k - f k| ^ q) hj_mem]
    rw [Function.update_self]
    have h_abs_eq : |t - f j| = f j - t := by
      rw [abs_of_neg h_neg]; ring
    rw [h_abs_eq]
    -- Rewrite the sum over erased: drop the update on k ≠ j
    have h_sum_eq :
        (∑ k ∈ Finset.univ.erase j, |Function.update x j t k - f k| ^ q) = C := by
      apply Finset.sum_congr rfl
      intro k hk
      have hkj : k ≠ j := Finset.ne_of_mem_erase hk
      rw [Function.update_of_ne hkj]
    rw [h_sum_eq]
  -- Compute derivative of t ↦ f j - t at t = 0
  have h_inner : HasDerivAt (fun t : ℝ => f j - t) (-1 : ℝ) (0 : ℝ) := by
    have h1 : HasDerivAt (fun t : ℝ => t) (1 : ℝ) (0 : ℝ) := hasDerivAt_id 0
    have h2 : HasDerivAt (fun t : ℝ => -t) (-1 : ℝ) (0 : ℝ) := by simpa using h1.neg
    have h3 := h2.const_add (f j)
    -- h3 : HasDerivAt (fun t => f j + -t) (-1) 0
    have hfun_eq : (fun t : ℝ => f j + -t) = (fun t : ℝ => f j - t) := by
      funext t; ring
    rw [hfun_eq] at h3
    exact h3
  -- Compute derivative of s ↦ s^q at s = f j (positive base)
  have h_s_pow_q : HasDerivAt (fun s : ℝ => s ^ q) (q * (f j) ^ (q - 1)) (f j) :=
    Real.hasDerivAt_rpow_const (Or.inl hfj_ne)
  -- Chain rule: derivative of t ↦ (f j - t)^q at t = 0
  have h_pow_q : HasDerivAt (fun t : ℝ => (f j - t) ^ q)
      (q * (f j) ^ (q - 1) * (-1)) (0 : ℝ) := by
    have h_fj_eq : f j = f j - (0 : ℝ) := by ring
    have h_s_pow_q' : HasDerivAt (fun s : ℝ => s ^ q) (q * (f j) ^ (q - 1)) (f j - (0 : ℝ)) := by
      rw [← h_fj_eq]; exact h_s_pow_q
    exact h_s_pow_q'.comp (0 : ℝ) h_inner
  -- Add constant C
  have h_C_add : HasDerivAt (fun t : ℝ => C + (f j - t) ^ q)
      (q * (f j) ^ (q - 1) * (-1)) (0 : ℝ) := by
    have := h_pow_q.const_add C
    convert this using 1
  -- (C + (f j)^q) = (lqNorm q (x - f))^q
  have h_inner_eq : C + (f j) ^ q = (lqNorm q (fun k => x k - f k)) ^ q := by
    rw [← h_total_sum, ← h_lqNorm_q_eq]
  have h_inner_pos : 0 < C + (f j) ^ q := by
    rw [h_inner_eq]
    exact Real.rpow_pos_of_pos hlq_pos q
  have h_inner_at0 : C + (f j - (0 : ℝ)) ^ q = C + (f j) ^ q := by ring_nf
  have h_inner_ne : C + (f j - (0 : ℝ)) ^ q ≠ 0 := by
    rw [h_inner_at0]; exact ne_of_gt h_inner_pos
  -- Use HasDerivAt.rpow_const for the outer composition
  have h_outer : HasDerivAt (fun t : ℝ => (C + (f j - t) ^ q) ^ ((1 : ℝ) / q))
      (q * (f j) ^ (q - 1) * (-1) * ((1 : ℝ) / q) *
        (C + (f j - (0 : ℝ)) ^ q) ^ ((1 : ℝ) / q - 1)) (0 : ℝ) :=
    h_C_add.rpow_const (Or.inl h_inner_ne)
  -- Transfer via eventuallyEq
  have h_eq_local' : (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k)) =ᶠ[nhds 0]
      (fun t : ℝ => (C + (f j - t) ^ q) ^ ((1 : ℝ) / q)) := by
    filter_upwards [h_eq_local] with t ht
    exact ht
  -- Convert h_outer to HasDerivAt of our target function
  have h_target_HasDerivAt : HasDerivAt
      (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k))
      (q * (f j) ^ (q - 1) * (-1) * ((1 : ℝ) / q) *
        (C + (f j - (0 : ℝ)) ^ q) ^ ((1 : ℝ) / q - 1)) (0 : ℝ) := by
    rw [Filter.EventuallyEq.hasDerivAt_iff h_eq_local']
    exact h_outer
  -- Now show that this derivative value equals -(f j)^(q-1) / (lqNorm q (x-f))^(q-1)
  have h_deriv_eq :
      q * (f j) ^ (q - 1) * (-1) * ((1 : ℝ) / q) *
        (C + (f j - (0 : ℝ)) ^ q) ^ ((1 : ℝ) / q - 1) =
      -(f j) ^ (q - 1) / (lqNorm q (fun k => x k - f k)) ^ (q - 1) := by
    rw [h_inner_at0, h_inner_eq]
    -- Step 1: simplify q * (f j)^(q-1) * (-1) * (1/q) = -(f j)^(q-1)
    have h_q_simp : q * (f j) ^ (q - 1) * (-1) * ((1 : ℝ) / q) = -(f j) ^ (q - 1) := by
      field_simp
    rw [h_q_simp]
    -- Step 2: ((lqNorm)^q)^(1/q - 1) = (lqNorm)^(1 - q)
    have h_pow_simp :
        ((lqNorm q (fun k => x k - f k)) ^ q) ^ ((1 : ℝ) / q - 1) =
          (lqNorm q (fun k => x k - f k)) ^ (1 - q) := by
      rw [← Real.rpow_mul hlq_nonneg]
      congr 1
      field_simp
    rw [h_pow_simp]
    -- Step 3: (lqNorm)^(1 - q) = ((lqNorm)^(q-1))⁻¹
    have h_neg : (lqNorm q (fun k => x k - f k)) ^ (1 - q) =
        ((lqNorm q (fun k => x k - f k)) ^ (q - 1))⁻¹ := by
      have : (1 - q) = -(q - 1) := by ring
      rw [this, Real.rpow_neg hlq_nonneg]
    rw [h_neg, div_eq_mul_inv]
  rw [h_deriv_eq] at h_target_HasDerivAt
  -- Convert HasDerivAt → HasDerivWithinAt
  exact h_target_HasDerivAt.hasDerivWithinAt
