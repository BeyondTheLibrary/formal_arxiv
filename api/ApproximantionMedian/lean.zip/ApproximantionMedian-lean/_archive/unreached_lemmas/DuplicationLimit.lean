import Mathlib
import Workspace.ProofLemmas.HSecondDerivative

open Workspace.ProofLemmas.HSecondDerivative

namespace Workspace.ProofLemmas.DuplicationLimit

noncomputable def V (q lambda delta : ℝ) (n : ℕ) : ℝ :=
  sInf { v : ℝ | ∃ x : Fin n → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, x i ≤ 1) ∧
                 (∑ i, x i) = (n : ℝ) / 2 ∧
                 v = ∑ i, h_q q lambda delta (x i) }

end Workspace.ProofLemmas.DuplicationLimit

open Workspace.ProofLemmas.DuplicationLimit in
theorem DuplicationLimit
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta)
    (n : ℕ) (hn_pos : 0 < n) (hn_even : Even n) :
    V q lambda delta (2 * n) / ((2 * n : ℕ) : ℝ) ≤
      V q lambda delta n / (n : ℝ) := by
  -- Notation for the two sets
  set S_n : Set ℝ := { v : ℝ | ∃ x : Fin n → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, x i ≤ 1) ∧
                 (∑ i, x i) = (n : ℝ) / 2 ∧ v = ∑ i, h_q q lambda delta (x i) } with hS_n_def
  set S_2n : Set ℝ := { v : ℝ | ∃ x : Fin (2*n) → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, x i ≤ 1) ∧
                 (∑ i, x i) = ((2*n : ℕ) : ℝ) / 2 ∧ v = ∑ i, h_q q lambda delta (x i) } with hS_2n_def
  have hVn_eq : V q lambda delta n = sInf S_n := rfl
  have hV2n_eq : V q lambda delta (2*n) = sInf S_2n := rfl
  -- Positive reals
  have hn_real_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn_pos
  have h2n_real_pos : (0 : ℝ) < ((2*n : ℕ) : ℝ) := by
    push_cast
    linarith
  have h2n_real_pos' : (0 : ℝ) < 2 * (n : ℝ) := by linarith
  -- Cast equality
  have h2n_cast : ((2*n : ℕ) : ℝ) = 2 * (n : ℝ) := by push_cast; ring
  -- Step 0: lower bound on h_q on [0,1]: h_q q lambda delta x ≥ -lambda
  have hq0 : 0 < q := lt_trans zero_lt_one hq
  have hq_inv_pos : 0 < (1 : ℝ) / q := by positivity
  have h_lower_pointwise : ∀ x : ℝ, 0 ≤ x → x ≤ 1 → -lambda ≤ h_q q lambda delta x := by
    intro x hx0 hx1
    -- h_q q lambda delta x = lambda * (delta * (1-x)^(1/q) - x^(1/q))
    -- ≥ lambda * (0 - 1) = -lambda
    have hx0' : (0 : ℝ) ≤ 1 - x := by linarith
    have h_pow_x : x ^ ((1 : ℝ) / q) ≤ 1 := by
      have := Real.rpow_le_one (x := x) hx0 hx1 (le_of_lt hq_inv_pos)
      exact this
    have h_pow_1mx : 0 ≤ (1 - x) ^ ((1 : ℝ) / q) :=
      Real.rpow_nonneg hx0' _
    have h_inner : -1 ≤ delta * (1 - x) ^ ((1 : ℝ) / q) - x ^ ((1 : ℝ) / q) := by
      have hd_nn : 0 ≤ delta * (1 - x) ^ ((1 : ℝ) / q) := by
        apply mul_nonneg
        · linarith
        · exact h_pow_1mx
      linarith
    show -lambda ≤ lambda * (delta * (1 - x) ^ ((1 : ℝ) / q) - x ^ ((1 : ℝ) / q))
    have : lambda * (-1) ≤ lambda * (delta * (1 - x) ^ ((1 : ℝ) / q) - x ^ ((1 : ℝ) / q)) :=
      mul_le_mul_of_nonneg_left h_inner (le_of_lt hlam)
    linarith
  -- Lower bounds on the sums
  have h_lower_bound_2n : ∀ v ∈ S_2n, -((2*n : ℕ) : ℝ) * lambda ≤ v := by
    intro v hv
    rcases hv with ⟨x, hx0, hx1, _hsum, hveq⟩
    rw [hveq]
    have hpt : ∀ i, -lambda ≤ h_q q lambda delta (x i) := fun i =>
      h_lower_pointwise (x i) (hx0 i) (hx1 i)
    have hsum_lb : ∑ i, -lambda ≤ ∑ i, h_q q lambda delta (x i) :=
      Finset.sum_le_sum (fun i _ => hpt i)
    have hconst : ∑ _i : Fin (2*n), (-lambda : ℝ) = -((2*n : ℕ) : ℝ) * lambda := by
      rw [Finset.sum_const]
      simp
    linarith [hconst, hsum_lb]
  have h_BddBelow_S2n : BddBelow S_2n := ⟨-((2*n : ℕ) : ℝ) * lambda, h_lower_bound_2n⟩
  -- Step 1: S_n is nonempty (use the constant 1/2 function)
  have h_Sn_nonempty : S_n.Nonempty := by
    refine ⟨∑ i : Fin n, h_q q lambda delta (1/2 : ℝ), ?_⟩
    refine ⟨fun _ => (1/2 : ℝ), ?_, ?_, ?_, ?_⟩
    · intro i; norm_num
    · intro i; norm_num
    · simp [Finset.sum_const, Finset.card_univ, Fintype.card_fin]
      ring
    · rfl
  -- Duplication construction:
  -- For x : Fin n → ℝ, define dup x : Fin (2*n) → ℝ by dup x i = x ⟨i.val % n, _⟩
  let dup : (Fin n → ℝ) → (Fin (2*n) → ℝ) :=
    fun x i => x ⟨i.val % n, Nat.mod_lt _ hn_pos⟩
  -- Equivalence: Fin (2*n) ≃ Fin 2 × Fin n via finProdFinEquiv (with arguments flipped)
  -- We have finProdFinEquiv : Fin m × Fin n ≃ Fin (m*n)
  -- So finProdFinEquiv : Fin 2 × Fin n ≃ Fin (2*n)
  let e : Fin 2 × Fin n ≃ Fin (2*n) := finProdFinEquiv
  -- Property: for p = (a, b), e p has value b + n * a
  have he_val : ∀ p : Fin 2 × Fin n, (e p).val = p.2.val + n * p.1.val := by
    intro p
    exact finProdFinEquiv_apply_val p
  -- For the duplication, dup x (e (a, b)) = x b
  have h_dup_e : ∀ x : Fin n → ℝ, ∀ p : Fin 2 × Fin n,
      dup x (e p) = x p.2 := by
    intro x p
    show x ⟨(e p).val % n, _⟩ = x p.2
    rw [he_val]
    -- (b + n * a) % n = b
    have hmod : (p.2.val + n * p.1.val) % n = p.2.val := by
      rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt p.2.isLt]
    congr 1
    exact Fin.ext hmod
  -- Sum over Fin (2*n) via the equivalence:
  have h_sum_via_e : ∀ (g : Fin (2*n) → ℝ),
      ∑ i, g i = ∑ p : Fin 2 × Fin n, g (e p) := by
    intro g
    rw [Equiv.sum_comp e g]
  -- Sum of dup x (e p) over Fin 2 × Fin n equals 2 * sum of x
  have h_dup_sum : ∀ x : Fin n → ℝ,
      (∑ i : Fin (2*n), dup x i) = 2 * (∑ i : Fin n, x i) := by
    intro x
    rw [h_sum_via_e (dup x)]
    -- ∑ p, dup x (e p) = ∑ p, x p.2 = ∑ a in Fin 2, ∑ b in Fin n, x b = 2 * ∑ b, x b
    have step1 : (∑ p : Fin 2 × Fin n, dup x (e p)) = ∑ p : Fin 2 × Fin n, x p.2 := by
      apply Finset.sum_congr rfl
      intro p _
      exact h_dup_e x p
    rw [step1]
    rw [Fintype.sum_prod_type]
    -- ∑ a : Fin 2, ∑ b : Fin n, x b = ∑ a, (∑ b, x b) = (∑ b, x b) * (Fintype.card (Fin 2))
    simp [Finset.sum_const, Finset.card_univ, Fintype.card_fin, two_mul]
  -- Sum of h_q (dup x i) over Fin (2*n) equals 2 * sum of h_q (x i)
  have h_dup_h_sum : ∀ x : Fin n → ℝ,
      (∑ i : Fin (2*n), h_q q lambda delta (dup x i)) =
        2 * (∑ i : Fin n, h_q q lambda delta (x i)) := by
    intro x
    rw [h_sum_via_e (fun i => h_q q lambda delta (dup x i))]
    have step1 : (∑ p : Fin 2 × Fin n, h_q q lambda delta (dup x (e p))) =
        ∑ p : Fin 2 × Fin n, h_q q lambda delta (x p.2) := by
      apply Finset.sum_congr rfl
      intro p _
      rw [h_dup_e x p]
    rw [step1]
    rw [Fintype.sum_prod_type]
    simp [Finset.sum_const, Finset.card_univ, Fintype.card_fin, two_mul]
  -- For any feasible x for n, dup x is feasible for 2*n and its cost is 2*cost(x).
  -- Hence 2 * cost(x) ∈ S_2n for every feasible x.
  have h_two_cost_mem : ∀ x : Fin n → ℝ,
      (∀ i, 0 ≤ x i) → (∀ i, x i ≤ 1) → (∑ i, x i) = (n : ℝ) / 2 →
        2 * (∑ i, h_q q lambda delta (x i)) ∈ S_2n := by
    intro x hx0 hx1 hsum
    refine ⟨dup x, ?_, ?_, ?_, ?_⟩
    · intro i
      show 0 ≤ x ⟨i.val % n, _⟩
      exact hx0 _
    · intro i
      show x ⟨i.val % n, _⟩ ≤ 1
      exact hx1 _
    · rw [h_dup_sum]
      rw [hsum]
      rw [h2n_cast]
      ring
    · rw [h_dup_h_sum]
  -- Step 2: sInf S_2n ≤ 2 * v for every v ∈ S_n
  have h_inf_le_two : ∀ v ∈ S_n, sInf S_2n ≤ 2 * v := by
    intro v hv
    rcases hv with ⟨x, hx0, hx1, hsum, hveq⟩
    have hmem : 2 * v ∈ S_2n := by
      rw [hveq]
      exact h_two_cost_mem x hx0 hx1 hsum
    exact csInf_le h_BddBelow_S2n hmem
  -- Equivalent: sInf S_2n / 2 ≤ v for every v ∈ S_n
  have h_inf_half_le : ∀ v ∈ S_n, sInf S_2n / 2 ≤ v := by
    intro v hv
    have h := h_inf_le_two v hv
    linarith
  -- Step 3: sInf S_2n / 2 ≤ sInf S_n  (using le_csInf)
  have h_main_ineq : sInf S_2n / 2 ≤ sInf S_n :=
    le_csInf h_Sn_nonempty h_inf_half_le
  -- Hence sInf S_2n ≤ 2 * sInf S_n
  have h_main : sInf S_2n ≤ 2 * sInf S_n := by linarith
  -- Step 4: divide by 2n
  -- Goal: V q lambda delta (2 * n) / ((2 * n : ℕ) : ℝ) ≤ V q lambda delta n / (n : ℝ)
  rw [hV2n_eq, hVn_eq, h2n_cast]
  -- Show: sInf S_2n / (2 * n) ≤ sInf S_n / n
  rw [div_le_div_iff₀ h2n_real_pos' hn_real_pos]
  -- Cross-multiply: sInf S_2n * n ≤ sInf S_n * (2 * n)
  have hn_real_nn : (0 : ℝ) ≤ (n : ℝ) := le_of_lt hn_real_pos
  have h_step : sInf S_2n * (n : ℝ) ≤ (2 * sInf S_n) * (n : ℝ) :=
    mul_le_mul_of_nonneg_right h_main hn_real_nn
  linarith
