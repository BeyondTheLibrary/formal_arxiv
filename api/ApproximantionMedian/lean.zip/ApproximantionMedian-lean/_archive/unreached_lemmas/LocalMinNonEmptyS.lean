import Mathlib
import Workspace.Types.LqNorm
import Workspace.ProofLemmas.ConstrainedMinExists
import Workspace.ProofLemmas.LambdaDeltaIdentity

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists
open Workspace.ProofLemmas.LambdaDeltaIdentity

theorem LocalMinNonEmptyS
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (S : Finset (Fin d)) (hS_ne : S.Nonempty)
    (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1)
    (p_star : Fin d → ℝ)
    (hΔS_pos : 0 < ∑ j ∈ S, (f j) ^ q)
    (hp_in : ∀ j ∈ S, p_star j = f j / (1 - c))
    (hp_out : ∀ j ∉ S, p_star j = 0)
    (hc_eq :
      c / (1 - c) =
        ((lambda ^ (q / (q - 1)) / (1 - lambda ^ (q / (q - 1)))) ^ ((1 : ℝ) / q)) *
        ((((1 : ℝ) - (∑ j ∈ S, (f j) ^ q)) / (∑ j ∈ S, (f j) ^ q)) ^ ((1 : ℝ) / q))) :
    g_lambda q lambda f p_star =
      (1 - lambda ^ (q / (q - 1))) ^ ((q - 1) / q) *
        ((1 : ℝ) - (∑ j ∈ S, (f j) ^ q)) ^ ((1 : ℝ) / q)
      - lambda * (∑ j ∈ S, (f j) ^ q) ^ ((1 : ℝ) / q) := by
  classical
  -- ===========================================================
  -- Positivity / ne-zero scaffolding
  -- ===========================================================
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_le : 1 ≤ q := le_of_lt hq
  have hq_sub_pos : 0 < q - 1 := by linarith
  have hq_sub_ne : q - 1 ≠ 0 := ne_of_gt hq_sub_pos
  have h_inv_q_pos : 0 < (1 : ℝ) / q := by positivity
  have h_inv_q_ne : (1 : ℝ) / q ≠ 0 := ne_of_gt h_inv_q_pos
  have hqm1_q_pos : 0 < (q - 1) / q := div_pos hq_sub_pos hq_pos
  have h1c_pos : 0 < 1 - c := by linarith
  have h1c_nn : 0 ≤ 1 - c := le_of_lt h1c_pos
  have h1c_ne : (1 - c) ≠ 0 := ne_of_gt h1c_pos
  set r : ℝ := q / (q - 1) with hr_def
  have hr_pos : 0 < r := div_pos hq_pos hq_sub_pos
  have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
  have hlamr_pos : 0 < lambda ^ r := Real.rpow_pos_of_pos hlam0 _
  have hlamr_nn : 0 ≤ lambda ^ r := le_of_lt hlamr_pos
  have hlamr_lt1 : lambda ^ r < 1 := by
    have : lambda ^ r < (1 : ℝ) ^ r :=
      Real.rpow_lt_rpow hlam_nn hlam1 hr_pos
    simpa using this
  have h_one_sub_lamr_pos : 0 < 1 - lambda ^ r := by linarith
  have h_one_sub_lamr_nn : 0 ≤ 1 - lambda ^ r := le_of_lt h_one_sub_lamr_pos
  have h_one_sub_lamr_ne : (1 - lambda ^ r) ≠ 0 := ne_of_gt h_one_sub_lamr_pos
  -- ===========================================================
  -- ΔS abbreviation
  -- ===========================================================
  set ΔS : ℝ := ∑ j ∈ S, (f j) ^ q with hΔS_def
  have hΔS_nn : 0 ≤ ΔS := by
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) _
  -- The hypothesis hΔS_pos directly gives ΔS > 0
  have hΔS_pos' : 0 < ΔS := hΔS_pos
  have hΔS_ne : ΔS ≠ 0 := ne_of_gt hΔS_pos'
  have hΔSc_eq : ∑ j ∈ Sᶜ, (f j) ^ q = 1 - ΔS := by
    have hsum_split := Finset.sum_add_sum_compl S (fun j => (f j) ^ q)
    rw [show ((∑ j ∈ S, (f j) ^ q) : ℝ) = ΔS from rfl] at hsum_split
    rw [hf_sum] at hsum_split
    linarith
  have h_one_sub_ΔS_nn : 0 ≤ 1 - ΔS := by
    have : ΔS ≤ 1 := by
      rw [← hf_sum]
      apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ S)
      intro j _ _
      exact Real.rpow_nonneg (hf_nn j) _
    linarith
  -- ===========================================================
  -- Main case: ΔS > 0 (the only case, thanks to hΔS_pos)
  -- ===========================================================
  -- Let α = c/(1-c).
  set α : ℝ := c / (1 - c) with hα_def
  have hα_nn : 0 ≤ α := div_nonneg hc0 h1c_nn
  have h1c_inv : (1 : ℝ) / (1 - c) = 1 + α := by
    rw [hα_def]; field_simp; ring
  -- Two factor pieces from the constraint.
  set X : ℝ := (lambda ^ r / (1 - lambda ^ r)) ^ ((1 : ℝ) / q) with hX_def
  set Y : ℝ := ((1 - ΔS) / ΔS) ^ ((1 : ℝ) / q) with hY_def
  have hX_nn : 0 ≤ X := Real.rpow_nonneg (by positivity) _
  have hY_nn : 0 ≤ Y := Real.rpow_nonneg (by positivity) _
  have hα_xy : α = X * Y := hc_eq
  -- ============================================================
  -- Step A: ∑ |p_star j - f j|^q = α^q * ΔS + (1 - ΔS)
  -- ============================================================
  have h_inner_diff : ∑ j, |p_star j - f j| ^ q = α ^ q * ΔS + (1 - ΔS) := by
    have hsplit := Finset.sum_add_sum_compl S (fun j => |p_star j - f j| ^ q)
    rw [← hsplit]
    have hS_sum : ∑ j ∈ S, |p_star j - f j| ^ q = α ^ q * ΔS := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro j hjS
      have hpj : p_star j = f j / (1 - c) := hp_in j hjS
      have hpsf : p_star j - f j = α * f j := by
        rw [hpj, hα_def]; field_simp; ring
      rw [hpsf, abs_mul, abs_of_nonneg hα_nn, abs_of_nonneg (hf_nn j),
          Real.mul_rpow hα_nn (hf_nn j)]
    have hSc_sum : ∑ j ∈ Sᶜ, |p_star j - f j| ^ q = 1 - ΔS := by
      rw [← hΔSc_eq]
      apply Finset.sum_congr rfl
      intro j hjSc
      rw [Finset.mem_compl] at hjSc
      rw [hp_out j hjSc]
      simp [abs_neg, abs_of_nonneg (hf_nn j)]
    rw [hS_sum, hSc_sum]
  -- ============================================================
  -- Step B: simplify α^q * ΔS + (1 - ΔS) = (1-ΔS)/(1-λ^r)
  -- ============================================================
  have hXq : X ^ q = lambda ^ r / (1 - lambda ^ r) := by
    rw [hX_def, ← Real.rpow_mul (by positivity) (1/q) q,
        one_div_mul_cancel hq_ne, Real.rpow_one]
  have hYq : Y ^ q = (1 - ΔS) / ΔS := by
    rw [hY_def, ← Real.rpow_mul (by positivity) (1/q) q,
        one_div_mul_cancel hq_ne, Real.rpow_one]
  have hαq : α ^ q = (lambda ^ r / (1 - lambda ^ r)) * ((1 - ΔS) / ΔS) := by
    rw [hα_xy, Real.mul_rpow hX_nn hY_nn, hXq, hYq]
  have hαq_ΔS : α ^ q * ΔS = (lambda ^ r / (1 - lambda ^ r)) * (1 - ΔS) := by
    rw [hαq]; field_simp
  have h_sum_simplify : α ^ q * ΔS + (1 - ΔS) = (1 - ΔS) / (1 - lambda ^ r) := by
    rw [hαq_ΔS]; field_simp; ring
  -- ============================================================
  -- Step C: lqNorm q (p_star - f) = (1-ΔS)^(1/q) / (1-λ^r)^(1/q)
  -- ============================================================
  have h_lqnorm_diff : lqNorm q (fun j => p_star j - f j) =
      (1 - ΔS) ^ ((1 : ℝ) / q) / (1 - lambda ^ r) ^ ((1 : ℝ) / q) := by
    unfold lqNorm
    rw [h_inner_diff, h_sum_simplify,
        Real.div_rpow h_one_sub_ΔS_nn h_one_sub_lamr_nn]
  -- ============================================================
  -- Step D: lqNorm q p_star = ΔS^(1/q) / (1 - c)
  -- ============================================================
  have h_inner_p : ∑ j, |p_star j| ^ q = ΔS / (1 - c) ^ q := by
    have hsplit := Finset.sum_add_sum_compl S (fun j => |p_star j| ^ q)
    rw [← hsplit]
    have hS_sum : ∑ j ∈ S, |p_star j| ^ q = ΔS / (1 - c) ^ q := by
      rw [hΔS_def, Finset.sum_div]
      apply Finset.sum_congr rfl
      intro j hjS
      rw [hp_in j hjS, abs_div, abs_of_nonneg (hf_nn j),
          abs_of_pos h1c_pos, Real.div_rpow (hf_nn j) h1c_nn]
    have hSc_sum : ∑ j ∈ Sᶜ, |p_star j| ^ q = 0 := by
      apply Finset.sum_eq_zero
      intro j hjSc
      rw [Finset.mem_compl] at hjSc
      rw [hp_out j hjSc]
      simp [Real.zero_rpow hq_ne]
    rw [hS_sum, hSc_sum, add_zero]
  have h_lqnorm_p : lqNorm q p_star = ΔS ^ ((1 : ℝ) / q) / (1 - c) := by
    unfold lqNorm
    rw [h_inner_p]
    have h1c_q_nn : 0 ≤ (1 - c) ^ q := Real.rpow_nonneg h1c_nn _
    rw [Real.div_rpow hΔS_nn h1c_q_nn]
    congr 1
    rw [← Real.rpow_mul h1c_nn q (1/q), mul_one_div, div_self hq_ne, Real.rpow_one]
  -- ============================================================
  -- Step E: assemble. Algebraic identities used.
  -- ============================================================
  have hΔS_pow_pos : 0 < ΔS ^ ((1 : ℝ) / q) := Real.rpow_pos_of_pos hΔS_pos' _
  have hΔS_pow_ne : ΔS ^ ((1 : ℝ) / q) ≠ 0 := ne_of_gt hΔS_pow_pos
  have h_one_sub_lamr_pow_pos : 0 < (1 - lambda ^ r) ^ ((1 : ℝ) / q) :=
    Real.rpow_pos_of_pos h_one_sub_lamr_pos _
  have h_one_sub_lamr_pow_ne : (1 - lambda ^ r) ^ ((1 : ℝ) / q) ≠ 0 :=
    ne_of_gt h_one_sub_lamr_pow_pos
  have hY_split : Y = (1 - ΔS) ^ ((1 : ℝ) / q) / ΔS ^ ((1 : ℝ) / q) := by
    rw [hY_def, Real.div_rpow h_one_sub_ΔS_nn hΔS_nn]
  have hX_split : X = (lambda ^ r) ^ ((1 : ℝ) / q) / (1 - lambda ^ r) ^ ((1 : ℝ) / q) := by
    rw [hX_def, Real.div_rpow hlamr_nn h_one_sub_lamr_nn]
  have hlamr_pow : (lambda ^ r) ^ ((1 : ℝ) / q) = lambda ^ (r / q) := by
    rw [← Real.rpow_mul hlam_nn]; congr 1; ring
  have h1_plus_rq : (1 : ℝ) + r / q = r := by
    rw [hr_def]; field_simp; ring
  have hlam_times_lamrq : lambda * lambda ^ (r / q) = lambda ^ r := by
    have h := Real.rpow_add hlam0 1 (r / q)
    rw [Real.rpow_one] at h
    rw [← h, h1_plus_rq]
  -- Plug in everything.
  unfold g_lambda
  rw [h_lqnorm_diff, h_lqnorm_p]
  -- Rewrite the (1-c) factor using α.
  have h_div_form : ΔS ^ ((1 : ℝ) / q) / (1 - c) = (1 + α) * ΔS ^ ((1 : ℝ) / q) := by
    have h_inv_form : ΔS ^ ((1 : ℝ) / q) / (1 - c) =
        (1 / (1 - c)) * ΔS ^ ((1 : ℝ) / q) := by field_simp
    rw [h_inv_form, h1c_inv]
  rw [h_div_form]
  -- Distribute λ * (1 + α) * D.
  have h_step1 : lambda * ((1 + α) * ΔS ^ ((1 : ℝ) / q))
      = lambda * ΔS ^ ((1 : ℝ) / q) + lambda * (α * ΔS ^ ((1 : ℝ) / q)) := by ring
  rw [h_step1]
  -- α * D = λ^(r/q) * (1-ΔS)^(1/q) / (1-λ^r)^(1/q).
  have h_α_ΔS_pow : α * ΔS ^ ((1 : ℝ) / q) =
      lambda ^ (r / q) * (1 - ΔS) ^ ((1 : ℝ) / q) / (1 - lambda ^ r) ^ ((1 : ℝ) / q) := by
    rw [hα_xy, hY_split, hX_split, hlamr_pow]; field_simp
  have h_lam_alpha_ΔS_pow : lambda * (α * ΔS ^ ((1 : ℝ) / q)) =
      lambda ^ r * (1 - ΔS) ^ ((1 : ℝ) / q) / (1 - lambda ^ r) ^ ((1 : ℝ) / q) := by
    rw [h_α_ΔS_pow]
    have : lambda * (lambda ^ (r/q) * (1-ΔS)^((1:ℝ)/q) / (1-lambda^r)^((1:ℝ)/q))
          = (lambda * lambda ^ (r/q)) * (1-ΔS)^((1:ℝ)/q) / (1-lambda^r)^((1:ℝ)/q) := by ring
    rw [this, hlam_times_lamrq]
  rw [h_lam_alpha_ΔS_pow]
  -- Final identity: (1-λ^r)^((q-1)/q) = (1-λ^r)/(1-λ^r)^(1/q).
  have h_B_factor : ((1 - lambda ^ r) ^ ((q - 1) / q)) =
      (1 - lambda ^ r) / (1 - lambda ^ r) ^ ((1 : ℝ) / q) := by
    have hqm1q : (q - 1) / q = 1 - 1 / q := by field_simp
    rw [hqm1q, Real.rpow_sub h_one_sub_lamr_pos, Real.rpow_one]
  rw [h_B_factor]
  field_simp
  ring
