import Mathlib

theorem Eq8aFrom_uStarZero
    (q : ℝ) (hq : 1 < q) (a : ℝ) (ha0 : 0 < a) (ha1 : a < 1) (delta : ℝ) :
    delta * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a = 0
      ↔ delta * (1 - a) ^ ((1 : ℝ) / q) = a ^ ((1 : ℝ) / q) + 1 - 2 * a := by
  constructor <;> intro h <;> linarith
