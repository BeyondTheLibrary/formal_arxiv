import Mathlib
import Workspace.ProofLemmas.HSecondDerivative

open Workspace.ProofLemmas.HSecondDerivative

theorem OneParamReduction
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta)
    {n : ℕ} (hn_pos : 0 < n) (hn_even : Even n)
    (a : ℝ) (ha0 : 0 ≤ a) (ha_le_half : a ≤ 1/2)
    (x : Fin n → ℝ)
    (hx_in : ∀ i, x i = a ∨ x i = 1)
    (hx_sum : (∑ i, x i) = (n : ℝ) / 2) :
    (∑ i, h_q q lambda delta (x i)) / (n : ℝ) =
      lambda *
      (delta * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a)
      / (2 * (1 - a)) := by
  -- Basic positivity
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_invq_pos : (0 : ℝ) < 1 / q := by positivity
  have h_invq_ne : (1 : ℝ) / q ≠ 0 := ne_of_gt h_invq_pos
  -- a < 1, so 1 - a > 0
  have ha_lt_one : a < 1 := lt_of_le_of_lt ha_le_half (by norm_num)
  have h1ma_pos : (0 : ℝ) < 1 - a := by linarith
  have h1ma_ne : (1 : ℝ) - a ≠ 0 := ne_of_gt h1ma_pos
  have h2_1ma_ne : (2 : ℝ) * (1 - a) ≠ 0 := by positivity
  -- n > 0 as a real
  have hn_pos_real : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn_pos
  have hn_ne : (n : ℝ) ≠ 0 := ne_of_gt hn_pos_real
  -- Define filter set
  classical
  set S : Finset (Fin n) := (Finset.univ.filter (fun i => x i = a)) with hS_def
  have hS_compl : ∀ i ∈ Finset.univ \ S, x i = 1 := by
    intro i hi
    rw [Finset.mem_sdiff] at hi
    obtain ⟨_, hiS⟩ := hi
    rcases hx_in i with hia | hi1
    · exfalso; apply hiS
      simp [S, hia]
    · exact hi1
  have hS_mem : ∀ i ∈ S, x i = a := by
    intro i hi
    simp [S] at hi
    exact hi
  -- Sum decomposition
  have h_sum_split :
      (∑ i, x i) = (S.card : ℝ) * a + ((n : ℝ) - S.card) * 1 := by
    have hsplit :
        (∑ i, x i) = (∑ i ∈ S, x i) + (∑ i ∈ Finset.univ \ S, x i) := by
      rw [← Finset.sum_union (Finset.disjoint_sdiff)]
      congr 1
      exact (Finset.union_sdiff_of_subset (Finset.subset_univ S)).symm
    rw [hsplit]
    have hsumS : (∑ i ∈ S, x i) = (S.card : ℝ) * a := by
      have : (∑ i ∈ S, x i) = (∑ i ∈ S, a) := by
        apply Finset.sum_congr rfl
        intro i hi
        exact hS_mem i hi
      rw [this]
      simp [Finset.sum_const, mul_comm]
    have hsumC : (∑ i ∈ Finset.univ \ S, x i) =
        ((Finset.univ \ S).card : ℝ) * 1 := by
      have : (∑ i ∈ Finset.univ \ S, x i) = (∑ i ∈ Finset.univ \ S, (1 : ℝ)) := by
        apply Finset.sum_congr rfl
        intro i hi
        exact hS_compl i hi
      rw [this]
      simp [Finset.sum_const]
    rw [hsumS, hsumC]
    have hcard_diff : ((Finset.univ \ S).card : ℝ) = (n : ℝ) - S.card := by
      have hSle_n : S.card ≤ n := by
        have := Finset.card_le_card (Finset.subset_univ S)
        simpa [Finset.card_univ, Fintype.card_fin] using this
      have h1 : (Finset.univ \ S).card = n - S.card := by
        rw [Finset.card_sdiff_of_subset (Finset.subset_univ S)]
        simp [Finset.card_univ, Fintype.card_fin]
      rw [h1]
      exact_mod_cast Nat.cast_sub hSle_n (R := ℝ)
    rw [hcard_diff]
  -- Solve for S.card
  -- (S.card : ℝ) * a + (n - S.card) = n/2
  -- S.card * a + n - S.card = n/2
  -- S.card * (a - 1) = n/2 - n = -n/2
  -- S.card * (1 - a) = n/2
  -- S.card = n / (2 * (1 - a))
  have hcard_eq : (S.card : ℝ) = (n : ℝ) / (2 * (1 - a)) := by
    have heq : (S.card : ℝ) * a + ((n : ℝ) - S.card) * 1 = (n : ℝ) / 2 := by
      rw [← h_sum_split]; exact hx_sum
    have hmid : (S.card : ℝ) * (1 - a) = (n : ℝ) / 2 := by linarith
    have hcard : (S.card : ℝ) = (n : ℝ) / 2 / (1 - a) := by
      field_simp at hmid ⊢
      linarith
    rw [hcard]
    field_simp
  -- Now compute ∑ h_q(x i)
  have h_sum_h_split :
      (∑ i, h_q q lambda delta (x i)) =
        (S.card : ℝ) * h_q q lambda delta a +
          ((n : ℝ) - S.card) * h_q q lambda delta 1 := by
    have hsplit :
        (∑ i, h_q q lambda delta (x i)) =
          (∑ i ∈ S, h_q q lambda delta (x i)) +
            (∑ i ∈ Finset.univ \ S, h_q q lambda delta (x i)) := by
      rw [← Finset.sum_union (Finset.disjoint_sdiff)]
      congr 1
      exact (Finset.union_sdiff_of_subset (Finset.subset_univ S)).symm
    rw [hsplit]
    have hsumS : (∑ i ∈ S, h_q q lambda delta (x i)) =
        (S.card : ℝ) * h_q q lambda delta a := by
      have : (∑ i ∈ S, h_q q lambda delta (x i)) =
          (∑ i ∈ S, h_q q lambda delta a) := by
        apply Finset.sum_congr rfl
        intro i hi
        rw [hS_mem i hi]
      rw [this]
      simp [Finset.sum_const, mul_comm]
    have hsumC : (∑ i ∈ Finset.univ \ S, h_q q lambda delta (x i)) =
        ((Finset.univ \ S).card : ℝ) * h_q q lambda delta 1 := by
      have : (∑ i ∈ Finset.univ \ S, h_q q lambda delta (x i)) =
          (∑ i ∈ Finset.univ \ S, h_q q lambda delta 1) := by
        apply Finset.sum_congr rfl
        intro i hi
        rw [hS_compl i hi]
      rw [this]
      simp [Finset.sum_const, mul_comm]
    rw [hsumS, hsumC]
    have hcard_diff : ((Finset.univ \ S).card : ℝ) = (n : ℝ) - S.card := by
      have hSle_n : S.card ≤ n := by
        have := Finset.card_le_card (Finset.subset_univ S)
        simpa [Finset.card_univ, Fintype.card_fin] using this
      have h1 : (Finset.univ \ S).card = n - S.card := by
        rw [Finset.card_sdiff_of_subset (Finset.subset_univ S)]
        simp [Finset.card_univ, Fintype.card_fin]
      rw [h1]
      exact_mod_cast Nat.cast_sub hSle_n (R := ℝ)
    rw [hcard_diff]
  -- Compute h_q(1) = -lambda
  have h_q_1 : h_q q lambda delta 1 = -lambda := by
    unfold h_q
    have h1 : (1 - (1 : ℝ)) = 0 := by ring
    rw [h1]
    rw [Real.zero_rpow h_invq_ne]
    rw [Real.one_rpow]
    ring
  -- Now plug everything in and compute
  rw [h_sum_h_split, h_q_1, hcard_eq]
  -- Goal: (n/(2(1-a)) * h_q q lambda delta a + (n - n/(2(1-a))) * (-lambda)) / n
  --       = lambda * (delta*(1-a)^(1/q) - a^(1/q) - 1 + 2a) / (2(1-a))
  unfold h_q
  -- Now both sides are rational in lambda, delta, a, (1-a)^(1/q), a^(1/q), n
  field_simp
  ring
