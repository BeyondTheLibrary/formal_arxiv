import Mathlib

open Real

theorem Eq10From8aAnd8b
    (q : ℝ) (hq : 1 < q) (a : ℝ) (ha0 : 0 < a) (ha1 : a < 1) (delta : ℝ)
    (h8a : delta * (1 - a) ^ ((1 : ℝ) / q) = a ^ ((1 : ℝ) / q) + 1 - 2 * a)
    (h8b : delta * (1 - a) ^ ((1 - q) / q) + a ^ ((1 - q) / q) = 2 * q) :
    2 * (1 - 1 / q) * a + (1 / q) * a ^ ((1 - q) / q) - 2 + 1 / q = 0 := by
  have h1a_pos : (0 : ℝ) < 1 - a := by linarith
  have ha_pos : (0 : ℝ) < a := ha0
  have hq_pos : (0 : ℝ) < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  -- Key rpow identity for `1 - a`: `(1-a)^((1-q)/q) * (1-a) = (1-a)^(1/q)`.
  have hsum : ((1 - q) / q) + 1 = (1 : ℝ) / q := by
    field_simp
    ring
  have h1a_rpow : (1 - a) ^ ((1 - q) / q) * (1 - a) = (1 - a) ^ ((1 : ℝ) / q) := by
    have hadd := Real.rpow_add h1a_pos ((1 - q) / q) 1
    rw [Real.rpow_one] at hadd
    rw [← hadd, hsum]
  have ha_rpow : a ^ ((1 - q) / q) * a = a ^ ((1 : ℝ) / q) := by
    have hadd := Real.rpow_add ha_pos ((1 - q) / q) 1
    rw [Real.rpow_one] at hadd
    rw [← hadd, hsum]
  -- Multiply (8b) by `(1 - a)`.
  have step1 :
      delta * ((1 - a) ^ ((1 - q) / q) * (1 - a))
        + a ^ ((1 - q) / q) * (1 - a) = 2 * q * (1 - a) := by
    have hmul := congrArg (fun x => x * (1 - a)) h8b
    simp only at hmul
    nlinarith [hmul]
  -- Substitute identities and expand.
  have step2 :
      delta * (1 - a) ^ ((1 : ℝ) / q)
        + (a ^ ((1 - q) / q) - a ^ ((1 : ℝ) / q)) = 2 * q * (1 - a) := by
    have heq : a ^ ((1 - q) / q) * (1 - a)
        = a ^ ((1 - q) / q) - a ^ ((1 : ℝ) / q) := by
      have hr : a ^ ((1 - q) / q) * (1 - a)
          = a ^ ((1 - q) / q) - a ^ ((1 - q) / q) * a := by ring
      rw [hr, ha_rpow]
    rw [h1a_rpow, heq] at step1
    exact step1
  -- Substitute (8a).
  rw [h8a] at step2
  -- step2 : (a^(1/q) + 1 - 2*a) + (a^((1-q)/q) - a^(1/q)) = 2*q*(1 - a)
  have step3 : 1 - 2 * a + a ^ ((1 - q) / q) = 2 * q - 2 * q * a := by
    nlinarith [step2]
  -- Multiply the goal by q to get a linear combination of step3.
  -- Goal after × q : 2*(q - 1)*a + a^((1-q)/q) - 2*q + 1 = 0,
  -- i.e. a^((1-q)/q) + 2*a*(q - 1) + 1 - 2*q = 0,
  -- i.e. a^((1-q)/q) - 2*a + 2*q*a + 1 - 2*q = 0,
  -- which is step3 rearranged.
  have hqq : q * (1 / q) = 1 := by
    field_simp
  have hgoal_q :
      q * (2 * (1 - 1 / q) * a + (1 / q) * a ^ ((1 - q) / q) - 2 + 1 / q) = 0 := by
    have h_expand :
        q * (2 * (1 - 1 / q) * a + (1 / q) * a ^ ((1 - q) / q) - 2 + 1 / q)
          = 2 * q * a - 2 * (q * (1 / q)) * a
              + (q * (1 / q)) * a ^ ((1 - q) / q) - 2 * q + q * (1 / q) := by
      ring
    rw [h_expand, hqq]
    -- Now: 2*q*a - 2*1*a + 1*a^((1-q)/q) - 2*q + 1 = 0
    linarith [step3]
  -- Divide by q.
  have : 2 * (1 - 1 / q) * a + (1 / q) * a ^ ((1 - q) / q) - 2 + 1 / q = 0 := by
    have hcancel := mul_left_cancel₀ hq_ne
      (show q * (2 * (1 - 1 / q) * a + (1 / q) * a ^ ((1 - q) / q) - 2 + 1 / q)
          = q * 0 by
        rw [mul_zero]; exact hgoal_q)
    exact hcancel
  exact this
