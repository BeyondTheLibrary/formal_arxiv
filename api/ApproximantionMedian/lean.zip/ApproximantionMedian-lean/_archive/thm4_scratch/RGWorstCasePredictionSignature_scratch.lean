import Mathlib
import Workspace.Types.LqNorm
import Workspace.ProofLemmas.ConstrainedMinExists

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

-- L2 norm monotonicity under coordinatewise abs domination
example {d : ℕ} (x y : Fin d → ℝ) (h : ∀ j, |x j| ≤ |y j|) :
    lqNorm 2 x ≤ lqNorm 2 y := by
  unfold lqNorm
  apply Real.rpow_le_rpow (sum_abs_rpow_nonneg 2 x)
  · apply Finset.sum_le_sum
    intro j _
    apply Real.rpow_le_rpow (abs_nonneg _) (h j) (by norm_num)
  · norm_num

-- equality of norm under coordinatewise abs equality
example {d : ℕ} (x y : Fin d → ℝ) (h : ∀ j, |x j| = |y j|) :
    lqNorm 2 x = lqNorm 2 y := by
  unfold lqNorm
  congr 1
  apply Finset.sum_congr rfl
  intro j _
  rw [h j]

-- counting: ∑ ±1 = card(=1) - card(=-1)
example {n : ℕ} (sg : Fin n → ℝ) (hpm : ∀ i, sg i = 1 ∨ sg i = -1) :
    ∑ i, sg i =
      ((Finset.univ.filter (fun i => sg i = 1)).card : ℝ)
      - ((Finset.univ.filter (fun i => sg i = -1)).card : ℝ) := by
  classical
  rw [← Finset.sum_filter_add_sum_filter_not Finset.univ (fun i => sg i = 1)]
  have h1 : ∑ i ∈ Finset.univ.filter (fun i => sg i = 1), sg i
      = ((Finset.univ.filter (fun i => sg i = 1)).card : ℝ) := by
    rw [Finset.sum_congr rfl (fun i hi => (Finset.mem_filter.mp hi).2)]
    simp
  have h2 : ∑ i ∈ Finset.univ.filter (fun i => ¬ sg i = 1), sg i
      = - ((Finset.univ.filter (fun i => sg i = -1)).card : ℝ) := by
    have heq : (Finset.univ.filter (fun i => ¬ sg i = 1))
        = (Finset.univ.filter (fun i => sg i = -1)) := by
      apply Finset.filter_congr
      intro i _
      constructor
      · intro hne
        rcases hpm i with h | h
        · exact absurd h hne
        · exact h
      · intro h hcontra; rw [h] at hcontra; norm_num at hcontra
    rw [heq]
    rw [Finset.sum_congr rfl (fun i hi => (Finset.mem_filter.mp hi).2)]
    simp
  rw [h1, h2]; ring
