import Mathlib
import Workspace.ProofLemmas.HSecondDerivative
import Workspace.ProofLemmas.ThreeValueStructure
import Workspace.ProofLemmas.BPointKilledInLimitProof

open Workspace.ProofLemmas.HSecondDerivative

namespace Workspace.ProofLemmas.BPointKilledInLimit

noncomputable def V (q lambda delta : ℝ) (n : ℕ) : ℝ :=
  sInf { v : ℝ | ∃ x : Fin n → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, x i ≤ 1) ∧
                 (∑ i, x i) = (n : ℝ) / 2 ∧
                 v = ∑ i, h_q q lambda delta (x i) }

end Workspace.ProofLemmas.BPointKilledInLimit

/-- The b-point's contribution to the per-capita relaxed minimum vanishes in
the limit, leaving the b-free one-parameter optimum.

The per-capita relaxed infimum `V(2(n+1))/(2(n+1))` converges to the
one-parameter optimum value `λ·u(a_lim)/(2(1−a_lim))`, where
`u(a) = δ(1−a)^{1/q} − a^{1/q} − 1 + 2a` and `a_lim ∈ [0, z]`. This is the
per-capita optimum of the `(a,1)` two-value mix from the paper's
one-parameter reduction (OneParamReduction.lean), NOT `h_q q λ δ a_lim`.

Cited from: Gravin & Jia, *Approximation guarantees of Median Mechanism in ℝ^d*,
arXiv:2502.08578v2, §"Upper Bounds on Approximation Ratios" / §2.7.4.
The full-sequence convergence is the paper's n→∞ duplication argument that
the per-capita relaxed minimum tends to the single-parameter infimum on
`[0, z]`. It is reduced (see `BPointKilledInLimitProof.lean`) to: Step 1
(`pc` attains its min on the compact `[0,z]` — FULLY PROVEN), an upper bound
(`limsup ≤ pc(a_lim)`), a lower bound (`pc(a_lim) ≤ liminf`), and the
squeeze (FULLY PROVEN). The two bound lemmas and per-capita boundedness
remain isolated, documented `sorry`s in `BPointKilledInLimitProof.lean`. -/
theorem BPointKilledInLimit
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) :
    let z := delta ^ (-(q / (2*q - 1))) / (delta ^ (-(q / (2*q - 1))) + 1)
    ∃ a_lim : ℝ, 0 ≤ a_lim ∧ a_lim ≤ z ∧
      Filter.Tendsto (fun n : ℕ => Workspace.ProofLemmas.BPointKilledInLimit.V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ))
        Filter.atTop (nhds (lambda * (delta * (1 - a_lim) ^ ((1 : ℝ) / q) - a_lim ^ ((1 : ℝ) / q) - 1 + 2 * a_lim) / (2 * (1 - a_lim)))) := by
  exact Workspace.ProofLemmas.BPointKilledInLimitProof.BPointKilledInLimit_pc
    q hq lambda hlam delta hdelta
