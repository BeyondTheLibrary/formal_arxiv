import Mathlib
import Workspace.ProofLemmas.DeltaStarDef
import Workspace.ProofLemmas.LambdaStarDef
import Workspace.ProofLemmas.LambdaDeltaIdentity
import Workspace.ProofLemmas.UStarMinAttained
import Workspace.ProofLemmas.ZeqInHalfRange
import Workspace.ProofLemmas.DuplicationLimit
import Workspace.ProofLemmas.BPointKilledInLimit
import Workspace.ProofLemmas.HSecondDerivative

open Workspace.ProofLemmas.DeltaStarDef
open Workspace.ProofLemmas.LambdaStarDef
open Workspace.ProofLemmas.LambdaDeltaIdentity
open Workspace.ProofLemmas.ZeqInHalfRange
open Workspace.ProofLemmas.HSecondDerivative

set_option maxHeartbeats 4000000

namespace Workspace.ProofLemmas.RelaxedCoreAssembly

/-! ## Step 1: Bridge identity `delta_of_lambda q (lambda_star q) = delta_star q`. -/

/-- For `q > 1`, plugging `λ = λ*(q)` into `δ(λ)` recovers `δ*(q)`.
This is pure rpow algebra from the definitions of `lambda_star`, `delta_of_lambda`,
using `δ*(q) ≥ 1 ≥ 0`. -/
theorem deltaOfLambda_lambdaStar_eq (q : ℝ) (hq : 1 < q) :
    delta_of_lambda q (lambda_star q) = delta_star q := by
  have hq1 : q ≠ 1 := ne_of_gt hq
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hqm1_pos : 0 < q - 1 := by linarith
  have hqm1_ne : q - 1 ≠ 0 := ne_of_gt hqm1_pos
  -- δ*(q) ≥ 1 > 0
  have hDS_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
  have hDS_pos : 0 < delta_star q := lt_of_lt_of_le one_pos hDS_ge_one
  have hDS_nn : 0 ≤ delta_star q := le_of_lt hDS_pos
  -- exponents
  set r : ℝ := q / (q - 1) with hr_def
  have hr_pos : 0 < r := div_pos hq_pos hqm1_pos
  set e : ℝ := (q - 1) / q with he_def
  have he_pos : 0 < e := div_pos hqm1_pos hq_pos
  -- (delta_star q)^r ≥ 0
  have hDSr_pos : 0 < (delta_star q) ^ r := Real.rpow_pos_of_pos hDS_pos r
  have hDSr_nn : 0 ≤ (delta_star q) ^ r := le_of_lt hDSr_pos
  -- B = 1 + (delta_star q)^r > 0
  set B : ℝ := 1 + (delta_star q) ^ r with hB_def
  have hB_pos : 0 < B := by rw [hB_def]; linarith
  have hB_nn : 0 ≤ B := le_of_lt hB_pos
  -- lambda_star q = B ^ (-e)
  have hlam_unfold : lambda_star q = B ^ (-e) := by
    unfold lambda_star
    rw [if_neg hq1, if_pos hq]
  -- (B^(-e))^(-r) = B^((-e)*(-r)) = B^(e*r) = B^1 = B
  have her : e * r = 1 := by
    rw [he_def, hr_def]; field_simp
  have h_pow_pow : (B ^ (-e)) ^ (-r) = B := by
    rw [← Real.rpow_mul hB_nn]
    have : (-e) * (-r) = 1 := by rw [neg_mul_neg, her]
    rw [this, Real.rpow_one]
  -- delta_of_lambda q (lambda_star q) = ((lambda_star q)^(-r) - 1)^e
  unfold delta_of_lambda
  rw [hlam_unfold]
  -- now goal: ((B^(-e))^(-(q/(q-1))) - 1)^((q-1)/q) = delta_star q
  rw [← hr_def, ← he_def, h_pow_pow]
  -- goal: (B - 1)^e = delta_star q, B - 1 = (delta_star q)^r
  have hB_sub : B - 1 = (delta_star q) ^ r := by rw [hB_def]; ring
  rw [hB_sub, ← Real.rpow_mul hDS_nn, mul_comm r e, her, Real.rpow_one]

/-! ## Step 3: Non-negativity of the per-capita one-parameter value on `[0, z]`. -/

/-- For `a ∈ [0, z_func q]`, the per-capita one-parameter optimum value
`λ*·u(a)/(2(1−a)) ≥ 0`, where `u(a) = δ*·(1−a)^{1/q} − a^{1/q} − 1 + 2a`.
Uses `UStarMinAttained` (`u(a) ≥ 0` on `[0,z]`), `lambda_star q > 0`
(`LambdaStarDef`), and `a ≤ z_func q ≤ 1/2 < 1` (`ZeqInHalfRange`), so the
numerator and `2(1−a)` are nonneg/positive. -/
theorem perCapita_nonneg_on_zrange (q : ℝ) (hq : 1 < q)
    (a : ℝ) (ha_nn : 0 ≤ a) (ha_le_z : a ≤ z_func q) :
    0 ≤ lambda_star q * (delta_star q * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a) / (2 * (1 - a)) := by
  -- λ* > 0
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hlam_pos : 0 < lambda_star q := (LambdaStarDef.1 q hq_le).1
  -- z ≤ 1/2, so a ≤ 1/2 < 1
  have hZ := ZeqInHalfRange q hq
  have hz_le_half : z_func q ≤ 1/2 := hZ.2
  have ha_le_half : a ≤ 1/2 := le_trans ha_le_z hz_le_half
  -- u(a) ≥ 0 from UStarMinAttained
  have hU := UStarMinAttained q hq
  have hU3 : ∀ a, 0 ≤ a → a ≤ z_func q →
      0 ≤ delta_star q * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a :=
    hU.2.2
  have hu_a := hU3 a ha_nn ha_le_z
  -- numerator λ* · u(a) ≥ 0
  have h_num_nn : 0 ≤ lambda_star q * (delta_star q * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a) :=
    mul_nonneg (le_of_lt hlam_pos) hu_a
  -- denominator 2(1−a) > 0 since a ≤ 1/2 < 1
  have h_denom_nn : 0 ≤ 2 * (1 - a) := by linarith
  exact div_nonneg h_num_nn h_denom_nn

/-! ## Step 4: The relaxed infimum `V` is non-negative at `(λ*, δ*)`. -/

open Workspace.ProofLemmas.DuplicationLimit in
/-- `0 ≤ V q (lambda_star q) (delta_star q) n` for even `n > 0`.

Argument (paper §, duplication + limit): the per-capita sequence
`b_j = V(2m·2^j)/(2m·2^j)` (`n = 2m`) is antitone by `DuplicationLimit`
and converges (as a subsequence of `BPointKilledInLimit`'s sequence) to
`h_q(a_lim)` with `a_lim ∈ [0, z_func q]`, which is `≥ 0` by Step 3.
An antitone sequence converging to `L` has every term `≥ L ≥ 0`; hence
`V(n)/n ≥ 0`, so `V(n) ≥ 0`. Uses `BPointKilledInLimit` as a premise. -/
theorem VNonneg (q : ℝ) (hq : 1 < q) {n : ℕ} (hn_pos : 0 < n) (hn_even : Even n) :
    0 ≤ DuplicationLimit.V q (lambda_star q) (delta_star q) n := by
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hlam_pos : 0 < lambda_star q := (LambdaStarDef.1 q hq_le).1
  have hDS_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
  set lam : ℝ := lambda_star q with hlam_def
  set del : ℝ := delta_star q with hdel_def
  -- The two V definitions coincide definitionally.
  have hV_bridge : ∀ k : ℕ,
      Workspace.ProofLemmas.BPointKilledInLimit.V q lam del k
        = DuplicationLimit.V q lam del k := fun _ => rfl
  -- n = 2 * m, m > 0.
  obtain ⟨m, hm_eq⟩ := hn_even
  -- Even gives n = m + m; rewrite as 2 * m.
  have hn2m : n = 2 * m := by omega
  have hm_pos : 0 < m := by omega
  -- Extract a_lim and the tendsto from BPointKilledInLimit.
  have hBP := BPointKilledInLimit q hq lam hlam_pos del hDS_ge_one
  -- z in BPointKilledInLimit at del = delta_star q is exactly z_func q.
  obtain ⟨a_lim, ha_lim_nn, ha_lim_le_z, htend⟩ := hBP
  -- ha_lim_le_z : a_lim ≤ del ^ (-(q/(2q-1)))/(del^(-(q/(2q-1)))+1) = z_func q
  have ha_lim_le_zfunc : a_lim ≤ z_func q := ha_lim_le_z
  -- L := per-capita one-parameter optimum value λ·u(a_lim)/(2(1−a_lim)) ≥ 0 by Step 3.
  set L : ℝ := lam * (del * (1 - a_lim) ^ ((1:ℝ)/q) - a_lim ^ ((1:ℝ)/q) - 1 + 2 * a_lim) / (2 * (1 - a_lim)) with hL_def
  have hL_nn : 0 ≤ L := by
    rw [hL_def, hlam_def, hdel_def]
    exact perCapita_nonneg_on_zrange q hq a_lim ha_lim_nn ha_lim_le_zfunc
  -- The original sequence c k = V(2(k+1))/(2(k+1)) → L.
  set c : ℕ → ℝ := fun k =>
    Workspace.ProofLemmas.BPointKilledInLimit.V q lam del (2 * (k + 1)) / ((2 * (k + 1) : ℕ) : ℝ)
    with hc_def
  have hc_tend : Filter.Tendsto c Filter.atTop (nhds L) := htend
  -- Doubling subsequence: b j = V(2m·2^j)/(2m·2^j) = c (m·2^j - 1).
  set φ : ℕ → ℕ := fun j => m * 2 ^ j - 1 with hφ_def
  -- m * 2^j ≥ 1 for all j.
  have hm2j_pos : ∀ j, 0 < m * 2 ^ j := by
    intro j; positivity
  -- 2 * (φ j + 1) = 2 * m * 2 ^ j.
  have hφ_succ : ∀ j, 2 * (φ j + 1) = 2 * (m * 2 ^ j) := by
    intro j
    have hpos := hm2j_pos j
    have h1 : φ j + 1 = m * 2 ^ j := by
      show m * 2 ^ j - 1 + 1 = m * 2 ^ j
      omega
    rw [h1]
  -- b := c ∘ φ.
  set b : ℕ → ℝ := c ∘ φ with hb_def
  -- φ → atTop.
  have hφ_tend : Filter.Tendsto φ Filter.atTop Filter.atTop := by
    apply Filter.tendsto_atTop_atTop.2
    intro N
    refine ⟨N, fun j hj => ?_⟩
    have hj_lt : j < 2 ^ j := Nat.lt_two_pow_self
    have h2j : N + 1 ≤ 2 ^ j := by omega
    have hmle : N + 1 ≤ m * 2 ^ j := le_trans h2j (Nat.le_mul_of_pos_left _ hm_pos)
    show N ≤ m * 2 ^ j - 1
    omega
  -- b → L (subsequence of c).
  have hb_tend : Filter.Tendsto b Filter.atTop (nhds L) :=
    hc_tend.comp hφ_tend
  -- b is antitone: b (j+1) ≤ b j, via DuplicationLimit on the even number 2 * m * 2^j.
  have hb_form : ∀ j, b j = DuplicationLimit.V q lam del (2 * (m * 2 ^ j)) / ((2 * (m * 2 ^ j) : ℕ) : ℝ) := by
    intro j
    show c (φ j) = _
    rw [hc_def]
    simp only
    rw [hφ_succ j, hV_bridge]
  have hb_anti : Antitone b := by
    apply antitone_nat_of_succ_le
    intro j
    -- b (j+1) ≤ b j
    rw [hb_form j, hb_form (j + 1)]
    -- 2 * (m * 2^(j+1)) = 2 * (2 * (m * 2^j))
    have hpow : m * 2 ^ (j + 1) = 2 * (m * 2 ^ j) := by ring
    rw [hpow]
    -- Now goal: V(2*(2*(m*2^j)))/(2*(2*(m*2^j))) ≤ V(2*(m*2^j))/(2*(m*2^j))
    -- Apply DuplicationLimit with n' = 2 * (m * 2^j) (even, positive).
    set N' : ℕ := 2 * (m * 2 ^ j) with hN'_def
    have hN'_pos : 0 < N' := by rw [hN'_def]; positivity
    have hN'_even : Even N' := ⟨m * 2 ^ j, by rw [hN'_def]; ring⟩
    have hDL := DuplicationLimit q hq lam hlam_pos del hDS_ge_one N' hN'_pos hN'_even
    exact hDL
  -- L ≤ b 0, since b antitone (∀ j, b j ≤ b 0) and b → L.
  have hL_le_b0 : L ≤ b 0 :=
    le_of_tendsto' hb_tend (fun j => hb_anti (Nat.zero_le j))
  -- b 0 = V(2m)/(2m) = V(n)/n.
  have hb0 : b 0 = DuplicationLimit.V q lam del n / (n : ℝ) := by
    rw [hb_form 0]
    simp only [pow_zero, mul_one]
    rw [← hn2m]
  rw [hb0] at hL_le_b0
  -- 0 ≤ L ≤ V(n)/n, and n > 0, so 0 ≤ V(n).
  have hn_real_pos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn_pos
  have h_vn_div_nn : 0 ≤ DuplicationLimit.V q lam del n / (n : ℝ) := le_trans hL_nn hL_le_b0
  -- 0 ≤ (V/n) * n = V.
  have hmul : 0 ≤ DuplicationLimit.V q lam del n / (n : ℝ) * (n : ℝ) :=
    mul_nonneg h_vn_div_nn (le_of_lt hn_real_pos)
  rwa [div_mul_cancel₀ _ (ne_of_gt hn_real_pos)] at hmul

/-! ## Step 5: Feasible value ≥ V ≥ 0. The assembled core inequality. -/

open Workspace.ProofLemmas.DuplicationLimit in
/-- The assembled non-negativity of `∑ h_q(x_i)` for a feasible `x` at
`λ = λ*(q)`, `δ = δ(λ*) = δ*(q)`. This is the genuine paper result
combining Steps 1, 3, 4, and `csInf_le`. -/
theorem relaxedFeasibleSumNonneg_assembled
    (q : ℝ) (hq : 1 < q)
    {n : ℕ} (hn_pos : 0 < n) (hn_even : Even n)
    (lambda : ℝ) (hlam_eq : lambda = lambda_star q)
    (delta : ℝ) (hdelta_eq : delta = delta_of_lambda q lambda)
    (x : Fin n → ℝ)
    (hx_nn : ∀ i, 0 ≤ x i) (hx_le_one : ∀ i, x i ≤ 1)
    (hx_sum : (∑ i, x i) = (n : ℝ) / 2) :
    0 ≤ (∑ i, h_q q lambda delta (x i)) := by
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hlam_pos : 0 < lambda := by rw [hlam_eq]; exact (LambdaStarDef.1 q hq_le).1
  -- Bridge: delta = delta_star q.
  have hdelta_star : delta = delta_star q := by
    rw [hdelta_eq, hlam_eq]
    exact deltaOfLambda_lambdaStar_eq q hq
  have hDS_ge_one : 1 ≤ delta_star q := (DeltaStarDef q hq).1
  have hdelta_ge_one : 1 ≤ delta := by rw [hdelta_star]; exact hDS_ge_one
  -- The feasible set.
  set S : Set ℝ := { v : ℝ | ∃ y : Fin n → ℝ, (∀ i, 0 ≤ y i) ∧ (∀ i, y i ≤ 1) ∧
                 (∑ i, y i) = (n : ℝ) / 2 ∧ v = ∑ i, h_q q lambda delta (y i) } with hS_def
  have hV_eq : DuplicationLimit.V q lambda delta n = sInf S := rfl
  -- x is feasible, so its cost is in S.
  have hx_mem : (∑ i, h_q q lambda delta (x i)) ∈ S :=
    ⟨x, hx_nn, hx_le_one, hx_sum, rfl⟩
  -- BddBelow S: pointwise h_q ≥ -lambda on [0,1].
  have hq0 : 0 < q := lt_trans zero_lt_one hq
  have hq_inv_pos : 0 < (1 : ℝ) / q := by positivity
  have h_lower_pointwise : ∀ y : ℝ, 0 ≤ y → y ≤ 1 → -lambda ≤ h_q q lambda delta y := by
    intro y hy0 hy1
    have hy0' : (0 : ℝ) ≤ 1 - y := by linarith
    have h_pow_y : y ^ ((1 : ℝ) / q) ≤ 1 := Real.rpow_le_one hy0 hy1 (le_of_lt hq_inv_pos)
    have h_pow_1my : 0 ≤ (1 - y) ^ ((1 : ℝ) / q) := Real.rpow_nonneg hy0' _
    have h_inner : -1 ≤ delta * (1 - y) ^ ((1 : ℝ) / q) - y ^ ((1 : ℝ) / q) := by
      have hd_nn : 0 ≤ delta * (1 - y) ^ ((1 : ℝ) / q) :=
        mul_nonneg (by linarith) h_pow_1my
      linarith
    show -lambda ≤ lambda * (delta * (1 - y) ^ ((1 : ℝ) / q) - y ^ ((1 : ℝ) / q))
    have := mul_le_mul_of_nonneg_left h_inner (le_of_lt hlam_pos)
    linarith
  have h_bddBelow : BddBelow S := by
    refine ⟨-(n : ℝ) * lambda, ?_⟩
    intro v hv
    obtain ⟨y, hy0, hy1, _hsum, hveq⟩ := hv
    rw [hveq]
    have hpt : ∀ i, -lambda ≤ h_q q lambda delta (y i) := fun i =>
      h_lower_pointwise (y i) (hy0 i) (hy1 i)
    have hsum_lb : ∑ _i : Fin n, (-lambda) ≤ ∑ i, h_q q lambda delta (y i) :=
      Finset.sum_le_sum (fun i _ => hpt i)
    have hconst : ∑ _i : Fin n, (-lambda : ℝ) = -(n : ℝ) * lambda := by
      rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin]; ring
    linarith [hconst, hsum_lb]
  -- V ≤ feasible value.
  have hV_le : DuplicationLimit.V q lambda delta n ≤ ∑ i, h_q q lambda delta (x i) := by
    rw [hV_eq]
    exact csInf_le h_bddBelow hx_mem
  -- 0 ≤ V (Step 4), rewriting lambda, delta to the canonical forms.
  have hV_nn : 0 ≤ DuplicationLimit.V q lambda delta n := by
    rw [hlam_eq, hdelta_star]
    exact VNonneg q hq hn_pos hn_even
  linarith

end Workspace.ProofLemmas.RelaxedCoreAssembly
