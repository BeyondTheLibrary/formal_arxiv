import Mathlib
import Workspace.ProofLemmas.HSecondDerivative
import Workspace.ProofLemmas.OneParamReduction

open Workspace.ProofLemmas.HSecondDerivative

namespace Workspace.ProofLemmas.BPointKilledInLimitProof

/-- Local copy of the relaxed per-capita infimum `V`. Definitionally identical
to `Workspace.ProofLemmas.BPointKilledInLimit.V`, so the assembled theorem
discharges `BPointKilledInLimit`'s goal up to defeq. Defined here to keep the
import DAG acyclic (the proof file must not import the target file). -/
noncomputable def V (q lambda delta : ℝ) (n : ℕ) : ℝ :=
  sInf { v : ℝ | ∃ x : Fin n → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, x i ≤ 1) ∧
                 (∑ i, x i) = (n : ℝ) / 2 ∧
                 v = ∑ i, h_q q lambda delta (x i) }

/-! # Duplication-limit step (`BPointKilledInLimit`), decomposed.

This file develops the paper's `n → ∞` duplication argument
(Gravin–Jia, `approx.tex` lines 230–247) that the per-capita relaxed minimum
`V(N)/N` converges to the one-parameter optimum `pc(a_lim)` on `[0, z]`.

`pc a = λ · u(a) / (2(1−a))` with `u(a) = δ(1−a)^{1/q} − a^{1/q} − 1 + 2a`
is the per-capita value of an exact `(a,1)` two-value mix
(`OneParamReduction`). The argument:

* **Step 1** (`pc_continuousOn_Icc`, `pc_min_exists`): `pc` is continuous on the
  compact `[0,z]`, hence attains its minimum at some `a_lim ∈ [0,z]`. FULLY
  PROVEN below.
* **Step 2** (`limsup_le_pc_min`): UPPER bound. For the minimizer `a_lim`,
  feasible `(a_lim,1)` configurations (with integer rounding, error `O(1/N)`)
  give `limsup V(N)/N ≤ pc(a_lim)`.
* **Step 3** (`pc_min_le_liminf`): LOWER bound. Any feasible config has value
  `≥ pc(a_lim)·N + O(1)` by `ThreeValueStructure` (one b-point, contributing
  `O(1/N)` per-capita), so `liminf V(N)/N ≥ pc(a_lim)`.
* **Step 4** (`BPointKilledInLimitProof`): squeeze Steps 2+3 into `Tendsto`.

Steps 2 and 3 are genuinely hard real-analysis and are left as clearly-isolated,
documented `sorry`s (see each lemma). Step 1 and the assembly are complete. -/

/-- The per-capita value of an exact `(a,1)` two-value mix, as a function of the
small value `a`. By `OneParamReduction`, for an exact `(a,1)` split of size `n`
summing to `n/2`, the per-capita cost `(∑ h_q(x_i))/n` equals `pc q λ δ a`. -/
noncomputable def pc (q lambda delta a : ℝ) : ℝ :=
  lambda * (delta * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a)
    / (2 * (1 - a))

/-! ## Step 1 — `pc` is continuous on `[0,z]` and attains its minimum there. -/

/-- `pc q λ δ` is continuous on `[0, z]` whenever `z ≤ 1/2` (so the denominator
`2(1−a)` is bounded away from `0` on the interval). FULLY PROVEN. -/
theorem pc_continuousOn_Icc
    (q : ℝ) (hq : 1 < q) (lambda delta : ℝ) (z : ℝ) (hz_le_half : z ≤ 1/2) :
    ContinuousOn (fun a => pc q lambda delta a) (Set.Icc (0 : ℝ) z) := by
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_inv_nn : (0 : ℝ) ≤ 1 / q := by positivity
  -- numerator is continuous (everywhere)
  have h_pow_a : Continuous (fun a : ℝ => a ^ ((1 : ℝ) / q)) :=
    Real.continuous_rpow_const hq_inv_nn
  have h_pow_1ma : Continuous (fun a : ℝ => (1 - a) ^ ((1 : ℝ) / q)) := by
    have h_sub : Continuous (fun a : ℝ => 1 - a) := by continuity
    exact (Real.continuous_rpow_const hq_inv_nn).comp h_sub
  have h_num : Continuous (fun a : ℝ =>
      lambda * (delta * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a)) := by
    have : Continuous (fun a : ℝ =>
        delta * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q) - 1 + 2 * a) := by
      have hd : Continuous (fun a : ℝ => delta * (1 - a) ^ ((1 : ℝ) / q)) :=
        continuous_const.mul h_pow_1ma
      have : Continuous (fun a : ℝ =>
          delta * (1 - a) ^ ((1 : ℝ) / q) - a ^ ((1 : ℝ) / q)) := hd.sub h_pow_a
      exact (this.sub continuous_const).add (continuous_const.mul continuous_id)
    exact continuous_const.mul this
  -- denominator is continuous and nonzero on [0,z]
  have h_den : Continuous (fun a : ℝ => 2 * (1 - a)) := by continuity
  have h_den_ne : ∀ a ∈ Set.Icc (0 : ℝ) z, (2 * (1 - a)) ≠ 0 := by
    intro a ha
    obtain ⟨_, ha_le⟩ := ha
    have ha_lt_one : a < 1 := lt_of_le_of_lt (le_trans ha_le hz_le_half) (by norm_num)
    have : (0 : ℝ) < 2 * (1 - a) := by linarith
    exact ne_of_gt this
  exact (h_num.continuousOn).div₀ (h_den.continuousOn) h_den_ne

/-- **Step 1 result.** `pc q λ δ` attains its minimum over the compact set
`[0, z]` at some `a_lim ∈ [0, z]`. FULLY PROVEN. -/
theorem pc_min_exists
    (q : ℝ) (hq : 1 < q) (lambda delta : ℝ) (z : ℝ)
    (hz_nn : 0 ≤ z) (hz_le_half : z ≤ 1/2) :
    ∃ a_lim : ℝ, a_lim ∈ Set.Icc (0 : ℝ) z ∧
      IsMinOn (fun a => pc q lambda delta a) (Set.Icc (0 : ℝ) z) a_lim := by
  have hcompact : IsCompact (Set.Icc (0 : ℝ) z) := isCompact_Icc
  have hne : (Set.Icc (0 : ℝ) z).Nonempty := Set.nonempty_Icc.mpr hz_nn
  have hcont := pc_continuousOn_Icc q hq lambda delta z hz_le_half
  exact hcompact.exists_isMinOn hne hcont

/-! ## Boundedness of the per-capita sequence (needed for the squeeze).

`V(N)/N` lies in `[-lambda, lambda*delta]` for every `N` (each `h_q(x_i) ∈
[-lambda, lambda*delta]` on `[0,1]`, so the average is too, and `sInf` of a set
bounded in this band lies in the band). This gives the `IsBoundedUnder`
side-conditions of the squeeze lemma. -/

/-- Pointwise band for `h_q` on `[0,1]`: `-λ ≤ h_q q λ δ x ≤ λδ`. -/
theorem h_q_band
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    -lambda ≤ h_q q lambda delta x ∧ h_q q lambda delta x ≤ lambda * delta := by
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hinv_nn : (0 : ℝ) ≤ 1 / q := by positivity
  have h1mx_nn : (0 : ℝ) ≤ 1 - x := by linarith
  have hA_nn : (0 : ℝ) ≤ (1 - x) ^ ((1 : ℝ) / q) := Real.rpow_nonneg h1mx_nn _
  have hA_le : (1 - x) ^ ((1 : ℝ) / q) ≤ 1 := Real.rpow_le_one h1mx_nn (by linarith) hinv_nn
  have hB_nn : (0 : ℝ) ≤ x ^ ((1 : ℝ) / q) := Real.rpow_nonneg hx0 _
  have hB_le : x ^ ((1 : ℝ) / q) ≤ 1 := Real.rpow_le_one hx0 hx1 hinv_nn
  unfold h_q
  constructor
  · have hdA : (0 : ℝ) ≤ delta * (1 - x) ^ ((1 : ℝ) / q) := by positivity
    nlinarith [hlam.le]
  · have hdA_le : delta * (1 - x) ^ ((1 : ℝ) / q) ≤ delta := by
      nlinarith [hA_le, hA_nn, hdelta]
    nlinarith [hlam.le, hB_nn, hdA_le]

/-- The feasible set defining `V q λ δ N` is nonempty whenever `N` is even
(the all-`1/2` configuration is feasible). Stated for the specific `N = 2(n+1)`. -/
theorem feasibleSet_mem_half
    (q lambda delta : ℝ) (m : ℕ) :
    (∑ i : Fin (2 * (m + 1)), h_q q lambda delta ((fun _ => (1 : ℝ) / 2) i)) ∈
      { v : ℝ | ∃ x : Fin (2 * (m + 1)) → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, x i ≤ 1) ∧
                 (∑ i, x i) = ((2 * (m + 1) : ℕ) : ℝ) / 2 ∧
                 v = ∑ i, h_q q lambda delta (x i) } := by
  refine ⟨fun _ => (1 : ℝ) / 2, ?_, ?_, ?_, rfl⟩
  · intro i; norm_num
  · intro i; norm_num
  · rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin]
    push_cast
    ring

/-- The feasible set defining `V q λ δ N` is bounded below by `-λ·N`. -/
theorem feasibleSet_bddBelow
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) (N : ℕ) :
    BddBelow { v : ℝ | ∃ x : Fin N → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, x i ≤ 1) ∧
                 (∑ i, x i) = (N : ℝ) / 2 ∧
                 v = ∑ i, h_q q lambda delta (x i) } := by
  refine ⟨-(lambda * N), ?_⟩
  rintro v ⟨x, hx0, hx1, _, rfl⟩
  have hbound : ∀ i : Fin N, -lambda ≤ h_q q lambda delta (x i) := by
    intro i
    exact (h_q_band q hq lambda hlam delta hdelta (x i) (hx0 i) (hx1 i)).1
  calc -(lambda * N) = ∑ _i : Fin N, (-lambda) := by
              rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]; ring
    _ ≤ ∑ i, h_q q lambda delta (x i) := Finset.sum_le_sum (fun i _ => hbound i)

theorem perCapita_isBounded
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) :
    Filter.IsBoundedUnder (· ≤ ·) Filter.atTop
        (fun n : ℕ => V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ)) ∧
    Filter.IsBoundedUnder (· ≥ ·) Filter.atTop
        (fun n : ℕ => V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ)) := by
  -- For every n, with N = 2(n+1): -λ ≤ V(N)/N ≤ λδ.
  have key : ∀ n : ℕ,
      -lambda ≤ V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ) ∧
      V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ) ≤ lambda * delta := by
    intro n
    set N : ℕ := 2 * (n + 1) with hN_def
    have hN_pos : 0 < N := by positivity
    have hN_pos_real : (0 : ℝ) < (N : ℝ) := by exact_mod_cast hN_pos
    have hN_ne : (N : ℝ) ≠ 0 := ne_of_gt hN_pos_real
    set S : Set ℝ := { v : ℝ | ∃ x : Fin N → ℝ, (∀ i, 0 ≤ x i) ∧ (∀ i, x i ≤ 1) ∧
                 (∑ i, x i) = (N : ℝ) / 2 ∧
                 v = ∑ i, h_q q lambda delta (x i) } with hS_def
    have hbdd : BddBelow S := feasibleSet_bddBelow q hq lambda hlam delta hdelta N
    -- nonempty witness: the all-1/2 config
    have hmem : (∑ i : Fin N, h_q q lambda delta ((fun _ => (1 : ℝ) / 2) i)) ∈ S :=
      feasibleSet_mem_half q lambda delta n
    -- lower bound for V: -λN ≤ V (csInf ≥ lower bound)
    have hVlow : -(lambda * (N : ℝ)) ≤ V q lambda delta N := by
      apply le_csInf
      · exact ⟨_, hmem⟩
      · rintro v ⟨x, hx0, hx1, _, rfl⟩
        have hbound : ∀ i : Fin N, -lambda ≤ h_q q lambda delta (x i) := by
          intro i
          exact (h_q_band q hq lambda hlam delta hdelta (x i) (hx0 i) (hx1 i)).1
        calc -(lambda * (N:ℝ)) = ∑ _i : Fin N, (-lambda) := by
                  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]; ring
          _ ≤ ∑ i, h_q q lambda delta (x i) := Finset.sum_le_sum (fun i _ => hbound i)
    -- upper bound for V: V ≤ (value at all-1/2 config) ≤ λδ·N
    have hVup : V q lambda delta N ≤ lambda * delta * (N : ℝ) := by
      have hle : V q lambda delta N ≤
          (∑ i : Fin N, h_q q lambda delta ((fun _ => (1 : ℝ) / 2) i)) :=
        csInf_le hbdd hmem
      have hval : (∑ i : Fin N, h_q q lambda delta ((fun _ => (1 : ℝ) / 2) i)) ≤
          lambda * delta * (N : ℝ) := by
        have hbound : ∀ i : Fin N,
            h_q q lambda delta ((1 : ℝ) / 2) ≤ lambda * delta :=
          fun i => (h_q_band q hq lambda hlam delta hdelta ((1:ℝ)/2)
            (by norm_num) (by norm_num)).2
        calc (∑ i : Fin N, h_q q lambda delta ((fun _ => (1 : ℝ) / 2) i))
              = ∑ _i : Fin N, h_q q lambda delta ((1:ℝ)/2) := rfl
          _ ≤ ∑ _i : Fin N, lambda * delta := Finset.sum_le_sum (fun i _ => hbound i)
          _ = lambda * delta * (N : ℝ) := by
                rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]; ring
      linarith
    refine ⟨?_, ?_⟩
    · rw [le_div_iff₀ hN_pos_real]
      have : -lambda * (N:ℝ) = -(lambda * (N:ℝ)) := by ring
      rw [this]; exact hVlow
    · rw [div_le_iff₀ hN_pos_real]; exact hVup
  constructor
  · exact Filter.isBoundedUnder_of ⟨lambda * delta, fun n => (key n).2⟩
  · exact Filter.isBoundedUnder_of ⟨-lambda, fun n => (key n).1⟩

/-! ## Step 2 — Upper bound: `limsup V(N)/N ≤ pc(a_lim)`.

For the minimizer `a_lim`, construct for each `N = 2(n+1)` a feasible
configuration `x : Fin N → ℝ` taking values in `{a_lim, 1}` (with integer
rounding of the count at `a_lim` to satisfy `∑ x = N/2`; the rounding error is
`O(1/N)`). Then `V(N) ≤ ∑ h_q(x_i)` by `csInf_le`, and the per-capita value of
the rounded config tends to `pc q λ δ a_lim` by `OneParamReduction` plus the
`O(1/N)` correction. Hence `limsup V(N)/N ≤ pc(a_lim)`.

This is the genuinely hard "upper bound" half. It is decomposed into:

* `limsup_le_pc_min_witness` — the irreducible analytic core: a uniform
  per-capita witness bound `V(N)/N ≤ pc(a_lim) + C/N` for a single constant
  `C` independent of `N`, obtained from the feasible rounded `(a_lim, 1)`
  configuration (`csInf_le` on the explicit `Fin N → ℝ` config, with the single
  `O(1)` repair coordinate giving the `C/N` slack). This single step is left as
  a documented `sorry` — it is the only remaining gap of Step 2.
* `limsup_le_pc_min` — FULLY PROVEN below from the witness: since `C/N → 0`,
  the dominating sequence `pc(a_lim) + C/N` converges to `pc(a_lim)`, so its
  `limsup` is `pc(a_lim)`, and `V(N)/N ≤ pc(a_lim) + C/N` pointwise pushes the
  `limsup` of `V(N)/N` below it via `Filter.limsup_le_limsup`. -/

/-- **Irreducible analytic core of Step 2's upper bound.** There is a single
constant `C` (depending only on `q, λ, δ, a_lim`, NOT on `N`) such that the
per-capita relaxed minimum is bounded by the one-parameter optimum up to an
`O(1/N)` slack: `V(2(n+1))/(2(n+1)) ≤ pc(a_lim) + C/(2(n+1))` for all `n`.

Math: take the feasible config with `k = ⌊N/(2(1−a_lim))⌋` coordinates at
`a_lim`, one repair coordinate `r ∈ [0,1]` fixing `∑ = N/2`, and the remaining
`N−k−1` coordinates at `1`. Such a `k` always exists because the admissible
window for `k` has length `1/(1−a_lim) ≥ 1`. By `csInf_le`, `V(N) ≤ ∑ h_q`.
The exact `(a_lim,1)` per-capita value is `pc(a_lim)` (`OneParamReduction` in
the limit); the single repair coordinate and the `|k − N·c| ≤ 1` rounding error
each contribute a bounded amount, all absorbed into `C/N`. Left as a documented
`sorry`: the explicit `Fin N → ℝ` construction, its feasibility, and the value
computation. -/
theorem limsup_le_pc_min_witness
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta)
    (z : ℝ) (a_lim : ℝ) (ha_lim_mem : a_lim ∈ Set.Icc (0 : ℝ) z)
    (hz_le_half : z ≤ 1/2) :
    ∃ C : ℝ, ∀ n : ℕ,
      V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ)
        ≤ pc q lambda delta a_lim + C / ((2 * (n + 1) : ℕ) : ℝ) := by
  sorry

theorem limsup_le_pc_min
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta)
    (z : ℝ) (a_lim : ℝ) (ha_lim_mem : a_lim ∈ Set.Icc (0 : ℝ) z)
    (hz_le_half : z ≤ 1/2) :
    Filter.limsup
        (fun n : ℕ => V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ))
        Filter.atTop
      ≤ pc q lambda delta a_lim := by
  obtain ⟨C, hC⟩ :=
    limsup_le_pc_min_witness q hq lambda hlam delta hdelta z a_lim ha_lim_mem hz_le_half
  set u : ℕ → ℝ :=
    fun n => V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ) with hu_def
  set v : ℕ → ℝ :=
    fun n => pc q lambda delta a_lim + C / ((2 * (n + 1) : ℕ) : ℝ) with hv_def
  -- The dominating sequence `v` converges to `pc(a_lim)`.
  have hN_tendsto : Filter.Tendsto (fun n : ℕ => ((2 * (n + 1) : ℕ) : ℝ))
      Filter.atTop Filter.atTop := by
    apply Filter.tendsto_atTop_mono (f := fun n : ℕ => ((n : ℝ) + 1))
    · intro n; push_cast; nlinarith [Nat.cast_nonneg (α := ℝ) n]
    · exact Filter.tendsto_atTop_add_const_right _ 1 tendsto_natCast_atTop_atTop
  have hdiv0 : Filter.Tendsto (fun n : ℕ => C / ((2 * (n + 1) : ℕ) : ℝ))
      Filter.atTop (nhds 0) :=
    Filter.Tendsto.div_atTop (tendsto_const_nhds) hN_tendsto
  have hv_tendsto : Filter.Tendsto v Filter.atTop (nhds (pc q lambda delta a_lim)) := by
    have := Filter.Tendsto.const_add (pc q lambda delta a_lim) hdiv0
    simpa [hv_def, add_zero] using this
  have hv_limsup : Filter.limsup v Filter.atTop = pc q lambda delta a_lim :=
    hv_tendsto.limsup_eq
  -- u ≤ v pointwise.
  have huv : u ≤ᶠ[Filter.atTop] v := Filter.Eventually.of_forall (fun n => hC n)
  -- Coboundedness of u and boundedness of v.
  obtain ⟨_, hb_lo⟩ := perCapita_isBounded q hq lambda hlam delta hdelta
  have hcobdd : Filter.IsCoboundedUnder (· ≤ ·) Filter.atTop u :=
    Filter.IsBoundedUnder.isCoboundedUnder_le hb_lo
  have hv_bdd : Filter.IsBoundedUnder (· ≤ ·) Filter.atTop v :=
    hv_tendsto.isBoundedUnder_le
  calc Filter.limsup u Filter.atTop
        ≤ Filter.limsup v Filter.atTop := Filter.limsup_le_limsup huv hcobdd hv_bdd
    _ = pc q lambda delta a_lim := hv_limsup

/-! ## Step 3 — Lower bound: `pc(a_lim) ≤ liminf V(N)/N`.

For each `N`, the relaxed minimizer (which exists since the feasible set is
compact, `ConstrainedMinExists`) has the three-value structure `x_i ∈ {a,b,1}`
with at most one `b`-point (`ThreeValueStructure`). Discarding the single
`b`-point (whose `h_q` contribution is bounded, hence `O(1/N)` per-capita), the
`(a,1)` part has per-capita value `≥ min_{a'∈[0,z]} pc(a') = pc(a_lim)`. Hence
`V(N)/N ≥ pc(a_lim) − O(1/N)`, giving `liminf V(N)/N ≥ pc(a_lim)`.

This is the genuinely hard "lower bound" half: applying `ThreeValueStructure`
to the per-`N` minimizer, reducing the `(a,1)` part via `OneParamReduction`,
bounding its per-capita value below by `pc(a_lim)` (minimality of `a_lim`), and
controlling the b-point in the limit. Left as a documented `sorry`. -/
theorem pc_min_le_liminf
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta)
    (z : ℝ) (a_lim : ℝ) (ha_lim_mem : a_lim ∈ Set.Icc (0 : ℝ) z)
    (hz_le_half : z ≤ 1/2)
    (h_min : IsMinOn (fun a => pc q lambda delta a) (Set.Icc (0 : ℝ) z) a_lim) :
    pc q lambda delta a_lim
      ≤ Filter.liminf
          (fun n : ℕ => V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ))
          Filter.atTop := by
  sorry

/-! ## Step 4 — Assemble: squeeze upper + lower bound into convergence. -/

/-- The full duplication-limit statement, in the `pc`-notation. Combines
Steps 1–3 via `tendsto_of_le_liminf_of_limsup_le`. The bridge to the
`BPointKilledInLimit` target value (`pc a_lim` unfolds to the target) is
definitional. -/
theorem BPointKilledInLimit_pc
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) :
    let z := delta ^ (-(q / (2*q - 1))) / (delta ^ (-(q / (2*q - 1))) + 1)
    ∃ a_lim : ℝ, 0 ≤ a_lim ∧ a_lim ≤ z ∧
      Filter.Tendsto
        (fun n : ℕ => V q lambda delta (2 * (n + 1)) / ((2 * (n + 1) : ℕ) : ℝ))
        Filter.atTop (nhds (pc q lambda delta a_lim)) := by
  intro z
  -- z ∈ [0, 1/2]: need delta ≥ 1 hence z = D^p/(D^p+1) with p < 0, D^p ∈ (0,1].
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have h2q1 : (0 : ℝ) < 2*q - 1 := by linarith
  set p : ℝ := -(q / (2*q - 1)) with hp_def
  have hp_neg : p < 0 := by
    rw [hp_def, neg_lt, neg_zero]; exact div_pos hq_pos h2q1
  have hp_nonpos : p ≤ 0 := le_of_lt hp_neg
  have hDpos : (0 : ℝ) < delta := lt_of_lt_of_le one_pos hdelta
  have hDp_pos : (0 : ℝ) < delta ^ p := Real.rpow_pos_of_pos hDpos p
  have hDp_le_one : delta ^ p ≤ 1 :=
    Real.rpow_le_one_of_one_le_of_nonpos hdelta hp_nonpos
  have hDenom_pos : (0 : ℝ) < delta ^ p + 1 := by linarith
  have hz_nn : 0 ≤ z := by
    show 0 ≤ delta ^ p / (delta ^ p + 1)
    exact le_of_lt (div_pos hDp_pos hDenom_pos)
  have hz_le_half : z ≤ 1/2 := by
    show delta ^ p / (delta ^ p + 1) ≤ 1/2
    rw [div_le_div_iff₀ hDenom_pos (by norm_num : (0:ℝ) < 2)]
    linarith
  -- Step 1: minimizer.
  obtain ⟨a_lim, ha_lim_mem, h_min⟩ :=
    pc_min_exists q hq lambda delta z hz_nn hz_le_half
  obtain ⟨ha_lim_nn, ha_lim_le_z⟩ := ha_lim_mem
  refine ⟨a_lim, ha_lim_nn, ha_lim_le_z, ?_⟩
  -- Steps 2,3,boundedness → squeeze.
  have h_up := limsup_le_pc_min q hq lambda hlam delta hdelta z a_lim
    ⟨ha_lim_nn, ha_lim_le_z⟩ hz_le_half
  have h_lo := pc_min_le_liminf q hq lambda hlam delta hdelta z a_lim
    ⟨ha_lim_nn, ha_lim_le_z⟩ hz_le_half h_min
  obtain ⟨hb_up, hb_lo⟩ := perCapita_isBounded q hq lambda hlam delta hdelta
  exact tendsto_of_le_liminf_of_limsup_le h_lo h_up hb_up hb_lo

end Workspace.ProofLemmas.BPointKilledInLimitProof
