import Mathlib

open scoped BigOperators

namespace Workspace.Types.LqNorm

/-- The `L_q` norm of a vector `x : Fin d → ℝ`, defined directly via
`Real.rpow`:
`lqNorm q x = (∑ j, |x j| ^ q) ^ (1/q)`.

We avoid `PiLp` / `EuclideanSpace` so the formula textually matches the
paper. The dimension `d` is implicit; the function is total in `q : ℝ`,
but the meaningful basic properties (non-negativity, scaling by a real)
are stated with `1 ≤ q` as required. -/
noncomputable def lqNorm (q : ℝ) {d : ℕ} (x : Fin d → ℝ) : ℝ :=
  (∑ j, |x j| ^ q) ^ ((1 : ℝ) / q)

/-- The inner sum `∑ j, |x j| ^ q` is non-negative. -/
lemma sum_abs_rpow_nonneg (q : ℝ) {d : ℕ} (x : Fin d → ℝ) :
    0 ≤ ∑ j, |x j| ^ q :=
  Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)

/-- `lqNorm q x` is non-negative for any real `q` (since the inner sum
is non-negative and `Real.rpow` of a non-negative base is non-negative). -/
lemma lqNorm_nonneg' (q : ℝ) {d : ℕ} (x : Fin d → ℝ) :
    0 ≤ lqNorm q x :=
  Real.rpow_nonneg (sum_abs_rpow_nonneg q x) _

/-- Spec-named non-negativity (with the `1 ≤ q` hypothesis). -/
lemma lqNorm_nonneg {q : ℝ} (_hq : 1 ≤ q) {d : ℕ} (x : Fin d → ℝ) :
    0 ≤ lqNorm q x :=
  lqNorm_nonneg' q x

/-- The L_q norm of the zero vector is 0. We use `Real.zero_rpow` and
the fact that `∑ j, |0|^q = 0`. -/
lemma lqNorm_zero {q : ℝ} (hq : 1 ≤ q) {d : ℕ} :
    lqNorm q (fun _ : Fin d => (0 : ℝ)) = 0 := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_ne : (1 : ℝ) / q ≠ 0 := by
    rw [one_div]; exact inv_ne_zero hq_ne
  unfold lqNorm
  have hsum : (∑ _j : Fin d, |(0 : ℝ)| ^ q) = 0 := by
    refine Finset.sum_eq_zero ?_
    intro j _
    rw [abs_zero, Real.zero_rpow hq_ne]
  rw [hsum, Real.zero_rpow h_inv_ne]

/-- The L_1 norm is the sum of absolute values. -/
lemma lqNorm_one_eq_sum_abs {d : ℕ} (x : Fin d → ℝ) :
    lqNorm 1 x = ∑ j, |x j| := by
  unfold lqNorm
  simp [Real.rpow_one]

/-- Scaling by a real `c`: `lqNorm q (c • x) = |c| * lqNorm q x`. -/
lemma lqNorm_smul {q : ℝ} (hq : 1 ≤ q) {d : ℕ} (c : ℝ) (x : Fin d → ℝ) :
    lqNorm q (fun j => c * x j) = |c| * lqNorm q x := by
  unfold lqNorm
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  -- Step 1: |c * x j| ^ q = |c|^q * |x j|^q, then factor the sum
  have h1 : (∑ j, |c * x j| ^ q) = |c| ^ q * ∑ j, |x j| ^ q := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl ?_
    intro j _
    rw [abs_mul, Real.mul_rpow (abs_nonneg _) (abs_nonneg _)]
  rw [h1]
  -- Step 2: distribute the outer rpow over the product
  have hcq_nn : 0 ≤ |c| ^ q := Real.rpow_nonneg (abs_nonneg _) q
  have hsum_nn : 0 ≤ ∑ j, |x j| ^ q := sum_abs_rpow_nonneg q x
  rw [Real.mul_rpow hcq_nn hsum_nn]
  -- Step 3: (|c|^q)^(1/q) = |c|, since q * (1/q) = 1 and |c| ≥ 0.
  have habs_nn : (0 : ℝ) ≤ |c| := abs_nonneg _
  have h2 : (|c| ^ q) ^ ((1 : ℝ) / q) = |c| := by
    rw [← Real.rpow_mul habs_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  rw [h2]

/-- (Optional, sanity) `lqNorm q` on a 1-dimensional vector is `|x 0|`. -/
lemma lqNorm_dim_one {q : ℝ} (hq : 1 ≤ q) (x : Fin 1 → ℝ) :
    lqNorm q x = |x 0| := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  unfold lqNorm
  rw [Fin.sum_univ_one]
  rw [← Real.rpow_mul (abs_nonneg _), mul_one_div, div_self hq_ne, Real.rpow_one]

/-- (Optional, sanity) `lqNorm q` on a 0-dimensional vector is `0`. -/
lemma lqNorm_dim_zero {q : ℝ} (hq : 1 ≤ q) (x : Fin 0 → ℝ) :
    lqNorm q x = 0 := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_ne : (1 : ℝ) / q ≠ 0 := by
    rw [one_div]; exact inv_ne_zero hq_ne
  unfold lqNorm
  have : (∑ j : Fin 0, |x j| ^ q) = 0 := by
    rw [Fin.sum_univ_zero]
  rw [this, Real.zero_rpow h_inv_ne]

end Workspace.Types.LqNorm

open scoped BigOperators
open Workspace.Types.LqNorm

namespace Workspace.Types.SocialCost

/-- The social cost of placing a facility at `f : Fin d → ℝ` for `n`
agents whose preferred locations are the rows of `P : Fin n → Fin d → ℝ`,
measured under the `L_q` norm:
`socialCost q P f = ∑_{i=1}^n lqNorm q (p_i − f)`,
where `(p_i − f) j = P i j − f j`. -/
noncomputable def socialCost (q : ℝ) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) : ℝ :=
  ∑ i, lqNorm q (fun j => P i j - f j)

/-- The optimal social cost is the infimum over all facility locations. -/
noncomputable def optSocialCost (q : ℝ) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) : ℝ :=
  ⨅ f, socialCost q P f

/-- The social cost is non-negative whenever `1 ≤ q`. -/
lemma socialCost_nonneg {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) :
    0 ≤ socialCost q P f := by
  unfold socialCost
  exact Finset.sum_nonneg (fun i _ => lqNorm_nonneg hq _)

/-- With zero agents the social cost is `0` for every facility location
and every `q`. -/
lemma socialCost_empty_agents :
    ∀ (q : ℝ), ∀ (d : ℕ) (P : Fin 0 → Fin d → ℝ) (f : Fin d → ℝ),
      socialCost q P f = 0 := by
  intro q d P f
  unfold socialCost
  exact Fin.sum_univ_zero _

/-- The set of social costs (over all facility locations) is bounded below
by `0` whenever `1 ≤ q`. -/
lemma socialCost_bddBelow {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) :
    BddBelow (Set.range (socialCost q P)) := by
  refine ⟨0, ?_⟩
  rintro x ⟨f, rfl⟩
  exact socialCost_nonneg hq P f

/-- The optimal social cost is a lower bound for the social cost at every
facility location (under `1 ≤ q`, which gives `BddBelow`). -/
lemma optSocialCost_le_socialCost {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) :
    optSocialCost q P ≤ socialCost q P f := by
  unfold optSocialCost
  exact ciInf_le (socialCost_bddBelow hq P) f

/-- The optimal social cost is non-negative under `1 ≤ q`. -/
lemma optSocialCost_nonneg {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) :
    0 ≤ optSocialCost q P := by
  unfold optSocialCost
  exact le_ciInf (fun f => socialCost_nonneg hq P f)

end Workspace.Types.SocialCost

/-!
# Coordinate-wise median predicate

This file defines the predicate `IsCoordinateMedian` saying that a vector
`m : Fin d → ℝ` is a coordinate-wise median of an instance
`P : Fin n → Fin d → ℝ`, in the sense that for every coordinate `j`,
both `#{i : P i j < m j}` and `#{i : P i j > m j}` are at most `n / 2`
(natural-number integer division).

The existence theorem `exists_coordinateMedian` shows that every instance
admits a coordinate-wise median; we construct one by sorting each
coordinate and taking the `n / 2`-th order statistic.
-/

namespace Workspace.Types.CoordinateMedian

open Finset

/-- A vector `m : Fin d → ℝ` is a *coordinate-wise median* of the instance
`P : Fin n → Fin d → ℝ` if for every coordinate `j`, both the number of
indices `i` with `P i j < m j` and the number of indices with
`P i j > m j` are at most `n / 2` (natural-number integer division).

When `n` is even, this gives `n / 2` on each side; when `n` is odd, this
gives `⌊n/2⌋ = (n - 1) / 2` on each side. The predicate models arbitrary
tie-breaking: many `m` will satisfy it for typical instances. -/
def IsCoordinateMedian {n d : ℕ} (m : Fin d → ℝ) (P : Fin n → Fin d → ℝ) : Prop :=
  ∀ j : Fin d,
    (Finset.univ.filter (fun i : Fin n => P i j < m j)).card ≤ n / 2 ∧
    (Finset.univ.filter (fun i : Fin n => P i j > m j)).card ≤ n / 2

/-- Helper lemma: for a monotone function `g : Fin n → ℝ`, choosing the
`n / 2`-th order statistic gives both upper bounds. -/
private lemma monotone_median_bounds {n : ℕ} (g : Fin n → ℝ) (hg : Monotone g)
    (hn : 0 < n) :
    let k : Fin n := ⟨n / 2, Nat.div_lt_of_lt_mul (by
      have : n ≤ n * 2 := Nat.le_mul_of_pos_right _ (by decide)
      omega)⟩
    (Finset.univ.filter (fun i : Fin n => g i < g k)).card ≤ n / 2 ∧
    (Finset.univ.filter (fun i : Fin n => g i > g k)).card ≤ n / 2 := by
  intro k
  refine ⟨?_, ?_⟩
  · -- {i : g i < g k} ⊆ {i : i.val < n/2}
    have hsub : (Finset.univ.filter (fun i : Fin n => g i < g k)) ⊆
        (Finset.univ.filter (fun i : Fin n => i.val < n / 2)) := by
      intro i hi
      simp only [mem_filter, mem_univ, true_and] at hi ⊢
      by_contra hi'
      have hi'' : n / 2 ≤ i.val := Nat.le_of_not_lt hi'
      -- i.val ≥ n/2 = k.val, so by monotone g i ≥ g k, contradicting g i < g k
      have : k ≤ i := by
        change k.val ≤ i.val
        exact hi''
      have := hg this
      linarith
    refine le_trans (card_le_card hsub) ?_
    -- card of {i : i.val < n/2} is exactly min(n, n/2) = n/2 (since n/2 ≤ n)
    have : (Finset.univ.filter (fun i : Fin n => i.val < n / 2)).card = n / 2 := by
      rw [show (Finset.univ.filter (fun i : Fin n => i.val < n / 2)) =
        (Finset.range (n / 2)).attachFin (fun m hm => by
          simp at hm
          exact lt_of_lt_of_le hm (Nat.div_le_self n 2)) from ?_]
      · simp
      · ext i
        simp [Finset.mem_attachFin]
    omega
  · -- {i : g i > g k} ⊆ {i : i.val > n/2}, which has cardinality n - n/2 - 1 ≤ n/2
    have hsub : (Finset.univ.filter (fun i : Fin n => g i > g k)) ⊆
        (Finset.univ.filter (fun i : Fin n => i.val > n / 2)) := by
      intro i hi
      simp only [mem_filter, mem_univ, true_and] at hi ⊢
      by_contra hi'
      have hi'' : i.val ≤ n / 2 := Nat.le_of_not_lt hi'
      have : i ≤ k := by
        change i.val ≤ k.val
        exact hi''
      have := hg this
      linarith
    refine le_trans (card_le_card hsub) ?_
    -- card of {i : i.val > n/2} = n - (n/2 + 1)
    have hle : (Finset.univ.filter (fun i : Fin n => i.val ≤ n / 2)).card = n / 2 + 1 := by
      rw [show (Finset.univ.filter (fun i : Fin n => i.val ≤ n / 2)) =
        (Finset.range (n / 2 + 1)).attachFin (fun m hm => by
          simp at hm
          omega) from ?_]
      · simp
      · ext i
        simp [Finset.mem_attachFin]
    have hsum :
        (Finset.univ.filter (fun i : Fin n => i.val > n / 2)).card +
        (Finset.univ.filter (fun i : Fin n => i.val ≤ n / 2)).card = n := by
      rw [← card_union_of_disjoint, show
        (Finset.univ.filter (fun i : Fin n => i.val > n / 2)) ∪
        (Finset.univ.filter (fun i : Fin n => i.val ≤ n / 2)) = Finset.univ from ?_]
      · simp
      · ext i; simp; omega
      · rw [disjoint_filter]
        intros; omega
    omega

/-- Every instance `P : Fin n → Fin d → ℝ` admits a coordinate-wise
median. We construct one by sorting each coordinate independently and
taking the `n / 2`-th order statistic. -/
theorem exists_coordinateMedian (n d : ℕ) (P : Fin n → Fin d → ℝ) :
    ∃ m, IsCoordinateMedian m P := by
  classical
  by_cases hn : n = 0
  · -- vacuous: all filters over Fin 0 have cardinality 0
    refine ⟨fun _ => 0, ?_⟩
    intro j
    subst hn
    refine ⟨?_, ?_⟩ <;> simp
  -- n ≥ 1
  have hn' : 0 < n := Nat.pos_of_ne_zero hn
  -- For each coordinate j, define m j as the n/2-th value of the sorted j-th column.
  refine ⟨fun j => P (Tuple.sort (fun i => P i j) ⟨n / 2,
    Nat.div_lt_of_lt_mul (by
      have hh : n ≤ n * 2 := Nat.le_mul_of_pos_right _ (by decide)
      omega)⟩) j, ?_⟩
  intro j
  -- Let f i = P i j; let σ = Tuple.sort f. Then g := f ∘ σ is monotone.
  set f : Fin n → ℝ := fun i => P i j with hf
  set σ : Equiv.Perm (Fin n) := Tuple.sort f with hσ
  set g : Fin n → ℝ := f ∘ σ with hg_def
  have hg_mono : Monotone g := Tuple.monotone_sort f
  set k : Fin n := ⟨n / 2, Nat.div_lt_of_lt_mul (by
    have hh : n ≤ n * 2 := Nat.le_mul_of_pos_right _ (by decide)
    omega)⟩ with hk_def
  -- The chosen median is f (σ k) = g k
  have hm_eq : (fun j' => P (Tuple.sort (fun i => P i j') ⟨n / 2,
      Nat.div_lt_of_lt_mul (by
        have hh : n ≤ n * 2 := Nat.le_mul_of_pos_right _ (by decide)
        omega)⟩) j') j = g k := by
    simp [hg_def, hf, hσ, hk_def]
  rw [hm_eq]
  -- Bounds for g via monotone_median_bounds
  obtain ⟨hlt, hgt⟩ := monotone_median_bounds g hg_mono hn'
  -- Translate cardinality of {i : f i < g k} to {i : g i < g k} via the bijection σ
  refine ⟨?_, ?_⟩
  · -- card {i : P i j < g k} ≤ n / 2
    have heq : (Finset.univ.filter (fun i : Fin n => P i j < g k)).card =
        (Finset.univ.filter (fun i : Fin n => g i < g k)).card := by
      apply Finset.card_bij (fun i _ => σ.symm i)
      · intro i hi
        simp only [mem_filter, mem_univ, true_and] at hi ⊢
        show f (σ (σ.symm i)) < g k
        rw [σ.apply_symm_apply]
        exact hi
      · intros a _ b _ hab
        exact σ.symm.injective hab
      · intro i hi
        simp only [mem_filter, mem_univ, true_and] at hi
        refine ⟨σ i, ?_, ?_⟩
        · simp only [mem_filter, mem_univ, true_and]
          show f (σ i) < g k
          exact hi
        · simp
    rw [heq]
    exact hlt
  · -- card {i : P i j > g k} ≤ n / 2
    have heq : (Finset.univ.filter (fun i : Fin n => P i j > g k)).card =
        (Finset.univ.filter (fun i : Fin n => g i > g k)).card := by
      apply Finset.card_bij (fun i _ => σ.symm i)
      · intro i hi
        simp only [mem_filter, mem_univ, true_and] at hi ⊢
        show f (σ (σ.symm i)) > g k
        rw [σ.apply_symm_apply]
        exact hi
      · intros a _ b _ hab
        exact σ.symm.injective hab
      · intro i hi
        simp only [mem_filter, mem_univ, true_and] at hi
        refine ⟨σ i, ?_, ?_⟩
        · simp only [mem_filter, mem_univ, true_and]
          show f (σ i) > g k
          exact hi
        · simp
    rw [heq]
    exact hgt

/-- When `d = 0`, every vector `m : Fin 0 → ℝ` is a coordinate-wise median of
every placement `P : Fin n → Fin 0 → ℝ`. The predicate's universal quantifier
over `Fin 0` is vacuous. -/
theorem isCoordinateMedian_dim_zero {n : ℕ} (m : Fin 0 → ℝ) (P : Fin n → Fin 0 → ℝ) :
    IsCoordinateMedian m P := by
  intro j
  exact j.elim0

/-- When `n = 1`, `IsCoordinateMedian m P` is equivalent to `m = P 0`: with a
single placement, the median predicate forces `m` to coincide with that
placement on every coordinate. -/
theorem isCoordinateMedian_unique_singleton {d : ℕ} (m : Fin d → ℝ) (P : Fin 1 → Fin d → ℝ) :
    IsCoordinateMedian m P ↔ m = P 0 := by
  classical
  constructor
  · intro h
    funext j
    obtain ⟨hlt, hgt⟩ := h j
    -- 1 / 2 = 0, so both filtered sets must be empty.
    have hlt0 : (Finset.univ.filter (fun i : Fin 1 => P i j < m j)).card = 0 := by
      have : (1 : ℕ) / 2 = 0 := rfl
      omega
    have hgt0 : (Finset.univ.filter (fun i : Fin 1 => P i j > m j)).card = 0 := by
      have : (1 : ℕ) / 2 = 0 := rfl
      omega
    have hlt_empty : ¬ (P 0 j < m j) := by
      intro hcontr
      have : (0 : Fin 1) ∈ Finset.univ.filter (fun i : Fin 1 => P i j < m j) := by
        simp [hcontr]
      have : 0 < (Finset.univ.filter (fun i : Fin 1 => P i j < m j)).card :=
        Finset.card_pos.mpr ⟨0, this⟩
      omega
    have hgt_empty : ¬ (P 0 j > m j) := by
      intro hcontr
      have : (0 : Fin 1) ∈ Finset.univ.filter (fun i : Fin 1 => P i j > m j) := by
        simp [hcontr]
      have : 0 < (Finset.univ.filter (fun i : Fin 1 => P i j > m j)).card :=
        Finset.card_pos.mpr ⟨0, this⟩
      omega
    -- Trichotomy on ℝ: not <, not >, so equal. Statement is `m j = P 0 j`.
    have : P 0 j = m j := le_antisymm (not_lt.mp hgt_empty) (not_lt.mp hlt_empty)
    exact this.symm
  · intro hm
    intro j
    -- Under `m = P 0`, `m j = P 0 j`, so neither strict inequality can hold for
    -- the only index `0 : Fin 1`.
    have hmj : m j = P 0 j := by rw [hm]
    have hlt_empty :
        (Finset.univ.filter (fun i : Fin 1 => P i j < m j)) = ∅ := by
      ext i
      simp only [mem_filter, mem_univ, true_and, Finset.notMem_empty, iff_false]
      have hi0 : i = 0 := Subsingleton.elim _ _
      rw [hi0, hmj]
      exact lt_irrefl _
    have hgt_empty :
        (Finset.univ.filter (fun i : Fin 1 => P i j > m j)) = ∅ := by
      ext i
      simp only [mem_filter, mem_univ, true_and, Finset.notMem_empty, iff_false]
      have hi0 : i = 0 := Subsingleton.elim _ _
      rw [hi0, hmj]
      exact lt_irrefl _
    refine ⟨?_, ?_⟩
    · rw [hlt_empty]; simp
    · rw [hgt_empty]; simp

end Workspace.Types.CoordinateMedian

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.SocialCost
open Workspace.Types.CoordinateMedian

namespace Workspace.ConsistencyTheorem

/-- The closed-form consistency bound `CG(c)` for the `CMP(c)` mechanism at
`q = 2` (Euclidean L₂), from Theorem 3 of Gravin & Jia.

For `c < 1/2`:
`CG(c) = √(4·√(2c+3)·c + 6·√(2c+3) − 10c − 8) / (c + 1)`.

For `c ≥ 1/2`:
`CG(c) = √(2 / (c + 1))`.

(The `^{1/2}` in the paper is rendered with `Real.sqrt`.) -/
noncomputable def CG (c : ℝ) : ℝ :=
  if c < 1 / 2 then
    Real.sqrt (4 * Real.sqrt (2 * c + 3) * c + 6 * Real.sqrt (2 * c + 3) - 10 * c - 8) / (c + 1)
  else
    Real.sqrt (2 / (c + 1))

/-- The `CMP(c)`-augmented instance: the original `n` agent reports `P`
augmented with `k` copies of the prediction `pred`. Indices `< n` return the
corresponding original report `P i`; indices `≥ n` (the last `k`) return `pred`.

Modeling choice: the index split uses `Fin.addCases`, so for
`i : Fin (n + k)` the result is `P` on the `Fin n` summand and the constant
`pred` on the `Fin k` summand. This matches "append `k` copies of `pred`". -/
def augment {n d : ℕ} (P : Fin n → Fin d → ℝ) (pred : Fin d → ℝ) (k : ℕ) :
    Fin (n + k) → Fin d → ℝ :=
  Fin.addCases (fun i => P i) (fun _ => pred)

end Workspace.ConsistencyTheorem

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.SocialCost
open Workspace.Types.CoordinateMedian
open Workspace.ConsistencyTheorem

namespace Workspace.RobustnessTheorem

/-- The closed-form robustness bound `RG(c)` for the `CMP(c)` mechanism at
`q = 2` (Euclidean L₂), from Theorem 4 of Gravin & Jia.

`RG(c) = 1/λ₂ = √(−4·√(3−2c)·c + 6·√(3−2c) + 10c − 8) / (1 − c)`,  `c ∈ [0,1)`.

Unlike consistency's `CG(c)`, the robustness `RG(c)` has a **single branch**
across the whole interval `c ∈ [0,1)`: the interior root
`a₂' = (2−c−√(3−2c))/2 ≤ (1+c)/2` for every `c ∈ [0,1)`, so the boundary case
`a₂ = (1+c)/2` never binds (appendix.tex lines 310–311). There is NO `if c < 1/2`
split here, in contrast to the two-branch `CG`.

(The `^{1/2}` in the paper is rendered with `Real.sqrt`.) -/
noncomputable def RG (c : ℝ) : ℝ :=
  Real.sqrt (-4 * Real.sqrt (3 - 2 * c) * c + 6 * Real.sqrt (3 - 2 * c) + 10 * c - 8) / (1 - c)

end Workspace.RobustnessTheorem

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.SocialCost
open Workspace.Types.CoordinateMedian
open Workspace.ConsistencyTheorem
open Workspace.RobustnessTheorem

namespace Workspace.ProofLemmas.RGEvenAugmentReduction

private lemma socialCost_zero_agents {q : ℝ} (d : ℕ)
    (P : Fin 0 → Fin d → ℝ) (f : Fin d → ℝ) :
    socialCost q P f = 0 := by
  unfold socialCost
  exact Fin.sum_univ_zero _

private lemma optSocialCost_zero_agents {q : ℝ} (hq : 1 ≤ q) (d : ℕ)
    (P : Fin 0 → Fin d → ℝ) :
    optSocialCost q P = 0 := by
  apply le_antisymm
  · have := optSocialCost_le_socialCost hq P (fun _ => 0)
    rw [socialCost_zero_agents] at this
    exact this
  · exact optSocialCost_nonneg hq P

theorem RGEvenAugmentReduction
    (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1)
    (h_even : ∀ {n d : ℕ}, Even (n + ⌊c * (n : ℝ)⌋₊) →
      (⌊c * (n : ℝ)⌋₊ : ℝ) = c * (n : ℝ) → 1 ≤ d →
      ∀ (P : Fin n → Fin d → ℝ) (pred : Fin d → ℝ) (fstar : Fin d → ℝ),
        socialCost 2 P fstar = optSocialCost 2 P →
      ∀ (m : Fin d → ℝ),
        IsCoordinateMedian m (augment P pred (⌊c * (n : ℝ)⌋₊)) →
        (∀ j, fstar j ≠ m j) →
        (∀ j, pred j ≠ m j) →
        socialCost 2 P m ≤ RG c * optSocialCost 2 P) :
    ∀ {n d : ℕ}, (⌊c * (n : ℝ)⌋₊ : ℝ) = c * (n : ℝ) → 1 ≤ d →
    ∀ (P : Fin n → Fin d → ℝ) (pred : Fin d → ℝ) (fstar : Fin d → ℝ),
      socialCost 2 P fstar = optSocialCost 2 P →
    ∀ (m : Fin d → ℝ),
      IsCoordinateMedian m (augment P pred (⌊c * (n : ℝ)⌋₊)) →
      (∀ j, fstar j ≠ m j) →
      (∀ j, pred j ≠ m j) →
      socialCost 2 P m ≤ RG c * optSocialCost 2 P := by
  intro n d hcn hd P pred fstar hfstar m hm hgp hgppred
  classical
  -- Case n = 0: both sides are 0.
  by_cases hn0 : n = 0
  · subst hn0
    have h1 : socialCost 2 P m = 0 := socialCost_zero_agents d P m
    have h2 : optSocialCost 2 P = 0 := optSocialCost_zero_agents (by norm_num) d P
    rw [h1, h2, mul_zero]
  have hn_pos : 0 < n := Nat.pos_of_ne_zero hn0
  -- Abbreviation for ⌊cn⌋.
  set K : ℕ := ⌊c * (n : ℝ)⌋₊ with hK
  -- Case split on parity of n + K.
  by_cases heven : Even (n + K)
  · exact h_even heven hcn hd P pred fstar hfstar m hm hgp hgppred
  -- Odd case: duplicate P to 2n.
  -- Notation for the floor at 2n.
  have hcn2 : ⌊c * ((n + n : ℕ) : ℝ)⌋₊ = K + K := by
    have hcast : ((n + n : ℕ) : ℝ) = (n : ℝ) + (n : ℝ) := by push_cast; ring
    rw [hcast]
    have : c * ((n : ℝ) + (n : ℝ)) = ((K + K : ℕ) : ℝ) := by
      push_cast
      have : c * (n : ℝ) = (K : ℝ) := hcn.symm
      rw [show c * ((n : ℝ) + (n : ℝ)) = 2 * (c * (n : ℝ)) by ring, this]
      ring
    rw [this, Nat.floor_natCast]
  -- Build the duplicated instance P'.
  let e : Fin n ⊕ Fin n ≃ Fin (n + n) := finSumFinEquiv
  let P' : Fin (n + n) → Fin d → ℝ := fun i => Sum.elim P P (e.symm i)
  have hn2_even : Even (n + n + (K + K)) := ⟨n + K, by ring⟩
  have hcn2' : (⌊c * ((n + n : ℕ) : ℝ)⌋₊ : ℝ) = c * ((n + n : ℕ) : ℝ) := by
    rw [hcn2]
    push_cast
    have : c * (n : ℝ) = (K : ℝ) := hcn.symm
    rw [show c * ((n : ℝ) + (n : ℝ)) = 2 * (c * (n : ℝ)) by ring, this]
    ring
  -- socialCost doubling.
  have h_sc : ∀ f : Fin d → ℝ, socialCost 2 P' f = 2 * socialCost 2 P f := by
    intro f
    unfold socialCost
    set F : Fin n → ℝ := fun i => lqNorm 2 (fun j => P i j - f j) with hF
    have h1 : (∑ i : Fin (n + n), lqNorm 2 (fun j => P' i j - f j))
        = ∑ i : Fin n ⊕ Fin n, lqNorm 2 (fun j => Sum.elim P P i j - f j) := by
      rw [← Equiv.sum_comp e (fun i : Fin (n + n) =>
            lqNorm 2 (fun j => P' i j - f j))]
      apply Finset.sum_congr rfl
      intro i _
      simp [P', Equiv.symm_apply_apply]
    rw [h1]
    have h2 : ∀ i : Fin n ⊕ Fin n,
        lqNorm 2 (fun j => Sum.elim P P i j - f j) = Sum.elim F F i := by
      intro i
      cases i with
      | inl a => simp [F, Sum.elim_inl]
      | inr a => simp [F, Sum.elim_inr]
    rw [Finset.sum_congr rfl (fun i _ => h2 i)]
    rw [Fintype.sum_sumElim]
    ring
  -- Median preservation of the augmented instance (now augmenting with `pred`).
  have hm' : IsCoordinateMedian m (augment P' pred (⌊c * ((n + n : ℕ) : ℝ)⌋₊)) := by
    rw [hcn2]
    intro j
    -- For an addCases function, split filter cardinality into the P-block and the
    -- constant-pred block, then count both blocks doubled.
    have count_aug : ∀ (R : ℝ → ℝ → Prop)
        {nn kk : ℕ} (Q : Fin nn → Fin d → ℝ)
        [DecidablePred (fun i : Fin (nn + kk) =>
          R ((augment Q pred kk) i j) (m j))]
        [DecidablePred (fun i : Fin nn => R (Q i j) (m j))],
        (Finset.univ.filter (fun i : Fin (nn + kk) =>
            R ((augment Q pred kk) i j) (m j))).card =
          (Finset.univ.filter (fun i : Fin nn => R (Q i j) (m j))).card
            + (if R (pred j) (m j) then kk else 0) := by
      intro R nn kk Q _ _
      classical
      have hcard1 : (Finset.univ.filter (fun i : Fin (nn + kk) =>
            R ((augment Q pred kk) i j) (m j))).card =
          ∑ i : Fin (nn + kk),
            (if R ((augment Q pred kk) i j) (m j) then (1 : ℕ) else 0) := by
        rw [Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const,
            smul_eq_mul, mul_one]
      rw [hcard1]
      let e2 : Fin nn ⊕ Fin kk ≃ Fin (nn + kk) := finSumFinEquiv
      rw [← Equiv.sum_comp e2 (fun i : Fin (nn + kk) =>
            (if R ((augment Q pred kk) i j) (m j) then (1 : ℕ) else 0))]
      have hsplit : ∀ i : Fin nn ⊕ Fin kk,
          (if R ((augment Q pred kk) (e2 i) j) (m j) then (1 : ℕ) else 0) =
          Sum.elim
            (fun a : Fin nn => if R (Q a j) (m j) then (1 : ℕ) else 0)
            (fun _ : Fin kk => if R (pred j) (m j) then (1 : ℕ) else 0) i := by
        intro i
        cases i with
        | inl a =>
          have hrw : (augment Q pred kk) (e2 (Sum.inl a)) = Q a := by
            simp only [augment, e2, finSumFinEquiv_apply_left, Fin.addCases_left]
          simp only [Sum.elim_inl, hrw]
        | inr a =>
          have hrw : (augment Q pred kk) (e2 (Sum.inr a)) = pred := by
            simp only [augment, e2, finSumFinEquiv_apply_right, Fin.addCases_right]
          simp only [Sum.elim_inr, hrw]
      rw [Finset.sum_congr rfl (fun i _ => hsplit i)]
      rw [Fintype.sum_sumElim]
      congr 1
      · rw [Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const,
            smul_eq_mul, mul_one]
      · by_cases hR : R (pred j) (m j)
        · simp [hR]
        · simp [hR]
    -- Count on P-block for P' equals twice the count for P.
    have hPblock : ∀ (R : ℝ → ℝ → Prop)
        [DecidablePred (fun i : Fin (n + n) => R (P' i j) (m j))]
        [DecidablePred (fun i : Fin n => R (P i j) (m j))],
        (Finset.univ.filter (fun i : Fin (n + n) => R (P' i j) (m j))).card =
        2 * (Finset.univ.filter (fun i : Fin n => R (P i j) (m j))).card := by
      intro R _ _
      classical
      have hc1 : (Finset.univ.filter (fun i : Fin (n + n) => R (P' i j) (m j))).card =
          ∑ i : Fin (n + n), (if R (P' i j) (m j) then (1 : ℕ) else 0) := by
        rw [Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const,
            smul_eq_mul, mul_one]
      have hc2 : (Finset.univ.filter (fun i : Fin n => R (P i j) (m j))).card =
          ∑ i : Fin n, (if R (P i j) (m j) then (1 : ℕ) else 0) := by
        rw [Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const,
            smul_eq_mul, mul_one]
      rw [hc1, hc2]
      rw [← Equiv.sum_comp e (fun i : Fin (n + n) =>
            (if R (P' i j) (m j) then (1 : ℕ) else 0))]
      have hF : ∀ i : Fin n ⊕ Fin n,
          (if R (P' (e i) j) (m j) then (1 : ℕ) else 0) =
          Sum.elim
            (fun a : Fin n => if R (P a j) (m j) then (1 : ℕ) else 0)
            (fun a : Fin n => if R (P a j) (m j) then (1 : ℕ) else 0) i := by
        intro i
        cases i with
        | inl a =>
          show (if R (P' (e (Sum.inl a)) j) (m j) then (1 : ℕ) else 0) = _
          have hrw : P' (e (Sum.inl a)) = P a := by
            show Sum.elim P P (e.symm (e (Sum.inl a))) = P a
            rw [e.symm_apply_apply]; rfl
          simp [hrw]
        | inr a =>
          show (if R (P' (e (Sum.inr a)) j) (m j) then (1 : ℕ) else 0) = _
          have hrw : P' (e (Sum.inr a)) = P a := by
            show Sum.elim P P (e.symm (e (Sum.inr a))) = P a
            rw [e.symm_apply_apply]; rfl
          simp [hrw]
      rw [Finset.sum_congr rfl (fun i _ => hF i)]
      rw [Fintype.sum_sumElim]
      ring
    -- Now combine. Get original median bounds.
    obtain ⟨hlt, hgt⟩ := hm j
    -- Rewrite original bounds via count_aug on (P, K).
    have hlt_aug := count_aug (· < ·) P (nn := n) (kk := K)
    have hgt_aug := count_aug (· > ·) P (nn := n) (kk := K)
    -- And the new (P', K+K) counts.
    have hlt_aug' := count_aug (· < ·) P' (nn := n + n) (kk := K + K)
    have hgt_aug' := count_aug (· > ·) P' (nn := n + n) (kk := K + K)
    rw [hPblock (· < ·)] at hlt_aug'
    rw [hPblock (· > ·)] at hgt_aug'
    -- The augmented size is n + n + (K + K) = 2(n+K); half is n+K.
    have hsize : (n + n + (K + K)) / 2 = n + K := by omega
    refine ⟨?_, ?_⟩
    · rw [hlt_aug', hsize]
      rw [hlt_aug] at hlt
      by_cases hR : (pred j) < (m j)
      · simp only [hR, if_true] at hlt ⊢
        have hpar : (n + K) / 2 + (n + K) / 2 ≤ n + K := by omega
        omega
      · simp only [hR, if_false] at hlt ⊢
        have hpar : (n + K) / 2 + (n + K) / 2 ≤ n + K := by omega
        omega
    · rw [hgt_aug', hsize]
      rw [hgt_aug] at hgt
      by_cases hR : (pred j) > (m j)
      · simp only [hR, if_true] at hgt ⊢
        have hpar : (n + K) / 2 + (n + K) / 2 ≤ n + K := by omega
        omega
      · simp only [hR, if_false] at hgt ⊢
        have hpar : (n + K) / 2 + (n + K) / 2 ≤ n + K := by omega
        omega
  -- optSocialCost doubles exactly: optSocialCost 2 P' = 2 * optSocialCost 2 P.
  have h_opt_le : optSocialCost 2 P' ≤ 2 * optSocialCost 2 P := by
    have hhalf : optSocialCost 2 P' / 2 ≤ optSocialCost 2 P := by
      apply le_ciInf
      intro f
      have hle := optSocialCost_le_socialCost (show (1:ℝ) ≤ 2 by norm_num) P' f
      rw [h_sc f] at hle
      linarith
    linarith
  have h_opt_ge : 2 * optSocialCost 2 P ≤ optSocialCost 2 P' := by
    have : ∀ f, 2 * optSocialCost 2 P ≤ socialCost 2 P' f := by
      intro f
      rw [h_sc f]
      have := optSocialCost_le_socialCost (show (1:ℝ) ≤ 2 by norm_num) P f
      linarith
    unfold optSocialCost
    exact le_ciInf (fun f => this f)
  have h_opt_eq : optSocialCost 2 P' = 2 * optSocialCost 2 P := le_antisymm h_opt_le h_opt_ge
  have h_opt : optSocialCost 2 P' ≤ 2 * optSocialCost 2 P := h_opt_le
  -- fstar is optimal for P' as well: socialCost 2 P' fstar = optSocialCost 2 P'.
  have hfstar' : socialCost 2 P' fstar = optSocialCost 2 P' := by
    rw [h_sc fstar, hfstar, h_opt_eq]
  -- Apply h_even to P'.
  have h_main := h_even (by rw [hcn2]; exact hn2_even) hcn2' hd P' pred fstar hfstar' m hm' hgp hgppred
  -- Convert back.
  have h_lhs : socialCost 2 P' m = 2 * socialCost 2 P m := h_sc m
  have hRG_nn : 0 ≤ RG c := by
    unfold RG
    apply div_nonneg (Real.sqrt_nonneg _)
    linarith
  rw [h_lhs] at h_main
  have h_chain : 2 * socialCost 2 P m ≤ RG c * (2 * optSocialCost 2 P) := by
    calc 2 * socialCost 2 P m
        ≤ RG c * optSocialCost 2 P' := h_main
      _ ≤ RG c * (2 * optSocialCost 2 P) := mul_le_mul_of_nonneg_left h_opt hRG_nn
  have h2 : RG c * (2 * optSocialCost 2 P) = 2 * (RG c * optSocialCost 2 P) := by ring
  rw [h2] at h_chain
  linarith

end Workspace.ProofLemmas.RGEvenAugmentReduction

namespace Workspace.ProofLemmas.LambdaDeltaIdentity

open Real

noncomputable def delta_of_lambda (q lambda : ℝ) : ℝ :=
  (lambda ^ (-(q / (q - 1))) - 1) ^ ((q - 1) / q)

end Workspace.ProofLemmas.LambdaDeltaIdentity

open Workspace.ProofLemmas.LambdaDeltaIdentity

theorem LambdaDeltaIdentity
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam_pos : 0 < lambda) (hlam_le : lambda ≤ 1) :
    lambda * delta_of_lambda q lambda
      = (1 - lambda ^ (q / (q - 1))) ^ ((q - 1) / q) := by
  unfold delta_of_lambda
  -- Set up positivity facts
  set r : ℝ := q / (q - 1) with hr_def
  have hq_sub_pos : 0 < q - 1 := by linarith
  have hq_sub_ne : q - 1 ≠ 0 := ne_of_gt hq_sub_pos
  have hq_pos : 0 < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hr_pos : 0 < r := by
    simp [hr_def]; exact div_pos hq_pos hq_sub_pos
  have hr_ne : r ≠ 0 := ne_of_gt hr_pos
  have hlam_nn : (0 : ℝ) ≤ lambda := le_of_lt hlam_pos
  have hlam_ne : lambda ≠ 0 := ne_of_gt hlam_pos
  -- lambda^r > 0
  have hlam_r_pos : 0 < lambda ^ r := Real.rpow_pos_of_pos hlam_pos _
  have hlam_r_nn : 0 ≤ lambda ^ r := le_of_lt hlam_r_pos
  have hlam_r_ne : lambda ^ r ≠ 0 := ne_of_gt hlam_r_pos
  -- Rewrite lambda^(-r) - 1 = (1 - lambda^r) / lambda^r
  have h_neg : lambda ^ (-r) = (lambda ^ r)⁻¹ := Real.rpow_neg hlam_nn r
  -- Compute 1 - lambda^r ≥ 0 since lambda ≤ 1 and r > 0
  have h_lam_r_le_one : lambda ^ r ≤ 1 := by
    have : lambda ^ r ≤ lambda ^ (0 : ℝ) := by
      apply Real.rpow_le_rpow_of_exponent_ge hlam_pos hlam_le
      linarith
    simpa using this
  have h_one_sub_nn : 0 ≤ 1 - lambda ^ r := by linarith
  -- Substitute lambda^(-r) = (lambda^r)⁻¹
  rw [h_neg]
  -- Now: lambda * ((lambda^r)⁻¹ - 1)^((q-1)/q) = (1 - lambda^r)^((q-1)/q)
  have h_step1 : (lambda ^ r)⁻¹ - 1 = (1 - lambda ^ r) / (lambda ^ r) := by
    field_simp
  rw [h_step1]
  -- Goal: lambda * ((1 - lambda^r) / lambda^r)^((q-1)/q) = (1 - lambda^r)^((q-1)/q)
  rw [Real.div_rpow h_one_sub_nn hlam_r_nn]
  -- Goal: lambda * ((1 - lambda^r)^((q-1)/q) / (lambda^r)^((q-1)/q)) = ...
  -- We want to show (lambda^r)^((q-1)/q) = lambda
  have h_inner : (lambda ^ r) ^ ((q - 1) / q) = lambda := by
    rw [← Real.rpow_mul hlam_nn]
    have h_prod : r * ((q - 1) / q) = 1 := by
      simp [hr_def]
      field_simp
    rw [h_prod, Real.rpow_one]
  rw [h_inner]
  -- Goal: lambda * ((1 - lambda^r)^((q-1)/q) / lambda) = (1 - lambda^r)^((q-1)/q)
  field_simp

namespace Workspace.ProofLemmas.HSecondDerivative

noncomputable def h_q (q lambda delta x : ℝ) : ℝ :=
  lambda * (delta * (1 - x) ^ ((1 : ℝ) / q) - x ^ ((1 : ℝ) / q))

end Workspace.ProofLemmas.HSecondDerivative

open Workspace.ProofLemmas.HSecondDerivative in
theorem HSecondDerivative
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam : 0 < lambda)
    (delta : ℝ) (hdelta : 1 ≤ delta) (x : ℝ) (hx0 : 0 < x) (hx1 : x < 1) :
    iteratedDeriv 2 (fun x => h_q q lambda delta x) x =
      (lambda * (q - 1) / q^2) *
        (x ^ ((1 - 2*q) / q) - delta * (1 - x) ^ ((1 - 2*q) / q)) := by
  -- q ≠ 0
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  -- First derivative formula at any point y with 0 < y < 1
  have firstDeriv : ∀ y, 0 < y → y < 1 →
      HasDerivAt (fun z => h_q q lambda delta z)
        (lambda * (-(delta * ((1/q) * (1 - y) ^ ((1:ℝ)/q - 1))) - (1/q) * y ^ ((1:ℝ)/q - 1))) y := by
    intro y hy0 hy1
    have hy_ne : y ≠ 0 := ne_of_gt hy0
    have h1my_ne : (1 - y) ≠ 0 := by linarith
    -- HasDerivAt for y ↦ y^(1/q)
    have h_y_pow : HasDerivAt (fun z : ℝ => z ^ ((1:ℝ)/q)) ((1/q) * y ^ ((1:ℝ)/q - 1)) y := by
      have h := (hasDerivAt_id y).rpow_const (p := (1:ℝ)/q) (Or.inl hy_ne)
      simpa using h
    -- HasDerivAt for y ↦ (1 - y)^(1/q)
    have h_oneminus_y : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) y := by
      simpa using (hasDerivAt_id y).const_sub 1
    have h_1my_pow : HasDerivAt (fun z : ℝ => (1 - z) ^ ((1:ℝ)/q))
        (-1 * (1/q) * (1 - y) ^ ((1:ℝ)/q - 1)) y := by
      have h := h_oneminus_y.rpow_const (p := (1:ℝ)/q) (Or.inl h1my_ne)
      convert h using 1
    -- HasDerivAt for delta * (1 - y)^(1/q)
    have h_d_1my_pow : HasDerivAt (fun z : ℝ => delta * (1 - z) ^ ((1:ℝ)/q))
        (delta * (-1 * (1/q) * (1 - y) ^ ((1:ℝ)/q - 1))) y :=
      h_1my_pow.const_mul delta
    -- HasDerivAt for (delta * (1 - y)^(1/q) - y^(1/q))
    have h_diff : HasDerivAt (fun z : ℝ => delta * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q))
        (delta * (-1 * (1/q) * (1 - y) ^ ((1:ℝ)/q - 1)) - (1/q) * y ^ ((1:ℝ)/q - 1)) y :=
      h_d_1my_pow.sub h_y_pow
    -- Multiply by lambda
    have h_full : HasDerivAt (fun z : ℝ => lambda * (delta * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q)))
        (lambda * (delta * (-1 * (1/q) * (1 - y) ^ ((1:ℝ)/q - 1)) - (1/q) * y ^ ((1:ℝ)/q - 1))) y :=
      h_diff.const_mul lambda
    have h_eq : (fun z => h_q q lambda delta z) =
        (fun z : ℝ => lambda * (delta * (1 - z) ^ ((1:ℝ)/q) - z ^ ((1:ℝ)/q))) := by
      funext z; rfl
    rw [h_eq]
    convert h_full using 1
    ring
  -- The first derivative function (in a neighborhood of x):
  let f' : ℝ → ℝ := fun y =>
    lambda * (-(delta * ((1/q) * (1 - y) ^ ((1:ℝ)/q - 1))) - (1/q) * y ^ ((1:ℝ)/q - 1))
  -- Equivalent simpler form for differentiation
  let g' : ℝ → ℝ := fun y =>
    -(lambda * (1/q)) * (delta * (1 - y) ^ ((1:ℝ)/q - 1) + y ^ ((1:ℝ)/q - 1))
  have hf'_eq_g' : f' = g' := by
    funext y; simp only [f', g']; ring
  -- deriv equals f' on a neighborhood of x (in fact, on (0,1))
  have hderiv_on_nbhd : ∀ᶠ y in nhds x, deriv (fun z => h_q q lambda delta z) y = f' y := by
    have h_open : IsOpen (Set.Ioo (0:ℝ) 1) := isOpen_Ioo
    have hx_mem : x ∈ Set.Ioo (0:ℝ) 1 := ⟨hx0, hx1⟩
    filter_upwards [h_open.mem_nhds hx_mem] with y hy
    exact (firstDeriv y hy.1 hy.2).deriv
  -- Now compute the derivative of f' at x using HasDerivAt
  -- Use the fact that f' = g' to do differentiation on g'
  have hx_ne : x ≠ 0 := ne_of_gt hx0
  have h1mx_ne : (1 - x) ≠ 0 := by linarith
  -- HasDerivAt for y ↦ y^((1/q) - 1)
  have h_y_pow' : HasDerivAt (fun z : ℝ => z ^ ((1:ℝ)/q - 1))
      (((1:ℝ)/q - 1) * x ^ ((1:ℝ)/q - 1 - 1)) x := by
    have h := (hasDerivAt_id x).rpow_const (p := (1:ℝ)/q - 1) (Or.inl hx_ne)
    simpa using h
  -- HasDerivAt for y ↦ (1 - y)^((1/q) - 1)
  have h_oneminus_x : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) x := by
    simpa using (hasDerivAt_id x).const_sub 1
  have h_1mx_pow' : HasDerivAt (fun z : ℝ => (1 - z) ^ ((1:ℝ)/q - 1))
      (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1:ℝ)/q - 1 - 1)) x := by
    have h := h_oneminus_x.rpow_const (p := (1:ℝ)/q - 1) (Or.inl h1mx_ne)
    convert h using 1
  -- delta * (1 - y) ^ ((1/q) - 1)
  have h_d_1mx_pow' : HasDerivAt (fun z : ℝ => delta * (1 - z) ^ ((1:ℝ)/q - 1))
      (delta * (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1:ℝ)/q - 1 - 1))) x :=
    h_1mx_pow'.const_mul delta
  -- Sum: delta * (1 - y) ^ ((1/q) - 1) + y ^ ((1/q) - 1)
  have h_sum : HasDerivAt
      (fun z : ℝ => delta * (1 - z) ^ ((1:ℝ)/q - 1) + z ^ ((1:ℝ)/q - 1))
      (delta * (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1:ℝ)/q - 1 - 1))
        + ((1:ℝ)/q - 1) * x ^ ((1:ℝ)/q - 1 - 1)) x :=
    h_d_1mx_pow'.add h_y_pow'
  -- Multiply by -(lambda/q)
  have h_g' : HasDerivAt g'
      (-(lambda * (1/q)) *
        (delta * (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1:ℝ)/q - 1 - 1))
          + ((1:ℝ)/q - 1) * x ^ ((1:ℝ)/q - 1 - 1))) x :=
    h_sum.const_mul _
  -- Iterated deriv
  rw [show (2 : ℕ) = 1 + 1 from rfl, iteratedDeriv_succ, iteratedDeriv_one]
  -- Goal: deriv (deriv (fun x => h_q q lambda delta x)) x = ...
  -- Replace deriv of inner function via EventuallyEq
  rw [Filter.EventuallyEq.deriv_eq hderiv_on_nbhd]
  rw [hf'_eq_g']
  rw [h_g'.deriv]
  -- Now we need to show the algebraic identity
  -- Simplify the exponents: (1/q) - 1 = (1 - q)/q  and  (1/q) - 1 - 1 = (1 - 2q)/q
  have hexp1 : (1:ℝ)/q - 1 - 1 = (1 - 2*q) / q := by
    field_simp
    ring
  have hexp2 : (1:ℝ)/q - 1 = (1 - q) / q := by
    field_simp
  -- Substitute exponents
  rw [hexp1]
  -- coefficient simplification
  -- LHS = -(lambda * (1/q)) * (delta * (-1 * ((1/q) - 1) * (1-x)^((1-2q)/q)) + ((1/q) - 1) * x^((1-2q)/q))
  -- We want: (lambda * (q - 1) / q^2) * (x^((1-2q)/q) - delta * (1-x)^((1-2q)/q))
  have hcoef : -(lambda * (1/q)) * ((1:ℝ)/q - 1) = lambda * (q - 1) / q^2 := by
    field_simp
    ring
  -- Rewrite goal
  have lhs_simp :
      -(lambda * (1/q)) *
        (delta * (-1 * ((1:ℝ)/q - 1) * (1 - x) ^ ((1 - 2*q)/q))
          + ((1:ℝ)/q - 1) * x ^ ((1 - 2*q)/q))
      = (-(lambda * (1/q)) * ((1:ℝ)/q - 1)) *
        (x ^ ((1 - 2*q)/q) - delta * (1 - x) ^ ((1 - 2*q)/q)) := by
    ring
  rw [lhs_simp, hcoef]

namespace Workspace.ProofLemmas.FqSignAt0Pos

noncomputable def F_q (q a : ℝ) : ℝ :=
  2 * (1 - 1/q) * a + (1/q) * a ^ ((1 - q) / q) - 2 + 1/q

end Workspace.ProofLemmas.FqSignAt0Pos

open Workspace.ProofLemmas.FqSignAt0Pos

theorem FqSignAt0Pos (q : ℝ) (hq : 1 < q) :
    Filter.Tendsto (fun a => F_q q a) (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop := by
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_inv_pos : (0 : ℝ) < 1 / q := by positivity
  have hexp_neg : (1 - q) / q < 0 := by
    apply div_neg_of_neg_of_pos
    · linarith
    · exact hq_pos
  -- a^((1-q)/q) → +∞ as a → 0+
  have h_rpow : Filter.Tendsto (fun a : ℝ => a ^ ((1 - q) / q))
      (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    tendsto_rpow_neg_nhdsGT_zero hexp_neg
  -- (1/q) * a^((1-q)/q) → +∞
  have h_rpow_scaled : Filter.Tendsto (fun a : ℝ => (1/q) * a ^ ((1 - q) / q))
      (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    h_rpow.const_mul_atTop' hq_inv_pos
  -- The remaining terms tend to a finite limit
  -- 2*(1 - 1/q)*a + (-2 + 1/q) → -2 + 1/q as a → 0
  have h_nhds_zero : Filter.Tendsto (fun a : ℝ => a) (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
    exact (continuous_id.tendsto 0).mono_left nhdsWithin_le_nhds
  have h_lin : Filter.Tendsto (fun a : ℝ => 2 * (1 - 1/q) * a)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds (2 * (1 - 1/q) * 0)) :=
    h_nhds_zero.const_mul _
  have h_lin0 : Filter.Tendsto (fun a : ℝ => 2 * (1 - 1/q) * a)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
    have : 2 * (1 - 1/q) * (0 : ℝ) = 0 := by ring
    rw [this] at h_lin
    exact h_lin
  have h_other : Filter.Tendsto (fun a : ℝ => 2 * (1 - 1/q) * a + (-2 + 1/q))
      (nhdsWithin 0 (Set.Ioi 0)) (nhds (0 + (-2 + 1/q))) :=
    h_lin0.add tendsto_const_nhds
  -- Now combine: ((1/q) * a^((1-q)/q)) + (2*(1-1/q)*a + (-2 + 1/q)) → +∞
  have h_sum : Filter.Tendsto
      (fun a : ℝ => (1/q) * a ^ ((1 - q) / q) + (2 * (1 - 1/q) * a + (-2 + 1/q)))
      (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    h_rpow_scaled.atTop_add h_other
  -- Show F_q q a equals our sum
  have heq : (fun a : ℝ => F_q q a) =
      fun a : ℝ => (1/q) * a ^ ((1 - q) / q) + (2 * (1 - 1/q) * a + (-2 + 1/q)) := by
    funext a
    simp only [F_q]
    ring
  rw [heq]
  exact h_sum

open Workspace.ProofLemmas.FqSignAt0Pos

theorem FqStrictConvex (q : ℝ) (hq : 1 < q) :
    StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) := by
  set p : ℝ := (1 - q) / q with hp_def
  have hq_pos : 0 < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_inv_pos : 0 < 1 / q := by positivity
  have hp_neg : p < 0 := by
    have h1 : 1 - q < 0 := by linarith
    exact div_neg_of_neg_of_pos h1 hq_pos
  have hp_minus_one_neg : p - 1 < 0 := by linarith
  have hpp1_pos : 0 < p * (p - 1) := mul_pos_of_neg_of_neg hp_neg hp_minus_one_neg
  -- Define helper: linear coefficient.
  set c1 : ℝ := 2 * (1 - 1 / q) with hc1_def
  set c2 : ℝ := 1 / q with hc2_def
  set c3 : ℝ := -2 + 1 / q with hc3_def
  -- Rewrite F_q q a = c1 * a + c2 * a^p + c3 (for any a).
  have hFq_eq : ∀ a : ℝ, F_q q a = c1 * a + c2 * a ^ p + c3 := by
    intro a
    simp [F_q, c1, c2, c3, p]
    ring
  -- Continuity on Ioi 0.
  have hCont : ContinuousOn (fun a => F_q q a) (Set.Ioi (0 : ℝ)) := by
    refine ContinuousOn.congr ?_ (fun a _ => hFq_eq a)
    refine ((continuousOn_const.mul continuousOn_id).add ?_).add continuousOn_const
    refine continuousOn_const.mul ?_
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    exact (Real.continuousAt_rpow_const a p (Or.inl ha_ne)).continuousWithinAt
  -- First derivative on Ioi 0: F_q' a = c1 + c2 * p * a^(p-1).
  have hFq_deriv : ∀ a ∈ Set.Ioi (0 : ℝ),
      HasDerivAt (fun a => F_q q a) (c1 + c2 * (p * a ^ (p - 1))) a := by
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    have hd_lin : HasDerivAt (fun y : ℝ => c1 * y) c1 a := by
      simpa using (hasDerivAt_id a).const_mul c1
    have hd_rpow : HasDerivAt (fun y : ℝ => y ^ p) (p * a ^ (p - 1)) a :=
      Real.hasDerivAt_rpow_const (Or.inl ha_ne)
    have hd_smul : HasDerivAt (fun y : ℝ => c2 * y ^ p) (c2 * (p * a ^ (p - 1))) a :=
      hd_rpow.const_mul c2
    have hd_sum : HasDerivAt (fun y : ℝ => c1 * y + c2 * y ^ p)
        (c1 + c2 * (p * a ^ (p - 1))) a := hd_lin.add hd_smul
    have hd_const : HasDerivAt (fun y : ℝ => c1 * y + c2 * y ^ p + c3)
        (c1 + c2 * (p * a ^ (p - 1))) a := hd_sum.add_const c3
    -- congr to F_q
    have hcongr : (fun y : ℝ => F_q q y) = (fun y => c1 * y + c2 * y ^ p + c3) := by
      funext y
      exact hFq_eq y
    rw [hcongr]
    exact hd_const
  -- Now apply strictConvexOn_of_deriv2_pos.
  apply strictConvexOn_of_deriv2_pos (convex_Ioi 0) hCont
  intro a ha
  rw [interior_Ioi] at ha
  have ha_pos : 0 < a := ha
  have ha_ne : a ≠ 0 := ne_of_gt ha_pos
  -- Show deriv (deriv F_q) a > 0.
  -- Step 1: deriv F_q is eventually equal to a ↦ c1 + c2 * (p * a^(p-1)) on Ioi 0.
  have hIoi_open : IsOpen (Set.Ioi (0 : ℝ)) := isOpen_Ioi
  have hnhds : Set.Ioi (0 : ℝ) ∈ nhds a := hIoi_open.mem_nhds ha_pos
  -- deriv F_q =ᶠ[𝓝 a] fun y => c1 + c2 * (p * y^(p-1))
  have hderiv_eq : deriv (fun a => F_q q a)
      =ᶠ[nhds a] (fun y => c1 + c2 * (p * y ^ (p - 1))) := by
    filter_upwards [hnhds] with y hy
    exact (hFq_deriv y hy).deriv
  -- Therefore deriv (deriv F_q) a = deriv (fun y => c1 + c2 * (p * y^(p-1))) a
  have hd2_eq : deriv (deriv (fun a => F_q q a)) a =
      deriv (fun y => c1 + c2 * (p * y ^ (p - 1))) a :=
    hderiv_eq.deriv_eq
  show 0 < deriv^[2] (fun a => F_q q a) a
  simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
  rw [hd2_eq]
  -- Now compute deriv (fun y => c1 + c2 * (p * y^(p-1))) a.
  have hd_inner : HasDerivAt (fun y : ℝ => y ^ (p - 1))
      ((p - 1) * a ^ (p - 1 - 1)) a :=
    Real.hasDerivAt_rpow_const (Or.inl ha_ne)
  have hd_mul1 : HasDerivAt (fun y : ℝ => p * y ^ (p - 1))
      (p * ((p - 1) * a ^ (p - 1 - 1))) a := hd_inner.const_mul p
  have hd_mul2 : HasDerivAt (fun y : ℝ => c2 * (p * y ^ (p - 1)))
      (c2 * (p * ((p - 1) * a ^ (p - 1 - 1)))) a := hd_mul1.const_mul c2
  have hd_total : HasDerivAt (fun y : ℝ => c1 + c2 * (p * y ^ (p - 1)))
      (c2 * (p * ((p - 1) * a ^ (p - 1 - 1)))) a := hd_mul2.const_add c1
  rw [hd_total.deriv]
  -- c2 * (p * ((p-1) * a^(p-2))) > 0
  have ha_rpow_pos : 0 < a ^ (p - 1 - 1) := Real.rpow_pos_of_pos ha_pos _
  have : 0 < c2 * (p * ((p - 1) * a ^ (p - 1 - 1))) := by
    apply mul_pos hq_inv_pos
    rw [show p * ((p - 1) * a ^ (p - 1 - 1)) = (p * (p - 1)) * a ^ (p - 1 - 1) by ring]
    exact mul_pos hpp1_pos ha_rpow_pos
  exact this

open Workspace.ProofLemmas.FqSignAt0Pos

theorem FqDerivMonotone (q : ℝ) (hq : 1 < q) :
    StrictMonoOn (deriv (fun a => F_q q a)) (Set.Ioi (0 : ℝ)) ∧
      Filter.Tendsto (deriv (fun a => F_q q a)) (nhdsWithin 0 (Set.Ioi 0)) Filter.atBot ∧
      Filter.Tendsto (deriv (fun a => F_q q a)) Filter.atTop (nhds (2 * (1 - 1/q))) := by
  set p : ℝ := (1 - q) / q with hp_def
  have hq_pos : 0 < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_inv_pos : 0 < 1 / q := by positivity
  have hp_neg : p < 0 := by
    have h1 : 1 - q < 0 := by linarith
    exact div_neg_of_neg_of_pos h1 hq_pos
  have hp_minus_one_neg : p - 1 < 0 := by linarith
  set c1 : ℝ := 2 * (1 - 1 / q) with hc1_def
  set c2 : ℝ := 1 / q with hc2_def
  set c3 : ℝ := -2 + 1 / q with hc3_def
  -- Rewrite F_q q a = c1 * a + c2 * a^p + c3.
  have hFq_eq : ∀ a : ℝ, F_q q a = c1 * a + c2 * a ^ p + c3 := by
    intro a
    simp [F_q, c1, c2, c3, p]
    ring
  -- Pointwise derivative on Ioi 0.
  have hFq_deriv : ∀ a ∈ Set.Ioi (0 : ℝ),
      HasDerivAt (fun a => F_q q a) (c1 + c2 * (p * a ^ (p - 1))) a := by
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    have hd_lin : HasDerivAt (fun y : ℝ => c1 * y) c1 a := by
      simpa using (hasDerivAt_id a).const_mul c1
    have hd_rpow : HasDerivAt (fun y : ℝ => y ^ p) (p * a ^ (p - 1)) a :=
      Real.hasDerivAt_rpow_const (Or.inl ha_ne)
    have hd_smul : HasDerivAt (fun y : ℝ => c2 * y ^ p) (c2 * (p * a ^ (p - 1))) a :=
      hd_rpow.const_mul c2
    have hd_sum : HasDerivAt (fun y : ℝ => c1 * y + c2 * y ^ p)
        (c1 + c2 * (p * a ^ (p - 1))) a := hd_lin.add hd_smul
    have hd_const : HasDerivAt (fun y : ℝ => c1 * y + c2 * y ^ p + c3)
        (c1 + c2 * (p * a ^ (p - 1))) a := hd_sum.add_const c3
    have hcongr : (fun y : ℝ => F_q q y) = (fun y => c1 * y + c2 * y ^ p + c3) := by
      funext y
      exact hFq_eq y
    rw [hcongr]
    exact hd_const
  -- DifferentiableAt for each a ∈ Ioi 0.
  have hDiff : ∀ a ∈ Set.Ioi (0 : ℝ), DifferentiableAt ℝ (fun a => F_q q a) a := by
    intro a ha
    exact (hFq_deriv a ha).differentiableAt
  -- The derivative formula: deriv F_q a = c1 + c2 * (p * a^(p-1)) for a ∈ Ioi 0.
  have hDerivEq : ∀ a ∈ Set.Ioi (0 : ℝ),
      deriv (fun a => F_q q a) a = c1 + c2 * (p * a ^ (p - 1)) := by
    intro a ha
    exact (hFq_deriv a ha).deriv
  refine ⟨?_, ?_, ?_⟩
  · -- StrictMonoOn (deriv F_q) (Ioi 0): use FqStrictConvex.
    have hConv : StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) :=
      FqStrictConvex q hq
    exact hConv.strictMonoOn_deriv hDiff
  · -- Tendsto deriv F_q at 0+ to atBot.
    -- deriv F_q =ᶠ[nhdsWithin 0 (Ioi 0)] (fun a => c1 + (c2 * p) * a^(p-1))
    have hK_neg : c2 * p < 0 := by
      have : c2 > 0 := hq_inv_pos
      exact mul_neg_of_pos_of_neg this hp_neg
    -- Eventually equal on nhdsWithin 0 (Ioi 0).
    have hEv : (fun a => deriv (fun a => F_q q a) a) =ᶠ[nhdsWithin (0:ℝ) (Set.Ioi 0)]
        (fun a => c1 + (c2 * p) * a ^ (p - 1)) := by
      filter_upwards [self_mem_nhdsWithin] with a ha
      have ha_pos : (0:ℝ) < a := ha
      rw [hDerivEq a ha_pos]
      ring
    -- (fun a => a^(p-1)) tends to atTop on nhdsWithin 0 (Ioi 0).
    have hTendsRpow : Filter.Tendsto (fun a : ℝ => a ^ (p - 1))
        (nhdsWithin (0:ℝ) (Set.Ioi 0)) Filter.atTop :=
      tendsto_rpow_neg_nhdsGT_zero hp_minus_one_neg
    -- (fun a => a^(p-1) * (c2 * p)) tends to atBot.
    have hTendsMul : Filter.Tendsto (fun a : ℝ => a ^ (p - 1) * (c2 * p))
        (nhdsWithin (0:ℝ) (Set.Ioi 0)) Filter.atBot :=
      hTendsRpow.atTop_mul_const_of_neg hK_neg
    -- Convert (fun a => a^(p-1) * (c2 * p)) ↦ (fun a => (c2 * p) * a^(p-1)).
    have hTendsMul' : Filter.Tendsto (fun a : ℝ => (c2 * p) * a ^ (p - 1))
        (nhdsWithin (0:ℝ) (Set.Ioi 0)) Filter.atBot := by
      convert hTendsMul using 1
      funext a
      ring
    -- Add c1 on the left → atBot.
    have hTendsAdd : Filter.Tendsto (fun a : ℝ => c1 + (c2 * p) * a ^ (p - 1))
        (nhdsWithin (0:ℝ) (Set.Ioi 0)) Filter.atBot :=
      Filter.tendsto_atBot_add_const_left _ c1 hTendsMul'
    -- Use EventuallyEq.
    exact hTendsAdd.congr' hEv.symm
  · -- Tendsto deriv F_q at atTop to nhds (2 * (1 - 1/q)) = nhds c1.
    have hEv : (fun a => deriv (fun a => F_q q a) a) =ᶠ[(Filter.atTop : Filter ℝ)]
        (fun a => c1 + (c2 * p) * a ^ (p - 1)) := by
      filter_upwards [Filter.eventually_gt_atTop (0:ℝ)] with a ha_pos
      rw [hDerivEq a ha_pos]
      ring
    -- (fun a => a^(p-1)) → 0 at atTop.
    have hTendsRpow : Filter.Tendsto (fun a : ℝ => a ^ (p - 1))
        Filter.atTop (nhds 0) := by
      have : Filter.Tendsto (fun a : ℝ => a ^ (-(1 - p))) Filter.atTop (nhds 0) :=
        tendsto_rpow_neg_atTop (by linarith)
      convert this using 1
      funext a
      congr 1
      ring
    -- (c2 * p) * a^(p-1) → 0.
    have hTendsConstMul : Filter.Tendsto (fun a : ℝ => (c2 * p) * a ^ (p - 1))
        Filter.atTop (nhds ((c2 * p) * 0)) :=
      hTendsRpow.const_mul (c2 * p)
    have hTendsConstMul0 : Filter.Tendsto (fun a : ℝ => (c2 * p) * a ^ (p - 1))
        Filter.atTop (nhds 0) := by
      simpa using hTendsConstMul
    -- c1 + (c2 * p) * a^(p-1) → c1 + 0 = c1.
    have hTendsAdd : Filter.Tendsto (fun a : ℝ => c1 + (c2 * p) * a ^ (p - 1))
        Filter.atTop (nhds (c1 + 0)) :=
      hTendsConstMul0.const_add c1
    have hTendsAdd' : Filter.Tendsto (fun a : ℝ => c1 + (c2 * p) * a ^ (p - 1))
        Filter.atTop (nhds c1) := by simpa using hTendsAdd
    -- The goal target is `nhds (2 * (1 - 1/q))` = `nhds c1` (set substituted).
    exact hTendsAdd'.congr' hEv.symm

open Workspace.ProofLemmas.FqSignAt0Pos
open Classical

namespace Workspace.ProofLemmas.FqHasUniqueInteriorZero

/-- The defining property: a is in the open interval (0, 1) and F_q q a = 0. -/
private def IsAStar (q a : ℝ) : Prop := 0 < a ∧ a < 1 ∧ F_q q a = 0

/-- The unique interior zero of F_q in (0, 1), defined for q > 1 by Classical.choose
    of the existence statement. For q ≤ 1, defined as 0 by default (irrelevant). -/
noncomputable def a_star (q : ℝ) : ℝ :=
  if h : ∃ a, IsAStar q a then Classical.choose h else 0

end Workspace.ProofLemmas.FqHasUniqueInteriorZero

open Workspace.ProofLemmas.FqHasUniqueInteriorZero

theorem FqHasUniqueInteriorZero (q : ℝ) (hq : 1 < q) :
    (∃! a : ℝ, IsAStar q a) ∧ IsAStar q (a_star q) := by
  classical
  -- Basic facts.
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_pow_pos : (0 : ℝ) < q^2 := by positivity
  set p : ℝ := (1 - q) / q with hp_def
  have hp_neg : p < 0 := by
    apply div_neg_of_neg_of_pos
    · linarith
    · exact hq_pos
  -- F_q(1) = 0 by direct algebra.
  have hFq_one : F_q q 1 = 0 := by
    simp only [F_q, Real.one_rpow]
    field_simp
    ring
  -- Strict convexity.
  have hStrictConv : StrictConvexOn ℝ (Set.Ioi (0 : ℝ)) (fun a => F_q q a) :=
    FqStrictConvex q hq
  -- Continuity of F_q on Ioi 0.
  have hCont : ContinuousOn (fun a => F_q q a) (Set.Ioi (0 : ℝ)) := by
    have heq : ∀ a : ℝ, F_q q a =
        (2 * (1 - 1/q)) * a + (1/q) * a ^ p + (-2 + 1/q) := by
      intro a
      simp only [F_q, p]
      ring
    refine ContinuousOn.congr ?_ (fun a _ => heq a)
    refine ((continuousOn_const.mul continuousOn_id).add ?_).add continuousOn_const
    refine continuousOn_const.mul ?_
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    exact (Real.continuousAt_rpow_const a p (Or.inl ha_ne)).continuousWithinAt
  -- HasDerivAt for F_q at any positive point.
  have hFq_deriv : ∀ a : ℝ, 0 < a →
      HasDerivAt (fun a => F_q q a) (2 * (1 - 1/q) + (1/q) * (p * a ^ (p - 1))) a := by
    intro a ha
    have ha_ne : a ≠ 0 := ne_of_gt ha
    have hd_lin : HasDerivAt (fun y : ℝ => (2 * (1 - 1/q)) * y) (2 * (1 - 1/q)) a := by
      simpa using (hasDerivAt_id a).const_mul (2 * (1 - 1/q))
    have hd_rpow : HasDerivAt (fun y : ℝ => y ^ p) (p * a ^ (p - 1)) a :=
      Real.hasDerivAt_rpow_const (Or.inl ha_ne)
    have hd_smul : HasDerivAt (fun y : ℝ => (1/q) * y ^ p) ((1/q) * (p * a ^ (p - 1))) a :=
      hd_rpow.const_mul (1/q)
    have hd_sum : HasDerivAt
        (fun y : ℝ => (2 * (1 - 1/q)) * y + (1/q) * y ^ p)
        (2 * (1 - 1/q) + (1/q) * (p * a ^ (p - 1))) a := hd_lin.add hd_smul
    have hd_total : HasDerivAt
        (fun y : ℝ => (2 * (1 - 1/q)) * y + (1/q) * y ^ p + (-2 + 1/q))
        (2 * (1 - 1/q) + (1/q) * (p * a ^ (p - 1))) a := hd_sum.add_const (-2 + 1/q)
    have hcongr : (fun y : ℝ => F_q q y) =
        (fun y => (2 * (1 - 1/q)) * y + (1/q) * y ^ p + (-2 + 1/q)) := by
      funext y; simp only [F_q, p]; ring
    rw [hcongr]; exact hd_total
  -- Compute the derivative value at 1.
  set L : ℝ := 2 * (1 - 1/q) + (1/q) * (p * (1 : ℝ) ^ (p - 1)) with hL_def
  have hL_eq : L = (2*q - 1) * (q - 1) / q^2 := by
    simp only [hL_def, p, Real.one_rpow, mul_one]
    field_simp
    ring
  have hL_pos : 0 < L := by
    rw [hL_eq]
    apply div_pos
    · apply mul_pos
      · linarith
      · linarith
    · exact hq_pow_pos
  have hFq_deriv_one : HasDerivAt (fun a => F_q q a) L 1 := hFq_deriv 1 zero_lt_one
  -- Step 1: Find a < 1 (close to 1, in (0,1)) with F_q a < 0.
  -- Use the slope characterization of HasDerivAt at 1.
  have htendsto_slope : Filter.Tendsto
      (fun t : ℝ => t⁻¹ * (F_q q (1 + t) - F_q q 1))
      (nhdsWithin (0:ℝ) {0}ᶜ) (nhds L) := by
    have h := hFq_deriv_one
    rw [hasDerivAt_iff_tendsto_slope_zero] at h
    simpa [smul_eq_mul] using h
  have htendsto_slope' : Filter.Tendsto
      (fun t : ℝ => t⁻¹ * F_q q (1 + t))
      (nhdsWithin (0:ℝ) {0}ᶜ) (nhds L) := by
    have heq : (fun t : ℝ => t⁻¹ * (F_q q (1 + t) - F_q q 1)) =
        (fun t => t⁻¹ * F_q q (1 + t)) := by
      funext t; rw [hFq_one]; ring
    rw [heq] at htendsto_slope
    exact htendsto_slope
  -- Restrict to nhdsWithin 0 (Iio 0).
  have hsub : nhdsWithin (0:ℝ) (Set.Iio 0) ≤ nhdsWithin (0:ℝ) {0}ᶜ :=
    nhdsWithin_mono _ (fun x hx => ne_of_lt hx)
  have htendsto_left : Filter.Tendsto
      (fun t : ℝ => t⁻¹ * F_q q (1 + t))
      (nhdsWithin (0:ℝ) (Set.Iio 0)) (nhds L) :=
    htendsto_slope'.mono_left hsub
  -- Eventually the slope > L/2 > 0.
  have hL_half : 0 < L/2 := by linarith
  have hL_half_lt : L/2 < L := by linarith
  have h_evt_slope : ∀ᶠ t in nhdsWithin (0:ℝ) (Set.Iio 0),
      L/2 < t⁻¹ * F_q q (1 + t) :=
    htendsto_left.eventually (eventually_gt_nhds hL_half_lt)
  -- Eventually -1/2 < t (so 1 + t > 1/2 > 0).
  have h_evt_t_gt : ∀ᶠ t in nhdsWithin (0:ℝ) (Set.Iio 0), -(1/2 : ℝ) < t := by
    have hneg : (-(1/2:ℝ)) < 0 := by norm_num
    have hev := (eventually_gt_nhds hneg : ∀ᶠ x in nhds (0:ℝ), -(1/2:ℝ) < x)
    exact hev.filter_mono nhdsWithin_le_nhds
  -- Membership: in nhdsWithin 0 (Iio 0), every t satisfies t < 0.
  have h_evt_t_lt : ∀ᶠ t in nhdsWithin (0:ℝ) (Set.Iio 0), t < 0 := by
    rw [Filter.eventually_iff]
    exact self_mem_nhdsWithin
  -- NeBot for the filter.
  haveI hNeBot : (nhdsWithin (0:ℝ) (Set.Iio 0)).NeBot := nhdsLT_neBot 0
  -- Combine the three eventuallys, then extract a witness.
  obtain ⟨t, ht_slope, ht_lt, ht_gt⟩ : ∃ t,
      (L/2 < t⁻¹ * F_q q (1 + t)) ∧ (t < 0) ∧ (-(1/2 : ℝ) < t) := by
    have h_combined : ∀ᶠ t in nhdsWithin (0:ℝ) (Set.Iio 0),
        (L/2 < t⁻¹ * F_q q (1 + t)) ∧ (t < 0) ∧ (-(1/2 : ℝ) < t) :=
      h_evt_slope.and (h_evt_t_lt.and h_evt_t_gt)
    exact h_combined.exists
  -- Now construct a := 1 + t.
  have ha_pos : 0 < 1 + t := by linarith
  have ha_lt_one : 1 + t < 1 := by linarith
  -- F_q q (1 + t) < 0 from the slope info.
  have h_slope_pos : 0 < t⁻¹ * F_q q (1 + t) := lt_trans hL_half ht_slope
  have ht_inv_neg : t⁻¹ < 0 := inv_lt_zero.mpr ht_lt
  have hFq_neg : F_q q (1 + t) < 0 := by
    by_contra h
    push_neg at h
    have : t⁻¹ * F_q q (1 + t) ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (le_of_lt ht_inv_neg) h
    linarith
  set a₁ : ℝ := 1 + t with ha₁_def
  -- Step 2: Find s ∈ (0, a₁) with F_q s > 0.
  -- From FqSignAt0Pos: F_q tends to +∞ at 0+.
  have hTopAtZero : Filter.Tendsto (fun a => F_q q a) (nhdsWithin 0 (Set.Ioi 0)) Filter.atTop :=
    FqSignAt0Pos q hq
  -- ∃ s ∈ (0, a₁), F_q s > 0.
  have h_evt_top : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), 1 < F_q q a :=
    hTopAtZero.eventually (Filter.eventually_gt_atTop 1)
  have h_evt_lt_a : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), a < a₁ := by
    have hev : ∀ᶠ x in nhds (0:ℝ), x < a₁ := eventually_lt_nhds ha_pos
    exact hev.filter_mono nhdsWithin_le_nhds
  have h_evt_a_pos : ∀ᶠ a in nhdsWithin (0:ℝ) (Set.Ioi 0), 0 < a := by
    rw [Filter.eventually_iff]
    exact self_mem_nhdsWithin
  haveI hNeBotR : (nhdsWithin (0:ℝ) (Set.Ioi 0)).NeBot := nhdsGT_neBot 0
  obtain ⟨s, hs_top, hs_lt, hs_pos⟩ : ∃ s,
      (1 < F_q q s) ∧ (s < a₁) ∧ (0 < s) := by
    have h := h_evt_top.and (h_evt_lt_a.and h_evt_a_pos)
    exact h.exists
  -- Step 3: Apply IVT to get a zero of F_q in (s, a₁).
  -- Use `intermediate_value_Ioo'`: a ≤ b, ContinuousOn f [a, b], Ioo (f b) (f a) ⊆ f '' Ioo a b.
  -- We have f(s) > 0 > f(a₁), so 0 ∈ Ioo (f a₁) (f s). Need ContinuousOn on [s, a₁].
  have hCont_on_Icc : ContinuousOn (fun a => F_q q a) (Set.Icc s a₁) := by
    apply hCont.mono
    intro x hx
    exact lt_of_lt_of_le hs_pos hx.1
  have hsub_lt : s ≤ a₁ := le_of_lt hs_lt
  have hzero_in : (0:ℝ) ∈ Set.Ioo (F_q q a₁) (F_q q s) := by
    refine ⟨hFq_neg, ?_⟩
    linarith
  have h_image : Set.Ioo (F_q q a₁) (F_q q s) ⊆ (fun a => F_q q a) '' Set.Ioo s a₁ :=
    intermediate_value_Ioo' hsub_lt hCont_on_Icc
  obtain ⟨c, hc_mem, hc_val⟩ := h_image hzero_in
  have hc_pos : 0 < c := lt_trans hs_pos hc_mem.1
  have hc_lt : c < 1 := lt_trans hc_mem.2 ha_lt_one
  -- So `c` is in (0, 1) with F_q q c = 0. Hence IsAStar q c.
  have hIsAStar_c : IsAStar q c := ⟨hc_pos, hc_lt, hc_val⟩
  -- Step 4: Uniqueness: at most one a satisfies IsAStar q a.
  have h_unique : ∀ a b : ℝ, IsAStar q a → IsAStar q b → a = b := by
    intro a b ha hb
    by_contra hne
    rcases lt_or_gt_of_ne hne with hab | hab
    · -- a < b < 1, all zeros.
      have ha_pos := ha.1
      have ha_lt := ha.2.1
      have ha_zero := ha.2.2
      have hb_pos := hb.1
      have hb_lt := hb.2.1
      have hb_zero := hb.2.2
      have ha_in_Ioi : a ∈ Set.Ioi (0:ℝ) := ha_pos
      have hone_in_Ioi : (1:ℝ) ∈ Set.Ioi (0:ℝ) := Set.mem_Ioi.mpr zero_lt_one
      have h_a_ne_one : a ≠ 1 := ne_of_lt (lt_trans hab hb_lt)
      have hb_in_seg : b ∈ openSegment ℝ a 1 := by
        rw [openSegment_eq_Ioo (lt_trans hab hb_lt)]
        exact ⟨hab, hb_lt⟩
      have h_lt_max : F_q q b < max (F_q q a) (F_q q 1) :=
        hStrictConv.lt_on_openSegment ha_in_Ioi hone_in_Ioi h_a_ne_one hb_in_seg
      rw [ha_zero, hFq_one, max_self] at h_lt_max
      linarith
    · -- b < a < 1, all zeros.
      have ha_pos := ha.1
      have ha_lt := ha.2.1
      have ha_zero := ha.2.2
      have hb_pos := hb.1
      have hb_lt := hb.2.1
      have hb_zero := hb.2.2
      have hb_in_Ioi : b ∈ Set.Ioi (0:ℝ) := hb_pos
      have hone_in_Ioi : (1:ℝ) ∈ Set.Ioi (0:ℝ) := Set.mem_Ioi.mpr zero_lt_one
      have h_b_ne_one : b ≠ 1 := ne_of_lt (lt_trans hab ha_lt)
      have ha_in_seg : a ∈ openSegment ℝ b 1 := by
        rw [openSegment_eq_Ioo (lt_trans hab ha_lt)]
        exact ⟨hab, ha_lt⟩
      have h_lt_max : F_q q a < max (F_q q b) (F_q q 1) :=
        hStrictConv.lt_on_openSegment hb_in_Ioi hone_in_Ioi h_b_ne_one ha_in_seg
      rw [hb_zero, hFq_one, max_self] at h_lt_max
      linarith
  -- Step 5: Build ∃! a, IsAStar q a from existence + uniqueness.
  have h_exists_unique : ∃! a, IsAStar q a := by
    refine ⟨c, hIsAStar_c, ?_⟩
    intro y hy
    exact h_unique y c hy hIsAStar_c
  refine ⟨h_exists_unique, ?_⟩
  -- Step 6: IsAStar q (a_star q).
  have h_exists : ∃ a, IsAStar q a := h_exists_unique.exists
  unfold a_star
  rw [dif_pos h_exists]
  exact Classical.choose_spec h_exists

open Workspace.ProofLemmas.FqHasUniqueInteriorZero
open Workspace.ProofLemmas.FqSignAt0Pos

theorem AStarLessThanOneHalf (q : ℝ) (hq : 1 < q) :
    0 < a_star q ∧ a_star q < 1/2 := by
  -- Get IsAStar info from FqHasUniqueInteriorZero
  obtain ⟨_, hIs⟩ := FqHasUniqueInteriorZero q hq
  obtain ⟨ha_pos, ha_lt_one, hFa⟩ := hIs
  refine ⟨ha_pos, ?_⟩
  -- Basic positivity facts
  have hq_pos : (0 : ℝ) < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
  have hqp1_pos : (0 : ℝ) < q + 1 := by linarith
  -- F_q q 1 = 0
  have hF_one : F_q q 1 = 0 := by
    simp only [F_q, Real.one_rpow]
    field_simp
    ring
  -- log 2 < 1
  have hlog2_lt_one : Real.log 2 < 1 := by
    have h := Real.log_lt_sub_one_of_pos (by norm_num : (0 : ℝ) < 2) (by norm_num : (2 : ℝ) ≠ 1)
    linarith
  -- 0 < log 2
  have hlog2_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  -- 2 * (q - 1) / (q + 1) < log q
  have hlogq_lower : 2 * (q - 1) / (q + 1) < Real.log q := by
    have h := Real.lt_log_one_add_of_pos (x := q - 1) hqm1_pos
    have h1 : (q - 1 : ℝ) + 2 = q + 1 := by ring
    have h2 : (1 : ℝ) + (q - 1) = q := by ring
    rw [h1, h2] at h
    exact h
  -- Key inequality: log 2 * (q - 1) < q * log q
  have h_key : Real.log 2 * (q - 1) < q * Real.log q := by
    have h_step1 : Real.log 2 * (q - 1) ≤ q * (2 * (q - 1) / (q + 1)) := by
      have h_aux : Real.log 2 * (q + 1) ≤ 2 * q := by
        have hq_ge_one : (1 : ℝ) ≤ q := le_of_lt hq
        nlinarith [hlog2_lt_one, hq_ge_one, hlog2_pos]
      have h_lhs : Real.log 2 * (q - 1) * (q + 1) ≤ 2 * q * (q - 1) := by
        nlinarith [hqm1_pos, h_aux]
      have h_rhs_eq : q * (2 * (q - 1) / (q + 1)) = (2 * q * (q - 1)) / (q + 1) := by
        field_simp
      rw [h_rhs_eq, le_div_iff₀ hqp1_pos]
      linarith
    have h_step2 : q * (2 * (q - 1) / (q + 1)) < q * Real.log q := by
      exact mul_lt_mul_of_pos_left hlogq_lower hq_pos
    linarith
  -- F_q q (1/2) < 0
  have hF_half : F_q q (1/2) < 0 := by
    have h_half_rpow : ((1:ℝ)/2) ^ ((1 - q) / q) = Real.exp (((q - 1) / q) * Real.log 2) := by
      rw [show ((1:ℝ)/2) = (2:ℝ)⁻¹ by norm_num]
      rw [Real.inv_rpow (by norm_num : (0:ℝ) ≤ 2)]
      rw [show ((2 : ℝ)^((1 - q) / q))⁻¹ = (2 : ℝ)^(-(((1 - q) / q))) by
        rw [← Real.rpow_neg (by norm_num : (0:ℝ) ≤ 2)]]
      rw [show -((1 - q) / q) = (q - 1) / q by ring]
      rw [Real.rpow_def_of_pos (by norm_num : (0:ℝ) < 2)]
      ring_nf
    -- Derive: (1/2)^((1-q)/q) < q
    have h_rpow_lt_q : ((1:ℝ)/2) ^ ((1 - q) / q) < q := by
      rw [h_half_rpow]
      have hexp_lt : ((q - 1) / q) * Real.log 2 < Real.log q := by
        rw [div_mul_eq_mul_div]
        rw [div_lt_iff₀ hq_pos]
        linarith [h_key]
      calc Real.exp (((q - 1) / q) * Real.log 2)
          < Real.exp (Real.log q) := Real.exp_lt_exp.mpr hexp_lt
        _ = q := Real.exp_log hq_pos
    -- Now F_q(1/2) = -1 + (1/q) * (1/2)^((1-q)/q) < -1 + (1/q) * q = 0
    have h_inv_pos : 0 < (1 : ℝ) / q := by positivity
    have h_mul : (1/q) * ((1:ℝ)/2) ^ ((1 - q) / q) < (1/q) * q := by
      exact mul_lt_mul_of_pos_left h_rpow_lt_q h_inv_pos
    have h_inv_q : (1/q) * q = 1 := by field_simp
    rw [h_inv_q] at h_mul
    have hFq_half_eq : F_q q (1/2) = -1 + (1/q) * ((1:ℝ)/2) ^ ((1 - q) / q) := by
      simp only [F_q]
      field_simp
      ring
    rw [hFq_half_eq]
    linarith
  -- Apply secant_strict_mono via FqStrictConvex
  by_contra h_neg
  push_neg at h_neg
  -- h_neg : 1/2 ≤ a_star q
  have hSC := FqStrictConvex q hq
  rcases eq_or_lt_of_le h_neg with heq | hlt
  · -- 1/2 = a_star q
    rw [← heq] at hFa
    linarith
  · -- 1/2 < a_star q
    have h_half_in : (1 : ℝ)/2 ∈ Set.Ioi (0 : ℝ) := by
      simp only [Set.mem_Ioi]; norm_num
    have h_one_in : (1 : ℝ) ∈ Set.Ioi (0 : ℝ) := by
      simp only [Set.mem_Ioi]; norm_num
    have h_astar_in : a_star q ∈ Set.Ioi (0 : ℝ) := ha_pos
    have hxa : (1 : ℝ)/2 ≠ 1 := by norm_num
    have hya : a_star q ≠ 1 := ne_of_lt ha_lt_one
    -- secant_strict_mono : a ∈ s → x ∈ s → y ∈ s → x ≠ a → y ≠ a → x < y →
    --   (f x - f a) / (x - a) < (f y - f a) / (y - a)
    have hSecant := hSC.secant_strict_mono h_one_in h_half_in h_astar_in hxa hya hlt
    rw [hFa, hF_one] at hSecant
    -- hSecant : (F_q q (1/2) - 0) / (1/2 - 1) < (0 - 0) / (a_star q - 1)
    -- Simplify: F_q q (1/2) / (1/2 - 1) < 0
    have h_rhs_zero : (0 - (0 : ℝ)) / (a_star q - 1) = 0 := by
      simp
    have h_lhs_simp : (F_q q (1/2) - 0) / ((1:ℝ)/2 - 1) = F_q q (1/2) / ((1:ℝ)/2 - 1) := by
      ring
    rw [h_rhs_zero, h_lhs_simp] at hSecant
    -- hSecant : F_q q (1/2) / (1/2 - 1) < 0
    have hdenom_neg : ((1:ℝ)/2 - 1) < 0 := by norm_num
    -- F_q q (1/2) / (negative) < 0 means F_q q (1/2) > 0, contradicting hF_half
    have hF_pos : 0 < F_q q (1/2) := by
      rcases div_neg_iff.mp hSecant with ⟨hp, hn⟩ | ⟨hn, hp⟩
      · linarith
      · linarith
    linarith

open Workspace.ProofLemmas.FqSignAt0Pos
open Workspace.ProofLemmas.FqHasUniqueInteriorZero

namespace Workspace.ProofLemmas.DeltaStarDef

noncomputable def delta_star (q : ℝ) : ℝ :=
  ((a_star q) ^ ((1 : ℝ) / q) + 1 - 2 * (a_star q)) /
  (1 - (a_star q)) ^ ((1 : ℝ) / q)

/-- Auxiliary: for `r ∈ (0, 1]` and `x ∈ [0, 1/2]`,
    `(1-x)^r ≤ x^r + 1 - 2x`. -/
private lemma aux_chord_inequality (r : ℝ) (hr_pos : 0 < r) (hr_le : r ≤ 1)
    (x : ℝ) (hx_nn : 0 ≤ x) (hx_le : x ≤ 1/2) :
    (1 - x) ^ r ≤ x ^ r + 1 - 2 * x := by
  rcases eq_or_lt_of_le hr_le with hr_eq | hr_lt
  · -- r = 1
    rw [hr_eq]
    rw [Real.rpow_one, Real.rpow_one]
    linarith
  · -- r < 1
    rcases eq_or_lt_of_le hx_nn with hx_zero | hx_pos
    · -- x = 0
      rw [← hx_zero]
      simp [Real.zero_rpow (ne_of_gt hr_pos)]
    · rcases eq_or_lt_of_le hx_le with hx_eq_half | hx_lt_half
      · -- x = 1/2
        rw [hx_eq_half]
        have : (1 - (1/2 : ℝ)) = 1/2 := by norm_num
        rw [this]
        linarith
      · -- 0 < x < 1/2
        set H : ℝ → ℝ := fun x => (1 - x) ^ r - x ^ r - 1 + 2 * x with hH_def
        suffices hH_le : H x ≤ 0 by
          have : H x = (1 - x) ^ r - x ^ r - 1 + 2 * x := rfl
          linarith
        have hH0 : H 0 = 0 := by
          simp [hH_def, Real.zero_rpow (ne_of_gt hr_pos), Real.one_rpow]
        have hH_half : H (1/2 : ℝ) = 0 := by
          show (1 - (1/2 : ℝ)) ^ r - ((1/2 : ℝ)) ^ r - 1 + 2 * (1/2 : ℝ) = 0
          have h12 : (1 - (1/2 : ℝ)) = 1/2 := by norm_num
          rw [h12]
          ring
        -- Continuity of H on [0, 1/2].
        have hCont : ContinuousOn H (Set.Icc (0 : ℝ) (1/2)) := by
          have h1 : ContinuousOn (fun x : ℝ => (1 - x) ^ r) (Set.Icc (0 : ℝ) (1/2)) := by
            intro x hx
            have hx_le : x ≤ 1/2 := hx.2
            have h1x_pos : 0 < 1 - x := by linarith
            have h_inner : ContinuousAt (fun x : ℝ => 1 - x) x :=
              (continuous_const.sub continuous_id).continuousAt
            have h_outer : ContinuousAt (fun y : ℝ => y ^ r) (1 - x) :=
              Real.continuousAt_rpow_const (1 - x) r (Or.inl (ne_of_gt h1x_pos))
            exact (h_outer.comp h_inner).continuousWithinAt
          have h2 : ContinuousOn (fun x : ℝ => x ^ r) (Set.Icc (0 : ℝ) (1/2)) := by
            intro x hx
            have : ContinuousAt (fun x : ℝ => x ^ r) x :=
              Real.continuousAt_rpow_const x r (Or.inr (le_of_lt hr_pos))
            exact this.continuousWithinAt
          have h3 : ContinuousOn (fun x : ℝ => (1 - x) ^ r - x ^ r) (Set.Icc (0 : ℝ) (1/2)) :=
            h1.sub h2
          have h4 : ContinuousOn (fun x : ℝ => (1 - x) ^ r - x ^ r - 1) (Set.Icc (0 : ℝ) (1/2)) :=
            h3.sub continuousOn_const
          have h5 : ContinuousOn H (Set.Icc (0 : ℝ) (1/2)) := by
            simp only [hH_def]
            exact h4.add (continuousOn_const.mul continuousOn_id)
          exact h5
        have hConv_Icc : Convex ℝ (Set.Icc (0 : ℝ) (1/2)) := convex_Icc 0 (1/2)
        have h_int : interior (Set.Icc (0 : ℝ) (1/2)) = Set.Ioo 0 (1/2) := interior_Icc
        -- First derivative formula on (0, 1/2).
        have hH_deriv : ∀ y ∈ Set.Ioo (0 : ℝ) (1/2),
            HasDerivAt H (-r * (1 - y) ^ (r - 1) - r * y ^ (r - 1) + 2) y := by
          intro y hy
          have hy_pos : 0 < y := hy.1
          have hy_ne : y ≠ 0 := ne_of_gt hy_pos
          have h1y_pos : 0 < 1 - y := by linarith [hy.2]
          have h1y_ne : 1 - y ≠ 0 := ne_of_gt h1y_pos
          have hd_inner_neg : HasDerivAt (fun y : ℝ => 1 - y) (-1 : ℝ) y := by
            simpa using (hasDerivAt_id y).const_sub 1
          have hd_rpow_y : HasDerivAt (fun y : ℝ => y ^ r) (r * y ^ (r - 1)) y :=
            Real.hasDerivAt_rpow_const (Or.inl hy_ne)
          have hd_rpow_one_minus :
              HasDerivAt (fun y : ℝ => (1 - y) ^ r)
                ((r * (1 - y) ^ (r - 1)) * (-1)) y := by
            have hd := Real.hasDerivAt_rpow_const (p := r) (x := 1 - y) (Or.inl h1y_ne)
            exact hd.comp y hd_inner_neg
          have hd_sub :
              HasDerivAt (fun y : ℝ => (1 - y) ^ r - y ^ r)
                ((r * (1 - y) ^ (r - 1)) * (-1) - r * y ^ (r - 1)) y :=
            hd_rpow_one_minus.sub hd_rpow_y
          have hd_sub_const :
              HasDerivAt (fun y : ℝ => (1 - y) ^ r - y ^ r - 1)
                ((r * (1 - y) ^ (r - 1)) * (-1) - r * y ^ (r - 1)) y :=
            hd_sub.sub_const 1
          have hd_lin : HasDerivAt (fun y : ℝ => 2 * y) (2 : ℝ) y := by
            simpa using (hasDerivAt_id y).const_mul 2
          have hd_total :
              HasDerivAt H
                ((r * (1 - y) ^ (r - 1)) * (-1) - r * y ^ (r - 1) + 2) y := by
            simp only [hH_def]
            exact hd_sub_const.add hd_lin
          have heq :
              (r * (1 - y) ^ (r - 1)) * (-1) - r * y ^ (r - 1) + 2 =
                -r * (1 - y) ^ (r - 1) - r * y ^ (r - 1) + 2 := by ring
          rw [heq] at hd_total
          exact hd_total
        -- Second derivative formula.
        have hH_deriv2 : ∀ y ∈ Set.Ioo (0 : ℝ) (1/2),
            HasDerivAt
              (fun y : ℝ => -r * (1 - y) ^ (r - 1) - r * y ^ (r - 1) + 2)
              (r * (r - 1) * (1 - y) ^ (r - 2) - r * (r - 1) * y ^ (r - 2)) y := by
          intro y hy
          have hy_pos : 0 < y := hy.1
          have hy_ne : y ≠ 0 := ne_of_gt hy_pos
          have h1y_pos : 0 < 1 - y := by linarith [hy.2]
          have h1y_ne : 1 - y ≠ 0 := ne_of_gt h1y_pos
          have hd_inner_neg : HasDerivAt (fun y : ℝ => 1 - y) (-1 : ℝ) y := by
            simpa using (hasDerivAt_id y).const_sub 1
          have hd_rpow_inner :
              HasDerivAt (fun y : ℝ => y ^ (r - 1)) ((r - 1) * y ^ (r - 1 - 1)) y :=
            Real.hasDerivAt_rpow_const (Or.inl hy_ne)
          have hd_rpow_one_minus_inner :
              HasDerivAt (fun y : ℝ => (1 - y) ^ (r - 1))
                (((r - 1) * (1 - y) ^ (r - 1 - 1)) * (-1)) y := by
            have hd := Real.hasDerivAt_rpow_const (p := r - 1) (x := 1 - y) (Or.inl h1y_ne)
            exact hd.comp y hd_inner_neg
          have hd_part1 :
              HasDerivAt (fun y : ℝ => -r * (1 - y) ^ (r - 1))
                (-r * (((r - 1) * (1 - y) ^ (r - 1 - 1)) * (-1))) y :=
            hd_rpow_one_minus_inner.const_mul (-r)
          have hd_part2 :
              HasDerivAt (fun y : ℝ => r * y ^ (r - 1))
                (r * ((r - 1) * y ^ (r - 1 - 1))) y :=
            hd_rpow_inner.const_mul r
          have hd_sub :
              HasDerivAt
                (fun y : ℝ => -r * (1 - y) ^ (r - 1) - r * y ^ (r - 1))
                (-r * (((r - 1) * (1 - y) ^ (r - 1 - 1)) * (-1)) -
                  r * ((r - 1) * y ^ (r - 1 - 1))) y :=
            hd_part1.sub hd_part2
          have hd_total := hd_sub.add_const (2 : ℝ)
          have heq :
              -r * (((r - 1) * (1 - y) ^ (r - 1 - 1)) * (-1)) -
                  r * ((r - 1) * y ^ (r - 1 - 1)) =
                r * (r - 1) * (1 - y) ^ (r - 2) - r * (r - 1) * y ^ (r - 2) := by
            have h1 : r - 1 - 1 = r - 2 := by ring
            rw [h1]
            ring
          rw [heq] at hd_total
          exact hd_total
        -- Convexity via second derivative ≥ 0.
        have hConv_H : ConvexOn ℝ (Set.Icc (0 : ℝ) (1/2)) H := by
          apply convexOn_of_deriv2_nonneg hConv_Icc hCont
          · rw [h_int]
            intro y hy
            exact (hH_deriv y hy).differentiableAt.differentiableWithinAt
          · rw [h_int]
            intro y hy
            have hopen : IsOpen (Set.Ioo (0 : ℝ) (1/2)) := isOpen_Ioo
            have hnhds : Set.Ioo (0 : ℝ) (1/2) ∈ nhds y := hopen.mem_nhds hy
            have hloc :
                deriv H =ᶠ[nhds y]
                  fun z => -r * (1 - z) ^ (r - 1) - r * z ^ (r - 1) + 2 := by
              filter_upwards [hnhds] with z hz
              exact (hH_deriv z hz).deriv
            have hd2 :
                DifferentiableAt ℝ
                  (fun z : ℝ => -r * (1 - z) ^ (r - 1) - r * z ^ (r - 1) + 2) y :=
              (hH_deriv2 y hy).differentiableAt
            have hd_local : DifferentiableAt ℝ (deriv H) y :=
              hd2.congr_of_eventuallyEq hloc
            exact hd_local.differentiableWithinAt
          · rw [h_int]
            intro y hy
            simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
            have hopen : IsOpen (Set.Ioo (0 : ℝ) (1/2)) := isOpen_Ioo
            have hnhds : Set.Ioo (0 : ℝ) (1/2) ∈ nhds y := hopen.mem_nhds hy
            have hloc :
                deriv H =ᶠ[nhds y]
                  fun z => -r * (1 - z) ^ (r - 1) - r * z ^ (r - 1) + 2 := by
              filter_upwards [hnhds] with z hz
              exact (hH_deriv z hz).deriv
            have hd2_eq : deriv (deriv H) y =
                deriv (fun z => -r * (1 - z) ^ (r - 1) - r * z ^ (r - 1) + 2) y :=
              hloc.deriv_eq
            rw [hd2_eq, (hH_deriv2 y hy).deriv]
            -- Show: 0 ≤ r * (r - 1) * (1 - y) ^ (r - 2) - r * (r - 1) * y ^ (r - 2)
            have hy_pos : 0 < y := hy.1
            have hy_lt : y < 1/2 := hy.2
            have h1y_pos : 0 < 1 - y := by linarith
            have h1y_gt_y : y < 1 - y := by linarith
            have hr_minus_one_neg : r - 1 < 0 := by linarith
            have hr_minus_two_neg : r - 2 < 0 := by linarith
            have h_rpow_lt : (1 - y) ^ (r - 2) < y ^ (r - 2) :=
              Real.rpow_lt_rpow_of_exponent_neg hy_pos h1y_gt_y hr_minus_two_neg
            have hr_rm1_neg : r * (r - 1) < 0 :=
              mul_neg_of_pos_of_neg hr_pos hr_minus_one_neg
            -- r * (r - 1) * ((1 - y)^(r-2) - y^(r-2)) ≥ 0
            -- = (negative) * (negative) ≥ 0
            have h_diff_neg : (1 - y) ^ (r - 2) - y ^ (r - 2) < 0 := by linarith
            have : 0 ≤ r * (r - 1) * ((1 - y) ^ (r - 2) - y ^ (r - 2)) := by
              have := mul_pos_of_neg_of_neg hr_rm1_neg h_diff_neg
              linarith
            linarith
        -- Apply convexity using ConvexOn.le_max_of_mem_Icc.
        have hx_in : x ∈ Set.Icc (0 : ℝ) (1/2) := ⟨le_of_lt hx_pos, le_of_lt hx_lt_half⟩
        have h0_in : (0 : ℝ) ∈ Set.Icc (0 : ℝ) (1/2) := ⟨le_refl _, by norm_num⟩
        have hhalf_in : (1/2 : ℝ) ∈ Set.Icc (0 : ℝ) (1/2) := ⟨by norm_num, le_refl _⟩
        have hbound : H x ≤ max (H 0) (H (1/2 : ℝ)) :=
          hConv_H.le_max_of_mem_Icc h0_in hhalf_in hx_in
        rw [hH0, hH_half] at hbound
        simpa using hbound

theorem DeltaStarDef (q : ℝ) (hq : 1 < q) :
    1 ≤ delta_star q ∧ 0 < (1 - a_star q) ^ ((1 : ℝ) / q) := by
  have h_astar := AStarLessThanOneHalf q hq
  obtain ⟨ha_pos, ha_lt_half⟩ := h_astar
  have ha_lt_one : a_star q < 1 := by linarith
  have h1_minus_pos : 0 < 1 - a_star q := by linarith
  have hq_pos : (0 : ℝ) < q := by linarith
  have hr_pos : (0 : ℝ) < (1 : ℝ) / q := by positivity
  have hr_le : (1 : ℝ) / q ≤ 1 := by
    rw [div_le_one hq_pos]; linarith
  have h_denom_pos : 0 < (1 - a_star q) ^ ((1 : ℝ) / q) :=
    Real.rpow_pos_of_pos h1_minus_pos _
  refine ⟨?_, h_denom_pos⟩
  unfold delta_star
  rw [le_div_iff₀ h_denom_pos]
  rw [one_mul]
  have hkey := aux_chord_inequality ((1 : ℝ) / q) hr_pos hr_le (a_star q)
    (le_of_lt ha_pos) (le_of_lt ha_lt_half)
  linarith

end Workspace.ProofLemmas.DeltaStarDef

open Workspace.ProofLemmas.DeltaStarDef

namespace Workspace.ProofLemmas.ZeqInHalfRange

noncomputable def z_func (q : ℝ) : ℝ :=
  (delta_star q) ^ (-(q / (2*q - 1))) /
    ((delta_star q) ^ (-(q / (2*q - 1))) + 1)

theorem ZeqInHalfRange (q : ℝ) (hq : 1 < q) :
    0 < z_func q ∧ z_func q ≤ 1/2 := by
  -- Use DeltaStarDef to get 1 ≤ delta_star q
  have hD : 1 ≤ delta_star q := (Workspace.ProofLemmas.DeltaStarDef.DeltaStarDef q hq).1
  have hDpos : 0 < delta_star q := lt_of_lt_of_le one_pos hD
  -- p = -(q/(2q-1)) is the exponent. Since q > 1, 2q - 1 > 1 > 0, q/(2q-1) > 0, so p < 0.
  set p : ℝ := -(q / (2*q - 1)) with hp_def
  have h2q1 : 0 < 2*q - 1 := by linarith
  have hqpos : 0 < q := lt_trans zero_lt_one hq
  have hp_neg : p < 0 := by
    rw [hp_def, neg_lt, neg_zero]
    exact div_pos hqpos h2q1
  have hp_nonpos : p ≤ 0 := le_of_lt hp_neg
  -- D^p > 0
  have hDp_pos : 0 < (delta_star q) ^ p := Real.rpow_pos_of_pos hDpos p
  -- D^p ≤ 1 since D ≥ 1 and p ≤ 0
  have hDp_le_one : (delta_star q) ^ p ≤ 1 :=
    Real.rpow_le_one_of_one_le_of_nonpos hD hp_nonpos
  -- denominator > 0
  have hDenom_pos : 0 < (delta_star q) ^ p + 1 := by linarith
  refine ⟨?_, ?_⟩
  · -- 0 < z_func q
    unfold z_func
    show 0 < (delta_star q) ^ p / ((delta_star q) ^ p + 1)
    exact div_pos hDp_pos hDenom_pos
  · -- z_func q ≤ 1/2
    unfold z_func
    show (delta_star q) ^ p / ((delta_star q) ^ p + 1) ≤ 1/2
    rw [div_le_div_iff₀ hDenom_pos (by norm_num : (0:ℝ) < 2)]
    -- Goal: D^p * 2 ≤ 1 * (D^p + 1)
    linarith

end Workspace.ProofLemmas.ZeqInHalfRange

open Workspace.ProofLemmas.LambdaDeltaIdentity
open Workspace.ProofLemmas.HSecondDerivative
open Workspace.ProofLemmas.ZeqInHalfRange

namespace Workspace.ProofLemmas.CGDefs

/-!
# Consistency-specific constants for Theorem 3 (CMP(c))

These are the genuinely new objects of the consistency proof (proof_nlp.md §3–§5,
`appendix.tex` 116–225), all at the fixed exponent `q = 2` (Euclidean L₂).

We follow proof_nlp.md exactly:

* `a1' c = (2 + c − √(3+2c))/2`         (the interior critical point `a₁'`, §5.1)
* `a1  c = a1' c` if `c < 1/2`, else `(1-c)/2`   (the branched optimum `a₁`, §5.2)
* `lambda1 c`                            (the optimal `λ₁` closed form, §5.3/§5.4)
* `delta1 c  = δ(λ₁) = (λ₁⁻² − 1)^{1/2}`  (the `δ₁`, §2.1)
* `u1 c a    = (1+c)(δ₁(1−a)^{1/2} − a^{1/2}) − 1 + 2a + c`  (the objective, §2.4)

The closed form for `λ₁` mirrors `Workspace.ConsistencyTheorem.CG c = 1/λ₁`.
-/

/-- The interior critical point `a₁' = (2 + c − √(3+2c))/2` (proof_nlp.md §5.1). -/
noncomputable def a1' (c : ℝ) : ℝ :=
  (2 + c - Real.sqrt (3 + 2 * c)) / 2

/-- The branched optimal `a₁`: the interior root `a₁'` on `c < 1/2`, the
constraint boundary `(1-c)/2` on `c ≥ 1/2` (proof_nlp.md §5.2). -/
noncomputable def a1 (c : ℝ) : ℝ :=
  if c < 1 / 2 then a1' c else (1 - c) / 2

/-- The optimal constant `λ₁` in closed form (proof_nlp.md §5.3, §5.4):

* `c < 1/2`:  `λ₁ = (c+1)·(4√(2c+3)·c + 6√(2c+3) − 10c − 8)^{-1/2}`
* `c ≥ 1/2`:  `λ₁ = √((c+1)/2)`

By construction `CG c = 1/λ₁` (see `CG_eq_inv_lambda1`). -/
noncomputable def lambda1 (c : ℝ) : ℝ :=
  if c < 1 / 2 then
    (c + 1) *
      (Real.sqrt (4 * Real.sqrt (2 * c + 3) * c + 6 * Real.sqrt (2 * c + 3) - 10 * c - 8))⁻¹
  else
    Real.sqrt ((c + 1) / 2)

/-- The associated `δ₁ = δ(λ₁) = (λ₁^{-2} − 1)^{1/2}`, i.e. the `q = 2` instance
of `delta_of_lambda` at `λ = λ₁` (proof_nlp.md §2.1). -/
noncomputable def delta1 (c : ℝ) : ℝ :=
  delta_of_lambda 2 (lambda1 c)

/-- The per-capita objective `u₁(a)` of proof_nlp.md §2.4:
`u₁(a) = (1+c)·(δ₁·(1−a)^{1/2} − a^{1/2}) − 1 + 2a + c`,
where `δ₁ = delta1 c` is the `δ` of the chosen `λ₁`. -/
noncomputable def u1 (c a : ℝ) : ℝ :=
  (1 + c) * (delta1 c * (1 - a) ^ ((1 : ℝ) / 2) - a ^ ((1 : ℝ) / 2)) - 1 + 2 * a + c

/-- `u₁(a)` with an *explicit* `δ`, for sub-lemmas that pin `δ` separately
(e.g. `CGOneParamReduction`, `CGOptimalSolutionForA1`). -/
noncomputable def u1delta (c delta a : ℝ) : ℝ :=
  (1 + c) * (delta * (1 - a) ^ ((1 : ℝ) / 2) - a ^ ((1 : ℝ) / 2)) - 1 + 2 * a + c

/-- The derivative `u₁'(a) = ½(1+c)(−δ(1−a)^{-1/2} − a^{-1/2}) + 2`
(proof_nlp.md §3, appendix line 121; with the corrected `−δ` sign). -/
noncomputable def u1deriv (c delta a : ℝ) : ℝ :=
  (1 / 2) * (1 + c) *
    (-delta * (1 - a) ^ (-(1 : ℝ) / 2) - a ^ (-(1 : ℝ) / 2)) + 2

/-- The inflection point `z = δ^{-2/3}/(δ^{-2/3}+1)`, the `q = 2` instance of
`z_func` (sign-change of `h''`). -/
noncomputable def zCG (delta : ℝ) : ℝ :=
  delta ^ (-(2 : ℝ) / 3) / (delta ^ (-(2 : ℝ) / 3) + 1)

end Workspace.ProofLemmas.CGDefs

open Workspace.ProofLemmas.CGDefs

/-- The relation pinning the closed form to `CG`: `CG c = 1 / λ₁`.
For `c < 1/2`, `1/λ₁ = √(4√(2c+3)c + 6√(2c+3) − 10c − 8)/(c+1)`; for `c ≥ 1/2`,
`1/λ₁ = √(2/(c+1))`. (proof_nlp.md §6.) -/
theorem CG_eq_inv_lambda1 (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) :
    Workspace.ConsistencyTheorem.CG c = 1 / lambda1 c := by
  unfold lambda1 Workspace.ConsistencyTheorem.CG
  by_cases hcase : c < 1 / 2
  · rw [if_pos hcase, if_pos hcase]
    set D := 4 * Real.sqrt (2 * c + 3) * c + 6 * Real.sqrt (2 * c + 3) - 10 * c - 8 with hD_def
    have hDpos : 0 < D := by
      have hs_nonneg : 0 ≤ Real.sqrt (2 * c + 3) := Real.sqrt_nonneg _
      have hs2 : (Real.sqrt (2 * c + 3)) ^ 2 = 2 * c + 3 := by
        rw [sq, Real.mul_self_sqrt (by linarith)]
      have hs_ge : (1 : ℝ) ≤ Real.sqrt (2 * c + 3) := by nlinarith [hs2, hs_nonneg]
      rw [hD_def]
      nlinarith [hs2, hs_nonneg, hs_ge, hc0, hcase, sq_nonneg (Real.sqrt (2 * c + 3) - 1),
        mul_nonneg hs_nonneg hc0]
    have hsqrtD_pos : 0 < Real.sqrt D := Real.sqrt_pos.mpr hDpos
    have hc1pos : (0 : ℝ) < c + 1 := by linarith
    field_simp
  · rw [if_neg hcase, if_neg hcase]
    have hc1pos : (0 : ℝ) < c + 1 := by linarith
    have hhalf_pos : (0 : ℝ) < (c + 1) / 2 := by linarith
    have hsqrt_pos : 0 < Real.sqrt ((c + 1) / 2) := Real.sqrt_pos.mpr hhalf_pos
    rw [eq_div_iff (ne_of_gt hsqrt_pos)]
    rw [← Real.sqrt_mul (by positivity)]
    rw [show (2 / (c + 1)) * ((c + 1) / 2) = 1 by field_simp]
    exact Real.sqrt_one

open Workspace.ProofLemmas.LambdaDeltaIdentity
open Workspace.ProofLemmas.HSecondDerivative
open Workspace.ProofLemmas.ZeqInHalfRange
open Workspace.ProofLemmas.CGDefs

namespace Workspace.ProofLemmas.RGDefs

/-!
# Robustness-specific constants for Theorem 4 (CMP(c))

These are the genuinely new objects of the robustness proof
(`appendix.tex` 257–311), all at the fixed exponent `q = 2` (Euclidean L₂).
They are the exact `c → −c` images of the consistency constants of
`Workspace.ProofLemmas.CGDefs`.

We follow appendix.tex exactly:

* `a2' c = (2 − c − √(3−2c))/2`        (the interior critical point `a₂'`, line 294)
* `a2  c = a2' c`  for ALL `c ∈ [0,1)`  (the *single-branch* optimum `a₂`, line 294)
* `lambda2 c`                           (the optimal `λ₂` closed form, line 310)
* `delta2 c  = δ(λ₂) = (λ₂⁻² − 1)^{1/2}`  (the `δ₂`)
* `u2 c a    = (1−c)(δ₂(1−a)^{1/2} − a^{1/2}) − 1 + 2a − c`  (the objective, line 257)

Unlike consistency's two-branch `a1`, the robustness `a2` is single-branch:
`a₂' ≤ (1+c)/2` on the whole interval `c ∈ [0,1)`, so the boundary never binds.

The closed form for `λ₂` mirrors `Workspace.RobustnessTheorem.RG c = 1/λ₂`.
-/

/-- Interior critical point `a₂' = (2 − c − √(3−2c))/2` (appendix 294). -/
noncomputable def a2' (c : ℝ) : ℝ := (2 - c - Real.sqrt (3 - 2 * c)) / 2

/-- The optimal `a₂`. SINGLE BRANCH: `a₂ = a₂'` for ALL `c ∈ [0,1)` (unlike the
two-branch `a1`), because `a₂' ≤ (1+c)/2` on the whole interval (appendix 294). -/
noncomputable def a2 (c : ℝ) : ℝ := a2' c

/-- Optimal `λ₂` closed form (single branch, appendix 310):
`λ₂ = (1−c)·(−4√(3−2c)·c + 6√(3−2c) + 10c − 8)^{-1/2}`. By construction `RG c = 1/λ₂`. -/
noncomputable def lambda2 (c : ℝ) : ℝ :=
  (1 - c) * (Real.sqrt (-4 * Real.sqrt (3 - 2 * c) * c + 6 * Real.sqrt (3 - 2 * c) + 10 * c - 8))⁻¹

/-- `δ₂ = δ(λ₂) = (λ₂^{-2} − 1)^{1/2}` — the `q=2` instance of `delta_of_lambda` at `λ₂`. -/
noncomputable def delta2 (c : ℝ) : ℝ := delta_of_lambda 2 (lambda2 c)

/-- Per-capita objective `u₂(a) = (1−c)(δ₂(1−a)^{1/2} − a^{1/2}) − 1 + 2a − c` (appendix 257). -/
noncomputable def u2 (c a : ℝ) : ℝ :=
  (1 - c) * (delta2 c * (1 - a) ^ ((1 : ℝ) / 2) - a ^ ((1 : ℝ) / 2)) - 1 + 2 * a - c

/-- `u₂` with explicit `δ`. -/
noncomputable def u2delta (c delta a : ℝ) : ℝ :=
  (1 - c) * (delta * (1 - a) ^ ((1 : ℝ) / 2) - a ^ ((1 : ℝ) / 2)) - 1 + 2 * a - c

/-- `u₂'(a) = ½(1−c)(−δ(1−a)^{-1/2} − a^{-1/2}) + 2` (c→−c image of `u1deriv`). -/
noncomputable def u2deriv (c delta a : ℝ) : ℝ :=
  (1 / 2) * (1 - c) * (-delta * (1 - a) ^ (-(1 : ℝ) / 2) - a ^ (-(1 : ℝ) / 2)) + 2

end Workspace.ProofLemmas.RGDefs

open Workspace.ProofLemmas.RGDefs

/-- `RG c = 1 / λ₂` (single branch, appendix 310). -/
theorem RG_eq_inv_lambda2 (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) :
    Workspace.RobustnessTheorem.RG c = 1 / lambda2 c := by
  unfold Workspace.RobustnessTheorem.RG lambda2
  set s := Real.sqrt (3 - 2 * c) with hs_def
  have hs_nonneg : 0 ≤ s := Real.sqrt_nonneg _
  have hs2 : s ^ 2 = 3 - 2 * c := by rw [hs_def, sq, Real.mul_self_sqrt (by linarith)]
  have hs_ge : (1 : ℝ) ≤ s := by nlinarith [hs2, hs_nonneg]
  set D := -4 * s * c + 6 * s + 10 * c - 8 with hD_def
  have hc1pos : (0 : ℝ) < 1 - c := by linarith
  have hDpos : 0 < D := by
    nlinarith [hs2, hs_nonneg, hs_ge, hc0, hc1, sq_nonneg (s - 1), mul_nonneg hs_nonneg hc0]
  have hsqrtDpos : 0 < Real.sqrt D := Real.sqrt_pos.mpr hDpos
  rw [one_div, mul_inv, inv_inv, div_eq_mul_inv, mul_comm]

open Workspace.Types.SocialCost
open Workspace.Types.LqNorm

theorem SocialCostTranslationInvariance (q : ℝ) {n d : ℕ}
    (P : Fin n → Fin d → ℝ) (t f : Fin d → ℝ) :
    socialCost q (fun (i : Fin n) (j : Fin d) => P i j - t j) (fun j => f j - t j)
      = socialCost q P f := by
  unfold socialCost
  refine Finset.sum_congr rfl (fun i _ => ?_)
  congr 1
  funext j
  ring

open Workspace.Types.SocialCost

theorem OptSocialCostTranslationInvariance
    (q : ℝ) {n d : ℕ} (P : Fin n → Fin d → ℝ) (t : Fin d → ℝ) :
    optSocialCost q (fun (i : Fin n) (j : Fin d) => P i j - t j) =
      optSocialCost q P := by
  unfold optSocialCost
  -- Apply the bijection f ↦ f - t on the domain.
  -- Function.Surjective.iInf_congr gives ⨅ x, F x = ⨅ y, G y when
  -- there's a surjection h with G (h x) = F x.
  -- We want ⨅ f, socialCost q P f = ⨅ f, socialCost q (P-t) f.
  symm
  refine Function.Surjective.iInf_congr (fun (f : Fin d → ℝ) => fun j => f j - t j) ?_ ?_
  · -- Surjective
    intro g
    refine ⟨fun j => g j + t j, ?_⟩
    funext j
    ring
  · -- pointwise equality
    intro f
    exact SocialCostTranslationInvariance q P t f

open Workspace.Types.CoordinateMedian

theorem MedianTranslationInvariance {n d : ℕ} (P : Fin n → Fin d → ℝ) (m t : Fin d → ℝ) :
    IsCoordinateMedian m P ↔
    IsCoordinateMedian (fun j => m j - t j) (fun (i : Fin n) (j : Fin d) => P i j - t j) := by
  unfold IsCoordinateMedian
  refine forall_congr' (fun j => ?_)
  have hlt_set : (Finset.univ.filter (fun i : Fin n => P i j < m j)) =
      (Finset.univ.filter (fun i : Fin n => P i j - t j < m j - t j)) := by
    apply Finset.filter_congr
    intros i _
    exact (sub_lt_sub_iff_right (t j)).symm
  have hgt_set : (Finset.univ.filter (fun i : Fin n => P i j > m j)) =
      (Finset.univ.filter (fun i : Fin n => P i j - t j > m j - t j)) := by
    apply Finset.filter_congr
    intros i _
    exact (sub_lt_sub_iff_right (t j)).symm
  rw [hlt_set, hgt_set]

open Workspace.Types.CoordinateMedian

theorem MedianCoordinateReflection {n d : ℕ} (P : Fin n → Fin d → ℝ)
    (eps : Fin d → ℝ) (heps : ∀ j, eps j = 1 ∨ eps j = -1)
    (h : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ)) P) :
    IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
      (fun (i : Fin n) (j : Fin d) => eps j * P i j) := by
  intro j
  rcases heps j with h1 | h1
  · -- eps j = 1: predicate is unchanged.
    have heq : ∀ i, eps j * P i j = P i j := fun i => by rw [h1]; ring
    have h_lt : (Finset.univ.filter (fun i : Fin n => eps j * P i j < 0)) =
                (Finset.univ.filter (fun i : Fin n => P i j < 0)) := by
      ext i
      simp [heq i]
    have h_gt : (Finset.univ.filter (fun i : Fin n => eps j * P i j > 0)) =
                (Finset.univ.filter (fun i : Fin n => P i j > 0)) := by
      ext i
      simp [heq i]
    rw [h_lt, h_gt]
    exact h j
  · -- eps j = -1: filters swap.
    have heq : ∀ i, eps j * P i j = -(P i j) := fun i => by rw [h1]; ring
    have h_lt : (Finset.univ.filter (fun i : Fin n => eps j * P i j < 0)) =
                (Finset.univ.filter (fun i : Fin n => P i j > 0)) := by
      ext i
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, heq i]
      constructor <;> intro hh <;> linarith
    have h_gt : (Finset.univ.filter (fun i : Fin n => eps j * P i j > 0)) =
                (Finset.univ.filter (fun i : Fin n => P i j < 0)) := by
      ext i
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, heq i]
      constructor <;> intro hh <;> linarith
    obtain ⟨hlt, hgt⟩ := h j
    rw [h_lt, h_gt]
    exact ⟨hgt, hlt⟩

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormZeroIffEqZero
    (q : ℝ) (hq : 1 ≤ q) {d : ℕ} (hd : 1 ≤ d) (x : Fin d → ℝ) :
    lqNorm q x = 0 ↔ x = 0 := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_ne : (1 : ℝ) / q ≠ 0 := by
    rw [one_div]; exact inv_ne_zero hq_ne
  have hsum_nn : 0 ≤ ∑ j, |x j| ^ q := sum_abs_rpow_nonneg q x
  unfold lqNorm
  rw [Real.rpow_eq_zero hsum_nn h_inv_ne]
  constructor
  · intro hsum
    have hzero : ∀ j ∈ Finset.univ, |x j| ^ q = 0 := by
      rw [Finset.sum_eq_zero_iff_of_nonneg
        (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)] at hsum
      exact hsum
    funext j
    have hj : |x j| ^ q = 0 := hzero j (Finset.mem_univ j)
    have habs : |x j| = 0 := by
      have := (Real.rpow_eq_zero (abs_nonneg _) hq_ne).mp hj
      exact this
    have : x j = 0 := abs_eq_zero.mp habs
    simpa using this
  · intro hx
    subst hx
    apply Finset.sum_eq_zero
    intro j _
    simp [Real.zero_rpow hq_ne]

open Workspace.ProofLemmas.RGDefs

namespace Workspace.ProofLemmas.RGLambda2InUnitInterval

theorem RGLambda2InUnitInterval (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) :
    0 < lambda2 c ∧ lambda2 c < 1 ∧ 1 < Workspace.RobustnessTheorem.RG c := by
  unfold lambda2 Workspace.RobustnessTheorem.RG
  -- D₂ = −4√(3−2c)·c + 6√(3−2c) + 10c − 8.  We show (1−c)² < D₂, hence 0 < D₂ and
  -- 1−c < √D₂, which yields all three conjuncts.
  set s := Real.sqrt (3 - 2 * c) with hs_def
  have hs_nonneg : 0 ≤ s := Real.sqrt_nonneg _
  have hs2 : s ^ 2 = 3 - 2 * c := by rw [hs_def, sq, Real.mul_self_sqrt (by linarith)]
  have hs_ge : (1 : ℝ) ≤ s := by nlinarith [hs2, hs_nonneg]
  set D := -4 * s * c + 6 * s + 10 * c - 8 with hD_def
  have hc1pos : (0 : ℝ) < 1 - c := by linarith
  have hDgt : (1 - c) ^ 2 < D := by
    nlinarith [hs2, hs_nonneg, hs_ge, hc0, hc1, sq_nonneg (s - 1),
      mul_nonneg hs_nonneg hc0]
  have hDpos : 0 < D := lt_trans (by positivity) hDgt
  have hsqrtD : 1 - c < Real.sqrt D := by
    rw [Real.lt_sqrt hc1pos.le]; exact hDgt
  have hsqrtDpos : 0 < Real.sqrt D := Real.sqrt_pos.mpr hDpos
  refine ⟨?_, ?_, ?_⟩
  · positivity
  · rw [mul_inv_lt_iff₀ hsqrtDpos]; linarith
  · rw [lt_div_iff₀ hc1pos]; linarith

end Workspace.ProofLemmas.RGLambda2InUnitInterval

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost
open Workspace.ConsistencyTheorem
open Workspace.RobustnessTheorem
open Workspace.ProofLemmas.RGDefs

namespace Workspace.ProofLemmas.RGTranslationScaleNormalize

/-! ### Private invariance helpers (ported verbatim from `CGTranslationScaleNormalize`). -/

/-- Reflecting a vector by signs preserves its lqNorm. -/
private lemma lqNorm_coord_reflection {q : ℝ} {d : ℕ}
    (eps : Fin d → ℝ) (heps : ∀ j, eps j = 1 ∨ eps j = -1) (x : Fin d → ℝ) :
    lqNorm q (fun j => eps j * x j) = lqNorm q x := by
  unfold lqNorm
  congr 1
  refine Finset.sum_congr rfl (fun j _ => ?_)
  show |eps j * x j| ^ q = |x j| ^ q
  rw [abs_mul]
  rcases heps j with h1 | h1
  · rw [h1]; simp
  · rw [h1]; simp

/-- Sign-flip on coordinates preserves SC. -/
private lemma socialCost_coord_reflection (q : ℝ) {n d : ℕ}
    (eps : Fin d → ℝ) (heps : ∀ j, eps j = 1 ∨ eps j = -1)
    (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) :
    socialCost q (fun (i : Fin n) (j : Fin d) => eps j * P i j)
      (fun j => eps j * f j) = socialCost q P f := by
  unfold socialCost
  refine Finset.sum_congr rfl (fun i _ => ?_)
  have heq : (fun j => eps j * P i j - eps j * f j)
              = (fun j => eps j * (P i j - f j)) := by
    funext j; ring
  rw [heq]
  exact lqNorm_coord_reflection eps heps _

/-- Scaling: socialCost q (αP) (αf) = α · socialCost q P f for α ≥ 0. -/
private lemma socialCost_scale {q : ℝ} (hq : 1 ≤ q) {n d : ℕ}
    (α : ℝ) (hα : 0 ≤ α) (P : Fin n → Fin d → ℝ) (f : Fin d → ℝ) :
    socialCost q (fun i j => α * P i j) (fun j => α * f j)
      = α * socialCost q P f := by
  unfold socialCost
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  have heq : (fun j => α * P i j - α * f j) = (fun j => α * (P i j - f j)) := by
    funext j; ring
  rw [heq, lqNorm_smul hq α, abs_of_nonneg hα]

/-- Median predicate is invariant under positive scaling. -/
private lemma median_scale {n d : ℕ} (P : Fin n → Fin d → ℝ) (m : Fin d → ℝ)
    (α : ℝ) (hα : 0 < α) :
    IsCoordinateMedian m P ↔
    IsCoordinateMedian (fun j => α * m j) (fun (i : Fin n) (j : Fin d) => α * P i j) := by
  unfold IsCoordinateMedian
  refine forall_congr' (fun j => ?_)
  have hlt : (Finset.univ.filter (fun i : Fin n => P i j < m j)) =
      (Finset.univ.filter (fun i : Fin n => α * P i j < α * m j)) := by
    apply Finset.filter_congr; intros i _
    constructor
    · intro h; exact mul_lt_mul_of_pos_left h hα
    · intro h; exact lt_of_mul_lt_mul_left h hα.le
  have hgt : (Finset.univ.filter (fun i : Fin n => P i j > m j)) =
      (Finset.univ.filter (fun i : Fin n => α * P i j > α * m j)) := by
    apply Finset.filter_congr; intros i _
    constructor
    · intro h; exact mul_lt_mul_of_pos_left h hα
    · intro h; exact lt_of_mul_lt_mul_left h hα.le
  rw [hlt, hgt]

/-- `augment` commutes with a pointwise affine transform `g j * (· - m j)`
applied to every report and to the appended point `pred` simultaneously:
transforming the augmented instance equals augmenting the transformed instance.
(Generic over the appended point; here applied to `pred`.) -/
private lemma augment_transform {n d : ℕ} (P : Fin n → Fin d → ℝ)
    (pred m : Fin d → ℝ) (g : Fin d → ℝ) (k : ℕ) :
    (fun (i : Fin (n + k)) (j : Fin d) =>
        g j * (augment P pred k i j - m j))
      = augment (fun (i : Fin n) (j : Fin d) => g j * (P i j - m j))
          (fun j => g j * (pred j - m j)) k := by
  funext i j
  unfold augment
  refine Fin.addCases ?_ ?_ i <;> intro i' <;> simp

theorem RGTranslationScaleNormalize
    (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1)
    (h_norm : ∀ {n d : ℕ}, 0 < n → Even (n + ⌊c * (n : ℝ)⌋₊) → 1 ≤ d →
      (⌊c * (n : ℝ)⌋₊ : ℝ) = c * (n : ℝ) →
      ∀ (P_norm : Fin n → Fin d → ℝ),
      ∀ (pred : Fin d → ℝ), (∀ j, pred j ≠ 0) →
      ∀ (f : Fin d → ℝ), (∀ j, 0 ≤ f j) → (∀ j, 0 < f j) → lqNorm 2 f = 1 →
      IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
        (augment P_norm pred (⌊c * (n : ℝ)⌋₊)) →
      socialCost 2 P_norm (fun (_ : Fin d) => (0 : ℝ))
        ≤ Workspace.RobustnessTheorem.RG c * socialCost 2 P_norm f) :
    ∀ {n d : ℕ}, 0 < n → Even (n + ⌊c * (n : ℝ)⌋₊) → 1 ≤ d →
      (⌊c * (n : ℝ)⌋₊ : ℝ) = c * (n : ℝ) →
      ∀ (P : Fin n → Fin d → ℝ) (pred : Fin d → ℝ) (fstar : Fin d → ℝ),
        socialCost 2 P fstar = optSocialCost 2 P →
        0 < optSocialCost 2 P →
      ∀ (m : Fin d → ℝ),
        IsCoordinateMedian m (augment P pred (⌊c * (n : ℝ)⌋₊)) →
        (∀ j, fstar j ≠ m j) →
        (∀ j, pred j ≠ m j) →
        socialCost 2 P m ≤ Workspace.RobustnessTheorem.RG c * optSocialCost 2 P := by
  intro n d hn hne hd hcn P pred fstar hsc_fstar hopt m hm hgp hgp_pred
  have hq : (1 : ℝ) ≤ 2 := by norm_num
  set k : ℕ := ⌊c * (n : ℝ)⌋₊ with hk_def
  set OPT : ℝ := optSocialCost 2 P with hOPT_def
  have hOPT_pos : 0 < OPT := hopt
  have hOPT_nn : 0 ≤ OPT := le_of_lt hOPT_pos
  -- v = fstar - m: optimum after translating m to 0.
  set v : Fin d → ℝ := fun j => fstar j - m j with hv_def
  classical
  set eps : Fin d → ℝ := fun j => if 0 ≤ v j then 1 else -1 with heps_def
  have heps_pm : ∀ j, eps j = 1 ∨ eps j = -1 := by
    intro j
    rw [heps_def]
    by_cases h : 0 ≤ v j
    · simp [h]
    · simp [h]
  have heps_v_nonneg : ∀ j, 0 ≤ eps j * v j := by
    intro j
    rw [heps_def]
    by_cases h : 0 ≤ v j
    · simp [h]
    · simp [h]
      have : v j < 0 := lt_of_not_ge h
      linarith
  -- General position of the optimum: v j = fstar j - m j ≠ 0.
  have hv_ne : ∀ j, v j ≠ 0 := by
    intro j hvj
    have : fstar j - m j = 0 := by rw [hv_def] at hvj; exact hvj
    exact hgp j (sub_eq_zero.mp this)
  have heps_v_pos : ∀ j, 0 < eps j * v j := by
    intro j
    have hne : eps j * v j ≠ 0 := by
      rw [heps_def]
      by_cases h : 0 ≤ v j
      · simp only [h, if_true, one_mul]; exact hv_ne j
      · simp only [h, if_false, neg_one_mul, neg_ne_zero]; exact hv_ne j
    exact lt_of_le_of_ne (heps_v_nonneg j) (Ne.symm hne)
  -- General position of the prediction: w j = pred j - m j ≠ 0.
  set w : Fin d → ℝ := fun j => pred j - m j with hw_def
  have hw_ne : ∀ j, w j ≠ 0 := by
    intro j hwj
    have : pred j - m j = 0 := by rw [hw_def] at hwj; exact hwj
    exact hgp_pred j (sub_eq_zero.mp this)
  -- P_tr_refl i j = eps j * (P i j - m j); v_refl j = eps j * v j > 0.
  set P_tr_refl : Fin n → Fin d → ℝ := fun i j => eps j * (P i j - m j) with hP_tr_def
  set v_refl : Fin d → ℝ := fun j => eps j * v j with hv_refl_def
  have hv_refl_nn : ∀ j, 0 ≤ v_refl j := heps_v_nonneg
  have hv_refl_pos : ∀ j, 0 < v_refl j := heps_v_pos
  -- pred_refl j = eps j * w j: the reflected prediction.  Nonzero by general position.
  set pred_refl : Fin d → ℝ := fun j => eps j * w j with hpred_refl_def
  have hpred_refl_ne : ∀ j, pred_refl j ≠ 0 := by
    intro j
    show eps j * w j ≠ 0
    rcases heps_pm j with h1 | h1
    · rw [h1, one_mul]; exact hw_ne j
    · rw [h1, neg_one_mul, neg_ne_zero]; exact hw_ne j
  -- Median 0 of the *augmented* translated+reflected instance.
  -- Q := augment P pred k; transport median m of Q to median 0 of the transform.
  have hmed_aug_tr : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
      (fun (i : Fin (n + k)) (j : Fin d) => augment P pred k i j - m j) := by
    have h1 := (MedianTranslationInvariance (augment P pred k) m m).mp hm
    have heq : (fun j => m j - m j) = (fun (_ : Fin d) => (0 : ℝ)) := by
      funext j; ring
    rw [heq] at h1
    exact h1
  have hmed_aug_tr_refl : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
      (fun (i : Fin (n + k)) (j : Fin d) => eps j * (augment P pred k i j - m j)) := by
    exact MedianCoordinateReflection
      (fun i j => augment P pred k i j - m j) eps heps_pm hmed_aug_tr
  -- SC(P_tr_refl, v_refl) = OPT.
  have hsc_tr_refl : socialCost 2 P_tr_refl v_refl = OPT := by
    have h1 : socialCost 2 (fun (i : Fin n) (j : Fin d) => P i j - m j) v
              = socialCost 2 P fstar := by
      have := SocialCostTranslationInvariance 2 P m fstar
      convert this using 2
    have h2 : socialCost 2 P_tr_refl v_refl =
              socialCost 2 (fun i j => P i j - m j) v := by
      rw [hP_tr_def, hv_refl_def]
      exact socialCost_coord_reflection 2 eps heps_pm _ _
    rw [h2, h1, hsc_fstar]
  -- SC(P_tr_refl, 0) = SC(P, m).
  have hsc_tr_refl_0 : socialCost 2 P_tr_refl (fun (_ : Fin d) => (0 : ℝ))
      = socialCost 2 P m := by
    have h1 : socialCost 2 P_tr_refl (fun (_ : Fin d) => (0 : ℝ))
              = socialCost 2 (fun (i : Fin n) (j : Fin d) => P i j - m j)
                  (fun (_ : Fin d) => (0 : ℝ)) := by
      rw [hP_tr_def]
      have heq : (fun (_ : Fin d) => (0 : ℝ)) = (fun (j : Fin d) => eps j * 0) := by
        funext j; ring
      conv_lhs => rw [heq]
      exact socialCost_coord_reflection 2 eps heps_pm _ _
    have h2 : socialCost 2 (fun (i : Fin n) (j : Fin d) => P i j - m j)
                (fun (_ : Fin d) => (0 : ℝ)) = socialCost 2 P m := by
      have := SocialCostTranslationInvariance 2 P m m
      have heq : (fun j => m j - m j) = (fun (_ : Fin d) => (0 : ℝ)) := by
        funext j; ring
      rw [heq] at this
      exact this
    rw [h1, h2]
  -- Case split on the norm of v_refl.
  set u : ℝ := lqNorm 2 v_refl with hu_def
  have hu_nn : 0 ≤ u := lqNorm_nonneg hq _
  by_cases hu_zero : u = 0
  · -- Degenerate: v_refl = 0, so fstar = m, so OPT = SC(P, m).
    have hv_refl_eq_zero : v_refl = (fun _ => 0) := by
      have := (LqNormZeroIffEqZero 2 hq hd v_refl).mp hu_zero
      ext j
      have := congr_fun this j
      simpa using this
    have hv_zero : ∀ j, v j = 0 := by
      intro j
      have hvr : eps j * v j = 0 := by
        have := congr_fun hv_refl_eq_zero j
        simpa [hv_refl_def] using this
      rcases heps_pm j with h1 | h1
      · rw [h1] at hvr; linarith
      · rw [h1] at hvr; linarith
    have hfstar_eq_m : fstar = m := by
      funext j
      have := hv_zero j
      simp [hv_def] at this
      linarith
    have hSC_eq_OPT : socialCost 2 P m = OPT := by
      rw [← hfstar_eq_m]
      exact hsc_fstar
    rw [hSC_eq_OPT]
    have hRG_ge_one : 1 ≤ Workspace.RobustnessTheorem.RG c :=
      (Workspace.ProofLemmas.RGLambda2InUnitInterval.RGLambda2InUnitInterval c hc0 hc1).2.2.le
    nlinarith [hOPT_pos]
  · -- Generic: u > 0. Scale by σ = 1/u.
    have hu_pos : 0 < u := lt_of_le_of_ne hu_nn (Ne.symm hu_zero)
    set σ : ℝ := 1 / u with hσ_def
    have hσ_pos : 0 < σ := by rw [hσ_def]; positivity
    have hσ_nn : 0 ≤ σ := le_of_lt hσ_pos
    set P_norm : Fin n → Fin d → ℝ := fun i j => σ * P_tr_refl i j with hP_norm_def
    set f_norm : Fin d → ℝ := fun j => σ * v_refl j with hf_norm_def
    -- The normalized prediction: pred_norm j = σ * pred_refl j.
    set pred_norm : Fin d → ℝ := fun j => σ * pred_refl j with hpred_norm_def
    -- pred_norm in general position.
    have hpred_norm_ne : ∀ j, pred_norm j ≠ 0 := by
      intro j
      rw [hpred_norm_def]
      exact mul_ne_zero (ne_of_gt hσ_pos) (hpred_refl_ne j)
    -- Median 0 of the augmented normalized instance (appended copies sit at pred_norm).
    have hmed_aug_norm : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
        (augment P_norm pred_norm k) := by
      have hscale := (median_scale
        (fun (i : Fin (n + k)) (j : Fin d) => eps j * (augment P pred k i j - m j))
        (fun (_ : Fin d) => (0 : ℝ)) σ hσ_pos).mp hmed_aug_tr_refl
      have heq0 : (fun j => σ * (0 : ℝ)) = (fun (_ : Fin d) => (0 : ℝ)) := by
        funext j; ring
      rw [heq0] at hscale
      -- Rewrite the scaled+reflected augmented instance as augment of P_norm/pred_norm.
      have hcomm := augment_transform P pred m (fun j => σ * eps j) k
      have hinst : (fun (i : Fin (n + k)) (j : Fin d) =>
            σ * (eps j * (augment P pred k i j - m j)))
          = augment P_norm pred_norm k := by
        rw [hP_norm_def, hpred_norm_def, hP_tr_def, hpred_refl_def, hw_def]
        rw [show (fun (i : Fin (n + k)) (j : Fin d) =>
              σ * (eps j * (augment P pred k i j - m j)))
            = (fun (i : Fin (n + k)) (j : Fin d) =>
              (fun j => σ * eps j) j * (augment P pred k i j - m j)) by
          funext i j; ring]
        rw [hcomm]
        congr 1
        · funext i j; ring
        · funext j; ring
      rw [hinst] at hscale
      exact hscale
    -- f_norm ≥ 0.
    have hf_norm_nn : ∀ j, 0 ≤ f_norm j := by
      intro j
      rw [hf_norm_def]
      exact mul_nonneg hσ_nn (hv_refl_nn j)
    -- f_norm > 0 (general position): each coordinate is σ·v_refl j with σ, v_refl j > 0.
    have hf_norm_pos : ∀ j, 0 < f_norm j := by
      intro j
      rw [hf_norm_def]
      exact mul_pos hσ_pos (hv_refl_pos j)
    -- lqNorm 2 f_norm = 1.
    have hf_norm_unit : lqNorm 2 f_norm = 1 := by
      rw [hf_norm_def]
      rw [lqNorm_smul hq σ v_refl]
      rw [abs_of_nonneg hσ_nn]
      rw [hσ_def, ← hu_def]
      field_simp
    -- SC(P_norm, f_norm) = σ * OPT.
    have hsc_norm : socialCost 2 P_norm f_norm = σ * OPT := by
      rw [hP_norm_def, hf_norm_def]
      rw [socialCost_scale hq σ hσ_nn P_tr_refl v_refl]
      rw [hsc_tr_refl]
    -- SC(P_norm, 0) = σ * SC(P, m).
    have hsc_norm_0 : socialCost 2 P_norm (fun (_ : Fin d) => (0 : ℝ))
        = σ * socialCost 2 P m := by
      rw [hP_norm_def]
      have heq : (fun (_ : Fin d) => (0 : ℝ)) = (fun j => σ * 0) := by
        funext j; ring
      conv_lhs => rw [heq]
      rw [socialCost_scale hq σ hσ_nn P_tr_refl _]
      rw [hsc_tr_refl_0]
    -- Apply h_norm with pred := pred_norm, f := f_norm.
    have happ : socialCost 2 P_norm (fun (_ : Fin d) => (0 : ℝ))
                ≤ Workspace.RobustnessTheorem.RG c * socialCost 2 P_norm f_norm :=
      h_norm hn hne hd hcn P_norm pred_norm hpred_norm_ne f_norm hf_norm_nn hf_norm_pos
        hf_norm_unit hmed_aug_norm
    rw [hsc_norm_0, hsc_norm] at happ
    have happ' : σ * socialCost 2 P m ≤ σ * (Workspace.RobustnessTheorem.RG c * OPT) := by
      nlinarith [happ]
    exact le_of_mul_le_mul_left happ' hσ_pos

end Workspace.ProofLemmas.RGTranslationScaleNormalize

open Workspace.Types.CoordinateMedian
open Workspace.ConsistencyTheorem
open Finset

set_option maxHeartbeats 1000000

namespace Workspace.ProofLemmas.RGMedianConstraintFromAugment

theorem RGMedianConstraintFromAugment
    {n d : ℕ} (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1)
    (hne : Even (n + ⌊c * (n : ℝ)⌋₊))
    (f : Fin d → ℝ) (hf_sum : (∑ j, (f j) ^ (2 : ℝ)) = 1)
    (pred : Fin d → ℝ) (hpred_gp : ∀ j, pred j ≠ 0)
    (s : Fin d → ℝ) (hs_pm : ∀ j, s j = 1 ∨ s j = -1)
    (hs_pos : ∀ j, pred j > 0 → s j = 1) (hs_neg : ∀ j, pred j < 0 → s j = -1)
    (P : Fin n → Fin d → ℝ)
    (hP : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
            (augment P pred (⌊c * (n : ℝ)⌋₊))) :
    ∃ sigma : Fin n → Fin d → ℝ,
      (∀ i j, sigma i j = 1 ∨ sigma i j = -1) ∧
      (∀ i j, P i j > 0 → sigma i j = 1) ∧
      (∀ i j, P i j < 0 → sigma i j = -1) ∧
      (∀ j, ∑ i, sigma i j = -(⌊c * (n : ℝ)⌋₊ : ℝ) * s j) ∧
      (∀ j, (((Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1)).card : ℝ) * 2
              = (n : ℝ) - (⌊c * (n : ℝ)⌋₊ : ℝ) * s j) := by
  classical
  set k : ℕ := ⌊c * (n : ℝ)⌋₊ with hk_def
  -- k ≤ n, since c < 1.
  have hk_le_n : k ≤ n := by
    rw [hk_def]
    rcases Nat.eq_zero_or_pos n with hn0 | hn0
    · subst hn0; simp
    · have hcn_lt : c * (n : ℝ) < (n : ℝ) := by
        have : c * (n : ℝ) < 1 * (n : ℝ) := by
          apply mul_lt_mul_of_pos_right hc1
          exact_mod_cast hn0
        simpa using this
      have hcn_nonneg : 0 ≤ c * (n : ℝ) := mul_nonneg hc0 (by positivity)
      have : (⌊c * (n : ℝ)⌋₊ : ℝ) ≤ c * (n : ℝ) := Nat.floor_le hcn_nonneg
      have hlt : (⌊c * (n : ℝ)⌋₊ : ℝ) < (n : ℝ) := lt_of_le_of_lt this hcn_lt
      have : (⌊c * (n : ℝ)⌋₊ : ℕ) < n := by exact_mod_cast hlt
      omega
  -- Per-coordinate original sets.
  set posSet : Fin d → Finset (Fin n) :=
    fun j => Finset.univ.filter (fun i => P i j > 0) with hposSet
  set negSet : Fin d → Finset (Fin n) :=
    fun j => Finset.univ.filter (fun i => P i j < 0) with hnegSet
  set zeroSet : Fin d → Finset (Fin n) :=
    fun j => Finset.univ.filter (fun i => P i j = 0) with hzeroSet
  have hpos_mem : ∀ {i j}, i ∈ posSet j ↔ P i j > 0 := by
    intro i j; simp [hposSet]
  have hneg_mem : ∀ {i j}, i ∈ negSet j ↔ P i j < 0 := by
    intro i j; simp [hnegSet]
  have hzero_mem : ∀ {i j}, i ∈ zeroSet j ↔ P i j = 0 := by
    intro i j; simp [hzeroSet]
  -- Augmented "< 0" count.
  have haug_neg_pos_pred : ∀ j, pred j > 0 →
      ((Finset.univ : Finset (Fin (n + k))).filter
        (fun i => augment P pred k i j < 0)).card = (negSet j).card := by
    intro j hpredj
    symm
    apply Finset.card_bij (fun (i : Fin n) _ => (Fin.castAdd k i : Fin (n + k)))
    · intro i hi
      rw [hneg_mem] at hi
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      simpa [augment, Fin.addCases_left] using hi
    · intro a _ b _ hab
      exact Fin.castAdd_injective _ _ hab
    · intro i hi
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hi
      refine Fin.addCases (motive := fun i => (augment P pred k i j < 0) →
        ∃ a, ∃ (_ : a ∈ negSet j), Fin.castAdd k a = i) ?_ ?_ i hi
      · intro a ha
        refine ⟨a, ?_, rfl⟩
        rw [hneg_mem]
        simpa [augment, Fin.addCases_left] using ha
      · intro a ha
        exfalso
        have : pred j < 0 := by simpa [augment, Fin.addCases_right] using ha
        linarith
  have haug_pos_pos_pred : ∀ j, pred j > 0 →
      ((Finset.univ : Finset (Fin (n + k))).filter
        (fun i => augment P pred k i j > 0)).card = (posSet j).card + k := by
    intro j hpredj
    rw [Finset.card_filter]
    rw [Fin.sum_univ_add]
    have hleft : (∑ i : Fin n, if augment P pred k (Fin.castAdd k i) j > 0 then 1 else 0)
        = (posSet j).card := by
      rw [hposSet]
      rw [Finset.card_filter]
      apply Finset.sum_congr rfl
      intro i _
      simp [augment, Fin.addCases_left]
    have hright : (∑ i : Fin k, if augment P pred k (Fin.natAdd n i) j > 0 then 1 else 0)
        = k := by
      have : ∀ i : Fin k, (if augment P pred k (Fin.natAdd n i) j > 0 then (1 : ℕ) else 0) = 1 := by
        intro i
        have heq : augment P pred k (Fin.natAdd n i) j = pred j := by
          simp [augment, Fin.addCases_right]
        rw [heq]
        simp [hpredj]
      rw [Finset.sum_congr rfl (fun i _ => this i)]
      simp
    rw [hleft, hright]
  -- For pred j < 0.
  have haug_pos_neg_pred : ∀ j, pred j < 0 →
      ((Finset.univ : Finset (Fin (n + k))).filter
        (fun i => augment P pred k i j > 0)).card = (posSet j).card := by
    intro j hpredj
    symm
    apply Finset.card_bij (fun (i : Fin n) _ => (Fin.castAdd k i : Fin (n + k)))
    · intro i hi
      rw [hpos_mem] at hi
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      simpa [augment, Fin.addCases_left] using hi
    · intro a _ b _ hab
      exact Fin.castAdd_injective _ _ hab
    · intro i hi
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hi
      refine Fin.addCases (motive := fun i => (augment P pred k i j > 0) →
        ∃ a, ∃ (_ : a ∈ posSet j), Fin.castAdd k a = i) ?_ ?_ i hi
      · intro a ha
        refine ⟨a, ?_, rfl⟩
        rw [hpos_mem]
        simpa [augment, Fin.addCases_left] using ha
      · intro a ha
        exfalso
        have : pred j > 0 := by simpa [augment, Fin.addCases_right] using ha
        linarith
  have haug_neg_neg_pred : ∀ j, pred j < 0 →
      ((Finset.univ : Finset (Fin (n + k))).filter
        (fun i => augment P pred k i j < 0)).card = (negSet j).card + k := by
    intro j hpredj
    rw [Finset.card_filter]
    rw [Fin.sum_univ_add]
    have hleft : (∑ i : Fin n, if augment P pred k (Fin.castAdd k i) j < 0 then 1 else 0)
        = (negSet j).card := by
      rw [hnegSet]
      rw [Finset.card_filter]
      apply Finset.sum_congr rfl
      intro i _
      simp [augment, Fin.addCases_left]
    have hright : (∑ i : Fin k, if augment P pred k (Fin.natAdd n i) j < 0 then 1 else 0)
        = k := by
      have : ∀ i : Fin k, (if augment P pred k (Fin.natAdd n i) j < 0 then (1 : ℕ) else 0) = 1 := by
        intro i
        have heq : augment P pred k (Fin.natAdd n i) j = pred j := by
          simp [augment, Fin.addCases_right]
        rw [heq]
        simp [hpredj]
      rw [Finset.sum_congr rfl (fun i _ => this i)]
      simp
    rw [hleft, hright]
  -- Disjointness and partition (sign-independent).
  have hpos_neg_disj : ∀ j, Disjoint (posSet j) (negSet j) := by
    intro j; rw [hposSet, hnegSet, Finset.disjoint_filter]
    intros i _ hpi hni; linarith
  have hpos_zero_disj : ∀ j, Disjoint (posSet j) (zeroSet j) := by
    intro j; rw [hposSet, hzeroSet, Finset.disjoint_filter]
    intros i _ hpi hzi; linarith
  have hneg_zero_disj : ∀ j, Disjoint (negSet j) (zeroSet j) := by
    intro j; rw [hnegSet, hzeroSet, Finset.disjoint_filter]
    intros i _ hni hzi; linarith
  have hunion : ∀ j,
      (posSet j) ∪ (negSet j) ∪ (zeroSet j) = (Finset.univ : Finset (Fin n)) := by
    intro j
    apply Finset.eq_univ_of_forall
    intro i
    rcases lt_trichotomy (P i j) 0 with h | h | h
    · apply Finset.mem_union.mpr; left
      apply Finset.mem_union.mpr; right
      exact hneg_mem.mpr h
    · apply Finset.mem_union.mpr; right
      exact hzero_mem.mpr h
    · apply Finset.mem_union.mpr; left
      apply Finset.mem_union.mpr; left
      exact hpos_mem.mpr h
  have hcard_sum : ∀ j, (posSet j).card + (negSet j).card + (zeroSet j).card = n := by
    intro j
    have hd1 : Disjoint (posSet j ∪ negSet j) (zeroSet j) := by
      rw [Finset.disjoint_union_left]
      exact ⟨hpos_zero_disj j, hneg_zero_disj j⟩
    have h1 : ((posSet j ∪ negSet j) ∪ zeroSet j).card =
        (posSet j ∪ negSet j).card + (zeroSet j).card :=
      Finset.card_union_of_disjoint hd1
    have h2 : (posSet j ∪ negSet j).card = (posSet j).card + (negSet j).card :=
      Finset.card_union_of_disjoint (hpos_neg_disj j)
    have h3 : ((posSet j ∪ negSet j) ∪ zeroSet j).card = n := by
      rw [hunion j]; simp
    omega
  -- Parity: n + k even.
  obtain ⟨w, hw⟩ := hne
  have hnk2 : 2 * ((n + k) / 2) = n + k := by rw [hk_def] at hw ⊢; omega
  -- Per coordinate: define a target count `tcount j` = number of +1 zeros to pick.
  -- tcount = (target+ count) - |posSet|, where target+ = (n - k·s j)/2 as a nat:
  --   s j = 1 -> (n-k)/2 ; s j = -1 -> (n+k)/2.
  -- Build everything per coordinate with a case split on the sign of pred j.
  -- We produce the full sigma via choosing T j ⊆ zeroSet j of the right card.
  -- First, the required nat cardinality bound for T (feasibility) in each case.
  have hexT : ∀ j, ∃ T : Finset (Fin n), T ⊆ zeroSet j ∧
      ((pred j > 0 → T.card = (n - k) / 2 - (posSet j).card) ∧
       (pred j < 0 → T.card = (n + k) / 2 - (posSet j).card)) := by
    intro j
    rcases lt_trichotomy (pred j) 0 with hlt | heq | hgt
    · -- pred j < 0 : target = (n+k)/2 - |posSet|
      have hpos_bd : (posSet j).card ≤ (n + k) / 2 := by
        have h := (hP j).2
        rw [haug_pos_neg_pred j hlt] at h
        exact h
      have hu_le : (n + k) / 2 - (posSet j).card ≤ (zeroSet j).card := by
        have hneg_bd : (negSet j).card + k ≤ (n + k) / 2 := by
          have h := (hP j).1
          rw [haug_neg_neg_pred j hlt] at h
          exact h
        have hsum := hcard_sum j
        omega
      obtain ⟨T, hTsub, hTcard⟩ := Finset.exists_subset_card_eq hu_le
      refine ⟨T, hTsub, ?_, ?_⟩
      · intro hh; linarith
      · intro _; exact hTcard
    · exact absurd heq (hpred_gp j)
    · -- pred j > 0 : target = (n-k)/2 - |posSet|
      have hpos_bd : (posSet j).card + k ≤ (n + k) / 2 := by
        have h := (hP j).2
        rw [haug_pos_pos_pred j hgt] at h
        exact h
      have hu_le : (n - k) / 2 - (posSet j).card ≤ (zeroSet j).card := by
        have hneg_bd : (negSet j).card ≤ (n + k) / 2 := by
          have h := (hP j).1
          rw [haug_neg_pos_pred j hgt] at h
          exact h
        have hsum := hcard_sum j
        omega
      obtain ⟨T, hTsub, hTcard⟩ := Finset.exists_subset_card_eq hu_le
      refine ⟨T, hTsub, ?_, ?_⟩
      · intro _; exact hTcard
      · intro hh; linarith
  let T : Fin d → Finset (Fin n) := fun j => (hexT j).choose
  have hT_sub : ∀ j, T j ⊆ zeroSet j := fun j => (hexT j).choose_spec.1
  have hT_card_pos : ∀ j, pred j > 0 → (T j).card = (n - k) / 2 - (posSet j).card :=
    fun j => (hexT j).choose_spec.2.1
  have hT_card_neg : ∀ j, pred j < 0 → (T j).card = (n + k) / 2 - (posSet j).card :=
    fun j => (hexT j).choose_spec.2.2
  -- Define the signature.
  refine ⟨fun i j => if P i j > 0 then (1 : ℝ)
                     else if P i j < 0 then (-1 : ℝ)
                     else if i ∈ T j then (1 : ℝ) else (-1 : ℝ), ?_, ?_, ?_, ?_, ?_⟩
  · intro i j
    by_cases h1 : P i j > 0
    · left; simp [h1]
    · by_cases h2 : P i j < 0
      · right; simp [h1, h2]
      · by_cases h3 : i ∈ T j
        · left; simp [h1, h2, h3]
        · right; simp [h1, h2, h3]
  · intro i j hij; simp [hij]
  · intro i j hij
    have h1 : ¬ P i j > 0 := by linarith
    simp [h1, hij]
  · -- Sum equals -k·s j per coordinate.
    intro j
    -- general signature-sum value via T-count, in ℝ.
    have hsigma_pos : ∀ i ∈ posSet j,
        (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1 else if i ∈ T j then 1 else -1) = 1 := by
      intros i hi
      have h := hpos_mem.mp hi
      simp [h]
    have hsigma_neg : ∀ i ∈ negSet j,
        (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1 else if i ∈ T j then 1 else -1) = -1 := by
      intros i hi
      have h := hneg_mem.mp hi
      have h1 : ¬ P i j > 0 := by linarith
      simp [h1, h]
    have hsigma_zero_in : ∀ i ∈ T j,
        (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1 else if i ∈ T j then 1 else -1) = 1 := by
      intros i hT
      have hi : i ∈ zeroSet j := hT_sub j hT
      have h := hzero_mem.mp hi
      have h1 : ¬ P i j > 0 := by linarith
      have h2 : ¬ P i j < 0 := by linarith
      simp [h1, h2, hT]
    have hsigma_zero_out : ∀ i ∈ zeroSet j \ T j,
        (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1 else if i ∈ T j then 1 else -1) = -1 := by
      intros i hi
      have hi1 : i ∈ zeroSet j := (Finset.mem_sdiff.mp hi).1
      have hi2 : i ∉ T j := (Finset.mem_sdiff.mp hi).2
      have h := hzero_mem.mp hi1
      have h1 : ¬ P i j > 0 := by linarith
      have h2 : ¬ P i j < 0 := by linarith
      simp [h1, h2, hi2]
    have hpart : (Finset.univ : Finset (Fin n)) = (posSet j ∪ negSet j) ∪ zeroSet j :=
      (hunion j).symm
    have hd1 : Disjoint (posSet j ∪ negSet j) (zeroSet j) := by
      rw [Finset.disjoint_union_left]
      exact ⟨hpos_zero_disj j, hneg_zero_disj j⟩
    have hT_le_zs : (T j).card ≤ (zeroSet j).card := Finset.card_le_card (hT_sub j)
    have hsdiff_real : ((zeroSet j \ T j).card : ℝ) =
        ((zeroSet j).card : ℝ) - ((T j).card : ℝ) := by
      rw [Finset.card_sdiff_of_subset (hT_sub j), Nat.cast_sub hT_le_zs]
    have hd2 : Disjoint (T j) (zeroSet j \ T j) := Finset.disjoint_sdiff
    have hzs_eq : zeroSet j = T j ∪ (zeroSet j \ T j) := by
      rw [Finset.union_sdiff_of_subset (hT_sub j)]
    have hzero_sum :
        ∑ i ∈ zeroSet j, (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1
              else if i ∈ T j then 1 else -1)
        = ((T j).card : ℝ) - ((zeroSet j \ T j).card : ℝ) := by
      conv_lhs => rw [hzs_eq]
      rw [Finset.sum_union hd2]
      rw [Finset.sum_congr rfl hsigma_zero_in]
      rw [Finset.sum_congr rfl hsigma_zero_out]
      rw [Finset.sum_const, Finset.sum_const]
      simp only [smul_eq_mul, mul_one, mul_neg_one, nsmul_eq_mul]
      ring
    have hsum_val :
        ∑ i, (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1
              else if i ∈ T j then 1 else -1)
        = ((posSet j).card : ℝ) - ((negSet j).card : ℝ)
          + (((T j).card : ℝ) - ((zeroSet j \ T j).card : ℝ)) := by
      rw [hpart, Finset.sum_union hd1, Finset.sum_union (hpos_neg_disj j)]
      rw [Finset.sum_congr rfl hsigma_pos]
      rw [Finset.sum_congr rfl hsigma_neg]
      rw [hzero_sum]
      rw [Finset.sum_const, Finset.sum_const]
      simp only [smul_eq_mul, mul_one, mul_neg_one, nsmul_eq_mul]
      ring
    rw [hsum_val, hsdiff_real]
    -- Now branch on sign of pred j.
    rcases lt_trichotomy (pred j) 0 with hlt | heq | hgt
    · -- s j = -1 ; sum should be -k·(-1) = k
      have hsj : s j = -1 := hs_neg j hlt
      rw [hsj]
      have hTc := hT_card_neg j hlt
      have hpos_le : (posSet j).card ≤ (n + k) / 2 := by
        have h := (hP j).2
        rw [haug_pos_neg_pred j hlt] at h; exact h
      -- |T| = (n+k)/2 - |posSet| ; |zeroSet| = n - |posSet| - |negSet|
      have hTreal : ((T j).card : ℝ) = (((n + k) / 2 : ℕ) : ℝ) - ((posSet j).card : ℝ) := by
        rw [hTc]; push_cast [Nat.cast_sub hpos_le]; ring
      have hzs_real : ((zeroSet j).card : ℝ) =
          (n : ℝ) - ((posSet j).card : ℝ) - ((negSet j).card : ℝ) := by
        have : ((posSet j).card : ℝ) + ((negSet j).card : ℝ) + ((zeroSet j).card : ℝ) = (n : ℝ) := by
          exact_mod_cast hcard_sum j
        linarith
      have hnk_real : (((n + k) / 2 : ℕ) : ℝ) * 2 = (n : ℝ) + (k : ℝ) := by
        have h2 : (2 : ℝ) * (((n + k) / 2 : ℕ) : ℝ) = ((n + k : ℕ) : ℝ) := by
          exact_mod_cast hnk2
        rw [Nat.cast_add] at h2; linarith
      -- Need: |negSet| relation. From median, |negSet|+k ≤ (n+k)/2 isn't enough; we need exact.
      -- Actually sum = |pos| - |neg| + (2|T| - |zero|). With |T|=(n+k)/2-|pos|, |zero|=n-|pos|-|neg|:
      --   = |pos| - |neg| + (n+k) - 2|pos| - (n - |pos| - |neg|) = |pos| - |neg| + k + |neg| = |pos| ...
      -- recompute: 2|T| - |zero| = (n+k) - 2|pos| - n + |pos| + |neg| = k - |pos| + |neg|
      -- sum = |pos| - |neg| + k - |pos| + |neg| = k. Good, = k = -k·(-1).
      rw [hTreal, hzs_real]
      have hk_real : ((k : ℕ) : ℝ) = (k : ℝ) := rfl
      nlinarith [hnk_real]
    · exact absurd heq (hpred_gp j)
    · -- s j = 1 ; sum should be -k
      have hsj : s j = 1 := hs_pos j hgt
      rw [hsj]
      have hTc := hT_card_pos j hgt
      have hpos_le : (posSet j).card ≤ (n - k) / 2 := by
        have h := (hP j).2
        rw [haug_pos_pos_pred j hgt] at h; omega
      have hTreal : ((T j).card : ℝ) = (((n - k) / 2 : ℕ) : ℝ) - ((posSet j).card : ℝ) := by
        rw [hTc]; push_cast [Nat.cast_sub hpos_le]; ring
      have hzs_real : ((zeroSet j).card : ℝ) =
          (n : ℝ) - ((posSet j).card : ℝ) - ((negSet j).card : ℝ) := by
        have : ((posSet j).card : ℝ) + ((negSet j).card : ℝ) + ((zeroSet j).card : ℝ) = (n : ℝ) := by
          exact_mod_cast hcard_sum j
        linarith
      have hnmk2 : 2 * ((n - k) / 2) = n - k := by omega
      have hnmk_real : (((n - k) / 2 : ℕ) : ℝ) * 2 = (n : ℝ) - (k : ℝ) := by
        have hkn : k ≤ n := hk_le_n
        have h2 : (2 : ℝ) * (((n - k) / 2 : ℕ) : ℝ) = ((n - k : ℕ) : ℝ) := by
          exact_mod_cast hnmk2
        have : ((n - k : ℕ) : ℝ) = (n : ℝ) - (k : ℝ) := by rw [Nat.cast_sub hkn]
        linarith
      rw [hTreal, hzs_real]
      nlinarith [hnmk_real]
  · -- Count of +1 signs.
    intro j
    have hset_eq : ((Finset.univ : Finset (Fin n)).filter
        (fun i => (if P i j > 0 then (1 : ℝ) else if P i j < 0 then -1
                   else if i ∈ T j then 1 else -1) = 1))
        = posSet j ∪ T j := by
      ext i
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_union]
      constructor
      · intro hi
        by_cases h1 : P i j > 0
        · left; exact hpos_mem.mpr h1
        · by_cases h2 : P i j < 0
          · exfalso
            rw [if_neg h1, if_pos h2] at hi
            norm_num at hi
          · by_cases h3 : i ∈ T j
            · right; exact h3
            · exfalso
              rw [if_neg h1, if_neg h2, if_neg h3] at hi
              norm_num at hi
      · intro hi
        rcases hi with hi | hi
        · have h1 : P i j > 0 := hpos_mem.mp hi
          simp [h1]
        · have hz : i ∈ zeroSet j := hT_sub j hi
          have h := hzero_mem.mp hz
          have h1 : ¬ P i j > 0 := by linarith
          have h2 : ¬ P i j < 0 := by linarith
          simp [h1, h2, hi]
    rw [hset_eq]
    have hdisj : Disjoint (posSet j) (T j) := by
      apply Finset.disjoint_left.mpr
      intro i hip hiT
      have hz : i ∈ zeroSet j := hT_sub j hiT
      have hpij : P i j > 0 := hpos_mem.mp hip
      have hzij : P i j = 0 := hzero_mem.mp hz
      linarith
    rw [Finset.card_union_of_disjoint hdisj]
    -- Branch on sign.
    rcases lt_trichotomy (pred j) 0 with hlt | heq | hgt
    · have hsj : s j = -1 := hs_neg j hlt
      rw [hsj]
      have hTc := hT_card_neg j hlt
      have hpos_le : (posSet j).card ≤ (n + k) / 2 := by
        have h := (hP j).2
        rw [haug_pos_neg_pred j hlt] at h; exact h
      rw [hTc]
      have hnk_real : (((n + k) / 2 : ℕ) : ℝ) * 2 = (n : ℝ) + (k : ℝ) := by
        have h2 : (2 : ℝ) * (((n + k) / 2 : ℕ) : ℝ) = ((n + k : ℕ) : ℝ) := by
          exact_mod_cast hnk2
        rw [Nat.cast_add] at h2; linarith
      have hcast : (((posSet j).card + ((n + k) / 2 - (posSet j).card) : ℕ) : ℝ)
          = (((n + k) / 2 : ℕ) : ℝ) := by
        congr 1; omega
      rw [hcast]; push_cast; linarith [hnk_real]
    · exact absurd heq (hpred_gp j)
    · have hsj : s j = 1 := hs_pos j hgt
      rw [hsj]
      have hTc := hT_card_pos j hgt
      have hpos_le : (posSet j).card ≤ (n - k) / 2 := by
        have h := (hP j).2
        rw [haug_pos_pos_pred j hgt] at h; omega
      rw [hTc]
      have hnmk2 : 2 * ((n - k) / 2) = n - k := by omega
      have hnmk_real : (((n - k) / 2 : ℕ) : ℝ) * 2 = (n : ℝ) - (k : ℝ) := by
        have hkn : k ≤ n := hk_le_n
        have h2 : (2 : ℝ) * (((n - k) / 2 : ℕ) : ℝ) = ((n - k : ℕ) : ℝ) := by
          exact_mod_cast hnmk2
        have : ((n - k : ℕ) : ℝ) = (n : ℝ) - (k : ℝ) := by rw [Nat.cast_sub hkn]
        linarith
      have hcast : (((posSet j).card + ((n - k) / 2 - (posSet j).card) : ℕ) : ℝ)
          = (((n - k) / 2 : ℕ) : ℝ) := by
        congr 1; omega
      rw [hcast]; push_cast; linarith [hnmk_real]

end Workspace.ProofLemmas.RGMedianConstraintFromAugment

open Workspace.Types.LqNorm

theorem LqNormSubReverseTriangle {q : ℝ} (hq : 1 ≤ q) {d : ℕ} (x y : Fin d → ℝ) :
    lqNorm q x - lqNorm q y ≤ lqNorm q (fun j => x j - y j) := by
  -- Apply the Minkowski inequality `Real.Lp_add_le` to f = x - y, g = y.
  -- That gives: lqNorm q ((x-y)+y) ≤ lqNorm q (x-y) + lqNorm q y, i.e.
  --            lqNorm q x ≤ lqNorm q (x-y) + lqNorm q y.
  have hMink := Real.Lp_add_le (Finset.univ : Finset (Fin d))
    (fun j => x j - y j) (fun j => y j) hq
  -- Rewrite `(x j - y j) + y j` as `x j` inside the LHS sum.
  have hxeq : (∑ j, |(x j - y j) + y j| ^ q) = (∑ j, |x j| ^ q) := by
    refine Finset.sum_congr rfl ?_
    intro j _
    have : (x j - y j) + y j = x j := by ring
    rw [this]
  rw [hxeq] at hMink
  -- Now hMink : (∑ j, |x j|^q)^(1/q) ≤ (∑ j, |x j - y j|^q)^(1/q) + (∑ j, |y j|^q)^(1/q)
  -- These are exactly lqNorm q x, lqNorm q (fun j => x j - y j), and lqNorm q y.
  unfold lqNorm
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm

namespace Workspace.ProofLemmas.ConstrainedMinExists

/-- The objective summand: `g_lambda q lambda f p = lqNorm q (p - f) - lambda * lqNorm q p`. -/
noncomputable def g_lambda (q : ℝ) (lambda : ℝ) {d : ℕ}
    (f : Fin d → ℝ) (p : Fin d → ℝ) : ℝ :=
  lqNorm q (fun j => p j - f j) - lambda * lqNorm q p

end Workspace.ProofLemmas.ConstrainedMinExists

open Workspace.ProofLemmas.ConstrainedMinExists

namespace ConstrainedMinExistsProof

-- Auxiliary lemma: lqNorm bounds individual coordinates.
private lemma lqNorm_ge_abs_coord {q : ℝ} (hq : 1 ≤ q) {d : ℕ}
    (x : Fin d → ℝ) (j : Fin d) :
    |x j| ≤ lqNorm q x := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_pos : 0 < (1 : ℝ) / q := by positivity
  have h_pos : ∀ k, 0 ≤ |x k| ^ q := fun k => Real.rpow_nonneg (abs_nonneg _) q
  have h_le : |x j| ^ q ≤ ∑ k, |x k| ^ q := by
    have := Finset.single_le_sum (f := fun k => |x k| ^ q)
      (s := Finset.univ) (a := j)
      (fun k _ => h_pos k) (Finset.mem_univ j)
    exact this
  have h_lhs_nn : 0 ≤ |x j| ^ q := h_pos j
  have h_rhs_nn : 0 ≤ ∑ k, |x k| ^ q := sum_abs_rpow_nonneg q x
  have h2 : (|x j| ^ q) ^ ((1 : ℝ) / q) ≤ (∑ k, |x k| ^ q) ^ ((1 : ℝ) / q) :=
    Real.rpow_le_rpow h_lhs_nn h_le (le_of_lt h_inv_pos)
  have habs_nn : (0 : ℝ) ≤ |x j| := abs_nonneg _
  have h3 : (|x j| ^ q) ^ ((1 : ℝ) / q) = |x j| := by
    rw [← Real.rpow_mul habs_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  rw [h3] at h2
  exact h2

-- Continuity of lqNorm
private lemma lqNorm_continuous {q : ℝ} (hq : 1 ≤ q) {d : ℕ} :
    Continuous (fun x : Fin d → ℝ => lqNorm q x) := by
  unfold lqNorm
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have h_inv_nn : 0 ≤ (1 : ℝ) / q := by positivity
  have hq_nn : 0 ≤ q := le_of_lt hq_pos
  have h_inner : Continuous (fun x : Fin d → ℝ => ∑ j, |x j| ^ q) := by
    apply continuous_finset_sum
    intro j _
    exact (Real.continuous_rpow_const hq_nn).comp ((continuous_apply j).abs)
  exact (Real.continuous_rpow_const h_inv_nn).comp h_inner

-- Continuity of g_lambda in p
private lemma g_lambda_continuous {q : ℝ} (hq : 1 ≤ q) (lambda : ℝ) {d : ℕ}
    (f : Fin d → ℝ) :
    Continuous (fun p : Fin d → ℝ => g_lambda q lambda f p) := by
  unfold g_lambda
  have h_arg : Continuous (fun p : Fin d → ℝ => fun j => p j - f j) := by
    apply continuous_pi
    intro j
    exact (continuous_apply j).sub continuous_const
  have h1 : Continuous (fun p : Fin d → ℝ => lqNorm q (fun j => p j - f j)) :=
    (lqNorm_continuous hq).comp h_arg
  have h2 : Continuous (fun p : Fin d → ℝ => lqNorm q p) := lqNorm_continuous hq
  exact h1.sub (continuous_const.mul h2)

-- Sum of g_lambda is continuous
private lemma sum_g_lambda_continuous {q : ℝ} (hq : 1 ≤ q) (lambda : ℝ) {n d : ℕ}
    (f : Fin d → ℝ) :
    Continuous (fun p : Fin n → Fin d → ℝ => ∑ i, g_lambda q lambda f (p i)) := by
  apply continuous_finset_sum
  intro i _
  exact (g_lambda_continuous hq lambda f).comp (continuous_apply i)

-- Coercive lower bound: g_lambda q lambda f p ≥ (1 - lambda) * lqNorm q p - 1
private lemma g_lambda_lower_bound {q : ℝ} (hq : 1 ≤ q) {lambda : ℝ}
    {d : ℕ} (f : Fin d → ℝ) (hf_norm : lqNorm q f = 1) (p : Fin d → ℝ) :
    (1 - lambda) * lqNorm q p - 1 ≤ g_lambda q lambda f p := by
  unfold g_lambda
  have h := LqNormSubReverseTriangle hq p f
  rw [hf_norm] at h
  linarith

end ConstrainedMinExistsProof

open ConstrainedMinExistsProof

theorem ConstrainedMinExists
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {n d : ℕ} (hd : 1 ≤ d)
    (f : Fin d → ℝ) (hf_norm : lqNorm q f = 1) (hf_nn : ∀ j, 0 ≤ f j)
    (sigma_assign : Fin n → Fin d → ℝ)
    (hsigma_pm : ∀ i j, sigma_assign i j = 1 ∨ sigma_assign i j = -1)
    (hsigma_zero : ∀ j, ∑ i, sigma_assign i j = 0) :
    ∃ p_star : Fin n → Fin d → ℝ,
      (∀ i j, (sigma_assign i j = 1 → 0 ≤ p_star i j) ∧
              (sigma_assign i j = -1 → p_star i j ≤ 0)) ∧
      (∀ p : Fin n → Fin d → ℝ,
        (∀ i j, (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                (sigma_assign i j = -1 → p i j ≤ 0)) →
        (∑ i, g_lambda q lambda f (p_star i)) ≤ (∑ i, g_lambda q lambda f (p i))) := by
  classical
  have hq_le : 1 ≤ q := le_of_lt hq
  -- Define the constraint set
  set S : Set (Fin n → Fin d → ℝ) :=
    {p | ∀ i j, (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                (sigma_assign i j = -1 → p i j ≤ 0)} with hS_def
  -- Define the objective
  set G : (Fin n → Fin d → ℝ) → ℝ :=
    fun p => ∑ i, g_lambda q lambda f (p i) with hG_def
  -- G is continuous
  have hG_cont : Continuous G := sum_g_lambda_continuous hq_le lambda f
  -- 0 ∈ S
  have h0_mem : (fun _ _ => (0 : ℝ)) ∈ S := by
    intro i j
    refine ⟨fun _ => le_refl 0, fun _ => le_refl 0⟩
  -- S is closed
  have hS_closed : IsClosed S := by
    have : S = ⋂ (i : Fin n) (j : Fin d),
        {p : Fin n → Fin d → ℝ | (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                                  (sigma_assign i j = -1 → p i j ≤ 0)} := by
      ext p
      simp only [Set.mem_iInter, Set.mem_setOf_eq, hS_def]
    rw [this]
    apply isClosed_iInter
    intro i
    apply isClosed_iInter
    intro j
    have h_eq : {p : Fin n → Fin d → ℝ | (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                                  (sigma_assign i j = -1 → p i j ≤ 0)} =
        {p | sigma_assign i j = 1 → 0 ≤ p i j} ∩
        {p | sigma_assign i j = -1 → p i j ≤ 0} := by
      ext p; simp [Set.mem_inter_iff, Set.mem_setOf_eq]
    rw [h_eq]
    apply IsClosed.inter
    · rcases hsigma_pm i j with h1 | h1
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = 1 → 0 ≤ p i j}
            = {p : Fin n → Fin d → ℝ | 0 ≤ p i j} := by
          ext p; simp [h1]
        rw [heq]
        have h_cont : Continuous (fun p : Fin n → Fin d → ℝ => p i j) :=
          (continuous_apply j).comp (continuous_apply i)
        exact isClosed_le continuous_const h_cont
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = 1 → 0 ≤ p i j}
            = Set.univ := by
          ext p
          simp only [Set.mem_setOf_eq, Set.mem_univ, iff_true]
          intro hcontr
          rw [h1] at hcontr
          linarith
        rw [heq]; exact isClosed_univ
    · rcases hsigma_pm i j with h1 | h1
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = -1 → p i j ≤ 0}
            = Set.univ := by
          ext p
          simp only [Set.mem_setOf_eq, Set.mem_univ, iff_true]
          intro hcontr
          rw [h1] at hcontr
          linarith
        rw [heq]; exact isClosed_univ
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = -1 → p i j ≤ 0}
            = {p : Fin n → Fin d → ℝ | p i j ≤ 0} := by
          ext p; simp [h1]
        rw [heq]
        have h_cont : Continuous (fun p : Fin n → Fin d → ℝ => p i j) :=
          (continuous_apply j).comp (continuous_apply i)
        exact isClosed_le h_cont continuous_const
  -- Set K := G 0
  set K : ℝ := G (fun _ _ => 0) with hK_def
  -- Define T := S ∩ {p | G p ≤ K}
  set T : Set (Fin n → Fin d → ℝ) := S ∩ {p | G p ≤ K} with hT_def
  -- T is closed
  have hT_closed : IsClosed T := hS_closed.inter (isClosed_le hG_cont continuous_const)
  -- T is bounded
  have hT_bdd : Bornology.IsBounded T := by
    have h_one_lam_pos : 0 < 1 - lambda := by linarith
    have h_one_lam_nn : 0 ≤ 1 - lambda := le_of_lt h_one_lam_pos
    set R : ℝ := (K + n) / (1 - lambda) with hR_def
    have h_pj_bound : ∀ p ∈ T, ∀ i j, |p i j| ≤ R := by
      intro p hp i j
      obtain ⟨hpS, hpK⟩ := hp
      simp only [Set.mem_setOf_eq] at hpK
      have h_each : ∀ i', (1 - lambda) * lqNorm q (p i') - 1 ≤ g_lambda q lambda f (p i') :=
        fun i' => g_lambda_lower_bound hq_le f hf_norm (p i')
      have h_sum : (1 - lambda) * (∑ i', lqNorm q (p i')) - n ≤ ∑ i', g_lambda q lambda f (p i') := by
        have h1 : (∑ i' : Fin n, ((1 - lambda) * lqNorm q (p i') - 1)) ≤
                   ∑ i', g_lambda q lambda f (p i') := by
          apply Finset.sum_le_sum
          intro i' _
          exact h_each i'
        have h2 : (∑ i' : Fin n, ((1 - lambda) * lqNorm q (p i') - 1)) =
                  (1 - lambda) * (∑ i', lqNorm q (p i')) - n := by
          rw [Finset.sum_sub_distrib]
          rw [← Finset.mul_sum]
          simp
        linarith [h1, h2.symm.le, h2.le]
      have h_sum2 : (1 - lambda) * (∑ i', lqNorm q (p i')) ≤ K + n := by
        have : ∑ i', g_lambda q lambda f (p i') = G p := rfl
        linarith
      have h_nn : ∀ i', 0 ≤ lqNorm q (p i') := fun i' => lqNorm_nonneg hq_le _
      have h_single_le_sum : lqNorm q (p i) ≤ ∑ i', lqNorm q (p i') := by
        exact Finset.single_le_sum (f := fun i' => lqNorm q (p i'))
          (s := Finset.univ) (a := i)
          (fun i' _ => h_nn i') (Finset.mem_univ _)
      have h_pi_bound : (1 - lambda) * lqNorm q (p i) ≤ K + n := by
        calc (1 - lambda) * lqNorm q (p i) ≤ (1 - lambda) * (∑ i', lqNorm q (p i')) := by
              exact mul_le_mul_of_nonneg_left h_single_le_sum h_one_lam_nn
          _ ≤ K + n := h_sum2
      have h_lqnorm_le_R : lqNorm q (p i) ≤ R := by
        rw [hR_def]
        rw [le_div_iff₀ h_one_lam_pos]
        linarith [mul_comm (1 - lambda) (lqNorm q (p i))]
      have h_abs_le : |p i j| ≤ lqNorm q (p i) := lqNorm_ge_abs_coord hq_le (p i) j
      linarith
    rw [Metric.isBounded_iff_subset_closedBall (0 : Fin n → Fin d → ℝ)]
    refine ⟨R, ?_⟩
    intro p hp
    rw [Metric.mem_closedBall, dist_zero_right]
    have hR_nn : 0 ≤ R := by
      rw [hR_def]
      apply div_nonneg
      · have h_g0 : ∀ i : Fin n, g_lambda q lambda f ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i) = 1 := by
          intro i
          unfold g_lambda
          have h_pi : ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i) = (fun (_ : Fin d) => (0 : ℝ)) := rfl
          rw [h_pi]
          have h_eq : (fun j : Fin d => ((fun (_ : Fin d) => (0 : ℝ)) j) - f j) = (fun j => -f j) := by
            funext j; simp
          rw [h_eq]
          have h_neg : lqNorm q (fun j : Fin d => -f j) = lqNorm q f := by
            have h1 := lqNorm_smul hq_le (-1 : ℝ) f
            have h2 : (fun j : Fin d => (-1 : ℝ) * f j) = (fun j => -f j) := by
              funext j; ring
            rw [h2] at h1
            simp at h1
            exact h1
          rw [h_neg, hf_norm]
          have h_zero : lqNorm q (fun (_ : Fin d) => (0 : ℝ)) = 0 := lqNorm_zero hq_le
          rw [h_zero]
          ring
        have hK_val : K = n := by
          show G (fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) = n
          show (∑ i : Fin n, g_lambda q lambda f ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i)) = n
          rw [Finset.sum_congr rfl (fun i _ => h_g0 i)]
          simp
        rw [hK_val]
        have hn_nn : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
        linarith
      · exact h_one_lam_nn
    rw [pi_norm_le_iff_of_nonneg hR_nn]
    intro i
    rw [pi_norm_le_iff_of_nonneg hR_nn]
    intro j
    simp only [Real.norm_eq_abs]
    exact h_pj_bound p hp i j
  -- T is compact
  have hT_compact : IsCompact T :=
    Metric.isCompact_iff_isClosed_bounded.mpr ⟨hT_closed, hT_bdd⟩
  -- T is nonempty
  have hT_nonempty : T.Nonempty := by
    refine ⟨fun _ _ => 0, h0_mem, ?_⟩
    simp only [Set.mem_setOf_eq]
    rfl
  -- G is continuous on T
  have hG_cont_on : ContinuousOn G T := hG_cont.continuousOn
  -- Apply IsCompact.exists_isMinOn
  obtain ⟨p_star, hp_star_T, hp_star_min⟩ :=
    hT_compact.exists_isMinOn hT_nonempty hG_cont_on
  refine ⟨p_star, hp_star_T.1, ?_⟩
  intro p hp
  by_cases hpK : G p ≤ K
  · have hpT : p ∈ T := ⟨hp, hpK⟩
    exact hp_star_min hpT
  · push_neg at hpK
    have hp_star_K : G p_star ≤ K := hp_star_T.2
    linarith

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.SocialCost
open Workspace.Types.CoordinateMedian
open Workspace.ConsistencyTheorem
open Workspace.RobustnessTheorem
open Workspace.ProofLemmas.ConstrainedMinExists

namespace Workspace.ProofLemmas.RGWorstCasePredictionSignature

/-- L2 norm is monotone under coordinatewise absolute-value domination. -/
private lemma lqNorm2_mono {d : ℕ} (x y : Fin d → ℝ) (h : ∀ j, |x j| ≤ |y j|) :
    lqNorm 2 x ≤ lqNorm 2 y := by
  unfold lqNorm
  apply Real.rpow_le_rpow (sum_abs_rpow_nonneg 2 x)
  · apply Finset.sum_le_sum
    intro j _
    exact Real.rpow_le_rpow (abs_nonneg _) (h j) (by norm_num)
  · norm_num

/-- L2 norm is determined by coordinatewise absolute values. -/
private lemma lqNorm2_congr {d : ℕ} (x y : Fin d → ℝ) (h : ∀ j, |x j| = |y j|) :
    lqNorm 2 x = lqNorm 2 y := by
  unfold lqNorm
  congr 1
  apply Finset.sum_congr rfl
  intro j _
  rw [h j]

/-- A ±1 sum equals (# of +1's) − (# of −1's). -/
private lemma sum_pm_eq_card {n : ℕ} (sg : Fin n → ℝ) (hpm : ∀ i, sg i = 1 ∨ sg i = -1) :
    ∑ i, sg i =
      ((Finset.univ.filter (fun i => sg i = 1)).card : ℝ)
      - ((Finset.univ.filter (fun i => sg i = -1)).card : ℝ) := by
  classical
  rw [← Finset.sum_filter_add_sum_filter_not Finset.univ (fun i => sg i = 1)]
  have h1 : ∑ i ∈ Finset.univ.filter (fun i => sg i = 1), sg i
      = ((Finset.univ.filter (fun i => sg i = 1)).card : ℝ) := by
    rw [Finset.sum_congr rfl (fun i hi => (Finset.mem_filter.mp hi).2)]
    simp
  have h2 : ∑ i ∈ Finset.univ.filter (fun i => ¬ sg i = 1), sg i
      = - ((Finset.univ.filter (fun i => sg i = -1)).card : ℝ) := by
    have heq : (Finset.univ.filter (fun i => ¬ sg i = 1))
        = (Finset.univ.filter (fun i => sg i = -1)) := by
      apply Finset.filter_congr
      intro i _
      constructor
      · intro hne
        rcases hpm i with h | h
        · exact absurd h hne
        · exact h
      · intro h hcontra; rw [h] at hcontra; norm_num at hcontra
    rw [heq, Finset.sum_congr rfl (fun i hi => (Finset.mem_filter.mp hi).2)]
    simp
  rw [h1, h2]; ring

/-- Cardinalities of the +1 and −1 sets sum to `n`. -/
private lemma card_pos_add_card_neg {n : ℕ} (sg : Fin n → ℝ)
    (hpm : ∀ i, sg i = 1 ∨ sg i = -1) :
    (Finset.univ.filter (fun i => sg i = 1)).card
      + (Finset.univ.filter (fun i => sg i = -1)).card = n := by
  classical
  have heq : (Finset.univ.filter (fun i => ¬ sg i = 1))
      = (Finset.univ.filter (fun i => sg i = -1)) := by
    apply Finset.filter_congr
    intro i _
    constructor
    · intro hne
      rcases hpm i with h | h
      · exact absurd h hne
      · exact h
    · intro h hcontra; rw [h] at hcontra; norm_num at hcontra
  have := Finset.filter_card_add_filter_neg_card_eq_card
    (s := (Finset.univ : Finset (Fin n))) (p := fun i => sg i = 1)
  rw [heq] at this
  simpa using this

theorem RGWorstCasePredictionSignature
    {n d : ℕ} (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) (lambda : ℝ)
    (f : Fin d → ℝ) (hf_pos : ∀ j, 0 < f j)
    (P : Fin n → Fin d → ℝ) (s : Fin d → ℝ)
    (hs_pm : ∀ j, s j = 1 ∨ s j = -1)
    -- `(P, s)` is feasible: there is a consistent ±1 signature assignment `σ`
    -- realizing the per-coordinate constraint `∑_i σ(pᵢ) j = −⌊cn⌋ · s j`.
    (sigma : Fin n → Fin d → ℝ)
    (hsigma_pm : ∀ i j, sigma i j = 1 ∨ sigma i j = -1)
    (hsigma_pos : ∀ i j, P i j > 0 → sigma i j = 1)
    (hsigma_neg : ∀ i j, P i j < 0 → sigma i j = -1)
    (hconstraint : ∀ j, ∑ i, sigma i j = -(⌊c * (n : ℝ)⌋₊ : ℝ) * s j) :
    -- There is a feasible configuration with prediction signature `(−1,…,−1)`
    -- whose objective is no larger.
    ∃ (P' : Fin n → Fin d → ℝ) (sigma' : Fin n → Fin d → ℝ),
      (∀ i j, sigma' i j = 1 ∨ sigma' i j = -1) ∧
      (∀ i j, P' i j > 0 → sigma' i j = 1) ∧
      (∀ i j, P' i j < 0 → sigma' i j = -1) ∧
      (∀ j, ∑ i, sigma' i j = -(⌊c * (n : ℝ)⌋₊ : ℝ) * (-1)) ∧
      (∑ i, g_lambda 2 lambda f (P' i)) ≤ (∑ i, g_lambda 2 lambda f (P i)) := by
  classical
  set m : ℕ := ⌊c * (n : ℝ)⌋₊ with hm
  -- The "negative-signature" set for coordinate j.
  set T : Fin d → Finset (Fin n) := fun j => Finset.univ.filter (fun i => sigma i j = -1) with hT
  -- m ≤ n.
  have hmn : m ≤ n := by
    rw [hm]
    have : c * (n : ℝ) ≤ (n : ℝ) := by
      have : c * (n : ℝ) ≤ 1 * (n : ℝ) :=
        mul_le_mul_of_nonneg_right (le_of_lt hc1) (by positivity)
      simpa using this
    calc ⌊c * (n : ℝ)⌋₊ ≤ ⌊(n : ℝ)⌋₊ := Nat.floor_le_floor this
      _ = n := Nat.floor_natCast n
  -- When s j = 1, the negative set has at least m elements.
  have hcard_T : ∀ j, s j = 1 → m ≤ (T j).card := by
    intro j hsj
    have hsum := hconstraint j
    rw [hsj, mul_one] at hsum
    have hpmj : ∀ i, sigma i j = 1 ∨ sigma i j = -1 := fun i => hsigma_pm i j
    rw [sum_pm_eq_card (fun i => sigma i j) hpmj] at hsum
    have hcard := card_pos_add_card_neg (fun i => sigma i j) hpmj
    -- Let A = #{+1}, B = #{-1} = (T j).card. A - B = -m, A + B = n  ⇒ B = (n+m)/2 ≥ m
    set A := (Finset.univ.filter (fun i => sigma i j = 1)).card with hA
    set B := (Finset.univ.filter (fun i => sigma i j = -1)).card with hB
    have hBcard : (T j).card = B := by rw [hT, hB]
    -- cast equations to ℝ
    have hsumcard_real : (A : ℝ) + (B : ℝ) = (n : ℝ) := by
      have : ((A + B : ℕ) : ℝ) = (n : ℝ) := by exact_mod_cast hcard
      push_cast at this; linarith
    have hB_ge : (m : ℝ) ≤ (B : ℝ) := by
      have hmn_real : (m : ℝ) ≤ (n : ℝ) := by exact_mod_cast hmn
      nlinarith [hsum]
    exact_mod_cast hB_ge
  -- Choose, for each coordinate j with s j = 1, an m-subset S j ⊆ T j.
  -- For s j = -1 we use ∅.
  have hSexists : ∀ j, ∃ (Sj : Finset (Fin n)), Sj ⊆ T j ∧ (s j = 1 → Sj.card = m) := by
    intro j
    by_cases hsj : s j = 1
    · obtain ⟨Sj, hsub, hcard⟩ := Finset.exists_subset_card_eq (hcard_T j hsj)
      exact ⟨Sj, hsub, fun _ => hcard⟩
    · exact ⟨∅, Finset.empty_subset _, fun h => absurd h hsj⟩
  choose S hS_sub hS_card using hSexists
  -- "flip" predicate.
  set flip : Fin n → Fin d → Prop := fun i j => s j = 1 ∧ i ∈ S j with hflip
  have flip_dec : ∀ i j, Decidable (flip i j) := by
    intro i j; rw [hflip]; infer_instance
  -- The new configuration.
  set P' : Fin n → Fin d → ℝ :=
    fun i j => if flip i j then -(P i j) else P i j with hP'
  set sigma' : Fin n → Fin d → ℝ :=
    fun i j => if flip i j then -(sigma i j) else sigma i j with hsig'
  -- Key fact: if flip i j then P i j ≤ 0 and sigma i j = -1.
  have hflip_neg : ∀ i j, flip i j → sigma i j = -1 ∧ P i j ≤ 0 := by
    intro i j hf
    have hiT : i ∈ T j := hS_sub j hf.2
    have hsig_neg : sigma i j = -1 := (Finset.mem_filter.mp hiT).2
    refine ⟨hsig_neg, ?_⟩
    by_contra hcontra
    push_neg at hcontra
    have := hsigma_pos i j hcontra
    rw [hsig_neg] at this; norm_num at this
  refine ⟨P', sigma', ?_, ?_, ?_, ?_, ?_⟩
  · -- sigma' is ±1
    intro i j
    rw [hsig']
    by_cases hf : flip i j
    · simp only [hf, if_true]
      rcases hsigma_pm i j with h | h
      · right; rw [h]
      · left; rw [h]; norm_num
    · simp only [hf, if_false]; exact hsigma_pm i j
  · -- P' i j > 0 → sigma' i j = 1
    intro i j hpos
    rw [hsig']
    rw [hP'] at hpos
    by_cases hf : flip i j
    · simp only [hf, if_true]
      simp only [hf, if_true] at hpos
      -- P' i j = -(P i j) > 0 ⇒ P i j < 0; but flip ⇒ P i j ≤ 0 and sigma i j = -1 ⇒ -sigma = 1
      have := (hflip_neg i j hf).1
      rw [this]; norm_num
    · simp only [hf, if_false]
      simp only [hf, if_false] at hpos
      exact hsigma_pos i j hpos
  · -- P' i j < 0 → sigma' i j = -1
    intro i j hneg
    rw [hsig']
    rw [hP'] at hneg
    by_cases hf : flip i j
    · -- contradiction: flip ⇒ P i j ≤ 0 ⇒ -(P i j) ≥ 0, but P' = -(P i j) < 0
      exfalso
      simp only [hf, if_true] at hneg
      have := (hflip_neg i j hf).2
      linarith
    · simp only [hf, if_false]
      simp only [hf, if_false] at hneg
      exact hsigma_neg i j hneg
  · -- constraint sum = m  (= -m·(-1))
    intro j
    rw [hsig']
    simp only [neg_neg, mul_neg, mul_one]
    have hrewrite : ∀ x, (if flip x j then -sigma x j else sigma x j)
        = sigma x j + (if flip x j then (-2 * sigma x j) else 0) := by
      intro x
      by_cases hf : flip x j
      · simp only [hf, if_true]; ring
      · simp only [hf, if_false]; ring
    rw [Finset.sum_congr rfl (fun x _ => hrewrite x), Finset.sum_add_distrib]
    have hsum_sigma : ∑ x, sigma x j = -(m : ℝ) * s j := hconstraint j
    by_cases hsj : s j = 1
    · -- flipped coordinate
      rw [hsj, mul_one] at hsum_sigma
      rw [hsum_sigma]
      -- ∑ (if flip then -2 sigma else 0) = ∑_{i ∈ S j} 2 = 2 m
      have hflip_iff : ∀ x, flip x j ↔ x ∈ S j := by
        intro x; rw [hflip]; simp only [hsj, true_and]
      have hinner : (∑ x, (if flip x j then (-2 * sigma x j) else 0)) = 2 * (m : ℝ) := by
        rw [Finset.sum_ite]
        have hfilter : (Finset.univ.filter (fun x => flip x j)) = S j := by
          ext x
          simp only [Finset.mem_filter, Finset.mem_univ, true_and]
          exact hflip_iff x
        rw [hfilter]
        rw [Finset.sum_const_zero, add_zero]
        have hval : ∀ x ∈ S j, -2 * sigma x j = (2 : ℝ) := by
          intro x hx
          have hfx : flip x j := (hflip_iff x).mpr hx
          rw [(hflip_neg x j hfx).1]; ring
        rw [Finset.sum_congr rfl hval, Finset.sum_const]
        rw [hS_card j hsj]
        simp [mul_comm]
      rw [hinner]; ring
    · -- s j = -1, no flips
      have hsj' : s j = -1 := (hs_pm j).resolve_left hsj
      rw [hsj'] at hsum_sigma
      rw [hsum_sigma]
      have hno_flip : ∀ x, ¬ flip x j := by
        intro x hf; exact hsj (hf.1)
      have hinner : (∑ x, (if flip x j then (-2 * sigma x j) else 0)) = 0 := by
        apply Finset.sum_eq_zero
        intro x _
        simp only [hno_flip x, if_false]
      rw [hinner]; ring
  · -- objective does not increase
    -- Prove it term-wise: for each i, g_lambda 2 lambda f (P' i) ≤ g_lambda 2 lambda f (P i).
    apply Finset.sum_le_sum
    intro i _
    -- Pointwise relation between P' i and P i.
    have hPval : ∀ j, P' i j = (if flip i j then -(P i j) else P i j) := by
      intro j; rw [hP']
    -- Absolute values of P' i j equal those of P i j (sign reflection).
    have habs_eq : ∀ j, |P' i j| = |P i j| := by
      intro j
      rw [hPval j]
      by_cases hf : flip i j
      · simp only [hf, if_true, abs_neg]
      · simp only [hf, if_false]
    -- Distance: |P' i j - f j| ≤ |P i j - f j| for all j.
    have hdist_le : ∀ j, |P' i j - f j| ≤ |P i j - f j| := by
      intro j
      rw [hPval j]
      by_cases hf : flip i j
      · simp only [hf, if_true]
        -- flip ⇒ P i j ≤ 0 < f j; reflection inequality |-(P i j) - f j| ≤ |P i j - f j|.
        have hpneg : P i j ≤ 0 := (hflip_neg i j hf).2
        have hfpos : 0 < f j := hf_pos j
        have hPf_eq : |P i j - f j| = f j - P i j := by
          rw [abs_of_nonpos (by linarith)]; ring
        rw [hPf_eq, abs_le]
        constructor
        · linarith
        · linarith
      · simp only [hf, if_false]; exact le_refl _
    -- Now combine via the g_lambda definition.
    unfold g_lambda
    have hnorm_eq : lqNorm 2 (P' i) = lqNorm 2 (P i) :=
      lqNorm2_congr (P' i) (P i) habs_eq
    have hdistnorm_le :
        lqNorm 2 (fun j => P' i j - f j) ≤ lqNorm 2 (fun j => P i j - f j) :=
      lqNorm2_mono (fun j => P' i j - f j) (fun j => P i j - f j) hdist_le
    have hnorm_eq' : lqNorm 2 (fun j => P' i j) = lqNorm 2 (fun j => P i j) := hnorm_eq
    rw [hnorm_eq']
    linarith [hdistnorm_le]

end Workspace.ProofLemmas.RGWorstCasePredictionSignature

open Workspace.ConsistencyTheorem
open Classical

namespace Workspace.ProofLemmas.RGRelaxedConstraint

theorem RGRelaxedConstraint
    {n d : ℕ} (c : ℝ)
    (hcn : (⌊c * (n : ℝ)⌋₊ : ℝ) = c * (n : ℝ))
    (f : Fin d → ℝ) (hf_sum : (∑ j, (f j) ^ (2 : ℝ)) = 1)
    (sigma : Fin n → Fin d → ℝ)
    (hsigma_pm : ∀ i j, sigma i j = 1 ∨ sigma i j = -1)
    (hbalance : ∀ j,
      (((Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1)).card : ℝ)
        = ((n : ℝ) + ⌊c * (n : ℝ)⌋₊) / 2) :
    (∑ i, ∑ j ∈ (Finset.univ : Finset (Fin d)).filter (fun j => sigma i j = 1),
        (f j) ^ (2 : ℝ))
      = (1 + c) / 2 * (n : ℝ) := by
  classical
  have step1 :
      (∑ i, ∑ j ∈ (Finset.univ : Finset (Fin d)).filter (fun j => sigma i j = 1),
          (f j) ^ (2 : ℝ)) =
      ∑ i, ∑ j, (if sigma i j = 1 then (f j) ^ (2 : ℝ) else 0) := by
    refine Finset.sum_congr rfl (fun i _ => ?_)
    rw [Finset.sum_filter]
  rw [step1, Finset.sum_comm]
  have step2 : ∀ j : Fin d,
      (∑ i, (if sigma i j = 1 then (f j) ^ (2 : ℝ) else 0)) =
      (((Finset.univ : Finset (Fin n)).filter (fun i => sigma i j = 1)).card : ℝ)
        * (f j) ^ (2 : ℝ) := by
    intro j
    rw [← Finset.sum_filter, Finset.sum_const]
    ring
  simp_rw [step2]
  simp_rw [hbalance]
  rw [← Finset.mul_sum, hf_sum, mul_one]
  rw [hcn]
  ring

end Workspace.ProofLemmas.RGRelaxedConstraint

open Workspace.ProofLemmas.CGDefs

namespace Workspace.ProofLemmas.CGOptimalSolutionForA1

set_option maxHeartbeats 4000000

/-- HasDerivAt for `u1delta c delta` at a point `a` with `0 < a < 1`. -/
theorem u1delta_hasDerivAt (c delta a : ℝ) (ha0 : 0 < a) (ha1 : a < 1) :
    HasDerivAt (fun x => u1delta c delta x) (u1deriv c delta a) a := by
  have ha_ne : a ≠ 0 := ne_of_gt ha0
  have h1ma_pos : 0 < 1 - a := by linarith
  have h1ma_ne : (1 - a) ≠ 0 := ne_of_gt h1ma_pos
  -- derivative of x ↦ x^(1/2)
  have hd_a_pow : HasDerivAt (fun x : ℝ => x ^ ((1:ℝ)/2)) ((1/2) * a ^ ((1:ℝ)/2 - 1)) a := by
    have h := (hasDerivAt_id a).rpow_const (p := (1:ℝ)/2) (Or.inl ha_ne)
    simpa using h
  -- derivative of x ↦ (1-x)^(1/2)
  have hd_inner : HasDerivAt (fun x : ℝ => 1 - x) (-1 : ℝ) a := by
    simpa using (hasDerivAt_id a).const_sub 1
  have hd_1ma_pow : HasDerivAt (fun x : ℝ => (1 - x) ^ ((1:ℝ)/2))
      (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) a := by
    have h := hd_inner.rpow_const (p := (1:ℝ)/2) (Or.inl h1ma_ne)
    convert h using 1
    ring
  have hd_d_1ma : HasDerivAt (fun x : ℝ => delta * (1 - x) ^ ((1:ℝ)/2))
      (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1)))) a :=
    hd_1ma_pow.const_mul delta
  have hd_diff : HasDerivAt (fun x : ℝ => delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2))
      (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1)) a :=
    hd_d_1ma.sub hd_a_pow
  have hd_mul : HasDerivAt (fun x : ℝ => (1 + c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)))
      ((1 + c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1))) a :=
    hd_diff.const_mul (1 + c)
  have hd_sub1 : HasDerivAt (fun x : ℝ => (1 + c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)) - 1)
      ((1 + c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1))) a :=
    hd_mul.sub_const 1
  have hd_lin : HasDerivAt (fun x : ℝ => 2 * x) (2 : ℝ) a := by
    simpa using (hasDerivAt_id a).const_mul 2
  have hd_total0 : HasDerivAt
      (fun x : ℝ => (1 + c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)) - 1 + 2 * x)
      ((1 + c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1)) + 2) a :=
    hd_sub1.add hd_lin
  have hd_total : HasDerivAt
      (fun x : ℝ => (1 + c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)) - 1 + 2 * x + c)
      ((1 + c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1)) + 2) a :=
    hd_total0.add_const c
  -- Now match against u1delta and u1deriv.
  have hfun : (fun x => u1delta c delta x) =
      (fun x : ℝ => (1 + c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)) - 1 + 2 * x + c) := by
    funext x; rw [u1delta]
  rw [hfun]
  -- derivative value matches u1deriv
  have hval : (1 + c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1)) + 2
      = u1deriv c delta a := by
    rw [u1deriv]
    have e1 : ((1:ℝ)/2 - 1) = -(1:ℝ)/2 := by norm_num
    rw [e1]
    ring
  rw [hval] at hd_total
  exact hd_total

/-- `zCG delta > 0` for `delta > 0`. -/
theorem zCG_pos (delta : ℝ) (hdelta : 0 < delta) : 0 < zCG delta := by
  rw [zCG]
  have hnum : 0 < delta ^ (-(2 : ℝ) / 3) := Real.rpow_pos_of_pos hdelta _
  have hden : 0 < delta ^ (-(2 : ℝ) / 3) + 1 := by linarith
  exact div_pos hnum hden

/-- On `(0, b)` with `b = ((1+c)/4)^2`, the derivative `u1deriv c delta a` is negative
(`a → 0⁺` makes `a^{-1/2} → +∞`). Concretely `a < ((1+c)/4)^2 ⟹ u1deriv < 0`. -/
theorem u1deriv_neg_near_zero (c delta a : ℝ) (hc0 : 0 ≤ c) (hdelta : 0 < delta)
    (ha0 : 0 < a) (ha1 : a < 1) (hab : a < ((1 + c) / 4) ^ 2) :
    u1deriv c delta a < 0 := by
  have h1c : (0:ℝ) < 1 + c := by linarith
  have h1ma_pos : 0 < 1 - a := by linarith
  -- a^{-1/2} > 4/(1+c)
  have hasqrt : Real.sqrt a < (1 + c) / 4 := by
    have h4 : (0:ℝ) < (1 + c) / 4 := by positivity
    have := Real.sqrt_lt_sqrt (le_of_lt ha0) hab
    rwa [Real.sqrt_sq (le_of_lt h4)] at this
  have ha_inv_sqrt : a ^ (-(1:ℝ)/2) = (Real.sqrt a)⁻¹ := by
    rw [show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt ha0),
        ← Real.sqrt_eq_rpow]
  have h1ma_inv_sqrt : (1 - a) ^ (-(1:ℝ)/2) = (Real.sqrt (1 - a))⁻¹ := by
    rw [show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt h1ma_pos),
        ← Real.sqrt_eq_rpow]
  have hsqrta_pos : 0 < Real.sqrt a := Real.sqrt_pos.mpr ha0
  have hsqrt1ma_pos : 0 < Real.sqrt (1 - a) := Real.sqrt_pos.mpr h1ma_pos
  -- a^{-1/2} = (√a)⁻¹ > 4/(1+c)
  have h_inv_gt : (4 : ℝ) / (1 + c) < (Real.sqrt a)⁻¹ := by
    have hpos : (0:ℝ) < (1 + c) / 4 := by positivity
    have hinv : ((1 + c) / 4)⁻¹ < (Real.sqrt a)⁻¹ := by gcongr
    rwa [inv_div] at hinv
  -- the δ term is ≤ 0
  have h_delta_term_nonpos : -delta * (1 - a) ^ (-(1:ℝ)/2) ≤ 0 := by
    rw [h1ma_inv_sqrt]
    have : 0 ≤ delta * (Real.sqrt (1 - a))⁻¹ := by positivity
    linarith
  rw [u1deriv, ha_inv_sqrt]
  -- ½(1+c)·(√a)⁻¹ > 2
  have hmain : (2:ℝ) < (1/2) * (1 + c) * (Real.sqrt a)⁻¹ := by
    have h4 : (4 : ℝ) / (1 + c) < (Real.sqrt a)⁻¹ := h_inv_gt
    have := mul_lt_mul_of_pos_left h4 (show (0:ℝ) < (1/2)*(1+c) by positivity)
    rw [show (1/2 * (1+c)) * (4 / (1 + c)) = 2 by field_simp; ring] at this
    linarith
  nlinarith [h_delta_term_nonpos, hmain]

/-- `u1delta c delta` is continuous on `Set.Icc 0 M` whenever `M < 1`. -/
theorem u1delta_continuousOn (c delta M : ℝ) (hM : M < 1) :
    ContinuousOn (fun x => u1delta c delta x) (Set.Icc (0:ℝ) M) := by
  intro x hx
  have hx_le : x ≤ M := hx.2
  have hx_lt_one : x < 1 := lt_of_le_of_lt hx_le hM
  have h1mx_pos : 0 < 1 - x := by linarith
  have hx_nn : 0 ≤ x := hx.1
  have h_inner : ContinuousAt (fun y : ℝ => 1 - y) x :=
    (continuous_const.sub continuous_id).continuousAt
  have h_outer : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) (1 - x) :=
    Real.continuousAt_rpow_const (1 - x) ((1:ℝ)/2) (Or.inl (ne_of_gt h1mx_pos))
  have h_1mx_pow : ContinuousAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/2)) x :=
    h_outer.comp h_inner
  have h_d_1mx_pow : ContinuousAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2)) x :=
    h_1mx_pow.const_mul delta
  have h_x_pow : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) x :=
    Real.continuousAt_rpow_const x ((1:ℝ)/2) (Or.inr (by norm_num))
  have h_diff : ContinuousAt
      (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2)) x :=
    h_d_1mx_pow.sub h_x_pow
  have h_mul : ContinuousAt
      (fun y : ℝ => (1 + c) * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2))) x :=
    h_diff.const_mul (1 + c)
  have h_total : ContinuousAt (fun x => u1delta c delta x) x := by
    have : (fun x => u1delta c delta x) =
        (fun y : ℝ => (1 + c) * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2)) - 1 + 2 * y + c) := by
      funext y; rw [u1delta]
    rw [this]
    exact (((h_mul.sub continuousAt_const).add
      ((continuous_const.mul continuous_id).continuousAt)).add continuousAt_const)
  exact h_total.continuousWithinAt

/-- The inflection identity at `z = zCG delta`: `delta·(1-z)^{-3/2} = z^{-3/2}`
(appendix.tex line 165).  Equivalently `delta = ((1-z)/z)^{3/2}`. -/
theorem zCG_inflection (delta : ℝ) (hdelta : 0 < delta) :
    delta * (1 - zCG delta) ^ (-(3:ℝ)/2) = (zCG delta) ^ (-(3:ℝ)/2) := by
  set D : ℝ := delta ^ (-(2:ℝ)/3) with hD_def
  have hD_pos : 0 < D := Real.rpow_pos_of_pos hdelta _
  have hDp1_pos : 0 < D + 1 := by linarith
  have hDp1_ne : D + 1 ≠ 0 := ne_of_gt hDp1_pos
  have hz : zCG delta = D / (D + 1) := rfl
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have h1mz : 1 - zCG delta = 1 / (D + 1) := by
    rw [hz]; field_simp; ring
  have h1mz_pos : 0 < 1 - zCG delta := by rw [h1mz]; positivity
  -- z^{-3/2} = (D/(D+1))^{-3/2}, (1-z)^{-3/2} = (1/(D+1))^{-3/2} = (D+1)^{3/2}
  rw [h1mz, hz]
  rw [Real.div_rpow (le_of_lt hD_pos) (le_of_lt hDp1_pos),
      Real.div_rpow (by norm_num) (le_of_lt hDp1_pos), Real.one_rpow]
  -- key: delta = D^{-3/2}, since D = delta^{-2/3} and (-2/3)·(-3/2) = 1.
  have hD_pow : D ^ (-(3:ℝ)/2) = delta := by
    rw [hD_def, ← Real.rpow_mul (le_of_lt hdelta)]
    rw [show (-(2:ℝ)/3) * (-(3:ℝ)/2) = 1 by ring, Real.rpow_one]
  have hDp1_pow_pos : 0 < (D + 1) ^ (-(3:ℝ)/2) := Real.rpow_pos_of_pos hDp1_pos _
  -- goal: delta * (1 / (D+1)^{-3/2}) = D^{-3/2} / (D+1)^{-3/2}
  rw [← hD_pow]
  field_simp

/-- The "bracket" of appendix.tex line 151–164:
`½·(δ(1-z)^{1/2} − z^{1/2}) − ½·z^{-1/2} + 1`, as a function of the point `z`. -/
noncomputable def zBracket (delta z : ℝ) : ℝ :=
  (1/2) * (delta * (1 - z) ^ ((1:ℝ)/2) - z ^ ((1:ℝ)/2)) - (1/2) * z ^ (-(1:ℝ)/2) + 1

/-- `zCG delta < 1`. -/
theorem zCG_lt_one (delta : ℝ) (hdelta : 0 < delta) : zCG delta < 1 := by
  rw [zCG]
  have hnum : 0 < delta ^ (-(2 : ℝ) / 3) := Real.rpow_pos_of_pos hdelta _
  have hden : 0 < delta ^ (-(2 : ℝ) / 3) + 1 := by linarith
  rw [div_lt_one hden]; linarith

/-- **Residual analytic inequality (appendix.tex lines 153–164).**

The bracket `½(δ(1-z)^{1/2} − z^{1/2}) − ½ z^{-1/2} + 1` is `≥ 0` at the inflection
point `z = zCG delta` when `z ≤ 1/2`.  Using the inflection identity
`δ(1-z)^{-3/2} = z^{-3/2}` (proved as `zCG_inflection`), i.e.
`δ(1-z)^{1/2} = z^{-3/2}(1-z)^2`, the bracket equals
`z^{-3/2}·(½ − (3/2)z) + 1`, and the appendix chain shows this is `≥ 0` for `z ≤ 1/2`.

This is proved fully (no residual): a self-contained real-analysis
inequality in the single variable `z = zCG delta`, with `δ` pinned to `z` by
`zCG_inflection`.  Everything in `CGOptimalSolutionForA1` (the derivative
formula, ruling out `a₁=0`, the slope identity at `z`, the minimality sign, and
Fermat's interior FOC) is proved rigorously.

In fact the substitution `s := √z` reduces the bracket to
`((s-1)^2(s + ½))/s^3 ≥ 0`, which holds for every `s > 0` (no need for `z ≤ 1/2`). -/
theorem zBracket_nonneg (delta : ℝ) (hdelta : 0 < delta)
    (hz_le_half : zCG delta ≤ 1 / 2) :
    0 ≤ zBracket delta (zCG delta) := by
  set z : ℝ := zCG delta with hz_def
  have hz0 : 0 < z := zCG_pos delta hdelta
  have hz1 : z < 1 := zCG_lt_one delta hdelta
  have h1mz_pos : 0 < 1 - z := by linarith
  -- inflection identity in the form  δ(1-z)^{1/2} = z^{-3/2}·(1-z)^2.
  have hinfl : delta * (1 - z) ^ ((1:ℝ)/2) = z ^ (-(3:ℝ)/2) * (1 - z) ^ 2 := by
    have h := zCG_inflection delta hdelta
    rw [← hz_def] at h
    have hpow : (1 - z) ^ (-(3:ℝ)/2) * (1 - z) ^ (2:ℝ) = (1 - z) ^ ((1:ℝ)/2) := by
      rw [← Real.rpow_add h1mz_pos]; norm_num
    have hrw2 : (1 - z) ^ (2:ℝ) = (1 - z) ^ 2 := by
      rw [show (2:ℝ) = ((2:ℕ):ℝ) by norm_num, Real.rpow_natCast]
    calc delta * (1 - z) ^ ((1:ℝ)/2)
        = delta * ((1 - z) ^ (-(3:ℝ)/2) * (1 - z) ^ (2:ℝ)) := by rw [hpow]
      _ = (delta * (1 - z) ^ (-(3:ℝ)/2)) * (1 - z) ^ (2:ℝ) := by ring
      _ = z ^ (-(3:ℝ)/2) * (1 - z) ^ (2:ℝ) := by rw [h]
      _ = z ^ (-(3:ℝ)/2) * (1 - z) ^ 2 := by rw [hrw2]
  -- Convert the rpow atoms to s := √z, then generalize.
  have hsqrt_sq : Real.sqrt z ^ 2 = z := Real.sq_sqrt (le_of_lt hz0)
  have hsqrt_pos : 0 < Real.sqrt z := Real.sqrt_pos.mpr hz0
  have h_half : z ^ ((1:ℝ)/2) = Real.sqrt z := (Real.sqrt_eq_rpow z).symm
  have hzinv : z ^ (-(1:ℝ)/2) = (Real.sqrt z)⁻¹ := by
    rw [show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt hz0), h_half]
  have hz3inv : z ^ (-(3:ℝ)/2) = (Real.sqrt z ^ 3)⁻¹ := by
    rw [show (-(3:ℝ)/2) = ((1:ℝ)/2) * (-3) by ring, Real.rpow_mul (le_of_lt hz0), h_half,
        Real.rpow_neg (le_of_lt hsqrt_pos), ← Real.rpow_natCast (Real.sqrt z) 3]
    norm_num
  rw [zBracket, hinfl, hzinv, hz3inv, h_half]
  -- goal now has √z (several) and z (only inside (1-z)^2); generalize √z to s,
  -- then rewrite the remaining z via z = s^2.
  generalize hs : Real.sqrt z = s at hsqrt_pos hsqrt_sq ⊢
  -- hsqrt_sq : s ^ 2 = z
  rw [← hsqrt_sq]
  have hs_ne : s ≠ 0 := ne_of_gt hsqrt_pos
  have hbracket_eq :
      (1/2) * ((s ^ 3)⁻¹ * (1 - s ^ 2) ^ 2 - s) - (1/2) * s⁻¹ + 1
        = ((s - 1) ^ 2 * (s + 1/2)) / s ^ 3 := by
    field_simp
    ring
  rw [hbracket_eq]
  positivity

/-- **Slope identity at `z` (appendix lines 143–151).**  For any `z` with `0 < z < 1`,
`u₁'(z)·(1−z) + u₁(z) = (1+c)·bracket(z)`, a pure algebraic identity obtained by
expanding `u1deriv`/`u1delta` and using `(1-z)^{-1/2}(1-z) = (1-z)^{1/2}` and
`z^{-1/2}(1-z) = z^{-1/2} − z^{1/2}`. -/
theorem u1deriv_slope_identity (c delta z : ℝ) (hz0 : 0 < z) (hz1 : z < 1) :
    u1deriv c delta z * (1 - z) + u1delta c delta z = (1 + c) * zBracket delta z := by
  have h1mz_pos : 0 < 1 - z := by linarith
  -- Key rpow relations.
  have hz_rel : z ^ (-(1:ℝ)/2) * z = z ^ ((1:ℝ)/2) := by
    nth_rewrite 2 [← Real.rpow_one z]
    rw [← Real.rpow_add hz0]; norm_num
  have h1mz_rel : (1 - z) ^ (-(1:ℝ)/2) * (1 - z) = (1 - z) ^ ((1:ℝ)/2) := by
    nth_rewrite 2 [← Real.rpow_one (1 - z)]
    rw [← Real.rpow_add h1mz_pos]; norm_num
  rw [u1deriv, u1delta, zBracket]
  -- expand the product and use the relations.
  have e1 : (1 - z) ^ (-(1:ℝ)/2) * (1 - z) = (1 - z) ^ ((1:ℝ)/2) := h1mz_rel
  have e2 : z ^ (-(1:ℝ)/2) * (1 - z) = z ^ (-(1:ℝ)/2) - z ^ ((1:ℝ)/2) := by
    rw [mul_sub, mul_one, hz_rel]
  linear_combination (-(1/2) * (1 + c) * delta) * e1 - ((1/2) * (1 + c)) * e2

/-- **The minimality sign (appendix line 139): at a right-endpoint minimum, the
derivative is `≤ 0`.**  If `a1v` minimizes `u1delta c delta` on `[0, M]` and
`a1v ≤ M` (so `a1v` is at or left of the right endpoint, with `0 < a1v`), then
`u1deriv c delta a1v ≤ 0`. -/
theorem u1deriv_nonpos_at_rightmin (c delta M a1v : ℝ)
    (ha1v_pos : 0 < a1v) (ha1v_lt_one : a1v < 1) (ha1v_le_M : a1v ≤ M)
    (hmin : ∀ a ∈ Set.Icc (0 : ℝ) M, u1delta c delta a1v ≤ u1delta c delta a) :
    u1deriv c delta a1v ≤ 0 := by
  have hderiv : HasDerivAt (fun x => u1delta c delta x) (u1deriv c delta a1v) a1v :=
    u1delta_hasDerivAt c delta a1v ha1v_pos ha1v_lt_one
  -- slope from the left tends to the derivative
  have htends := hderiv.tendsto_slope_zero_left
  -- eventually the slope is ≤ 0 for t ∈ (-a1v, 0)
  have hev : ∀ᶠ t : ℝ in nhdsWithin 0 (Set.Iio 0),
      t⁻¹ • ((fun x => u1delta c delta x) (a1v + t) - (fun x => u1delta c delta x) a1v) ≤ 0 := by
    have hmemIoo : Set.Ioo (-a1v) 0 ∈ nhdsWithin (0:ℝ) (Set.Iio 0) :=
      Ioo_mem_nhdsLT (by linarith)
    filter_upwards [hmemIoo] with t ht
    have ht_neg : t < 0 := ht.2
    have ht_gt : -a1v < t := ht.1
    have hxt_pos : 0 < a1v + t := by linarith
    have hxt_lt_M : a1v + t ≤ M := by linarith
    have hxt_mem : a1v + t ∈ Set.Icc (0:ℝ) M := ⟨le_of_lt hxt_pos, hxt_lt_M⟩
    have hval : u1delta c delta a1v ≤ u1delta c delta (a1v + t) := hmin _ hxt_mem
    have hnum_nonneg : 0 ≤ (fun x => u1delta c delta x) (a1v + t) - (fun x => u1delta c delta x) a1v := by
      simp only; linarith
    have htinv_neg : t⁻¹ < 0 := inv_lt_zero.mpr ht_neg
    rw [smul_eq_mul]
    exact mul_nonpos_of_nonpos_of_nonneg (le_of_lt htinv_neg) hnum_nonneg
  exact le_of_tendsto htends hev

/-- **CGOptimalSolutionForA1**.  Port of appendix.tex 116–166. -/
theorem CGOptimalSolutionForA1
    (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1)
    (delta : ℝ) (hdelta : 0 < delta)
    (a1v : ℝ)
    (hmem : a1v ∈ Set.Icc (0 : ℝ) (min (zCG delta) ((1 - c) / 2)))
    (hmin : ∀ a ∈ Set.Icc (0 : ℝ) (min (zCG delta) ((1 - c) / 2)),
      u1delta c delta a1v ≤ u1delta c delta a)
    (hzero : u1delta c delta a1v = 0) :
    u1deriv c delta a1v = 0 ∨ a1v = (1 - c) / 2 := by
  set M : ℝ := min (zCG delta) ((1 - c) / 2) with hM_def
  have hzCG_pos : 0 < zCG delta := zCG_pos delta hdelta
  have h1c2_pos : 0 < (1 - c) / 2 := by linarith
  have hM_pos : 0 < M := lt_min hzCG_pos h1c2_pos
  have hM_le_half : M ≤ (1 - c) / 2 := min_le_right _ _
  have hM_le_z : M ≤ zCG delta := min_le_left _ _
  have hM_lt_one : M < 1 := by
    have : (1 - c) / 2 < 1 := by linarith
    linarith [hM_le_half]
  have ha1v_nn : 0 ≤ a1v := hmem.1
  have ha1v_le_M : a1v ≤ M := hmem.2
  have ha1v_lt_one : a1v < 1 := lt_of_le_of_lt ha1v_le_M hM_lt_one
  -- Case split on whether a1v = (1-c)/2.
  by_cases hcase : a1v = (1 - c) / 2
  · exact Or.inr hcase
  · -- a1v < (1-c)/2, so a1v is to the left of the constraint boundary.
    refine Or.inl ?_
    have ha1v_lt_half : a1v < (1 - c) / 2 := lt_of_le_of_ne (le_trans ha1v_le_M hM_le_half) hcase
    -- STEP 1: rule out a1v = 0, i.e. 0 < a1v.
    have ha1v_pos : 0 < a1v := by
      rcases lt_or_eq_of_le ha1v_nn with h | h
      · exact h
      · exfalso
        -- a1v = 0, u1delta(0)=0; build a point with smaller value.
        have ha1v_eq : a1v = 0 := h.symm
        set b : ℝ := ((1 + c) / 4) ^ 2 with hb_def
        have hb_pos : 0 < b := by positivity
        set a0 : ℝ := min M b / 2 with ha0_def
        have hminMb_pos : 0 < min M b := lt_min hM_pos hb_pos
        have ha0_pos : 0 < a0 := by positivity
        have ha0_lt_M : a0 < M := by
          have : min M b ≤ M := min_le_left _ _
          have h2 : a0 < min M b := by
            rw [ha0_def]; linarith [hminMb_pos]
          linarith
        have ha0_lt_b : a0 < b := by
          have : min M b ≤ b := min_le_right _ _
          have h2 : a0 < min M b := by rw [ha0_def]; linarith [hminMb_pos]
          linarith
        have ha0_lt_one : a0 < 1 := lt_trans ha0_lt_M hM_lt_one
        -- u1delta strictly decreasing on [0, a0]: derivative negative on (0, a0).
        have hanti : StrictAntiOn (fun x => u1delta c delta x) (Set.Icc (0:ℝ) a0) := by
          apply strictAntiOn_of_hasDerivWithinAt_neg (convex_Icc 0 a0)
            (u1delta_continuousOn c delta a0 ha0_lt_one)
          · intro x hx
            rw [interior_Icc] at hx
            have hx0 : 0 < x := hx.1
            have hx_lt_a0 : x < a0 := hx.2
            have hx_lt_one : x < 1 := lt_trans hx_lt_a0 ha0_lt_one
            exact (u1delta_hasDerivAt c delta x hx0 hx_lt_one).hasDerivWithinAt
          · intro x hx
            rw [interior_Icc] at hx
            have hx0 : 0 < x := hx.1
            have hx_lt_a0 : x < a0 := hx.2
            have hx_lt_one : x < 1 := lt_trans hx_lt_a0 ha0_lt_one
            have hx_lt_b : x < b := lt_trans hx_lt_a0 ha0_lt_b
            exact u1deriv_neg_near_zero c delta x hc0 hdelta hx0 hx_lt_one hx_lt_b
        -- so u1delta(a0) < u1delta(0).
        have hmem0 : (0:ℝ) ∈ Set.Icc (0:ℝ) a0 := ⟨le_refl _, le_of_lt ha0_pos⟩
        have hmema0 : a0 ∈ Set.Icc (0:ℝ) a0 := ⟨le_of_lt ha0_pos, le_refl _⟩
        have hdecr : (fun x => u1delta c delta x) a0 < (fun x => u1delta c delta x) 0 :=
          hanti hmem0 hmema0 ha0_pos
        simp only at hdecr
        have hu0_eq : u1delta c delta (0:ℝ) = u1delta c delta a1v := by rw [ha1v_eq]
        rw [hu0_eq, hzero] at hdecr
        -- a0 ∈ [0, M] so by minimality 0 ≤ u1delta(a0).
        have ha0_mem : a0 ∈ Set.Icc (0:ℝ) M := ⟨le_of_lt ha0_pos, le_of_lt ha0_lt_M⟩
        have := hmin a0 ha0_mem
        rw [hzero] at this
        linarith
    -- STEP 2: split on whether a1v is interior (a1v < M) or at the right endpoint.
    rcases lt_or_eq_of_le ha1v_le_M with hlt | heq
    · -- Interior case: Fermat's theorem.  a1v ∈ (0,M), global min on [0,M].
      have ha1v_int : a1v ∈ Set.Ioo (0:ℝ) M := ⟨ha1v_pos, hlt⟩
      have hderiv : HasDerivAt (fun x => u1delta c delta x) (u1deriv c delta a1v) a1v :=
        u1delta_hasDerivAt c delta a1v ha1v_pos ha1v_lt_one
      have hlocmin : IsLocalMin (fun x => u1delta c delta x) a1v := by
        have hnhds : Set.Ioo (0:ℝ) M ∈ nhds a1v := isOpen_Ioo.mem_nhds ha1v_int
        rw [IsLocalMin, IsMinFilter]
        filter_upwards [hnhds] with x hx
        have hx_mem : x ∈ Set.Icc (0:ℝ) M := ⟨le_of_lt hx.1, le_of_lt hx.2⟩
        exact hmin x hx_mem
      exact hlocmin.hasDerivAt_eq_zero hderiv
    · -- Right-endpoint case: a1v = M.  Since a1v < (1-c)/2, M < (1-c)/2, so
      -- M = zCG delta and a1v = z.  Then u1deriv ≤ 0 (minimality) and u1deriv ≥ 0
      -- (slope identity + bracket ≥ 0), hence u1deriv = 0.
      have ha1v_eq_M : a1v = M := heq
      have hM_lt_half : M < (1 - c) / 2 := by rw [← ha1v_eq_M]; exact ha1v_lt_half
      have hz_le_half : zCG delta ≤ (1 - c) / 2 := by
        by_contra hcon
        push_neg at hcon
        have : M = (1 - c) / 2 := by rw [hM_def]; exact min_eq_right (le_of_lt hcon)
        linarith
      have hM_eq_z : M = zCG delta := by rw [hM_def]; exact min_eq_left hz_le_half
      have ha1v_eq_z : a1v = zCG delta := by rw [ha1v_eq_M, hM_eq_z]
      have hz_lt_half : zCG delta ≤ 1 / 2 := le_trans hz_le_half (by linarith)
      -- minimality ⟹ u1deriv ≤ 0.
      have hle : u1deriv c delta a1v ≤ 0 :=
        u1deriv_nonpos_at_rightmin c delta M a1v ha1v_pos ha1v_lt_one ha1v_le_M hmin
      -- slope identity at z with u1delta(a1v) = 0.
      have hident := u1deriv_slope_identity c delta a1v ha1v_pos ha1v_lt_one
      rw [hzero] at hident
      -- bracket ≥ 0 at z = zCG delta = a1v.
      have hbr : 0 ≤ zBracket delta a1v := by
        rw [ha1v_eq_z]; exact zBracket_nonneg delta hdelta hz_lt_half
      have h1c_pos : (0:ℝ) < 1 + c := by linarith
      have h1mz_pos : 0 < 1 - a1v := by linarith [ha1v_lt_one]
      -- u1deriv(a1v)·(1-a1v) + 0 = (1+c)·bracket ≥ 0, and (1-a1v) > 0, so u1deriv ≥ 0.
      have hge : 0 ≤ u1deriv c delta a1v := by
        have hprod_nonneg : 0 ≤ u1deriv c delta a1v * (1 - a1v) := by
          have : u1deriv c delta a1v * (1 - a1v) = (1 + c) * zBracket delta a1v := by
            linarith [hident]
          rw [this]; positivity
        nlinarith [hprod_nonneg, h1mz_pos]
      linarith

end Workspace.ProofLemmas.CGOptimalSolutionForA1

open Workspace.ProofLemmas.CGDefs

namespace Workspace.ProofLemmas.CGABranchComparison

/-- **CGABranchComparison** (prediction.tex line 197; appendix `a₁'` vs `(1-c)/2`).
For `c ≥ 0`, with `a₁' = (2 + c − √(3+2c))/2 = a1' c`:
`a₁' ≤ (1-c)/2 ⟺ c ≤ 1/2`.
(Proof: `a₁' − (1-c)/2 = (1 + 2c − √(3+2c))/2`, so the inequality is
`√(3+2c) ≥ 1 + 2c`; squaring both nonnegative sides gives
`0 ≥ 2(2c−1)(c+1) ⟺ c ≤ 1/2`.) -/
theorem CGABranchComparison_iff (c : ℝ) (hc : 0 ≤ c) :
    a1' c ≤ (1 - c) / 2 ↔ c ≤ 1 / 2 := by
  unfold a1'
  rw [div_le_div_iff_of_pos_right (show (0:ℝ) < 2 by norm_num)]
  constructor
  · intro h
    nlinarith [Real.sq_sqrt (show (0:ℝ) ≤ 3 + 2 * c by linarith),
      Real.sqrt_nonneg (3 + 2 * c)]
  · intro h
    nlinarith [Real.sq_sqrt (show (0:ℝ) ≤ 3 + 2 * c by linarith),
      Real.sqrt_nonneg (3 + 2 * c),
      Real.sqrt_le_sqrt (show (1 + 2 * c) ^ 2 ≤ 3 + 2 * c by nlinarith),
      Real.sqrt_sq (show (0:ℝ) ≤ 1 + 2 * c by linarith)]

/-- Consequently the branched optimum `a1 c` is the interior root for `c < 1/2`
and the constraint boundary `(1-c)/2` for `c ≥ 1/2` — i.e. `a1` agrees with its
definition, which is the content of the branch selection from
`CGOptimalSolutionForA1` (`a₁ = a₁'` when the interior point is feasible, i.e.
`a₁' ≤ (1-c)/2`; otherwise `a₁ = (1-c)/2`). -/
theorem CGABranchComparison_value (c : ℝ) (hc : 0 ≤ c) :
    (c < 1 / 2 → a1 c = a1' c) ∧ (1 / 2 ≤ c → a1 c = (1 - c) / 2) := by
  exact ⟨fun h => by unfold a1; rw [if_pos h],
    fun h => by unfold a1; rw [if_neg (by linarith)]⟩

end Workspace.ProofLemmas.CGABranchComparison

open Workspace.ProofLemmas.CGDefs

namespace Workspace.ProofLemmas.CGInteriorRoot

/-- **CGInteriorRoot** (appendix.tex 190–196). For `c ≥ 0` the quadratic factor
`2t² + 2t − (1+c) = 0` has a unique nonnegative root `t₁ = (−1 + √(3+2c))/2`
(the other root `(−1 − √(3+2c))/2 < 0` is rejected since `t₁ = √(a₁') ≥ 0`).
Consequently the interior critical point of `u₁` is
`a₁' = t₁² = (2 + c − √(3+2c))/2 = a1' c`.

The statement bundles: (a) `t₁` is a root of the quadratic, (b) `t₁ ≥ 0`,
(c) the negative root is `< 0`, (d) `a₁' = t₁²` matches `a1' c`. -/
theorem CGInteriorRoot (c : ℝ) (hc : 0 ≤ c) :
    let t1 : ℝ := (-1 + Real.sqrt (3 + 2 * c)) / 2
    (2 * t1 ^ 2 + 2 * t1 - (1 + c) = 0) ∧
    (0 ≤ t1) ∧
    ((-1 - Real.sqrt (3 + 2 * c)) / 2 < 0) ∧
    (a1' c = t1 ^ 2) := by
  intro t1
  have h3 : (0:ℝ) ≤ 3 + 2 * c := by linarith
  set s := Real.sqrt (3 + 2 * c) with hs_def
  have hs_nonneg : 0 ≤ s := Real.sqrt_nonneg _
  have hs_sq : s ^ 2 = 3 + 2 * c := by rw [hs_def, sq, Real.mul_self_sqrt h3]
  have hs_ge1 : 1 ≤ s := by
    rw [hs_def, show (1:ℝ) = Real.sqrt 1 by simp]
    exact Real.sqrt_le_sqrt (by linarith)
  have ht1 : t1 = (-1 + s) / 2 := rfl
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [ht1]; nlinarith [hs_sq]
  · rw [ht1]; linarith
  · linarith
  · rw [ht1]
    show a1' c = ((-1 + s) / 2) ^ 2
    rw [a1']; nlinarith [hs_sq]

end Workspace.ProofLemmas.CGInteriorRoot

open Workspace.ProofLemmas.CGDefs
open Workspace.ProofLemmas.CGABranchComparison
open Workspace.ProofLemmas.CGInteriorRoot

namespace Workspace.ProofLemmas.CGDeltaLambdaLowBranch

theorem CGDeltaLambdaLowBranch (c : ℝ) (hc_lo : 0 ≤ c) (hc_hi : c < 1 / 2) :
    let a1v : ℝ := a1' c
    let d1sq : ℝ :=
      ((1 - 2 * a1v - c) / (1 + c) + a1v ^ ((1 : ℝ) / 2)) ^ 2 / (1 - a1v)
    (lambda1 c = (1 + d1sq) ^ (-(1 : ℝ) / 2)) ∧
    (lambda1 c =
      (c + 1) *
        (Real.sqrt
          (4 * Real.sqrt (2 * c + 3) * c + 6 * Real.sqrt (2 * c + 3) - 10 * c - 8))⁻¹) ∧
    (1 / lambda1 c = Workspace.ConsistencyTheorem.CG c) := by
  intro a1v d1sq
  -- Surd setup: s = √(2c+3) = √(3+2c)
  have h23 : (0:ℝ) ≤ 2 * c + 3 := by linarith
  set s := Real.sqrt (2 * c + 3) with hs_def
  have hs_nonneg : 0 ≤ s := Real.sqrt_nonneg _
  have hs_sq : s ^ 2 = 2 * c + 3 := by rw [hs_def, sq, Real.mul_self_sqrt h23]
  have hs_ge1 : 1 ≤ s := by
    rw [hs_def, show (1:ℝ) = Real.sqrt 1 by simp]
    exact Real.sqrt_le_sqrt (by linarith)
  have hsr : Real.sqrt (3 + 2 * c) = s := by
    rw [hs_def]; congr 1; ring
  -- s > c  (needed for 1 - a > 0):  s² = 2c+3 > c² for c ≥ 0
  have hs_gt_c : c < s := by nlinarith [hs_sq, hs_nonneg, sq_nonneg (s - c)]
  -- helper: (y²)^(1/2) = y for y ≥ 0
  have hsqrt_sq : ∀ (y:ℝ), 0 ≤ y → (y ^ 2) ^ ((1:ℝ)/2) = y := by
    intro y hy; rw [← Real.rpow_natCast y 2, ← Real.rpow_mul hy]; norm_num
  -- a1' c = (2 + c - s)/2
  have ha1v : a1v = (2 + c - s) / 2 := by
    show a1' c = (2 + c - s) / 2
    rw [a1', hsr]
  -- (a1' c)^(1/2) = t1 = (-1 + s)/2
  have ht1_nonneg : (0:ℝ) ≤ (-1 + s) / 2 := by linarith
  have ha1v_eq_sq : a1v = ((-1 + s) / 2) ^ 2 := by
    rw [ha1v]; nlinarith [hs_sq]
  have hasqrt : a1v ^ ((1 : ℝ) / 2) = (-1 + s) / 2 := by
    rw [ha1v_eq_sq, hsqrt_sq _ ht1_nonneg]
  -- positivity facts
  have hc1_pos : (0:ℝ) < c + 1 := by linarith
  have h1c_pos : (0:ℝ) < 1 + c := by linarith
  have h1ma_pos : (0:ℝ) < 1 - a1v := by rw [ha1v]; linarith
  set R : ℝ := 4 * s * c + 6 * s - 10 * c - 8 with hR_def
  have hR_pos : (0:ℝ) < R := by
    rw [hR_def]; nlinarith [hs_sq, hs_ge1, hs_gt_c, mul_nonneg hs_nonneg hc_lo]
  have hsqrtR_pos : (0:ℝ) < Real.sqrt R := Real.sqrt_pos.mpr hR_pos
  -- KEY identity: 1 + d1sq = R / (c+1)²
  have hkey : 1 + d1sq = R / (c + 1) ^ 2 := by
    show 1 + ((1 - 2 * a1v - c) / (1 + c) + a1v ^ ((1:ℝ)/2)) ^ 2 / (1 - a1v)
        = R / (c + 1) ^ 2
    rw [hasqrt, ha1v, hR_def]
    rw [show (1:ℝ) - (2 + c - s) / 2 = (s - c) / 2 by ring]
    have hsc : s - c ≠ 0 := by nlinarith [hs_gt_c]
    field_simp
    linear_combination (c ^ 4 - 6 * c ^ 2 - 8 * c - 3) * hs_sq
  -- conjunct 2 (and lambda1 closed form): lambda1 c = (c+1) * (√R)⁻¹
  have hlam : lambda1 c = (c + 1) * (Real.sqrt R)⁻¹ := by
    rw [lambda1, if_pos hc_hi, hR_def]
  -- rpow building blocks
  have hden : ((c + 1) ^ 2 : ℝ) ^ (-(1:ℝ) / 2) = (c + 1)⁻¹ := by
    rw [show (c + 1) ^ 2 = (c + 1) ^ (2:ℕ) by norm_num,
        ← Real.rpow_natCast (c + 1) 2, ← Real.rpow_mul (le_of_lt hc1_pos),
        show ((2:ℕ):ℝ) * (-(1:ℝ) / 2) = -1 by norm_num, Real.rpow_neg_one]
  have hnum : (R : ℝ) ^ (-(1:ℝ) / 2) = (Real.sqrt R)⁻¹ := by
    rw [Real.sqrt_eq_rpow, show (-(1:ℝ) / 2) = -(1 / 2) by ring,
        Real.rpow_neg (le_of_lt hR_pos)]
  -- (1 + d1sq)^(-1/2) = (c+1) * (√R)⁻¹
  have hpow : (1 + d1sq) ^ (-(1:ℝ) / 2) = (c + 1) * (Real.sqrt R)⁻¹ := by
    rw [hkey, Real.div_rpow (le_of_lt hR_pos) (by positivity), hden, hnum]
    rw [div_eq_mul_inv, inv_inv, mul_comm]
  refine ⟨?_, hlam, ?_⟩
  · rw [hlam, hpow]
  · -- 1 / lambda1 c = CG c
    rw [hlam, Workspace.ConsistencyTheorem.CG, if_pos hc_hi, hR_def]
    rw [one_div, mul_inv, inv_inv, div_eq_mul_inv]
    ring

end Workspace.ProofLemmas.CGDeltaLambdaLowBranch

open Workspace.ProofLemmas.CGDefs
open Workspace.ProofLemmas.CGABranchComparison

namespace Workspace.ProofLemmas.CGDeltaLambdaHighBranch

/-- **CGDeltaLambdaHighBranch** (prediction.tex line 92; appendix.tex 215–220).
For `c ∈ [1/2, 1)`, with `a₁ = (1-c)/2` (so the term `(1−2a₁−c)/(1+c)` vanishes
since `1 − 2a₁ − c = 0`), the value `δ₁²` obtained from `u₁(a₁) = 0` is
`δ₁² = a₁/(1−a₁) = ((1-c)/2)/((1+c)/2) = (1-c)/(1+c)`, and the resulting
`λ₁ = (1 + δ₁²)^{-1/2} = (2/(1+c))^{-1/2} = √((c+1)/2)`, so
`1/λ₁ = √(2/(c+1)) = CG c`.

We state: on this branch the closed-form `lambda1 c` (defined as `√((c+1)/2)`)
satisfies the chain of equalities
`δ₁² = (1-c)/(1+c)`, `lambda1 c = (1 + δ₁²)^{-1/2} = √((c+1)/2)`, and
`1 / lambda1 c = CG c`. -/
theorem CGDeltaLambdaHighBranch (c : ℝ) (hc_lo : 1 / 2 ≤ c) (hc_hi : c < 1) :
    let a1v : ℝ := (1 - c) / 2
    let d1sq : ℝ := a1v / (1 - a1v)
    (d1sq = (1 - c) / (1 + c)) ∧
    (lambda1 c = (1 + d1sq) ^ (-(1 : ℝ) / 2)) ∧
    (lambda1 c = Real.sqrt ((c + 1) / 2)) ∧
    (1 / lambda1 c = Workspace.ConsistencyTheorem.CG c) := by
  have hc1 : (0 : ℝ) < 1 - c := by linarith
  have hc2 : (0 : ℝ) < 1 + c := by linarith
  have hcn : ¬ (c < 1 / 2) := by linarith
  have hlam : lambda1 c = Real.sqrt ((c + 1) / 2) := by
    unfold lambda1; rw [if_neg hcn]
  have hcg : Workspace.ConsistencyTheorem.CG c = Real.sqrt (2 / (c + 1)) := by
    unfold Workspace.ConsistencyTheorem.CG; rw [if_neg hcn]
  intro a1v d1sq
  have hd1 : d1sq = (1 - c) / (1 + c) := by
    show ((1 - c) / 2) / (1 - (1 - c) / 2) = (1 - c) / (1 + c)
    rw [div_eq_div_iff (by nlinarith) (by linarith)]
    ring
  refine ⟨hd1, ?_, hlam, ?_⟩
  · -- lambda1 c = (1 + d1sq) ^ (-1/2)
    have hsum : (1 : ℝ) + d1sq = 2 / (1 + c) := by
      rw [hd1]; field_simp; ring
    rw [hlam, hsum]
    have h2c : (0 : ℝ) < 2 / (1 + c) := by positivity
    rw [show (-1 / 2 : ℝ) = -(1 / 2 : ℝ) by ring, Real.rpow_neg (le_of_lt h2c),
      ← Real.sqrt_eq_rpow, ← Real.sqrt_inv]
    congr 1
    rw [inv_div]
    ring
  · -- 1 / lambda1 c = CG c
    rw [hlam, hcg, one_div, ← Real.sqrt_inv]
    congr 1
    rw [inv_div]

end Workspace.ProofLemmas.CGDeltaLambdaHighBranch

open Workspace.ProofLemmas.CGDefs

namespace Workspace.ProofLemmas.CGLambda1InUnitInterval

/-- **CGLambda1InUnitInterval** (prediction.tex 89–95; proof_nlp.md §5.5).
For every `c ∈ [0,1)`, the constant `λ₁ = lambda1 c` given by the two-branch
closed form satisfies `0 < λ₁ ∧ λ₁ < 1`; equivalently `CG c = 1/λ₁ > 1`.

* For `c < 1/2`: `4√(2c+3)c + 6√(2c+3) − 10c − 8 > (c+1)² > 0` (e.g. at `c = 0`,
  `6√3 − 8 > 1`, the `SixSqrtThreeMinusEightPos`-style bound), so `λ₁ < 1`.
* For `c ≥ 1/2`: `λ₁ = √((c+1)/2)` with `(c+1)/2 > 0` and `(c+1)/2 < 1 ⟺ c < 1`.

We state both `0 < λ₁ < 1` and `1 < CG c`. -/
theorem CGLambda1InUnitInterval (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) :
    0 < lambda1 c ∧ lambda1 c < 1 ∧ 1 < Workspace.ConsistencyTheorem.CG c := by
  unfold lambda1 Workspace.ConsistencyTheorem.CG
  by_cases hcase : c < 1 / 2
  · -- Low branch c ∈ [0, 1/2): λ₁ = (c+1)·(√D)⁻¹, CG = √D/(c+1), with
    -- D = 4√(2c+3)·c + 6√(2c+3) − 10c − 8.  We show (c+1)² < D, hence 0 < D and
    -- c+1 < √D, which yields all three conjuncts.
    rw [if_pos hcase, if_pos hcase]
    set s := Real.sqrt (2 * c + 3) with hs_def
    have hs_nonneg : 0 ≤ s := Real.sqrt_nonneg _
    have hs2 : s ^ 2 = 2 * c + 3 := by rw [hs_def, sq, Real.mul_self_sqrt (by linarith)]
    have hs_ge : (1 : ℝ) ≤ s := by nlinarith [hs2, hs_nonneg]
    set D := 4 * s * c + 6 * s - 10 * c - 8 with hD_def
    have hc1pos : (0 : ℝ) < c + 1 := by linarith
    have hDgt : (c + 1) ^ 2 < D := by
      nlinarith [hs2, hs_nonneg, hs_ge, hc0, hcase, sq_nonneg (s - 1),
        mul_nonneg hs_nonneg hc0]
    have hDpos : 0 < D := lt_trans (by positivity) hDgt
    have hsqrtD : c + 1 < Real.sqrt D := by
      rw [Real.lt_sqrt hc1pos.le]; exact hDgt
    have hsqrtDpos : 0 < Real.sqrt D := Real.sqrt_pos.mpr hDpos
    refine ⟨?_, ?_, ?_⟩
    · positivity
    · rw [mul_inv_lt_iff₀ hsqrtDpos]; linarith
    · rw [lt_div_iff₀ hc1pos]; linarith
  · -- High branch c ∈ [1/2, 1): λ₁ = √((c+1)/2), CG = √(2/(c+1)).
    rw [if_neg hcase, if_neg hcase]
    have hpos : (0 : ℝ) < (c + 1) / 2 := by linarith
    refine ⟨Real.sqrt_pos.mpr hpos, ?_, ?_⟩
    · rw [Real.sqrt_lt' (by norm_num : (0 : ℝ) < 1)]; nlinarith
    · rw [Real.lt_sqrt (by norm_num : (0 : ℝ) ≤ 1),
        lt_div_iff₀ (by linarith : (0 : ℝ) < c + 1)]
      linarith

end Workspace.ProofLemmas.CGLambda1InUnitInterval

open Workspace.ProofLemmas.CGDefs
open Workspace.ProofLemmas.HSecondDerivative
open Workspace.ProofLemmas.LambdaDeltaIdentity
open Workspace.ProofLemmas.CGABranchComparison
open Workspace.ProofLemmas.CGInteriorRoot
open Workspace.ProofLemmas.CGDeltaLambdaLowBranch
open Workspace.ProofLemmas.CGDeltaLambdaHighBranch
open Workspace.ProofLemmas.CGOptimalSolutionForA1
open Workspace.ProofLemmas.CGLambda1InUnitInterval

namespace Workspace.ProofLemmas.CGRelaxedCoreNonneg

set_option maxHeartbeats 4000000

/-- Second derivative of `u1delta c delta` at an interior point `0 < a < 1`:
`u₁''(a) = ((1+c)/4)·(a^{-3/2} − δ·(1−a)^{-3/2})`.  (No `δ ≥ 1` needed.) -/
theorem u1delta_secondDeriv (c delta a : ℝ) (ha0 : 0 < a) (ha1 : a < 1) :
    HasDerivAt (fun y => u1deriv c delta y)
      ((1 + c) / 4 * (a ^ (-(3:ℝ)/2) - delta * (1 - a) ^ (-(3:ℝ)/2))) a := by
  have ha_ne : a ≠ 0 := ne_of_gt ha0
  have h1ma_pos : 0 < 1 - a := by linarith
  have h1ma_ne : (1 - a) ≠ 0 := ne_of_gt h1ma_pos
  -- exponents
  set p1 : ℝ := -(1:ℝ)/2 with hp1_def
  set p2 : ℝ := -(3:ℝ)/2 with hp2_def
  have hexp : p1 - 1 = p2 := by rw [hp1_def, hp2_def]; norm_num
  -- d/da a^p1 = p1 * a^p2
  have hd_a : HasDerivAt (fun y : ℝ => y ^ p1) (p1 * a ^ p2) a := by
    have h := (hasDerivAt_id a).rpow_const (p := p1) (Or.inl ha_ne)
    rw [hexp] at h; simpa using h
  -- d/da (1-a)^p1 = p1 * (1-a)^p2 * (-1)
  have hd_inner : HasDerivAt (fun y : ℝ => 1 - y) (-1 : ℝ) a := by
    simpa using (hasDerivAt_id a).const_sub 1
  have hd_1ma : HasDerivAt (fun y : ℝ => (1 - y) ^ p1) (-1 * p1 * (1 - a) ^ p2) a := by
    have h := hd_inner.rpow_const (p := p1) (Or.inl h1ma_ne)
    rw [hexp] at h; exact h
  -- u1deriv c delta y = (1/2)*(1+c)*(-delta*(1-y)^p1 - y^p1) + 2
  have hfun : (fun y => u1deriv c delta y) =
      (fun y : ℝ => (1/2) * (1 + c) * (-delta * (1 - y) ^ p1 - y ^ p1) + 2) := by
    funext y; rw [u1deriv]
  rw [hfun]
  -- assemble
  have hd_d1ma : HasDerivAt (fun y : ℝ => -delta * (1 - y) ^ p1)
      (-delta * (-1 * p1 * (1 - a) ^ p2)) a := hd_1ma.const_mul (-delta)
  have hd_sub : HasDerivAt (fun y : ℝ => -delta * (1 - y) ^ p1 - y ^ p1)
      (-delta * (-1 * p1 * (1 - a) ^ p2) - p1 * a ^ p2) a := hd_d1ma.sub hd_a
  have hd_mul : HasDerivAt (fun y : ℝ => (1/2) * (1 + c) * (-delta * (1 - y) ^ p1 - y ^ p1))
      ((1/2) * (1 + c) * (-delta * (-1 * p1 * (1 - a) ^ p2) - p1 * a ^ p2)) a :=
    hd_sub.const_mul ((1/2) * (1 + c))
  have hd_total := hd_mul.add_const (2 : ℝ)
  convert hd_total using 1
  rw [hp1_def, hp2_def]; ring

/-- `ψ(a) = a^{-3/2} − δ·(1−a)^{-3/2}` is strictly antitone on `(0,1)` for `δ > 0`. -/
theorem u1psi_strictAnti (delta : ℝ) (hdelta : 0 < delta) :
    StrictAntiOn (fun a => a ^ (-(3:ℝ)/2) - delta * (1 - a) ^ (-(3:ℝ)/2)) (Set.Ioo (0:ℝ) 1) := by
  intro xx hxx yy hyy hxy
  have hx_pos : 0 < xx := hxx.1
  have hy_pos : 0 < yy := hyy.1
  have h1my_pos : 0 < 1 - yy := by linarith [hyy.2]
  have hp_neg : (-(3:ℝ)/2) < 0 := by norm_num
  have hxp : yy ^ (-(3:ℝ)/2) < xx ^ (-(3:ℝ)/2) :=
    Real.rpow_lt_rpow_of_neg hx_pos hxy hp_neg
  have h1mxy : 1 - yy < 1 - xx := by linarith
  have h1m_p : (1 - xx) ^ (-(3:ℝ)/2) < (1 - yy) ^ (-(3:ℝ)/2) :=
    Real.rpow_lt_rpow_of_neg h1my_pos h1mxy hp_neg
  have hd_mul : delta * (1 - xx) ^ (-(3:ℝ)/2) < delta * (1 - yy) ^ (-(3:ℝ)/2) :=
    mul_lt_mul_of_pos_left h1m_p hdelta
  simp only
  linarith

/-- `u1delta c δ` is convex on `[0, zCG δ]` (for `δ > 0`). -/
theorem u1delta_convexOn_left (c delta : ℝ) (hc0 : 0 ≤ c) (hdelta : 0 < delta) :
    ConvexOn ℝ (Set.Icc (0:ℝ) (zCG delta)) (fun y => u1delta c delta y) := by
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have hz_lt_one : zCG delta < 1 := zCG_lt_one delta hdelta
  have hcont : ContinuousOn (fun y => u1delta c delta y) (Set.Icc (0:ℝ) (zCG delta)) :=
    u1delta_continuousOn c delta (zCG delta) hz_lt_one
  apply convexOn_of_deriv2_nonneg (convex_Icc 0 (zCG delta)) hcont
  · rw [interior_Icc]
    intro y hy
    exact (u1delta_hasDerivAt c delta y hy.1
      (lt_trans hy.2 hz_lt_one)).differentiableAt.differentiableWithinAt
  · rw [interior_Icc]
    intro y hy
    have hy0 : 0 < y := hy.1
    have hy1 : y < 1 := lt_trans hy.2 hz_lt_one
    have hopen : IsOpen (Set.Ioo (0:ℝ) (zCG delta)) := isOpen_Ioo
    have hnhds : Set.Ioo (0:ℝ) (zCG delta) ∈ nhds y := hopen.mem_nhds hy
    have hloc : deriv (fun y => u1delta c delta y) =ᶠ[nhds y] fun z => u1deriv c delta z := by
      filter_upwards [hnhds] with z hz
      exact (u1delta_hasDerivAt c delta z hz.1 (lt_trans hz.2 hz_lt_one)).deriv
    have hd2 : DifferentiableAt ℝ (fun y => u1deriv c delta y) y :=
      (u1delta_secondDeriv c delta y hy0 hy1).differentiableAt
    exact (hd2.congr_of_eventuallyEq hloc).differentiableWithinAt
  · rw [interior_Icc]
    intro y hy
    have hy0 : 0 < y := hy.1
    have hy1 : y < 1 := lt_trans hy.2 hz_lt_one
    have hopen : IsOpen (Set.Ioo (0:ℝ) (zCG delta)) := isOpen_Ioo
    have hnhds : Set.Ioo (0:ℝ) (zCG delta) ∈ nhds y := hopen.mem_nhds hy
    have hloc : deriv (fun y => u1delta c delta y) =ᶠ[nhds y] fun z => u1deriv c delta z := by
      filter_upwards [hnhds] with z hz
      exact (u1delta_hasDerivAt c delta z hz.1 (lt_trans hz.2 hz_lt_one)).deriv
    have hd2_eq : deriv (deriv (fun y => u1delta c delta y)) y =
        deriv (fun y => u1deriv c delta y) y := hloc.deriv_eq
    simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
    rw [hd2_eq, (u1delta_secondDeriv c delta y hy0 hy1).deriv]
    -- second derivative ≥ 0 on (0,z): ψ(y) ≥ 0 since y ≤ z and ψ antitone, ψ(z)=0.
    have hpsi_z : (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) = 0 := by
      have h := zCG_inflection delta hdelta; linarith
    have hpsi_anti := u1psi_strictAnti delta hdelta
    have hy_in : y ∈ Set.Ioo (0:ℝ) 1 := ⟨hy0, hy1⟩
    have hz_in : zCG delta ∈ Set.Ioo (0:ℝ) 1 := ⟨hz_pos, hz_lt_one⟩
    have hpsi_y_nonneg : 0 ≤ y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) := by
      rcases eq_or_lt_of_le (le_of_lt hy.2) with heq | hlt
      · have : y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) =
            (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) := by rw [heq]
        rw [this, hpsi_z]
      · have := hpsi_anti hy_in hz_in hlt
        simp only at this
        linarith [hpsi_z]
    have h1c : 0 ≤ (1 + c) / 4 := by positivity
    have : 0 ≤ (1 + c) / 4 * (y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2)) :=
      mul_nonneg h1c hpsi_y_nonneg
    simpa using this

/-- `u1delta c δ` is concave on `[zCG δ, 1]` (for `δ > 0`). -/
theorem u1delta_concaveOn_right (c delta : ℝ) (hc0 : 0 ≤ c) (hdelta : 0 < delta) :
    ConcaveOn ℝ (Set.Icc (zCG delta) 1) (fun y => u1delta c delta y) := by
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have hz_lt_one : zCG delta < 1 := zCG_lt_one delta hdelta
  -- continuity on [z,1]: u1delta_continuousOn needs upper bound < 1, so handle endpoint 1 directly.
  have hcont : ContinuousOn (fun y => u1delta c delta y) (Set.Icc (zCG delta) 1) := by
    intro x hx
    have hx_ge : zCG delta ≤ x := hx.1
    have hx_le : x ≤ 1 := hx.2
    have hx_pos : 0 < x := lt_of_lt_of_le hz_pos hx_ge
    have h_inner : ContinuousAt (fun y : ℝ => 1 - y) x :=
      (continuous_const.sub continuous_id).continuousAt
    have h_outer : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) (1 - x) := by
      rcases eq_or_lt_of_le hx_le with hxone | hxlt
      · rw [hxone]; simpa using
          Real.continuousAt_rpow_const (0:ℝ) ((1:ℝ)/2) (Or.inr (by norm_num))
      · exact Real.continuousAt_rpow_const (1 - x) ((1:ℝ)/2) (Or.inl (by linarith))
    have h_1mx_pow : ContinuousAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/2)) x := h_outer.comp h_inner
    have h_d_1mx : ContinuousAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2)) x :=
      h_1mx_pow.const_mul delta
    have h_x_pow : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) x :=
      Real.continuousAt_rpow_const x ((1:ℝ)/2) (Or.inr (by norm_num))
    have h_diff : ContinuousAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2)) x :=
      h_d_1mx.sub h_x_pow
    have h_mul : ContinuousAt
        (fun y : ℝ => (1 + c) * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2))) x :=
      h_diff.const_mul (1 + c)
    have h_total : ContinuousAt (fun y => u1delta c delta y) x := by
      have : (fun y => u1delta c delta y) =
          (fun y : ℝ => (1 + c) * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2)) - 1 + 2 * y + c) := by
        funext y; rw [u1delta]
      rw [this]
      exact (((h_mul.sub continuousAt_const).add
        ((continuous_const.mul continuous_id).continuousAt)).add continuousAt_const)
    exact h_total.continuousWithinAt
  apply concaveOn_of_deriv2_nonpos (convex_Icc (zCG delta) 1) hcont
  · rw [interior_Icc]
    intro y hy
    exact (u1delta_hasDerivAt c delta y (lt_trans hz_pos hy.1) hy.2).differentiableAt.differentiableWithinAt
  · rw [interior_Icc]
    intro y hy
    have hy0 : 0 < y := lt_trans hz_pos hy.1
    have hopen : IsOpen (Set.Ioo (zCG delta) 1) := isOpen_Ioo
    have hnhds : Set.Ioo (zCG delta) 1 ∈ nhds y := hopen.mem_nhds hy
    have hloc : deriv (fun y => u1delta c delta y) =ᶠ[nhds y] fun z => u1deriv c delta z := by
      filter_upwards [hnhds] with z hz
      exact (u1delta_hasDerivAt c delta z (lt_trans hz_pos hz.1) hz.2).deriv
    have hd2 : DifferentiableAt ℝ (fun y => u1deriv c delta y) y :=
      (u1delta_secondDeriv c delta y hy0 hy.2).differentiableAt
    exact (hd2.congr_of_eventuallyEq hloc).differentiableWithinAt
  · rw [interior_Icc]
    intro y hy
    have hy0 : 0 < y := lt_trans hz_pos hy.1
    have hy1 : y < 1 := hy.2
    have hopen : IsOpen (Set.Ioo (zCG delta) 1) := isOpen_Ioo
    have hnhds : Set.Ioo (zCG delta) 1 ∈ nhds y := hopen.mem_nhds hy
    have hloc : deriv (fun y => u1delta c delta y) =ᶠ[nhds y] fun z => u1deriv c delta z := by
      filter_upwards [hnhds] with z hz
      exact (u1delta_hasDerivAt c delta z (lt_trans hz_pos hz.1) hz.2).deriv
    have hd2_eq : deriv (deriv (fun y => u1delta c delta y)) y =
        deriv (fun y => u1deriv c delta y) y := hloc.deriv_eq
    simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
    rw [hd2_eq, (u1delta_secondDeriv c delta y hy0 hy1).deriv]
    -- second derivative ≤ 0 on (z,1): ψ(y) ≤ 0 since y > z and ψ antitone, ψ(z)=0.
    have hpsi_z : (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) = 0 := by
      have h := zCG_inflection delta hdelta; linarith
    have hpsi_anti := u1psi_strictAnti delta hdelta
    have hy_in : y ∈ Set.Ioo (0:ℝ) 1 := ⟨hy0, hy1⟩
    have hz_in : zCG delta ∈ Set.Ioo (0:ℝ) 1 := ⟨hz_pos, hz_lt_one⟩
    have hpsi_y_nonpos : y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) ≤ 0 := by
      have := hpsi_anti hz_in hy_in hy.1
      simp only at this
      linarith [hpsi_z]
    have h1c : 0 ≤ (1 + c) / 4 := by positivity
    have : (1 + c) / 4 * (y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2)) ≤ 0 :=
      mul_nonpos_of_nonneg_of_nonpos h1c hpsi_y_nonpos
    simpa using this

/-- `u1delta c δ 1 = 0` (the right-endpoint zero). -/
theorem u1delta_at_one (c delta : ℝ) : u1delta c delta 1 = 0 := by
  unfold u1delta
  rw [show (1:ℝ) - 1 = 0 by ring, Real.zero_rpow (by norm_num), Real.one_rpow]
  ring

/-- **Nonnegativity engine.**  If `δ > 0` and `a₁ ∈ (0, zCG δ]` is an interior critical
zero of `u1delta c δ` (`u₁(a₁) = 0` and `u₁'(a₁) = 0`), then `u1delta c δ y ≥ 0` for all
`y ∈ [0,1]`.  (Convex on `[0,z]` with a stationary zero ⇒ `u₁ ≥ 0` there; concave on
`[z,1]` with `u₁(z) ≥ 0`, `u₁(1) = 0` ⇒ chord ⇒ `u₁ ≥ 0` there.) -/
theorem u1delta_nonneg_engine (c delta a1v : ℝ) (hc0 : 0 ≤ c) (hdelta : 0 < delta)
    (ha1v_pos : 0 < a1v) (ha1v_le_z : a1v ≤ zCG delta)
    (hu_zero : u1delta c delta a1v = 0)
    (hderiv_zero : u1deriv c delta a1v = 0) :
    ∀ y : ℝ, 0 ≤ y → y ≤ 1 → 0 ≤ u1delta c delta y := by
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have hz_lt_one : zCG delta < 1 := zCG_lt_one delta hdelta
  have ha1v_lt_one : a1v < 1 := lt_of_le_of_lt ha1v_le_z hz_lt_one
  set f : ℝ → ℝ := fun y => u1delta c delta y with hf_def
  have hconv : ConvexOn ℝ (Set.Icc (0:ℝ) (zCG delta)) f := u1delta_convexOn_left c delta hc0 hdelta
  have hconc : ConcaveOn ℝ (Set.Icc (zCG delta) 1) f := u1delta_concaveOn_right c delta hc0 hdelta
  have ha1v_mem : a1v ∈ Set.Icc (0:ℝ) (zCG delta) := ⟨le_of_lt ha1v_pos, ha1v_le_z⟩
  have hderiv_a1 : HasDerivAt f (u1deriv c delta a1v) a1v :=
    u1delta_hasDerivAt c delta a1v ha1v_pos ha1v_lt_one
  rw [hderiv_zero] at hderiv_a1
  -- STEP A: f ≥ 0 = f(a₁) on [0,z] (tangent below convex, slope 0).
  have hleft : ∀ y ∈ Set.Icc (0:ℝ) (zCG delta), 0 ≤ f y := by
    intro y hy
    have hfa1 : f a1v = 0 := hu_zero
    rcases lt_trichotomy y a1v with hlt | heq | hgt
    · -- y < a1v: slope f y a1v ≤ f'(a1v) = 0  ⟹ (f a1v - f y)/(a1v-y) ≤ 0 ⟹ f y ≥ f a1v
      have hsl := hconv.slope_le_of_hasDerivAt hy ha1v_mem hlt hderiv_a1
      rw [slope_def_field] at hsl
      have hpos : 0 < a1v - y := by linarith
      have : f a1v - f y ≤ 0 := by
        by_contra hcon
        push_neg at hcon
        have : 0 < (f a1v - f y) / (a1v - y) := div_pos hcon hpos
        linarith
      linarith [hfa1]
    · rw [heq, hfa1]
    · -- a1v < y: f'(a1v) = 0 ≤ slope f a1v y = (f y - f a1v)/(y-a1v) ⟹ f y ≥ f a1v
      have hsl := hconv.le_slope_of_hasDerivAt ha1v_mem hy hgt hderiv_a1
      rw [slope_def_field] at hsl
      have hpos : 0 < y - a1v := by linarith
      have : 0 ≤ f y - f a1v := by
        by_contra hcon
        push_neg at hcon
        have : (f y - f a1v) / (y - a1v) < 0 := div_neg_of_neg_of_pos hcon hpos
        linarith
      linarith [hfa1]
  -- u₁(z) ≥ 0.
  have hz_mem_left : zCG delta ∈ Set.Icc (0:ℝ) (zCG delta) := ⟨le_of_lt hz_pos, le_refl _⟩
  have hfz_nonneg : 0 ≤ f (zCG delta) := hleft _ hz_mem_left
  have hf_one : f 1 = 0 := u1delta_at_one c delta
  -- STEP B: f ≥ 0 on [z,1] via concavity chord.
  have hright : ∀ y ∈ Set.Icc (zCG delta) 1, 0 ≤ f y := by
    intro y hy
    have hz_mem : zCG delta ∈ Set.Icc (zCG delta) 1 := ⟨le_refl _, le_of_lt hz_lt_one⟩
    have hone_mem : (1:ℝ) ∈ Set.Icc (zCG delta) 1 := ⟨le_of_lt hz_lt_one, le_refl _⟩
    have hy_seg : y ∈ segment ℝ (zCG delta) 1 := by
      rw [segment_eq_Icc (le_of_lt hz_lt_one)]; exact hy
    have hchord := hconc.ge_on_segment hz_mem hone_mem hy_seg
    have hmin_nn : 0 ≤ min (f (zCG delta)) (f 1) := by
      rw [hf_one]; exact le_min hfz_nonneg (le_refl 0)
    exact le_trans hmin_nn hchord
  -- Combine.
  intro y hy0 hy1
  rcases le_or_gt y (zCG delta) with hyz | hyz
  · exact hleft y ⟨hy0, hyz⟩
  · exact hright y ⟨le_of_lt hyz, hy1⟩

/-- `0 < delta1 c` for `c ∈ [0,1)` (since `0 < λ₁ < 1`). -/
theorem delta1_pos (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) : 0 < delta1 c := by
  obtain ⟨hl0, hl1, _⟩ := CGLambda1InUnitInterval c hc0 hc1
  unfold delta1 delta_of_lambda
  have h1 : (1:ℝ) < lambda1 c ^ (-((2:ℝ)/(2-1))) := by
    rw [show (-((2:ℝ)/(2-1))) = (-2:ℝ) by norm_num,
      show (-2:ℝ) = -(2:ℝ) by norm_num, Real.rpow_neg hl0.le,
      show (2:ℝ) = ((2:ℕ):ℝ) by norm_num, Real.rpow_natCast]
    rw [one_lt_inv_iff₀]
    refine ⟨by positivity, ?_⟩
    nlinarith [hl0, hl1, sq_nonneg (lambda1 c)]
  apply Real.rpow_pos_of_pos; linarith

/-- **Low-branch pointwise nonnegativity** (`c < 1/2`): `u1 c y ≥ 0` for `y ∈ [0,1]`.
The interior critical point `a₁' = a1' c` is a stationary zero of `u₁` in the convex
region `(0, zCG δ₁]`, so the nonnegativity engine applies. -/
theorem low_branch_hu1_nonneg (c : ℝ) (hc0 : 0 ≤ c) (hc_hi : c < 1 / 2) :
    ∀ y : ℝ, 0 ≤ y → y ≤ 1 → 0 ≤ u1 c y := by
  have hc1 : c < 1 := by linarith
  have hd1pos : 0 < delta1 c := delta1_pos c hc0 hc1
  -- surd s = √(3+2c)
  have h3 : (0:ℝ) ≤ 3 + 2 * c := by linarith
  set s := Real.sqrt (3 + 2 * c) with hs_def
  have hs_nn : 0 ≤ s := Real.sqrt_nonneg _
  have hs_sq : s ^ 2 = 3 + 2 * c := by rw [hs_def, sq, Real.mul_self_sqrt h3]
  have hs_ge1 : 1 ≤ s := by
    rw [hs_def, show (1:ℝ) = Real.sqrt 1 by simp]; exact Real.sqrt_le_sqrt (by linarith)
  have hs_gt_c : c < s := by nlinarith [hs_sq, hs_nn, sq_nonneg (s - c)]
  -- a₁' and its square roots
  have ha1v : a1' c = (2 + c - s) / 2 := by rw [a1', hs_def]
  have ht_nn : (0:ℝ) ≤ (s - 1) / 2 := by linarith
  have ha1v_sq : a1' c = ((s - 1) / 2) ^ 2 := by rw [ha1v]; nlinarith [hs_sq]
  have ha1v_pos : 0 < a1' c := by
    rw [ha1v_sq]; have : (0:ℝ) < (s-1)/2 ∨ (s-1)/2 = 0 := by
      rcases eq_or_lt_of_le hs_ge1 with h | h
      · right; rw [← h]; ring
      · left; linarith
    rcases this with h | h
    · positivity
    · -- s = 1 ⟹ c such that 3+2c=1 ⟹ c=-1, impossible since c≥0
      exfalso; have : s = 1 := by linarith
      rw [this] at hs_sq; nlinarith [hc0]
  have hsqrt_a1v : (a1' c) ^ ((1:ℝ)/2) = (s - 1) / 2 := by
    rw [ha1v_sq, ← Real.rpow_natCast ((s-1)/2) 2, ← Real.rpow_mul ht_nn]
    norm_num
  have h1ma1v : 1 - a1' c = (s - c) / 2 := by rw [ha1v]; ring
  have h1ma1v_pos : 0 < 1 - a1' c := by rw [h1ma1v]; linarith
  have hc1pos : (0:ℝ) < 1 + c := by linarith
  have ha1v_lt_half : a1' c < (1 - c) / 2 := by
    have := (CGABranchComparison_iff c hc0).mpr (le_of_lt hc_hi)
    rcases lt_or_eq_of_le this with h | h
    · exact h
    · -- a₁' = (1-c)/2 would force c = 1/2, contradiction
      exfalso
      have : a1' c = (1 - c) / 2 := h
      rw [ha1v] at this; have hsc : s = 1 + 2 * c := by linarith
      rw [hsc] at hs_sq; nlinarith [hc_hi, hc0]
  -- δ₁ explicit: δ₁² = d1sq, and δ₁·√(1-a₁') = N with N ≥ 0.
  obtain ⟨hlam_eq, _, _⟩ := CGDeltaLambdaLowBranch c hc0 hc_hi
  obtain ⟨hl0, hl1, _⟩ := CGLambda1InUnitInterval c hc0 hc1
  -- abbreviations matching the surd forms
  set δ := delta1 c with hδ_def
  set rt : ℝ := (1 - a1' c) ^ ((1:ℝ)/2) with hrt_def
  have hrt_sq : rt ^ 2 = 1 - a1' c := by
    rw [hrt_def, ← Real.rpow_natCast _ 2, ← Real.rpow_mul (le_of_lt h1ma1v_pos)]; norm_num
  have hrt_pos : 0 < rt := by rw [hrt_def]; exact Real.rpow_pos_of_pos h1ma1v_pos _
  -- N (numerator), in surd form.
  set N : ℝ := (1 - 2 * a1' c - c) / (1 + c) + (a1' c) ^ ((1:ℝ)/2) with hN_def
  have hN_s : N = (s - 1 - 2 * c) / (1 + c) + (s - 1) / 2 := by
    rw [hN_def, hsqrt_a1v, ha1v]; congr 1; field_simp; ring
  have hN_nn : 0 ≤ N := by
    rw [hN_s]; rw [div_add_div _ _ (ne_of_gt hc1pos) (by norm_num : (2:ℝ) ≠ 0)]
    apply div_nonneg _ (by positivity)
    nlinarith [hs_ge1, hs_gt_c, hc0, hs_sq, sq_nonneg (s - 3)]
  -- δ² = d1sq = N²/(1-a₁')
  have hbase_nn : (0:ℝ) ≤ lambda1 c ^ (-((2:ℝ)/(2-1))) - 1 := by
    rw [show (-((2:ℝ)/(2-1))) = -(2:ℝ) by norm_num, Real.rpow_neg hl0.le,
      show (2:ℝ)=((2:ℕ):ℝ) by norm_num, Real.rpow_natCast,
      le_sub_iff_add_le, zero_add, one_le_inv_iff₀]
    exact ⟨by positivity, by nlinarith [hl0, hl1, sq_nonneg (lambda1 c)]⟩
  have hδ_sq : δ ^ 2 = lambda1 c ^ (-((2:ℝ)/(2-1))) - 1 := by
    rw [hδ_def]; unfold delta1 delta_of_lambda
    rw [← Real.rpow_natCast _ 2, ← Real.rpow_mul hbase_nn]; norm_num
  have hlaminv : lambda1 c ^ (-((2:ℝ)/(2-1))) = 1 + N ^ 2 / (1 - a1' c) := by
    rw [hlam_eq, ← Real.rpow_mul (by positivity)]
    rw [show (-(1:ℝ)/2) * (-((2:ℝ)/(2-1))) = 1 by norm_num, Real.rpow_one]
  have hδ_d1sq : δ ^ 2 * (1 - a1' c) = N ^ 2 := by
    rw [hδ_sq, hlaminv, hN_def]; field_simp; ring
  -- δ·rt = N (both nonneg, squares equal)
  have hδrt : δ * rt = N := by
    have hsq : (δ * rt) ^ 2 = N ^ 2 := by
      rw [mul_pow, hrt_sq]; exact hδ_d1sq
    have hδrt_nn : 0 ≤ δ * rt := by positivity
    nlinarith [hsq, hN_nn, hδrt_nn, sq_nonneg (δ * rt - N)]
  -- u₁(a₁') = 0.
  have hu_zero : u1 c (a1' c) = 0 := by
    show u1delta c δ (a1' c) = 0
    unfold u1delta
    rw [show (1 - a1' c) ^ ((1:ℝ)/2) = rt from rfl, hsqrt_a1v]
    have : δ * rt = (1 - 2 * a1' c - c) / (1 + c) + (s - 1) / 2 := by
      rw [hδrt, hN_def, hsqrt_a1v]
    rw [this, ha1v]; field_simp; ring
  -- FOC: u1deriv c δ (a₁') = 0.
  have hsqrt_a1v_pos : 0 < (a1' c) ^ ((1:ℝ)/2) := by rw [hsqrt_a1v]; linarith
  have hderiv_zero : u1deriv c δ (a1' c) = 0 := by
    unfold u1deriv
    have e1 : (1 - a1' c) ^ (-(1:ℝ)/2) = rt⁻¹ := by
      rw [hrt_def, show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt h1ma1v_pos)]
    have e2 : (a1' c) ^ (-(1:ℝ)/2) = ((a1' c) ^ ((1:ℝ)/2))⁻¹ := by
      rw [show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt ha1v_pos)]
    rw [e1, e2, hsqrt_a1v]
    -- want: ½(1+c)(-δ·rt⁻¹ - ((s-1)/2)⁻¹) + 2 = 0.
    -- Rewrite rt⁻¹ via δ·rt = N and rt² = 1-a₁': δ·rt⁻¹ = N/(1-a₁').
    have hs1 : s - 1 > 0 := by linarith
    have hsc : s - c > 0 := by linarith
    have hδrt_inv : δ * rt⁻¹ = N / (1 - a1' c) := by
      rw [eq_div_iff (ne_of_gt h1ma1v_pos), ← hrt_sq]
      have : δ * rt⁻¹ * rt ^ 2 = (δ * rt) * (rt⁻¹ * rt) := by ring
      rw [this, hδrt, inv_mul_cancel₀ (ne_of_gt hrt_pos), mul_one]
    have hbracket : -δ * rt⁻¹ - ((s - 1) / 2)⁻¹ = -(N / (1 - a1' c)) - ((s - 1) / 2)⁻¹ := by
      linear_combination -hδrt_inv
    have hgoal : (1 / 2) * (1 + c) * (-δ * rt⁻¹ - ((s - 1) / 2)⁻¹) + 2 = 0 := by
      rw [hbracket, hN_s, h1ma1v]
      have hsc' : (s - c) / 2 ≠ 0 := ne_of_gt (by linarith)
      have hs1' : (s - 1) / 2 ≠ 0 := ne_of_gt (by linarith)
      field_simp
      nlinarith [hs_sq, hs1, hsc, hc1pos]
    exact hgoal
  -- a₁' ≤ zCG δ : show u₁''(a₁') > 0 ⟹ ψ(a₁')>0=ψ(z) ⟹ a₁'<z.
  have hz_pos : 0 < zCG δ := zCG_pos δ hd1pos
  have hz_lt_one : zCG δ < 1 := zCG_lt_one δ hd1pos
  have ha1v_lt_one : a1' c < 1 := by linarith [ha1v_lt_half, hc0]
  have ht_pos : 0 < (s - 1) / 2 := by
    rcases eq_or_lt_of_le hs_ge1 with h | h
    · exfalso; have : s = 1 := h.symm; rw [this] at hs_sq; nlinarith [hc0]
    · linarith
  have hpsi_a1_pos : 0 < (a1' c) ^ (-(3:ℝ)/2) - δ * (1 - a1' c) ^ (-(3:ℝ)/2) := by
    -- a₁'^{-3/2} = ((s-1)/2)^{-3} = (((s-1)/2)^3)⁻¹
    have e_a3 : (a1' c) ^ (-(3:ℝ)/2) = (((s - 1) / 2) ^ 3)⁻¹ := by
      rw [ha1v_sq, ← Real.rpow_natCast (((s-1)/2)) 2, ← Real.rpow_mul ht_nn,
        show ((2:ℕ):ℝ) * (-(3:ℝ)/2) = -((3:ℕ):ℝ) by norm_num,
        Real.rpow_neg ht_nn, Real.rpow_natCast]
    -- (1-a₁')^{-3/2} = (rt^3)⁻¹  where rt = (1-a₁')^{1/2}
    have e_1ma3 : (1 - a1' c) ^ (-(3:ℝ)/2) = (rt ^ 3)⁻¹ := by
      have hrt3 : rt ^ 3 = (1 - a1' c) ^ ((3:ℝ)/2) := by
        rw [hrt_def, ← Real.rpow_natCast _ 3, ← Real.rpow_mul (le_of_lt h1ma1v_pos)]
        norm_num
      rw [hrt3, show (-(3:ℝ)/2) = -((3:ℝ)/2) by ring, Real.rpow_neg (le_of_lt h1ma1v_pos)]
    rw [e_a3, e_1ma3]
    -- δ·(rt³)⁻¹ = N/(1-a₁')² . Use δ·rt = N, rt² = 1-a₁'.
    have hδ_rt3 : δ * (rt ^ 3)⁻¹ = N / (1 - a1' c) ^ 2 := by
      rw [eq_div_iff (by positivity)]
      have hrtne : rt ≠ 0 := ne_of_gt hrt_pos
      have hkey : (rt ^ 3)⁻¹ * (1 - a1' c) ^ 2 = rt := by
        rw [← hrt_sq]
        field_simp
      calc δ * (rt ^ 3)⁻¹ * (1 - a1' c) ^ 2
          = δ * ((rt ^ 3)⁻¹ * (1 - a1' c) ^ 2) := by ring
        _ = δ * rt := by rw [hkey]
        _ = N := hδrt
    rw [hδ_rt3]
    -- goal: 0 < (((s-1)/2)^3)⁻¹ - N/(1-a₁')²
    rw [h1ma1v, hN_s]
    have hs1 : 0 < s - 1 := by linarith
    have hsc : 0 < s - c := by linarith
    rw [inv_eq_one_div, sub_pos, div_lt_div_iff₀ (by positivity) (by positivity)]
    rw [div_add_div _ _ (ne_of_gt hc1pos) (by norm_num : (2:ℝ) ≠ 0),
      div_mul_eq_mul_div, div_lt_iff₀ (by positivity)]
    nlinarith [hs_sq, hs1, hsc, hc1pos, hs_nn, sq_nonneg (s - 3), mul_pos hs1 hsc,
      mul_nonneg hs_nn (sq_nonneg (s - 3)), mul_pos (mul_pos hs1 hsc) hc1pos]
  have ha1v_le_z : a1' c ≤ zCG δ := by
    by_contra hcon
    push_neg at hcon
    have hz_in : zCG δ ∈ Set.Ioo (0:ℝ) 1 := ⟨hz_pos, hz_lt_one⟩
    have ha_in : a1' c ∈ Set.Ioo (0:ℝ) 1 := ⟨ha1v_pos, ha1v_lt_one⟩
    have hpsi_z : (zCG δ) ^ (-(3:ℝ)/2) - δ * (1 - zCG δ) ^ (-(3:ℝ)/2) = 0 := by
      have h := zCG_inflection δ hd1pos; linarith
    have := u1psi_strictAnti δ hd1pos hz_in ha_in hcon
    simp only at this
    linarith [hpsi_a1_pos, hpsi_z]
  -- Apply the engine.
  have hkey := u1delta_nonneg_engine c δ (a1' c) hc0 hd1pos ha1v_pos ha1v_le_z hu_zero hderiv_zero
  intro y hy0 hy1
  show 0 ≤ u1delta c δ y
  exact hkey y hy0 hy1

/- Helper lemmas for `CGRelaxedCoreNonneg` (the main statement is documented at
its declaration below). -/

/-- The calibrating identity `h = λ₁/(1+c)·(u₁ + 1 − 2x − c)`. -/
theorem h_eq_u1_affine (c : ℝ) (hc0 : 0 ≤ c) (y : ℝ) :
    h_q 2 (lambda1 c) (delta1 c) y
      = lambda1 c / (1 + c) * (u1 c y + 1 - 2 * y - c) := by
  have : (1 : ℝ) + c ≠ 0 := by positivity
  unfold h_q u1; field_simp; ring

/-- First derivative of `h_q 2 λ δ` at an interior point. -/
theorem h_firstDeriv (lam delta a : ℝ) (ha0 : 0 < a) (ha1 : a < 1) :
    HasDerivAt (fun y => h_q 2 lam delta y)
      (lam * (-delta * (1/2) * (1 - a) ^ (-(1:ℝ)/2) - (1/2) * a ^ (-(1:ℝ)/2))) a := by
  have ha_ne : a ≠ 0 := ne_of_gt ha0
  have h1ma_pos : 0 < 1 - a := by linarith
  have h1ma_ne : (1 - a) ≠ 0 := ne_of_gt h1ma_pos
  have hexp : (1:ℝ)/2 - 1 = -(1:ℝ)/2 := by norm_num
  have hd_a : HasDerivAt (fun y : ℝ => y ^ ((1:ℝ)/2)) ((1/2) * a ^ (-(1:ℝ)/2)) a := by
    have h := (hasDerivAt_id a).rpow_const (p := (1:ℝ)/2) (Or.inl ha_ne)
    rw [hexp] at h; simpa using h
  have hd_inner : HasDerivAt (fun y : ℝ => 1 - y) (-1 : ℝ) a := by
    simpa using (hasDerivAt_id a).const_sub 1
  have hd_1ma : HasDerivAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/2)) (-1 * ((1/2) * (1 - a) ^ (-(1:ℝ)/2))) a := by
    have h := hd_inner.rpow_const (p := (1:ℝ)/2) (Or.inl h1ma_ne)
    rw [hexp] at h; convert h using 1; ring
  have hd_d1ma : HasDerivAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2))
      (delta * (-1 * ((1/2) * (1 - a) ^ (-(1:ℝ)/2)))) a := hd_1ma.const_mul delta
  have hd_diff : HasDerivAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2))
      (delta * (-1 * ((1/2) * (1 - a) ^ (-(1:ℝ)/2))) - (1/2) * a ^ (-(1:ℝ)/2)) a := hd_d1ma.sub hd_a
  have hd_mul : HasDerivAt (fun y => h_q 2 lam delta y)
      (lam * (delta * (-1 * ((1/2) * (1 - a) ^ (-(1:ℝ)/2))) - (1/2) * a ^ (-(1:ℝ)/2))) a := by
    have : (fun y => h_q 2 lam delta y) = (fun y : ℝ => lam * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2))) := by
      funext y; rfl
    rw [this]; exact hd_diff.const_mul lam
  convert hd_mul using 1; ring

/-- The derivative of `h`'s first-derivative function: the second derivative of `h`,
`h''(y) = lam·(1/4)·(y^{-3/2} − δ·(1−y)^{-3/2})`.  Returns the matching `HasDerivAt`. -/
theorem h_secondDeriv_aux (lam delta y : ℝ) (hy0 : 0 < y) (hy1 : y < 1) :
    True ∧ HasDerivAt
      (fun z => lam * (-delta * (1/2) * (1 - z) ^ (-(1:ℝ)/2) - (1/2) * z ^ (-(1:ℝ)/2)))
      (lam * (1/4) * (y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2))) y := by
  refine ⟨trivial, ?_⟩
  have hy_ne : y ≠ 0 := ne_of_gt hy0
  have h1my_pos : 0 < 1 - y := by linarith
  have h1my_ne : (1 - y) ≠ 0 := ne_of_gt h1my_pos
  set p1 : ℝ := -(1:ℝ)/2 with hp1_def
  set p2 : ℝ := -(3:ℝ)/2 with hp2_def
  have hexp : p1 - 1 = p2 := by rw [hp1_def, hp2_def]; norm_num
  have hd_y : HasDerivAt (fun z : ℝ => z ^ p1) (p1 * y ^ p2) y := by
    have h := (hasDerivAt_id y).rpow_const (p := p1) (Or.inl hy_ne)
    rw [hexp] at h; simpa using h
  have hd_inner : HasDerivAt (fun z : ℝ => 1 - z) (-1 : ℝ) y := by
    simpa using (hasDerivAt_id y).const_sub 1
  have hd_1my : HasDerivAt (fun z : ℝ => (1 - z) ^ p1) (-1 * p1 * (1 - y) ^ p2) y := by
    have h := hd_inner.rpow_const (p := p1) (Or.inl h1my_ne)
    rw [hexp] at h; exact h
  have hd_d1my : HasDerivAt (fun z : ℝ => -delta * (1/2) * (1 - z) ^ p1)
      (-delta * (1/2) * (-1 * p1 * (1 - y) ^ p2)) y := hd_1my.const_mul (-delta * (1/2))
  have hd_y2 : HasDerivAt (fun z : ℝ => (1/2) * z ^ p1) ((1/2) * (p1 * y ^ p2)) y := hd_y.const_mul (1/2)
  have hd_sub : HasDerivAt (fun z : ℝ => -delta * (1/2) * (1 - z) ^ p1 - (1/2) * z ^ p1)
      (-delta * (1/2) * (-1 * p1 * (1 - y) ^ p2) - (1/2) * (p1 * y ^ p2)) y := hd_d1my.sub hd_y2
  have hd_mul := hd_sub.const_mul lam
  convert hd_mul using 1
  rw [hp1_def, hp2_def]; ring

/-- `h_q 2 λ δ` is convex on `[0, zCG δ]` (`δ > 0`, `0 ≤ lam`). -/
theorem h_convexOn_left_gen (lam delta : ℝ) (hlam : 0 ≤ lam) (hdelta : 0 < delta) :
    ConvexOn ℝ (Set.Icc (0:ℝ) (zCG delta)) (fun y => h_q 2 lam delta y) := by
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have hz_lt_one : zCG delta < 1 := zCG_lt_one delta hdelta
  have hcont : ContinuousOn (fun y => h_q 2 lam delta y) (Set.Icc (0:ℝ) (zCG delta)) := by
    intro x hx
    have hx_le : x ≤ zCG delta := hx.2
    have hx_lt_one : x < 1 := lt_of_le_of_lt hx_le hz_lt_one
    have h1mx_pos : 0 < 1 - x := by linarith
    have h_inner : ContinuousAt (fun y : ℝ => 1 - y) x := (continuous_const.sub continuous_id).continuousAt
    have h_outer : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) (1 - x) :=
      Real.continuousAt_rpow_const (1 - x) ((1:ℝ)/2) (Or.inl (ne_of_gt h1mx_pos))
    have h1 : ContinuousAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/2)) x := h_outer.comp h_inner
    have h2 : ContinuousAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2)) x := h1.const_mul delta
    have h3 : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) x :=
      Real.continuousAt_rpow_const x ((1:ℝ)/2) (Or.inr (by norm_num))
    have h4 : ContinuousAt (fun y => h_q 2 lam delta y) x := by
      have : (fun y => h_q 2 lam delta y) = (fun y : ℝ => lam * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2))) := by
        funext y; rfl
      rw [this]; exact (h2.sub h3).const_mul lam
    exact h4.continuousWithinAt
  apply convexOn_of_deriv2_nonneg (convex_Icc 0 (zCG delta)) hcont
  · rw [interior_Icc]; intro y hy
    exact (h_firstDeriv lam delta y hy.1 (lt_trans hy.2 hz_lt_one)).differentiableAt.differentiableWithinAt
  · rw [interior_Icc]; intro y hy
    have hy0 : 0 < y := hy.1
    have hy1 : y < 1 := lt_trans hy.2 hz_lt_one
    have hnhds : Set.Ioo (0:ℝ) (zCG delta) ∈ nhds y := isOpen_Ioo.mem_nhds hy
    have hloc : deriv (fun y => h_q 2 lam delta y) =ᶠ[nhds y]
        fun z => lam * (-delta * (1/2) * (1 - z) ^ (-(1:ℝ)/2) - (1/2) * z ^ (-(1:ℝ)/2)) := by
      filter_upwards [hnhds] with z hz
      exact (h_firstDeriv lam delta z hz.1 (lt_trans hz.2 hz_lt_one)).deriv
    have hd2 : DifferentiableAt ℝ
        (fun z => lam * (-delta * (1/2) * (1 - z) ^ (-(1:ℝ)/2) - (1/2) * z ^ (-(1:ℝ)/2))) y := by
      have hy_ne : y ≠ 0 := ne_of_gt hy0
      have h1my_ne : (1 - y) ≠ 0 := by linarith
      apply DifferentiableAt.const_mul
      apply DifferentiableAt.sub
      · apply DifferentiableAt.const_mul
        exact (((differentiable_const (1:ℝ)).differentiableAt.sub differentiableAt_id).rpow_const
          (Or.inl h1my_ne))
      · exact (DifferentiableAt.rpow_const differentiableAt_id (Or.inl hy_ne)).const_mul _
    exact (hd2.congr_of_eventuallyEq hloc).differentiableWithinAt
  · rw [interior_Icc]; intro y hy
    have hy0 : 0 < y := hy.1
    have hy1 : y < 1 := lt_trans hy.2 hz_lt_one
    have hnhds : Set.Ioo (0:ℝ) (zCG delta) ∈ nhds y := isOpen_Ioo.mem_nhds hy
    have hloc : deriv (fun y => h_q 2 lam delta y) =ᶠ[nhds y]
        fun z => lam * (-delta * (1/2) * (1 - z) ^ (-(1:ℝ)/2) - (1/2) * z ^ (-(1:ℝ)/2)) := by
      filter_upwards [hnhds] with z hz
      exact (h_firstDeriv lam delta z hz.1 (lt_trans hz.2 hz_lt_one)).deriv
    have hd2 := h_secondDeriv_aux lam delta y hy0 hy1
    simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
    rw [hloc.deriv_eq, hd2.2.deriv]
    have hpsi_z : (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) = 0 := by
      have h := zCG_inflection delta hdelta; linarith
    have hpsi_anti := u1psi_strictAnti delta hdelta
    have hpsi_nonneg : 0 ≤ y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) := by
      rcases eq_or_lt_of_le (le_of_lt hy.2) with heq | hlt
      · have : y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) =
            (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) := by rw [heq]
        rw [this, hpsi_z]
      · have := hpsi_anti ⟨hy0, hy1⟩ ⟨hz_pos, hz_lt_one⟩ hlt
        simp only at this; linarith [hpsi_z]
    have : 0 ≤ lam * (1/4) * (y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2)) := by
      apply mul_nonneg (by positivity) hpsi_nonneg
    simpa using this

/-- `h_q 2 λ δ` is concave on `[zCG δ, 1]` (`δ > 0`, `0 ≤ lam`). -/
theorem h_concaveOn_right_gen (lam delta : ℝ) (hlam : 0 ≤ lam) (hdelta : 0 < delta) :
    ConcaveOn ℝ (Set.Icc (zCG delta) 1) (fun y => h_q 2 lam delta y) := by
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have hz_lt_one : zCG delta < 1 := zCG_lt_one delta hdelta
  have hcont : ContinuousOn (fun y => h_q 2 lam delta y) (Set.Icc (zCG delta) 1) := by
    intro x hx
    have hx_ge : zCG delta ≤ x := hx.1
    have hx_le : x ≤ 1 := hx.2
    have hx_pos : 0 < x := lt_of_lt_of_le hz_pos hx_ge
    have h_inner : ContinuousAt (fun y : ℝ => 1 - y) x := (continuous_const.sub continuous_id).continuousAt
    have h_outer : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) (1 - x) := by
      rcases eq_or_lt_of_le hx_le with hxone | hxlt
      · rw [hxone]; simpa using Real.continuousAt_rpow_const (0:ℝ) ((1:ℝ)/2) (Or.inr (by norm_num))
      · exact Real.continuousAt_rpow_const (1 - x) ((1:ℝ)/2) (Or.inl (by linarith))
    have h1 : ContinuousAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/2)) x := h_outer.comp h_inner
    have h2 : ContinuousAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2)) x := h1.const_mul delta
    have h3 : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) x :=
      Real.continuousAt_rpow_const x ((1:ℝ)/2) (Or.inr (by norm_num))
    have h4 : ContinuousAt (fun y => h_q 2 lam delta y) x := by
      have : (fun y => h_q 2 lam delta y) = (fun y : ℝ => lam * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2))) := by
        funext y; rfl
      rw [this]; exact (h2.sub h3).const_mul lam
    exact h4.continuousWithinAt
  apply concaveOn_of_deriv2_nonpos (convex_Icc (zCG delta) 1) hcont
  · rw [interior_Icc]; intro y hy
    exact (h_firstDeriv lam delta y (lt_trans hz_pos hy.1) hy.2).differentiableAt.differentiableWithinAt
  · rw [interior_Icc]; intro y hy
    have hy0 : 0 < y := lt_trans hz_pos hy.1
    have hnhds : Set.Ioo (zCG delta) 1 ∈ nhds y := isOpen_Ioo.mem_nhds hy
    have hloc : deriv (fun y => h_q 2 lam delta y) =ᶠ[nhds y]
        fun z => lam * (-delta * (1/2) * (1 - z) ^ (-(1:ℝ)/2) - (1/2) * z ^ (-(1:ℝ)/2)) := by
      filter_upwards [hnhds] with z hz
      exact (h_firstDeriv lam delta z (lt_trans hz_pos hz.1) hz.2).deriv
    have hd2 := h_secondDeriv_aux lam delta y hy0 hy.2
    exact ((hd2.2.differentiableAt).congr_of_eventuallyEq hloc).differentiableWithinAt
  · rw [interior_Icc]; intro y hy
    have hy0 : 0 < y := lt_trans hz_pos hy.1
    have hy1 : y < 1 := hy.2
    have hnhds : Set.Ioo (zCG delta) 1 ∈ nhds y := isOpen_Ioo.mem_nhds hy
    have hloc : deriv (fun y => h_q 2 lam delta y) =ᶠ[nhds y]
        fun z => lam * (-delta * (1/2) * (1 - z) ^ (-(1:ℝ)/2) - (1/2) * z ^ (-(1:ℝ)/2)) := by
      filter_upwards [hnhds] with z hz
      exact (h_firstDeriv lam delta z (lt_trans hz_pos hz.1) hz.2).deriv
    have hd2 := h_secondDeriv_aux lam delta y hy0 hy1
    simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
    rw [hloc.deriv_eq, hd2.2.deriv]
    have hpsi_z : (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) = 0 := by
      have h := zCG_inflection delta hdelta; linarith
    have hpsi_anti := u1psi_strictAnti delta hdelta
    have hpsi_nonpos : y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) ≤ 0 := by
      have := hpsi_anti ⟨hz_pos, hz_lt_one⟩ ⟨hy0, hy1⟩ hy.1
      simp only at this; linarith [hpsi_z]
    have : lam * (1/4) * (y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2)) ≤ 0 :=
      mul_nonpos_of_nonneg_of_nonpos (by positivity) hpsi_nonpos
    simpa using this

/-- **Tangent-below bound for a convex-then-concave function.**  If `f` is convex on
`[0,z]` and concave on `[z,1]`, `a ∈ (0,z]`, and `f` has derivative `D` at `a`, then for
all `y ∈ [0,1]`, `f y ≥ f a + D·(y − a)` — the global tangent at `a` lies below `f`.
(Convexity gives it on `[0,z]`; on `[z,1]` the tangent line is `≤` the chord from
`(z,f z)` to `(1,f 1)` since it is `≤ f` at both endpoints, and the chord is `≤ f` by
concavity.) -/
theorem tangent_below_convex_concave (f : ℝ → ℝ) (z D a : ℝ)
    (hz0 : 0 < z) (hz1 : z < 1) (ha0 : 0 < a) (ha_le_z : a ≤ z)
    (hconv : ConvexOn ℝ (Set.Icc (0:ℝ) z) f) (hconc : ConcaveOn ℝ (Set.Icc z 1) f)
    (hderiv : HasDerivAt f D a)
    (htan_one : f a + D * (1 - a) ≤ f 1) :
    ∀ y : ℝ, 0 ≤ y → y ≤ 1 → f a + D * (y - a) ≤ f y := by
  have ha_mem : a ∈ Set.Icc (0:ℝ) z := ⟨le_of_lt ha0, ha_le_z⟩
  -- tangent below convex on [0,z]
  have hleft : ∀ y ∈ Set.Icc (0:ℝ) z, f a + D * (y - a) ≤ f y := by
    intro y hy
    rcases lt_trichotomy y a with hlt | heq | hgt
    · have hsl := hconv.slope_le_of_hasDerivAt hy ha_mem hlt hderiv
      rw [slope_def_field] at hsl
      have hpos : 0 < a - y := by linarith
      have hmul := mul_le_mul_of_nonneg_right hsl (le_of_lt hpos)
      rw [div_mul_cancel₀ _ (ne_of_gt hpos)] at hmul
      -- hmul : f a - f y ≤ D * (a - y)
      nlinarith [hmul]
    · rw [heq]; simp
    · have hsl := hconv.le_slope_of_hasDerivAt ha_mem hy hgt hderiv
      rw [slope_def_field] at hsl
      have hpos : 0 < y - a := by linarith
      have : D * (y - a) ≤ f y - f a := by
        have := mul_le_mul_of_nonneg_right hsl (le_of_lt hpos)
        rw [div_mul_cancel₀ _ (ne_of_gt hpos)] at this
        linarith
      linarith
  -- value at z
  have hz_mem : z ∈ Set.Icc (0:ℝ) z := ⟨le_of_lt hz0, le_refl _⟩
  have htan_z : f a + D * (z - a) ≤ f z := hleft z hz_mem
  -- right side via chord
  have hright : ∀ y ∈ Set.Icc z 1, f a + D * (y - a) ≤ f y := by
    intro y hy
    have hz_in : z ∈ Set.Icc z 1 := ⟨le_refl _, le_of_lt hz1⟩
    have hone_in : (1:ℝ) ∈ Set.Icc z 1 := ⟨le_of_lt hz1, le_refl _⟩
    -- tangent value at 1 ≤ f 1: need it. Use convex extension? Instead bound directly.
    -- Parametrize y = (1-t)·z + t·1 with t = (y - z)/(1 - z).
    rcases eq_or_lt_of_le hy.1 with hyz | hyz
    · rw [← hyz]; exact htan_z
    · set t : ℝ := (y - z) / (1 - z) with ht_def
      have h1mz_pos : 0 < 1 - z := by linarith
      have ht0 : 0 < t := by rw [ht_def]; exact div_pos (by linarith) h1mz_pos
      have ht1 : t ≤ 1 := by rw [ht_def, div_le_one h1mz_pos]; linarith [hy.2]
      have hcombo : y = (1 - t) * z + t * 1 := by
        rw [ht_def]; field_simp; ring
      -- concavity: f y ≥ (1-t) f z + t f 1
      have hy_seg : y ∈ segment ℝ z 1 := by
        rw [segment_eq_Icc (le_of_lt hz1)]; exact hy
      -- Use the explicit combination form.
      have hconc_app := hconc.2 hz_in hone_in (by linarith : (0:ℝ) ≤ 1 - t)
        (le_of_lt ht0) (by ring)
      simp only [smul_eq_mul] at hconc_app
      have hzpt : (1 - t) * z + t * 1 = y := hcombo.symm
      rw [hzpt] at hconc_app
      -- tangent at 1: f a + D(1-a) ≤ f 1 ?  Get from convex tangent extended is NOT available.
      -- Instead bound the tangent line by the chord of the TANGENT itself (it's linear):
      -- f a + D(y-a) = (1-t)(f a + D(z-a)) + t(f a + D(1-a)).
      have htan_lin : f a + D * (y - a) =
          (1 - t) * (f a + D * (z - a)) + t * (f a + D * (1 - a)) := by
        rw [hcombo]; ring
      -- f y ≥ (1-t) f z + t f 1 ≥ (1-t)(tangent z) + t(tangent 1) = tangent y.
      have h1mt_nn : (0:ℝ) ≤ 1 - t := by linarith
      have hbound1 : (1 - t) * (f a + D * (z - a)) ≤ (1 - t) * f z :=
        mul_le_mul_of_nonneg_left htan_z h1mt_nn
      have hbound2 : t * (f a + D * (1 - a)) ≤ t * f 1 :=
        mul_le_mul_of_nonneg_left htan_one (le_of_lt ht0)
      rw [htan_lin]
      calc (1 - t) * (f a + D * (z - a)) + t * (f a + D * (1 - a))
          ≤ (1 - t) * f z + t * f 1 := by linarith [hbound1, hbound2]
        _ ≤ f y := by linarith [hconc_app]
  intro y hy0 hy1
  rcases le_or_gt y z with hyz | hyz
  · exact hleft y ⟨hy0, hyz⟩
  · exact hright y ⟨le_of_lt hyz, hy1⟩

/-- **High-branch pointwise bound** (`1/2 ≤ c < 1`).  There is a slope `D` such that the
affine line `ℓ(y) = D·(y − (1−c)/2)` through `((1−c)/2, 0)` lies below `h` on `[0,1]`.
(`h((1−c)/2) = 0`; the tangent at the constraint boundary `(1−c)/2 ≤ z` under-estimates
`h` everywhere, by convexity on `[0,z]` and the concavity chord on `[z,1]`.) -/
theorem high_branch_pointwise (c : ℝ) (hc_lo : 1 / 2 ≤ c) (hc1 : c < 1) :
    ∃ D : ℝ, ∀ y : ℝ, 0 ≤ y → y ≤ 1 →
      D * (y - (1 - c) / 2) ≤ h_q 2 (lambda1 c) (delta1 c) y := by
  have hc0 : 0 ≤ c := by linarith
  have hd1pos : 0 < delta1 c := delta1_pos c hc0 hc1
  obtain ⟨hl0, hl1, _⟩ := CGLambda1InUnitInterval c hc0 hc1
  -- high-branch closed forms
  obtain ⟨hd1sq, _, hlam_val, _⟩ := CGDeltaLambdaHighBranch c hc_lo hc1
  -- δ₁ = √((1-c)/(1+c)), λ₁ = √((c+1)/2).
  have h1mc : (0:ℝ) < 1 - c := by linarith
  have h1pc : (0:ℝ) < 1 + c := by linarith
  set a1v : ℝ := (1 - c) / 2 with ha1v_def
  have ha1v_pos : 0 < a1v := by rw [ha1v_def]; linarith
  have ha1v_lt_one : a1v < 1 := by rw [ha1v_def]; linarith
  have h1ma1v : 1 - a1v = (1 + c) / 2 := by rw [ha1v_def]; ring
  have h1ma1v_pos : 0 < 1 - a1v := by rw [h1ma1v]; linarith
  -- δ₁ explicit value: δ₁² = (1-c)/(1+c), δ₁ = √((1-c)/(1+c)).
  have hδ1_sq : delta1 c ^ 2 = (1 - c) / (1 + c) := by
    -- delta1 c = (lambda1 c^{-2} - 1)^{1/2}; lambda1 c = √((c+1)/2).
    have hbase : lambda1 c ^ (-((2:ℝ)/(2-1))) - 1 = (1 - c) / (1 + c) := by
      rw [hlam_val, show (-((2:ℝ)/(2-1))) = -(2:ℝ) by norm_num,
        show (-(2:ℝ)) = -((2:ℕ):ℝ) by norm_num, Real.rpow_neg (Real.sqrt_nonneg _),
        Real.rpow_natCast, Real.sq_sqrt (by positivity)]
      rw [inv_div]; field_simp; ring
    have hbn : (0:ℝ) ≤ lambda1 c ^ (-((2:ℝ)/(2-1))) - 1 := by rw [hbase]; positivity
    have hstep : delta1 c ^ 2 = lambda1 c ^ (-((2:ℝ)/(2-1))) - 1 := by
      unfold delta1 delta_of_lambda
      rw [← Real.rpow_natCast _ 2, ← Real.rpow_mul hbn]; norm_num
    rw [hstep, hbase]
  have hδ1_val : delta1 c = Real.sqrt ((1 - c) / (1 + c)) := by
    have : delta1 c = Real.sqrt (delta1 c ^ 2) := by rw [Real.sqrt_sq (le_of_lt hd1pos)]
    rw [this, hδ1_sq]
  -- √a1v = √((1-c)/2), √(1-a1v) = √((1+c)/2).
  have hsqrt_a1v : a1v ^ ((1:ℝ)/2) = Real.sqrt a1v := (Real.sqrt_eq_rpow a1v).symm
  have hsqrt_1ma1v : (1 - a1v) ^ ((1:ℝ)/2) = Real.sqrt (1 - a1v) := (Real.sqrt_eq_rpow _).symm
  -- KEY: δ₁·√(1-a1v) = √a1v, the calibration making h(a1v)=0.
  have hcalib : delta1 c * (1 - a1v) ^ ((1:ℝ)/2) = a1v ^ ((1:ℝ)/2) := by
    rw [hδ1_val, hsqrt_1ma1v, hsqrt_a1v, h1ma1v, ha1v_def,
      ← Real.sqrt_mul (by positivity)]
    congr 1
    field_simp
  -- h(a1v) = 0.
  have hh_a1v : h_q 2 (lambda1 c) (delta1 c) a1v = 0 := by
    unfold h_q
    rw [show (1:ℝ)/(2:ℝ) = (1:ℝ)/2 from rfl, hcalib]; ring
  -- a1v ≤ zCG δ₁.  (Use ψ(a1v) ≥ 0 ⟹ a1v ≤ z, since ψ antitone and ψ(z)=0.)
  have ha1v_le_z : a1v ≤ zCG (delta1 c) := by
    -- z = D₀/(D₀+1) with D₀ = δ₁^{-2/3}.  a1v ≤ z ⟺ a1v/(1-a1v) ≤ D₀, and
    -- a1v/(1-a1v) = (1-c)/(1+c) = δ₁², while D₀ = δ₁^{-2/3} ≥ δ₁² since δ₁ ≤ 1.
    set D0 : ℝ := delta1 c ^ (-(2:ℝ)/3) with hD0_def
    have hD0_pos : 0 < D0 := Real.rpow_pos_of_pos hd1pos _
    have hz_eq : zCG (delta1 c) = D0 / (D0 + 1) := rfl
    have hδ1_le_one : delta1 c ≤ 1 := by
      rw [hδ1_val, show (1:ℝ) = Real.sqrt 1 by rw [Real.sqrt_one]]
      apply Real.sqrt_le_sqrt
      have : (1 - c) / (1 + c) ≤ 1 := by rw [div_le_one h1pc]; linarith
      linarith
    -- δ₁² ≤ D0 = δ₁^{-2/3}: δ₁^{2} ≤ δ₁^{-2/3} ⟺ δ₁^{8/3} ≤ 1 (δ₁ ≤ 1, exp > 0).
    have hδ1sq_le_D0 : delta1 c ^ 2 ≤ D0 := by
      rw [hD0_def, ← Real.rpow_natCast (delta1 c) 2, show ((2:ℕ):ℝ) = (2:ℝ) by norm_num]
      rcases eq_or_lt_of_le hδ1_le_one with heq | hlt
      · rw [heq]; norm_num
      · apply Real.rpow_le_rpow_of_exponent_ge hd1pos (le_of_lt hlt); norm_num
    -- δ₁² = (1-c)/(1+c), so (1-c)/(1+c) ≤ D0.
    have hratio_le : (1 - c) / (1 + c) ≤ D0 := by rw [← hδ1_sq]; exact hδ1sq_le_D0
    rw [hz_eq, ha1v_def, le_div_iff₀ (by linarith)]
    -- goal: (1-c)/2 * (D0+1) ≤ D0.  From (1-c) ≤ D0(1+c).
    have hkey : (1 - c) ≤ D0 * (1 + c) := by
      rw [div_le_iff₀ h1pc] at hratio_le; linarith
    nlinarith [hkey, hD0_pos, h1pc, h1mc]
  -- the derivative D = h'(a1v) and the tangent bound.
  refine ⟨lambda1 c * (-delta1 c * (1/2) * (1 - a1v) ^ (-(1:ℝ)/2) - (1/2) * a1v ^ (-(1:ℝ)/2)), ?_⟩
  set D : ℝ := lambda1 c * (-delta1 c * (1/2) * (1 - a1v) ^ (-(1:ℝ)/2) - (1/2) * a1v ^ (-(1:ℝ)/2)) with hD_def
  have hderiv : HasDerivAt (fun y => h_q 2 (lambda1 c) (delta1 c) y) D a1v :=
    h_firstDeriv (lambda1 c) (delta1 c) a1v ha1v_pos ha1v_lt_one
  have hconv := h_convexOn_left_gen (lambda1 c) (delta1 c) (le_of_lt hl0) hd1pos
  have hconc := h_concaveOn_right_gen (lambda1 c) (delta1 c) (le_of_lt hl0) hd1pos
  have hz_pos : 0 < zCG (delta1 c) := zCG_pos _ hd1pos
  have hz_lt_one : zCG (delta1 c) < 1 := zCG_lt_one _ hd1pos
  -- htan_one : h(a1v) + D·(1-a1v) ≤ h(1).
  have hh_one : h_q 2 (lambda1 c) (delta1 c) 1 = -lambda1 c := by
    unfold h_q; rw [show (1:ℝ) - 1 = 0 by ring, Real.zero_rpow (by norm_num), Real.one_rpow]; ring
  have htan_one : h_q 2 (lambda1 c) (delta1 c) a1v + D * (1 - a1v) ≤ h_q 2 (lambda1 c) (delta1 c) 1 := by
    rw [hh_a1v, hh_one, zero_add]
    -- D·(1-a1v) = -λ₁/(2√a1v) ≤ -λ₁ (since √a1v ≤ 1/2 ⟺ a1v ≤ 1/4 ⟺ c ≥ 1/2).
    set sa : ℝ := Real.sqrt a1v with hsa_def
    have hsa_pos : 0 < sa := Real.sqrt_pos.mpr ha1v_pos
    have hsa_sq : sa ^ 2 = a1v := Real.sq_sqrt (le_of_lt ha1v_pos)
    have e_a_neg : a1v ^ (-(1:ℝ)/2) = sa⁻¹ := by
      rw [hsa_def, show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt ha1v_pos),
        ← Real.sqrt_eq_rpow]
    have e_1ma_neg : (1 - a1v) ^ (-(1:ℝ)/2) = (Real.sqrt (1 - a1v))⁻¹ := by
      rw [show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt h1ma1v_pos),
        ← Real.sqrt_eq_rpow]
    -- δ₁·(1-a1v)^{-1/2}·(1-a1v) = δ₁·(1-a1v)^{1/2} = a1v^{1/2} = sa (hcalib).
    set sb : ℝ := Real.sqrt (1 - a1v) with hsb_def
    have hsb_pos : 0 < sb := Real.sqrt_pos.mpr h1ma1v_pos
    have hsb_sq : sb ^ 2 = 1 - a1v := Real.sq_sqrt (le_of_lt h1ma1v_pos)
    have hsb_ne : sb ≠ 0 := ne_of_gt hsb_pos
    have hδ_term : delta1 c * sb⁻¹ * (1 - a1v) = sa := by
      have h1 : sb⁻¹ * (1 - a1v) = sb := by
        rw [← hsb_sq, sq, ← mul_assoc, inv_mul_cancel₀ hsb_ne, one_mul]
      have hc2 := hcalib
      rw [hsqrt_1ma1v, hsqrt_a1v] at hc2
      rw [mul_assoc, h1]; exact hc2
    have hsainv_1ma : sa⁻¹ * (1 - a1v) = sa⁻¹ - sa := by
      rw [← hsa_sq]; field_simp
    -- D·(1-a1v) = λ₁·(-δ₁·(1/2)·sb⁻¹ - (1/2)·sa⁻¹)·(1-a1v) = -λ₁/(2 sa).
    have hDval : D * (1 - a1v) = -lambda1 c / (2 * sa) := by
      rw [hD_def, e_a_neg, e_1ma_neg]
      have hbracket : (-delta1 c * (1/2) * sb⁻¹ - 1/2 * sa⁻¹) * (1 - a1v)
          = -(1/2) * sa⁻¹ := by
        have hexpand : (-delta1 c * (1/2) * sb⁻¹ - 1/2 * sa⁻¹) * (1 - a1v)
            = -(1/2) * (delta1 c * sb⁻¹ * (1 - a1v)) - (1/2) * (sa⁻¹ * (1 - a1v)) := by ring
        rw [hexpand, hδ_term, hsainv_1ma]; ring
      have hstep : lambda1 c * (-delta1 c * (1/2) * sb⁻¹ - 1/2 * sa⁻¹) * (1 - a1v)
          = lambda1 c * ((-delta1 c * (1/2) * sb⁻¹ - 1/2 * sa⁻¹) * (1 - a1v)) := by ring
      rw [hstep, hbracket]
      have hsane : sa ≠ 0 := ne_of_gt hsa_pos
      field_simp
    rw [hDval]
    -- -λ₁/(2 sa) ≤ -λ₁ ⟺ 2 sa ≤ 1 (λ₁ > 0).
    have hsa_le : sa ≤ 1 / 2 := by
      rw [hsa_def, show (1:ℝ)/2 = Real.sqrt (1/4) by rw [show (1:ℝ)/4 = (1/2)^2 by norm_num,
        Real.sqrt_sq (by norm_num)]]
      apply Real.sqrt_le_sqrt
      rw [ha1v_def]; linarith [hc_lo]
    rw [div_le_iff₀ (by positivity)]
    nlinarith [hsa_le, hsa_pos, hl0]
  have hbound := tangent_below_convex_concave (fun y => h_q 2 (lambda1 c) (delta1 c) y)
    (zCG (delta1 c)) D a1v hz_pos hz_lt_one ha1v_pos ha1v_le_z hconv hconc hderiv htan_one
  intro y hy0 hy1
  have hb := hbound y hy0 hy1
  simp only [] at hb
  rw [hh_a1v, zero_add] at hb
  exact hb

theorem CGRelaxedCoreNonneg
    (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1)
    {n : ℕ}
    (x : Fin n → ℝ)
    (hx_nn : ∀ i, 0 ≤ x i) (hx_le_one : ∀ i, x i ≤ 1)
    (hx_sum : (∑ i, x i) = (1 - c) / 2 * (n : ℝ)) :
    0 ≤ (∑ i, h_q 2 (lambda1 c) (delta1 c) (x i)) := by
  -- ## Two-branch supporting-line certificate.
  --
  -- The per-point objective is `h(x) = h_q 2 λ₁ δ₁ x`.  In BOTH branches we exhibit
  -- an affine support line `ℓ` with `ℓ(xᵢ) ≤ h(xᵢ)` pointwise on `[0,1]` and
  -- `∑ᵢ ℓ(xᵢ) = 0` under the constraint `∑ xᵢ = (1−c)/2·n`; summing gives the result.
  --
  -- * `c < 1/2` (LOW branch): the global supporting line is the tangent at the
  --   interior critical point `a₁' = a1' c`, equivalently `ℓ(x) = λ₁/(1+c)·(1−2x−c)`,
  --   and `h ≥ ℓ ⟺ u₁ ≥ 0` on `[0,1]` (`low_branch_hu1_nonneg`).
  -- * `1/2 ≤ c` (HIGH branch): `u₁ ≥ 0` FAILS pointwise; instead the support line is
  --   the tangent to `h` at the constraint boundary `(1−c)/2 ≤ z`, `ℓ(x)=D·(x−(1−c)/2)`
  --   (`high_branch_pointwise`), with `∑ℓ(xᵢ)=D·0=0`.
  have hc_pos : (0 : ℝ) < 1 + c := by linarith
  have hlam_pos : 0 < lambda1 c := (CGLambda1InUnitInterval c hc0 hc1).1
  have hcoef_nn : 0 ≤ lambda1 c / (1 + c) := by positivity
  by_cases hcase : c < 1 / 2
  · -- LOW branch: `u₁ ≥ 0` global support.
    have hu1_nonneg : ∀ y : ℝ, 0 ≤ y → y ≤ 1 → 0 ≤ u1 c y :=
      low_branch_hu1_nonneg c hc0 hcase
    have key : ∀ y : ℝ,
        h_q 2 (lambda1 c) (delta1 c) y = lambda1 c / (1 + c) * (u1 c y + 1 - 2 * y - c) := by
      intro y; unfold h_q u1; field_simp; ring
    have h_pointwise : ∀ i,
        lambda1 c / (1 + c) * (1 - 2 * x i - c) ≤ h_q 2 (lambda1 c) (delta1 c) (x i) := by
      intro i
      rw [key (x i)]
      have hu := hu1_nonneg (x i) (hx_nn i) (hx_le_one i)
      have hmul := mul_le_mul_of_nonneg_left
        (show (1 - 2 * x i - c) ≤ (u1 c (x i) + 1 - 2 * (x i) - c) by linarith) hcoef_nn
      linarith [hmul]
    have hsum_lb :
        (∑ i, lambda1 c / (1 + c) * (1 - 2 * x i - c))
          ≤ (∑ i, h_q 2 (lambda1 c) (delta1 c) (x i)) :=
      Finset.sum_le_sum (fun i _ => h_pointwise i)
    have hsum_eq : (∑ i, lambda1 c / (1 + c) * (1 - 2 * x i - c)) = 0 := by
      rw [← Finset.mul_sum]
      have hinner : (∑ i, (1 - 2 * x i - c)) = (n : ℝ) - 2 * (∑ i, x i) - c * n := by
        rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib, Finset.sum_const,
          Finset.card_univ, Fintype.card_fin, ← Finset.mul_sum]
        simp [mul_comm]
      rw [hinner, hx_sum]; ring
    rw [hsum_eq] at hsum_lb
    exact hsum_lb
  · -- HIGH branch: boundary-tangent support `ℓ(x) = D·(x − (1−c)/2)`.
    push_neg at hcase
    obtain ⟨D, hD_bound⟩ := high_branch_pointwise c hcase hc1
    have h_pointwise : ∀ i,
        D * (x i - (1 - c) / 2) ≤ h_q 2 (lambda1 c) (delta1 c) (x i) :=
      fun i => hD_bound (x i) (hx_nn i) (hx_le_one i)
    have hsum_lb :
        (∑ i, D * (x i - (1 - c) / 2)) ≤ (∑ i, h_q 2 (lambda1 c) (delta1 c) (x i)) :=
      Finset.sum_le_sum (fun i _ => h_pointwise i)
    have hsum_eq : (∑ i, D * (x i - (1 - c) / 2)) = 0 := by
      rw [← Finset.mul_sum]
      have hinner : (∑ i, (x i - (1 - c) / 2)) = (∑ i, x i) - (1 - c) / 2 * n := by
        rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin]
        ring
      rw [hinner, hx_sum]; ring
    rw [hsum_eq] at hsum_lb
    exact hsum_lb

end Workspace.ProofLemmas.CGRelaxedCoreNonneg

open Workspace.ProofLemmas.RGDefs

namespace Workspace.ProofLemmas.RGABranchComparison

/-- **RGABranchComparison** (proof_detailed.md Step 13; appendix.tex 294, `a₂'` vs
`(1+c)/2`; the `c → −c` image of `CGABranchComparison`).

SINGLE BRANCH: for EVERY `c ∈ [0,1)`, with
`a₂' = (2 − c − √(3−2c))/2 = a2' c`:
`a₂' ≤ (1+c)/2`.

(Proof: `a₂' − (1+c)/2 = (1 − 2c − √(3−2c))/2`, so the inequality is
`√(3−2c) ≥ 1 − 2c`. If `1 − 2c ≤ 0` this is immediate; else squaring both
nonneg sides gives `0 ≥ 2(2c+1)(c−1) ⟺ (2c+1)(c−1) ≤ 0`, which holds on
`[0,1)` since `2c+1 > 0` and `c−1 < 0`. Unlike consistency's two-branch factor
`(2c−1)(c+1)`, here `(2c+1)(c−1) ≤ 0` on the WHOLE interval — no phase
transition.) -/
theorem RGABranchComparison_le (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) :
    a2' c ≤ (1 + c) / 2 := by
  unfold a2'
  rw [div_le_div_iff_of_pos_right (show (0:ℝ) < 2 by norm_num)]
  -- Goal: 2 - c - √(3 - 2*c) ≤ 1 + c
  -- ⟺ 1 - 2*c ≤ √(3 - 2*c)
  have hsqnn : (0:ℝ) ≤ Real.sqrt (3 - 2 * c) := Real.sqrt_nonneg _
  have h32 : (0:ℝ) ≤ 3 - 2 * c := by linarith
  by_cases hcase : c < 1 / 2
  · -- c < 1/2, so 1 - 2c > 0; need to square
    have h12c_nn : (0:ℝ) ≤ 1 - 2 * c := by linarith
    -- (1-2c)^2 = 4c^2 - 4c + 1 ≤ 3 - 2c iff 4c^2 - 2c - 2 ≤ 0 iff 2(2c+1)(c-1) ≤ 0
    nlinarith [Real.sq_sqrt h32, Real.sqrt_nonneg (3 - 2 * c),
               Real.sqrt_le_sqrt (show (1 - 2*c)^2 ≤ 3 - 2*c by nlinarith),
               Real.sqrt_sq h12c_nn]
  · -- c ≥ 1/2, so 1 - 2c ≤ 0 ≤ √(3 - 2c)
    have hc12 : 1 / 2 ≤ c := not_lt.mp hcase
    nlinarith [Real.sqrt_nonneg (3 - 2 * c)]

/-- Consequently the optimal `a₂` is the interior root for ALL `c ∈ [0,1)`:
`a₂ = a₂'`. The constraint boundary `(1+c)/2` never binds (single branch — this
is the definitional content of `a2`, justified by `RGABranchComparison_le`). -/
theorem RGABranchComparison_value (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) :
    a2 c = a2' c := by
  unfold a2
  rfl

end Workspace.ProofLemmas.RGABranchComparison

open Workspace.ProofLemmas.RGDefs

namespace Workspace.ProofLemmas.RGInteriorRoot

/-- **RGInteriorRoot** (appendix.tex 292–294; `c → −c` mirror of `CGInteriorRoot`).
For `c ∈ [0,1)` the quadratic factor `2t² + 2t − (1−c) = 0` has a unique nonnegative
root `t₂ = (−1 + √(3−2c))/2` (the other root `(−1 − √(3−2c))/2 < 0` is rejected since
`t₂ = √(a₂') ≥ 0`). Consequently the interior critical point of `u₂` is
`a₂' = t₂² = (2 − c − √(3−2c))/2 = a2' c`.

The statement bundles: (a) `t₂` is a root of the quadratic, (b) `t₂ ≥ 0`,
(c) the negative root is `< 0`, (d) `a₂' = t₂²` matches `a2' c`. -/
theorem RGInteriorRoot (c : ℝ) (hc : 0 ≤ c) (hc1 : c ≤ 1) :
    let t2 : ℝ := (-1 + Real.sqrt (3 - 2 * c)) / 2
    (2 * t2 ^ 2 + 2 * t2 - (1 - c) = 0) ∧
    (0 ≤ t2) ∧
    ((-1 - Real.sqrt (3 - 2 * c)) / 2 < 0) ∧
    (a2' c = t2 ^ 2) := by
  intro t2
  have h3 : (0:ℝ) ≤ 3 - 2 * c := by linarith
  set s := Real.sqrt (3 - 2 * c) with hs_def
  have hs_nonneg : 0 ≤ s := Real.sqrt_nonneg _
  have hs_sq : s ^ 2 = 3 - 2 * c := by rw [hs_def, sq, Real.mul_self_sqrt h3]
  have hs_ge1 : 1 ≤ s := by
    rw [hs_def, show (1:ℝ) = Real.sqrt 1 by simp]
    exact Real.sqrt_le_sqrt (by linarith)
  have ht2 : t2 = (-1 + s) / 2 := rfl
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [ht2]; nlinarith [hs_sq]
  · rw [ht2]; linarith
  · linarith
  · rw [ht2]
    show a2' c = ((-1 + s) / 2) ^ 2
    rw [a2']; nlinarith [hs_sq]

end Workspace.ProofLemmas.RGInteriorRoot

open Workspace.ProofLemmas.RGDefs
open Workspace.ProofLemmas.RGABranchComparison
open Workspace.ProofLemmas.RGInteriorRoot

namespace Workspace.ProofLemmas.RGDeltaLambda

theorem RGDeltaLambda (c : ℝ) (hc_lo : 0 ≤ c) (hc_hi : c < 1) :
    let a2v : ℝ := a2' c
    let d2sq : ℝ :=
      ((1 - 2 * a2v + c) / (1 - c) + a2v ^ ((1 : ℝ) / 2)) ^ 2 / (1 - a2v)
    (lambda2 c = (1 + d2sq) ^ (-(1 : ℝ) / 2)) ∧
    (lambda2 c =
      (1 - c) *
        (Real.sqrt
          (-4 * Real.sqrt (3 - 2 * c) * c + 6 * Real.sqrt (3 - 2 * c) + 10 * c - 8))⁻¹) ∧
    (1 / lambda2 c = Workspace.RobustnessTheorem.RG c) := by
  intro a2v d2sq
  -- Surd setup: s = √(3-2c)
  have h23 : (0:ℝ) ≤ 3 - 2 * c := by linarith
  set s := Real.sqrt (3 - 2 * c) with hs_def
  have hs_nonneg : 0 ≤ s := Real.sqrt_nonneg _
  have hs_sq : s ^ 2 = 3 - 2 * c := by rw [hs_def, sq, Real.mul_self_sqrt h23]
  have hs_ge1 : 1 ≤ s := by
    rw [hs_def, show (1:ℝ) = Real.sqrt 1 by simp]
    exact Real.sqrt_le_sqrt (by linarith)
  -- s > c  (needed for 1 - a > 0):  s² = 3-2c > c² for c ∈ [0,1)
  have hs_gt_c : c < s := by nlinarith [hs_sq, hs_nonneg, sq_nonneg (s - c)]
  -- helper: (y²)^(1/2) = y for y ≥ 0
  have hsqrt_sq : ∀ (y:ℝ), 0 ≤ y → (y ^ 2) ^ ((1:ℝ)/2) = y := by
    intro y hy; rw [← Real.rpow_natCast y 2, ← Real.rpow_mul hy]; norm_num
  -- a2' c = (2 - c - s)/2
  have ha2v : a2v = (2 - c - s) / 2 := by
    show a2' c = (2 - c - s) / 2
    rw [a2']
  -- (a2' c)^(1/2) = t2 = (-1 + s)/2
  have ht2_nonneg : (0:ℝ) ≤ (-1 + s) / 2 := by linarith
  have ha2v_eq_sq : a2v = ((-1 + s) / 2) ^ 2 := by
    rw [ha2v]; nlinarith [hs_sq]
  have hasqrt : a2v ^ ((1 : ℝ) / 2) = (-1 + s) / 2 := by
    rw [ha2v_eq_sq, hsqrt_sq _ ht2_nonneg]
  -- positivity facts
  have h1c_pos : (0:ℝ) < 1 - c := by linarith
  have h1ma_pos : (0:ℝ) < 1 - a2v := by rw [ha2v]; linarith
  set R : ℝ := -4 * s * c + 6 * s + 10 * c - 8 with hR_def
  have hR_pos : (0:ℝ) < R := by
    rw [hR_def]; nlinarith [hs_sq, hs_ge1, hs_gt_c, mul_nonneg hs_nonneg hc_lo]
  have hsqrtR_pos : (0:ℝ) < Real.sqrt R := Real.sqrt_pos.mpr hR_pos
  -- KEY identity: 1 + d2sq = R / (1-c)²
  have hkey : 1 + d2sq = R / (1 - c) ^ 2 := by
    show 1 + ((1 - 2 * a2v + c) / (1 - c) + a2v ^ ((1:ℝ)/2)) ^ 2 / (1 - a2v)
        = R / (1 - c) ^ 2
    rw [hasqrt, ha2v, hR_def]
    rw [show (1:ℝ) - (2 - c - s) / 2 = (s + c) / 2 by ring]
    have hsc : s + c ≠ 0 := by nlinarith [hs_gt_c, hc_lo]
    field_simp
    nlinarith [hs_sq]
  -- conjunct 2 (and lambda2 closed form): lambda2 c = (1-c) * (√R)⁻¹
  have hlam : lambda2 c = (1 - c) * (Real.sqrt R)⁻¹ := by
    rw [lambda2, hR_def]
  -- rpow building blocks
  have hden : ((1 - c) ^ 2 : ℝ) ^ (-(1:ℝ) / 2) = (1 - c)⁻¹ := by
    rw [show (1 - c) ^ 2 = (1 - c) ^ (2:ℕ) by norm_num,
        ← Real.rpow_natCast (1 - c) 2, ← Real.rpow_mul (le_of_lt h1c_pos),
        show ((2:ℕ):ℝ) * (-(1:ℝ) / 2) = -1 by norm_num, Real.rpow_neg_one]
  have hnum : (R : ℝ) ^ (-(1:ℝ) / 2) = (Real.sqrt R)⁻¹ := by
    rw [Real.sqrt_eq_rpow, show (-(1:ℝ) / 2) = -(1 / 2) by ring,
        Real.rpow_neg (le_of_lt hR_pos)]
  -- (1 + d2sq)^(-1/2) = (1-c) * (√R)⁻¹
  have hpow : (1 + d2sq) ^ (-(1:ℝ) / 2) = (1 - c) * (Real.sqrt R)⁻¹ := by
    rw [hkey, Real.div_rpow (le_of_lt hR_pos) (by positivity), hden, hnum]
    rw [div_eq_mul_inv, inv_inv, mul_comm]
  refine ⟨?_, hlam, ?_⟩
  · rw [hlam, hpow]
  · -- 1 / lambda2 c = RG c
    rw [hlam, Workspace.RobustnessTheorem.RG, hR_def]
    rw [one_div, mul_inv, inv_inv, div_eq_mul_inv]
    ring

end Workspace.ProofLemmas.RGDeltaLambda

open Workspace.ProofLemmas.RGDefs
open Workspace.ProofLemmas.HSecondDerivative
open Workspace.ProofLemmas.LambdaDeltaIdentity
open Workspace.ProofLemmas.CGDefs
open Workspace.ProofLemmas.CGOptimalSolutionForA1
open Workspace.ProofLemmas.CGRelaxedCoreNonneg
open Workspace.ProofLemmas.RGABranchComparison
open Workspace.ProofLemmas.RGInteriorRoot
open Workspace.ProofLemmas.RGDeltaLambda
open Workspace.ProofLemmas.RGLambda2InUnitInterval

namespace Workspace.ProofLemmas.RGRelaxedCoreNonneg

set_option maxHeartbeats 4000000

/-- HasDerivAt for `u2delta c delta` at a point `a` with `0 < a < 1`. -/
private theorem u2delta_hasDerivAt (c delta a : ℝ) (ha0 : 0 < a) (ha1 : a < 1) :
    HasDerivAt (fun x => u2delta c delta x) (u2deriv c delta a) a := by
  have ha_ne : a ≠ 0 := ne_of_gt ha0
  have h1ma_pos : 0 < 1 - a := by linarith
  have h1ma_ne : (1 - a) ≠ 0 := ne_of_gt h1ma_pos
  have hd_a_pow : HasDerivAt (fun x : ℝ => x ^ ((1:ℝ)/2)) ((1/2) * a ^ ((1:ℝ)/2 - 1)) a := by
    have h := (hasDerivAt_id a).rpow_const (p := (1:ℝ)/2) (Or.inl ha_ne)
    simpa using h
  have hd_inner : HasDerivAt (fun x : ℝ => 1 - x) (-1 : ℝ) a := by
    simpa using (hasDerivAt_id a).const_sub 1
  have hd_1ma_pow : HasDerivAt (fun x : ℝ => (1 - x) ^ ((1:ℝ)/2))
      (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) a := by
    have h := hd_inner.rpow_const (p := (1:ℝ)/2) (Or.inl h1ma_ne)
    convert h using 1
    ring
  have hd_d_1ma : HasDerivAt (fun x : ℝ => delta * (1 - x) ^ ((1:ℝ)/2))
      (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1)))) a :=
    hd_1ma_pow.const_mul delta
  have hd_diff : HasDerivAt (fun x : ℝ => delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2))
      (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1)) a :=
    hd_d_1ma.sub hd_a_pow
  have hd_mul : HasDerivAt (fun x : ℝ => (1 - c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)))
      ((1 - c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1))) a :=
    hd_diff.const_mul (1 - c)
  have hd_sub1 : HasDerivAt (fun x : ℝ => (1 - c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)) - 1)
      ((1 - c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1))) a :=
    hd_mul.sub_const 1
  have hd_lin : HasDerivAt (fun x : ℝ => 2 * x) (2 : ℝ) a := by
    simpa using (hasDerivAt_id a).const_mul 2
  have hd_total0 : HasDerivAt
      (fun x : ℝ => (1 - c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)) - 1 + 2 * x)
      ((1 - c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1)) + 2) a :=
    hd_sub1.add hd_lin
  have hd_total : HasDerivAt
      (fun x : ℝ => (1 - c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)) - 1 + 2 * x - c)
      ((1 - c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1)) + 2) a :=
    hd_total0.sub_const c
  have hfun : (fun x => u2delta c delta x) =
      (fun x : ℝ => (1 - c) * (delta * (1 - x) ^ ((1:ℝ)/2) - x ^ ((1:ℝ)/2)) - 1 + 2 * x - c) := by
    funext x; rw [u2delta]
  rw [hfun]
  have hval : (1 - c) * (delta * (-1 * ((1/2) * (1 - a) ^ ((1:ℝ)/2 - 1))) - (1/2) * a ^ ((1:ℝ)/2 - 1)) + 2
      = u2deriv c delta a := by
    rw [u2deriv]
    have e1 : ((1:ℝ)/2 - 1) = -(1:ℝ)/2 := by norm_num
    rw [e1]
    ring
  rw [hval] at hd_total
  exact hd_total

/-- `u2delta c delta` is continuous on `Set.Icc 0 M` whenever `M < 1`. -/
private theorem u2delta_continuousOn (c delta M : ℝ) (hM : M < 1) :
    ContinuousOn (fun x => u2delta c delta x) (Set.Icc (0:ℝ) M) := by
  intro x hx
  have hx_le : x ≤ M := hx.2
  have hx_lt_one : x < 1 := lt_of_le_of_lt hx_le hM
  have h1mx_pos : 0 < 1 - x := by linarith
  have hx_nn : 0 ≤ x := hx.1
  have h_inner : ContinuousAt (fun y : ℝ => 1 - y) x :=
    (continuous_const.sub continuous_id).continuousAt
  have h_outer : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) (1 - x) :=
    Real.continuousAt_rpow_const (1 - x) ((1:ℝ)/2) (Or.inl (ne_of_gt h1mx_pos))
  have h_1mx_pow : ContinuousAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/2)) x :=
    h_outer.comp h_inner
  have h_d_1mx_pow : ContinuousAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2)) x :=
    h_1mx_pow.const_mul delta
  have h_x_pow : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) x :=
    Real.continuousAt_rpow_const x ((1:ℝ)/2) (Or.inr (by norm_num))
  have h_diff : ContinuousAt
      (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2)) x :=
    h_d_1mx_pow.sub h_x_pow
  have h_mul : ContinuousAt
      (fun y : ℝ => (1 - c) * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2))) x :=
    h_diff.const_mul (1 - c)
  have h_total : ContinuousAt (fun x => u2delta c delta x) x := by
    have : (fun x => u2delta c delta x) =
        (fun y : ℝ => (1 - c) * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2)) - 1 + 2 * y - c) := by
      funext y; rw [u2delta]
    rw [this]
    exact (((h_mul.sub continuousAt_const).add
      ((continuous_const.mul continuous_id).continuousAt)).sub continuousAt_const)
  exact h_total.continuousWithinAt

/-- Second derivative of `u2delta c delta` at an interior point `0 < a < 1`:
`u₂''(a) = ((1-c)/4)·(a^{-3/2} − δ·(1−a)^{-3/2})`. -/
private theorem u2delta_secondDeriv (c delta a : ℝ) (ha0 : 0 < a) (ha1 : a < 1) :
    HasDerivAt (fun y => u2deriv c delta y)
      ((1 - c) / 4 * (a ^ (-(3:ℝ)/2) - delta * (1 - a) ^ (-(3:ℝ)/2))) a := by
  have ha_ne : a ≠ 0 := ne_of_gt ha0
  have h1ma_pos : 0 < 1 - a := by linarith
  have h1ma_ne : (1 - a) ≠ 0 := ne_of_gt h1ma_pos
  set p1 : ℝ := -(1:ℝ)/2 with hp1_def
  set p2 : ℝ := -(3:ℝ)/2 with hp2_def
  have hexp : p1 - 1 = p2 := by rw [hp1_def, hp2_def]; norm_num
  have hd_a : HasDerivAt (fun y : ℝ => y ^ p1) (p1 * a ^ p2) a := by
    have h := (hasDerivAt_id a).rpow_const (p := p1) (Or.inl ha_ne)
    rw [hexp] at h; simpa using h
  have hd_inner : HasDerivAt (fun y : ℝ => 1 - y) (-1 : ℝ) a := by
    simpa using (hasDerivAt_id a).const_sub 1
  have hd_1ma : HasDerivAt (fun y : ℝ => (1 - y) ^ p1) (-1 * p1 * (1 - a) ^ p2) a := by
    have h := hd_inner.rpow_const (p := p1) (Or.inl h1ma_ne)
    rw [hexp] at h; exact h
  have hfun : (fun y => u2deriv c delta y) =
      (fun y : ℝ => (1/2) * (1 - c) * (-delta * (1 - y) ^ p1 - y ^ p1) + 2) := by
    funext y; rw [u2deriv]
  rw [hfun]
  have hd_d1ma : HasDerivAt (fun y : ℝ => -delta * (1 - y) ^ p1)
      (-delta * (-1 * p1 * (1 - a) ^ p2)) a := hd_1ma.const_mul (-delta)
  have hd_sub : HasDerivAt (fun y : ℝ => -delta * (1 - y) ^ p1 - y ^ p1)
      (-delta * (-1 * p1 * (1 - a) ^ p2) - p1 * a ^ p2) a := hd_d1ma.sub hd_a
  have hd_mul : HasDerivAt (fun y : ℝ => (1/2) * (1 - c) * (-delta * (1 - y) ^ p1 - y ^ p1))
      ((1/2) * (1 - c) * (-delta * (-1 * p1 * (1 - a) ^ p2) - p1 * a ^ p2)) a :=
    hd_sub.const_mul ((1/2) * (1 - c))
  have hd_total := hd_mul.add_const (2 : ℝ)
  convert hd_total using 1
  rw [hp1_def, hp2_def]; ring

/-- `u2delta c δ` is convex on `[0, zCG δ]` (for `δ > 0`, `c ≤ 1`). -/
private theorem u2delta_convexOn_left (c delta : ℝ) (hc1 : c ≤ 1) (hdelta : 0 < delta) :
    ConvexOn ℝ (Set.Icc (0:ℝ) (zCG delta)) (fun y => u2delta c delta y) := by
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have hz_lt_one : zCG delta < 1 := zCG_lt_one delta hdelta
  have hcont : ContinuousOn (fun y => u2delta c delta y) (Set.Icc (0:ℝ) (zCG delta)) :=
    u2delta_continuousOn c delta (zCG delta) hz_lt_one
  apply convexOn_of_deriv2_nonneg (convex_Icc 0 (zCG delta)) hcont
  · rw [interior_Icc]
    intro y hy
    exact (u2delta_hasDerivAt c delta y hy.1
      (lt_trans hy.2 hz_lt_one)).differentiableAt.differentiableWithinAt
  · rw [interior_Icc]
    intro y hy
    have hy0 : 0 < y := hy.1
    have hy1 : y < 1 := lt_trans hy.2 hz_lt_one
    have hnhds : Set.Ioo (0:ℝ) (zCG delta) ∈ nhds y := isOpen_Ioo.mem_nhds hy
    have hloc : deriv (fun y => u2delta c delta y) =ᶠ[nhds y] fun z => u2deriv c delta z := by
      filter_upwards [hnhds] with z hz
      exact (u2delta_hasDerivAt c delta z hz.1 (lt_trans hz.2 hz_lt_one)).deriv
    have hd2 : DifferentiableAt ℝ (fun y => u2deriv c delta y) y :=
      (u2delta_secondDeriv c delta y hy0 hy1).differentiableAt
    exact (hd2.congr_of_eventuallyEq hloc).differentiableWithinAt
  · rw [interior_Icc]
    intro y hy
    have hy0 : 0 < y := hy.1
    have hy1 : y < 1 := lt_trans hy.2 hz_lt_one
    have hnhds : Set.Ioo (0:ℝ) (zCG delta) ∈ nhds y := isOpen_Ioo.mem_nhds hy
    have hloc : deriv (fun y => u2delta c delta y) =ᶠ[nhds y] fun z => u2deriv c delta z := by
      filter_upwards [hnhds] with z hz
      exact (u2delta_hasDerivAt c delta z hz.1 (lt_trans hz.2 hz_lt_one)).deriv
    have hd2_eq : deriv (deriv (fun y => u2delta c delta y)) y =
        deriv (fun y => u2deriv c delta y) y := hloc.deriv_eq
    simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
    rw [hd2_eq, (u2delta_secondDeriv c delta y hy0 hy1).deriv]
    have hpsi_z : (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) = 0 := by
      have h := zCG_inflection delta hdelta; linarith
    have hpsi_anti := u1psi_strictAnti delta hdelta
    have hy_in : y ∈ Set.Ioo (0:ℝ) 1 := ⟨hy0, hy1⟩
    have hz_in : zCG delta ∈ Set.Ioo (0:ℝ) 1 := ⟨hz_pos, hz_lt_one⟩
    have hpsi_y_nonneg : 0 ≤ y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) := by
      rcases eq_or_lt_of_le (le_of_lt hy.2) with heq | hlt
      · have : y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) =
            (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) := by rw [heq]
        rw [this, hpsi_z]
      · have := hpsi_anti hy_in hz_in hlt
        simp only at this
        linarith [hpsi_z]
    have h1c : 0 ≤ (1 - c) / 4 := by linarith
    have : 0 ≤ (1 - c) / 4 * (y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2)) :=
      mul_nonneg h1c hpsi_y_nonneg
    simpa using this

/-- `u2delta c δ` is concave on `[zCG δ, 1]` (for `δ > 0`, `c ≤ 1`). -/
private theorem u2delta_concaveOn_right (c delta : ℝ) (hc1 : c ≤ 1) (hdelta : 0 < delta) :
    ConcaveOn ℝ (Set.Icc (zCG delta) 1) (fun y => u2delta c delta y) := by
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have hz_lt_one : zCG delta < 1 := zCG_lt_one delta hdelta
  have hcont : ContinuousOn (fun y => u2delta c delta y) (Set.Icc (zCG delta) 1) := by
    intro x hx
    have hx_ge : zCG delta ≤ x := hx.1
    have hx_le : x ≤ 1 := hx.2
    have hx_pos : 0 < x := lt_of_lt_of_le hz_pos hx_ge
    have h_inner : ContinuousAt (fun y : ℝ => 1 - y) x :=
      (continuous_const.sub continuous_id).continuousAt
    have h_outer : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) (1 - x) := by
      rcases eq_or_lt_of_le hx_le with hxone | hxlt
      · rw [hxone]; simpa using
          Real.continuousAt_rpow_const (0:ℝ) ((1:ℝ)/2) (Or.inr (by norm_num))
      · exact Real.continuousAt_rpow_const (1 - x) ((1:ℝ)/2) (Or.inl (by linarith))
    have h_1mx_pow : ContinuousAt (fun y : ℝ => (1 - y) ^ ((1:ℝ)/2)) x := h_outer.comp h_inner
    have h_d_1mx : ContinuousAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2)) x :=
      h_1mx_pow.const_mul delta
    have h_x_pow : ContinuousAt (fun y : ℝ => y ^ ((1:ℝ)/2)) x :=
      Real.continuousAt_rpow_const x ((1:ℝ)/2) (Or.inr (by norm_num))
    have h_diff : ContinuousAt (fun y : ℝ => delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2)) x :=
      h_d_1mx.sub h_x_pow
    have h_mul : ContinuousAt
        (fun y : ℝ => (1 - c) * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2))) x :=
      h_diff.const_mul (1 - c)
    have h_total : ContinuousAt (fun y => u2delta c delta y) x := by
      have : (fun y => u2delta c delta y) =
          (fun y : ℝ => (1 - c) * (delta * (1 - y) ^ ((1:ℝ)/2) - y ^ ((1:ℝ)/2)) - 1 + 2 * y - c) := by
        funext y; rw [u2delta]
      rw [this]
      exact (((h_mul.sub continuousAt_const).add
        ((continuous_const.mul continuous_id).continuousAt)).sub continuousAt_const)
    exact h_total.continuousWithinAt
  apply concaveOn_of_deriv2_nonpos (convex_Icc (zCG delta) 1) hcont
  · rw [interior_Icc]
    intro y hy
    exact (u2delta_hasDerivAt c delta y (lt_trans hz_pos hy.1) hy.2).differentiableAt.differentiableWithinAt
  · rw [interior_Icc]
    intro y hy
    have hy0 : 0 < y := lt_trans hz_pos hy.1
    have hnhds : Set.Ioo (zCG delta) 1 ∈ nhds y := isOpen_Ioo.mem_nhds hy
    have hloc : deriv (fun y => u2delta c delta y) =ᶠ[nhds y] fun z => u2deriv c delta z := by
      filter_upwards [hnhds] with z hz
      exact (u2delta_hasDerivAt c delta z (lt_trans hz_pos hz.1) hz.2).deriv
    have hd2 : DifferentiableAt ℝ (fun y => u2deriv c delta y) y :=
      (u2delta_secondDeriv c delta y hy0 hy.2).differentiableAt
    exact (hd2.congr_of_eventuallyEq hloc).differentiableWithinAt
  · rw [interior_Icc]
    intro y hy
    have hy0 : 0 < y := lt_trans hz_pos hy.1
    have hy1 : y < 1 := hy.2
    have hnhds : Set.Ioo (zCG delta) 1 ∈ nhds y := isOpen_Ioo.mem_nhds hy
    have hloc : deriv (fun y => u2delta c delta y) =ᶠ[nhds y] fun z => u2deriv c delta z := by
      filter_upwards [hnhds] with z hz
      exact (u2delta_hasDerivAt c delta z (lt_trans hz_pos hz.1) hz.2).deriv
    have hd2_eq : deriv (deriv (fun y => u2delta c delta y)) y =
        deriv (fun y => u2deriv c delta y) y := hloc.deriv_eq
    simp only [Function.iterate_succ, Function.iterate_zero, Function.comp_apply, id]
    rw [hd2_eq, (u2delta_secondDeriv c delta y hy0 hy1).deriv]
    have hpsi_z : (zCG delta) ^ (-(3:ℝ)/2) - delta * (1 - zCG delta) ^ (-(3:ℝ)/2) = 0 := by
      have h := zCG_inflection delta hdelta; linarith
    have hpsi_anti := u1psi_strictAnti delta hdelta
    have hy_in : y ∈ Set.Ioo (0:ℝ) 1 := ⟨hy0, hy1⟩
    have hz_in : zCG delta ∈ Set.Ioo (0:ℝ) 1 := ⟨hz_pos, hz_lt_one⟩
    have hpsi_y_nonpos : y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2) ≤ 0 := by
      have := hpsi_anti hz_in hy_in hy.1
      simp only at this
      linarith [hpsi_z]
    have h1c : 0 ≤ (1 - c) / 4 := by linarith
    have : (1 - c) / 4 * (y ^ (-(3:ℝ)/2) - delta * (1 - y) ^ (-(3:ℝ)/2)) ≤ 0 :=
      mul_nonpos_of_nonneg_of_nonpos h1c hpsi_y_nonpos
    simpa using this

/-- `u2delta c δ 1 = -2c` (the right-endpoint value). Wait — for robustness `u2delta c δ 1`
needs care.  `u2delta c δ 1 = (1-c)(δ·0 - 1) - 1 + 2 - c = -(1-c) + 1 - c = 0`. -/
private theorem u2delta_at_one (c delta : ℝ) : u2delta c delta 1 = 0 := by
  unfold u2delta
  rw [show (1:ℝ) - 1 = 0 by ring, Real.zero_rpow (by norm_num), Real.one_rpow]
  ring

/-- **Nonnegativity engine** (robustness c→−c image). -/
private theorem u2delta_nonneg_engine (c delta a2v : ℝ) (hc1 : c ≤ 1) (hdelta : 0 < delta)
    (ha2v_pos : 0 < a2v) (ha2v_le_z : a2v ≤ zCG delta)
    (hu_zero : u2delta c delta a2v = 0)
    (hderiv_zero : u2deriv c delta a2v = 0) :
    ∀ y : ℝ, 0 ≤ y → y ≤ 1 → 0 ≤ u2delta c delta y := by
  have hz_pos : 0 < zCG delta := zCG_pos delta hdelta
  have hz_lt_one : zCG delta < 1 := zCG_lt_one delta hdelta
  have ha2v_lt_one : a2v < 1 := lt_of_le_of_lt ha2v_le_z hz_lt_one
  set f : ℝ → ℝ := fun y => u2delta c delta y with hf_def
  have hconv : ConvexOn ℝ (Set.Icc (0:ℝ) (zCG delta)) f := u2delta_convexOn_left c delta hc1 hdelta
  have hconc : ConcaveOn ℝ (Set.Icc (zCG delta) 1) f := u2delta_concaveOn_right c delta hc1 hdelta
  have ha2v_mem : a2v ∈ Set.Icc (0:ℝ) (zCG delta) := ⟨le_of_lt ha2v_pos, ha2v_le_z⟩
  have hderiv_a2 : HasDerivAt f (u2deriv c delta a2v) a2v :=
    u2delta_hasDerivAt c delta a2v ha2v_pos ha2v_lt_one
  rw [hderiv_zero] at hderiv_a2
  have hleft : ∀ y ∈ Set.Icc (0:ℝ) (zCG delta), 0 ≤ f y := by
    intro y hy
    have hfa2 : f a2v = 0 := hu_zero
    rcases lt_trichotomy y a2v with hlt | heq | hgt
    · have hsl := hconv.slope_le_of_hasDerivAt hy ha2v_mem hlt hderiv_a2
      rw [slope_def_field] at hsl
      have hpos : 0 < a2v - y := by linarith
      have : f a2v - f y ≤ 0 := by
        by_contra hcon
        push_neg at hcon
        have : 0 < (f a2v - f y) / (a2v - y) := div_pos hcon hpos
        linarith
      linarith [hfa2]
    · rw [heq, hfa2]
    · have hsl := hconv.le_slope_of_hasDerivAt ha2v_mem hy hgt hderiv_a2
      rw [slope_def_field] at hsl
      have hpos : 0 < y - a2v := by linarith
      have : 0 ≤ f y - f a2v := by
        by_contra hcon
        push_neg at hcon
        have : (f y - f a2v) / (y - a2v) < 0 := div_neg_of_neg_of_pos hcon hpos
        linarith
      linarith [hfa2]
  have hz_mem_left : zCG delta ∈ Set.Icc (0:ℝ) (zCG delta) := ⟨le_of_lt hz_pos, le_refl _⟩
  have hfz_nonneg : 0 ≤ f (zCG delta) := hleft _ hz_mem_left
  have hf_one : f 1 = 0 := u2delta_at_one c delta
  have hright : ∀ y ∈ Set.Icc (zCG delta) 1, 0 ≤ f y := by
    intro y hy
    have hz_mem : zCG delta ∈ Set.Icc (zCG delta) 1 := ⟨le_refl _, le_of_lt hz_lt_one⟩
    have hone_mem : (1:ℝ) ∈ Set.Icc (zCG delta) 1 := ⟨le_of_lt hz_lt_one, le_refl _⟩
    have hy_seg : y ∈ segment ℝ (zCG delta) 1 := by
      rw [segment_eq_Icc (le_of_lt hz_lt_one)]; exact hy
    have hchord := hconc.ge_on_segment hz_mem hone_mem hy_seg
    have hmin_nn : 0 ≤ min (f (zCG delta)) (f 1) := by
      rw [hf_one]; exact le_min hfz_nonneg (le_refl 0)
    exact le_trans hmin_nn hchord
  intro y hy0 hy1
  rcases le_or_gt y (zCG delta) with hyz | hyz
  · exact hleft y ⟨hy0, hyz⟩
  · exact hright y ⟨le_of_lt hyz, hy1⟩

/-- `0 < delta2 c` for `c ∈ [0,1)` (since `0 < λ₂ < 1`). -/
private theorem delta2_pos (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) : 0 < delta2 c := by
  obtain ⟨hl0, hl1, _⟩ := RGLambda2InUnitInterval c hc0 hc1
  unfold delta2 delta_of_lambda
  have h1 : (1:ℝ) < lambda2 c ^ (-((2:ℝ)/(2-1))) := by
    rw [show (-((2:ℝ)/(2-1))) = (-2:ℝ) by norm_num,
      show (-2:ℝ) = -(2:ℝ) by norm_num, Real.rpow_neg hl0.le,
      show (2:ℝ) = ((2:ℕ):ℝ) by norm_num, Real.rpow_natCast]
    rw [one_lt_inv_iff₀]
    refine ⟨by positivity, ?_⟩
    nlinarith [hl0, hl1, sq_nonneg (lambda2 c)]
  apply Real.rpow_pos_of_pos; linarith

/-- **Single-branch pointwise nonnegativity**: `u2 c y ≥ 0` for `y ∈ [0,1]`,
for ALL `c ∈ [0,1)` (the `c→−c` LOW-branch image; no high branch). -/
private theorem rg_hu2_nonneg (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1) :
    ∀ y : ℝ, 0 ≤ y → y ≤ 1 → 0 ≤ u2 c y := by
  have hd2pos : 0 < delta2 c := delta2_pos c hc0 hc1
  -- surd s = √(3-2c)
  have h3 : (0:ℝ) ≤ 3 - 2 * c := by linarith
  set s := Real.sqrt (3 - 2 * c) with hs_def
  have hs_nn : 0 ≤ s := Real.sqrt_nonneg _
  have hs_sq : s ^ 2 = 3 - 2 * c := by rw [hs_def, sq, Real.mul_self_sqrt h3]
  have hs_ge1 : 1 ≤ s := by
    rw [hs_def, show (1:ℝ) = Real.sqrt 1 by simp]; exact Real.sqrt_le_sqrt (by linarith)
  -- strict: since c < 1, 3-2c > 1, so s > 1.
  have hs_gt1 : 1 < s := by
    have h1 : (1:ℝ) < 3 - 2 * c := by linarith
    nlinarith [hs_sq, hs_nn, hs_ge1]
  -- s > c needs care: s² = 3-2c, c≥0; (s-c) sign? At c→1: s²=1, s=1 > c<1. Generally s>c.
  have hs_gt_c : c < s := by nlinarith [hs_sq, hs_nn, sq_nonneg (s - c)]
  -- a₂' and its square roots
  have ha2v : a2' c = (2 - c - s) / 2 := by rw [a2', hs_def]
  have ht_nn : (0:ℝ) ≤ (s - 1) / 2 := by linarith
  have ha2v_sq : a2' c = ((s - 1) / 2) ^ 2 := by rw [ha2v]; nlinarith [hs_sq]
  have ha2v_pos : 0 < a2' c := by
    rw [ha2v_sq]; have : (0:ℝ) < (s-1)/2 ∨ (s-1)/2 = 0 := by
      rcases eq_or_lt_of_le hs_ge1 with h | h
      · right; rw [← h]; ring
      · left; linarith
    rcases this with h | h
    · positivity
    · exfalso; have : s = 1 := by linarith
      rw [this] at hs_sq; nlinarith [hc0]
  have hsqrt_a2v : (a2' c) ^ ((1:ℝ)/2) = (s - 1) / 2 := by
    rw [ha2v_sq, ← Real.rpow_natCast ((s-1)/2) 2, ← Real.rpow_mul ht_nn]
    norm_num
  have h1ma2v : 1 - a2' c = (s + c) / 2 := by rw [ha2v]; ring
  have h1ma2v_pos : 0 < 1 - a2' c := by rw [h1ma2v]; linarith
  have h1mc_pos : (0:ℝ) < 1 - c := by linarith
  -- δ₂ explicit: δ₂² = N²/(1-a₂'), and δ₂·√(1-a₂') = N with N ≥ 0.
  obtain ⟨hlam_eq, _, _⟩ := RGDeltaLambda c hc0 hc1
  obtain ⟨hl0, hl1, _⟩ := RGLambda2InUnitInterval c hc0 hc1
  set δ := delta2 c with hδ_def
  set rt : ℝ := (1 - a2' c) ^ ((1:ℝ)/2) with hrt_def
  have hrt_sq : rt ^ 2 = 1 - a2' c := by
    rw [hrt_def, ← Real.rpow_natCast _ 2, ← Real.rpow_mul (le_of_lt h1ma2v_pos)]; norm_num
  have hrt_pos : 0 < rt := by rw [hrt_def]; exact Real.rpow_pos_of_pos h1ma2v_pos _
  -- N (numerator), in surd form.  N = (1-2a₂'+c)/(1-c) + √a₂'.
  set N : ℝ := (1 - 2 * a2' c + c) / (1 - c) + (a2' c) ^ ((1:ℝ)/2) with hN_def
  have hN_s : N = (s - 1 + 2 * c) / (1 - c) + (s - 1) / 2 := by
    rw [hN_def, hsqrt_a2v, ha2v]; congr 1; field_simp; ring
  have hN_nn : 0 ≤ N := by
    rw [hN_s]; rw [div_add_div _ _ (ne_of_gt h1mc_pos) (by norm_num : (2:ℝ) ≠ 0)]
    apply div_nonneg _ (by positivity)
    nlinarith [hs_ge1, hs_gt_c, hc0, hs_sq, sq_nonneg (s - 1)]
  -- δ² = lambda2^{-2} - 1.
  have hbase_nn : (0:ℝ) ≤ lambda2 c ^ (-((2:ℝ)/(2-1))) - 1 := by
    rw [show (-((2:ℝ)/(2-1))) = -(2:ℝ) by norm_num, Real.rpow_neg hl0.le,
      show (2:ℝ)=((2:ℕ):ℝ) by norm_num, Real.rpow_natCast,
      le_sub_iff_add_le, zero_add, one_le_inv_iff₀]
    exact ⟨by positivity, by nlinarith [hl0, hl1, sq_nonneg (lambda2 c)]⟩
  have hδ_sq : δ ^ 2 = lambda2 c ^ (-((2:ℝ)/(2-1))) - 1 := by
    rw [hδ_def]; unfold delta2 delta_of_lambda
    rw [← Real.rpow_natCast _ 2, ← Real.rpow_mul hbase_nn]; norm_num
  have hlaminv : lambda2 c ^ (-((2:ℝ)/(2-1))) = 1 + N ^ 2 / (1 - a2' c) := by
    rw [hlam_eq, ← Real.rpow_mul (by positivity)]
    rw [show (-(1:ℝ)/2) * (-((2:ℝ)/(2-1))) = 1 by norm_num, Real.rpow_one]
  have hδ_d2sq : δ ^ 2 * (1 - a2' c) = N ^ 2 := by
    rw [hδ_sq, hlaminv, hN_def]; field_simp; ring
  -- δ·rt = N
  have hδrt : δ * rt = N := by
    have hsq : (δ * rt) ^ 2 = N ^ 2 := by
      rw [mul_pow, hrt_sq]; exact hδ_d2sq
    have hδrt_nn : 0 ≤ δ * rt := by positivity
    nlinarith [hsq, hN_nn, hδrt_nn, sq_nonneg (δ * rt - N)]
  -- u₂(a₂') = 0.
  have hu_zero : u2 c (a2' c) = 0 := by
    show u2delta c δ (a2' c) = 0
    unfold u2delta
    rw [show (1 - a2' c) ^ ((1:ℝ)/2) = rt from rfl, hsqrt_a2v]
    have : δ * rt = (1 - 2 * a2' c + c) / (1 - c) + (s - 1) / 2 := by
      rw [hδrt, hN_def, hsqrt_a2v]
    rw [this, ha2v]; field_simp; ring
  -- FOC: u2deriv c δ (a₂') = 0.
  have hsqrt_a2v_pos : 0 < (a2' c) ^ ((1:ℝ)/2) := by rw [hsqrt_a2v]; linarith [hs_gt1]
  have hderiv_zero : u2deriv c δ (a2' c) = 0 := by
    unfold u2deriv
    have e1 : (1 - a2' c) ^ (-(1:ℝ)/2) = rt⁻¹ := by
      rw [hrt_def, show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt h1ma2v_pos)]
    have e2 : (a2' c) ^ (-(1:ℝ)/2) = ((a2' c) ^ ((1:ℝ)/2))⁻¹ := by
      rw [show (-(1:ℝ)/2) = -((1:ℝ)/2) by ring, Real.rpow_neg (le_of_lt ha2v_pos)]
    rw [e1, e2, hsqrt_a2v]
    have hs1 : s - 1 > 0 := by linarith
    have hsc : s + c > 0 := by linarith
    have hδrt_inv : δ * rt⁻¹ = N / (1 - a2' c) := by
      rw [eq_div_iff (ne_of_gt h1ma2v_pos), ← hrt_sq]
      have : δ * rt⁻¹ * rt ^ 2 = (δ * rt) * (rt⁻¹ * rt) := by ring
      rw [this, hδrt, inv_mul_cancel₀ (ne_of_gt hrt_pos), mul_one]
    have hbracket : -δ * rt⁻¹ - ((s - 1) / 2)⁻¹ = -(N / (1 - a2' c)) - ((s - 1) / 2)⁻¹ := by
      linear_combination -hδrt_inv
    have hgoal : (1 / 2) * (1 - c) * (-δ * rt⁻¹ - ((s - 1) / 2)⁻¹) + 2 = 0 := by
      rw [hbracket, hN_s, h1ma2v]
      have hsc' : (s + c) / 2 ≠ 0 := ne_of_gt (by linarith)
      have hs1' : (s - 1) / 2 ≠ 0 := ne_of_gt (by linarith)
      field_simp
      nlinarith [hs_sq, hs1, hsc, h1mc_pos]
    exact hgoal
  -- a₂' ≤ zCG δ.
  have hz_pos : 0 < zCG δ := zCG_pos δ hd2pos
  have hz_lt_one : zCG δ < 1 := zCG_lt_one δ hd2pos
  have ha2v_lt_one : a2' c < 1 := by linarith [h1ma2v_pos]
  have ht_pos : 0 < (s - 1) / 2 := by
    rcases eq_or_lt_of_le hs_ge1 with h | h
    · exfalso; have : s = 1 := h.symm; rw [this] at hs_sq; nlinarith [hc0]
    · linarith
  have hpsi_a2_pos : 0 < (a2' c) ^ (-(3:ℝ)/2) - δ * (1 - a2' c) ^ (-(3:ℝ)/2) := by
    have e_a3 : (a2' c) ^ (-(3:ℝ)/2) = (((s - 1) / 2) ^ 3)⁻¹ := by
      rw [ha2v_sq, ← Real.rpow_natCast (((s-1)/2)) 2, ← Real.rpow_mul ht_nn,
        show ((2:ℕ):ℝ) * (-(3:ℝ)/2) = -((3:ℕ):ℝ) by norm_num,
        Real.rpow_neg ht_nn, Real.rpow_natCast]
    have e_1ma3 : (1 - a2' c) ^ (-(3:ℝ)/2) = (rt ^ 3)⁻¹ := by
      have hrt3 : rt ^ 3 = (1 - a2' c) ^ ((3:ℝ)/2) := by
        rw [hrt_def, ← Real.rpow_natCast _ 3, ← Real.rpow_mul (le_of_lt h1ma2v_pos)]
        norm_num
      rw [hrt3, show (-(3:ℝ)/2) = -((3:ℝ)/2) by ring, Real.rpow_neg (le_of_lt h1ma2v_pos)]
    rw [e_a3, e_1ma3]
    have hδ_rt3 : δ * (rt ^ 3)⁻¹ = N / (1 - a2' c) ^ 2 := by
      rw [eq_div_iff (by positivity)]
      have hrtne : rt ≠ 0 := ne_of_gt hrt_pos
      have hkey : (rt ^ 3)⁻¹ * (1 - a2' c) ^ 2 = rt := by
        rw [← hrt_sq]
        field_simp
      calc δ * (rt ^ 3)⁻¹ * (1 - a2' c) ^ 2
          = δ * ((rt ^ 3)⁻¹ * (1 - a2' c) ^ 2) := by ring
        _ = δ * rt := by rw [hkey]
        _ = N := hδrt
    rw [hδ_rt3]
    rw [h1ma2v, hN_s]
    have hs1 : 0 < s - 1 := by linarith
    have hsc : 0 < s + c := by linarith
    rw [inv_eq_one_div, sub_pos, div_lt_div_iff₀ (by positivity) (by positivity)]
    rw [div_add_div _ _ (ne_of_gt h1mc_pos) (by norm_num : (2:ℝ) ≠ 0),
      div_mul_eq_mul_div, div_lt_iff₀ (by positivity)]
    nlinarith [hs_sq, hs1, hsc, h1mc_pos, hs_nn, sq_nonneg (s - 1), mul_pos hs1 hsc,
      mul_nonneg hs_nn (sq_nonneg (s - 1)), mul_pos (mul_pos hs1 hsc) h1mc_pos]
  have ha2v_le_z : a2' c ≤ zCG δ := by
    by_contra hcon
    push_neg at hcon
    have hz_in : zCG δ ∈ Set.Ioo (0:ℝ) 1 := ⟨hz_pos, hz_lt_one⟩
    have ha_in : a2' c ∈ Set.Ioo (0:ℝ) 1 := ⟨ha2v_pos, ha2v_lt_one⟩
    have hpsi_z : (zCG δ) ^ (-(3:ℝ)/2) - δ * (1 - zCG δ) ^ (-(3:ℝ)/2) = 0 := by
      have h := zCG_inflection δ hd2pos; linarith
    have := u1psi_strictAnti δ hd2pos hz_in ha_in hcon
    simp only at this
    linarith [hpsi_a2_pos, hpsi_z]
  -- Apply the engine.
  have hkey := u2delta_nonneg_engine c δ (a2' c) (le_of_lt hc1) hd2pos ha2v_pos ha2v_le_z hu_zero hderiv_zero
  intro y hy0 hy1
  show 0 ≤ u2delta c δ y
  exact hkey y hy0 hy1

theorem RGRelaxedCoreNonneg
    (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1)
    {n : ℕ}
    (x : Fin n → ℝ)
    (hx_nn : ∀ i, 0 ≤ x i) (hx_le_one : ∀ i, x i ≤ 1)
    (hx_sum : (∑ i, x i) = (1 + c) / 2 * (n : ℝ)) :
    0 ≤ (∑ i, h_q 2 (lambda2 c) (delta2 c) (x i)) := by
  have hc_pos : (0 : ℝ) < 1 - c := by linarith
  have hlam_pos : 0 < lambda2 c := (RGLambda2InUnitInterval c hc0 hc1).1
  have hcoef_nn : 0 ≤ lambda2 c / (1 - c) := by positivity
  -- SINGLE branch: `u₂ ≥ 0` global support line `ℓ(x) = λ₂/(1-c)·(1 − 2x + c)`.
  have hu2_nonneg : ∀ y : ℝ, 0 ≤ y → y ≤ 1 → 0 ≤ u2 c y :=
    rg_hu2_nonneg c hc0 hc1
  have key : ∀ y : ℝ,
      h_q 2 (lambda2 c) (delta2 c) y = lambda2 c / (1 - c) * (u2 c y + 1 - 2 * y + c) := by
    intro y; unfold h_q u2; field_simp; ring
  have h_pointwise : ∀ i,
      lambda2 c / (1 - c) * (1 - 2 * x i + c) ≤ h_q 2 (lambda2 c) (delta2 c) (x i) := by
    intro i
    rw [key (x i)]
    have hu := hu2_nonneg (x i) (hx_nn i) (hx_le_one i)
    have hmul := mul_le_mul_of_nonneg_left
      (show (1 - 2 * x i + c) ≤ (u2 c (x i) + 1 - 2 * (x i) + c) by linarith) hcoef_nn
    linarith [hmul]
  have hsum_lb :
      (∑ i, lambda2 c / (1 - c) * (1 - 2 * x i + c))
        ≤ (∑ i, h_q 2 (lambda2 c) (delta2 c) (x i)) :=
    Finset.sum_le_sum (fun i _ => h_pointwise i)
  have hsum_eq : (∑ i, lambda2 c / (1 - c) * (1 - 2 * x i + c)) = 0 := by
    rw [← Finset.mul_sum]
    have hinner : (∑ i, (1 - 2 * x i + c)) = (n : ℝ) - 2 * (∑ i, x i) + c * n := by
      rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, Finset.sum_const,
        Finset.card_univ, Fintype.card_fin, ← Finset.mul_sum, Finset.sum_const,
        Finset.card_univ, Fintype.card_fin]
      simp [mul_comm]
    rw [hinner, hx_sum]; ring
  rw [hsum_eq] at hsum_lb
  exact hsum_lb

end Workspace.ProofLemmas.RGRelaxedCoreNonneg

open Workspace.Types.LqNorm
open scoped BigOperators

/-- Strict-monotonicity primitive for `lqNorm`: if `tildep` agrees with
`p` off a single coordinate `j_0` and `|tildep j_0 - f j_0| < |p j_0 - f j_0|`,
then `lqNorm q (tildep - f) < lqNorm q (p - f)`. -/
theorem LqNormStrictDecrease_OfSingleCoordinateCloser
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (p tildep f : Fin d → ℝ) (j0 : Fin d)
    (h_eq_off : ∀ k : Fin d, k ≠ j0 → tildep k = p k)
    (h_strict : |tildep j0 - f j0| < |p j0 - f j0|) :
    lqNorm q (fun k => tildep k - f k) < lqNorm q (fun k => p k - f k) := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hinv_pos : 0 < (1 : ℝ) / q := by
    rw [one_div]; exact inv_pos.mpr hq_pos
  -- Step 1: reduce to comparing the inner sums via strict monotonicity of x ↦ x^(1/q)
  unfold lqNorm
  -- Set up the two sums
  set S₁ : ℝ := ∑ j, |tildep j - f j| ^ q with hS₁
  set S₂ : ℝ := ∑ j, |p j - f j| ^ q with hS₂
  have hS₁_nn : 0 ≤ S₁ :=
    Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)
  have hS₂_nn : 0 ≤ S₂ :=
    Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)
  -- Step 2: show S₁ < S₂
  have h_sum_lt : S₁ < S₂ := by
    -- Apply Finset.sum_lt_sum: every term is ≤, and at j0 it is strictly <
    refine Finset.sum_lt_sum (fun k _ => ?_) ⟨j0, Finset.mem_univ j0, ?_⟩
    · -- term-wise ≤
      by_cases hk : k = j0
      · -- at j0, use strict inequality (which is in particular ≤)
        subst hk
        have h_abs_nn₁ : 0 ≤ |tildep k - f k| := abs_nonneg _
        have h_abs_lt : |tildep k - f k| < |p k - f k| := h_strict
        exact le_of_lt (Real.rpow_lt_rpow h_abs_nn₁ h_abs_lt hq_pos)
      · -- off j0: equality
        have hk_eq : tildep k = p k := h_eq_off k hk
        rw [hk_eq]
    · -- strict at j0
      have h_abs_nn₁ : 0 ≤ |tildep j0 - f j0| := abs_nonneg _
      exact Real.rpow_lt_rpow h_abs_nn₁ h_strict hq_pos
  -- Step 3: apply (·)^(1/q) which is strictly monotonic on [0,∞)
  exact Real.rpow_lt_rpow hS₁_nn h_sum_lt hinv_pos

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormStrictIncrease_OfSingleCoordinateLarger
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (p tildep : Fin d → ℝ) (j0 : Fin d)
    (h_eq_off : ∀ k : Fin d, k ≠ j0 → tildep k = p k)
    (h_strict : |p j0| < |tildep j0|) :
    lqNorm q p < lqNorm q tildep := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hinv_pos : 0 < (1 : ℝ) / q := by
    rw [one_div]; exact inv_pos.mpr hq_pos
  -- Step 1: reduce to comparing the inner sums via strict monotonicity of x ↦ x^(1/q)
  unfold lqNorm
  -- Set up the two sums
  set S₁ : ℝ := ∑ j, |p j| ^ q with hS₁
  set S₂ : ℝ := ∑ j, |tildep j| ^ q with hS₂
  have hS₁_nn : 0 ≤ S₁ :=
    Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)
  have hS₂_nn : 0 ≤ S₂ :=
    Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (abs_nonneg _) q)
  -- Step 2: show S₁ < S₂
  have h_sum_lt : S₁ < S₂ := by
    -- Apply Finset.sum_lt_sum: every term is ≤, and at j0 it is strictly <
    refine Finset.sum_lt_sum (fun k _ => ?_) ⟨j0, Finset.mem_univ j0, ?_⟩
    · -- term-wise ≤
      by_cases hk : k = j0
      · -- at j0, use strict inequality (which is in particular ≤)
        subst hk
        have h_abs_nn : 0 ≤ |p k| := abs_nonneg _
        exact le_of_lt (Real.rpow_lt_rpow h_abs_nn h_strict hq_pos)
      · -- off j0: equality
        have hk_eq : tildep k = p k := h_eq_off k hk
        rw [hk_eq]
    · -- strict at j0
      have h_abs_nn : 0 ≤ |p j0| := abs_nonneg _
      exact Real.rpow_lt_rpow h_abs_nn h_strict hq_pos
  -- Step 3: apply (·)^(1/q) which is strictly monotonic on [0,∞)
  exact Real.rpow_lt_rpow hS₁_nn h_sum_lt hinv_pos

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem Claim1_RuleOutInterior
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (j : Fin d) (hsig : sigma j = 1) :
    p_star j = 0 ∨ f j ≤ p_star j := by
  -- Proof by contradiction: suppose 0 < p_star j and p_star j < f j.
  by_contra hcon
  push_neg at hcon
  obtain ⟨hpj_ne, hpj_lt_fj⟩ := hcon
  -- From hp_in and σ_j = 1, p_star j ≥ 0; combined with ≠ 0 gives 0 < p_star j.
  have hpj_nn : 0 ≤ p_star j := (hp_in j).1 hsig
  have hpj_pos : 0 < p_star j := lt_of_le_of_ne hpj_nn (Ne.symm hpj_ne)
  -- Get the local-min radius ε > 0.
  obtain ⟨ε, hε_pos, hε_loc⟩ := hp_loc
  -- Define δ := min(ε/2, (f j - p_star j)/2) > 0.
  have hgap_pos : 0 < f j - p_star j := sub_pos.mpr hpj_lt_fj
  set δ : ℝ := min (ε / 2) ((f j - p_star j) / 2) with hδ_def
  have hδ_pos : 0 < δ := lt_min (by linarith) (by linarith)
  have hδ_le_eps_half : δ ≤ ε / 2 := min_le_left _ _
  have hδ_le_gap_half : δ ≤ (f j - p_star j) / 2 := min_le_right _ _
  -- Define t := p_star j + δ.
  set t : ℝ := p_star j + δ with ht_def
  have ht_gt_pj : p_star j < t := by rw [ht_def]; linarith
  have ht_lt_fj : t < f j := by
    rw [ht_def]
    have : (f j - p_star j) / 2 < f j - p_star j := by linarith
    linarith
  have ht_pos : 0 < t := lt_trans hpj_pos ht_gt_pj
  have ht_nn : 0 ≤ t := le_of_lt ht_pos
  -- Define the perturbation tildep := update p_star j t.
  set tildep : Fin d → ℝ := Function.update p_star j t with htildep_def
  -- tildep j = t.
  have htildep_at_j : tildep j = t := by
    simp [htildep_def, Function.update_self]
  -- For k ≠ j, tildep k = p_star k.
  have htildep_off_j : ∀ k : Fin d, k ≠ j → tildep k = p_star k := by
    intro k hk
    simp [htildep_def, Function.update_of_ne hk]
  -- tildep is in the orthant.
  have htildep_in : ∀ k, (sigma k = 1 → 0 ≤ tildep k) ∧ (sigma k = -1 → tildep k ≤ 0) := by
    intro k
    by_cases hk : k = j
    · subst hk
      refine ⟨fun _ => ?_, fun hsig_neg => ?_⟩
      · rw [htildep_at_j]; exact ht_nn
      · -- σ k = 1, but hypothesis says σ k = -1. Contradiction.
        exfalso
        rw [hsig] at hsig_neg
        linarith
    · rw [htildep_off_j k hk]
      exact hp_in k
  -- |tildep k - p_star k| < ε for all k.
  have htildep_close : ∀ k, |tildep k - p_star k| < ε := by
    intro k
    by_cases hk : k = j
    · subst hk
      rw [htildep_at_j, ht_def]
      have : p_star k + δ - p_star k = δ := by ring
      rw [this]
      rw [abs_of_pos hδ_pos]
      linarith
    · rw [htildep_off_j k hk]
      have : p_star k - p_star k = 0 := by ring
      rw [this, abs_zero]
      exact hε_pos
  -- By local-min: g(p_star) ≤ g(tildep).
  have hg_le : g_lambda q lambda f p_star ≤ g_lambda q lambda f tildep :=
    hε_loc tildep htildep_in htildep_close
  -- Now derive a strict inequality the other way.
  -- Step (a): lqNorm q (tildep - f) < lqNorm q (p_star - f).
  -- Need |tildep j - f j| < |p_star j - f j|.
  -- |tildep j - f j| = |t - f j| = f j - t (since t < f j).
  -- |p_star j - f j| = f j - p_star j (since p_star j < f j).
  -- And f j - t < f j - p_star j since p_star j < t.
  have h_abs_strict_decrease : |tildep j - f j| < |p_star j - f j| := by
    rw [htildep_at_j]
    have h1 : t - f j < 0 := sub_neg.mpr ht_lt_fj
    have h2 : p_star j - f j < 0 := sub_neg.mpr hpj_lt_fj
    rw [abs_of_neg h1, abs_of_neg h2]
    linarith
  have h_eq_off_decrease : ∀ k : Fin d, k ≠ j → tildep k = p_star k := htildep_off_j
  have hnorm_decrease :
      lqNorm q (fun k => tildep k - f k) < lqNorm q (fun k => p_star k - f k) :=
    LqNormStrictDecrease_OfSingleCoordinateCloser hq hd p_star tildep f j h_eq_off_decrease h_abs_strict_decrease
  -- Step (b): lqNorm q p_star < lqNorm q tildep.
  -- |p_star j| = p_star j, |tildep j| = t, p_star j < t.
  have h_abs_strict_increase : |p_star j| < |tildep j| := by
    rw [htildep_at_j]
    rw [abs_of_pos hpj_pos, abs_of_pos ht_pos]
    exact ht_gt_pj
  have h_eq_off_increase : ∀ k : Fin d, k ≠ j → tildep k = p_star k := htildep_off_j
  have hnorm_increase : lqNorm q p_star < lqNorm q tildep :=
    LqNormStrictIncrease_OfSingleCoordinateLarger hq hd p_star tildep j h_eq_off_increase h_abs_strict_increase
  -- Combine: g_lambda q lambda f tildep < g_lambda q lambda f p_star.
  have hg_strict_lt : g_lambda q lambda f tildep < g_lambda q lambda f p_star := by
    unfold g_lambda
    -- LHS = lqNorm q (tildep - f) - lambda * lqNorm q tildep
    -- RHS = lqNorm q (p_star - f) - lambda * lqNorm q p_star
    -- LHS < RHS ↔ lqNorm q (tildep - f) - lqNorm q (p_star - f) < lambda * (lqNorm q tildep - lqNorm q p_star)
    -- We have: lqNorm q (tildep - f) < lqNorm q (p_star - f) (so LHS_decrease < 0)
    -- and: lambda * (lqNorm q tildep - lqNorm q p_star) > 0 (so RHS positive).
    have h1 : lqNorm q (fun k => tildep k - f k) - lqNorm q (fun k => p_star k - f k) < 0 := by
      linarith
    have h2 : 0 < lambda * (lqNorm q tildep - lqNorm q p_star) := by
      apply mul_pos hlam0
      linarith
    linarith
  -- Contradiction.
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormPartialDerivative_PosBranch
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d)
    (hx_pos : 0 < x j) (hlq_pos : 0 < lqNorm q x) :
    HasDerivAt (fun t : ℝ => lqNorm q (Function.update x j t))
      ((x j) ^ (q - 1) / (lqNorm q x) ^ (q - 1)) (x j) := by
  -- Setup basic facts about q
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_xj_ne : (x j) ≠ 0 := ne_of_gt hx_pos
  have h_lqq_pos : 0 < lqNorm q x := hlq_pos
  have h_lqq_ne : lqNorm q x ≠ 0 := ne_of_gt h_lqq_pos
  have h_lqq_nonneg : 0 ≤ lqNorm q x := le_of_lt h_lqq_pos
  -- Define the constant part C = ∑_{k≠j} |x k|^q
  set C : ℝ := ∑ k ∈ Finset.univ.erase j, |x k| ^ q with hC_def
  -- The total sum equals C + (x j)^q (using |x j| = x j since x j > 0)
  have h_total_sum : (∑ k, |x k| ^ q) = C + (x j) ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h1 : (∑ k, |x k| ^ q) = ∑ k ∈ Finset.univ.erase j, |x k| ^ q + |x j| ^ q := by
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d)) (fun k => |x k| ^ q) hj_mem]
    rw [h1, abs_of_pos hx_pos]
  -- (lqNorm q x)^q = total_sum: ((∑|x|^q)^(1/q))^q = ∑|x|^q
  have h_lqNorm_q_eq : (lqNorm q x) ^ q = ∑ k, |x k| ^ q := by
    unfold lqNorm
    rw [← Real.rpow_mul (sum_abs_rpow_nonneg q x), one_div_mul_cancel hq_ne, Real.rpow_one]
  -- Show: in a nbhd of x j, the function equals (C + t^q)^(1/q)
  have h_pos_nhd : ∀ᶠ t in nhds (x j), (0 : ℝ) < t :=
    eventually_gt_nhds hx_pos
  have h_eq_local : ∀ᶠ t in nhds (x j),
      lqNorm q (Function.update x j t) = (C + t ^ q) ^ ((1 : ℝ) / q) := by
    filter_upwards [h_pos_nhd] with t ht_pos
    unfold lqNorm
    congr 1
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
          (fun k => |Function.update x j t k| ^ q) hj_mem]
    rw [Function.update_self, abs_of_pos ht_pos]
    congr 1
    apply Finset.sum_congr rfl
    intro k hk
    have hkj : k ≠ j := Finset.ne_of_mem_erase hk
    rw [Function.update_of_ne hkj]
  -- Compute derivative of t ↦ C + t^q at t = x j
  have h_t_pow_q : HasDerivAt (fun t : ℝ => t ^ q) (q * (x j) ^ (q - 1)) (x j) :=
    Real.hasDerivAt_rpow_const (Or.inl h_xj_ne)
  have h_C_add : HasDerivAt (fun t : ℝ => C + t ^ q) (q * (x j) ^ (q - 1)) (x j) := by
    have := h_t_pow_q.const_add C
    convert this using 1
  -- (C + (x j)^q) = (lqNorm q x)^q > 0
  have h_inner_eq : C + (x j) ^ q = (lqNorm q x) ^ q := by
    rw [← h_total_sum, ← h_lqNorm_q_eq]
  have h_inner_pos : 0 < C + (x j) ^ q := by
    rw [h_inner_eq]
    exact Real.rpow_pos_of_pos h_lqq_pos q
  have h_inner_ne : C + (x j) ^ q ≠ 0 := ne_of_gt h_inner_pos
  -- Use HasDerivAt.rpow_const for the outer composition
  have h_outer : HasDerivAt (fun t : ℝ => (C + t ^ q) ^ ((1 : ℝ) / q))
      (q * (x j) ^ (q - 1) * ((1 : ℝ) / q) * (C + (x j) ^ q) ^ ((1 : ℝ) / q - 1)) (x j) :=
    h_C_add.rpow_const (Or.inl h_inner_ne)
  -- Transfer via eventuallyEq
  have h_eq_local' : (fun t : ℝ => lqNorm q (Function.update x j t)) =ᶠ[nhds (x j)]
      (fun t : ℝ => (C + t ^ q) ^ ((1 : ℝ) / q)) := by
    filter_upwards [h_eq_local] with t ht
    exact ht
  rw [Filter.EventuallyEq.hasDerivAt_iff h_eq_local']
  -- Algebraic manipulation: show the two derivative values are equal
  convert h_outer using 1
  -- Goal: (x j)^(q-1) / (lqNorm q x)^(q-1) = q * (x j)^(q-1) * (1/q) * (C + (x j)^q)^(1/q - 1)
  rw [h_inner_eq]
  -- Now: (x j)^(q-1) / (lqNorm q x)^(q-1) = q * (x j)^(q-1) * (1/q) * ((lqNorm q x)^q)^(1/q - 1)
  -- Step 1: simplify q * (...) * (1/q) = (...)
  have h_q_simp : q * (x j) ^ (q - 1) * ((1 : ℝ) / q) = (x j) ^ (q - 1) := by
    field_simp
  rw [h_q_simp]
  -- Step 2: ((lqNorm q x)^q)^(1/q - 1) = (lqNorm q x)^(q*(1/q - 1)) = (lqNorm q x)^(1 - q)
  have h_pow_simp : ((lqNorm q x) ^ q) ^ ((1 : ℝ) / q - 1) = (lqNorm q x) ^ (1 - q) := by
    rw [← Real.rpow_mul h_lqq_nonneg]
    congr 1
    field_simp
  rw [h_pow_simp]
  -- Step 3: (lqNorm q x)^(1 - q) = ((lqNorm q x)^(q-1))⁻¹
  have h_neg : (lqNorm q x) ^ (1 - q) = ((lqNorm q x) ^ (q - 1))⁻¹ := by
    have : (1 - q) = -(q - 1) := by ring
    rw [this, Real.rpow_neg h_lqq_nonneg]
  rw [h_neg]
  -- Goal: (x j)^(q-1) / (lqNorm q x)^(q-1) = (x j)^(q-1) * ((lqNorm q x)^(q-1))⁻¹
  rw [div_eq_mul_inv]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem InteriorFOC_Pos
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (hp_pos : 0 < lqNorm q p_star)
    (j : Fin d) (hsig : sigma j = 1) (hpf : f j < p_star j) :
    (p_star j - f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
      = lambda * ((p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) := by
  -- Strategy: restrict g_lambda to the line through p_star in direction e_j and
  -- apply IsLocalMin.hasDerivAt_eq_zero.
  -- Setup
  have hpj_pos : 0 < p_star j := lt_of_le_of_lt (hf_nn j) hpf
  have hpfj_pos : 0 < p_star j - f j := sub_pos.mpr hpf
  -- Define y := p_star - f and y' := p_star (so we can apply LqNormPartialDerivative_PosBranch)
  set y : Fin d → ℝ := fun k => p_star k - f k with hy_def
  have hyj_pos : 0 < y j := hpfj_pos
  have hy_lq_pos : 0 < lqNorm q y := hpf_pos
  -- KEY ALGEBRAIC IDENTITY:
  -- (fun k => Function.update p_star j t k - f k) = Function.update y j (t - f j)
  have h_update_sub : ∀ t : ℝ,
      (fun k => Function.update p_star j t k - f k) = Function.update y j (t - f j) := by
    intro t
    funext k
    by_cases hk : k = j
    · subst hk
      rw [Function.update_self, Function.update_self]
    · rw [Function.update_of_ne hk, Function.update_of_ne hk]
  -- Derivative of t ↦ lqNorm q (Function.update y j (t - f j)) at t = p_star j
  -- Step 1: t ↦ t - f j has derivative 1 at t = p_star j, with value (p_star j - f j) = y j
  have h_lin : HasDerivAt (fun t : ℝ => t - f j) 1 (p_star j) := by
    have := (hasDerivAt_id (p_star j)).sub_const (f j)
    convert this
  -- Step 2: t ↦ lqNorm q (Function.update y j t) has derivative
  -- (y j)^(q-1) / (lqNorm q y)^(q-1) at t = y j = p_star j - f j
  have h_lq1 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update y j t))
      ((y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (y j) :=
    LqNormPartialDerivative_PosBranch hq hd y j hyj_pos hy_lq_pos
  -- Compose: t ↦ lqNorm q (Function.update y j (t - f j))
  -- has derivative ((y j)^(q-1)/(lqNorm q y)^(q-1)) * 1 at t = p_star j
  -- (since t - f j evaluated at p_star j gives p_star j - f j = y j)
  have h_yj_eq : y j = p_star j - f j := by simp [hy_def]
  have h_comp1 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update y j (t - f j)))
      ((y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (p_star j) := by
    have h_at : (p_star j) - f j = y j := h_yj_eq.symm
    have := HasDerivAt.comp (p_star j) (h_at ▸ h_lq1) h_lin
    -- this : HasDerivAt ((fun t => lqNorm q (Function.update y j t)) ∘ (fun t => t - f j))
    --   ((y j)^(q-1)/(lqNorm q y)^(q-1) * 1) (p_star j)
    have h_simp : (y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1) * 1 =
                  (y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1) := by ring
    rw [← h_simp]
    exact this
  -- Now rewrite the result in terms of p_star - f
  have h_deriv1 : HasDerivAt (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
      ((y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (p_star j) := by
    have h_eq : (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
              = (fun t : ℝ => lqNorm q (Function.update y j (t - f j))) := by
      funext t
      rw [h_update_sub t]
    rw [h_eq]
    exact h_comp1
  -- Derivative of t ↦ lqNorm q (Function.update p_star j t) at t = p_star j
  have h_deriv2 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update p_star j t))
      ((p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) (p_star j) :=
    LqNormPartialDerivative_PosBranch hq hd p_star j hpj_pos hp_pos
  -- Combine: derivative of φ(t) = g_lambda q lambda f (Function.update p_star j t)
  -- equals (deriv1) - lambda * (deriv2)
  set D1 : ℝ := (y j) ^ (q - 1) / (lqNorm q y) ^ (q - 1) with hD1_def
  set D2 : ℝ := (p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1) with hD2_def
  have h_phi_deriv : HasDerivAt
      (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t))
      (D1 - lambda * D2) (p_star j) := by
    unfold g_lambda
    exact h_deriv1.sub (h_deriv2.const_mul lambda)
  -- Now show: φ has a local min at p_star j
  obtain ⟨ε, hε_pos, hε_min⟩ := hp_loc
  -- Pick δ = min(ε, p_star j)
  have h_local_min :
      IsLocalMin (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) := by
    -- We need: ∀ᶠ t in nhds (p_star j), φ (p_star j) ≤ φ t
    rw [IsLocalMin, IsMinFilter]
    -- Want: ∀ᶠ t in nhds (p_star j), g_lambda q lambda f p_star ≤ g_lambda q lambda f (Function.update p_star j t)
    -- Note: Function.update p_star j (p_star j) = p_star.
    have h_eventually_close : ∀ᶠ t in nhds (p_star j), |t - p_star j| < ε := by
      filter_upwards [eventually_abs_sub_lt (p_star j) hε_pos] with t ht
      exact ht
    -- Also need t in (p_star j - p_star j, ∞) i.e. t > 0 for j coordinate
    have h_eventually_pos : ∀ᶠ t in nhds (p_star j), 0 < t := eventually_gt_nhds hpj_pos
    filter_upwards [h_eventually_close, h_eventually_pos] with t ht_close ht_pos
    -- Apply hε_min to p := Function.update p_star j t
    -- After update_self, Function.update p_star j (p_star j) = p_star
    show g_lambda q lambda f (Function.update p_star j (p_star j)) ≤
         g_lambda q lambda f (Function.update p_star j t)
    rw [Function.update_eq_self]
    apply hε_min (Function.update p_star j t)
    · -- Orthant condition
      intro k
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        refine ⟨fun _ => le_of_lt ht_pos, fun hcontr => ?_⟩
        rw [hsig] at hcontr; linarith
      · rw [Function.update_of_ne hk]
        exact hp_in k
    · -- Distance condition: |p k - p_star k| < ε for all k
      intro k
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        exact ht_close
      · rw [Function.update_of_ne hk]
        simp only [sub_self, abs_zero]
        exact hε_pos
  -- Apply IsLocalMin.hasDerivAt_eq_zero
  have h_zero : D1 - lambda * D2 = 0 := h_local_min.hasDerivAt_eq_zero h_phi_deriv
  -- Rewrite to obtain the goal
  -- Goal: D1 = lambda * D2
  have hD1_eq_D2 : D1 = lambda * D2 := by linarith
  -- Now translate back to the goal statement
  show (p_star j - f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
      = lambda * ((p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1))
  have h_y_lq : lqNorm q y = lqNorm q (fun k => p_star k - f k) := rfl
  rw [← h_yj_eq, ← h_y_lq]
  exact hD1_eq_D2

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormPartialDerivative_NegBranch
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d)
    (hx_neg : x j < 0) (hlq_pos : 0 < lqNorm q x) :
    HasDerivAt (fun t : ℝ => lqNorm q (Function.update x j t))
      (-(-(x j)) ^ (q - 1) / (lqNorm q x) ^ (q - 1)) (x j) := by
  -- Setup basic facts about q
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_xj_ne : (x j) ≠ 0 := ne_of_lt hx_neg
  have h_neg_xj_pos : 0 < -(x j) := neg_pos.mpr hx_neg
  have h_neg_xj_ne : -(x j) ≠ 0 := ne_of_gt h_neg_xj_pos
  have h_lqq_pos : 0 < lqNorm q x := hlq_pos
  have h_lqq_ne : lqNorm q x ≠ 0 := ne_of_gt h_lqq_pos
  have h_lqq_nonneg : 0 ≤ lqNorm q x := le_of_lt h_lqq_pos
  -- Define the constant part C = ∑_{k≠j} |x k|^q
  set C : ℝ := ∑ k ∈ Finset.univ.erase j, |x k| ^ q with hC_def
  -- The total sum equals C + (-(x j))^q (using |x j| = -(x j) since x j < 0)
  have h_total_sum : (∑ k, |x k| ^ q) = C + (-(x j)) ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h1 : (∑ k, |x k| ^ q) = ∑ k ∈ Finset.univ.erase j, |x k| ^ q + |x j| ^ q := by
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d)) (fun k => |x k| ^ q) hj_mem]
    rw [h1, abs_of_neg hx_neg]
  -- (lqNorm q x)^q = total_sum: ((∑|x|^q)^(1/q))^q = ∑|x|^q
  have h_lqNorm_q_eq : (lqNorm q x) ^ q = ∑ k, |x k| ^ q := by
    unfold lqNorm
    rw [← Real.rpow_mul (sum_abs_rpow_nonneg q x), one_div_mul_cancel hq_ne, Real.rpow_one]
  -- Show: in a nbhd of x j, the function equals (C + (-t)^q)^(1/q)
  have h_neg_nhd : ∀ᶠ t in nhds (x j), t < (0 : ℝ) :=
    eventually_lt_nhds hx_neg
  have h_eq_local : ∀ᶠ t in nhds (x j),
      lqNorm q (Function.update x j t) = (C + (-t) ^ q) ^ ((1 : ℝ) / q) := by
    filter_upwards [h_neg_nhd] with t ht_neg
    unfold lqNorm
    congr 1
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
          (fun k => |Function.update x j t k| ^ q) hj_mem]
    rw [Function.update_self, abs_of_neg ht_neg]
    congr 1
    apply Finset.sum_congr rfl
    intro k hk
    have hkj : k ≠ j := Finset.ne_of_mem_erase hk
    rw [Function.update_of_ne hkj]
  -- Compute derivative of t ↦ -t at t = x j
  have h_neg_t : HasDerivAt (fun t : ℝ => -t) (-1 : ℝ) (x j) := by
    simpa using (hasDerivAt_id (x j)).neg
  -- Compute derivative of s ↦ s^q at s = -(x j)
  have h_t_pow_q_outer : HasDerivAt (fun s : ℝ => s ^ q) (q * (-(x j)) ^ (q - 1)) (-(x j)) :=
    Real.hasDerivAt_rpow_const (Or.inl h_neg_xj_ne)
  -- Chain: derivative of t ↦ (-t)^q at t = x j is q * (-(x j))^(q-1) * (-1)
  have h_neg_t_pow_q : HasDerivAt (fun t : ℝ => (-t) ^ q)
      (q * (-(x j)) ^ (q - 1) * (-1)) (x j) :=
    h_t_pow_q_outer.comp (x j) h_neg_t
  -- Add constant C
  have h_C_add : HasDerivAt (fun t : ℝ => C + (-t) ^ q)
      (q * (-(x j)) ^ (q - 1) * (-1)) (x j) := by
    have := h_neg_t_pow_q.const_add C
    convert this using 1
  -- (C + (-(x j))^q) = (lqNorm q x)^q > 0
  have h_inner_eq : C + (-(x j)) ^ q = (lqNorm q x) ^ q := by
    rw [← h_total_sum, ← h_lqNorm_q_eq]
  have h_inner_pos : 0 < C + (-(x j)) ^ q := by
    rw [h_inner_eq]
    exact Real.rpow_pos_of_pos h_lqq_pos q
  have h_inner_ne : C + (-(x j)) ^ q ≠ 0 := ne_of_gt h_inner_pos
  -- Use HasDerivAt.rpow_const for the outer composition
  have h_outer : HasDerivAt (fun t : ℝ => (C + (-t) ^ q) ^ ((1 : ℝ) / q))
      (q * (-(x j)) ^ (q - 1) * (-1) * ((1 : ℝ) / q) *
        (C + (-(x j)) ^ q) ^ ((1 : ℝ) / q - 1)) (x j) :=
    h_C_add.rpow_const (Or.inl h_inner_ne)
  -- Transfer via eventuallyEq
  have h_eq_local' : (fun t : ℝ => lqNorm q (Function.update x j t)) =ᶠ[nhds (x j)]
      (fun t : ℝ => (C + (-t) ^ q) ^ ((1 : ℝ) / q)) := by
    filter_upwards [h_eq_local] with t ht
    exact ht
  rw [Filter.EventuallyEq.hasDerivAt_iff h_eq_local']
  -- Algebraic manipulation
  convert h_outer using 1
  -- Goal: -(-(x j))^(q-1) / (lqNorm q x)^(q-1) =
  --       q * (-(x j))^(q-1) * (-1) * (1/q) * (C + (-(x j))^q)^(1/q - 1)
  rw [h_inner_eq]
  -- Step 1: simplify q * (-(x j))^(q-1) * (-1) * (1/q) = -(-(x j))^(q-1)
  have h_q_simp : q * (-(x j)) ^ (q - 1) * (-1) * ((1 : ℝ) / q) = -(-(x j)) ^ (q - 1) := by
    field_simp
  rw [h_q_simp]
  -- Step 2: ((lqNorm q x)^q)^(1/q - 1) = (lqNorm q x)^(1 - q)
  have h_pow_simp : ((lqNorm q x) ^ q) ^ ((1 : ℝ) / q - 1) = (lqNorm q x) ^ (1 - q) := by
    rw [← Real.rpow_mul h_lqq_nonneg]
    congr 1
    field_simp
  rw [h_pow_simp]
  -- Step 3: (lqNorm q x)^(1 - q) = ((lqNorm q x)^(q-1))⁻¹
  have h_neg : (lqNorm q x) ^ (1 - q) = ((lqNorm q x) ^ (q - 1))⁻¹ := by
    have : (1 - q) = -(q - 1) := by ring
    rw [this, Real.rpow_neg h_lqq_nonneg]
  rw [h_neg]
  -- Goal: -(-(x j))^(q-1) / (lqNorm q x)^(q-1) = -(-(x j))^(q-1) * ((lqNorm q x)^(q-1))⁻¹
  rw [div_eq_mul_inv]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

/-- **Interior first-order condition — negative branch.**

Under the same hypotheses as `Claim1_RuleOutInterior`, suppose furthermore
`lqNorm q (p_star - f) > 0` and `lqNorm q p_star > 0`. Then for every
index `j` with `σ j = -1` and `p_star j < 0`, the first-order condition
holds:
`(f j - p_star j)^(q-1) / (lqNorm q (p_star - f))^(q-1)
  = λ · (-(p_star j))^(q-1) / (lqNorm q p_star)^(q-1)`.

Paper reference: Block 2, Steps 2.3.1–2.3.4 (KKT negative branch);
mirror of `InteriorFOC_Pos` with sign flips. -/
theorem InteriorFOC_Neg
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (hp_pos : 0 < lqNorm q p_star)
    (j : Fin d) (hsig : sigma j = -1) (hpneg : p_star j < 0) :
    (f j - p_star j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
      = lambda * ((-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) := by
  -- Mirror of InteriorFOC_Pos with sign flips.
  -- Setup
  have hpj_neg : p_star j < 0 := hpneg
  have hfj_nn : 0 ≤ f j := hf_nn j
  -- y j = p_star j - f j < 0 since p_star j < 0 and f j ≥ 0
  have hyj_neg : p_star j - f j < 0 := by linarith
  have hfj_sub_pos : 0 < f j - p_star j := by linarith
  -- Define y := p_star - f
  set y : Fin d → ℝ := fun k => p_star k - f k with hy_def
  have hyj_neg' : y j < 0 := hyj_neg
  have hy_lq_pos : 0 < lqNorm q y := hpf_pos
  -- KEY ALGEBRAIC IDENTITY:
  -- (fun k => Function.update p_star j t k - f k) = Function.update y j (t - f j)
  have h_update_sub : ∀ t : ℝ,
      (fun k => Function.update p_star j t k - f k) = Function.update y j (t - f j) := by
    intro t
    funext k
    by_cases hk : k = j
    · subst hk
      rw [Function.update_self, Function.update_self]
    · rw [Function.update_of_ne hk, Function.update_of_ne hk]
  -- Derivative of t ↦ lqNorm q (Function.update y j (t - f j)) at t = p_star j
  -- Step 1: t ↦ t - f j has derivative 1 at t = p_star j, with value (p_star j - f j) = y j
  have h_lin : HasDerivAt (fun t : ℝ => t - f j) 1 (p_star j) := by
    have := (hasDerivAt_id (p_star j)).sub_const (f j)
    convert this
  -- Step 2: t ↦ lqNorm q (Function.update y j t) has derivative
  -- -(-(y j))^(q-1) / (lqNorm q y)^(q-1) at t = y j
  have h_lq1 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update y j t))
      (-(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (y j) :=
    LqNormPartialDerivative_NegBranch hq hd y j hyj_neg' hy_lq_pos
  -- Compose: t ↦ lqNorm q (Function.update y j (t - f j))
  -- has derivative the same value at t = p_star j (since 1 * x = x)
  have h_yj_eq : y j = p_star j - f j := by simp [hy_def]
  have h_comp1 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update y j (t - f j)))
      (-(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (p_star j) := by
    have h_at : (p_star j) - f j = y j := h_yj_eq.symm
    have := HasDerivAt.comp (p_star j) (h_at ▸ h_lq1) h_lin
    have h_simp : -(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1) * 1 =
                  -(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1) := by ring
    rw [← h_simp]
    exact this
  -- Now rewrite the result in terms of p_star - f
  have h_deriv1 : HasDerivAt (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
      (-(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1)) (p_star j) := by
    have h_eq : (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
              = (fun t : ℝ => lqNorm q (Function.update y j (t - f j))) := by
      funext t
      rw [h_update_sub t]
    rw [h_eq]
    exact h_comp1
  -- Derivative of t ↦ lqNorm q (Function.update p_star j t) at t = p_star j
  have h_deriv2 : HasDerivAt (fun t : ℝ => lqNorm q (Function.update p_star j t))
      (-(-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) (p_star j) :=
    LqNormPartialDerivative_NegBranch hq hd p_star j hpneg hp_pos
  -- Combine: derivative of φ(t) = g_lambda q lambda f (Function.update p_star j t)
  -- equals (deriv1) - lambda * (deriv2)
  set D1 : ℝ := -(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1) with hD1_def
  set D2 : ℝ := -(-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1) with hD2_def
  have h_phi_deriv : HasDerivAt
      (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t))
      (D1 - lambda * D2) (p_star j) := by
    unfold g_lambda
    exact h_deriv1.sub (h_deriv2.const_mul lambda)
  -- Now show: φ has a local min at p_star j
  obtain ⟨ε, hε_pos, hε_min⟩ := hp_loc
  have h_local_min :
      IsLocalMin (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) := by
    rw [IsLocalMin, IsMinFilter]
    have h_eventually_close : ∀ᶠ t in nhds (p_star j), |t - p_star j| < ε := by
      filter_upwards [eventually_abs_sub_lt (p_star j) hε_pos] with t ht
      exact ht
    -- We need t < 0 in a neighborhood of p_star j (since p_star j < 0)
    have h_eventually_neg : ∀ᶠ t in nhds (p_star j), t < 0 := eventually_lt_nhds hpneg
    filter_upwards [h_eventually_close, h_eventually_neg] with t ht_close ht_neg
    show g_lambda q lambda f (Function.update p_star j (p_star j)) ≤
         g_lambda q lambda f (Function.update p_star j t)
    rw [Function.update_eq_self]
    apply hε_min (Function.update p_star j t)
    · -- Orthant condition
      intro k
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        refine ⟨fun hcontr => ?_, fun _ => le_of_lt ht_neg⟩
        rw [hsig] at hcontr; linarith
      · rw [Function.update_of_ne hk]
        exact hp_in k
    · -- Distance condition: |p k - p_star k| < ε for all k
      intro k
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        exact ht_close
      · rw [Function.update_of_ne hk]
        simp only [sub_self, abs_zero]
        exact hε_pos
  -- Apply IsLocalMin.hasDerivAt_eq_zero
  have h_zero : D1 - lambda * D2 = 0 := h_local_min.hasDerivAt_eq_zero h_phi_deriv
  -- D1 = lambda * D2
  have hD1_eq_D2 : D1 = lambda * D2 := by linarith
  -- Now translate back to the goal statement
  -- D1 = -(-(y j))^(q-1) / (lqNorm q y)^(q-1)
  -- We have y j = p_star j - f j, so -(y j) = f j - p_star j
  -- Goal: (f j - p_star j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
  --     = lambda * ((-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1))
  -- Note D1 = -((f j - p_star j))^(q-1) / (lqNorm q y)^(q-1)
  --      D2 = -(-(p_star j))^(q-1) / (lqNorm q p_star)^(q-1)
  -- So D1 = lambda * D2 means:
  --   -(f j - p_star j)^(q-1) / D₁norm = lambda * -(-(p_star j))^(q-1) / D₂norm
  -- Multiply both sides by -1:
  --   (f j - p_star j)^(q-1) / D₁norm = lambda * (-(p_star j))^(q-1) / D₂norm
  show (f j - p_star j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
      = lambda * ((-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1))
  have h_y_lq : lqNorm q y = lqNorm q (fun k => p_star k - f k) := rfl
  have h_neg_yj : -(y j) = f j - p_star j := by show -(p_star j - f j) = f j - p_star j; ring
  -- Rewrite D1 using -(y j) = f j - p_star j
  have hD1_rewrite : D1 = -((f j - p_star j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)) := by
    show -(-(y j)) ^ (q - 1) / (lqNorm q y) ^ (q - 1) = _
    rw [h_neg_yj, h_y_lq]
    ring
  -- Rewrite D2
  have hD2_rewrite : D2 = -((-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1)) := by
    show -(-(p_star j)) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1) = _
    ring
  rw [hD1_rewrite, hD2_rewrite] at hD1_eq_D2
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormBoundaryUpwardExpansion
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d) (delta : ℝ)
    (hd_nn : 0 ≤ delta) (hxj_zero : x j = 0) :
    lqNorm q (Function.update x j delta)
      = ((lqNorm q x) ^ q + delta ^ q) ^ ((1 : ℝ) / q) := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hsum_nn : (0 : ℝ) ≤ ∑ k, |x k| ^ q := sum_abs_rpow_nonneg q x
  -- Step 1: Compute (lqNorm q x)^q = ∑ k, |x k|^q
  have h_pow_lqNorm : (lqNorm q x) ^ q = ∑ k, |x k| ^ q := by
    show ((∑ k, |x k| ^ q) ^ ((1 : ℝ) / q)) ^ q = ∑ k, |x k| ^ q
    rw [← Real.rpow_mul hsum_nn, one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one]
  -- Step 2: Split the sum over Function.update using Finset.sum_update_of_mem
  have h_update_sum :
      (∑ k, |Function.update x j delta k| ^ q) = delta ^ q + ∑ k ∈ Finset.univ \ {j}, |x k| ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h_eq : (fun k => |Function.update x j delta k| ^ q) =
                Function.update (fun k => |x k| ^ q) j (|delta| ^ q) := by
      funext k
      by_cases hk : k = j
      · subst hk
        simp [Function.update_self]
      · rw [Function.update_of_ne hk, Function.update_of_ne hk]
    rw [show (∑ k, |Function.update x j delta k| ^ q) =
            ∑ k, Function.update (fun k => |x k| ^ q) j (|delta| ^ q) k from by rw [h_eq]]
    rw [Finset.sum_update_of_mem hj_mem]
    rw [abs_of_nonneg hd_nn]
  -- Step 3: ∑ k, |x k|^q = ∑ k ∈ univ \ {j}, |x k|^q (since |x j|^q = 0)
  have h_x_sum : (∑ k, |x k| ^ q) = ∑ k ∈ Finset.univ \ {j}, |x k| ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    rw [← Finset.sum_erase_add _ _ hj_mem]
    rw [hxj_zero, abs_zero, Real.zero_rpow hq_ne, add_zero]
    congr 1
    ext k
    simp [Finset.mem_erase, Finset.mem_sdiff, Finset.mem_singleton, and_comm]
  -- Step 4: combine
  have h_main_sum :
      (∑ k, |Function.update x j delta k| ^ q) = (∑ k, |x k| ^ q) + delta ^ q := by
    rw [h_update_sum, h_x_sum, add_comm]
  -- Step 5: Use h_main_sum and h_pow_lqNorm to rewrite the goal
  show ((∑ k, |Function.update x j delta k| ^ q) ^ ((1 : ℝ) / q))
        = ((lqNorm q x) ^ q + delta ^ q) ^ ((1 : ℝ) / q)
  rw [h_main_sum, h_pow_lqNorm]

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormBoundaryRightDeriv
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d)
    (hx_nn : 0 ≤ x j) (hlq_pos : 0 < lqNorm q x) :
    HasDerivWithinAt (fun t : ℝ => lqNorm q (Function.update x j t))
      ((x j) ^ (q - 1) / (lqNorm q x) ^ (q - 1)) (Set.Ici (x j)) (x j) := by
  -- Useful basic facts about q.
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_one_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hq1_pos : 0 < q - 1 := sub_pos.mpr hq
  have hq1_nonneg : (0 : ℝ) ≤ q - 1 := le_of_lt hq1_pos
  have hq1_ne : q - 1 ≠ 0 := ne_of_gt hq1_pos
  have hlq_nn : 0 ≤ lqNorm q x := le_of_lt hlq_pos
  have hlq_ne : lqNorm q x ≠ 0 := ne_of_gt hlq_pos
  -- Split on x j > 0 vs x j = 0.
  rcases lt_or_eq_of_le hx_nn with hxj_pos | hxj_zero_eq
  · -- Case x j > 0: use LqNormPartialDerivative_PosBranch.
    have h := LqNormPartialDerivative_PosBranch hq hd x j hxj_pos hlq_pos
    exact h.hasDerivWithinAt
  · -- Case 0 = x j (so x j = 0).
    have hxj0 : x j = 0 := hxj_zero_eq.symm
    -- The target derivative is 0:
    have htarget : (x j) ^ (q - 1) / (lqNorm q x) ^ (q - 1) = 0 := by
      rw [hxj0, Real.zero_rpow hq1_ne, zero_div]
    rw [htarget, hxj0]
    -- We want HasDerivWithinAt (fun t => lqNorm q (update x j t)) 0 (Set.Ici 0) 0.
    -- Define g(t) := ((lqNorm q x)^q + t^q)^(1/q). By LqNormBoundaryUpwardExpansion,
    -- on Ici 0 we have lqNorm q (update x j t) = g(t).
    set L : ℝ := lqNorm q x with hL_def
    -- L^q > 0, so the inner sum L^q + t^q > 0 for t ≥ 0.
    have hLq_pos : 0 < L ^ q := Real.rpow_pos_of_pos hlq_pos q
    have hLq_ne : L ^ q ≠ 0 := ne_of_gt hLq_pos
    -- Step A: HasDerivAt (fun t => L^q + t^q) (q * 0^(q-1)) 0.
    have h_pow_q : HasDerivAt (fun t : ℝ => t ^ q) (q * (0 : ℝ) ^ (q - 1)) 0 :=
      Real.hasDerivAt_rpow_const (Or.inr hq_one_le)
    have h_inner : HasDerivAt (fun t : ℝ => L ^ q + t ^ q) (q * (0 : ℝ) ^ (q - 1)) 0 := by
      have := h_pow_q.const_add (L ^ q)
      simpa using this
    -- Step B: simplify (q * 0^(q-1)) = 0
    have h_inner_deriv_zero : q * (0 : ℝ) ^ (q - 1) = 0 := by
      rw [Real.zero_rpow hq1_ne, mul_zero]
    rw [h_inner_deriv_zero] at h_inner
    -- Step C: Apply rpow_const at p = 1/q with f(0) = L^q ≠ 0.
    have h_outer : HasDerivAt (fun t : ℝ => (L ^ q + t ^ q) ^ ((1 : ℝ) / q))
        (0 * (1 / q) * (L ^ q + (0 : ℝ) ^ q) ^ ((1 : ℝ) / q - 1)) 0 := by
      have hbase : (fun t : ℝ => L ^ q + t ^ q) 0 ≠ 0 := by
        show L ^ q + (0 : ℝ) ^ q ≠ 0
        rw [Real.zero_rpow hq_ne, add_zero]
        exact hLq_ne
      exact h_inner.rpow_const (Or.inl hbase)
    -- Step D: simplify the derivative value to 0.
    have h_outer_deriv_zero :
        (0 : ℝ) * (1 / q) * (L ^ q + (0 : ℝ) ^ q) ^ ((1 : ℝ) / q - 1) = 0 := by
      ring
    rw [h_outer_deriv_zero] at h_outer
    -- Step E: Lift to HasDerivWithinAt on Ici 0.
    have h_outer_within : HasDerivWithinAt
        (fun t : ℝ => (L ^ q + t ^ q) ^ ((1 : ℝ) / q))
        0 (Set.Ici (0 : ℝ)) 0 := h_outer.hasDerivWithinAt
    -- Step F: Show eventually-equal in nhdsWithin 0 (Ici 0):
    -- For t ≥ 0, lqNorm q (update x j t) = (L^q + t^q)^(1/q).
    have h_eq_on : ∀ t ∈ Set.Ici (0 : ℝ),
        lqNorm q (Function.update x j t) = (L ^ q + t ^ q) ^ ((1 : ℝ) / q) := by
      intro t ht
      have ht_nn : 0 ≤ t := ht
      exact LqNormBoundaryUpwardExpansion hq hd x j t ht_nn hxj0
    -- Use HasDerivWithinAt.congr to switch from g to lqNorm.
    -- HasDerivWithinAt.congr : HasDerivWithinAt f f' s x → (∀ x ∈ s, f₁ x = f x) → f₁ x = f x → HasDerivWithinAt f₁ s x
    refine h_outer_within.congr ?_ ?_
    · intros t ht
      exact h_eq_on t ht
    · -- f₁ 0 = f 0 where f₁ = lqNorm composition, f = (L^q + t^q)^(1/q)
      exact h_eq_on 0 Set.self_mem_Ici

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem RightBoundary_ForcesC0
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (hp_pos : 0 < lqNorm q p_star)
    (j : Fin d) (hsig : sigma j = 1) (hpf_eq : p_star j = f j) (hfj_pos : 0 < f j) :
    lqNorm q (fun k => p_star k - f k) = 0 := by
  -- The proof strategy: we derive False from the hypotheses.
  -- We compute the right-derivative of t ↦ g_lambda q lambda f (Function.update p_star j t)
  -- on Ici (p_star j) at t = p_star j. It is strictly negative, contradicting
  -- the local-min hypothesis.
  exfalso
  -- Useful basic facts.
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq1_pos : 0 < q - 1 := sub_pos.mpr hq
  have hq1_ne : q - 1 ≠ 0 := ne_of_gt hq1_pos
  have hpj_pos : 0 < p_star j := by rw [hpf_eq]; exact hfj_pos
  have hpj_nn : 0 ≤ p_star j := le_of_lt hpj_pos
  -- Notation: pmf = p_star - f.
  set pmf : Fin d → ℝ := fun k => p_star k - f k with hpmf_def
  have hpmf_j_zero : pmf j = 0 := by
    simp [hpmf_def, hpf_eq]
  have hpmf_pos : 0 < lqNorm q pmf := hpf_pos
  have hpmf_nn : 0 ≤ lqNorm q pmf := le_of_lt hpmf_pos
  have hpmf_ne : lqNorm q pmf ≠ 0 := ne_of_gt hpmf_pos
  -- ============================================================
  -- Step 1: Compute right derivative of (t ↦ lqNorm q (update p_star j t - f))
  -- at t = p_star j on Ici (p_star j). Equals 0.
  -- ============================================================
  -- Use LqNormBoundaryRightDeriv on pmf at index j.
  -- That gives derivative on Ici (pmf j) = Ici 0 of t ↦ lqNorm q (update pmf j t).
  have hH : HasDerivWithinAt
      (fun s : ℝ => lqNorm q (Function.update pmf j s))
      ((pmf j) ^ (q - 1) / (lqNorm q pmf) ^ (q - 1))
      (Set.Ici (pmf j)) (pmf j) :=
    LqNormBoundaryRightDeriv hq hd pmf j (le_of_eq hpmf_j_zero.symm) hpmf_pos
  -- The derivative simplifies to 0 since pmf j = 0.
  have hH_zero : HasDerivWithinAt
      (fun s : ℝ => lqNorm q (Function.update pmf j s))
      0 (Set.Ici (0 : ℝ)) 0 := by
    have hcoef : (pmf j) ^ (q - 1) / (lqNorm q pmf) ^ (q - 1) = 0 := by
      rw [hpmf_j_zero, Real.zero_rpow hq1_ne, zero_div]
    rw [hcoef] at hH
    rw [hpmf_j_zero] at hH
    exact hH
  -- Now translate from `s` to `t = s + p_star j`, i.e. `s = t - p_star j`.
  -- The function `t ↦ lqNorm q (update p_star j t - f)` equals
  -- `t ↦ lqNorm q (update pmf j (t - p_star j))` pointwise.
  have h_update_eq : ∀ t : ℝ,
      (fun k => Function.update p_star j t k - f k) = Function.update pmf j (t - p_star j) := by
    intro t
    funext k
    by_cases hk : k = j
    · subst hk
      simp [Function.update_self, hpmf_def, hpf_eq]
    · simp [Function.update_of_ne hk, hpmf_def]
  -- Compose with the affine map `t ↦ t - p_star j` to obtain HasDerivWithinAt on Ici (p_star j).
  have h_inner : HasDerivAt (fun t : ℝ => t - p_star j) 1 (p_star j) := by
    have := (hasDerivAt_id (p_star j)).sub_const (p_star j)
    simpa using this
  -- MapsTo: t ∈ Ici (p_star j) → t - p_star j ∈ Ici 0
  have h_maps : Set.MapsTo (fun t : ℝ => t - p_star j) (Set.Ici (p_star j)) (Set.Ici (0 : ℝ)) := by
    intro t ht
    simp only [Set.mem_Ici] at ht ⊢
    linarith
  have h_inner_within : HasDerivWithinAt (fun t : ℝ => t - p_star j) 1
      (Set.Ici (p_star j)) (p_star j) := h_inner.hasDerivWithinAt
  have h_comp_at_zero : (fun t : ℝ => t - p_star j) (p_star j) = 0 := by ring
  have hG_pre : HasDerivWithinAt
      (fun t : ℝ => lqNorm q (Function.update pmf j (t - p_star j)))
      (1 * 0) (Set.Ici (p_star j)) (p_star j) := by
    have hH_at : HasDerivWithinAt
        (fun s : ℝ => lqNorm q (Function.update pmf j s))
        0 (Set.Ici (0 : ℝ)) ((fun t : ℝ => t - p_star j) (p_star j)) := by
      rw [h_comp_at_zero]
      exact hH_zero
    have := HasDerivWithinAt.scomp (x := p_star j)
      (g₁ := fun s : ℝ => lqNorm q (Function.update pmf j s))
      (h := fun t : ℝ => t - p_star j)
      (g₁' := (0 : ℝ)) (h' := (1 : ℝ))
      (t' := Set.Ici (0 : ℝ)) (s := Set.Ici (p_star j))
      hH_at h_inner_within h_maps
    -- this : HasDerivWithinAt (g₁ ∘ h) (h' • g₁') s x
    -- which is: HasDerivWithinAt (fun t => lqNorm q (update pmf j (t - p_star j))) (1 • 0) (Ici (p_star j)) (p_star j)
    convert this using 1
  have hG : HasDerivWithinAt
      (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
      0 (Set.Ici (p_star j)) (p_star j) := by
    have h_eq_fun : (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
        = fun t : ℝ => lqNorm q (Function.update pmf j (t - p_star j)) := by
      funext t
      rw [h_update_eq t]
    rw [h_eq_fun]
    have : (1 : ℝ) * 0 = 0 := by ring
    rw [← this]
    exact hG_pre
  -- ============================================================
  -- Step 2: Compute derivative of (t ↦ lqNorm q (update p_star j t)) at t = p_star j.
  -- Equals (p_star j)^(q-1) / (lqNorm q p_star)^(q-1) > 0.
  -- ============================================================
  have hP : HasDerivAt
      (fun t : ℝ => lqNorm q (Function.update p_star j t))
      ((p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1))
      (p_star j) :=
    LqNormPartialDerivative_PosBranch hq hd p_star j hpj_pos hp_pos
  set deriv_p : ℝ := (p_star j) ^ (q - 1) / (lqNorm q p_star) ^ (q - 1) with hdp_def
  have hdp_pos : 0 < deriv_p := by
    rw [hdp_def]
    apply div_pos
    · exact Real.rpow_pos_of_pos hpj_pos _
    · exact Real.rpow_pos_of_pos hp_pos _
  -- Lift hP to HasDerivWithinAt on Ici (p_star j).
  have hP_within : HasDerivWithinAt
      (fun t : ℝ => lqNorm q (Function.update p_star j t))
      deriv_p (Set.Ici (p_star j)) (p_star j) := hP.hasDerivWithinAt
  -- ============================================================
  -- Step 3: Compute right derivative of g_lambda(update p_star j t) at p_star j.
  -- ============================================================
  -- g_lambda q lambda f p = lqNorm q (p - f) - lambda * lqNorm q p
  -- Right deriv = (deriv of first) - lambda * (deriv of second) = 0 - lambda * deriv_p
  -- = -lambda * deriv_p < 0.
  have hP_within_smul : HasDerivWithinAt
      (fun t : ℝ => lambda * lqNorm q (Function.update p_star j t))
      (lambda * deriv_p) (Set.Ici (p_star j)) (p_star j) :=
    hP_within.const_mul lambda
  have hG_total : HasDerivWithinAt
      (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t))
      (0 - lambda * deriv_p) (Set.Ici (p_star j)) (p_star j) := by
    -- g_lambda q lambda f (update p_star j t) = lqNorm q (update p_star j t - f) - lambda * lqNorm q (update p_star j t)
    have h_eq : (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t))
        = fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k)
                      - lambda * lqNorm q (Function.update p_star j t) := by
      funext t
      simp [g_lambda]
    rw [h_eq]
    exact hG.sub hP_within_smul
  -- The derivative is strictly negative.
  set D : ℝ := 0 - lambda * deriv_p with hD_def
  have hD_neg : D < 0 := by
    rw [hD_def, zero_sub]
    apply neg_neg_iff_pos.mpr
    exact mul_pos hlam0 hdp_pos
  -- ============================================================
  -- Step 4: Use HasDerivWithinAt.liminf_right_slope_le to find a point z > p_star j
  -- arbitrarily close, with slope < 0.
  -- ============================================================
  have h_freq : ∃ᶠ z in (nhdsWithin (p_star j) (Set.Ioi (p_star j))),
      slope (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) z < 0 :=
    hG_total.liminf_right_slope_le hD_neg
  -- ============================================================
  -- Step 5: Pull a specific z out of the frequently filter.
  -- The local-min radius gives ε > 0.
  -- ============================================================
  obtain ⟨ε, hε_pos, hε_loc⟩ := hp_loc
  -- We want z ∈ (p_star j, p_star j + ε), with slope < 0.
  -- Build a neighborhood: (p_star j, p_star j + ε) is a punctured-right neighborhood.
  have h_nbhd : Set.Ioo (p_star j) (p_star j + ε) ∈ (nhdsWithin (p_star j) (Set.Ioi (p_star j))) := by
    rw [mem_nhdsWithin]
    refine ⟨Set.Iio (p_star j + ε), isOpen_Iio, ?_, ?_⟩
    · show p_star j < p_star j + ε
      linarith
    · intro x hx
      simp only [Set.mem_inter_iff, Set.mem_Iio, Set.mem_Ioi, Set.mem_Ioo] at hx ⊢
      exact ⟨hx.2, hx.1⟩
  -- Combine the frequently-witness with the neighborhood.
  have h_freq_strong : ∃ᶠ z in (nhdsWithin (p_star j) (Set.Ioi (p_star j))),
      z ∈ Set.Ioo (p_star j) (p_star j + ε) ∧
      slope (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) z < 0 :=
    (Filter.eventually_of_mem h_nbhd (fun _ h => h)).and_frequently h_freq
  -- Extract one such z.
  obtain ⟨z, ⟨hz_lo, hz_hi⟩, h_slope⟩ := h_freq_strong.exists
  have hz_gt : p_star j < z := hz_lo
  have hz_close : z < p_star j + ε := hz_hi
  -- ============================================================
  -- Step 6: Show update_p_star_j_z is in the orthant and within ε.
  -- ============================================================
  set tildep : Fin d → ℝ := Function.update p_star j z with htildep_def
  have htildep_at_j : tildep j = z := by simp [htildep_def, Function.update_self]
  have htildep_off_j : ∀ k : Fin d, k ≠ j → tildep k = p_star k := by
    intro k hk
    simp [htildep_def, Function.update_of_ne hk]
  have hz_pos : 0 < z := lt_trans hpj_pos hz_gt
  have hz_nn : 0 ≤ z := le_of_lt hz_pos
  -- tildep is in the orthant.
  have htildep_in : ∀ k, (sigma k = 1 → 0 ≤ tildep k) ∧ (sigma k = -1 → tildep k ≤ 0) := by
    intro k
    by_cases hk : k = j
    · subst hk
      refine ⟨fun _ => ?_, fun hsig_neg => ?_⟩
      · rw [htildep_at_j]; exact hz_nn
      · exfalso; rw [hsig] at hsig_neg; linarith
    · rw [htildep_off_j k hk]
      exact hp_in k
  -- |tildep k - p_star k| < ε for all k.
  have htildep_close : ∀ k, |tildep k - p_star k| < ε := by
    intro k
    by_cases hk : k = j
    · subst hk
      rw [htildep_at_j]
      have hzk_pos : 0 < z - p_star k := by linarith
      rw [abs_of_pos hzk_pos]
      linarith
    · rw [htildep_off_j k hk]
      have : p_star k - p_star k = 0 := by ring
      rw [this, abs_zero]
      exact hε_pos
  -- ============================================================
  -- Step 7: From local-min hypothesis: g_lambda(p_star) ≤ g_lambda(tildep).
  -- ============================================================
  have hg_le : g_lambda q lambda f p_star ≤ g_lambda q lambda f tildep :=
    hε_loc tildep htildep_in htildep_close
  -- Note: tildep = update p_star j z, and at j: p_star = update p_star j (p_star j).
  -- So slope (fun t => g_lambda(update p_star j t)) (p_star j) z =
  --        (g_lambda(update p_star j z) - g_lambda(update p_star j (p_star j))) / (z - p_star j)
  --      = (g_lambda(tildep) - g_lambda(p_star)) / (z - p_star j) ≥ 0
  -- This contradicts slope < 0.
  have h_update_pstar : Function.update p_star j (p_star j) = p_star := by
    funext k
    by_cases hk : k = j
    · subst hk; simp [Function.update_self]
    · simp [Function.update_of_ne hk]
  have h_slope_eq :
      slope (fun t : ℝ => g_lambda q lambda f (Function.update p_star j t)) (p_star j) z
        = (z - p_star j)⁻¹ * (g_lambda q lambda f tildep - g_lambda q lambda f p_star) := by
    unfold slope
    simp only [vsub_eq_sub, smul_eq_mul]
    rw [h_update_pstar]
  rw [h_slope_eq] at h_slope
  have hz_diff_pos : 0 < z - p_star j := by linarith
  have hz_inv_pos : 0 < (z - p_star j)⁻¹ := inv_pos.mpr hz_diff_pos
  have h_sub_nn : 0 ≤ g_lambda q lambda f tildep - g_lambda q lambda f p_star := by linarith
  have h_prod_nn : 0 ≤ (z - p_star j)⁻¹ * (g_lambda q lambda f tildep - g_lambda q lambda f p_star) :=
    mul_nonneg (le_of_lt hz_inv_pos) h_sub_nn
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm

theorem LqNormPartialDerivative_PosBranch_LimitAtZero
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x f : Fin d → ℝ) (j : Fin d)
    (hxj_zero : x j = 0) (hfj_pos : 0 < f j) (hf_nn : ∀ k, 0 ≤ f k)
    (hlq_pos : 0 < lqNorm q (fun k => x k - f k)) :
    HasDerivWithinAt
      (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k))
      (-(f j) ^ (q - 1) / (lqNorm q (fun k => x k - f k)) ^ (q - 1))
      (Set.Ici (0 : ℝ)) 0 := by
  -- Setup basic facts
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hfj_ne : f j ≠ 0 := ne_of_gt hfj_pos
  have h_lqq_ne : lqNorm q (fun k => x k - f k) ≠ 0 := ne_of_gt hlq_pos
  have h_lqq_nonneg : 0 ≤ lqNorm q (fun k => x k - f k) := le_of_lt hlq_pos
  -- Define the constant part A = ∑_{k≠j} |x k - f k|^q
  set A : ℝ := ∑ k ∈ Finset.univ.erase j, |x k - f k| ^ q with hA_def
  -- The total sum equals A + (f j)^q (using x j = 0 and f j > 0, so |x j - f j| = |-f j| = f j)
  have h_total_sum : (∑ k, |x k - f k| ^ q) = A + (f j) ^ q := by
    have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
    have h1 : (∑ k, |x k - f k| ^ q) = ∑ k ∈ Finset.univ.erase j, |x k - f k| ^ q
                + |x j - f j| ^ q := by
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
            (fun k => |x k - f k| ^ q) hj_mem]
    rw [h1, hxj_zero, zero_sub, abs_neg, abs_of_pos hfj_pos]
  -- (lqNorm q (x - f))^q = A + (f j)^q
  have h_lqNorm_q_eq : (lqNorm q (fun k => x k - f k)) ^ q = ∑ k, |x k - f k| ^ q := by
    unfold lqNorm
    rw [← Real.rpow_mul (sum_abs_rpow_nonneg q _), one_div_mul_cancel hq_ne, Real.rpow_one]
  have h_inner_eq : A + (f j) ^ q = (lqNorm q (fun k => x k - f k)) ^ q := by
    rw [← h_total_sum, ← h_lqNorm_q_eq]
  have h_inner_pos : 0 < A + (f j) ^ q := by
    rw [h_inner_eq]
    exact Real.rpow_pos_of_pos hlq_pos q
  have h_inner_ne : A + (f j) ^ q ≠ 0 := ne_of_gt h_inner_pos
  -- Local equality on a nhdsWithin (Set.Ici 0) 0:
  -- for t ∈ [0, f j), the lqNorm equals (A + (f j - t)^q)^(1/q)
  have h_eq_local :
      (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k)) =ᶠ[nhdsWithin 0 (Set.Ici (0 : ℝ))]
      (fun t : ℝ => (A + (f j - t) ^ q) ^ ((1 : ℝ) / q)) := by
    -- We use the characterization: ∀ᶠ in nhdsWithin a s ↔ ∀ᶠ in nhds a, x ∈ s → p x.
    rw [Filter.eventuallyEq_iff_exists_mem]
    refine ⟨Set.Iio (f j), ?_, ?_⟩
    · -- Set.Iio (f j) ∈ nhdsWithin 0 (Set.Ici 0): just need it to be in nhds 0.
      apply mem_nhdsWithin_of_mem_nhds
      exact Iio_mem_nhds hfj_pos
    · -- For t ∈ Iio (f j), the equality holds.
      intro t ht_lt
      have ht_lt' : t < f j := ht_lt
      show lqNorm q (fun k => Function.update x j t k - f k)
        = (A + (f j - t) ^ q) ^ ((1 : ℝ) / q)
      unfold lqNorm
      congr 1
      have hj_mem : j ∈ (Finset.univ : Finset (Fin d)) := Finset.mem_univ j
      rw [← Finset.sum_erase_add (Finset.univ : Finset (Fin d))
            (fun k => |Function.update x j t k - f k| ^ q) hj_mem]
      rw [Function.update_self]
      -- Now |t - f j|^q = (f j - t)^q since t - f j < 0
      have h_neg : t - f j < 0 := by linarith
      have h_abs : |t - f j| = f j - t := by
        rw [abs_of_neg h_neg]; ring
      rw [h_abs]
      -- Sum over k ≠ j is unchanged because Function.update at k ≠ j equals x k.
      have h_sum_eq : (∑ k ∈ Finset.univ.erase j,
            |Function.update x j t k - f k| ^ q) = A := by
        apply Finset.sum_congr rfl
        intro k hk
        have hkj : k ≠ j := Finset.ne_of_mem_erase hk
        rw [Function.update_of_ne hkj]
      rw [h_sum_eq]
  -- Compute derivative at 0 of t ↦ A + (f j - t)^q within Set.Ici 0
  -- Step 1: HasDerivAt of t ↦ f j - t at 0 with derivative -1
  have h_sub : HasDerivAt (fun t : ℝ => f j - t) (-1) 0 := by
    have h1 : HasDerivAt (fun t : ℝ => t) 1 0 := hasDerivAt_id 0
    exact h1.const_sub (f j)
  -- Step 2: HasDerivAt of t ↦ (f j - t)^q at 0
  -- Apply rpow_const: HasDerivAt.rpow_const requires h_sub.x ≠ 0 ∨ 1 ≤ q. Since f j ≠ 0 (h_sub at 0 is f j - 0 = f j).
  have h_sub_at_zero : (fun t : ℝ => f j - t) 0 = f j := by simp
  have h_pow : HasDerivAt (fun t : ℝ => (f j - t) ^ q)
      (-1 * q * (f j) ^ (q - 1)) 0 := by
    have h_ne0 : (fun t : ℝ => f j - t) 0 ≠ 0 := by simp [hfj_ne]
    have h := HasDerivAt.rpow_const (p := q) h_sub (Or.inl h_ne0)
    -- h : HasDerivAt (fun y => (f j - y)^q) (-1 * q * (f j - 0)^(q-1)) 0
    have h_simp : (f j - (0 : ℝ)) = f j := by ring
    rw [h_simp] at h
    exact h
  -- Step 3: HasDerivAt of t ↦ A + (f j - t)^q at 0
  have h_A_add : HasDerivAt (fun t : ℝ => A + (f j - t) ^ q)
      (-1 * q * (f j) ^ (q - 1)) 0 := by
    have := h_pow.const_add A
    simpa using this
  -- Step 4: HasDerivAt of t ↦ (A + (f j - t)^q)^(1/q) at 0
  have h_outer : HasDerivAt (fun t : ℝ => (A + (f j - t) ^ q) ^ ((1 : ℝ) / q))
      (-1 * q * (f j) ^ (q - 1) * ((1 : ℝ) / q) *
        (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q - 1)) 0 := by
    have h_at_zero : (fun t : ℝ => A + (f j - t) ^ q) 0 = A + (f j) ^ q := by
      simp
    have h_ne : (fun t : ℝ => A + (f j - t) ^ q) 0 ≠ 0 := by
      rw [h_at_zero]; exact h_inner_ne
    have h := HasDerivAt.rpow_const (p := (1 : ℝ) / q) h_A_add (Or.inl h_ne)
    convert h using 1
  -- Convert HasDerivAt to HasDerivWithinAt
  have h_outer_within : HasDerivWithinAt (fun t : ℝ => (A + (f j - t) ^ q) ^ ((1 : ℝ) / q))
      (-1 * q * (f j) ^ (q - 1) * ((1 : ℝ) / q) *
        (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q - 1)) (Set.Ici (0 : ℝ)) 0 :=
    h_outer.hasDerivWithinAt
  -- Use HasDerivWithinAt.congr_of_eventuallyEq:
  -- HasDerivWithinAt f f' s x → f₁ =ᶠ[nhdsWithin x s] f → f₁ x = f x → HasDerivWithinAt f₁ f' s x
  -- We have HasDerivWithinAt of rpow_form (=: f), and h_eq_local says lqNorm_form =ᶠ rpow_form.
  -- So passing h_eq_local makes lqNorm_form play the role of f₁, and we get HasDerivWithinAt lqNorm_form.
  have h_pointwise : (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k)) 0
      = (fun t : ℝ => (A + (f j - t) ^ q) ^ ((1 : ℝ) / q)) 0 := by
    -- At t = 0, Function.update x j 0 = x (since x j = 0).
    have h_upd : Function.update x j (0 : ℝ) = x := by
      ext k
      by_cases hk : k = j
      · subst hk; rw [Function.update_self, hxj_zero]
      · rw [Function.update_of_ne hk]
    show lqNorm q (fun k => Function.update x j 0 k - f k)
        = (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q)
    rw [show (fun k => Function.update x j 0 k - f k) = (fun k => x k - f k) by
          ext k; rw [h_upd]]
    -- now lqNorm q (x - f) = (A + (f j)^q)^(1/q)
    show lqNorm q (fun k => x k - f k) = (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q)
    have : (A + (f j - 0) ^ q) = (lqNorm q (fun k => x k - f k)) ^ q := by
      have : f j - 0 = f j := by ring
      rw [this, h_inner_eq]
    rw [this]
    -- Goal: lqNorm q (x - f) = ((lqNorm q (x - f))^q)^(1/q)
    rw [← Real.rpow_mul h_lqq_nonneg, mul_one_div, div_self hq_ne, Real.rpow_one]
  have h_target : HasDerivWithinAt (fun t : ℝ => lqNorm q (fun k => Function.update x j t k - f k))
      (-1 * q * (f j) ^ (q - 1) * ((1 : ℝ) / q) *
        (A + (f j - 0) ^ q) ^ ((1 : ℝ) / q - 1)) (Set.Ici (0 : ℝ)) 0 :=
    h_outer_within.congr_of_eventuallyEq h_eq_local h_pointwise
  -- Now show the derivative value matches the goal:
  -- -1 * q * (f j)^(q-1) * (1/q) * (A + (f j)^q)^(1/q - 1) = -(f j)^(q-1) / (lqNorm q (x - f))^(q-1)
  convert h_target using 1
  -- Goal: -(f j)^(q-1) / (lqNorm q (x - f))^(q-1)
  --     = -1 * q * (f j)^(q-1) * (1/q) * (A + (f j - 0)^q)^(1/q - 1)
  have h_fj0 : f j - 0 = f j := by ring
  rw [h_fj0]
  rw [h_inner_eq]
  -- Now: ... = -1 * q * (f j)^(q-1) * (1/q) * ((lqNorm q (x - f))^q)^(1/q - 1)
  -- Simplify: q * (1/q) = 1, so: -1 * (f j)^(q-1) * ((lqNorm q (x - f))^q)^(1/q - 1)
  have h_q_simp : (-1 : ℝ) * q * (f j) ^ (q - 1) * ((1 : ℝ) / q)
      = -((f j) ^ (q - 1)) := by
    field_simp
  -- Reorganize the RHS
  have h_pow_simp : ((lqNorm q (fun k => x k - f k)) ^ q) ^ ((1 : ℝ) / q - 1)
      = (lqNorm q (fun k => x k - f k)) ^ (1 - q) := by
    rw [← Real.rpow_mul h_lqq_nonneg]
    congr 1
    field_simp
  have h_neg_pow : (lqNorm q (fun k => x k - f k)) ^ (1 - q)
      = ((lqNorm q (fun k => x k - f k)) ^ (q - 1))⁻¹ := by
    have heq : (1 - q) = -(q - 1) := by ring
    rw [heq, Real.rpow_neg h_lqq_nonneg]
  -- Algebraic manipulation
  rw [show (-1 : ℝ) * q * (f j) ^ (q - 1) * ((1 : ℝ) / q) *
        ((lqNorm q (fun k => x k - f k)) ^ q) ^ ((1 : ℝ) / q - 1)
       = ((-1 : ℝ) * q * (f j) ^ (q - 1) * ((1 : ℝ) / q)) *
         ((lqNorm q (fun k => x k - f k)) ^ q) ^ ((1 : ℝ) / q - 1) by ring]
  rw [h_q_simp, h_pow_simp, h_neg_pow]
  -- Goal: -(f j)^(q-1) / (lqNorm q (x - f))^(q-1) = -((f j)^(q-1)) * ((lqNorm q (x - f))^(q-1))⁻¹
  rw [div_eq_mul_inv, neg_mul]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

/-- **Left boundary forces `f j = 0` (positive branch).**

Under the same hypotheses as `Claim1_RuleOutInterior`, with the
additional assumption that `lqNorm q (p_star - f) > 0`, every index `j`
with `σ j = +1` and `p_star j = 0` satisfies `f j = 0`.

Paper reference: Block 3, Step 3.6 (companion to `RightBoundary_ForcesC0`)
of Gravin & Jia, *Approximation guarantees of Median Mechanism in ℝ^d*,
arXiv:2502.08578v2. -/
theorem LeftBoundary_ForcesFjZero
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (j : Fin d) (hsig : sigma j = 1) (hpz : p_star j = 0) :
    f j = 0 := by
  classical
  -- Basic facts about q.
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq1_pos : 0 < q - 1 := sub_pos.mpr hq
  have hq1_nn : (0 : ℝ) ≤ q - 1 := le_of_lt hq1_pos
  -- f j is non-negative.
  have hfj_nn : 0 ≤ f j := hf_nn j
  -- Try to derive a contradiction from f j > 0.
  by_contra hfj_ne
  have hfj_pos : 0 < f j := lt_of_le_of_ne hfj_nn (Ne.symm hfj_ne)
  -- Extract the local-min ε from hp_loc.
  obtain ⟨ε, hε_pos, hε_loc⟩ := hp_loc
  -- Set up the abbreviation L = lqNorm q (p_star - f).
  set L : ℝ := lqNorm q (fun k => p_star k - f k) with hL_def
  have hL_pos : 0 < L := hpf_pos
  have hL_nn : 0 ≤ L := le_of_lt hL_pos
  have hL_ne : L ≠ 0 := ne_of_gt hL_pos
  -- The first-term derivative.
  have h_deriv_first :
      HasDerivWithinAt
        (fun t : ℝ => lqNorm q (fun k => Function.update p_star j t k - f k))
        (-(f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1))
        (Set.Ici (0 : ℝ)) 0 :=
    LqNormPartialDerivative_PosBranch_LimitAtZero hq hd p_star f j hpz hfj_pos hf_nn hpf_pos
  -- Define D₁ as that derivative; show D₁ < 0.
  set D₁ : ℝ := -(f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1) with hD₁_def
  have hLpow_pos : 0 < L ^ (q - 1) := Real.rpow_pos_of_pos hL_pos _
  have hfjpow_pos : 0 < (f j) ^ (q - 1) := Real.rpow_pos_of_pos hfj_pos _
  have hD₁_neg : D₁ < 0 := by
    rw [hD₁_def]
    show -(f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1) < 0
    rw [show -(f j) ^ (q - 1) / (lqNorm q (fun k => p_star k - f k)) ^ (q - 1)
          = -((f j) ^ (q - 1) / L ^ (q - 1)) by rw [hL_def]; ring]
    have hpos : 0 < (f j) ^ (q - 1) / L ^ (q - 1) := div_pos hfjpow_pos hLpow_pos
    linarith
  -- Use HasDerivWithinAt.liminf_right_slope_le with r = D₁/2 > D₁ to find a small z>0
  -- for which the slope is < D₁/2.
  -- First, set the function name explicitly.
  set F : ℝ → ℝ := fun t => lqNorm q (fun k => Function.update p_star j t k - f k) with hF_def
  have h_deriv_first' :
      HasDerivWithinAt F D₁ (Set.Ici (0 : ℝ)) 0 := h_deriv_first
  -- D₁/2 is strictly between D₁ and 0.
  have hD₁_half_lt_zero : D₁ / 2 < 0 := by linarith
  have hD₁_lt_half : D₁ < D₁ / 2 := by linarith
  -- Frequently in 𝓝[>] 0, slope F 0 z < D₁/2.
  have h_freq : ∃ᶠ z in nhdsWithin 0 (Set.Ioi (0 : ℝ)), slope F 0 z < D₁ / 2 :=
    h_deriv_first'.liminf_right_slope_le hD₁_lt_half
  -- We also need z to lie in the open interval where the local-min and t<ε hold:
  -- specifically z ∈ (0, ε) suffices.
  have h_in_nhds : Set.Ioo (0 : ℝ) ε ∈ nhdsWithin (0 : ℝ) (Set.Ioi 0) := by
    rw [mem_nhdsWithin]
    refine ⟨Set.Iio ε, isOpen_Iio, hε_pos, ?_⟩
    intro x hx
    refine ⟨hx.2, hx.1⟩
  -- Combine the frequently and the eventually-membership of (0, ε) to extract a witness.
  have h_witness : ∃ z ∈ Set.Ioo (0 : ℝ) ε, slope F 0 z < D₁ / 2 := by
    -- Filter.Frequently.exists from h_freq filtered by the eventually predicate.
    have := h_freq.and_eventually (Filter.Eventually.of_forall (p := fun z => True) (fun _ => trivial))
    have h_freq' : ∃ᶠ z in nhdsWithin 0 (Set.Ioi (0 : ℝ)),
        z ∈ Set.Ioo (0 : ℝ) ε ∧ slope F 0 z < D₁ / 2 := by
      have hev : ∀ᶠ z in nhdsWithin 0 (Set.Ioi (0 : ℝ)), z ∈ Set.Ioo (0 : ℝ) ε := h_in_nhds
      exact h_freq.and_eventually hev |>.mp (Filter.Eventually.of_forall (fun z hz => ⟨hz.2, hz.1⟩))
    rcases h_freq'.exists with ⟨z, hz⟩
    exact ⟨z, hz.1, hz.2⟩
  -- Unpack the witness.
  obtain ⟨z, hz_mem, hz_slope⟩ := h_witness
  obtain ⟨hz_pos, hz_lt_ε⟩ := hz_mem
  -- The slope is (F z - F 0) / z.
  have h_slope_eq : slope F 0 z = (F z - F 0) / z := by
    rw [slope_def_field]
    rw [sub_zero]
  rw [h_slope_eq] at hz_slope
  have hz_ne : z ≠ 0 := ne_of_gt hz_pos
  -- From slope < D₁/2 and z > 0: F z - F 0 < (D₁/2) * z.
  have h_F_diff_lt : F z - F 0 < (D₁ / 2) * z := by
    have := (div_lt_iff₀ hz_pos).mp hz_slope
    linarith
  -- Now compute: F 0 = lqNorm q (p_star - f) = L; F z = lqNorm q (update p_star j z - f).
  have hF0 : F 0 = L := by
    show lqNorm q (fun k => Function.update p_star j 0 k - f k) = L
    have h_upd : Function.update p_star j (0 : ℝ) = p_star := by
      ext k
      by_cases hk : k = j
      · subst hk; rw [Function.update_self, hpz]
      · rw [Function.update_of_ne hk]
    rw [show (fun k => Function.update p_star j 0 k - f k) = (fun k => p_star k - f k) by
          ext k; rw [h_upd]]
  -- Now we control the second term: lqNorm q (update p_star j z) ≥ lqNorm q p_star.
  -- Apply LqNormBoundaryUpwardExpansion with x := p_star, j, delta := z.
  have hz_nn : 0 ≤ z := le_of_lt hz_pos
  have h_expand : lqNorm q (Function.update p_star j z)
      = ((lqNorm q p_star) ^ q + z ^ q) ^ ((1 : ℝ) / q) :=
    LqNormBoundaryUpwardExpansion hq hd p_star j z hz_nn hpz
  -- Show lqNorm q (update p_star j z) ≥ lqNorm q p_star.
  have h_lq_pstar_nn : 0 ≤ lqNorm q p_star := lqNorm_nonneg' q p_star
  have h_lq_mono : lqNorm q p_star ≤ lqNorm q (Function.update p_star j z) := by
    rw [h_expand]
    have h_zq_nn : 0 ≤ z ^ q := Real.rpow_nonneg hz_nn q
    have h_lqq_nn : 0 ≤ (lqNorm q p_star) ^ q := Real.rpow_nonneg h_lq_pstar_nn q
    have h_le : (lqNorm q p_star) ^ q ≤ (lqNorm q p_star) ^ q + z ^ q := by linarith
    have h_inv_nn : (0 : ℝ) ≤ (1 : ℝ) / q := by positivity
    have h1 : ((lqNorm q p_star) ^ q) ^ ((1 : ℝ) / q)
        ≤ ((lqNorm q p_star) ^ q + z ^ q) ^ ((1 : ℝ) / q) :=
      Real.rpow_le_rpow h_lqq_nn h_le h_inv_nn
    have h2 : ((lqNorm q p_star) ^ q) ^ ((1 : ℝ) / q) = lqNorm q p_star := by
      rw [← Real.rpow_mul h_lq_pstar_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
    linarith [h2]
  -- Now use the local minimum: g_lambda p_star ≤ g_lambda (update p_star j z).
  -- Build the constraint hypothesis for hε_loc.
  have h_orth : ∀ k, (sigma k = 1 → 0 ≤ Function.update p_star j z k) ∧
                     (sigma k = -1 → Function.update p_star j z k ≤ 0) := by
    intro k
    refine ⟨?_, ?_⟩
    · intro hsk
      by_cases hk : k = j
      · subst hk
        rw [Function.update_self]
        exact hz_nn
      · rw [Function.update_of_ne hk]
        exact (hp_in k).1 hsk
    · intro hsk
      by_cases hk : k = j
      · subst hk
        -- sigma j = -1 contradicts hsig : sigma j = 1
        rw [hsig] at hsk; linarith
      · rw [Function.update_of_ne hk]
        exact (hp_in k).2 hsk
  -- ε-closeness condition.
  have h_close : ∀ k, |Function.update p_star j z k - p_star k| < ε := by
    intro k
    by_cases hk : k = j
    · subst hk
      rw [Function.update_self, hpz, sub_zero, abs_of_pos hz_pos]
      exact hz_lt_ε
    · rw [Function.update_of_ne hk, sub_self, abs_zero]
      exact hε_pos
  -- Apply the local-min property.
  have h_g_le := hε_loc (Function.update p_star j z) h_orth h_close
  -- Now we want to derive a contradiction.
  -- g_lambda f p_star = L - λ * lqNorm q p_star
  -- g_lambda f (update p_star j z) = F z - λ * lqNorm q (update p_star j z)
  -- h_g_le: L - λ*A ≤ F z - λ*B, where A = lqNorm q p_star, B = lqNorm q (update p_star j z).
  -- h_lq_mono: A ≤ B → -λ*B ≤ -λ*A → ... So we have F z ≥ L + λ*(B - A) ≥ L.
  -- But h_F_diff_lt: F z < L + (D₁/2) * z, with (D₁/2)*z < 0, so F z < L. Contradiction.
  have h_lambda_ineq : -lambda * lqNorm q (Function.update p_star j z) ≤
      -lambda * lqNorm q p_star := by
    have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
    have := mul_le_mul_of_nonneg_left h_lq_mono hlam_nn
    linarith
  -- Unfold g_lambda.
  have h_g_unfold : g_lambda q lambda f p_star ≤ g_lambda q lambda f (Function.update p_star j z) :=
    h_g_le
  -- Recall g_lambda q lambda f p = lqNorm q (p - f) - lambda * lqNorm q p
  have h_g_p_star : g_lambda q lambda f p_star = L - lambda * lqNorm q p_star := by
    show lqNorm q (fun k => p_star k - f k) - lambda * lqNorm q p_star = L - lambda * lqNorm q p_star
    rfl
  have h_g_update : g_lambda q lambda f (Function.update p_star j z)
      = F z - lambda * lqNorm q (Function.update p_star j z) := by
    show lqNorm q (fun k => Function.update p_star j z k - f k) - lambda * lqNorm q (Function.update p_star j z)
        = F z - lambda * lqNorm q (Function.update p_star j z)
    rfl
  rw [h_g_p_star, h_g_update] at h_g_unfold
  -- Now: L - λ * lqNorm q p_star ≤ F z - λ * lqNorm q (Function.update p_star j z)
  -- With h_lq_mono: λ * lqNorm q p_star ≤ λ * lqNorm q (Function.update p_star j z).
  have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
  have h_lq_lam_mono : lambda * lqNorm q p_star ≤ lambda * lqNorm q (Function.update p_star j z) :=
    mul_le_mul_of_nonneg_left h_lq_mono hlam_nn
  -- From h_g_unfold and h_lq_lam_mono: L ≤ F z + (λ * lqNorm q p_star - λ * lqNorm q (update))
  -- Wait, let's just rearrange.
  -- L - λ*A ≤ F z - λ*B
  -- L ≤ F z - λ*B + λ*A = F z - λ*(B - A) ≤ F z (since B ≥ A and λ > 0)
  have h_L_le_Fz : L ≤ F z := by
    have hsub : 0 ≤ lambda * lqNorm q (Function.update p_star j z) - lambda * lqNorm q p_star := by
      linarith
    linarith
  -- But h_F_diff_lt: F z - L < (D₁/2) * z, and (D₁/2) * z < 0 (since z > 0 and D₁/2 < 0).
  have hD₁_half_z_neg : (D₁ / 2) * z < 0 := by
    exact mul_neg_of_neg_of_pos hD₁_half_lt_zero hz_pos
  have h_Fz_lt_L : F z < L := by
    have : F z - L < 0 := by
      have := h_F_diff_lt
      rw [hF0] at this
      linarith
    linarith
  -- Contradiction.
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

/-- **Sign Incompatibility lemma.**

Under the same hypotheses as `Claim1_RuleOutInterior`, with
`lqNorm q (p_star - f) > 0` and `lqNorm q p_star > 0`, the following two
conditions cannot both hold simultaneously:

* (P) there exists `j` with `σ j = +1`, `p_star j ≥ f j`, and `f j > 0`;
* (N) there exists `i` with `σ i = -1`, `p_star i < 0`, and `f i > 0`.

Paper reference: `approx.tex` lines 103–106; Block 4, Steps 4.1–4.3
(Gravin & Jia, *Approximation guarantees of Median Mechanism in ℝ^d*,
arXiv:2502.08578v2). -/
theorem SignIncompatibility
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma j = 1 → 0 ≤ p_star j) ∧ (sigma j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (hpf_pos : 0 < lqNorm q (fun k => p_star k - f k))
    (hp_pos : 0 < lqNorm q p_star) :
    ¬ ((∃ j : Fin d, sigma j = 1 ∧ f j ≤ p_star j ∧ 0 < f j) ∧
       (∃ i : Fin d, sigma i = -1 ∧ p_star i < 0 ∧ 0 < f i)) := by
  -- Take the assumption and break it down
  intro ⟨⟨j, hsig_j, hfj_le, hfj_pos⟩, ⟨i, hsig_i, hpi_neg, hfi_pos⟩⟩
  -- Notation
  have hq1 : 0 < q - 1 := by linarith
  have hN_pos : 0 < lqNorm q (fun k => p_star k - f k) := hpf_pos
  have hM_pos : 0 < lqNorm q p_star := hp_pos
  have hNqm1_pos : 0 < (lqNorm q (fun k => p_star k - f k)) ^ (q - 1) :=
    Real.rpow_pos_of_pos hN_pos _
  have hMqm1_pos : 0 < (lqNorm q p_star) ^ (q - 1) :=
    Real.rpow_pos_of_pos hM_pos _
  have hNqm1_ne : (lqNorm q (fun k => p_star k - f k)) ^ (q - 1) ≠ 0 := ne_of_gt hNqm1_pos
  have hMqm1_ne : (lqNorm q p_star) ^ (q - 1) ≠ 0 := ne_of_gt hMqm1_pos
  -- p_star j ≥ 0 from orthant
  have hpj_nn : 0 ≤ p_star j := (hp_in j).1 hsig_j
  -- p_star j ≥ f j > 0
  have hpj_pos : 0 < p_star j := lt_of_lt_of_le hfj_pos hfj_le
  -- Case split on whether f j = p_star j or f j < p_star j
  rcases lt_or_eq_of_le hfj_le with hfj_lt | hfj_eq
  · -- Case A: f j < p_star j (interior)
    -- Apply InteriorFOC_Pos
    have h_pos := InteriorFOC_Pos q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
      sigma hsigma_pm p_star hp_in hp_loc hpf_pos hp_pos j hsig_j hfj_lt
    -- Apply InteriorFOC_Neg
    have h_neg := InteriorFOC_Neg q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
      sigma hsigma_pm p_star hp_in hp_loc hpf_pos hp_pos i hsig_i hpi_neg
    -- Positive branch: derive (p_star j - f j)^(q-1) / p_star j^(q-1) = lambda * N^(q-1) / M^(q-1)
    have hpfj_pos : 0 < p_star j - f j := sub_pos.mpr hfj_lt
    have hpj_qm1_pos : 0 < p_star j ^ (q - 1) := Real.rpow_pos_of_pos hpj_pos _
    have hpfj_qm1_pos : 0 < (p_star j - f j) ^ (q - 1) := Real.rpow_pos_of_pos hpfj_pos _
    have hpj_qm1_ne : p_star j ^ (q - 1) ≠ 0 := ne_of_gt hpj_qm1_pos
    have hpfj_qm1_ne : (p_star j - f j) ^ (q - 1) ≠ 0 := ne_of_gt hpfj_qm1_pos
    -- Negative branch positivities
    have hmpi_pos : 0 < -p_star i := neg_pos.mpr hpi_neg
    have h_diff_pos : 0 < f i - p_star i := by linarith
    have h_diff_gt : -p_star i < f i - p_star i := by linarith
    have hmpi_qm1_pos : 0 < (-p_star i) ^ (q - 1) := Real.rpow_pos_of_pos hmpi_pos _
    have h_diff_qm1_pos : 0 < (f i - p_star i) ^ (q - 1) := Real.rpow_pos_of_pos h_diff_pos _
    have hmpi_qm1_ne : (-p_star i) ^ (q - 1) ≠ 0 := ne_of_gt hmpi_qm1_pos
    -- Step 1: rewrite h_pos and h_neg as: ratio of differences = K
    -- where K = lambda * N^(q-1) / M^(q-1)
    -- From h_pos:
    --   (p_star j - f j)^(q-1) / N^(q-1) = lambda * (p_star j^(q-1) / M^(q-1))
    -- Multiply both sides by N^(q-1) / p_star j^(q-1):
    --   (p_star j - f j)^(q-1) / p_star j^(q-1) = lambda * N^(q-1) / M^(q-1)
    set N := lqNorm q (fun k => p_star k - f k)
    set M := lqNorm q p_star
    -- Make K explicit
    set K := lambda * N ^ (q - 1) / M ^ (q - 1) with hK_def
    have hK_pos : 0 < K := by rw [hK_def]; positivity
    -- Convert h_pos to (p_star j - f j)^(q-1) / p_star j^(q-1) = K
    have h_pos_K : (p_star j - f j) ^ (q - 1) / p_star j ^ (q - 1) = K := by
      have hN_ne : N ^ (q - 1) ≠ 0 := hNqm1_ne
      have hM_ne : M ^ (q - 1) ≠ 0 := hMqm1_ne
      rw [hK_def]
      field_simp
      have h := h_pos
      field_simp at h
      linarith
    -- Inequality: (p_star j - f j)^(q-1) / p_star j^(q-1) < 1
    have h_lt_one : (p_star j - f j) ^ (q - 1) / p_star j ^ (q - 1) < 1 := by
      rw [div_lt_one hpj_qm1_pos]
      apply Real.rpow_lt_rpow (le_of_lt hpfj_pos) _ hq1
      linarith
    have hK_lt_one : K < 1 := h_pos_K ▸ h_lt_one
    -- Convert h_neg to (f i - p_star i)^(q-1) / (-p_star i)^(q-1) = K
    have h_neg_K : (f i - p_star i) ^ (q - 1) / (-p_star i) ^ (q - 1) = K := by
      have hN_ne : N ^ (q - 1) ≠ 0 := hNqm1_ne
      have hM_ne : M ^ (q - 1) ≠ 0 := hMqm1_ne
      rw [hK_def]
      field_simp
      have h := h_neg
      field_simp at h
      linarith
    have h_gt_one : 1 < (f i - p_star i) ^ (q - 1) / (-p_star i) ^ (q - 1) := by
      rw [lt_div_iff₀ hmpi_qm1_pos, one_mul]
      apply Real.rpow_lt_rpow (le_of_lt hmpi_pos) h_diff_gt hq1
    have hK_gt_one : 1 < K := h_neg_K ▸ h_gt_one
    linarith
  · -- Case B: f j = p_star j, use RightBoundary_ForcesC0
    have h_eq : p_star j = f j := hfj_eq.symm
    have h_zero := RightBoundary_ForcesC0 q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
      sigma hsigma_pm p_star hp_in hp_loc hpf_pos hp_pos j hsig_j h_eq hfj_pos
    -- h_zero : lqNorm q (fun k => p_star k - f k) = 0
    -- Contradicts hpf_pos
    rw [h_zero] at hpf_pos
    exact lt_irrefl 0 hpf_pos

open Workspace.Types.LqNorm

theorem LqNormBoundaryFirstOrderRise
    {q : ℝ} (hq : 1 < q) {d : ℕ} (hd : 1 ≤ d)
    (x : Fin d → ℝ) (j : Fin d)
    (hxj_zero : x j = 0) (hlq_pos : 0 < lqNorm q x) :
    ∃ delta0 > (0 : ℝ), ∃ C > (0 : ℝ),
      ∀ delta ∈ Set.Ioo (0 : ℝ) delta0,
        lqNorm q (Function.update x j delta)
          ≤ lqNorm q x + C * delta ^ q := by
  -- Set up the basic constants and positivity facts.
  set M : ℝ := lqNorm q x with hM_def
  have hM_pos : 0 < M := hlq_pos
  have hM_nn : 0 ≤ M := le_of_lt hM_pos
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_nn : 0 ≤ q := le_of_lt hq_pos
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hinvq_pos : 0 < 1 / q := by positivity
  have hinvq_le_one : 1 / q ≤ 1 := by
    rw [div_le_one hq_pos]; exact le_of_lt hq
  have hinvq_nn : 0 ≤ 1 / q := le_of_lt hinvq_pos
  -- M^q > 0 and M^(q-1) > 0
  have hMq_pos : 0 < M ^ q := Real.rpow_pos_of_pos hM_pos q
  have hMq_nn : 0 ≤ M ^ q := le_of_lt hMq_pos
  have hMq_ne : M ^ q ≠ 0 := ne_of_gt hMq_pos
  have hMqm1_pos : 0 < M ^ (q - 1) := Real.rpow_pos_of_pos hM_pos (q - 1)
  have hMqm1_ne : M ^ (q - 1) ≠ 0 := ne_of_gt hMqm1_pos
  -- Useful identity: (M^q)^(1/q) = M
  have hMq_invq : (M ^ q) ^ ((1 : ℝ) / q) = M := by
    rw [← Real.rpow_mul hM_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  -- Useful: M^q = M^(q-1) * M
  have hMq_split : M ^ q = M ^ (q - 1) * M := by
    have : M ^ (q - 1) * M ^ (1 : ℝ) = M ^ ((q - 1) + 1) :=
      (Real.rpow_add hM_pos _ _).symm
    rw [Real.rpow_one] at this
    rw [this]
    ring_nf
  -- Choose C = 1 / (q * M^(q-1))
  refine ⟨1, by norm_num, 1 / (q * M ^ (q - 1)), ?_, ?_⟩
  · -- C > 0
    apply div_pos zero_lt_one
    exact mul_pos hq_pos hMqm1_pos
  · -- The main inequality, for all δ ∈ (0, 1)
    intro delta hdelta
    obtain ⟨hdelta_pos, hdelta_lt⟩ := hdelta
    have hdelta_nn : 0 ≤ delta := le_of_lt hdelta_pos
    have hdq_pos : 0 < delta ^ q := Real.rpow_pos_of_pos hdelta_pos q
    have hdq_nn : 0 ≤ delta ^ q := le_of_lt hdq_pos
    -- Use UpwardExpansion to rewrite the LHS.
    have hexp : lqNorm q (Function.update x j delta)
                  = (M ^ q + delta ^ q) ^ ((1 : ℝ) / q) :=
      LqNormBoundaryUpwardExpansion hq hd x j delta hdelta_nn hxj_zero
    rw [hexp]
    -- Factor (M^q + δ^q) = M^q * (1 + δ^q / M^q)
    have hfactor : M ^ q + delta ^ q = M ^ q * (1 + delta ^ q / M ^ q) := by
      field_simp
    rw [hfactor]
    -- (M^q * (1 + δ^q/M^q))^(1/q) = (M^q)^(1/q) * (1 + δ^q/M^q)^(1/q)
    have hsdef : delta ^ q / M ^ q ≥ 0 := div_nonneg hdq_nn hMq_nn
    have h1pos : (0 : ℝ) ≤ 1 + delta ^ q / M ^ q := by linarith
    rw [Real.mul_rpow hMq_nn h1pos]
    rw [hMq_invq]
    -- Apply Bernoulli-type bound: (1 + s)^(1/q) ≤ 1 + (1/q)*s for s ≥ -1
    set s : ℝ := delta ^ q / M ^ q with hs_def
    have hs_ge : -1 ≤ s := by
      have : (0 : ℝ) ≤ s := hsdef
      linarith
    have hbern : (1 + s) ^ ((1 : ℝ) / q) ≤ 1 + (1 / q) * s :=
      rpow_one_add_le_one_add_mul_self hs_ge hinvq_nn hinvq_le_one
    have hbound : M * (1 + s) ^ ((1 : ℝ) / q) ≤ M * (1 + (1 / q) * s) :=
      mul_le_mul_of_nonneg_left hbern hM_nn
    refine le_trans hbound ?_
    -- Now show M * (1 + (1/q) * s) ≤ M + (1/(q*M^(q-1))) * δ^q
    -- Actually equality holds.
    have hgoal : M * (1 + (1 / q) * s) = M + (1 / (q * M ^ (q - 1))) * delta ^ q := by
      show M * (1 + (1 / q) * (delta ^ q / M ^ q))
            = M + (1 / (q * M ^ (q - 1))) * delta ^ q
      rw [hMq_split]
      field_simp
    linarith

open scoped BigOperators
open Workspace.Types.LqNorm

theorem PerturbAtZero_StrictDescent
    {q : ℝ} (hq : 1 < q) {lambda : ℝ} (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_norm : lqNorm q f = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (hS_pos : ∃ k, sigma k = 1)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ tildep : Fin d → ℝ,
      (∀ j, (sigma j = 1 → 0 ≤ tildep j) ∧ (sigma j = -1 → tildep j ≤ 0)) ∧
      (∀ j, |tildep j| < ε) ∧
      lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep
        < lqNorm q (fun k => -(f k)) := by
  -- Basic positivity of q
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  -- Pick k with σ k = 1
  obtain ⟨k, hsigma_k⟩ := hS_pos
  -- lqNorm q (fun k => -(f k)) = lqNorm q f = 1
  have hlq_neg_f : lqNorm q (fun k => -(f k)) = lqNorm q f := by
    unfold lqNorm
    congr 1
    apply Finset.sum_congr rfl
    intro j _
    rw [abs_neg]
  have hlq_neg_f_eq_one : lqNorm q (fun k => -(f k)) = 1 := by
    rw [hlq_neg_f, hf_norm]
  -- A helper: lqNorm q (Function.update (fun _ => 0) k δ) = δ for δ ≥ 0
  have hnorm_update_zero : ∀ delta : ℝ, 0 ≤ delta →
      lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k delta) = delta := by
    intro delta hdelta_nn
    have h_zero_k : (fun _ : Fin d => (0 : ℝ)) k = 0 := rfl
    have hexp : lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k delta)
        = ((lqNorm q (fun _ : Fin d => (0 : ℝ))) ^ q + delta ^ q) ^ ((1 : ℝ) / q) :=
      LqNormBoundaryUpwardExpansion hq hd (fun _ : Fin d => (0 : ℝ)) k delta hdelta_nn h_zero_k
    rw [hexp, lqNorm_zero hq_le]
    rw [Real.zero_rpow hq_ne, zero_add]
    rw [← Real.rpow_mul hdelta_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  -- Case split on whether f k > 0 or f k = 0
  by_cases hfk_pos : 0 < f k
  · -- ============= Case 1: f k > 0 =============
    -- Pick δ := min(ε, f k) / 2
    set δ := min ε (f k) / 2 with hδ_def
    have hδ_pos : 0 < δ := by
      apply div_pos
      · exact lt_min hε hfk_pos
      · norm_num
    have hδ_lt_ε : δ < ε := by
      have h1 : δ ≤ min ε (f k) / 1 := by
        rw [div_one]; rw [hδ_def]; linarith [min_le_left ε (f k), min_le_right ε (f k)]
      have h2 : min ε (f k) ≤ ε := min_le_left _ _
      have : min ε (f k) / 2 < min ε (f k) := by
        have : min ε (f k) > 0 := lt_min hε hfk_pos
        linarith
      linarith
    have hδ_lt_fk : δ < f k := by
      have hmin : min ε (f k) ≤ f k := min_le_right _ _
      have hpos : 0 < min ε (f k) := lt_min hε hfk_pos
      linarith
    have hδ_nn : 0 ≤ δ := le_of_lt hδ_pos
    -- Define tildep
    refine ⟨Function.update (fun _ : Fin d => (0 : ℝ)) k δ, ?_, ?_, ?_⟩
    · -- Orthant condition
      intro j
      refine ⟨?_, ?_⟩
      · intro _
        by_cases hj : j = k
        · subst hj; rw [Function.update_self]; exact hδ_nn
        · rw [Function.update_of_ne hj]
      · intro hsj
        by_cases hj : j = k
        · subst hj
          -- sigma k = 1 and sigma k = -1 simultaneously is impossible
          rw [hsigma_k] at hsj; norm_num at hsj
        · rw [Function.update_of_ne hj]
    · -- |tildep j| < ε
      intro j
      by_cases hj : j = k
      · subst hj; rw [Function.update_self]; rw [abs_of_nonneg hδ_nn]; exact hδ_lt_ε
      · rw [Function.update_of_ne hj]; rw [abs_zero]; exact hε
    · -- Strict descent
      -- lqNorm q (tildep - f) < lqNorm q (-f) using LqNormStrictDecrease_OfSingleCoordinateCloser
      have h_strict_dec :
          lqNorm q (fun j => Function.update (fun _ : Fin d => (0 : ℝ)) k δ j - f j)
            < lqNorm q (fun j => (fun _ : Fin d => (0 : ℝ)) j - f j) := by
        apply LqNormStrictDecrease_OfSingleCoordinateCloser hq hd
            (fun _ : Fin d => (0 : ℝ)) (Function.update (fun _ : Fin d => (0 : ℝ)) k δ) f k
        · intro j hj
          rw [Function.update_of_ne hj]
        · -- |tildep k - f k| < |0 - f k|
          rw [Function.update_self]
          rw [zero_sub]
          rw [abs_neg, abs_of_nonneg (hf_nn k)]
          rw [abs_of_nonpos (by linarith : δ - f k ≤ 0)]
          linarith
      -- Rewrite (fun j => 0 - f j) = (fun j => -(f j))
      have h_zero_sub : (fun j : Fin d => (fun _ : Fin d => (0 : ℝ)) j - f j) =
                        (fun j : Fin d => -(f j)) := by
        funext j; rw [zero_sub]
      rw [h_zero_sub] at h_strict_dec
      -- lqNorm q tildep ≥ 0
      have hlq_tildep_nn : 0 ≤ lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k δ) :=
        lqNorm_nonneg hq_le _
      have h_lambda_norm_nn :
          0 ≤ lambda * lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k δ) :=
        mul_nonneg (le_of_lt hlam0) hlq_tildep_nn
      linarith
  · -- ============= Case 2: f k = 0 =============
    push_neg at hfk_pos
    have hfk_eq_zero : f k = 0 := le_antisymm hfk_pos (hf_nn k)
    -- Apply LqNormBoundaryFirstOrderRise to x = -f at coordinate k
    have h_neg_f_k_zero : (fun j => -(f j)) k = 0 := by simp [hfk_eq_zero]
    have hlq_neg_f_pos : 0 < lqNorm q (fun j => -(f j)) := by
      rw [hlq_neg_f_eq_one]; norm_num
    obtain ⟨delta0, hdelta0_pos, C, hC_pos, hbound⟩ :=
      LqNormBoundaryFirstOrderRise hq hd (fun j => -(f j)) k h_neg_f_k_zero hlq_neg_f_pos
    -- Now choose δ small enough:
    --   0 < δ < δ0, δ < ε, δ < (λ / (2C))^(1/(q-1))   (so C * δ^q < λ * δ)
    -- A simple bound: pick δ ≤ (λ / (2C)) for the last condition? Actually we need
    --   C * δ^q < λ * δ ⇔ δ^(q-1) < λ/C ⇔ δ < (λ/C)^(1/(q-1)).
    -- Let `bound1 := (lambda / (2 * C))^(1/(q-1))`.
    -- Pick δ := min(delta0, ε, bound1) / 2.
    have hqm1_pos : 0 < q - 1 := by linarith
    have hqm1_inv_pos : 0 < 1 / (q - 1) := by positivity
    have h_lambda_2C_pos : 0 < lambda / (2 * C) := div_pos hlam0 (by linarith)
    set bound1 : ℝ := (lambda / (2 * C)) ^ ((1 : ℝ) / (q - 1)) with hbound1_def
    have hbound1_pos : 0 < bound1 := by
      apply Real.rpow_pos_of_pos h_lambda_2C_pos
    set δ : ℝ := min (min delta0 ε) bound1 / 2 with hδ_def
    have h_min_pos : 0 < min (min delta0 ε) bound1 := by
      exact lt_min (lt_min hdelta0_pos hε) hbound1_pos
    have hδ_pos : 0 < δ := by rw [hδ_def]; positivity
    have hδ_nn : 0 ≤ δ := le_of_lt hδ_pos
    have hδ_lt_min : δ < min (min delta0 ε) bound1 := by
      rw [hδ_def]; linarith
    have hδ_lt_delta0 : δ < delta0 :=
      lt_of_lt_of_le hδ_lt_min (le_trans (min_le_left _ _) (min_le_left _ _))
    have hδ_lt_ε : δ < ε :=
      lt_of_lt_of_le hδ_lt_min (le_trans (min_le_left _ _) (min_le_right _ _))
    have hδ_lt_bound1 : δ < bound1 :=
      lt_of_lt_of_le hδ_lt_min (min_le_right _ _)
    -- Define tildep
    refine ⟨Function.update (fun _ : Fin d => (0 : ℝ)) k δ, ?_, ?_, ?_⟩
    · -- Orthant condition
      intro j
      refine ⟨?_, ?_⟩
      · intro _
        by_cases hj : j = k
        · subst hj; rw [Function.update_self]; exact hδ_nn
        · rw [Function.update_of_ne hj]
      · intro hsj
        by_cases hj : j = k
        · subst hj
          rw [hsigma_k] at hsj; norm_num at hsj
        · rw [Function.update_of_ne hj]
    · -- |tildep j| < ε
      intro j
      by_cases hj : j = k
      · subst hj; rw [Function.update_self]; rw [abs_of_nonneg hδ_nn]; exact hδ_lt_ε
      · rw [Function.update_of_ne hj]; rw [abs_zero]; exact hε
    · -- Strict descent via boundary first-order rise
      -- (1) Show that (tildep - f) = Function.update (-f) k δ
      have h_tildep_minus_f :
          (fun j => Function.update (fun _ : Fin d => (0 : ℝ)) k δ j - f j)
            = Function.update (fun j => -(f j)) k δ := by
        funext j
        by_cases hj : j = k
        · subst hj
          rw [Function.update_self, Function.update_self, hfk_eq_zero, sub_zero]
        · rw [Function.update_of_ne hj, Function.update_of_ne hj]
          rw [zero_sub]
      rw [h_tildep_minus_f]
      -- (2) From boundary first order rise:
      have hδ_in_Ioo : δ ∈ Set.Ioo (0 : ℝ) delta0 := ⟨hδ_pos, hδ_lt_delta0⟩
      have h_rise : lqNorm q (Function.update (fun j => -(f j)) k δ)
                      ≤ lqNorm q (fun j => -(f j)) + C * δ ^ q :=
        hbound δ hδ_in_Ioo
      -- (3) lqNorm q tildep = δ
      have hnorm_tildep :
          lqNorm q (Function.update (fun _ : Fin d => (0 : ℝ)) k δ) = δ :=
        hnorm_update_zero δ hδ_nn
      rw [hnorm_tildep]
      -- (4) Final inequality:
      --   lqNorm q (-f) + C * δ^q - λ * δ < lqNorm q (-f)
      -- iff C * δ^q < λ * δ
      -- We have δ < bound1 = (λ/(2C))^(1/(q-1)), so δ^(q-1) < λ/(2C),
      -- so C * δ^q = C * δ^(q-1) * δ < (λ/2) * δ < λ * δ.
      -- Step (a): δ^(q-1) < λ/(2C)
      have h_delta_qm1_lt : δ ^ (q - 1) < lambda / (2 * C) := by
        -- δ < (λ/(2C))^(1/(q-1)) ⇒ δ^(q-1) < λ/(2C)
        have h_eq : (bound1) ^ (q - 1) = lambda / (2 * C) := by
          rw [hbound1_def]
          rw [← Real.rpow_mul (le_of_lt h_lambda_2C_pos)]
          rw [div_mul_cancel₀ 1 (by linarith : q - 1 ≠ 0)]
          exact Real.rpow_one _
        have h_step : δ ^ (q - 1) < bound1 ^ (q - 1) :=
          Real.rpow_lt_rpow hδ_nn hδ_lt_bound1 hqm1_pos
        rw [h_eq] at h_step
        exact h_step
      -- Step (b): C * δ^q < (λ/2) * δ
      have hCpos : 0 < C := hC_pos
      -- C * δ^q = C * δ * δ^(q-1)  (since δ^q = δ^(q-1) * δ^1 = δ^(q-1) * δ)
      have h_split : δ ^ q = δ ^ (q - 1) * δ := by
        have h1 : δ ^ ((q - 1) + 1) = δ ^ (q - 1) * δ ^ (1 : ℝ) :=
          Real.rpow_add hδ_pos _ _
        rw [Real.rpow_one] at h1
        have h_qm1_p1 : (q - 1) + 1 = q := by ring
        rw [h_qm1_p1] at h1
        exact h1
      have h_Cdelta_qm1 : C * δ ^ (q - 1) < lambda / 2 := by
        have h1 : C * δ ^ (q - 1) < C * (lambda / (2 * C)) :=
          mul_lt_mul_of_pos_left h_delta_qm1_lt hCpos
        have h_simp : C * (lambda / (2 * C)) = lambda / 2 := by
          field_simp
        linarith [h_simp]
      have h_C_delta_q_lt : C * δ ^ q < (lambda / 2) * δ := by
        rw [h_split]
        have heq : C * (δ ^ (q - 1) * δ) = (C * δ ^ (q - 1)) * δ := by ring
        rw [heq]
        exact mul_lt_mul_of_pos_right h_Cdelta_qm1 hδ_pos
      -- Step (c): conclude
      have h_lambda_2_lt : (lambda / 2) * δ < lambda * δ := by
        have hl : lambda / 2 < lambda := by linarith
        exact mul_lt_mul_of_pos_right hl hδ_pos
      have h_C_delta_q_lt' : C * δ ^ q < lambda * δ := lt_trans h_C_delta_q_lt h_lambda_2_lt
      linarith [h_rise]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem PEqZeroNotLocalMin
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma : Fin d → ℝ) (hsigma_pm : ∀ j, sigma j = 1 ∨ sigma j = -1)
    (hS_pos : ∃ k, sigma k = 1) :
    ¬ ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma j = 1 → 0 ≤ p j) ∧ (sigma j = -1 → p j ≤ 0)) →
          (∀ j, |p j - 0| < ε) →
          g_lambda q lambda f (fun _ : Fin d => (0 : ℝ)) ≤ g_lambda q lambda f p := by
  -- Step 1: convert the sum hypothesis to lqNorm q f = 1
  have hq_le : 1 ≤ q := le_of_lt hq
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq_le
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hf_norm : lqNorm q f = 1 := by
    unfold lqNorm
    have h_abs : (∑ j, |f j| ^ q) = (∑ j, (f j) ^ q) := by
      apply Finset.sum_congr rfl
      intro j _
      rw [abs_of_nonneg (hf_nn j)]
    rw [h_abs, hf_sum, Real.one_rpow]
  -- Step 2: assume the contradiction hypothesis
  rintro ⟨ε, hε_pos, hε_local⟩
  -- Step 3: apply PerturbAtZero_StrictDescent
  obtain ⟨tildep, h_orthant, h_close, h_strict⟩ :=
    PerturbAtZero_StrictDescent hq hlam0 hlam1 hd f hf_nn hf_norm sigma hsigma_pm hS_pos hε_pos
  -- h_strict : lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep
  --             < lqNorm q (fun k => -(f k))
  -- Step 4: apply the local minimum at tildep
  have h_dist : ∀ j, |tildep j - 0| < ε := by
    intro j
    rw [sub_zero]
    exact h_close j
  have h_local := hε_local tildep h_orthant h_dist
  -- h_local : g_lambda q lambda f 0 ≤ g_lambda q lambda f tildep
  -- Step 5: simplify g_lambda at 0
  have h_g0 : g_lambda q lambda f (fun _ : Fin d => (0 : ℝ))
              = lqNorm q (fun k : Fin d => -(f k)) := by
    unfold g_lambda
    have h_zero : lqNorm q (fun _ : Fin d => (0 : ℝ)) = 0 := lqNorm_zero hq_le
    have h_arg : (fun j : Fin d => (fun (_ : Fin d) => (0 : ℝ)) j - f j)
                  = (fun k : Fin d => -(f k)) := by
      funext j; ring
    rw [h_arg, h_zero]
    ring
  -- Step 6: g_lambda at tildep
  have h_gtilde : g_lambda q lambda f tildep
                  = lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep := rfl
  -- Step 7: derive contradiction
  rw [h_g0] at h_local
  rw [h_gtilde] at h_local
  -- h_local : lqNorm q (fun k => -(f k)) ≤ lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep
  -- h_strict : lqNorm q (fun k => tildep k - f k) - lambda * lqNorm q tildep < lqNorm q (fun k => -(f k))
  linarith

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

namespace LocalOptimumCharacterization_CaseSNonemptyProof

/-- Helper: x^(q-1) = y^(q-1) with x, y ≥ 0 and q-1 > 0 implies x = y. -/
private lemma rpow_qm1_inj {q : ℝ} (hqm1 : 0 < q - 1) {x y : ℝ}
    (hx : 0 ≤ x) (hy : 0 ≤ y) (heq : x ^ (q - 1) = y ^ (q - 1)) : x = y := by
  have hq_inv_pos : 0 < 1 / (q - 1) := by positivity
  have h1 : (x ^ (q - 1)) ^ (1 / (q - 1)) = (y ^ (q - 1)) ^ (1 / (q - 1)) := by rw [heq]
  rw [← Real.rpow_mul hx, ← Real.rpow_mul hy] at h1
  have hmul : (q - 1) * (1 / (q - 1)) = 1 := by
    field_simp
  rw [hmul, Real.rpow_one, Real.rpow_one] at h1
  exact h1

/-- Helper: from `(p - f)^(q-1) / N1^(q-1) = lambda * p^(q-1) / N2^(q-1)`
with `p > f ≥ 0`, `N1 > 0`, `N2 > 0`, `lambda > 0`, `q > 1`, derive
`(p - f) / p = lambda^(1/(q-1)) * N1 / N2`. -/
private lemma extract_c_pos {q : ℝ} (hq : 1 < q) {p_j f_j N1 N2 lambda : ℝ}
    (hf_nn : 0 ≤ f_j) (hpf : f_j < p_j) (hN1 : 0 < N1) (hN2 : 0 < N2)
    (hlam : 0 < lambda)
    (hkkt : (p_j - f_j) ^ (q - 1) / N1 ^ (q - 1)
            = lambda * (p_j ^ (q - 1) / N2 ^ (q - 1))) :
    (p_j - f_j) / p_j = Real.rpow lambda (1 / (q - 1)) * N1 / N2 := by
  have hp_pos : 0 < p_j := lt_of_le_of_lt hf_nn hpf
  have hpf_pos : 0 < p_j - f_j := by linarith
  have hqm1_pos : 0 < q - 1 := by linarith
  have hN1_pow : 0 < N1 ^ (q - 1) := Real.rpow_pos_of_pos hN1 _
  have hN2_pow : 0 < N2 ^ (q - 1) := Real.rpow_pos_of_pos hN2 _
  have hp_pow : 0 < p_j ^ (q - 1) := Real.rpow_pos_of_pos hp_pos _
  -- Step 1: Multiply both sides by N1^(q-1)/p^(q-1).
  -- ((p-f)/p)^(q-1) = lambda * (N1/N2)^(q-1)
  have hstep1 : ((p_j - f_j) / p_j) ^ (q - 1) = lambda * (N1 / N2) ^ (q - 1) := by
    rw [Real.div_rpow (le_of_lt hpf_pos) (le_of_lt hp_pos)]
    rw [Real.div_rpow (le_of_lt hN1) (le_of_lt hN2)]
    field_simp
    field_simp at hkkt
    linarith
  -- Step 2: Take (q-1)-th roots.
  -- LHS: ((p-f)/p) ≥ 0; RHS: lambda^(1/(q-1)) * N1/N2 ≥ 0.
  have hlhs_nn : 0 ≤ (p_j - f_j) / p_j := div_nonneg (le_of_lt hpf_pos) (le_of_lt hp_pos)
  have hN1N2_nn : 0 ≤ N1 / N2 := div_nonneg (le_of_lt hN1) (le_of_lt hN2)
  have hlam_rpow_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) := Real.rpow_nonneg (le_of_lt hlam) _
  have hrhs_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) * (N1 / N2) :=
    mul_nonneg hlam_rpow_nn hN1N2_nn
  -- We'll show: (lambda^(1/(q-1)) * (N1/N2))^(q-1) = lambda * (N1/N2)^(q-1).
  have hrhs_pow : (Real.rpow lambda (1 / (q - 1)) * (N1 / N2)) ^ (q - 1)
      = lambda * (N1 / N2) ^ (q - 1) := by
    rw [Real.mul_rpow hlam_rpow_nn hN1N2_nn]
    -- (lambda^(1/(q-1)))^(q-1) = lambda
    have hlam_pow : Real.rpow lambda (1 / (q - 1)) ^ (q - 1) = lambda := by
      rw [show (Real.rpow lambda (1/(q-1))) ^ (q-1)
            = Real.rpow lambda ((1/(q-1))*(q-1))
            from (Real.rpow_mul (le_of_lt hlam) (1/(q-1)) (q-1)).symm,
          show (1 / (q-1) * (q-1) : ℝ) = 1 from by field_simp]
      exact Real.rpow_one lambda
    rw [hlam_pow]
  -- Now ((p-f)/p)^(q-1) = (lambda^(1/(q-1)) * (N1/N2))^(q-1).
  have heq2 : ((p_j - f_j) / p_j) ^ (q - 1)
      = (Real.rpow lambda (1 / (q - 1)) * (N1 / N2)) ^ (q - 1) := by
    rw [hrhs_pow]; exact hstep1
  have heq3 : (p_j - f_j) / p_j = Real.rpow lambda (1 / (q - 1)) * (N1 / N2) :=
    rpow_qm1_inj hqm1_pos hlhs_nn hrhs_nn heq2
  rw [heq3]; ring

/-- Helper: same for negative branch.
From `(f - p)^(q-1) / N1^(q-1) = lambda * (-p)^(q-1) / N2^(q-1)` with `p < 0`, `f ≥ 0`,
derive `(f - p) / (-p) = lambda^(1/(q-1)) * N1/N2`. -/
private lemma extract_c_neg {q : ℝ} (hq : 1 < q) {p_j f_j N1 N2 lambda : ℝ}
    (hf_nn : 0 ≤ f_j) (hp_neg : p_j < 0) (hN1 : 0 < N1) (hN2 : 0 < N2)
    (hlam : 0 < lambda)
    (hkkt : (f_j - p_j) ^ (q - 1) / N1 ^ (q - 1)
            = lambda * ((-p_j) ^ (q - 1) / N2 ^ (q - 1))) :
    (f_j - p_j) / (-p_j) = Real.rpow lambda (1 / (q - 1)) * N1 / N2 := by
  have hnp_pos : 0 < -p_j := by linarith
  have hfp_pos : 0 < f_j - p_j := by linarith
  have hqm1_pos : 0 < q - 1 := by linarith
  have hN1_pow : 0 < N1 ^ (q - 1) := Real.rpow_pos_of_pos hN1 _
  have hN2_pow : 0 < N2 ^ (q - 1) := Real.rpow_pos_of_pos hN2 _
  have hnp_pow : 0 < (-p_j) ^ (q - 1) := Real.rpow_pos_of_pos hnp_pos _
  have hstep1 : ((f_j - p_j) / (-p_j)) ^ (q - 1) = lambda * (N1 / N2) ^ (q - 1) := by
    rw [Real.div_rpow (le_of_lt hfp_pos) (le_of_lt hnp_pos)]
    rw [Real.div_rpow (le_of_lt hN1) (le_of_lt hN2)]
    field_simp
    field_simp at hkkt
    linarith
  have hlhs_nn : 0 ≤ (f_j - p_j) / (-p_j) := div_nonneg (le_of_lt hfp_pos) (le_of_lt hnp_pos)
  have hN1N2_nn : 0 ≤ N1 / N2 := div_nonneg (le_of_lt hN1) (le_of_lt hN2)
  have hlam_rpow_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) := Real.rpow_nonneg (le_of_lt hlam) _
  have hrhs_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) * (N1 / N2) :=
    mul_nonneg hlam_rpow_nn hN1N2_nn
  have hrhs_pow : (Real.rpow lambda (1 / (q - 1)) * (N1 / N2)) ^ (q - 1)
      = lambda * (N1 / N2) ^ (q - 1) := by
    rw [Real.mul_rpow hlam_rpow_nn hN1N2_nn]
    have hlam_pow : Real.rpow lambda (1 / (q - 1)) ^ (q - 1) = lambda := by
      rw [show (Real.rpow lambda (1/(q-1))) ^ (q-1)
            = Real.rpow lambda ((1/(q-1))*(q-1))
            from (Real.rpow_mul (le_of_lt hlam) (1/(q-1)) (q-1)).symm,
          show (1 / (q-1) * (q-1) : ℝ) = 1 from by field_simp]
      exact Real.rpow_one lambda
    rw [hlam_pow]
  have heq2 : ((f_j - p_j) / (-p_j)) ^ (q - 1)
      = (Real.rpow lambda (1 / (q - 1)) * (N1 / N2)) ^ (q - 1) := by
    rw [hrhs_pow]; exact hstep1
  have heq3 : (f_j - p_j) / (-p_j) = Real.rpow lambda (1 / (q - 1)) * (N1 / N2) :=
    rpow_qm1_inj hqm1_pos hlhs_nn hrhs_nn heq2
  rw [heq3]; ring

end LocalOptimumCharacterization_CaseSNonemptyProof

open LocalOptimumCharacterization_CaseSNonemptyProof

theorem LocalOptimumCharacterization_CaseSNonempty
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧
                  (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧
                (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (S : Finset (Fin d))
    (hS_def : S = Finset.univ.filter (fun j : Fin d => sigma_i j = 1))
    (hS_ne : S.Nonempty) :
    ∃ c : ℝ, 0 ≤ c ∧ c < 1 ∧
      (∀ j ∈ S, p_star j = f j / (1 - c)) ∧
      (∀ j ∉ S, p_star j = 0) := by
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have hq_pos : (0 : ℝ) < q := lt_of_lt_of_le zero_lt_one hq_le
  have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
  have hmemS : ∀ j, j ∈ S ↔ sigma_i j = 1 := by
    intro j; rw [hS_def]; simp [Finset.mem_filter]
  have hnotmemS : ∀ j, j ∉ S ↔ sigma_i j = -1 := by
    intro j
    rw [hmemS]
    constructor
    · intro hne
      rcases hsigma_pm j with h | h
      · exact (hne h).elim
      · exact h
    · intro h heq
      rw [heq] at h; norm_num at h
  have hp_nn_S : ∀ j ∈ S, 0 ≤ p_star j := by
    intro j hj; exact (hp_in j).1 ((hmemS j).mp hj)
  have hp_np_Sc : ∀ j ∉ S, p_star j ≤ 0 := by
    intro j hj; exact (hp_in j).2 ((hnotmemS j).mp hj)
  -- p_star is not identically zero
  have hS_pos : ∃ k, sigma_i k = 1 := by
    obtain ⟨j, hj⟩ := hS_ne
    exact ⟨j, (hmemS j).mp hj⟩
  have hp_not_zero : ¬ (∀ j, p_star j = 0) := by
    intro hzero
    apply PEqZeroNotLocalMin q hq lambda hlam0 hlam1 hd f hf_nn hf_sum sigma_i hsigma_pm hS_pos
    obtain ⟨ε, hε, hloc⟩ := hp_loc
    refine ⟨ε, hε, ?_⟩
    intro p hp_orth hp_close
    have hp_close' : ∀ j, |p j - p_star j| < ε := by
      intro j; have hk := hp_close j; rw [hzero j]; simpa using hk
    have h2 : g_lambda q lambda f p_star ≤ g_lambda q lambda f p := hloc p hp_orth hp_close'
    have hpstar_eq : p_star = (fun _ : Fin d => (0 : ℝ)) := by
      funext j; exact hzero j
    rw [hpstar_eq] at h2
    exact h2
  have hps_pos : 0 < lqNorm q p_star := by
    have hps_nn : 0 ≤ lqNorm q p_star := lqNorm_nonneg hq_le p_star
    rcases lt_or_eq_of_le hps_nn with h | h
    · exact h
    · exfalso
      have heq : lqNorm q p_star = 0 := h.symm
      have hzero : p_star = 0 := (LqNormZeroIffEqZero q hq_le hd p_star).mp heq
      apply hp_not_zero
      intro j; have := congrFun hzero j; simpa using this
  -- Case split on lqNorm q (p - f) = 0.
  by_cases hpf_zero : lqNorm q (fun k => p_star k - f k) = 0
  · -- Case A: p_star = f.
    have hpf_eq : (fun k => p_star k - f k) = 0 :=
      (LqNormZeroIffEqZero q hq_le hd _).mp hpf_zero
    have hpf_ptw : ∀ j, p_star j = f j := by
      intro j
      have := congrFun hpf_eq j
      simp at this
      linarith
    refine ⟨0, le_refl 0, by norm_num, ?_, ?_⟩
    · intro j _hj
      rw [hpf_ptw j]; ring
    · intro j hj
      have hpj_le : p_star j ≤ 0 := hp_np_Sc j hj
      have hpj_eq : p_star j = f j := hpf_ptw j
      have hfj_nn : 0 ≤ f j := hf_nn j
      linarith
  · -- Case B: lqNorm q (p_star - f) > 0.
    have hpf_pos : 0 < lqNorm q (fun k => p_star k - f k) := by
      have hnn : 0 ≤ lqNorm q (fun k => p_star k - f k) := lqNorm_nonneg hq_le _
      rcases lt_or_eq_of_le hnn with h | h
      · exact h
      · exfalso; exact hpf_zero h.symm
    set c : ℝ :=
        Real.rpow lambda (1 / (q - 1)) *
          lqNorm q (fun k => p_star k - f k) / lqNorm q p_star with hc_def
    have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
    have hrpow_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) := Real.rpow_nonneg hlam_nn _
    have hc_nn : 0 ≤ c := by
      have h1 : 0 ≤ Real.rpow lambda (1 / (q - 1)) *
          lqNorm q (fun k => p_star k - f k) :=
        mul_nonneg hrpow_nn (le_of_lt hpf_pos)
      exact div_nonneg h1 (le_of_lt hps_pos)
    -- Key claim: at any j ∈ Fin d with σ_j = +1, p_star j > f j, we have
    -- (p_star j - f j) / p_star j = c.
    have hc_eq_pos : ∀ (j : Fin d), sigma_i j = 1 → f j < p_star j →
        (p_star j - f j) / p_star j = c := by
      intro j hsig hpf
      have hkkt := InteriorFOC_Pos q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
        sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos hps_pos j hsig hpf
      have := extract_c_pos hq (hf_nn j) hpf hpf_pos hps_pos hlam0 hkkt
      rw [this, hc_def]
    -- Similarly for negative branch.
    have hc_eq_neg : ∀ (j : Fin d), sigma_i j = -1 → p_star j < 0 →
        (f j - p_star j) / (- p_star j) = c := by
      intro j hsig hpneg
      have hkkt := InteriorFOC_Neg q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
        sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos hps_pos j hsig hpneg
      have := extract_c_neg hq (hf_nn j) hpneg hpf_pos hps_pos hlam0 hkkt
      rw [this, hc_def]
    -- Step 5.1.2: For every j ∈ S, (1 - c) p_star j = f j.
    have hS_eq_aux : ∀ j ∈ S, (1 - c) * p_star j = f j := by
      intro j hj
      have hsig : sigma_i j = 1 := (hmemS j).mp hj
      have hp_nn : 0 ≤ p_star j := hp_nn_S j hj
      have hclaim := Claim1_RuleOutInterior q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
        sigma_i hsigma_pm p_star hp_in hp_loc j hsig
      rcases hclaim with hpz | hpf_ge
      · have hfz : f j = 0 := LeftBoundary_ForcesFjZero q hq lambda hlam0 hlam1 hd f
          hf_nn hf_sum sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos j hsig hpz
        rw [hpz, hfz]; ring
      · rcases lt_or_eq_of_le hpf_ge with hgt | heq
        · -- p_star j > f j. Use hc_eq_pos.
          have hcj := hc_eq_pos j hsig hgt
          have hpj_pos : 0 < p_star j := lt_of_le_of_lt (hf_nn j) hgt
          -- hcj : (p_star j - f j)/p_star j = c.
          -- Want: (1-c) * p_star j = f j.
          have : p_star j - f j = c * p_star j := by
            field_simp at hcj
            linarith
          linarith
        · -- p_star j = f j. Sub-cases.
          rcases lt_or_eq_of_le (hf_nn j) with hfp | hfz
          · -- f j > 0. RightBoundary_ForcesC0 contradicts Case B.
            exfalso
            have hcontr := RightBoundary_ForcesC0 q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
              sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos hps_pos j hsig heq.symm hfp
            rw [hcontr] at hpf_pos
            exact lt_irrefl _ hpf_pos
          · -- f j = 0. Then p_star j = 0 too.
            have hfj : f j = 0 := hfz.symm
            have hpj : p_star j = 0 := by linarith
            rw [hpj, hfj]; ring
    -- Step 5.1.3: KEY — there is some j ∈ S with f j > 0 (i.e. the energy on S
    -- is positive). From this, c < 1 follows directly. We package the witness
    -- with the bound f j ≤ p_star j so it doubles as the SignIncompatibility (P)
    -- witness.
    have hPwit : ∃ j ∈ S, f j ≤ p_star j ∧ 0 < f j := by
      -- Helper: at any k ∈ S with f k > 0, we get f k ≤ p_star k.
      have hSwit_of_mem : ∀ k ∈ S, 0 < f k → f k ≤ p_star k := by
        intro k hk_S hfk_pos
        have hsig_k : sigma_i k = 1 := (hmemS k).mp hk_S
        have hcl_k := Claim1_RuleOutInterior q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
          sigma_i hsigma_pm p_star hp_in hp_loc k hsig_k
        rcases hcl_k with hpkz | hpk_ge
        · exfalso
          have hfk_zero := LeftBoundary_ForcesFjZero q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
            sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos k hsig_k hpkz
          linarith
        · exact hpk_ge
      -- It suffices to prove there is some j ∈ S with 0 < f j (positive S-energy).
      rsuffices ⟨j, hj_S, hfj_pos⟩ : ∃ j ∈ S, 0 < f j
      · exact ⟨j, hj_S, hSwit_of_mem j hj_S hfj_pos, hfj_pos⟩
      -- ===================================================================
      -- POSITIVE S-ENERGY  (∃ j ∈ S, 0 < f j).
      --
      -- With the paper's normalization `hf_pos : ∀ j, 0 < f j` (approx.tex
      -- line 9, every optimal facility coordinate is strictly positive), the
      -- degenerate configuration E_S = ∑_{j∈S} f_j^q = 0 cannot occur: S is
      -- nonempty, so pick any witness j ∈ S and `hf_pos j` gives 0 < f j.
      -- ===================================================================
      obtain ⟨j, hj_S⟩ := hS_ne
      exact ⟨j, hj_S, hf_pos j⟩
    -- From hPwit, derive c < 1 and the SignIncompatibility (P) witness.
    obtain ⟨jw, hjw_S, hfjw_le, hfjw_pos⟩ := hPwit
    have hsig_jw : sigma_i jw = 1 := (hmemS jw).mp hjw_S
    have hpjw_pos : 0 < p_star jw := lt_of_lt_of_le hfjw_pos hfjw_le
    -- c < 1: from (1 - c) * p_star jw = f jw > 0 and p_star jw > 0.
    have hc_lt_one : c < 1 := by
      have hq_eq := hS_eq_aux jw hjw_S
      by_contra hge
      push_neg at hge  -- 1 ≤ c
      have h1mc : 1 - c ≤ 0 := by linarith
      have : (1 - c) * p_star jw ≤ 0 :=
        mul_nonpos_of_nonpos_of_nonneg h1mc (le_of_lt hpjw_pos)
      rw [hq_eq] at this
      linarith
    -- (P) witness for SignIncompatibility.
    have hP : ∃ j : Fin d, sigma_i j = 1 ∧ f j ≤ p_star j ∧ 0 < f j :=
      ⟨jw, hsig_jw, hfjw_le, hfjw_pos⟩
    -- Step 5.1.5: For every i ∉ S, p_star i = 0.
    have h_pSc_zero : ∀ i, i ∉ S → p_star i = 0 := by
      intro i hi
      have hsig_i : sigma_i i = -1 := (hnotmemS i).mp hi
      have hpi_np : p_star i ≤ 0 := hp_np_Sc i hi
      rcases lt_or_eq_of_le hpi_np with hpi_neg | hpi_zero
      · exfalso
        rcases lt_or_eq_of_le (hf_nn i) with hfi_pos | hfi_zero
        · -- f i > 0, p_star i < 0: SignIncompatibility with the (P) witness.
          have hsi := SignIncompatibility q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
            sigma_i hsigma_pm p_star hp_in hp_loc hpf_pos hps_pos
          apply hsi
          exact ⟨hP, ⟨i, hsig_i, hpi_neg, hfi_pos⟩⟩
        · -- f i = 0, p_star i < 0: negative FOC gives c = 1, contradicting c < 1.
          have hci := hc_eq_neg i hsig_i hpi_neg
          have hfi_eq : f i = 0 := hfi_zero.symm
          rw [hfi_eq, zero_sub] at hci
          have hnpi_ne : -p_star i ≠ 0 := by linarith
          have hci_eq_one : c = 1 := by
            rw [← hci, neg_div_neg_eq, div_self (by linarith : p_star i ≠ 0)]
          linarith
      · exact hpi_zero
    -- Step 5.1.6 + 5.1.7: assemble.
    refine ⟨c, hc_nn, hc_lt_one, ?_, h_pSc_zero⟩
    intro j hj
    have hj_eq := hS_eq_aux j hj
    have h1mc_pos : 0 < 1 - c := by linarith
    have h1mc_ne : (1 - c) ≠ 0 := ne_of_gt h1mc_pos
    field_simp
    linarith

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem LocalOptimumCharacterization_CaseSEmpty
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧
                  (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧
                (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (S : Finset (Fin d))
    (hS_def : S = Finset.univ.filter (fun j : Fin d => sigma_i j = 1))
    (hS_eq : S = ∅) :
    ∃ T : Finset (Fin d), ∃ c' : ℝ, 1 < c' ∧
      (∀ j ∈ T, -(p_star j) = f j / (c' - 1)) ∧
      (∀ j ∉ T, p_star j = 0) ∧
      (∀ j, p_star j ≤ 0) := by
  classical
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_le : 1 ≤ q := le_of_lt hq
  have hq1_pos : 0 < q - 1 := by linarith
  have hq1_ne : (q - 1) ≠ 0 := ne_of_gt hq1_pos
  -- Step 5.2.1: every σ_j = -1, hence p_star j ≤ 0 for all j
  have hsig_neg : ∀ j, sigma_i j = -1 := by
    intro j
    rcases hsigma_pm j with h1 | hm
    · -- σ_j = 1 ⇒ j ∈ S, but S = ∅
      exfalso
      have hj_in : j ∈ S := by
        rw [hS_def]
        simp [Finset.mem_filter, h1]
      rw [hS_eq] at hj_in
      exact (Finset.notMem_empty j) hj_in
    · exact hm
  have hpstar_le : ∀ j, p_star j ≤ 0 := fun j => (hp_in j).2 (hsig_neg j)
  -- Step 5.2.2: define T
  set T : Finset (Fin d) := Finset.univ.filter (fun j : Fin d => p_star j < 0) with hT_def
  have hT_mem : ∀ j, j ∈ T ↔ p_star j < 0 := by
    intro j
    rw [hT_def, Finset.mem_filter]
    simp
  -- Step 5.2.3: case on whether T is empty.  T may legitimately be empty
  -- (the all-zero point is a genuine local min when every σ = −1); in that
  -- case the conclusion holds vacuously with c' = 2.
  rcases Finset.eq_empty_or_nonempty T with hT_empty | hT_ne
  · -- T = ∅ ⇒ ∀ j, p_star j = 0.  Witnesses: T (= ∅), c' = 2.
    have hpstar_zero : ∀ j, p_star j = 0 := by
      intro j
      have hnotmem : j ∉ T := by
        rw [hT_empty]; exact Finset.notMem_empty j
      have hnot_lt : ¬ p_star j < 0 := by
        intro h_lt
        exact hnotmem ((hT_mem j).mpr h_lt)
      have h_ge : 0 ≤ p_star j := not_lt.mp hnot_lt
      linarith [hpstar_le j]
    refine ⟨T, 2, by norm_num, ?_, ?_, hpstar_le⟩
    · intro j hjT
      rw [hT_empty] at hjT
      exact absurd hjT (Finset.notMem_empty j)
    · intro j _
      exact hpstar_zero j
  -- Step 5.2.4: define c' (T nonempty branch)
  -- First we need lqNorm q p_star > 0 and lqNorm q (p_star - f) > 0
  -- Pick j₀ ∈ T
  obtain ⟨j₀, hj₀_T⟩ := hT_ne
  have hj₀_neg : p_star j₀ < 0 := (hT_mem j₀).mp hj₀_T
  -- lqNorm q p_star > 0 because |p_star j₀| > 0
  have hp_norm_pos : 0 < lqNorm q p_star := by
    -- Use that |p_star j₀|^q > 0 ≤ ∑ j, |p_star j|^q, so the sum is positive
    have h_abs_pos : 0 < |p_star j₀| := abs_pos.mpr (ne_of_lt hj₀_neg)
    have h_each_nn : ∀ j, 0 ≤ |p_star j| ^ q :=
      fun j => Real.rpow_nonneg (abs_nonneg _) q
    have h_j₀_pow_pos : 0 < |p_star j₀| ^ q := Real.rpow_pos_of_pos h_abs_pos q
    have h_sum_pos : 0 < ∑ j, |p_star j| ^ q := by
      have h_le := Finset.single_le_sum (f := fun j => |p_star j| ^ q)
        (s := Finset.univ) (a := j₀)
        (fun k _ => h_each_nn k) (Finset.mem_univ j₀)
      linarith
    unfold lqNorm
    exact Real.rpow_pos_of_pos h_sum_pos _
  have hp_norm_ne : lqNorm q p_star ≠ 0 := ne_of_gt hp_norm_pos
  -- lqNorm q (p_star - f) > 0 because |p_star j₀ - f j₀| > 0
  have hpf_norm_pos : 0 < lqNorm q (fun k => p_star k - f k) := by
    -- p_star j₀ < 0 ≤ f j₀, so p_star j₀ - f j₀ < 0
    have h_sub_neg : p_star j₀ - f j₀ < 0 := by
      have := hf_nn j₀
      linarith
    have h_sub_ne : p_star j₀ - f j₀ ≠ 0 := ne_of_lt h_sub_neg
    have h_abs_pos : 0 < |p_star j₀ - f j₀| := abs_pos.mpr h_sub_ne
    have h_each_nn : ∀ j, 0 ≤ |p_star j - f j| ^ q :=
      fun j => Real.rpow_nonneg (abs_nonneg _) q
    have h_j₀_pow_pos : 0 < |p_star j₀ - f j₀| ^ q := Real.rpow_pos_of_pos h_abs_pos q
    have h_sum_pos : 0 < ∑ j, |p_star j - f j| ^ q := by
      have h_le := Finset.single_le_sum (f := fun j => |p_star j - f j| ^ q)
        (s := Finset.univ) (a := j₀)
        (fun k _ => h_each_nn k) (Finset.mem_univ j₀)
      linarith
    unfold lqNorm
    exact Real.rpow_pos_of_pos h_sum_pos _
  have hpf_norm_ne : lqNorm q (fun k => p_star k - f k) ≠ 0 := ne_of_gt hpf_norm_pos
  -- Define c'
  set c' : ℝ := Real.rpow lambda (1 / (q - 1)) * lqNorm q (fun k => p_star k - f k) / lqNorm q p_star with hc'_def
  have hlam_pow_pos : 0 < Real.rpow lambda (1 / (q - 1)) := Real.rpow_pos_of_pos hlam0 _
  have hc'_pos : 0 < c' := by
    rw [hc'_def]
    exact div_pos (mul_pos hlam_pow_pos hpf_norm_pos) hp_norm_pos
  -- Step 5.2.5: equation (⋆_-) on T (using InteriorFOC_Neg)
  -- For j ∈ T, derive (f j - p_star j) / (-(p_star j)) = c'
  have hFOC_eq : ∀ j ∈ T, (f j - p_star j) / (-(p_star j)) = c' := by
    intro j hjT
    have hp_j_neg : p_star j < 0 := (hT_mem j).mp hjT
    have hsig_j : sigma_i j = -1 := hsig_neg j
    -- Apply InteriorFOC_Neg
    have hFOC := InteriorFOC_Neg q hq lambda hlam0 hlam1 hd f hf_nn hf_sum sigma_i hsigma_pm
        p_star hp_in hp_loc hpf_norm_pos hp_norm_pos j hsig_j hp_j_neg
    -- hFOC : (f j - p_star j)^(q-1) / N1^(q-1) = lambda * ((-(p_star j))^(q-1) / N2^(q-1))
    -- where N1 = lqNorm q (fun k => p_star k - f k), N2 = lqNorm q p_star
    set N1 : ℝ := lqNorm q (fun k => p_star k - f k) with hN1
    set N2 : ℝ := lqNorm q p_star with hN2
    have hA_pos : 0 < f j - p_star j := by
      have := hf_nn j
      linarith
    have hB_pos : 0 < -(p_star j) := by linarith
    have hN1_pos : 0 < N1 := hpf_norm_pos
    have hN2_pos : 0 < N2 := hp_norm_pos
    have hA_q1_pos : 0 < (f j - p_star j) ^ (q - 1) := Real.rpow_pos_of_pos hA_pos _
    have hB_q1_pos : 0 < (-(p_star j)) ^ (q - 1) := Real.rpow_pos_of_pos hB_pos _
    have hN1_q1_pos : 0 < N1 ^ (q - 1) := Real.rpow_pos_of_pos hN1_pos _
    have hN2_q1_pos : 0 < N2 ^ (q - 1) := Real.rpow_pos_of_pos hN2_pos _
    -- Manipulate hFOC: cross-multiply
    -- A^(q-1) / N1^(q-1) = lambda * (B^(q-1) / N2^(q-1))
    -- A^(q-1) * N2^(q-1) = lambda * B^(q-1) * N1^(q-1)
    -- (A/B)^(q-1) = lambda * (N1/N2)^(q-1)
    -- = (lambda^(1/(q-1)))^(q-1) * (N1/N2)^(q-1)
    -- = (lambda^(1/(q-1)) * N1/N2)^(q-1) = (c')^(q-1)
    have h_eq1 : ((f j - p_star j) / (-(p_star j))) ^ (q - 1) = c' ^ (q - 1) := by
      -- Step 1: (f j - p_star j) / (-(p_star j)) ^(q-1) = ((f j - p_star j)^(q-1)) / ((-(p_star j))^(q-1))
      have hA_nn : 0 ≤ f j - p_star j := le_of_lt hA_pos
      have hB_nn : 0 ≤ -(p_star j) := le_of_lt hB_pos
      have hN1_nn : 0 ≤ N1 := le_of_lt hN1_pos
      have hN2_nn : 0 ≤ N2 := le_of_lt hN2_pos
      have hlam_nn : 0 ≤ lambda := le_of_lt hlam0
      have hlam_pow_nn : 0 ≤ Real.rpow lambda (1 / (q - 1)) := le_of_lt hlam_pow_pos
      -- (A/B)^(q-1) = A^(q-1) / B^(q-1)
      rw [Real.div_rpow hA_nn hB_nn]
      -- c'^(q-1) = (lambda^(1/(q-1)) * N1 / N2)^(q-1) = (lambda^(1/(q-1)))^(q-1) * (N1/N2)^(q-1)
      --   = lambda * (N1/N2)^(q-1) = lambda * N1^(q-1) / N2^(q-1)
      have hc'_eq : c' ^ (q - 1)
          = lambda * (N1 ^ (q - 1) / N2 ^ (q - 1)) := by
        rw [hc'_def]
        rw [show Real.rpow lambda (1 / (q - 1)) * N1 / N2
            = (Real.rpow lambda (1 / (q - 1)) * N1) * (N2)⁻¹ by ring]
        -- ((λ^{1/(q-1)} * N1) * N2⁻¹)^(q-1) = (λ^{1/(q-1)})^(q-1) * N1^(q-1) * (N2⁻¹)^(q-1)
        --   = λ * N1^(q-1) * N2^(-1*(q-1)) -- wait, easier to use Real.div_rpow & Real.mul_rpow
        rw [show Real.rpow lambda (1 / (q - 1)) * N1 * N2⁻¹
            = (Real.rpow lambda (1 / (q - 1)) * N1) / N2 by ring]
        rw [Real.div_rpow (mul_nonneg hlam_pow_nn hN1_nn) hN2_nn]
        rw [Real.mul_rpow hlam_pow_nn hN1_nn]
        -- (λ^{1/(q-1)})^(q-1) = λ
        have h_pow : (Real.rpow lambda (1 / (q - 1))) ^ (q - 1) = lambda := by
          show (lambda ^ (1 / (q - 1) : ℝ)) ^ (q - 1 : ℝ) = lambda
          rw [← Real.rpow_mul hlam_nn]
          rw [show (1/(q-1) : ℝ) * (q-1) = 1 from by field_simp]
          exact Real.rpow_one _
        rw [h_pow]
        ring
      rw [hc'_eq]
      -- Now we have A^(q-1) / B^(q-1) = lambda * (N1^(q-1) / N2^(q-1))
      -- From hFOC : A^(q-1) / N1^(q-1) = lambda * (B^(q-1) / N2^(q-1))
      -- Need: A^(q-1) / B^(q-1) = lambda * N1^(q-1) / N2^(q-1)
      -- From hFOC: A^(q-1) * N2^(q-1) = lambda * B^(q-1) * N1^(q-1) (cross multiply)
      -- Divide both sides by B^(q-1) * N2^(q-1): A^(q-1)/B^(q-1) = lambda * N1^(q-1) / N2^(q-1)
      have hN1_q1_ne : N1 ^ (q - 1) ≠ 0 := ne_of_gt hN1_q1_pos
      have hN2_q1_ne : N2 ^ (q - 1) ≠ 0 := ne_of_gt hN2_q1_pos
      have hB_q1_ne : (-(p_star j)) ^ (q - 1) ≠ 0 := ne_of_gt hB_q1_pos
      field_simp at hFOC
      field_simp
      linarith
    -- Now A/B and c' are both positive; their (q-1)-th powers are equal
    have hAB_pos : 0 < (f j - p_star j) / (-(p_star j)) := div_pos hA_pos hB_pos
    have hAB_nn : 0 ≤ (f j - p_star j) / (-(p_star j)) := le_of_lt hAB_pos
    have hc'_nn : 0 ≤ c' := le_of_lt hc'_pos
    exact (Real.rpow_left_inj hAB_nn hc'_nn hq1_ne).mp h_eq1
  -- Step 5.2.6: c' > 1, derived directly from the witness j₀ ∈ T.
  -- FOC at j₀ gives (f j₀ - p_star j₀) / (-(p_star j₀)) = c'; since f j₀ > 0
  -- (by hf_pos) the numerator exceeds the denominator, forcing c' > 1.
  have hFOC_j0 : (f j₀ - p_star j₀) / (-(p_star j₀)) = c' := hFOC_eq j₀ hj₀_T
  have hB_j0_pos : 0 < -(p_star j₀) := by linarith
  have hc'_gt1 : 1 < c' := by
    rw [← hFOC_j0]
    rw [lt_div_iff₀ hB_j0_pos]
    linarith [hf_pos j₀]
  -- Step 5.2.7: closed form -p_star j = f j / (c' - 1) for j ∈ T
  have hc'1_pos : 0 < c' - 1 := by linarith
  have hc'1_ne : c' - 1 ≠ 0 := ne_of_gt hc'1_pos
  have heqT : ∀ j ∈ T, -(p_star j) = f j / (c' - 1) := by
    intro j hjT
    have hp_j_neg : p_star j < 0 := (hT_mem j).mp hjT
    have hB_j_pos : 0 < -(p_star j) := by linarith
    have hB_j_ne : -(p_star j) ≠ 0 := ne_of_gt hB_j_pos
    have h_eq := hFOC_eq j hjT
    -- (f j - p_star j) / (-(p_star j)) = c'
    -- ⇒ f j - p_star j = c' * (-(p_star j))
    have h1 : f j - p_star j = c' * (-(p_star j)) := by
      have := (div_eq_iff hB_j_ne).mp h_eq
      linarith
    -- f j = c' * (-(p_star j)) + p_star j = (c' - 1) * (-(p_star j))
    have h2 : f j = (c' - 1) * (-(p_star j)) := by linarith
    -- Hence -(p_star j) = f j / (c' - 1)
    rw [h2]
    field_simp
  -- Step 5.2.8: For j ∉ T, p_star j = 0
  have heqTc : ∀ j ∉ T, p_star j = 0 := by
    intro j hjnotT
    have hnot_lt : ¬ p_star j < 0 := by
      intro h_lt
      exact hjnotT ((hT_mem j).mpr h_lt)
    have h_ge : 0 ≤ p_star j := not_lt.mp hnot_lt
    exact le_antisymm (hpstar_le j) h_ge
  -- Assemble
  exact ⟨T, c', hc'_gt1, heqT, heqTc, hpstar_le⟩

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

namespace LocalOptimumCharacterizationProof

open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists

theorem case_S_nonempty
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧
                  (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧
                (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (S : Finset (Fin d))
    (hS_def : S = Finset.univ.filter (fun j : Fin d => sigma_i j = 1))
    (hS_ne : S.Nonempty) :
    ∃ c : ℝ, 0 ≤ c ∧ c < 1 ∧
      (∀ j ∈ S, p_star j = f j / (1 - c)) ∧
      (∀ j ∉ S, p_star j = 0) :=
  LocalOptimumCharacterization_CaseSNonempty q hq lambda hlam0 hlam1 hd f hf_nn hf_pos hf_sum
    sigma_i hsigma_pm p_star hp_in hp_loc S hS_def hS_ne

theorem case_S_empty
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧
                  (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧
                (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p)
    (S : Finset (Fin d))
    (hS_def : S = Finset.univ.filter (fun j : Fin d => sigma_i j = 1))
    (hS_eq : S = ∅) :
    ∃ T : Finset (Fin d), ∃ c' : ℝ, 1 < c' ∧
      (∀ j ∈ T, -(p_star j) = f j / (c' - 1)) ∧
      (∀ j ∉ T, p_star j = 0) ∧
      (∀ j, p_star j ≤ 0) :=
  LocalOptimumCharacterization_CaseSEmpty q hq lambda hlam0 hlam1 hd f hf_nn hf_pos hf_sum
    sigma_i hsigma_pm p_star hp_in hp_loc S hS_def hS_eq

end LocalOptimumCharacterizationProof

open LocalOptimumCharacterizationProof

open Classical in
theorem LocalOptimumCharacterization
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j, (sigma_i j = 1 → 0 ≤ p_star j) ∧ (sigma_i j = -1 → p_star j ≤ 0))
    (hp_loc :
      ∃ ε > (0 : ℝ),
        ∀ p : Fin d → ℝ,
          (∀ j, (sigma_i j = 1 → 0 ≤ p j) ∧ (sigma_i j = -1 → p j ≤ 0)) →
          (∀ j, |p j - p_star j| < ε) →
          g_lambda q lambda f p_star ≤ g_lambda q lambda f p) :
    let S := Finset.univ.filter (fun j : Fin d => sigma_i j = 1)
    ( S.Nonempty ∧ ∃ c : ℝ, 0 ≤ c ∧ c < 1 ∧
        (∀ j ∈ S, p_star j = f j / (1 - c)) ∧
        (∀ j ∉ S, p_star j = 0) )
    ∨
    ( S = ∅ ∧ ∃ T : Finset (Fin d), ∃ c' : ℝ, 1 < c' ∧
        (∀ j ∈ T, -(p_star j) = f j / (c' - 1)) ∧
        (∀ j ∉ T, p_star j = 0) ∧
        (∀ j, p_star j ≤ 0) ) := by
  -- Set up the abbreviation `S := {j : σ_j = +1}` introduced by the `let`
  -- in the goal.
  intro S
  -- The proof distinguishes the two cases of paper Lemma 2:
  --   case (i):  S ≠ ∅, with closed form p_j = f_j/(1-c) on S;
  --   case (ii): S = ∅, with closed form -p_j = f_j/(c'-1) on T.
  by_cases hS : S.Nonempty
  · -- **Case (i): S ≠ ∅.** Apply step (a) to get c.
    left
    refine ⟨hS, ?_⟩
    exact case_S_nonempty q hq lambda hlam0 hlam1 hd f hf_nn hf_pos hf_sum
            sigma_i hsigma_pm p_star hp_in hp_loc S rfl hS
  · -- **Case (ii): S = ∅.** Apply step (b) to get T, c'.
    right
    have hS_eq : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hS
    refine ⟨hS_eq, ?_⟩
    exact case_S_empty q hq lambda hlam0 hlam1 hd f hf_nn hf_pos hf_sum
            sigma_i hsigma_pm p_star hp_in hp_loc S rfl hS_eq

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists
open Workspace.ProofLemmas.LambdaDeltaIdentity

namespace LocalMinEmptyS_Aux2

/-- Helper: For w ≥ 0, q > 1, lambda ∈ (0,1), with K = (1 - lambda^(q/(q-1)))^((q-1)/q),
    we have `(w^q + 1)^(1/q) ≥ K + lambda * w`. Proven via 2-component Hölder. -/
lemma key_holder_one_dim
    {q : ℝ} (hq : 1 < q) {lambda : ℝ} (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {w : ℝ} (hw : 0 ≤ w) :
    (1 - lambda ^ (q / (q - 1))) ^ ((q - 1) / q) + lambda * w
      ≤ (w ^ q + 1) ^ ((1 : ℝ) / q) := by
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_sub_pos : 0 < q - 1 := by linarith
  have hq_sub_ne : q - 1 ≠ 0 := ne_of_gt hq_sub_pos
  set p : ℝ := q / (q - 1) with hp_def
  have hp_pos : 0 < p := by simp [hp_def]; exact div_pos hq_pos hq_sub_pos
  have hp_ne : p ≠ 0 := ne_of_gt hp_pos
  have hp_gt1 : 1 < p := by
    rw [hp_def]
    rw [lt_div_iff₀ hq_sub_pos]
    linarith
  have hpinv_q : p⁻¹ + q⁻¹ = 1 := by
    rw [hp_def]
    field_simp
    ring
  have h_hc : Real.HolderConjugate p q := by
    rw [Real.holderConjugate_iff]
    exact ⟨hp_gt1, hpinv_q⟩
  -- lambda^p = lambda^(q/(q-1))
  set lp : ℝ := lambda ^ p with hlp_def
  have hlam_nn : (0 : ℝ) ≤ lambda := le_of_lt hlam0
  have hlp_pos : 0 < lp := Real.rpow_pos_of_pos hlam0 _
  have hlp_nn : 0 ≤ lp := le_of_lt hlp_pos
  -- lambda^p ≤ 1
  have hlp_le_one : lp ≤ 1 := by
    rw [hlp_def]
    have h1 : lambda ^ p ≤ lambda ^ (0 : ℝ) := by
      apply Real.rpow_le_rpow_of_exponent_ge hlam0 (le_of_lt hlam1)
      linarith
    simpa using h1
  have h_one_sub_lp_nn : 0 ≤ 1 - lp := by linarith
  -- K = (1 - lp)^((q-1)/q)
  set K : ℝ := (1 - lp) ^ ((q - 1) / q) with hK_def
  have hK_nn : 0 ≤ K := Real.rpow_nonneg h_one_sub_lp_nn _
  let fH : Fin 2 → ℝ := fun i => if i = 0 then lambda else K
  let gH : Fin 2 → ℝ := fun i => if i = 0 then w else 1
  have hfH_nn : ∀ i ∈ (Finset.univ : Finset (Fin 2)), 0 ≤ fH i := by
    intro i _
    fin_cases i
    · simp [fH]; exact hlam_nn
    · simp [fH]; exact hK_nn
  have hgH_nn : ∀ i ∈ (Finset.univ : Finset (Fin 2)), 0 ≤ gH i := by
    intro i _
    fin_cases i
    · simp [gH]; exact hw
    · simp [gH]
  have hHolder := Real.inner_le_Lp_mul_Lq_of_nonneg
    (Finset.univ : Finset (Fin 2)) h_hc hfH_nn hgH_nn
  -- Compute the sums explicitly
  have hsum_fg : ∑ i, fH i * gH i = lambda * w + K * 1 := by
    rw [Fin.sum_univ_two]
    simp [fH, gH]
  have hsum_f : ∑ i, fH i ^ p = lambda ^ p + K ^ p := by
    rw [Fin.sum_univ_two]
    simp [fH]
  have hsum_g : ∑ i, gH i ^ q = w ^ q + 1 ^ q := by
    rw [Fin.sum_univ_two]
    simp [gH]
  rw [hsum_fg, hsum_f, hsum_g] at hHolder
  -- Show lambda^p + K^p = 1.
  have hKp : K ^ p = 1 - lp := by
    rw [hK_def]
    rw [← Real.rpow_mul h_one_sub_lp_nn]
    have hprod : ((q - 1) / q) * p = 1 := by
      rw [hp_def]; field_simp
    rw [hprod, Real.rpow_one]
  have hsum_one : lambda ^ p + K ^ p = 1 := by
    rw [hKp, ← hlp_def]; ring
  rw [hsum_one] at hHolder
  have h_one_pinv : (1 : ℝ) ^ (1 / p) = 1 := Real.one_rpow _
  rw [h_one_pinv, one_mul] at hHolder
  have h_one_q : (1 : ℝ) ^ q = 1 := Real.one_rpow _
  rw [h_one_q] at hHolder
  rw [mul_one] at hHolder
  linarith [hHolder]

/-- Helper: For u ≥ v ≥ 0 and q ≥ 1, `u^q ≥ (u-v)^q + v^q`. -/
lemma sub_rpow_le {q : ℝ} (hq : 1 ≤ q) {u v : ℝ} (hv : 0 ≤ v) (huv : v ≤ u) :
    (u - v) ^ q + v ^ q ≤ u ^ q := by
  have h_uvnn : 0 ≤ u - v := by linarith
  have h := Real.add_rpow_le_rpow_add h_uvnn hv hq
  have heq : (u - v) + v = u := by ring
  rw [heq] at h
  exact h

end LocalMinEmptyS_Aux2

open LocalMinEmptyS_Aux2

theorem LocalMinEmptyS
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (T : Finset (Fin d)) (hT_ne : T.Nonempty)
    (c' : ℝ) (hc' : 1 < c')
    (p_star : Fin d → ℝ)
    (hp_in : ∀ j ∈ T, -(p_star j) = f j / (c' - 1))
    (hp_out : ∀ j ∉ T, p_star j = 0)
    (hp_nonpos : ∀ j, p_star j ≤ 0) :
    (1 - lambda ^ (q / (q - 1))) ^ ((q - 1) / q) ≤ g_lambda q lambda f p_star := by
  classical
  have hq_le : 1 ≤ q := le_of_lt hq
  have hq_pos : 0 < q := lt_trans zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_inv_pos : 0 < 1 / q := by positivity
  have hq_inv_nn : 0 ≤ 1 / q := le_of_lt hq_inv_pos
  have hc'_sub_pos : 0 < c' - 1 := by linarith
  have hc'_sub_ne : c' - 1 ≠ 0 := ne_of_gt hc'_sub_pos
  have hc'_pos : 0 < c' := by linarith
  -- Set c = c'/(c'-1) > 1.
  set c : ℝ := c' / (c' - 1) with hc_def
  have hc_pos : 0 < c := div_pos hc'_pos hc'_sub_pos
  have hc_gt1 : 1 < c := by
    rw [hc_def, lt_div_iff₀ hc'_sub_pos]; linarith
  have hc_nn : 0 ≤ c := le_of_lt hc_pos
  have hc_sub1 : c - 1 = 1 / (c' - 1) := by
    rw [hc_def]; field_simp; ring
  -- |p_star j| for j ∈ T equals f j / (c'-1).
  have habs_in : ∀ j ∈ T, |p_star j| = f j / (c' - 1) := by
    intro j hj
    have h1 : -(p_star j) = f j / (c' - 1) := hp_in j hj
    have h2 : p_star j = -(f j / (c' - 1)) := by linarith
    rw [h2, abs_neg]
    have h3 : 0 ≤ f j / (c' - 1) := div_nonneg (hf_nn j) (le_of_lt hc'_sub_pos)
    rw [abs_of_nonneg h3]
  have habs_out : ∀ j ∉ T, |p_star j| = 0 := by
    intro j hj
    rw [hp_out j hj, abs_zero]
  -- |p_star j - f j| for j ∈ T equals f j * c'/(c'-1) = c * f j.
  -- For j ∉ T equals f j.
  have hsub_in : ∀ j ∈ T, |p_star j - f j| = c * f j := by
    intro j hj
    have h1 : -(p_star j) = f j / (c' - 1) := hp_in j hj
    have h2 : p_star j = -(f j / (c' - 1)) := by linarith
    rw [h2]
    have h3 : -(f j / (c' - 1)) - f j = -(f j * (c'/(c'-1))) := by
      field_simp
      ring
    rw [h3, abs_neg]
    have h4 : 0 ≤ f j * c := mul_nonneg (hf_nn j) hc_nn
    have heq : f j * (c'/(c'-1)) = f j * c := by rw [hc_def]
    rw [heq]
    rw [abs_of_nonneg h4]
    ring
  have hsub_out : ∀ j ∉ T, |p_star j - f j| = f j := by
    intro j hj
    rw [hp_out j hj, zero_sub, abs_neg]
    rw [abs_of_nonneg (hf_nn j)]
  -- Define S_T = ∑ j ∈ T, f_j ^ q
  set S_T : ℝ := ∑ j ∈ T, (f j) ^ q with hST_def
  have hST_nn : 0 ≤ S_T := by
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) q
  -- 1 - S_T = ∑ j ∉ T (over univ \ T), f_j ^ q
  have hST_le_one : S_T ≤ 1 := by
    rw [← hf_sum]
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · exact T.subset_univ
    · intro j _ _
      exact Real.rpow_nonneg (hf_nn j) q
  -- Compute lqNorm q p_star ^ q = (c-1)^q * S_T
  have h_pstar_norm_pow : (∑ j, |p_star j| ^ q) = (c - 1) ^ q * S_T := by
    rw [hST_def]
    rw [← Finset.sum_compl_add_sum T (fun j => |p_star j| ^ q)]
    have h_left : ∑ j ∈ Tᶜ, |p_star j| ^ q = 0 := by
      apply Finset.sum_eq_zero
      intro j hj
      have hjT : j ∉ T := Finset.mem_compl.mp hj
      rw [habs_out j hjT]
      exact Real.zero_rpow hq_ne
    rw [h_left, zero_add]
    have h_right : ∑ j ∈ T, |p_star j| ^ q = ∑ j ∈ T, ((c - 1) ^ q) * (f j) ^ q := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [habs_in j hj]
      have h1 : f j / (c' - 1) = (1 / (c' - 1)) * f j := by ring
      rw [h1]
      have h2 : 1 / (c' - 1) = c - 1 := by rw [hc_sub1]
      rw [h2]
      have h_cm1 : 0 ≤ c - 1 := by linarith
      have h_fj : 0 ≤ f j := hf_nn j
      rw [Real.mul_rpow h_cm1 h_fj]
    rw [h_right, ← Finset.mul_sum]
  -- Compute lqNorm q (p_star - f) ^ q = c^q * S_T + (1 - S_T)
  have h_psf_norm_pow : (∑ j, |p_star j - f j| ^ q) = c ^ q * S_T + (1 - S_T) := by
    rw [← Finset.sum_compl_add_sum T (fun j => |p_star j - f j| ^ q)]
    have h_left : ∑ j ∈ Tᶜ, |p_star j - f j| ^ q = 1 - S_T := by
      have heq : ∑ j ∈ Tᶜ, |p_star j - f j| ^ q = ∑ j ∈ Tᶜ, (f j) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        have hjT : j ∉ T := Finset.mem_compl.mp hj
        rw [hsub_out j hjT]
      rw [heq]
      have hsum_split : ∑ j ∈ T, (f j) ^ q + ∑ j ∈ Tᶜ, (f j) ^ q = 1 := by
        rw [add_comm]
        rw [Finset.sum_compl_add_sum T (fun j => (f j) ^ q)]
        exact hf_sum
      linarith [hsum_split, hST_def]
    rw [h_left]
    have h_right : ∑ j ∈ T, |p_star j - f j| ^ q = c ^ q * S_T := by
      have heq : ∑ j ∈ T, |p_star j - f j| ^ q = ∑ j ∈ T, c ^ q * (f j) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        rw [hsub_in j hj]
        rw [Real.mul_rpow hc_nn (hf_nn j)]
      rw [heq, ← Finset.mul_sum]
    rw [h_right]
    ring
  -- Now compute lqNorm q p_star and lqNorm q (p_star - f) using these.
  -- Define u = c * S_T^(1/q), v = S_T^(1/q).
  set v : ℝ := S_T ^ ((1 : ℝ) / q) with hv_def
  have hv_nn : 0 ≤ v := Real.rpow_nonneg hST_nn _
  -- v^q = S_T
  have hv_q : v ^ q = S_T := by
    rw [hv_def, ← Real.rpow_mul hST_nn]
    rw [one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one]
  -- v ≤ 1 since S_T ≤ 1 and (·)^(1/q) is monotone on [0, ∞)
  have hv_le_one : v ≤ 1 := by
    rw [hv_def]
    have h1 : S_T ^ ((1 : ℝ) / q) ≤ (1 : ℝ) ^ ((1 : ℝ) / q) :=
      Real.rpow_le_rpow hST_nn hST_le_one hq_inv_nn
    rw [Real.one_rpow] at h1
    exact h1
  set u : ℝ := c * v with hu_def
  have hu_nn : 0 ≤ u := mul_nonneg hc_nn hv_nn
  have hu_ge_v : v ≤ u := by
    rw [hu_def]
    nlinarith [hv_nn, hc_gt1]
  -- u^q = c^q * v^q = c^q * S_T
  have hu_q : u ^ q = c ^ q * S_T := by
    rw [hu_def, Real.mul_rpow hc_nn hv_nn, hv_q]
  -- lqNorm q (p_star - f) ^ q = u^q + 1 - v^q = u^q + (1 - v^q)
  have h_psf_pow_eq : (∑ j, |p_star j - f j| ^ q) = u ^ q + (1 - v ^ q) := by
    rw [h_psf_norm_pow, hu_q, hv_q]
  -- Bound: u^q ≥ (u-v)^q + v^q  (so u^q + 1 - v^q ≥ (u-v)^q + 1).
  have h_uv_bound : (u - v) ^ q + 1 ≤ u ^ q + (1 - v ^ q) := by
    have h := sub_rpow_le hq_le hv_nn hu_ge_v
    -- h: (u - v)^q + v^q ≤ u^q
    linarith
  -- (∑ j, |p_star j - f j|^q)^(1/q) ≥ ((u-v)^q + 1)^(1/q)
  have h_psf_norm_ge : ((u - v) ^ q + 1) ^ ((1 : ℝ) / q)
                        ≤ (∑ j, |p_star j - f j| ^ q) ^ ((1 : ℝ) / q) := by
    rw [h_psf_pow_eq]
    have h_lhs_nn : 0 ≤ (u - v) ^ q + 1 := by
      have hl1 : 0 ≤ (u - v) ^ q :=
        Real.rpow_nonneg (by linarith) q
      linarith
    exact Real.rpow_le_rpow h_lhs_nn h_uv_bound hq_inv_nn
  -- (∑ j, |p_star j|^q)^(1/q) = (c-1) * S_T^(1/q) = u - v
  have hc_sub1_nn : 0 ≤ c - 1 := by linarith
  have h_pstar_norm_eq : (∑ j, |p_star j| ^ q) ^ ((1 : ℝ) / q) = u - v := by
    rw [h_pstar_norm_pow]
    have hcm1_q_nn : 0 ≤ (c - 1) ^ q := Real.rpow_nonneg hc_sub1_nn _
    rw [Real.mul_rpow hcm1_q_nn hST_nn]
    have h_cm1_qq : ((c - 1) ^ q) ^ ((1 : ℝ) / q) = c - 1 := by
      rw [← Real.rpow_mul hc_sub1_nn]
      rw [mul_one_div, div_self hq_ne, Real.rpow_one]
    rw [h_cm1_qq]
    -- Goal: (c - 1) * S_T ^ (1/q) = u - v
    -- u - v = c * v - v = (c - 1) * v = (c - 1) * S_T^(1/q)
    rw [hu_def, hv_def]
    ring
  -- Now use the key Hölder inequality on w = u - v.
  have h_w_nn : 0 ≤ u - v := by linarith
  have h_key := key_holder_one_dim hq hlam0 hlam1 h_w_nn
  -- h_key: K + lambda * (u - v) ≤ ((u - v)^q + 1)^(1/q)
  -- Combine: K ≤ ((u-v)^q + 1)^(1/q) - lambda*(u-v) ≤ lqNorm q (p_star - f) - lambda*lqNorm q p_star
  -- = g_lambda.
  unfold g_lambda lqNorm
  rw [h_pstar_norm_eq]
  linarith [h_key, h_psf_norm_ge]

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.ProofLemmas.ConstrainedMinExists
open Workspace.ProofLemmas.LambdaDeltaIdentity

theorem GLambdaLowerBound_h
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {d : ℕ} (hd : 1 ≤ d) (f : Fin d → ℝ)
    (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j) (hf_sum : (∑ j, (f j) ^ q) = 1)
    (sigma_i : Fin d → ℝ) (hsigma_pm : ∀ j, sigma_i j = 1 ∨ sigma_i j = -1)
    (p_star : Fin d → ℝ)
    (h_local :
      let S := Finset.univ.filter (fun j : Fin d => sigma_i j = 1)
      ( S.Nonempty ∧ ∃ c : ℝ, 0 ≤ c ∧ c < 1 ∧
          (∀ j ∈ S, p_star j = f j / (1 - c)) ∧
          (∀ j ∉ S, p_star j = 0) )
      ∨
      ( S = ∅ ∧ ∃ T : Finset (Fin d), ∃ c' : ℝ, 1 < c' ∧
          (∀ j ∈ T, -(p_star j) = f j / (c' - 1)) ∧
          (∀ j ∉ T, p_star j = 0) ∧
          (∀ j, p_star j ≤ 0) )) :
    let S := Finset.univ.filter (fun j : Fin d => sigma_i j = 1)
    let x := ∑ j ∈ S, (f j) ^ q
    lambda *
      (delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q) - x ^ ((1 : ℝ) / q))
      ≤ g_lambda q lambda f p_star := by
  classical
  intro S
  intro x
  -- Set up basic positivity / arithmetic facts
  have hq_pos : 0 < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hq_sub_pos : 0 < q - 1 := by linarith
  have hq_sub_ne : q - 1 ≠ 0 := ne_of_gt hq_sub_pos
  have hq_le : (1 : ℝ) ≤ q := le_of_lt hq
  have h_inv_q_pos : 0 < (1 : ℝ) / q := by positivity
  have h_inv_q_nn : 0 ≤ (1 : ℝ) / q := le_of_lt h_inv_q_pos
  have hlam_nn : (0 : ℝ) ≤ lambda := le_of_lt hlam0
  have hlam_le : lambda ≤ 1 := le_of_lt hlam1
  -- r := q / (q - 1)
  set r : ℝ := q / (q - 1) with hr_def
  have hr_pos : 0 < r := div_pos hq_pos hq_sub_pos
  have hr_ne : r ≠ 0 := ne_of_gt hr_pos
  have hlam_r_pos : 0 < lambda ^ r := Real.rpow_pos_of_pos hlam0 _
  have hlam_r_nn : 0 ≤ lambda ^ r := le_of_lt hlam_r_pos
  -- 1 - lambda^r > 0
  have h_lam_r_lt_one : lambda ^ r < 1 := by
    have h1 : lambda ^ r < (1 : ℝ) ^ r :=
      Real.rpow_lt_rpow hlam_nn hlam1 hr_pos
    simpa using h1
  have h_one_sub_pos : 0 < 1 - lambda ^ r := by linarith
  have h_one_sub_nn : 0 ≤ 1 - lambda ^ r := le_of_lt h_one_sub_pos
  -- lambda * delta = (1 - lambda^r)^((q-1)/q)
  have h_lam_delta : lambda * delta_of_lambda q lambda
        = (1 - lambda ^ r) ^ ((q - 1) / q) := by
    have := LambdaDeltaIdentity q hq lambda hlam0 hlam_le
    simpa [hr_def] using this
  -- f j ≥ 0, so |f j| = f j
  have hf_abs : ∀ j, |f j| = f j := fun j => abs_of_nonneg (hf_nn j)
  -- 1 - x = sum over complement of S
  have h_one_sub_x : (1 : ℝ) - x = ∑ j ∈ Sᶜ, (f j) ^ q := by
    have h_split := Finset.sum_compl_add_sum (s := S) (f := fun j => (f j) ^ q)
    have : (∑ j ∈ Sᶜ, (f j) ^ q) + (∑ j ∈ S, (f j) ^ q) = ∑ j, (f j) ^ q := by
      simpa using h_split
    rw [hf_sum] at this
    linarith
  -- x ≥ 0, 1 - x ≥ 0
  have hx_nn : 0 ≤ x := by
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) q
  have h_one_sub_x_nn : 0 ≤ 1 - x := by
    rw [h_one_sub_x]
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) q
  -- Now do the case split
  rcases h_local with ⟨hS_ne, c, hc0, hc1, hp_in, hp_out⟩ | ⟨hS_emp, hcase2⟩
  · -- Case (i): S nonempty
    have h1c_pos : 0 < 1 - c := by linarith
    have h1c_ne : 1 - c ≠ 0 := ne_of_gt h1c_pos
    have h1c_nn : 0 ≤ 1 - c := le_of_lt h1c_pos
    have hc_nn : 0 ≤ c := hc0
    have h_c_over : 0 ≤ c / (1 - c) := div_nonneg hc_nn h1c_nn
    -- For j ∈ S: |p_star j|^q = f j^q / (1-c)^q
    have h_ps_in : ∀ j ∈ S, |p_star j| ^ q = (f j) ^ q / (1 - c) ^ q := by
      intro j hj
      have h_eq : p_star j = f j / (1 - c) := hp_in j hj
      have h_nn : 0 ≤ p_star j := by
        rw [h_eq]; exact div_nonneg (hf_nn j) h1c_nn
      rw [abs_of_nonneg h_nn, h_eq]
      rw [Real.div_rpow (hf_nn j) h1c_nn]
    -- For j ∈ S: |p_star j - f j|^q = (c/(1-c))^q * f j^q
    have h_ps_diff_in : ∀ j ∈ S, |p_star j - f j| ^ q
        = (c / (1 - c)) ^ q * (f j) ^ q := by
      intro j hj
      have h_eq : p_star j = f j / (1 - c) := hp_in j hj
      have h_diff : p_star j - f j = f j * (c / (1 - c)) := by
        rw [h_eq]; field_simp; ring
      have h_diff_nn : 0 ≤ p_star j - f j := by
        rw [h_diff]; exact mul_nonneg (hf_nn j) h_c_over
      rw [abs_of_nonneg h_diff_nn, h_diff]
      rw [Real.mul_rpow (hf_nn j) h_c_over]
      ring
    -- For j ∉ S: |p_star j|^q = 0
    have h_ps_out : ∀ j ∉ S, |p_star j| ^ q = 0 := by
      intro j hj
      rw [hp_out j hj, abs_zero, Real.zero_rpow hq_ne]
    -- For j ∉ S: |p_star j - f j|^q = f j^q
    have h_ps_diff_out : ∀ j ∉ S, |p_star j - f j| ^ q = (f j) ^ q := by
      intro j hj
      rw [hp_out j hj, zero_sub, abs_neg, hf_abs j]
    -- Compute sum |p_star|^q
    have h_sum_ps : (∑ j, |p_star j| ^ q) = x / (1 - c) ^ q := by
      have hsplit := Finset.sum_compl_add_sum (s := S) (f := fun j => |p_star j| ^ q)
      have hSc : (∑ j ∈ Sᶜ, |p_star j| ^ q) = 0 := by
        apply Finset.sum_eq_zero
        intro j hj
        have hj' : j ∉ S := by
          intro hjS
          exact (Finset.mem_compl.mp hj) hjS
        exact h_ps_out j hj'
      have hSi : (∑ j ∈ S, |p_star j| ^ q) = ∑ j ∈ S, (f j) ^ q / (1 - c) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        exact h_ps_in j hj
      have h_total : (∑ j, |p_star j| ^ q) = ∑ j ∈ S, (f j) ^ q / (1 - c) ^ q := by
        calc (∑ j, |p_star j| ^ q)
            = (∑ j ∈ Sᶜ, |p_star j| ^ q) + (∑ j ∈ S, |p_star j| ^ q) := hsplit.symm
          _ = 0 + (∑ j ∈ S, |p_star j| ^ q) := by rw [hSc]
          _ = ∑ j ∈ S, |p_star j| ^ q := by rw [zero_add]
          _ = ∑ j ∈ S, (f j) ^ q / (1 - c) ^ q := hSi
      rw [h_total]
      rw [show x = ∑ j ∈ S, (f j) ^ q from rfl]
      rw [← Finset.sum_div]
    -- Compute sum |p_star - f|^q
    have h_sum_ps_diff : (∑ j, |p_star j - f j| ^ q)
        = (c / (1 - c)) ^ q * x + (1 - x) := by
      have hsplit := Finset.sum_compl_add_sum (s := S) (f := fun j => |p_star j - f j| ^ q)
      have hSc : (∑ j ∈ Sᶜ, |p_star j - f j| ^ q) = ∑ j ∈ Sᶜ, (f j) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        have hj' : j ∉ S := by
          intro hjS
          exact (Finset.mem_compl.mp hj) hjS
        exact h_ps_diff_out j hj'
      have hSi : (∑ j ∈ S, |p_star j - f j| ^ q)
          = ∑ j ∈ S, (c / (1 - c)) ^ q * (f j) ^ q := by
        apply Finset.sum_congr rfl
        intro j hj
        exact h_ps_diff_in j hj
      have h_total : (∑ j, |p_star j - f j| ^ q)
          = (∑ j ∈ Sᶜ, (f j) ^ q) + (c / (1 - c)) ^ q * x := by
        calc (∑ j, |p_star j - f j| ^ q)
            = (∑ j ∈ Sᶜ, |p_star j - f j| ^ q) + (∑ j ∈ S, |p_star j - f j| ^ q) :=
              hsplit.symm
          _ = (∑ j ∈ Sᶜ, (f j) ^ q) + (∑ j ∈ S, (c / (1 - c)) ^ q * (f j) ^ q) := by
              rw [hSc, hSi]
          _ = (∑ j ∈ Sᶜ, (f j) ^ q) + (c / (1 - c)) ^ q * (∑ j ∈ S, (f j) ^ q) := by
              rw [Finset.mul_sum]
          _ = (∑ j ∈ Sᶜ, (f j) ^ q) + (c / (1 - c)) ^ q * x := rfl
      rw [h_total]
      rw [show (∑ j ∈ Sᶜ, (f j) ^ q) = 1 - x from h_one_sub_x.symm]
      ring
    -- Compute lqNorm q p_star = x^(1/q) / (1-c)
    have h_norm_ps : lqNorm q p_star = x ^ ((1 : ℝ) / q) / (1 - c) := by
      unfold lqNorm
      rw [h_sum_ps]
      rw [Real.div_rpow hx_nn (Real.rpow_nonneg h1c_nn q)]
      have h_pow : ((1 - c) ^ q) ^ ((1 : ℝ) / q) = 1 - c := by
        rw [← Real.rpow_mul h1c_nn]
        rw [mul_one_div, div_self hq_ne, Real.rpow_one]
      rw [h_pow]
    -- Compute lqNorm q (p_star - f) = ((c/(1-c))^q * x + (1-x))^(1/q)
    have h_norm_psf : lqNorm q (fun j => p_star j - f j)
        = ((c / (1 - c)) ^ q * x + (1 - x)) ^ ((1 : ℝ) / q) := by
      unfold lqNorm
      rw [h_sum_ps_diff]
    -- g_lambda q lambda f p_star
    have h_g : g_lambda q lambda f p_star
        = ((c / (1 - c)) ^ q * x + (1 - x)) ^ ((1 : ℝ) / q)
            - lambda * (x ^ ((1 : ℝ) / q) / (1 - c)) := by
      unfold g_lambda
      rw [h_norm_ps, h_norm_psf]
    -- Apply two-term Hölder
    -- HolderConjugate q r where r = q/(q-1)
    have hr_q_conj : (q : ℝ).HolderConjugate r := by
      rw [Real.holderConjugate_iff]
      refine ⟨hq, ?_⟩
      rw [hr_def]
      field_simp
      ring
    -- Define vectors A and B
    -- A 0 = (c/(1-c)) * x^(1/q),  A 1 = (1-x)^(1/q)
    -- B 0 = lambda,                B 1 = (1 - lambda^r)^((q-1)/q)
    -- ∑ A*B ≤ (∑|A|^q)^(1/q) * (∑|B|^r)^(1/r)
    have h_x_inv_q_nn : 0 ≤ x ^ ((1 : ℝ) / q) := Real.rpow_nonneg hx_nn _
    have h_one_x_inv_q_nn : 0 ≤ (1 - x) ^ ((1 : ℝ) / q) :=
      Real.rpow_nonneg h_one_sub_x_nn _
    have h_lamr_pow_nn : 0 ≤ (1 - lambda ^ r) ^ ((q - 1) / q) :=
      Real.rpow_nonneg h_one_sub_nn _
    let A : Fin 2 → ℝ := fun i => if i = 0 then (c / (1 - c)) * x ^ ((1 : ℝ) / q)
                                  else (1 - x) ^ ((1 : ℝ) / q)
    let B : Fin 2 → ℝ := fun i => if i = 0 then lambda
                                  else (1 - lambda ^ r) ^ ((q - 1) / q)
    have hA0 : A 0 = (c / (1 - c)) * x ^ ((1 : ℝ) / q) := by simp [A]
    have hA1 : A 1 = (1 - x) ^ ((1 : ℝ) / q) := by simp [A]
    have hB0 : B 0 = lambda := by simp [B]
    have hB1 : B 1 = (1 - lambda ^ r) ^ ((q - 1) / q) := by simp [B]
    -- ∑ A*B
    have h_sum_AB : (∑ i, A i * B i)
        = (c / (1 - c)) * x ^ ((1 : ℝ) / q) * lambda
            + (1 - x) ^ ((1 : ℝ) / q) * (1 - lambda ^ r) ^ ((q - 1) / q) := by
      rw [Fin.sum_univ_two, hA0, hA1, hB0, hB1]
    -- ∑ |A i|^q
    have h_A0_nn : 0 ≤ A 0 := by
      rw [hA0]; exact mul_nonneg h_c_over h_x_inv_q_nn
    have h_A1_nn : 0 ≤ A 1 := by
      rw [hA1]; exact h_one_x_inv_q_nn
    have h_B0_nn : 0 ≤ B 0 := by rw [hB0]; exact hlam_nn
    have h_B1_nn : 0 ≤ B 1 := by rw [hB1]; exact h_lamr_pow_nn
    have h_pow_xinvq : (x ^ ((1 : ℝ) / q)) ^ q = x := by
      rw [← Real.rpow_mul hx_nn, one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one]
    have h_pow_oneminusx : ((1 - x) ^ ((1 : ℝ) / q)) ^ q = 1 - x := by
      rw [← Real.rpow_mul h_one_sub_x_nn, one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one]
    have h_sum_Aq : (∑ i, |A i| ^ q) = (c / (1 - c)) ^ q * x + (1 - x) := by
      rw [Fin.sum_univ_two]
      rw [hA0, hA1]
      rw [abs_of_nonneg (mul_nonneg h_c_over h_x_inv_q_nn)]
      rw [abs_of_nonneg h_one_x_inv_q_nn]
      rw [Real.mul_rpow h_c_over h_x_inv_q_nn]
      rw [h_pow_xinvq, h_pow_oneminusx]
    -- ∑ |B i|^r
    have h_pow_lamr : ((1 - lambda ^ r) ^ ((q - 1) / q)) ^ r = 1 - lambda ^ r := by
      rw [← Real.rpow_mul h_one_sub_nn]
      have h_prod : (q - 1) / q * r = 1 := by
        rw [hr_def]; field_simp
      rw [h_prod, Real.rpow_one]
    have h_sum_Br : (∑ i, |B i| ^ r) = 1 := by
      rw [Fin.sum_univ_two]
      rw [hB0, hB1]
      rw [abs_of_nonneg hlam_nn]
      rw [abs_of_nonneg h_lamr_pow_nn]
      rw [h_pow_lamr]
      linarith
    -- Apply Hölder
    have h_holder := Real.inner_le_Lp_mul_Lq Finset.univ A B hr_q_conj
    rw [h_sum_AB, h_sum_Aq, h_sum_Br] at h_holder
    have h_one_rpow : (1 : ℝ) ^ ((1 : ℝ) / r) = 1 := Real.one_rpow _
    rw [h_one_rpow, mul_one] at h_holder
    -- h_holder: (c/(1-c))*x^(1/q)*lambda + (1-x)^(1/q)*(1-lambda^r)^((q-1)/q)
    --           ≤ ((c/(1-c))^q * x + (1-x))^(1/q)
    rw [h_g]
    -- Goal: lambda * (delta * (1-x)^(1/q) - x^(1/q))
    --      ≤ ((c/(1-c))^q * x + (1-x))^(1/q) - lambda * (x^(1/q)/(1-c))
    -- Step: rewrite LHS using h_lam_delta
    have h_LHS : lambda * (delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q)
          - x ^ ((1 : ℝ) / q))
        = (1 - lambda ^ r) ^ ((q - 1) / q) * (1 - x) ^ ((1 : ℝ) / q)
            - lambda * x ^ ((1 : ℝ) / q) := by
      have h1 : lambda * delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q)
            = (1 - lambda ^ r) ^ ((q - 1) / q) * (1 - x) ^ ((1 : ℝ) / q) := by
        rw [h_lam_delta]
      have h2 : lambda * (delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q)
            - x ^ ((1 : ℝ) / q))
          = lambda * delta_of_lambda q lambda * (1 - x) ^ ((1 : ℝ) / q)
              - lambda * x ^ ((1 : ℝ) / q) := by ring
      rw [h2, h1]
    rw [h_LHS]
    -- Now need to show:
    -- (1-lambda^r)^((q-1)/q) * (1-x)^(1/q) - lambda * x^(1/q)
    -- ≤ ((c/(1-c))^q*x + (1-x))^(1/q) - lambda * (x^(1/q)/(1-c))
    -- Equivalently: lambda*(x^(1/q)/(1-c)) - lambda * x^(1/q)
    --            ≤ ((c/(1-c))^q*x + (1-x))^(1/q) - (1-lambda^r)^((q-1)/q)*(1-x)^(1/q)
    -- And: lambda*(x^(1/q)/(1-c)) - lambda*x^(1/q) = lambda * x^(1/q) * c/(1-c)
    --                                              = (c/(1-c)) * x^(1/q) * lambda
    -- So we need ((c/(1-c)) * x^(1/q) * lambda) + (1-lambda^r)^((q-1)/q) * (1-x)^(1/q)
    --           ≤ ((c/(1-c))^q*x + (1-x))^(1/q)
    -- which is h_holder (with the second term reordered).
    have h_eq_form : lambda * (x ^ ((1 : ℝ) / q) / (1 - c)) - lambda * x ^ ((1 : ℝ) / q)
        = (c / (1 - c)) * x ^ ((1 : ℝ) / q) * lambda := by
      have : x ^ ((1 : ℝ) / q) / (1 - c) - x ^ ((1 : ℝ) / q)
          = (c / (1 - c)) * x ^ ((1 : ℝ) / q) := by
        field_simp; ring
      have hmul : lambda * (x ^ ((1 : ℝ) / q) / (1 - c) - x ^ ((1 : ℝ) / q))
          = lambda * ((c / (1 - c)) * x ^ ((1 : ℝ) / q)) := by
        rw [this]
      have hl : lambda * (x ^ ((1 : ℝ) / q) / (1 - c) - x ^ ((1 : ℝ) / q))
          = lambda * (x ^ ((1 : ℝ) / q) / (1 - c)) - lambda * x ^ ((1 : ℝ) / q) := by ring
      have hr : lambda * ((c / (1 - c)) * x ^ ((1 : ℝ) / q))
          = (c / (1 - c)) * x ^ ((1 : ℝ) / q) * lambda := by ring
      linarith [hmul, hl, hr]
    linarith [h_holder, h_eq_form]
  · -- Case (ii): S = ∅
    -- x = 0 in this case
    have hx_zero : x = 0 := by
      show (∑ j ∈ S, (f j) ^ q) = 0
      have : S = ∅ := hS_emp
      rw [this, Finset.sum_empty]
    obtain ⟨T, c', hc'_lt, hp_in, hp_out, hp_nonpos⟩ := hcase2
    rw [hx_zero]
    have h_one_sub_zero : (1 : ℝ) - 0 = 1 := by ring
    rw [h_one_sub_zero]
    have h_one_pow : (1 : ℝ) ^ ((1 : ℝ) / q) = 1 := Real.one_rpow _
    have h_zero_pow : (0 : ℝ) ^ ((1 : ℝ) / q) = 0 :=
      Real.zero_rpow (ne_of_gt h_inv_q_pos)
    rw [h_one_pow, h_zero_pow]
    have h_calc : lambda * (delta_of_lambda q lambda * 1 - 0)
        = lambda * delta_of_lambda q lambda := by ring
    rw [h_calc, h_lam_delta]
    rcases Finset.eq_empty_or_nonempty T with hT_emp | hT_ne
    · -- T = ∅ : every p_star j = 0, so g_lambda = 1 and the bound is ≤ 1
      have hp0 : ∀ j, p_star j = 0 := by
        intro j
        exact hp_out j (hT_emp ▸ Finset.notMem_empty j)
      -- g_lambda q lambda f p_star = 1
      have h_g_one : g_lambda q lambda f p_star = 1 := by
        unfold g_lambda
        have h_norm_ps : lqNorm q p_star = 0 := by
          unfold lqNorm
          have : (∑ j, |p_star j| ^ q) = 0 := by
            apply Finset.sum_eq_zero
            intro j _
            rw [hp0 j, abs_zero, Real.zero_rpow hq_ne]
          rw [this, Real.zero_rpow (ne_of_gt h_inv_q_pos)]
        have h_norm_psf : lqNorm q (fun j => p_star j - f j) = 1 := by
          unfold lqNorm
          have hsum : (∑ j, |p_star j - f j| ^ q) = 1 := by
            have : (∑ j, |p_star j - f j| ^ q) = ∑ j, (f j) ^ q := by
              apply Finset.sum_congr rfl
              intro j _
              rw [hp0 j, zero_sub, abs_neg, hf_abs j]
            rw [this, hf_sum]
          rw [hsum, Real.one_rpow]
        rw [h_norm_ps, h_norm_psf]
        ring
      rw [h_g_one]
      -- Goal: (1 - lambda^r)^((q-1)/q) ≤ 1
      apply Real.rpow_le_one h_one_sub_nn (by linarith [hlam_r_nn]) (by positivity)
    · -- T nonempty : existing LocalMinEmptyS path
      have h_min := LocalMinEmptyS q hq lambda hlam0 hlam1 hd f hf_nn hf_sum
          T hT_ne c' hc'_lt p_star hp_in hp_out hp_nonpos
      exact h_min

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost
open Workspace.ConsistencyTheorem
open Workspace.RobustnessTheorem
open Workspace.ProofLemmas.RGDefs
open Workspace.ProofLemmas.ConstrainedMinExists
open Workspace.ProofLemmas.HSecondDerivative
open Workspace.ProofLemmas.LambdaDeltaIdentity

namespace Workspace.ProofLemmas.RGNormalizedCoreInequality

namespace RGNormalizedCoreInequalityProof

-- Auxiliary lemma: lqNorm bounds individual coordinates.
private lemma lqNorm_ge_abs_coord {q : ℝ} (hq : 1 ≤ q) {d : ℕ}
    (x : Fin d → ℝ) (j : Fin d) :
    |x j| ≤ lqNorm q x := by
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have h_inv_pos : 0 < (1 : ℝ) / q := by positivity
  have h_pos : ∀ k, 0 ≤ |x k| ^ q := fun k => Real.rpow_nonneg (abs_nonneg _) q
  have h_le : |x j| ^ q ≤ ∑ k, |x k| ^ q := by
    have := Finset.single_le_sum (f := fun k => |x k| ^ q)
      (s := Finset.univ) (a := j)
      (fun k _ => h_pos k) (Finset.mem_univ j)
    exact this
  have h_lhs_nn : 0 ≤ |x j| ^ q := h_pos j
  have h_rhs_nn : 0 ≤ ∑ k, |x k| ^ q := sum_abs_rpow_nonneg q x
  have h2 : (|x j| ^ q) ^ ((1 : ℝ) / q) ≤ (∑ k, |x k| ^ q) ^ ((1 : ℝ) / q) :=
    Real.rpow_le_rpow h_lhs_nn h_le (le_of_lt h_inv_pos)
  have habs_nn : (0 : ℝ) ≤ |x j| := abs_nonneg _
  have h3 : (|x j| ^ q) ^ ((1 : ℝ) / q) = |x j| := by
    rw [← Real.rpow_mul habs_nn, mul_one_div, div_self hq_ne, Real.rpow_one]
  rw [h3] at h2
  exact h2

-- Continuity of lqNorm
private lemma lqNorm_continuous {q : ℝ} (hq : 1 ≤ q) {d : ℕ} :
    Continuous (fun x : Fin d → ℝ => lqNorm q x) := by
  unfold lqNorm
  have hq_pos : 0 < q := lt_of_lt_of_le zero_lt_one hq
  have h_inv_nn : 0 ≤ (1 : ℝ) / q := by positivity
  have hq_nn : 0 ≤ q := le_of_lt hq_pos
  have h_inner : Continuous (fun x : Fin d → ℝ => ∑ j, |x j| ^ q) := by
    apply continuous_finset_sum
    intro j _
    exact (Real.continuous_rpow_const hq_nn).comp ((continuous_apply j).abs)
  exact (Real.continuous_rpow_const h_inv_nn).comp h_inner

-- Continuity of g_lambda in p
private lemma g_lambda_continuous {q : ℝ} (hq : 1 ≤ q) (lambda : ℝ) {d : ℕ}
    (f : Fin d → ℝ) :
    Continuous (fun p : Fin d → ℝ => g_lambda q lambda f p) := by
  unfold g_lambda
  have h_arg : Continuous (fun p : Fin d → ℝ => fun j => p j - f j) := by
    apply continuous_pi
    intro j
    exact (continuous_apply j).sub continuous_const
  have h1 : Continuous (fun p : Fin d → ℝ => lqNorm q (fun j => p j - f j)) :=
    (lqNorm_continuous hq).comp h_arg
  have h2 : Continuous (fun p : Fin d → ℝ => lqNorm q p) := lqNorm_continuous hq
  exact h1.sub (continuous_const.mul h2)

-- Sum of g_lambda is continuous
private lemma sum_g_lambda_continuous {q : ℝ} (hq : 1 ≤ q) (lambda : ℝ) {n d : ℕ}
    (f : Fin d → ℝ) :
    Continuous (fun p : Fin n → Fin d → ℝ => ∑ i, g_lambda q lambda f (p i)) := by
  apply continuous_finset_sum
  intro i _
  exact (g_lambda_continuous hq lambda f).comp (continuous_apply i)

-- Coercive lower bound
private lemma g_lambda_lower_bound {q : ℝ} (hq : 1 ≤ q) {lambda : ℝ}
    {d : ℕ} (f : Fin d → ℝ) (hf_norm : lqNorm q f = 1) (p : Fin d → ℝ) :
    (1 - lambda) * lqNorm q p - 1 ≤ g_lambda q lambda f p := by
  unfold g_lambda
  have h := LqNormSubReverseTriangle hq p f
  rw [hf_norm] at h
  linarith

/-- **RG constrained-min existence** (constraint-free; the column-sum constraint
is unused in the consistency `CGConstrainedMinExists` / `ConstrainedMinExists`
existence argument, which only needs the `±1` signature). For the worst-case
prediction signature `(−1,…,−1)` the constraint is `∑ σ = ⌊cn⌋`, so neither
`ConstrainedMinExists` (`∑ = 0`) nor `CGConstrainedMinExists` (`∑ = −⌊cn⌋`)
applies directly; we inline the existence proof here as instructed (no new
RG* node file). -/
private theorem rgConstrainedMinExists
    (q : ℝ) (hq : 1 < q) (lambda : ℝ) (hlam0 : 0 < lambda) (hlam1 : lambda < 1)
    {n d : ℕ}
    (f : Fin d → ℝ) (hf_norm : lqNorm q f = 1)
    (sigma_assign : Fin n → Fin d → ℝ)
    (hsigma_pm : ∀ i j, sigma_assign i j = 1 ∨ sigma_assign i j = -1) :
    ∃ p_star : Fin n → Fin d → ℝ,
      (∀ i j, (sigma_assign i j = 1 → 0 ≤ p_star i j) ∧
              (sigma_assign i j = -1 → p_star i j ≤ 0)) ∧
      (∀ p : Fin n → Fin d → ℝ,
        (∀ i j, (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                (sigma_assign i j = -1 → p i j ≤ 0)) →
        (∑ i, g_lambda q lambda f (p_star i)) ≤ (∑ i, g_lambda q lambda f (p i))) := by
  classical
  have hq_le : 1 ≤ q := le_of_lt hq
  set S : Set (Fin n → Fin d → ℝ) :=
    {p | ∀ i j, (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                (sigma_assign i j = -1 → p i j ≤ 0)} with hS_def
  set G : (Fin n → Fin d → ℝ) → ℝ :=
    fun p => ∑ i, g_lambda q lambda f (p i) with hG_def
  have hG_cont : Continuous G := sum_g_lambda_continuous hq_le lambda f
  have h0_mem : (fun _ _ => (0 : ℝ)) ∈ S := by
    intro i j
    refine ⟨fun _ => le_refl 0, fun _ => le_refl 0⟩
  have hS_closed : IsClosed S := by
    have : S = ⋂ (i : Fin n) (j : Fin d),
        {p : Fin n → Fin d → ℝ | (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                                  (sigma_assign i j = -1 → p i j ≤ 0)} := by
      ext p
      simp only [Set.mem_iInter, Set.mem_setOf_eq, hS_def]
    rw [this]
    apply isClosed_iInter
    intro i
    apply isClosed_iInter
    intro j
    have h_eq : {p : Fin n → Fin d → ℝ | (sigma_assign i j = 1 → 0 ≤ p i j) ∧
                                  (sigma_assign i j = -1 → p i j ≤ 0)} =
        {p | sigma_assign i j = 1 → 0 ≤ p i j} ∩
        {p | sigma_assign i j = -1 → p i j ≤ 0} := by
      ext p; simp [Set.mem_inter_iff, Set.mem_setOf_eq]
    rw [h_eq]
    apply IsClosed.inter
    · rcases hsigma_pm i j with h1 | h1
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = 1 → 0 ≤ p i j}
            = {p : Fin n → Fin d → ℝ | 0 ≤ p i j} := by
          ext p; simp [h1]
        rw [heq]
        have h_cont : Continuous (fun p : Fin n → Fin d → ℝ => p i j) :=
          (continuous_apply j).comp (continuous_apply i)
        exact isClosed_le continuous_const h_cont
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = 1 → 0 ≤ p i j}
            = Set.univ := by
          ext p
          simp only [Set.mem_setOf_eq, Set.mem_univ, iff_true]
          intro hcontr
          rw [h1] at hcontr
          linarith
        rw [heq]; exact isClosed_univ
    · rcases hsigma_pm i j with h1 | h1
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = -1 → p i j ≤ 0}
            = Set.univ := by
          ext p
          simp only [Set.mem_setOf_eq, Set.mem_univ, iff_true]
          intro hcontr
          rw [h1] at hcontr
          linarith
        rw [heq]; exact isClosed_univ
      · have heq : {p : Fin n → Fin d → ℝ | sigma_assign i j = -1 → p i j ≤ 0}
            = {p : Fin n → Fin d → ℝ | p i j ≤ 0} := by
          ext p; simp [h1]
        rw [heq]
        have h_cont : Continuous (fun p : Fin n → Fin d → ℝ => p i j) :=
          (continuous_apply j).comp (continuous_apply i)
        exact isClosed_le h_cont continuous_const
  set K : ℝ := G (fun _ _ => 0) with hK_def
  set T : Set (Fin n → Fin d → ℝ) := S ∩ {p | G p ≤ K} with hT_def
  have hT_closed : IsClosed T := hS_closed.inter (isClosed_le hG_cont continuous_const)
  have hT_bdd : Bornology.IsBounded T := by
    have h_one_lam_pos : 0 < 1 - lambda := by linarith
    have h_one_lam_nn : 0 ≤ 1 - lambda := le_of_lt h_one_lam_pos
    set R : ℝ := (K + n) / (1 - lambda) with hR_def
    have h_pj_bound : ∀ p ∈ T, ∀ i j, |p i j| ≤ R := by
      intro p hp i j
      obtain ⟨hpS, hpK⟩ := hp
      simp only [Set.mem_setOf_eq] at hpK
      have h_each : ∀ i', (1 - lambda) * lqNorm q (p i') - 1 ≤ g_lambda q lambda f (p i') :=
        fun i' => g_lambda_lower_bound hq_le f hf_norm (p i')
      have h_sum : (1 - lambda) * (∑ i', lqNorm q (p i')) - n ≤ ∑ i', g_lambda q lambda f (p i') := by
        have h1 : (∑ i' : Fin n, ((1 - lambda) * lqNorm q (p i') - 1)) ≤
                   ∑ i', g_lambda q lambda f (p i') := by
          apply Finset.sum_le_sum
          intro i' _
          exact h_each i'
        have h2 : (∑ i' : Fin n, ((1 - lambda) * lqNorm q (p i') - 1)) =
                  (1 - lambda) * (∑ i', lqNorm q (p i')) - n := by
          rw [Finset.sum_sub_distrib]
          rw [← Finset.mul_sum]
          simp
        linarith [h1, h2.symm.le, h2.le]
      have h_sum2 : (1 - lambda) * (∑ i', lqNorm q (p i')) ≤ K + n := by
        have : ∑ i', g_lambda q lambda f (p i') = G p := rfl
        linarith
      have h_nn : ∀ i', 0 ≤ lqNorm q (p i') := fun i' => lqNorm_nonneg hq_le _
      have h_single_le_sum : lqNorm q (p i) ≤ ∑ i', lqNorm q (p i') := by
        exact Finset.single_le_sum (f := fun i' => lqNorm q (p i'))
          (s := Finset.univ) (a := i)
          (fun i' _ => h_nn i') (Finset.mem_univ _)
      have h_pi_bound : (1 - lambda) * lqNorm q (p i) ≤ K + n := by
        calc (1 - lambda) * lqNorm q (p i) ≤ (1 - lambda) * (∑ i', lqNorm q (p i')) := by
              exact mul_le_mul_of_nonneg_left h_single_le_sum h_one_lam_nn
          _ ≤ K + n := h_sum2
      have h_lqnorm_le_R : lqNorm q (p i) ≤ R := by
        rw [hR_def]
        rw [le_div_iff₀ h_one_lam_pos]
        linarith [mul_comm (1 - lambda) (lqNorm q (p i))]
      have h_abs_le : |p i j| ≤ lqNorm q (p i) := lqNorm_ge_abs_coord hq_le (p i) j
      linarith
    rw [Metric.isBounded_iff_subset_closedBall (0 : Fin n → Fin d → ℝ)]
    refine ⟨R, ?_⟩
    intro p hp
    rw [Metric.mem_closedBall, dist_zero_right]
    have hR_nn : 0 ≤ R := by
      rw [hR_def]
      apply div_nonneg
      · have h_g0 : ∀ i : Fin n, g_lambda q lambda f ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i) = 1 := by
          intro i
          unfold g_lambda
          have h_pi : ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i) = (fun (_ : Fin d) => (0 : ℝ)) := rfl
          rw [h_pi]
          have h_eq : (fun j : Fin d => ((fun (_ : Fin d) => (0 : ℝ)) j) - f j) = (fun j => -f j) := by
            funext j; simp
          rw [h_eq]
          have h_neg : lqNorm q (fun j : Fin d => -f j) = lqNorm q f := by
            have h1 := lqNorm_smul hq_le (-1 : ℝ) f
            have h2 : (fun j : Fin d => (-1 : ℝ) * f j) = (fun j => -f j) := by
              funext j; ring
            rw [h2] at h1
            simp at h1
            exact h1
          rw [h_neg, hf_norm]
          have h_zero : lqNorm q (fun (_ : Fin d) => (0 : ℝ)) = 0 := lqNorm_zero hq_le
          rw [h_zero]
          ring
        have hK_val : K = n := by
          show G (fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) = n
          show (∑ i : Fin n, g_lambda q lambda f ((fun (_ : Fin n) (_ : Fin d) => (0 : ℝ)) i)) = n
          rw [Finset.sum_congr rfl (fun i _ => h_g0 i)]
          simp
        rw [hK_val]
        have hn_nn : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
        linarith
      · exact h_one_lam_nn
    rw [pi_norm_le_iff_of_nonneg hR_nn]
    intro i
    rw [pi_norm_le_iff_of_nonneg hR_nn]
    intro j
    simp only [Real.norm_eq_abs]
    exact h_pj_bound p hp i j
  have hT_compact : IsCompact T :=
    Metric.isCompact_iff_isClosed_bounded.mpr ⟨hT_closed, hT_bdd⟩
  have hT_nonempty : T.Nonempty := by
    refine ⟨fun _ _ => 0, h0_mem, ?_⟩
    simp only [Set.mem_setOf_eq]
    rfl
  have hG_cont_on : ContinuousOn G T := hG_cont.continuousOn
  obtain ⟨p_star, hp_star_T, hp_star_min⟩ :=
    hT_compact.exists_isMinOn hT_nonempty hG_cont_on
  refine ⟨p_star, hp_star_T.1, ?_⟩
  intro p hp
  by_cases hpK : G p ≤ K
  · have hpT : p ∈ T := ⟨hp, hpK⟩
    exact hp_star_min hpT
  · push_neg at hpK
    have hp_star_K : G p_star ≤ K := hp_star_T.2
    linarith

end RGNormalizedCoreInequalityProof

open RGNormalizedCoreInequalityProof

theorem RGNormalizedCoreInequality_fpos
    (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c < 1)
    {n d : ℕ} (hn_pos : 0 < n) (hne : Even (n + ⌊c * (n : ℝ)⌋₊)) (hd : 1 ≤ d)
    (hcn : (⌊c * (n : ℝ)⌋₊ : ℝ) = c * (n : ℝ))
    (P_norm : Fin n → Fin d → ℝ)
    (pred : Fin d → ℝ) (hpred_gp : ∀ j, pred j ≠ 0)
    (f : Fin d → ℝ) (hf_nn : ∀ j, 0 ≤ f j) (hf_pos : ∀ j, 0 < f j)
    (hf_norm : lqNorm 2 f = 1)
    (hP_med : IsCoordinateMedian (fun (_ : Fin d) => (0 : ℝ))
                (augment P_norm pred (⌊c * (n : ℝ)⌋₊))) :
    socialCost 2 P_norm (fun (_ : Fin d) => (0 : ℝ))
      ≤ Workspace.RobustnessTheorem.RG c * socialCost 2 P_norm f := by
  classical
  -- Fix q = 2 and lambda := lambda2 c.
  have hq : (1 : ℝ) < (2 : ℝ) := by norm_num
  have hq_le : (1 : ℝ) ≤ (2 : ℝ) := by norm_num
  have hq_pos : (0 : ℝ) < (2 : ℝ) := by norm_num
  have hq_ne : (2 : ℝ) ≠ 0 := by norm_num
  set lambda : ℝ := lambda2 c with hlam_def
  -- 0 < lambda2 c, lambda2 c < 1, 1 < RG c.
  obtain ⟨hlam_pos, hlam_lt_one, hRG_gt_one⟩ :=
    Workspace.ProofLemmas.RGLambda2InUnitInterval.RGLambda2InUnitInterval c hc0 hc1
  -- The relation RG c = 1 / lambda2 c (cite RG_eq_inv_lambda2).
  have h_RG_eq : Workspace.RobustnessTheorem.RG c = 1 / lambda := by
    rw [hlam_def]; exact RG_eq_inv_lambda2 c hc0 hc1
  -- Rewrite the goal: SC(0) ≤ RG c · SC(f) ↔ lambda · SC(0) ≤ SC(f).
  rw [h_RG_eq]
  rw [show (1 : ℝ) / lambda * socialCost 2 P_norm f = socialCost 2 P_norm f / lambda by ring]
  rw [le_div_iff₀ hlam_pos]
  -- f satisfies ∑ (f j)^2 = 1 since lqNorm 2 f = 1.
  have hf_pow_sum : (∑ j, (f j) ^ (2 : ℝ)) = 1 := by
    have h1 : lqNorm 2 f = (∑ j, |f j| ^ (2 : ℝ)) ^ ((1 : ℝ) / 2) := rfl
    rw [h1] at hf_norm
    have h_inner_nn : 0 ≤ ∑ j, |f j| ^ (2 : ℝ) := sum_abs_rpow_nonneg 2 f
    have hsum_eq : (∑ j, |f j| ^ (2 : ℝ)) = 1 := by
      have h2 : ((∑ j, |f j| ^ (2 : ℝ)) ^ ((1 : ℝ) / 2)) ^ (2 : ℝ) = (1 : ℝ) ^ (2 : ℝ) := by
        rw [hf_norm]
      rw [← Real.rpow_mul h_inner_nn, one_div, inv_mul_cancel₀ hq_ne, Real.rpow_one,
          Real.one_rpow] at h2
      exact h2
    have h_abs : ∀ j, |f j| ^ (2 : ℝ) = (f j) ^ (2 : ℝ) := by
      intro j; rw [abs_of_nonneg (hf_nn j)]
    rw [show (∑ j, (f j) ^ (2 : ℝ)) = (∑ j, |f j| ^ (2 : ℝ)) from
      Finset.sum_congr rfl (fun j _ => (h_abs j).symm)]
    exact hsum_eq
  -- Prediction signature s = σ(pred).
  set s : Fin d → ℝ := fun j => if pred j > 0 then (1 : ℝ) else (-1 : ℝ) with hs_def
  have hs_pm : ∀ j, s j = 1 ∨ s j = -1 := by
    intro j; rw [hs_def]; by_cases h : pred j > 0 <;> simp [h]
  have hs_pos : ∀ j, pred j > 0 → s j = 1 := by
    intro j hj; rw [hs_def]; simp [hj]
  have hs_neg : ∀ j, pred j < 0 → s j = -1 := by
    intro j hj; rw [hs_def]
    have : ¬ (pred j > 0) := by linarith
    simp [this]
  -- Step (3): obtain sigma via RGMedianConstraintFromAugment (SIGNED constraint).
  obtain ⟨sigma, hsigma_pm, hsigma_pos, hsigma_neg, hsigma_cons, hsigma_balance⟩ :=
    Workspace.ProofLemmas.RGMedianConstraintFromAugment.RGMedianConstraintFromAugment
      c hc0 hc1 hne f hf_pow_sum pred hpred_gp s hs_pm hs_pos hs_neg P_norm hP_med
  -- NEW step: reduce to worst-case prediction signature (−1,…,−1).
  obtain ⟨P', sigma', hsigma'_pm, hsigma'_pos, hsigma'_neg, hsigma'_cons, hg_le⟩ :=
    Workspace.ProofLemmas.RGWorstCasePredictionSignature.RGWorstCasePredictionSignature
      c hc0 hc1 lambda f hf_pos P_norm s hs_pm sigma hsigma_pm hsigma_pos hsigma_neg hsigma_cons
  -- The worst-case constraint: ∑ sigma' i j = ⌊cn⌋.
  have hsigma'_eq : ∀ j, ∑ i, sigma' i j = (⌊c * (n : ℝ)⌋₊ : ℝ) := by
    intro j; have := hsigma'_cons j; simpa using this
  -- Step (4): apply RG constrained-min existence to sigma' → p_star.
  obtain ⟨p_star, hp_star_in, hp_star_min⟩ :=
    rgConstrainedMinExists 2 hq lambda hlam_pos hlam_lt_one
      f hf_norm sigma' hsigma'_pm
  -- P' itself satisfies the orthant constraint w.r.t. sigma'.
  have hP'_in : ∀ i j, (sigma' i j = 1 → 0 ≤ P' i j) ∧
                       (sigma' i j = -1 → P' i j ≤ 0) := by
    intro i j
    refine ⟨?_, ?_⟩
    · intro hsig
      by_contra h_neg
      push_neg at h_neg
      have := hsigma'_neg i j h_neg
      rw [this] at hsig
      norm_num at hsig
    · intro hsig
      by_contra h_pos
      push_neg at h_pos
      have := hsigma'_pos i j h_pos
      rw [this] at hsig
      norm_num at hsig
  -- The minimization gives: ∑ g(p_star) ≤ ∑ g(P').
  have h_p_star_le : (∑ i, g_lambda 2 lambda f (p_star i))
      ≤ (∑ i, g_lambda 2 lambda f (P' i)) := hp_star_min P' hP'_in
  -- Define x_i := ∑_{j ∈ S_i} (f j)^2, where S_i := {j : sigma' i j = 1}.
  set x : Fin n → ℝ := fun i =>
    ∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma' i j = 1)), (f j) ^ (2 : ℝ) with hx_def
  have hx_nn : ∀ i, 0 ≤ x i := by
    intro i
    apply Finset.sum_nonneg
    intro j _
    exact Real.rpow_nonneg (hf_nn j) (2 : ℝ)
  have hx_le_one : ∀ i, x i ≤ 1 := by
    intro i
    have h_split := Finset.sum_compl_add_sum
      (s := (Finset.univ.filter (fun j : Fin d => sigma' i j = 1)))
      (f := fun j => (f j) ^ (2 : ℝ))
    have h_compl_nn : 0 ≤ ∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma' i j = 1))ᶜ, (f j) ^ (2 : ℝ) := by
      apply Finset.sum_nonneg
      intro j _
      exact Real.rpow_nonneg (hf_nn j) (2 : ℝ)
    have hf_sum_eq :
        (∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma' i j = 1))ᶜ, (f j) ^ (2 : ℝ)) +
          (∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma' i j = 1)), (f j) ^ (2 : ℝ)) =
        ∑ j, (f j) ^ (2 : ℝ) := h_split
    rw [hf_pow_sum] at hf_sum_eq
    show (∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma' i j = 1)), (f j) ^ (2 : ℝ)) ≤ 1
    linarith
  -- ∑ x i = (1+c)/2 · n by RGRelaxedConstraint.
  -- First convert the worst-case column-sum to the card-balance form.
  have hbalance : ∀ j,
      (((Finset.univ : Finset (Fin n)).filter (fun i => sigma' i j = 1)).card : ℝ)
        = ((n : ℝ) + ⌊c * (n : ℝ)⌋₊) / 2 := by
    intro j
    -- ∑ sigma' i j = ⌊cn⌋, with σ ∈ {−1,1}: #{+1} − #{−1} = ⌊cn⌋, #{+1}+#{−1}=n.
    have hcol := hsigma'_eq j
    set Sp := (Finset.univ : Finset (Fin n)).filter (fun i => sigma' i j = 1) with hSp_def
    set Sm := (Finset.univ : Finset (Fin n)).filter (fun i => sigma' i j = -1) with hSm_def
    -- The sum splits as #Sp - #Sm.
    have hsum_split : ∑ i, sigma' i j = (Sp.card : ℝ) - (Sm.card : ℝ) := by
      rw [hSp_def, hSm_def]
      rw [← Finset.sum_filter_add_sum_filter_not (Finset.univ) (fun i => sigma' i j = 1)]
      have h1 : ∑ i ∈ Finset.univ.filter (fun i => sigma' i j = 1), sigma' i j
          = (Sp.card : ℝ) := by
        rw [hSp_def]
        rw [Finset.sum_congr rfl (fun i hi => by
          simp only [Finset.mem_filter] at hi; exact hi.2)]
        simp
      have h2 : ∑ i ∈ Finset.univ.filter (fun i => ¬ sigma' i j = 1), sigma' i j
          = -(Sm.card : ℝ) := by
        have hset : (Finset.univ.filter (fun i => ¬ sigma' i j = 1))
            = Finset.univ.filter (fun i => sigma' i j = -1) := by
          apply Finset.filter_congr
          intro i _
          constructor
          · intro h
            rcases hsigma'_pm i j with h' | h'
            · exact absurd h' h
            · exact h'
          · intro h
            rw [h]; norm_num
        rw [hset, ← hSm_def]
        rw [Finset.sum_congr rfl (fun i hi => by
          simp only [Finset.mem_filter, hSm_def] at hi; exact hi.2)]
        simp
      rw [h1, h2, ← hSp_def, ← hSm_def]; ring
    -- #Sp + #Sm = n.
    have hcard_total : (Sp.card : ℝ) + (Sm.card : ℝ) = (n : ℝ) := by
      have : Sp.card + Sm.card = Fintype.card (Fin n) := by
        rw [hSp_def, hSm_def]
        have hneg : (Finset.univ.filter (fun i => sigma' i j = -1))
            = (Finset.univ.filter (fun i => ¬ sigma' i j = 1)) := by
          apply Finset.filter_congr
          intro i _
          constructor
          · intro h hcontr; rw [h] at hcontr; norm_num at hcontr
          · intro h
            rcases hsigma'_pm i j with h' | h'
            · exact absurd h' h
            · exact h'
        rw [hneg, Finset.filter_card_add_filter_neg_card_eq_card (p := fun i => sigma' i j = 1),
          Finset.card_univ]
      have := this
      rw [Fintype.card_fin] at this
      exact_mod_cast this
    rw [hsum_split] at hcol
    rw [hSp_def] at hcol ⊢
    linarith
  have hx_sum : (∑ i, x i) = (1 + c) / 2 * (n : ℝ) := by
    have := Workspace.ProofLemmas.RGRelaxedConstraint.RGRelaxedConstraint
      c hcn f hf_pow_sum sigma' hsigma'_pm hbalance
    exact this
  -- Define the lower-bound delta (= delta2 c definitionally).
  set delta : ℝ := delta_of_lambda 2 lambda with hdelta_def
  -- Per-agent local-min argument.
  have h_per_agent_min : ∀ i (p_i : Fin d → ℝ),
      (∀ j, (sigma' i j = 1 → 0 ≤ p_i j) ∧ (sigma' i j = -1 → p_i j ≤ 0)) →
      g_lambda 2 lambda f (p_star i) ≤ g_lambda 2 lambda f p_i := by
    intro i p_i hp_i_in
    let p' : Fin n → Fin d → ℝ := fun i' => if i' = i then p_i else p_star i'
    have hp'_in : ∀ i' j, (sigma' i' j = 1 → 0 ≤ p' i' j) ∧
                          (sigma' i' j = -1 → p' i' j ≤ 0) := by
      intro i' j
      by_cases hi' : i' = i
      · subst hi'
        show (sigma' i' j = 1 → 0 ≤ (if i' = i' then p_i else p_star i') j) ∧
             (sigma' i' j = -1 → (if i' = i' then p_i else p_star i') j ≤ 0)
        simp only [if_true]
        exact hp_i_in j
      · show (sigma' i' j = 1 → 0 ≤ (if i' = i then p_i else p_star i') j) ∧
             (sigma' i' j = -1 → (if i' = i then p_i else p_star i') j ≤ 0)
        simp only [if_neg hi']
        exact hp_star_in i' j
    have h_global := hp_star_min p' hp'_in
    have h_at_i : p' i = p_i := by simp [p']
    have h_off_i : ∀ i' ∈ Finset.univ.erase i, p' i' = p_star i' := by
      intro i' hi'
      rw [Finset.mem_erase] at hi'
      simp [p', hi'.1]
    have h_sum_p' :
        (∑ i', g_lambda 2 lambda f (p' i')) =
          g_lambda 2 lambda f p_i + ∑ i' ∈ Finset.univ.erase i, g_lambda 2 lambda f (p_star i') := by
      rw [← Finset.add_sum_erase _ _ (Finset.mem_univ i)]
      congr 1
      · rw [h_at_i]
      · apply Finset.sum_congr rfl
        intro i' hi'
        rw [h_off_i i' hi']
    have h_sum_pstar :
        (∑ i', g_lambda 2 lambda f (p_star i')) =
          g_lambda 2 lambda f (p_star i) + ∑ i' ∈ Finset.univ.erase i, g_lambda 2 lambda f (p_star i') := by
      rw [← Finset.add_sum_erase _ _ (Finset.mem_univ i)]
    rw [h_sum_p', h_sum_pstar] at h_global
    linarith
  have h_local_min : ∀ i,
      ∃ ε > (0 : ℝ),
        ∀ p_i : Fin d → ℝ,
          (∀ j, (sigma' i j = 1 → 0 ≤ p_i j) ∧ (sigma' i j = -1 → p_i j ≤ 0)) →
          (∀ j, |p_i j - p_star i j| < ε) →
          g_lambda 2 lambda f (p_star i) ≤ g_lambda 2 lambda f p_i := by
    intro i
    refine ⟨1, by norm_num, ?_⟩
    intro p_i hp_i_in _
    exact h_per_agent_min i p_i hp_i_in
  -- Per-agent g ≥ h via LocalOptimumCharacterization + GLambdaLowerBound_h.
  have h_per_agent_g_ge_h : ∀ i,
      lambda * (delta * (1 - x i) ^ ((1 : ℝ) / 2) - (x i) ^ ((1 : ℝ) / 2))
        ≤ g_lambda 2 lambda f (p_star i) := by
    intro i
    have hp_star_i_in : ∀ j, (sigma' i j = 1 → 0 ≤ p_star i j) ∧
                              (sigma' i j = -1 → p_star i j ≤ 0) := hp_star_in i
    have hsigma_i_pm : ∀ j, sigma' i j = 1 ∨ sigma' i j = -1 := fun j => hsigma'_pm i j
    have h_local := LocalOptimumCharacterization 2 hq lambda hlam_pos hlam_lt_one
      hd f hf_nn hf_pos hf_pow_sum (sigma' i) hsigma_i_pm (p_star i)
      hp_star_i_in (h_local_min i)
    have h_glb := GLambdaLowerBound_h 2 hq lambda hlam_pos hlam_lt_one
      hd f hf_nn hf_pos hf_pow_sum (sigma' i) hsigma_i_pm (p_star i) h_local
    show lambda * (delta * (1 - x i) ^ ((1 : ℝ) / 2) - (x i) ^ ((1 : ℝ) / 2))
      ≤ g_lambda 2 lambda f (p_star i)
    have hx_eq : x i =
        ∑ j ∈ (Finset.univ.filter (fun j : Fin d => sigma' i j = 1)), (f j) ^ (2 : ℝ) := rfl
    have hdelta_eq : delta = delta_of_lambda 2 lambda := rfl
    rw [hx_eq, hdelta_eq]
    exact h_glb
  have h_g_ge_h : (∑ i, lambda * (delta * (1 - x i) ^ ((1 : ℝ) / 2) - (x i) ^ ((1 : ℝ) / 2)))
      ≤ (∑ i, g_lambda 2 lambda f (p_star i)) := by
    apply Finset.sum_le_sum
    intro i _
    exact h_per_agent_g_ge_h i
  -- ∑ h_q(x i) ≥ 0 via RGRelaxedCoreNonneg.
  have h_sum_h_nn : 0 ≤ (∑ i, h_q 2 lambda delta (x i)) := by
    have hdelta2 : delta = delta2 c := by
      rw [hdelta_def, hlam_def]; rfl
    have := Workspace.ProofLemmas.RGRelaxedCoreNonneg.RGRelaxedCoreNonneg
      c hc0 hc1 x hx_nn hx_le_one hx_sum
    rw [hdelta2, hlam_def]
    exact this
  -- Convert the LHS of h_g_ge_h to the h_q form.
  have h_lhs_eq : (∑ i, lambda * (delta * (1 - x i) ^ ((1 : ℝ) / 2) - (x i) ^ ((1 : ℝ) / 2)))
      = (∑ i, h_q 2 lambda delta (x i)) := by
    apply Finset.sum_congr rfl
    intro i _
    rfl
  rw [h_lhs_eq] at h_g_ge_h
  -- Chain: 0 ≤ ∑ h ≤ ∑ g(p_star) ≤ ∑ g(P') ≤ ∑ g(P_norm).
  have h_main_chain : 0 ≤ ∑ i, g_lambda 2 lambda f (P_norm i) := by
    have h1 : 0 ≤ ∑ i, g_lambda 2 lambda f (p_star i) :=
      le_trans h_sum_h_nn h_g_ge_h
    have h2 : 0 ≤ ∑ i, g_lambda 2 lambda f (P' i) :=
      le_trans h1 h_p_star_le
    linarith [hg_le]
  -- Unfold g_lambda and conclude.
  have h_sum_eq : (∑ i, g_lambda 2 lambda f (P_norm i))
      = socialCost 2 P_norm f - lambda * socialCost 2 P_norm (fun (_ : Fin d) => (0 : ℝ)) := by
    unfold g_lambda socialCost
    rw [Finset.sum_sub_distrib]
    rw [Finset.mul_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro i _
    have h_ext : (fun j => P_norm i j - (fun (_ : Fin d) => (0 : ℝ)) j) = fun j => P_norm i j := by
      funext j; ring
    rw [h_ext]
  rw [h_sum_eq] at h_main_chain
  linarith

end Workspace.ProofLemmas.RGNormalizedCoreInequality

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.CoordinateMedian
open Workspace.Types.SocialCost
open Workspace.ConsistencyTheorem
open Workspace.RobustnessTheorem

namespace Workspace.ProofLemmas.RGFinalAssembly

/-- **Strict-majority coordinate median.**  In the OPT = 0 robustness branch the
pred-augmented instance is `fstar'` on the `n'` original agents and `pred'` on the
`⌊cn'⌋` appended copies.  When `n' > (n' + ⌊cn'⌋)/2` (i.e. the original agents form a
STRICT majority, which holds because `⌊cn'⌋ < n'`), any coordinate-wise median `m'`
must agree with `fstar'` on every coordinate: if `m' j < fstar' j` then all `n'`
original agents lie strictly above `m' j`, forcing the `>`-filter card `≥ n' > N/2`,
contradicting the median condition (symmetric for `m' j > fstar' j`).  This is the one
genuine difference from the consistency assembly, where the augmented instance is a
true constant and `MedianOfConstant` applies directly. -/
private lemma strictMajority_median_eq {n' d' k : ℕ}
    (hmaj : (n' + k) / 2 < n')
    (cst : Fin d' → ℝ) (pred' : Fin d' → ℝ) (m' : Fin d' → ℝ)
    (hmed : IsCoordinateMedian m'
      (Workspace.ConsistencyTheorem.augment
        (fun (_ : Fin n') (j : Fin d') => cst j) pred' k)) :
    m' = cst := by
  classical
  funext j
  obtain ⟨hlt, hgt⟩ := hmed j
  by_contra hne
  rcases lt_or_gt_of_ne hne with hmlt | hmgt
  · -- m' j < cst j : every original agent (left summand) lies strictly above m' j.
    have hsub : n' ≤
        (Finset.univ.filter
          (fun i : Fin (n' + k) =>
            (Workspace.ConsistencyTheorem.augment
              (fun (_ : Fin n') (j : Fin d') => cst j) pred' k) i j > m' j)).card := by
      have hcard :
          (Finset.univ : Finset (Fin n')).card ≤
          (Finset.univ.filter
            (fun i : Fin (n' + k) =>
              (Workspace.ConsistencyTheorem.augment
                (fun (_ : Fin n') (j : Fin d') => cst j) pred' k) i j > m' j)).card := by
        refine Finset.card_le_card_of_injOn (fun i => Fin.castAdd k i) ?_ ?_
        · intro i _
          simp only [Finset.coe_filter, Finset.mem_univ, true_and, Set.mem_setOf_eq]
          show (Workspace.ConsistencyTheorem.augment
            (fun (_ : Fin n') (j : Fin d') => cst j) pred' k) (Fin.castAdd k i) j > m' j
          unfold Workspace.ConsistencyTheorem.augment
          rw [Fin.addCases_left]
          exact hmlt
        · intro a _ b _ hab
          exact Fin.castAdd_injective _ _ hab
      simpa using hcard
    have : n' ≤ (n' + k) / 2 := le_trans hsub hgt
    omega
  · -- m' j > cst j : every original agent (left summand) lies strictly below m' j.
    have hsub : n' ≤
        (Finset.univ.filter
          (fun i : Fin (n' + k) =>
            (Workspace.ConsistencyTheorem.augment
              (fun (_ : Fin n') (j : Fin d') => cst j) pred' k) i j < m' j)).card := by
      have hcard :
          (Finset.univ : Finset (Fin n')).card ≤
          (Finset.univ.filter
            (fun i : Fin (n' + k) =>
              (Workspace.ConsistencyTheorem.augment
                (fun (_ : Fin n') (j : Fin d') => cst j) pred' k) i j < m' j)).card := by
        refine Finset.card_le_card_of_injOn (fun i => Fin.castAdd k i) ?_ ?_
        · intro i _
          simp only [Finset.coe_filter, Finset.mem_univ, true_and, Set.mem_setOf_eq]
          show (Workspace.ConsistencyTheorem.augment
            (fun (_ : Fin n') (j : Fin d') => cst j) pred' k) (Fin.castAdd k i) j < m' j
          unfold Workspace.ConsistencyTheorem.augment
          rw [Fin.addCases_left]
          exact hmgt
        · intro a _ b _ hab
          exact Fin.castAdd_injective _ _ hab
      simpa using hcard
    have : n' ≤ (n' + k) / 2 := le_trans hsub hlt
    omega

/-- **RGFinalAssembly** — the proof of Theorem 4 (robustness guarantee of
`CMP(c)`), assembled from the robustness sub-lemmas.

This is the body of `Workspace.RobustnessTheorem.robustness_guarantee`; the
root statement file sets `robustness_guarantee := RGFinalAssembly`.

Pipeline (faithful `c → −c` / `fstar → pred` mirror of `CGFinalAssembly`):
* `RGEvenAugmentReduction` reduces to the case `n + ⌊cn⌋` even (and discharges
  `n = 0`) by duplicating the pred-augmented instance.
* In the even case we split on `optSocialCost 2 P = 0`:
  - `OPT = 0`: every report equals the optimal facility `fstar'`, so the
    pred-augmented instance is `fstar'` on the `n'` agents and `pred'` on the
    `⌊cn'⌋` appended copies.  Because `⌊cn'⌋ < n'`, the original agents form a
    STRICT majority on every coordinate, so any median `m'` equals `fstar'`
    (`strictMajority_median_eq`).  Then `SC(P',m') = SC(P',fstar') = 0 ≤ RG c · 0`.
  - `OPT > 0`: `RGTranslationScaleNormalize` (its `h_norm` premise instantiated
    with the strict-`f>0` core `RGNormalizedCoreInequality_fpos`) gives the bound,
    using the general-position hypotheses `∀ j, fstar j ≠ m j` and `∀ j, pred j ≠ m j`.

The general-position hypotheses are the paper's standing normalization; see
`robustness_guarantee`'s docstring. -/
theorem RGFinalAssembly :
    ∀ (c : ℝ), 0 ≤ c → c < 1 →
      ∀ {n d : ℕ}, 1 ≤ d →
      (⌊c * (n : ℝ)⌋₊ : ℝ) = c * (n : ℝ) →
      ∀ (P : Fin n → Fin d → ℝ) (pred : Fin d → ℝ) (fstar : Fin d → ℝ),
        socialCost 2 P fstar = optSocialCost 2 P →
      ∀ (m : Fin d → ℝ),
        IsCoordinateMedian m (augment P pred (⌊c * (n : ℝ)⌋₊)) →
        (∀ j, fstar j ≠ m j) →
        (∀ j, pred j ≠ m j) →
        socialCost 2 P m ≤ RG c * optSocialCost 2 P := by
  intro c hc0 hc1 n d hd hcn P pred fstar hopt m hmed hgp hgp_pred
  -- Reduce to the even case via RGEvenAugmentReduction.  Its `h_even` premise is
  -- the even-`n` bound, which we discharge below; the rest of its arguments are
  -- the present instance data.
  refine Workspace.ProofLemmas.RGEvenAugmentReduction.RGEvenAugmentReduction
    c hc0 hc1 ?_ hcn hd P pred fstar hopt m hmed hgp hgp_pred
  -- Goal: the `h_even` closure (general instance, `n' + ⌊cn'⌋` even).
  intro n' d' hne' hcn' hd' P' pred' fstar' hopt' m' hmed' hgp' hgp_pred'
  classical
  -- Split on whether OPT' = 0.
  by_cases hOPT0 : optSocialCost 2 P' = 0
  · -- Trivial branch: OPT' = 0 ⇒ every report = fstar'.  The pred-augmented
    -- instance is `fstar'` on agents + `pred'` on the appended copies; the strict
    -- majority of agents forces m' = fstar', whence SC(P',m') = 0 = RG c · 0.
    have hq2 : (1 : ℝ) ≤ 2 := by norm_num
    -- SC(P', fstar') = 0.
    have hsc0 : socialCost 2 P' fstar' = 0 := by rw [hopt', hOPT0]
    -- Each report equals fstar'.
    have hP_eq : ∀ i : Fin n', (fun j => P' i j) = fstar' := by
      intro i
      have hsum : ∑ i, lqNorm 2 (fun j => P' i j - fstar' j) = 0 := by
        have : socialCost 2 P' fstar' = ∑ i, lqNorm 2 (fun j => P' i j - fstar' j) := rfl
        rw [this] at hsc0; exact hsc0
      have hnn : ∀ i ∈ (Finset.univ : Finset (Fin n')),
          0 ≤ lqNorm 2 (fun j => P' i j - fstar' j) := fun i _ => lqNorm_nonneg hq2 _
      have hterm : lqNorm 2 (fun j => P' i j - fstar' j) = 0 :=
        (Finset.sum_eq_zero_iff_of_nonneg hnn).mp hsum i (Finset.mem_univ i)
      have hzero : (fun j => P' i j - fstar' j) = 0 :=
        (LqNormZeroIffEqZero 2 hq2 hd' _).mp hterm
      funext j
      have := congr_fun hzero j
      simp only [Pi.zero_apply] at this
      linarith
    -- The pred-augmented instance is `fstar'` on agents + `pred'` on the copies.
    have haug_eq :
        augment P' pred' (⌊c * (n' : ℝ)⌋₊)
          = augment (fun (_ : Fin n') (j : Fin d') => fstar' j) pred' (⌊c * (n' : ℝ)⌋₊) := by
      funext i j
      unfold augment
      refine Fin.addCases ?_ ?_ i
      · intro a
        simp only [Fin.addCases_left]
        have := congr_fun (hP_eq a) j
        simpa using this
      · intro a
        simp only [Fin.addCases_right]
    -- n' > 0 (else OPT' is the empty-agent cost, which is 0 — fine — but we need the
    -- strict-majority argument; handle n' = 0 separately).
    by_cases hn'0 : n' = 0
    · subst hn'0
      have hscm0 : socialCost 2 P' m' = 0 := by
        show ∑ i, lqNorm 2 (fun j => P' i j - m' j) = 0
        exact Fin.sum_univ_zero _
      rw [hscm0, hOPT0, mul_zero]
    · have hn'_pos : 0 < n' := Nat.pos_of_ne_zero hn'0
      -- ⌊cn'⌋ < n', so the original agents form a strict majority.
      have hk_lt : ⌊c * (n' : ℝ)⌋₊ < n' := by
        have hreal : (⌊c * (n' : ℝ)⌋₊ : ℝ) < (n' : ℝ) := by
          rw [hcn']
          calc c * (n' : ℝ) < 1 * (n' : ℝ) := by
                apply mul_lt_mul_of_pos_right hc1
                exact_mod_cast hn'_pos
            _ = (n' : ℝ) := by ring
        exact_mod_cast hreal
      have hmaj : (n' + ⌊c * (n' : ℝ)⌋₊) / 2 < n' := by omega
      -- The median equals fstar'.
      have hmed_cst :
          IsCoordinateMedian m'
            (augment (fun (_ : Fin n') (j : Fin d') => fstar' j) pred' (⌊c * (n' : ℝ)⌋₊)) := by
        rw [← haug_eq]; exact hmed'
      have hm_eq : m' = fstar' :=
        strictMajority_median_eq hmaj fstar' pred' m' hmed_cst
      have hscm0 : socialCost 2 P' m' = 0 := by
        rw [hm_eq]; exact hsc0
      rw [hscm0, hOPT0, mul_zero]
  · -- Generic branch: OPT' > 0.
    have hOPT_pos : 0 < optSocialCost 2 P' :=
      lt_of_le_of_ne (optSocialCost_nonneg (by norm_num) P') (Ne.symm hOPT0)
    -- n' > 0 (else OPT' = 0).
    have hn'_pos : 0 < n' := by
      by_contra hcon
      push_neg at hcon
      interval_cases n'
      · -- n' = 0 ⇒ optSocialCost 2 P' = 0, contradicting hOPT_pos.
        have : optSocialCost 2 P' = 0 := by
          apply le_antisymm
          · have hle := optSocialCost_le_socialCost (show (1:ℝ) ≤ 2 by norm_num) P' (fun _ => 0)
            have : socialCost 2 P' (fun _ => 0) = 0 := by
              show ∑ i, lqNorm 2 (fun j => P' i j - (fun _ => (0:ℝ)) j) = 0
              exact Fin.sum_univ_zero _
            rw [this] at hle; exact hle
          · exact optSocialCost_nonneg (by norm_num) P'
        exact absurd this hOPT0
    -- Apply RGTranslationScaleNormalize with the strict-f>0 core as h_norm.
    exact Workspace.ProofLemmas.RGTranslationScaleNormalize.RGTranslationScaleNormalize
      c hc0 hc1
      (Workspace.ProofLemmas.RGNormalizedCoreInequality.RGNormalizedCoreInequality_fpos c hc0 hc1)
      hn'_pos hne' hd' hcn' P' pred' fstar' hopt' hOPT_pos m' hmed' hgp' hgp_pred'

end Workspace.ProofLemmas.RGFinalAssembly

open scoped BigOperators
open Workspace.Types.LqNorm
open Workspace.Types.SocialCost
open Workspace.Types.CoordinateMedian
open Workspace.ConsistencyTheorem

namespace Workspace.RobustnessTheorem

theorem robustness_guarantee :
    ∀ (c : ℝ), 0 ≤ c → c < 1 →
      ∀ {n d : ℕ}, 1 ≤ d →
      (⌊c * (n : ℝ)⌋₊ : ℝ) = c * (n : ℝ) →
      ∀ (P : Fin n → Fin d → ℝ) (pred : Fin d → ℝ) (fstar : Fin d → ℝ),
        socialCost 2 P fstar = optSocialCost 2 P →
      ∀ (m : Fin d → ℝ),
        IsCoordinateMedian m (augment P pred (⌊c * (n : ℝ)⌋₊)) →
        (∀ j, fstar j ≠ m j) →
        (∀ j, pred j ≠ m j) →
        socialCost 2 P m ≤ RG c * optSocialCost 2 P
    := Workspace.ProofLemmas.RGFinalAssembly.RGFinalAssembly

end Workspace.RobustnessTheorem
