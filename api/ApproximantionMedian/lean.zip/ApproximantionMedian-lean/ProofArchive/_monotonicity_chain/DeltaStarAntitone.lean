import Mathlib
import Workspace.ProofLemmas.DeltaStarDef
import Workspace.ProofLemmas.DeltaStarContinuousOn
import Workspace.ProofLemmas.DeltaStarDifferentiable
import Workspace.ProofLemmas.DerivDeltaStarNonpos

open Workspace.ProofLemmas.DeltaStarDef

/-!
# DeltaStarAntitone — Attempt 5 (closes via `DerivDeltaStarNonpos` black box)

Attempt 4 left a single `sorry` for the derivative-sign step. We now have a
dedicated lemma `DerivDeltaStarNonpos` which directly provides
`∀ q > 1, deriv delta_star q ≤ 0`. Using it as a black box closes the
proof skeleton through `antitoneOn_of_deriv_nonpos`.
-/

theorem DeltaStarAntitone :
    AntitoneOn delta_star (Set.Ioi (1 : ℝ)) := by
  -- Reduce to a derivative-sign statement via `antitoneOn_of_deriv_nonpos`
  -- on the convex set `Ioi 1`, which equals its own interior.
  have hConv : Convex ℝ (Set.Ioi (1 : ℝ)) := convex_Ioi 1
  have hInt : interior (Set.Ioi (1 : ℝ)) = Set.Ioi (1 : ℝ) := interior_Ioi
  -- (b) Continuity of `delta_star` on `Ioi 1`.
  have h_cont : ContinuousOn delta_star (Set.Ioi (1 : ℝ)) := DeltaStarContinuousOn
  -- (c) Differentiability of `delta_star` on the interior of `Ioi 1`.
  have h_diff : DifferentiableOn ℝ delta_star (interior (Set.Ioi (1 : ℝ))) := by
    rw [hInt]
    intro q hq
    have hq1 : (1 : ℝ) < q := hq
    exact (DeltaStarDifferentiable q hq1).differentiableWithinAt
  -- (d) Sign of `deriv delta_star`: now provided directly by
  -- `DerivDeltaStarNonpos`.
  have h_deriv_nonpos : ∀ q ∈ interior (Set.Ioi (1 : ℝ)), deriv delta_star q ≤ 0 := by
    rw [hInt]
    intro q hq
    exact DerivDeltaStarNonpos q hq
  exact antitoneOn_of_deriv_nonpos hConv h_cont h_diff h_deriv_nonpos
