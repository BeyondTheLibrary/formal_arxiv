import Mathlib
import Workspace.ProofLemmas.DeltaStarDef

open Workspace.ProofLemmas.DeltaStarDef

/-- Non-positivity of the derivative of `delta_star` on `(1, ∞)`. -/
theorem DerivDeltaStarNonpos : ∀ q : ℝ, 1 < q → deriv delta_star q ≤ 0 := by
  sorry
