import Mathlib
import Workspace.ProofLemmas.LambdaStarDef
import Workspace.ProofLemmas.DeltaStarDef
import Workspace.ProofLemmas.DeltaStarAntitone
import Workspace.ProofLemmas.DeltaStarContinuousOn
import Workspace.ProofLemmas.DeltaStarDifferentiable

open Workspace.ProofLemmas.LambdaStarDef
open Workspace.ProofLemmas.DeltaStarDef

/-!
# LambdaStarAntitone — Attempt 6

Closes the two "standard" helper lemmas (`ContinuousOn`, `DifferentiableOn`)
using `DeltaStarContinuousOn` and `DeltaStarDifferentiable`, then applies
the closed form via `ContinuousOn.congr` / `DifferentiableOn.congr`.

The substantive derivative-sign lemma `deriv_lambda_star_nonpos` is admitted
as a single `sorry` per the paper-derived proof outline (the deferred
"tedious sign analysis" step).
-/

/-- Closed form of `lambda_star` on `(1, ∞)`. -/
private noncomputable def lambda_closedForm (q : ℝ) : ℝ :=
  (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q))

/-- On `(1, ∞)`, `lambda_star` agrees with its closed-form definition. -/
private lemma lambda_star_eq_closedForm {q : ℝ} (hq : 1 < q) :
    lambda_star q = lambda_closedForm q := by
  have hq1 : q ≠ 1 := ne_of_gt hq
  unfold lambda_star lambda_closedForm
  rw [if_neg hq1, if_pos hq]

/-- Auxiliary positivity: `1 + (delta_star q)^(q/(q-1)) > 0` for `q > 1`. -/
private lemma one_plus_delta_rpow_pos {q : ℝ} (hq : 1 < q) :
    0 < 1 + (delta_star q) ^ (q / (q - 1)) := by
  have hq_pos : (0 : ℝ) < q := by linarith
  have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
  have h_exp_pos : 0 < q / (q - 1) := div_pos hq_pos hqm1_pos
  obtain ⟨hD_ge_one, _⟩ := DeltaStarDef q hq
  have hD_pos : 0 < delta_star q := by linarith
  have h_dpow_ge_one : 1 ≤ (delta_star q) ^ (q / (q - 1)) :=
    Real.one_le_rpow hD_ge_one (le_of_lt h_exp_pos)
  linarith

/-- Continuity of the closed form on `(1, ∞)`. -/
private lemma lambda_closedForm_continuousOn :
    ContinuousOn lambda_closedForm (Set.Ioi (1 : ℝ)) := by
  -- Build up continuity piece by piece.
  have h_id : ContinuousOn (fun q : ℝ => q) (Set.Ioi (1 : ℝ)) := continuousOn_id
  have h_one : ContinuousOn (fun _ : ℝ => (1 : ℝ)) (Set.Ioi (1 : ℝ)) := continuousOn_const
  have h_qm1 : ContinuousOn (fun q : ℝ => q - 1) (Set.Ioi (1 : ℝ)) :=
    h_id.sub h_one
  -- q ≠ 0 on Ioi 1
  have hq_ne : ∀ q ∈ Set.Ioi (1 : ℝ), q ≠ 0 := fun q hq => by
    have : (1 : ℝ) < q := hq
    linarith
  -- q - 1 ≠ 0 on Ioi 1
  have hqm1_ne : ∀ q ∈ Set.Ioi (1 : ℝ), q - 1 ≠ 0 := fun q hq => by
    have : (1 : ℝ) < q := hq
    linarith
  -- Continuity of q ↦ q / (q - 1)
  have h_e : ContinuousOn (fun q : ℝ => q / (q - 1)) (Set.Ioi (1 : ℝ)) := by
    exact h_id.div h_qm1 hqm1_ne
  -- Continuity of delta_star
  have h_delta : ContinuousOn delta_star (Set.Ioi (1 : ℝ)) := DeltaStarContinuousOn
  -- delta_star q > 0 on Ioi 1
  have h_delta_pos : ∀ q ∈ Set.Ioi (1 : ℝ), 0 < delta_star q := fun q hq => by
    have hq1 : (1 : ℝ) < q := hq
    have ⟨h, _⟩ := DeltaStarDef q hq1
    linarith
  -- Continuity of q ↦ (delta_star q)^(q/(q-1))
  have h_dpow : ContinuousOn
      (fun q : ℝ => (delta_star q) ^ (q / (q - 1))) (Set.Ioi (1 : ℝ)) := by
    apply ContinuousOn.rpow h_delta h_e
    intro q hq
    left
    exact ne_of_gt (h_delta_pos q hq)
  -- Continuity of q ↦ 1 + (delta_star q)^(q/(q-1))
  have h_base : ContinuousOn
      (fun q : ℝ => 1 + (delta_star q) ^ (q / (q - 1))) (Set.Ioi (1 : ℝ)) :=
    h_one.add h_dpow
  -- Continuity of q ↦ (q - 1) / q
  have h_qm1_div_q : ContinuousOn (fun q : ℝ => (q - 1) / q) (Set.Ioi (1 : ℝ)) := by
    exact h_qm1.div h_id hq_ne
  -- Continuity of q ↦ -((q - 1) / q)
  have h_f : ContinuousOn (fun q : ℝ => -((q - 1) / q)) (Set.Ioi (1 : ℝ)) := by
    exact h_qm1_div_q.neg
  -- Base is positive on Ioi 1
  have h_base_pos : ∀ q ∈ Set.Ioi (1 : ℝ),
      0 < 1 + (delta_star q) ^ (q / (q - 1)) := fun q hq =>
    one_plus_delta_rpow_pos hq
  -- Continuity of the final rpow
  show ContinuousOn (fun q : ℝ =>
      (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q))) (Set.Ioi (1 : ℝ))
  apply ContinuousOn.rpow h_base h_f
  intro q hq
  left
  exact ne_of_gt (h_base_pos q hq)

/-- Differentiability of the closed form on `(1, ∞)`. -/
private lemma lambda_closedForm_differentiableOn :
    DifferentiableOn ℝ lambda_closedForm (Set.Ioi (1 : ℝ)) := by
  intro q hq
  have hq1 : (1 : ℝ) < q := hq
  have hq_pos : (0 : ℝ) < q := by linarith
  have hq_ne : q ≠ 0 := ne_of_gt hq_pos
  have hqm1_pos : (0 : ℝ) < q - 1 := by linarith
  have hqm1_ne : q - 1 ≠ 0 := ne_of_gt hqm1_pos
  obtain ⟨hD_ge_one, _⟩ := DeltaStarDef q hq1
  have hD_pos : 0 < delta_star q := by linarith
  have hD_ne : delta_star q ≠ 0 := ne_of_gt hD_pos
  have h_base_pos : 0 < 1 + (delta_star q) ^ (q / (q - 1)) :=
    one_plus_delta_rpow_pos hq1
  have h_base_ne : 1 + (delta_star q) ^ (q / (q - 1)) ≠ 0 :=
    ne_of_gt h_base_pos
  -- DifferentiableAt versions
  have hd_id : DifferentiableAt ℝ (fun q : ℝ => q) q := differentiableAt_id
  have hd_one : DifferentiableAt ℝ (fun _ : ℝ => (1 : ℝ)) q := differentiableAt_const _
  have hd_qm1 : DifferentiableAt ℝ (fun q : ℝ => q - 1) q := hd_id.sub hd_one
  -- e(q) = q/(q-1)
  have hd_e : DifferentiableAt ℝ (fun q : ℝ => q / (q - 1)) q :=
    hd_id.div hd_qm1 hqm1_ne
  -- delta_star differentiable at q
  have hd_delta : DifferentiableAt ℝ delta_star q := DeltaStarDifferentiable q hq1
  -- (delta_star q)^(q/(q-1)) differentiable at q
  have hd_dpow : DifferentiableAt ℝ
      (fun q : ℝ => (delta_star q) ^ (q / (q - 1))) q :=
    hd_delta.rpow hd_e hD_ne
  -- 1 + (delta_star q)^(q/(q-1)) differentiable
  have hd_base : DifferentiableAt ℝ
      (fun q : ℝ => 1 + (delta_star q) ^ (q / (q - 1))) q :=
    hd_one.add hd_dpow
  -- (q-1)/q
  have hd_qm1_div_q : DifferentiableAt ℝ (fun q : ℝ => (q - 1) / q) q :=
    hd_qm1.div hd_id hq_ne
  -- -((q-1)/q)
  have hd_f : DifferentiableAt ℝ (fun q : ℝ => -((q - 1) / q)) q :=
    hd_qm1_div_q.neg
  -- Final rpow
  have hd_final : DifferentiableAt ℝ
      (fun q : ℝ => (1 + (delta_star q) ^ (q / (q - 1))) ^ (-((q - 1) / q))) q :=
    hd_base.rpow hd_f h_base_ne
  exact hd_final.differentiableWithinAt

/-- Local helper: `lambda_star` is continuous on `(1, ∞)`. -/
private lemma lambda_star_continuousOn_Ioi :
    ContinuousOn lambda_star (Set.Ioi (1 : ℝ)) := by
  apply lambda_closedForm_continuousOn.congr
  intro q hq
  exact lambda_star_eq_closedForm hq

/-- Local helper: `lambda_star` is differentiable on `(1, ∞)`. -/
private lemma lambda_star_differentiableOn_Ioi :
    DifferentiableOn ℝ lambda_star (Set.Ioi (1 : ℝ)) := by
  apply lambda_closedForm_differentiableOn.congr
  intro q hq
  exact lambda_star_eq_closedForm hq

/-- Non-positivity of the derivative of `lambda_star` on `(1, ∞)`.
Cited from: Gravin & Jia, *Approximation guarantees of Median Mechanism in ℝ^d*,
arXiv:2502.08578v2, Theorem 1 / monotonicity of UB(q). The full chain-rule
derivative-sign step is paper-deferred ("tedious computation"). -/
private theorem deriv_lambda_star_nonpos :
    ∀ q : ℝ, 1 < q → deriv lambda_star q ≤ 0 := by
  sorry

theorem LambdaStarAntitone :
    AntitoneOn lambda_star (Set.Ici (1 : ℝ)) := by
  intro a ha b hb hab
  rcases eq_or_lt_of_le hab with heq | hlt
  · rw [heq]
  · have ha' : (1 : ℝ) ≤ a := ha
    have hb' : (1 : ℝ) ≤ b := hb
    rcases eq_or_lt_of_le ha' with ha_eq | ha_gt
    · have ha1 : a = 1 := ha_eq.symm
      obtain ⟨hbound, h1⟩ := LambdaStarDef
      have hb_le_one : lambda_star b ≤ 1 := (hbound b hb').2
      rw [ha1, h1]
      exact hb_le_one
    · have hConv : Convex ℝ (Set.Ioi (1 : ℝ)) := convex_Ioi 1
      have hInt : interior (Set.Ioi (1 : ℝ)) = Set.Ioi (1 : ℝ) := interior_Ioi
      have h_cont : ContinuousOn lambda_star (Set.Ioi (1 : ℝ)) :=
        lambda_star_continuousOn_Ioi
      have h_diff : DifferentiableOn ℝ lambda_star (interior (Set.Ioi (1 : ℝ))) := by
        rw [hInt]; exact lambda_star_differentiableOn_Ioi
      have h_deriv_nonpos :
          ∀ q ∈ interior (Set.Ioi (1 : ℝ)), deriv lambda_star q ≤ 0 := by
        rw [hInt]; intro q hq; exact deriv_lambda_star_nonpos q hq
      have h_anti : AntitoneOn lambda_star (Set.Ioi (1 : ℝ)) :=
        antitoneOn_of_deriv_nonpos hConv h_cont h_diff h_deriv_nonpos
      have ha_in : a ∈ Set.Ioi (1 : ℝ) := ha_gt
      have hb_in : b ∈ Set.Ioi (1 : ℝ) := lt_of_lt_of_le ha_gt hab
      exact h_anti ha_in hb_in hab
